Grailbird.data.tweets_2012_05 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Ruelle",
      "screen_name" : "danrmitvn",
      "indices" : [ 0, 10 ],
      "id_str" : "125853393",
      "id" : 125853393
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "208220386628861952",
  "geo" : { },
  "id_str" : "208223267440431106",
  "in_reply_to_user_id" : 125853393,
  "text" : "@danrmitvn ta very much",
  "id" : 208223267440431106,
  "in_reply_to_status_id" : 208220386628861952,
  "created_at" : "2012-05-31 15:47:50 +0000",
  "in_reply_to_screen_name" : "danrmitvn",
  "in_reply_to_user_id_str" : "125853393",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Ruelle",
      "screen_name" : "danrmitvn",
      "indices" : [ 0, 10 ],
      "id_str" : "125853393",
      "id" : 125853393
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "moore",
      "indices" : [ 42, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208220228906270721",
  "in_reply_to_user_id" : 125853393,
  "text" : "@danrmitvn many many thanks for the julie #moore academic vocab webinar tweets. any ref links provided at end?",
  "id" : 208220228906270721,
  "created_at" : "2012-05-31 15:35:45 +0000",
  "in_reply_to_screen_name" : "danrmitvn",
  "in_reply_to_user_id_str" : "125853393",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Ruelle",
      "screen_name" : "danrmitvn",
      "indices" : [ 0, 10 ],
      "id_str" : "125853393",
      "id" : 125853393
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "208200360609841152",
  "geo" : { },
  "id_str" : "208200757164523520",
  "in_reply_to_user_id" : 125853393,
  "text" : "@danrmitvn sweet",
  "id" : 208200757164523520,
  "in_reply_to_status_id" : 208200360609841152,
  "created_at" : "2012-05-31 14:18:23 +0000",
  "in_reply_to_screen_name" : "danrmitvn",
  "in_reply_to_user_id_str" : "125853393",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Ruelle",
      "screen_name" : "danrmitvn",
      "indices" : [ 0, 10 ],
      "id_str" : "125853393",
      "id" : 125853393
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "208198444395925505",
  "geo" : { },
  "id_str" : "208199499011723266",
  "in_reply_to_user_id" : 125853393,
  "text" : "@danrmitvn okay cool, i did register yesterday but somehow it failed! maybe you can tweet some of the webinar ? :)",
  "id" : 208199499011723266,
  "in_reply_to_status_id" : 208198444395925505,
  "created_at" : "2012-05-31 14:13:23 +0000",
  "in_reply_to_screen_name" : "danrmitvn",
  "in_reply_to_user_id_str" : "125853393",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Ruelle",
      "screen_name" : "danrmitvn",
      "indices" : [ 0, 10 ],
      "id_str" : "125853393",
      "id" : 125853393
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "208182546717089793",
  "geo" : { },
  "id_str" : "208183744283160576",
  "in_reply_to_user_id" : 125853393,
  "text" : "@danrmitvn hi if u dont' want to attend academic vocab one can i have that link? :)",
  "id" : 208183744283160576,
  "in_reply_to_status_id" : 208182546717089793,
  "created_at" : "2012-05-31 13:10:47 +0000",
  "in_reply_to_screen_name" : "danrmitvn",
  "in_reply_to_user_id_str" : "125853393",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/208183276014272512\/photo\/1",
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/KGFRBrf3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AuOdlidCAAAQWVd.png",
      "id_str" : "208183276018466816",
      "id" : 208183276018466816,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AuOdlidCAAAQWVd.png",
      "sizes" : [ {
        "h" : 287,
        "resize" : "fit",
        "w" : 411
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 287,
        "resize" : "fit",
        "w" : 411
      }, {
        "h" : 237,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 287,
        "resize" : "fit",
        "w" : 411
      } ],
      "display_url" : "pic.twitter.com\/KGFRBrf3"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/Z2QuT3u8",
      "expanded_url" : "http:\/\/www.eurotrib.com",
      "display_url" : "eurotrib.com"
    } ]
  },
  "geo" : { },
  "id_str" : "208183276014272512",
  "text" : "Stereotyping in Europe - imo graphic shows Southern Europe most honest re nat corruption HT http:\/\/t.co\/Z2QuT3u8 http:\/\/t.co\/KGFRBrf3",
  "id" : 208183276014272512,
  "created_at" : "2012-05-31 13:08:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 40 ],
      "url" : "http:\/\/t.co\/y4sqapk0",
      "expanded_url" : "http:\/\/www.medialens.org\/index.php?option=com_content&view=article&id=682:the-houla-massacre&catid=25:alerts-2012&Itemid=69#.T8dm78qEXVs.twitter",
      "display_url" : "medialens.org\/index.php?opti\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "208178338982920193",
  "text" : "The Houla Massacre: http:\/\/t.co\/y4sqapk0",
  "id" : 208178338982920193,
  "created_at" : "2012-05-31 12:49:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 51, 61 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http:\/\/t.co\/l4sp2piq",
      "expanded_url" : "http:\/\/www.waronwant.org\/campaigns\/justice-for-palestine\/save-silwan\/17529-act-now-stop-the-bulldozers",
      "display_url" : "waronwant.org\/campaigns\/just\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "208175742004109312",
  "text" : "Stop the bulldozers June 1 http:\/\/t.co\/l4sp2piq HT @medialens",
  "id" : 208175742004109312,
  "created_at" : "2012-05-31 12:38:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/LP3t8owF",
      "expanded_url" : "http:\/\/elt.oup.com\/feature\/global\/upcoming_events\/approaches_to_teaching_academic_vocabulary?cc=fr&selLanguage=en",
      "display_url" : "elt.oup.com\/feature\/global\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "208174324287422464",
  "text" : "bugger my registration failed for http:\/\/t.co\/LP3t8owF for this afternoon?, hopefully recording will b available!",
  "id" : 208174324287422464,
  "created_at" : "2012-05-31 12:33:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http:\/\/t.co\/LP3t8owF",
      "expanded_url" : "http:\/\/elt.oup.com\/feature\/global\/upcoming_events\/approaches_to_teaching_academic_vocabulary?cc=fr&selLanguage=en",
      "display_url" : "elt.oup.com\/feature\/global\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "208138102131269632",
  "text" : "anyone got the link to http:\/\/t.co\/LP3t8owF for this afternoon?",
  "id" : 208138102131269632,
  "created_at" : "2012-05-31 10:09:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "michaelcraiggradwell",
      "screen_name" : "michaelcraig",
      "indices" : [ 0, 13 ],
      "id_str" : "805969",
      "id" : 805969
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/9lLx1GPC",
      "expanded_url" : "http:\/\/bit.ly\/H10jDy",
      "display_url" : "bit.ly\/H10jDy"
    } ]
  },
  "in_reply_to_status_id_str" : "208118911516942336",
  "geo" : { },
  "id_str" : "208127213902643200",
  "in_reply_to_user_id" : 805969,
  "text" : "@michaelcraig hit back with stats, according to this http:\/\/t.co\/9lLx1GPC teens and adults use Twitter at similar rates :)",
  "id" : 208127213902643200,
  "in_reply_to_status_id" : 208118911516942336,
  "created_at" : "2012-05-31 09:26:09 +0000",
  "in_reply_to_screen_name" : "michaelcraig",
  "in_reply_to_user_id_str" : "805969",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "indices" : [ 51, 66 ],
      "id_str" : "27716419",
      "id" : 27716419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/OZYBfwMd",
      "expanded_url" : "http:\/\/www.craigmurray.org.uk\/archives\/2012\/05\/back-in-business\/",
      "display_url" : "craigmurray.org.uk\/archives\/2012\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "207968564202848256",
  "text" : "French judiciaire vs English judicial Craig Murray\/@CraigMurrayOrg on recent Assange appeal  http:\/\/t.co\/OZYBfwMd",
  "id" : 207968564202848256,
  "created_at" : "2012-05-30 22:55:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/V2WFlcsx",
      "expanded_url" : "http:\/\/www.rawa.org\/temp\/runews\/rawanews.php?id=2807",
      "display_url" : "rawa.org\/temp\/runews\/ra\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "207872027963559936",
  "text" : "Civilian deaths in Afghanistan continue uncheck  http:\/\/t.co\/V2WFlcsx",
  "id" : 207872027963559936,
  "created_at" : "2012-05-30 16:32:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/rZPa0gHM",
      "expanded_url" : "http:\/\/www.indymedia.org.uk\/en\/2012\/05\/496104.html",
      "display_url" : "indymedia.org.uk\/en\/2012\/05\/496\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "207810987364073473",
  "text" : "4,000 days today! The Parliament Square peace campaign continues http:\/\/t.co\/rZPa0gHM",
  "id" : 207810987364073473,
  "created_at" : "2012-05-30 12:29:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "British Council",
      "screen_name" : "AsiaELT",
      "indices" : [ 0, 8 ],
      "id_str" : "299641719",
      "id" : 299641719
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207417148660912128",
  "geo" : { },
  "id_str" : "207586934988607489",
  "in_reply_to_user_id" : 299641719,
  "text" : "@AsiaELT yr welcome :)",
  "id" : 207586934988607489,
  "in_reply_to_status_id" : 207417148660912128,
  "created_at" : "2012-05-29 21:39:16 +0000",
  "in_reply_to_screen_name" : "AsiaELT",
  "in_reply_to_user_id_str" : "299641719",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Novak",
      "screen_name" : "paleofuture",
      "indices" : [ 3, 15 ],
      "id_str" : "16877374",
      "id" : 16877374
    }, {
      "name" : "Paleofuture",
      "screen_name" : "PaleofutureBlog",
      "indices" : [ 17, 33 ],
      "id_str" : "221619593",
      "id" : 221619593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/f24o1qTJ",
      "expanded_url" : "http:\/\/blogs.smithsonianmag.com\/paleofuture\/2012\/05\/predictions-for-educational-tv-in-the-1930s\/",
      "display_url" : "blogs.smithsonianmag.com\/paleofuture\/20\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "207567350369751040",
  "text" : "MT @paleofuture: @PaleofutureBlog looks at predictions for educational TV: http:\/\/t.co\/f24o1qTJ&lt;--fascinating history; &amp; future of ed tech?",
  "id" : 207567350369751040,
  "created_at" : "2012-05-29 20:21:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pahriadi Noerbek",
      "screen_name" : "Pahriadi62",
      "indices" : [ 0, 11 ],
      "id_str" : "333444285",
      "id" : 333444285
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207420795234947073",
  "geo" : { },
  "id_str" : "207450246169636864",
  "in_reply_to_user_id" : 333444285,
  "text" : "@Pahriadi62 hello there nice to tweet u :)",
  "id" : 207450246169636864,
  "in_reply_to_status_id" : 207420795234947073,
  "created_at" : "2012-05-29 12:36:07 +0000",
  "in_reply_to_screen_name" : "Pahriadi62",
  "in_reply_to_user_id_str" : "333444285",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Seymour",
      "screen_name" : "leninology",
      "indices" : [ 80, 91 ],
      "id_str" : "15557246",
      "id" : 15557246
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/LijwV5ML",
      "expanded_url" : "http:\/\/www.leninology.com\/2012\/05\/what-bbc-newsnight-did-to-shanene.html",
      "display_url" : "leninology.com\/2012\/05\/what-b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "207401460256874497",
  "text" : "LENIN'S TOMB: What BBC Newsnight did to Shanene Thorpe http:\/\/t.co\/LijwV5ML via @leninology&lt;incisive analysis as usual",
  "id" : 207401460256874497,
  "created_at" : "2012-05-29 09:22:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cheimi10",
      "screen_name" : "cheimi10",
      "indices" : [ 44, 53 ],
      "id_str" : "2547295525",
      "id" : 2547295525
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AsiaELT",
      "indices" : [ 116, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/EOTbhXDA",
      "expanded_url" : "http:\/\/bit.ly\/GA6drW",
      "display_url" : "bit.ly\/GA6drW"
    } ]
  },
  "geo" : { },
  "id_str" : "207329000958328834",
  "text" : "just quickly popping by to share this where @cheimi10 describes video telling http:\/\/t.co\/EOTbhXDA, hve a grt chat! #AsiaELT",
  "id" : 207329000958328834,
  "created_at" : "2012-05-29 04:34:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/dAGf8LcC",
      "expanded_url" : "http:\/\/gu.com\/p\/37q53\/tw",
      "display_url" : "gu.com\/p\/37q53\/tw"
    }, {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/LFczFjQm",
      "expanded_url" : "http:\/\/johnmullenagen.blogspot.com",
      "display_url" : "johnmullenagen.blogspot.com"
    } ]
  },
  "geo" : { },
  "id_str" : "207052245638975489",
  "text" : "France's champion of the left sends a challenge to Marine Le Pen http:\/\/t.co\/dAGf8LcC via http:\/\/t.co\/LFczFjQm",
  "id" : 207052245638975489,
  "created_at" : "2012-05-28 10:14:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 43, 59 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 38 ],
      "url" : "http:\/\/t.co\/5r2jer3p",
      "expanded_url" : "http:\/\/wp.me\/p1tYEb-oU",
      "display_url" : "wp.me\/p1tYEb-oU"
    } ]
  },
  "geo" : { },
  "id_str" : "207042774686642176",
  "text" : "Guarding the well http:\/\/t.co\/5r2jer3p via @wordpressdotcom &lt;--great post on MOOCs and Higher Ed",
  "id" : 207042774686642176,
  "created_at" : "2012-05-28 09:36:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Patterson",
      "screen_name" : "Brad5Patterson",
      "indices" : [ 0, 15 ],
      "id_str" : "944237276",
      "id" : 944237276
    }, {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 16, 27 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207026647264800770",
  "geo" : { },
  "id_str" : "207029411395018752",
  "in_reply_to_user_id" : 236921161,
  "text" : "@brad5patterson @leoselivan not been to Montsouris will need to check it, thx. for picnicing, in a non-park, i do like canal st martin",
  "id" : 207029411395018752,
  "in_reply_to_status_id" : 207026647264800770,
  "created_at" : "2012-05-28 08:43:52 +0000",
  "in_reply_to_screen_name" : "wordtov",
  "in_reply_to_user_id_str" : "236921161",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "Brad Patterson",
      "screen_name" : "Brad5Patterson",
      "indices" : [ 12, 27 ],
      "id_str" : "944237276",
      "id" : 944237276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207012233878839296",
  "geo" : { },
  "id_str" : "207026304753729536",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan @brad5patterson had a quick look Parc Floral and Bois de Vincennes not mentioned; wld agree buttes chaumont is worth a visit",
  "id" : 207026304753729536,
  "in_reply_to_status_id" : 207012233878839296,
  "created_at" : "2012-05-28 08:31:32 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http:\/\/t.co\/qXRqASsc",
      "expanded_url" : "http:\/\/boingboing.net\/2012\/05\/27\/cpu-wars-top-trumps-with-cpus.html",
      "display_url" : "boingboing.net\/2012\/05\/27\/cpu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "206837503498518528",
  "text" : "CPU Wars: Top Trumps with CPUs: http:\/\/t.co\/qXRqASsc&lt;--sweet just ordered a set",
  "id" : 206837503498518528,
  "created_at" : "2012-05-27 20:01:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206802729723625472",
  "text" : "if u get the chance i recommend watching Vivianne Westwood docu - DIY",
  "id" : 206802729723625472,
  "created_at" : "2012-05-27 17:43:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josette LeBlanc",
      "screen_name" : "JosetteLB",
      "indices" : [ 0, 10 ],
      "id_str" : "33503694",
      "id" : 33503694
    }, {
      "name" : "John T. Spencer",
      "screen_name" : "JohnTSpencer",
      "indices" : [ 11, 24 ],
      "id_str" : "2285706270",
      "id" : 2285706270
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "206736834905116673",
  "geo" : { },
  "id_str" : "206738206115368960",
  "in_reply_to_user_id" : 33503694,
  "text" : "@JosetteLB @johntspencer nice writing website thanks for heads up josette",
  "id" : 206738206115368960,
  "in_reply_to_status_id" : 206736834905116673,
  "created_at" : "2012-05-27 13:26:44 +0000",
  "in_reply_to_screen_name" : "JosetteLB",
  "in_reply_to_user_id_str" : "33503694",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karenne Sylvester",
      "screen_name" : "kalinagoenglish",
      "indices" : [ 3, 19 ],
      "id_str" : "22755100",
      "id" : 22755100
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 85, 93 ]
    }, {
      "text" : "mlearning",
      "indices" : [ 94, 104 ]
    }, {
      "text" : "edtech",
      "indices" : [ 105, 112 ]
    }, {
      "text" : "tesol",
      "indices" : [ 113, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/CQyazcy6",
      "expanded_url" : "http:\/\/ow.ly\/baY8k",
      "display_url" : "ow.ly\/baY8k"
    } ]
  },
  "geo" : { },
  "id_str" : "206726800133455872",
  "text" : "RT @kalinagoenglish: Analysis of Android Language Teaching Apps http:\/\/t.co\/CQyazcy6 #eltchat #mlearning #edtech #tesol&lt;--needed initiative!",
  "id" : 206726800133455872,
  "created_at" : "2012-05-27 12:41:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "206016887803494402",
  "geo" : { },
  "id_str" : "206032646189494273",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow a school drinking party in the country! sounds well sweet! enjoy!",
  "id" : 206032646189494273,
  "in_reply_to_status_id" : 206016887803494402,
  "created_at" : "2012-05-25 14:43:05 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    }, {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 107, 118 ],
      "id_str" : "282659955",
      "id" : 282659955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205795124444278784",
  "geo" : { },
  "id_str" : "205983927742111744",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow  there is a typo \"subject verb object structure\" in para 2; want to use yr ideas and refs from @teflerinha to help my TOEIC sts",
  "id" : 205983927742111744,
  "in_reply_to_status_id" : 205795124444278784,
  "created_at" : "2012-05-25 11:29:30 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sandy Millin",
      "screen_name" : "sandymillin",
      "indices" : [ 0, 12 ],
      "id_str" : "144236944",
      "id" : 144236944
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205747247567216641",
  "geo" : { },
  "id_str" : "205752407437737986",
  "in_reply_to_user_id" : 144236944,
  "text" : "@sandymillin hi link not working",
  "id" : 205752407437737986,
  "in_reply_to_status_id" : 205747247567216641,
  "created_at" : "2012-05-24 20:09:31 +0000",
  "in_reply_to_screen_name" : "sandymillin",
  "in_reply_to_user_id_str" : "144236944",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 3, 14 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EFL",
      "indices" : [ 72, 76 ]
    }, {
      "text" : "ELTchat",
      "indices" : [ 77, 85 ]
    }, {
      "text" : "TESOL",
      "indices" : [ 86, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/ieLXidG7",
      "expanded_url" : "http:\/\/scr.bi\/MKfEuk",
      "display_url" : "scr.bi\/MKfEuk"
    } ]
  },
  "geo" : { },
  "id_str" : "205687455364546560",
  "text" : "MT @kevchanwow Even Native Speaker Stops Sometimes http:\/\/t.co\/ieLXidG7 #EFL #ELTchat #TESOL&lt;-grt writing style all tch papers be like this",
  "id" : 205687455364546560,
  "created_at" : "2012-05-24 15:51:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "phil wade",
      "screen_name" : "phil3wade",
      "indices" : [ 0, 10 ],
      "id_str" : "248864761",
      "id" : 248864761
    }, {
      "name" : "TESOL France",
      "screen_name" : "TESOLFrance",
      "indices" : [ 11, 23 ],
      "id_str" : "70341872",
      "id" : 70341872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205675859623948289",
  "geo" : { },
  "id_str" : "205683998888955904",
  "in_reply_to_user_id" : 248864761,
  "text" : "@phil3wade @TESOLFrance imposs to change 4:3 to widescreen! maybe blogger has option to make pixels fluid instead of fixed?",
  "id" : 205683998888955904,
  "in_reply_to_status_id" : 205675859623948289,
  "created_at" : "2012-05-24 15:37:41 +0000",
  "in_reply_to_screen_name" : "phil3wade",
  "in_reply_to_user_id_str" : "248864761",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "phil wade",
      "screen_name" : "phil3wade",
      "indices" : [ 3, 13 ],
      "id_str" : "248864761",
      "id" : 248864761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205683206991773696",
  "text" : "RT @phil3wade: TPR is where you train your stdts to make you a cup of tea every time u say \"I'm thirsty\". &lt;--hehe :0",
  "id" : 205683206991773696,
  "created_at" : "2012-05-24 15:34:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "phil wade",
      "screen_name" : "phil3wade",
      "indices" : [ 0, 10 ],
      "id_str" : "248864761",
      "id" : 248864761
    }, {
      "name" : "TESOL France",
      "screen_name" : "TESOLFrance",
      "indices" : [ 11, 23 ],
      "id_str" : "70341872",
      "id" : 70341872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205669845285609472",
  "geo" : { },
  "id_str" : "205673594024493056",
  "in_reply_to_user_id" : 248864761,
  "text" : "@phil3wade @TESOLFrance not size but resolution, i hv 15inch screen but it is 4:3 not widescreen. fluid(%) instead of fixed pixels?",
  "id" : 205673594024493056,
  "in_reply_to_status_id" : 205669845285609472,
  "created_at" : "2012-05-24 14:56:20 +0000",
  "in_reply_to_screen_name" : "phil3wade",
  "in_reply_to_user_id_str" : "248864761",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "phil wade",
      "screen_name" : "phil3wade",
      "indices" : [ 0, 10 ],
      "id_str" : "248864761",
      "id" : 248864761
    }, {
      "name" : "TESOL France",
      "screen_name" : "TESOLFrance",
      "indices" : [ 11, 23 ],
      "id_str" : "70341872",
      "id" : 70341872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205663298417467392",
  "geo" : { },
  "id_str" : "205669356481425409",
  "in_reply_to_user_id" : 248864761,
  "text" : "@phil3wade @TESOLFrance slightly better but still have to scroll.",
  "id" : 205669356481425409,
  "in_reply_to_status_id" : 205663298417467392,
  "created_at" : "2012-05-24 14:39:30 +0000",
  "in_reply_to_screen_name" : "phil3wade",
  "in_reply_to_user_id_str" : "248864761",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TESOL France",
      "screen_name" : "TESOLFrance",
      "indices" : [ 0, 12 ],
      "id_str" : "70341872",
      "id" : 70341872
    }, {
      "name" : "phil wade",
      "screen_name" : "phil3wade",
      "indices" : [ 13, 23 ],
      "id_str" : "248864761",
      "id" : 248864761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205658190581481473",
  "geo" : { },
  "id_str" : "205659783221608448",
  "in_reply_to_user_id" : 70341872,
  "text" : "@TESOLFrance @phil3wade looks good but is designed for widescreen display? i have 4:3 screen so right hand side have to scroll.",
  "id" : 205659783221608448,
  "in_reply_to_status_id" : 205658190581481473,
  "created_at" : "2012-05-24 14:01:27 +0000",
  "in_reply_to_screen_name" : "TESOLFrance",
  "in_reply_to_user_id_str" : "70341872",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/AsL3nUtz",
      "expanded_url" : "http:\/\/truth-out.org\/opinion\/item\/9043-why-isnt-closing-40-philadelphia-public-schools-national-news",
      "display_url" : "truth-out.org\/opinion\/item\/9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "205398759557971969",
  "text" : "Why Isn't Closing 40 Philadelphia Public Schools National News? http:\/\/t.co\/AsL3nUtz",
  "id" : 205398759557971969,
  "created_at" : "2012-05-23 20:44:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELTons",
      "indices" : [ 30, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205361201679581184",
  "text" : "looks a bit empty audience at #ELTons or is it still early?",
  "id" : 205361201679581184,
  "created_at" : "2012-05-23 18:15:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elinda Gjondedaj",
      "screen_name" : "ElindaGjondedaj",
      "indices" : [ 0, 16 ],
      "id_str" : "72877592",
      "id" : 72877592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205349148868886530",
  "geo" : { },
  "id_str" : "205359219652837376",
  "in_reply_to_user_id" : 72877592,
  "text" : "@ElindaGjondedaj congrats elinda, look forward to your edu programs!",
  "id" : 205359219652837376,
  "in_reply_to_status_id" : 205349148868886530,
  "created_at" : "2012-05-23 18:07:08 +0000",
  "in_reply_to_screen_name" : "ElindaGjondedaj",
  "in_reply_to_user_id_str" : "72877592",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/FgIFjUgY",
      "expanded_url" : "http:\/\/www.google.com\/doodles\/robert-moogs-78th-birthday",
      "display_url" : "google.com\/doodles\/robert\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "205332322420133888",
  "text" : "Google's Moog birthday anniversary animation pretty darn tight http:\/\/t.co\/FgIFjUgY",
  "id" : 205332322420133888,
  "created_at" : "2012-05-23 16:20:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205318230523392000",
  "geo" : { },
  "id_str" : "205318726231396352",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan sorry, what was the talk on?",
  "id" : 205318726231396352,
  "in_reply_to_status_id" : 205318230523392000,
  "created_at" : "2012-05-23 15:26:13 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205317301094973440",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan no, what was it on?",
  "id" : 205317301094973440,
  "created_at" : "2012-05-23 15:20:33 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Digital Play",
      "screen_name" : "eltdigitalplay",
      "indices" : [ 4, 19 ],
      "id_str" : "67682458",
      "id" : 67682458
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELTons",
      "indices" : [ 20, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205316515262771202",
  "text" : "FTW @eltdigitalplay #ELTons",
  "id" : 205316515262771202,
  "created_at" : "2012-05-23 15:17:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/tMRJv7mB",
      "expanded_url" : "http:\/\/youtu.be\/ZvUwC5JTAJY",
      "display_url" : "youtu.be\/ZvUwC5JTAJY"
    } ]
  },
  "geo" : { },
  "id_str" : "205311183174119425",
  "text" : "a great jovial Julian Assange interview with President of Ecuador, Rafael Correa http:\/\/t.co\/tMRJv7mB",
  "id" : 205311183174119425,
  "created_at" : "2012-05-23 14:56:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 104, 114 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/UIsClwKF",
      "expanded_url" : "http:\/\/www.chomsky.info\/talks\/20110406.htm",
      "display_url" : "chomsky.info\/talks\/20110406\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "205297397264420865",
  "text" : "\/implement the policy of indoctrination of the young by trapping them in debt\/  http:\/\/t.co\/UIsClwKF HT @medialens",
  "id" : 205297397264420865,
  "created_at" : "2012-05-23 14:01:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roger Dupuy",
      "screen_name" : "rogerdupuy",
      "indices" : [ 3, 14 ],
      "id_str" : "13498092",
      "id" : 13498092
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "actionresearch",
      "indices" : [ 47, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/FrfuB1ud",
      "expanded_url" : "http:\/\/connectedlearning.tv\/case-studies\/los-feliz-charter-school-arts-case-teaching-whole-child",
      "display_url" : "connectedlearning.tv\/case-studies\/l\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "205034618305515521",
  "text" : "MT @rogerdupuy: I like teachers walking around #actionresearch http:\/\/t.co\/FrfuB1ud&lt;--amazing school!",
  "id" : 205034618305515521,
  "created_at" : "2012-05-22 20:37:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/E37s2Ezm",
      "expanded_url" : "http:\/\/tbogg.firedoglake.com\/2012\/05\/20\/internet-man-does-not-want-to-be-on-the-google-anymore\/",
      "display_url" : "tbogg.firedoglake.com\/2012\/05\/20\/int\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "204789012945309696",
  "text" : "not sure if this character is made up or not? http:\/\/t.co\/E37s2Ezm",
  "id" : 204789012945309696,
  "created_at" : "2012-05-22 04:21:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Forbes",
      "screen_name" : "GenkiSarah",
      "indices" : [ 0, 11 ],
      "id_str" : "586340658",
      "id" : 586340658
    }, {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 12, 23 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "204769406528651264",
  "geo" : { },
  "id_str" : "204775685200416768",
  "in_reply_to_user_id" : 586340658,
  "text" : "@GenkiSarah @kevchanwow @sarahatktc just been reading about yr collab project and teaching in high schools on yr blog, amazing work!",
  "id" : 204775685200416768,
  "in_reply_to_status_id" : 204769406528651264,
  "created_at" : "2012-05-22 03:28:22 +0000",
  "in_reply_to_screen_name" : "GenkiSarah",
  "in_reply_to_user_id_str" : "586340658",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "204541124071800833",
  "geo" : { },
  "id_str" : "204581176936108033",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow @SarahatKTC hi there welcome to twitter!",
  "id" : 204581176936108033,
  "in_reply_to_status_id" : 204541124071800833,
  "created_at" : "2012-05-21 14:35:28 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elmira Merve Oflaz",
      "screen_name" : "oflazmerve",
      "indices" : [ 0, 11 ],
      "id_str" : "263866847",
      "id" : 263866847
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "204405253326639104",
  "geo" : { },
  "id_str" : "204460647315030016",
  "in_reply_to_user_id" : 263866847,
  "text" : "@oflazmerve good luck!",
  "id" : 204460647315030016,
  "in_reply_to_status_id" : 204405253326639104,
  "created_at" : "2012-05-21 06:36:31 +0000",
  "in_reply_to_screen_name" : "oflazmerve",
  "in_reply_to_user_id_str" : "263866847",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "204301859056386048",
  "geo" : { },
  "id_str" : "204307460775886848",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan a good thing no? depending on comment of course. :\/",
  "id" : 204307460775886848,
  "in_reply_to_status_id" : 204301859056386048,
  "created_at" : "2012-05-20 20:27:49 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zachary Jones",
      "screen_name" : "ZJonesSpanish",
      "indices" : [ 0, 14 ],
      "id_str" : "522281504",
      "id" : 522281504
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "204304482211864576",
  "geo" : { },
  "id_str" : "204306595067346944",
  "in_reply_to_user_id" : 195187694,
  "text" : "@ZJonesSpanish well done that's great! hope you move up to top spot!",
  "id" : 204306595067346944,
  "in_reply_to_status_id" : 204304482211864576,
  "created_at" : "2012-05-20 20:24:22 +0000",
  "in_reply_to_screen_name" : "Zamb0mbazo",
  "in_reply_to_user_id_str" : "195187694",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "204210947571716097",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan hope your online PLN talk went swimmingly!",
  "id" : 204210947571716097,
  "created_at" : "2012-05-20 14:04:18 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/Kumybadx",
      "expanded_url" : "http:\/\/www.private-eye.co.uk\/sections.php?section_link=in_the_back&",
      "display_url" : "private-eye.co.uk\/sections.php?s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "204208619712024576",
  "text" : "London Olympics Inoculation 4: LOCOG\u2019S OLYMPIC KNITWITS http:\/\/t.co\/Kumybadx",
  "id" : 204208619712024576,
  "created_at" : "2012-05-20 13:55:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Sample",
      "screen_name" : "samplereality",
      "indices" : [ 3, 17 ],
      "id_str" : "8497292",
      "id" : 8497292
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thatcamp",
      "indices" : [ 86, 95 ]
    }, {
      "text" : "pmt",
      "indices" : [ 96, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/gXGetvOi",
      "expanded_url" : "http:\/\/bit.ly\/M7oO15",
      "display_url" : "bit.ly\/M7oO15"
    } ]
  },
  "geo" : { },
  "id_str" : "204207081237127169",
  "text" : "MT @samplereality: \"Hacking Classroom\"  notes from \"Hacking Campus Spaces\" session at #thatcamp #pmt http:\/\/t.co\/gXGetvOi",
  "id" : 204207081237127169,
  "created_at" : "2012-05-20 13:48:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/eLNkpPpG",
      "expanded_url" : "http:\/\/www.eurotrib.com\/story\/2012\/5\/18\/17414\/3885",
      "display_url" : "eurotrib.com\/story\/2012\/5\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "203822278683787264",
  "text" : "$1,000,000,000,000 or what we must remember http:\/\/t.co\/eLNkpPpG",
  "id" : 203822278683787264,
  "created_at" : "2012-05-19 12:19:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol Goodey",
      "screen_name" : "cgoodey",
      "indices" : [ 0, 8 ],
      "id_str" : "26606833",
      "id" : 26606833
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203773093150330880",
  "geo" : { },
  "id_str" : "203789959310737408",
  "in_reply_to_user_id" : 26606833,
  "text" : "@cgoodey thx you too!",
  "id" : 203789959310737408,
  "in_reply_to_status_id" : 203773093150330880,
  "created_at" : "2012-05-19 10:11:27 +0000",
  "in_reply_to_screen_name" : "cgoodey",
  "in_reply_to_user_id_str" : "26606833",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "Henrick Oprea",
      "screen_name" : "hoprea",
      "indices" : [ 12, 19 ],
      "id_str" : "14902916",
      "id" : 14902916
    }, {
      "name" : "gareth davies",
      "screen_name" : "reasons4",
      "indices" : [ 20, 29 ],
      "id_str" : "413454135",
      "id" : 413454135
    }, {
      "name" : "Luiz Otavio Barros",
      "screen_name" : "luizotavioELT",
      "indices" : [ 30, 44 ],
      "id_str" : "54798894",
      "id" : 54798894
    }, {
      "name" : "Carol Goodey",
      "screen_name" : "cgoodey",
      "indices" : [ 45, 53 ],
      "id_str" : "26606833",
      "id" : 26606833
    }, {
      "name" : "Chiew Pang",
      "screen_name" : "aClilToClimb",
      "indices" : [ 54, 67 ],
      "id_str" : "76160458",
      "id" : 76160458
    }, {
      "name" : "Laura Patsko",
      "screen_name" : "lauraahaha",
      "indices" : [ 68, 79 ],
      "id_str" : "97957137",
      "id" : 97957137
    }, {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "indices" : [ 80, 93 ],
      "id_str" : "1685397408",
      "id" : 1685397408
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sat",
      "indices" : [ 104, 108 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203559283172982784",
  "geo" : { },
  "id_str" : "203763841761423360",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan @hoprea @reasons4 @luizotavioELT @cgoodey @aClilToClimb @lauraahaha @harrisonmike ta leo, a #sat shoutout to all you good people",
  "id" : 203763841761423360,
  "in_reply_to_status_id" : 203559283172982784,
  "created_at" : "2012-05-19 08:27:40 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slashdot",
      "screen_name" : "slashdot",
      "indices" : [ 68, 77 ],
      "id_str" : "1068831",
      "id" : 1068831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/IHdvOOdq",
      "expanded_url" : "http:\/\/bit.ly\/JHcIeH",
      "display_url" : "bit.ly\/JHcIeH"
    } ]
  },
  "geo" : { },
  "id_str" : "203418487207632896",
  "text" : "GMU Prof Teaches How To Falsify Wikipedia  http:\/\/t.co\/IHdvOOdq via @slashdot",
  "id" : 203418487207632896,
  "created_at" : "2012-05-18 09:35:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anna Loseva",
      "screen_name" : "AnnLoseva",
      "indices" : [ 0, 10 ],
      "id_str" : "38822368",
      "id" : 38822368
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "203171769820000256",
  "geo" : { },
  "id_str" : "203393766936154112",
  "in_reply_to_user_id" : 38822368,
  "text" : "@AnnLoseva reading and commenting on blogs for me; can't shove down others throat but mention it casually good approach",
  "id" : 203393766936154112,
  "in_reply_to_status_id" : 203171769820000256,
  "created_at" : "2012-05-18 07:57:07 +0000",
  "in_reply_to_screen_name" : "AnnLoseva",
  "in_reply_to_user_id_str" : "38822368",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anna Loseva",
      "screen_name" : "AnnLoseva",
      "indices" : [ 3, 13 ],
      "id_str" : "38822368",
      "id" : 38822368
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELT",
      "indices" : [ 95, 99 ]
    }, {
      "text" : "ESL",
      "indices" : [ 100, 104 ]
    }, {
      "text" : "EFL",
      "indices" : [ 105, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203393300508585984",
  "text" : "MT @AnnLoseva: What's in PLN for YOU? What should we say about PLN to those who are skeptical? #ELT #ESL #EFL",
  "id" : 203393300508585984,
  "created_at" : "2012-05-18 07:55:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/Aj8p71Mv",
      "expanded_url" : "http:\/\/www.zcommunications.org\/never-forget-that-bradley-manning-not-gay-marriage-is-the-issue-by-john-pilger",
      "display_url" : "zcommunications.org\/never-forget-t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "203205841543901184",
  "text" : "Pilger's latest Never Forget That Bradley Manning http:\/\/t.co\/Aj8p71Mv",
  "id" : 203205841543901184,
  "created_at" : "2012-05-17 19:30:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Patterson",
      "screen_name" : "Brad5Patterson",
      "indices" : [ 3, 18 ],
      "id_str" : "944237276",
      "id" : 944237276
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "esl",
      "indices" : [ 105, 109 ]
    }, {
      "text" : "elt",
      "indices" : [ 110, 114 ]
    }, {
      "text" : "grammar",
      "indices" : [ 115, 123 ]
    }, {
      "text" : "vocabulary",
      "indices" : [ 124, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/faYD8Jkj",
      "expanded_url" : "http:\/\/ow.ly\/aX1r5",
      "display_url" : "ow.ly\/aX1r5"
    } ]
  },
  "geo" : { },
  "id_str" : "203099409611886593",
  "text" : "rt @brad5patterson: PLS RT: Gramster and Vocabster now online and pay what you want http:\/\/t.co\/faYD8Jkj #esl #elt #grammar #vocabulary",
  "id" : 203099409611886593,
  "created_at" : "2012-05-17 12:27:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zack Hausrath",
      "screen_name" : "Hausrazy",
      "indices" : [ 3, 12 ],
      "id_str" : "244710124",
      "id" : 244710124
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "minecraftedu",
      "indices" : [ 118, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/x2vVMT3R",
      "expanded_url" : "http:\/\/tesolbuilders.blogspot.com\/",
      "display_url" : "tesolbuilders.blogspot.com"
    } ]
  },
  "geo" : { },
  "id_str" : "203098996821073920",
  "text" : "rt @Hausrazy: Short description of Unit 3: Descriptive essay, and Minecraft world screen shots: http:\/\/t.co\/x2vVMT3R. #minecraftedu",
  "id" : 203098996821073920,
  "created_at" : "2012-05-17 12:25:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/zAAYe230",
      "expanded_url" : "http:\/\/boingboing.net\/2012\/05\/15\/ipod-body-mod-magnetic-wrist.html",
      "display_url" : "boingboing.net\/2012\/05\/15\/ipo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "202782887181959168",
  "text" : "intrsting example of use of  verb \"pull off\" http:\/\/t.co\/zAAYe230 :)",
  "id" : 202782887181959168,
  "created_at" : "2012-05-16 15:29:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Graham Stanley",
      "screen_name" : "grahamstanley",
      "indices" : [ 0, 14 ],
      "id_str" : "74143",
      "id" : 74143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202524616525217792",
  "geo" : { },
  "id_str" : "202532658662739968",
  "in_reply_to_user_id" : 74143,
  "text" : "@grahamstanley save money for teachers :) hehe",
  "id" : 202532658662739968,
  "in_reply_to_status_id" : 202524616525217792,
  "created_at" : "2012-05-15 22:55:23 +0000",
  "in_reply_to_screen_name" : "grahamstanley",
  "in_reply_to_user_id_str" : "74143",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josette LeBlanc",
      "screen_name" : "JosetteLB",
      "indices" : [ 0, 10 ],
      "id_str" : "33503694",
      "id" : 33503694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202230705500069888",
  "geo" : { },
  "id_str" : "202257514237149184",
  "in_reply_to_user_id" : 33503694,
  "text" : "@JosetteLB does that mean you get a day off! have a good one anyways :)",
  "id" : 202257514237149184,
  "in_reply_to_status_id" : 202230705500069888,
  "created_at" : "2012-05-15 04:42:03 +0000",
  "in_reply_to_screen_name" : "JosetteLB",
  "in_reply_to_user_id_str" : "33503694",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 3, 17 ],
      "id_str" : "25388528",
      "id" : 25388528
    }, {
      "name" : "Dr. Alec Couros",
      "screen_name" : "courosa",
      "indices" : [ 23, 31 ],
      "id_str" : "739293",
      "id" : 739293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/KN1ifL8p",
      "expanded_url" : "http:\/\/bit.ly\/IT5B1f",
      "display_url" : "bit.ly\/IT5B1f"
    } ]
  },
  "geo" : { },
  "id_str" : "202251877365186561",
  "text" : "MT @audreywatters:  RT @courosa: \" Sabotage - MCA Tribute\" http:\/\/t.co\/KN1ifL8p Sabotage video with kids.&lt;--connect 4 game is a class touch!",
  "id" : 202251877365186561,
  "created_at" : "2012-05-15 04:19:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheLanguagePoint",
      "screen_name" : "Marie_Sanako",
      "indices" : [ 3, 16 ],
      "id_str" : "356176087",
      "id" : 356176087
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 29, 38 ],
      "id_str" : "18602422",
      "id" : 18602422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/utAUjWGZ",
      "expanded_url" : "http:\/\/bit.ly\/H5czi9",
      "display_url" : "bit.ly\/H5czi9"
    } ]
  },
  "geo" : { },
  "id_str" : "202064630162538496",
  "text" : "MT @Marie_Sanako:Congrats to @muranava whose resource on 'Place-hacking' London's Shard is our featured item this week! http:\/\/t.co\/utAUjWGZ",
  "id" : 202064630162538496,
  "created_at" : "2012-05-14 15:55:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheLanguagePoint",
      "screen_name" : "Marie_Sanako",
      "indices" : [ 0, 13 ],
      "id_str" : "356176087",
      "id" : 356176087
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202043618326888450",
  "geo" : { },
  "id_str" : "202044799971364865",
  "in_reply_to_user_id" : 356176087,
  "text" : "@Marie_Sanako okay have replied, thx again!",
  "id" : 202044799971364865,
  "in_reply_to_status_id" : 202043618326888450,
  "created_at" : "2012-05-14 14:36:48 +0000",
  "in_reply_to_screen_name" : "Marie_Sanako",
  "in_reply_to_user_id_str" : "356176087",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheLanguagePoint",
      "screen_name" : "Marie_Sanako",
      "indices" : [ 0, 13 ],
      "id_str" : "356176087",
      "id" : 356176087
    }, {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 14, 25 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202005596633968640",
  "geo" : { },
  "id_str" : "202043793623621633",
  "in_reply_to_user_id" : 356176087,
  "text" : "@Marie_Sanako @kevchanwow hehe, there sure is a need for classroom space  to be hacked to make students want to learn in them!",
  "id" : 202043793623621633,
  "in_reply_to_status_id" : 202005596633968640,
  "created_at" : "2012-05-14 14:32:48 +0000",
  "in_reply_to_screen_name" : "Marie_Sanako",
  "in_reply_to_user_id_str" : "356176087",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheLanguagePoint",
      "screen_name" : "Marie_Sanako",
      "indices" : [ 0, 13 ],
      "id_str" : "356176087",
      "id" : 356176087
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202027780068745220",
  "geo" : { },
  "id_str" : "202040331129208832",
  "in_reply_to_user_id" : 356176087,
  "text" : "@Marie_Sanako ah sweet! i am well chuffed, thanks!",
  "id" : 202040331129208832,
  "in_reply_to_status_id" : 202027780068745220,
  "created_at" : "2012-05-14 14:19:03 +0000",
  "in_reply_to_screen_name" : "Marie_Sanako",
  "in_reply_to_user_id_str" : "356176087",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cdmblogs",
      "screen_name" : "cdmblogs",
      "indices" : [ 54, 63 ],
      "id_str" : "15739035",
      "id" : 15739035
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/yWk4OrFC",
      "expanded_url" : "http:\/\/networkawesome.com\/2012-5-11",
      "display_url" : "networkawesome.com\/2012-5-11"
    } ]
  },
  "geo" : { },
  "id_str" : "201788232034291713",
  "text" : "great Beastie's video archive http:\/\/t.co\/yWk4OrFC HT @cdmblogs",
  "id" : 201788232034291713,
  "created_at" : "2012-05-13 21:37:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "Naomi Epstein",
      "screen_name" : "naomishema",
      "indices" : [ 12, 23 ],
      "id_str" : "228469472",
      "id" : 228469472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "201674176749240320",
  "geo" : { },
  "id_str" : "201770300721999872",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan @naomishema the easy to grasp wildcard options on netspeak are great. if they can apply that to other corpora be doubly great!",
  "id" : 201770300721999872,
  "in_reply_to_status_id" : 201674176749240320,
  "created_at" : "2012-05-13 20:26:03 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "201671031985930241",
  "geo" : { },
  "id_str" : "201769700298989568",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow shucks, your teaching attitude is one i hope to reach some day!",
  "id" : 201769700298989568,
  "in_reply_to_status_id" : 201671031985930241,
  "created_at" : "2012-05-13 20:23:39 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 3, 14 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELTchat",
      "indices" : [ 104, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/zN04dKHG",
      "expanded_url" : "http:\/\/theotherthingsmatter.blogspot.jp\/2012\/05\/its-not-teaching-if-your-not-noticing.html",
      "display_url" : "theotherthingsmatter.blogspot.jp\/2012\/05\/its-no\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "201655367887896576",
  "text" : "MT @kevchanwow: So I decided to have kids read silently for a minute.  One minute. http:\/\/t.co\/zN04dKHG #ELTchat&lt;--another quality post",
  "id" : 201655367887896576,
  "created_at" : "2012-05-13 12:49:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "michaelcraiggradwell",
      "screen_name" : "michaelcraig",
      "indices" : [ 0, 13 ],
      "id_str" : "805969",
      "id" : 805969
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "201651857821679618",
  "geo" : { },
  "id_str" : "201652647365849089",
  "in_reply_to_user_id" : 805969,
  "text" : "@michaelcraig sounds heavy, good luck in the swotting!",
  "id" : 201652647365849089,
  "in_reply_to_status_id" : 201651857821679618,
  "created_at" : "2012-05-13 12:38:32 +0000",
  "in_reply_to_screen_name" : "michaelcraig",
  "in_reply_to_user_id_str" : "805969",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "michaelcraiggradwell",
      "screen_name" : "michaelcraig",
      "indices" : [ 0, 13 ],
      "id_str" : "805969",
      "id" : 805969
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "201648826300383232",
  "geo" : { },
  "id_str" : "201649048363614208",
  "in_reply_to_user_id" : 805969,
  "text" : "@michaelcraig what's the lpma exam?",
  "id" : 201649048363614208,
  "in_reply_to_status_id" : 201648826300383232,
  "created_at" : "2012-05-13 12:24:14 +0000",
  "in_reply_to_screen_name" : "michaelcraig",
  "in_reply_to_user_id_str" : "805969",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 116, 126 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/yMtsGuGs",
      "expanded_url" : "http:\/\/www.wsws.org\/articles\/2012\/may2012\/queb-m11.shtml",
      "display_url" : "wsws.org\/articles\/2012\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "201648913290235904",
  "text" : "Quebec students reject union-promoted sellout of their fight for accessible education http:\/\/t.co\/yMtsGuGs HT Anton @medialens",
  "id" : 201648913290235904,
  "created_at" : "2012-05-13 12:23:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naomi Epstein",
      "screen_name" : "naomishema",
      "indices" : [ 3, 14 ],
      "id_str" : "228469472",
      "id" : 228469472
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 71, 79 ]
    }, {
      "text" : "efl",
      "indices" : [ 80, 84 ]
    }, {
      "text" : "esl",
      "indices" : [ 85, 89 ]
    }, {
      "text" : "edchat",
      "indices" : [ 90, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/Rf4ECvAl",
      "expanded_url" : "http:\/\/leoxicon.blogspot.com\/2012\/05\/lexical-priming.html?spref=tw",
      "display_url" : "leoxicon.blogspot.com\/2012\/05\/lexica\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "201406899114090496",
  "text" : "MT @naomishema: Leoxicon: One word leads to... http:\/\/t.co\/Rf4ECvAl&gt;#eltchat #efl #esl #edchat&lt; good heads up on Netspeak webtool",
  "id" : 201406899114090496,
  "created_at" : "2012-05-12 20:22:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "TheLanguagePoint",
      "screen_name" : "Marie_Sanako",
      "indices" : [ 12, 25 ],
      "id_str" : "356176087",
      "id" : 356176087
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "201011728371290113",
  "geo" : { },
  "id_str" : "201013294042054656",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan @Marie_Sanako for sure! the upload process is very straightforward.",
  "id" : 201013294042054656,
  "in_reply_to_status_id" : 201011728371290113,
  "created_at" : "2012-05-11 18:17:58 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheLanguagePoint",
      "screen_name" : "Marie_Sanako",
      "indices" : [ 84, 97 ],
      "id_str" : "356176087",
      "id" : 356176087
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "languagepoint",
      "indices" : [ 13, 27 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/8VPp7n4F",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-9e",
      "display_url" : "wp.me\/pgHyE-9e"
    } ]
  },
  "geo" : { },
  "id_str" : "201008439273594880",
  "text" : "blog post on #languagepoint website and my recent lesson there http:\/\/t.co\/8VPp7n4F @Marie_Sanako",
  "id" : 201008439273594880,
  "created_at" : "2012-05-11 17:58:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheLanguagePoint",
      "screen_name" : "Marie_Sanako",
      "indices" : [ 0, 13 ],
      "id_str" : "356176087",
      "id" : 356176087
    }, {
      "name" : "Issac A. Greaves",
      "screen_name" : "issacgreaves",
      "indices" : [ 14, 27 ],
      "id_str" : "2807411366",
      "id" : 2807411366
    }, {
      "name" : "phil wade",
      "screen_name" : "phil3wade",
      "indices" : [ 28, 38 ],
      "id_str" : "248864761",
      "id" : 248864761
    }, {
      "name" : "Sylvie",
      "screen_name" : "SylvieBRawlings",
      "indices" : [ 39, 55 ],
      "id_str" : "535482884",
      "id" : 535482884
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200950950217789440",
  "geo" : { },
  "id_str" : "200959105081409536",
  "in_reply_to_user_id" : 356176087,
  "text" : "@Marie_Sanako @IssacGreaves @phil3wade @SylvieBRawlings your very welcome, have a great w\/e",
  "id" : 200959105081409536,
  "in_reply_to_status_id" : 200950950217789440,
  "created_at" : "2012-05-11 14:42:38 +0000",
  "in_reply_to_screen_name" : "Marie_Sanako",
  "in_reply_to_user_id_str" : "356176087",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    }, {
      "name" : "Josette LeBlanc",
      "screen_name" : "JosetteLB",
      "indices" : [ 12, 22 ],
      "id_str" : "33503694",
      "id" : 33503694
    }, {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 23, 39 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FF",
      "indices" : [ 90, 93 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200943388856549378",
  "geo" : { },
  "id_str" : "200958745927368704",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow @JosetteLB @michaelegriffin hey cheers pal, outside of twitter always thought #FF were swear words :\/",
  "id" : 200958745927368704,
  "in_reply_to_status_id" : 200943388856549378,
  "created_at" : "2012-05-11 14:41:13 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 0, 10 ],
      "id_str" : "6531902",
      "id" : 6531902
    }, {
      "name" : "Eddie Brennan",
      "screen_name" : "EddieBrennan",
      "indices" : [ 11, 24 ],
      "id_str" : "22502725",
      "id" : 22502725
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200867012036149248",
  "geo" : { },
  "id_str" : "200876907401711616",
  "in_reply_to_user_id" : 6531902,
  "text" : "@medialens @EddieBrennan i do like the cogitations! keep up the great work!",
  "id" : 200876907401711616,
  "in_reply_to_status_id" : 200867012036149248,
  "created_at" : "2012-05-11 09:16:01 +0000",
  "in_reply_to_screen_name" : "medialens",
  "in_reply_to_user_id_str" : "6531902",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sandy Millin",
      "screen_name" : "sandymillin",
      "indices" : [ 0, 12 ],
      "id_str" : "144236944",
      "id" : 144236944
    }, {
      "name" : "David Peter Koster",
      "screen_name" : "davpetkos",
      "indices" : [ 13, 23 ],
      "id_str" : "528650114",
      "id" : 528650114
    }, {
      "name" : "Matthew Smith",
      "screen_name" : "matsmithj",
      "indices" : [ 24, 34 ],
      "id_str" : "541662071",
      "id" : 541662071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200837374039687168",
  "geo" : { },
  "id_str" : "200875732723965952",
  "in_reply_to_user_id" : 144236944,
  "text" : "@sandymillin @davpetkos @matsmithj welcome to twitter!",
  "id" : 200875732723965952,
  "in_reply_to_status_id" : 200837374039687168,
  "created_at" : "2012-05-11 09:11:21 +0000",
  "in_reply_to_screen_name" : "sandymillin",
  "in_reply_to_user_id_str" : "144236944",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 60, 70 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/r45z90ym",
      "expanded_url" : "http:\/\/www.medialens.org\/index.php?option=com_content&view=article&id=679:the-mystery-of-the-missing-clocks&catid=4:cogitations&Itemid=36",
      "display_url" : "medialens.org\/index.php?opti\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "200682204832071682",
  "text" : "The Mystery Of The Missing Clocks: http:\/\/t.co\/r45z90ym via @medialens&lt;--always great food for thought",
  "id" : 200682204832071682,
  "created_at" : "2012-05-10 20:22:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200246960446382080",
  "geo" : { },
  "id_str" : "200310159422132224",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow thx though the train yr baby seems easier said than done!",
  "id" : 200310159422132224,
  "in_reply_to_status_id" : 200246960446382080,
  "created_at" : "2012-05-09 19:43:58 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200245076553773057",
  "geo" : { },
  "id_str" : "200246540252626944",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow thx, we seem to be coping with his sleep\/feed cycle though it has only been a week and a half so far!",
  "id" : 200246540252626944,
  "in_reply_to_status_id" : 200245076553773057,
  "created_at" : "2012-05-09 15:31:10 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Graham Stanley",
      "screen_name" : "grahamstanley",
      "indices" : [ 3, 17 ],
      "id_str" : "74143",
      "id" : 74143
    }, {
      "name" : "TeachingEnglish",
      "screen_name" : "TeachingEnglish",
      "indices" : [ 85, 101 ],
      "id_str" : "21313816",
      "id" : 21313816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/pPMNQRQ1",
      "expanded_url" : "http:\/\/bit.ly\/LcKHvt",
      "display_url" : "bit.ly\/LcKHvt"
    } ]
  },
  "geo" : { },
  "id_str" : "200241767143047169",
  "text" : "RT @grahamstanley: New for EL Teachers: Writing: mini things http:\/\/t.co\/pPMNQRQ1 by @TeachingEnglish&lt;-grt writing activity",
  "id" : 200241767143047169,
  "created_at" : "2012-05-09 15:12:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 32, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200197598496301056",
  "text" : "thx moderators and all for chat #eltchat",
  "id" : 200197598496301056,
  "created_at" : "2012-05-09 12:16:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "Graham Stanley",
      "screen_name" : "grahamstanley",
      "indices" : [ 22, 36 ],
      "id_str" : "74143",
      "id" : 74143
    }, {
      "name" : "kylemawer",
      "screen_name" : "KyleMawer",
      "indices" : [ 37, 47 ],
      "id_str" : "41313717",
      "id" : 41313717
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 51, 59 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200193371766136833",
  "geo" : { },
  "id_str" : "200194188103524352",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan hint hint @grahamstanley @KyleMawer ;) #eltchat",
  "id" : 200194188103524352,
  "in_reply_to_status_id" : 200193371766136833,
  "created_at" : "2012-05-09 12:03:08 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 75, 83 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200192634826919937",
  "geo" : { },
  "id_str" : "200193007759269890",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan FTW for sure. still have to get a copy of their text book tho! #eltchat",
  "id" : 200193007759269890,
  "in_reply_to_status_id" : 200192634826919937,
  "created_at" : "2012-05-09 11:58:27 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Digital Playspace",
      "screen_name" : "DigitalPlay",
      "indices" : [ 65, 77 ],
      "id_str" : "25614865",
      "id" : 25614865
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 130, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200192412121960449",
  "text" : "when i started to use computer games in class i was glad to have @digitalplay as a ref point if my colleagues asked about utility #eltchat",
  "id" : 200192412121960449,
  "created_at" : "2012-05-09 11:56:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Pereira",
      "screen_name" : "creedpatton",
      "indices" : [ 29, 41 ],
      "id_str" : "23870533",
      "id" : 23870533
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 81, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200189848726929408",
  "text" : "oops sorry twitter handle is @creedpatton who has done AR on Interactive Fiction #eltchat",
  "id" : 200189848726929408,
  "created_at" : "2012-05-09 11:45:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "indices" : [ 3, 16 ],
      "id_str" : "1685397408",
      "id" : 1685397408
    }, {
      "name" : "paul braddock",
      "screen_name" : "bcnpaul1",
      "indices" : [ 18, 27 ],
      "id_str" : "130975050",
      "id" : 130975050
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 133, 141 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200189287571005440",
  "text" : "RT @harrisonmike: @bcnpaul1 Interactive fiction for AR project would be cooooooool&lt;--@creedpaton has done this, good rd, ask him  #eltchat",
  "id" : 200189287571005440,
  "created_at" : "2012-05-09 11:43:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paul braddock",
      "screen_name" : "bcnpaul1",
      "indices" : [ 3, 12 ],
      "id_str" : "130975050",
      "id" : 130975050
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 137, 145 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200182398770626560",
  "text" : "MT @bcnpaul1: gps who go off in lots of diff. directions &amp; then give rsh input to all ts - really useful&lt;--agree dissm rslts key  #eltchat",
  "id" : 200182398770626560,
  "created_at" : "2012-05-09 11:16:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 83, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200179739204399104",
  "text" : "many T's who have multi-employers will find it tricky organising it and all i feel #eltchat",
  "id" : 200179739204399104,
  "created_at" : "2012-05-09 11:05:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200045090520055808",
  "geo" : { },
  "id_str" : "200149271130025984",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt way to be elected! i like the 'member at large' titles, makes it sound like an organized syndicate of teacherly sorts :)",
  "id" : 200149271130025984,
  "in_reply_to_status_id" : 200045090520055808,
  "created_at" : "2012-05-09 09:04:39 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    }, {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 12, 28 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199995266198282240",
  "geo" : { },
  "id_str" : "199997249084854274",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow @michaelegriffin am hoping this handful of joy will go to sleep  in his cot rather than my arm after his next feed!",
  "id" : 199997249084854274,
  "in_reply_to_status_id" : 199995266198282240,
  "created_at" : "2012-05-08 23:00:34 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    }, {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 17, 28 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199994440478228480",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin @kevchanwow thanks for kind words guys, am trying to get used to one handed working, with new born baby in other hand!",
  "id" : 199994440478228480,
  "created_at" : "2012-05-08 22:49:24 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "Scott Thornbury",
      "screen_name" : "thornburyscott",
      "indices" : [ 12, 27 ],
      "id_str" : "23090474",
      "id" : 23090474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199985033862316032",
  "geo" : { },
  "id_str" : "199993463327031297",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan @thornburyscott frequent co-text - \/...derisory laughter...\/...pull the other one...\/...is it April 1st?\/ etc etc :)",
  "id" : 199993463327031297,
  "in_reply_to_status_id" : 199985033862316032,
  "created_at" : "2012-05-08 22:45:32 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199986643707506689",
  "text" : "@kevingiddens ah thanks! :) thought it was not up to snuff! the formatting on posterous is a bit skewed mind!",
  "id" : 199986643707506689,
  "created_at" : "2012-05-08 22:18:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheLanguagePoint",
      "screen_name" : "Marie_Sanako",
      "indices" : [ 75, 88 ],
      "id_str" : "356176087",
      "id" : 356176087
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/Fu2DcQMB",
      "expanded_url" : "http:\/\/bit.ly\/JeaAIZ",
      "display_url" : "bit.ly\/JeaAIZ"
    } ]
  },
  "geo" : { },
  "id_str" : "199982273494392833",
  "text" : "Olympic inoculation 3: London Olympic Shard lesson http:\/\/t.co\/Fu2DcQMB at @Marie_Sanako Language Point",
  "id" : 199982273494392833,
  "created_at" : "2012-05-08 22:01:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "phil wade",
      "screen_name" : "phil3wade",
      "indices" : [ 0, 10 ],
      "id_str" : "248864761",
      "id" : 248864761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/r5WGtMsj",
      "expanded_url" : "http:\/\/www.imdb.com\/title\/tt1899353\/",
      "display_url" : "imdb.com\/title\/tt189935\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "199862920279097344",
  "geo" : { },
  "id_str" : "199911593373478912",
  "in_reply_to_user_id" : 248864761,
  "text" : "@phil3wade looks like The Raid:Redemption (http:\/\/t.co\/r5WGtMsj) is gonna fill my kickbangwhallop needs in the nr future!",
  "id" : 199911593373478912,
  "in_reply_to_status_id" : 199862920279097344,
  "created_at" : "2012-05-08 17:20:12 +0000",
  "in_reply_to_screen_name" : "phil3wade",
  "in_reply_to_user_id_str" : "248864761",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "phil wade",
      "screen_name" : "phil3wade",
      "indices" : [ 0, 10 ],
      "id_str" : "248864761",
      "id" : 248864761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199861101377241088",
  "geo" : { },
  "id_str" : "199862656511909888",
  "in_reply_to_user_id" : 248864761,
  "text" : "@phil3wade the whedon characterisation and dialogue is good but all that crashbangwhallop near end tedious",
  "id" : 199862656511909888,
  "in_reply_to_status_id" : 199861101377241088,
  "created_at" : "2012-05-08 14:05:45 +0000",
  "in_reply_to_screen_name" : "phil3wade",
  "in_reply_to_user_id_str" : "248864761",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199562586642071553",
  "geo" : { },
  "id_str" : "199563041921183744",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt ah right will do, ta",
  "id" : 199563041921183744,
  "in_reply_to_status_id" : 199562586642071553,
  "created_at" : "2012-05-07 18:15:11 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EAPchat",
      "indices" : [ 29, 37 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199558327745781760",
  "geo" : { },
  "id_str" : "199559336203268096",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt sorry to hve missed #EAPchat it look fwd to reading summary",
  "id" : 199559336203268096,
  "in_reply_to_status_id" : 199558327745781760,
  "created_at" : "2012-05-07 18:00:28 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stevemuir",
      "screen_name" : "steve_muir",
      "indices" : [ 0, 11 ],
      "id_str" : "18537988",
      "id" : 18537988
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199494248498864130",
  "geo" : { },
  "id_str" : "199522665843802115",
  "in_reply_to_user_id" : 18537988,
  "text" : "@steve_muir a case of engineering students not a pretty sight :\/",
  "id" : 199522665843802115,
  "in_reply_to_status_id" : 199494248498864130,
  "created_at" : "2012-05-07 15:34:45 +0000",
  "in_reply_to_screen_name" : "steve_muir",
  "in_reply_to_user_id_str" : "18537988",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Teacher Annette",
      "screen_name" : "TeacherAnnette",
      "indices" : [ 0, 15 ],
      "id_str" : "503518609",
      "id" : 503518609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199468694814994434",
  "geo" : { },
  "id_str" : "199521716177870848",
  "in_reply_to_user_id" : 503518609,
  "text" : "@TeacherAnnette thx for Newsing me! :)",
  "id" : 199521716177870848,
  "in_reply_to_status_id" : 199468694814994434,
  "created_at" : "2012-05-07 15:30:58 +0000",
  "in_reply_to_screen_name" : "TeacherAnnette",
  "in_reply_to_user_id_str" : "503518609",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Don Williams",
      "screen_name" : "donaldthesane",
      "indices" : [ 64, 78 ],
      "id_str" : "370274508",
      "id" : 370274508
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 60 ],
      "url" : "https:\/\/t.co\/iyxddpav",
      "expanded_url" : "https:\/\/sites.google.com\/site\/englishdroid2\/",
      "display_url" : "sites.google.com\/site\/englishdr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "199513133402959872",
  "text" : "some hilarious stuff here Englishdroid https:\/\/t.co\/iyxddpav HT @donaldthesane",
  "id" : 199513133402959872,
  "created_at" : "2012-05-07 14:56:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sandy Millin",
      "screen_name" : "sandymillin",
      "indices" : [ 0, 12 ],
      "id_str" : "144236944",
      "id" : 144236944
    }, {
      "name" : "Laura Patsko",
      "screen_name" : "lauraahaha",
      "indices" : [ 13, 24 ],
      "id_str" : "97957137",
      "id" : 97957137
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/MpB0bYuM",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-3r",
      "display_url" : "wp.me\/pgHyE-3r"
    } ]
  },
  "in_reply_to_status_id_str" : "199420726917345280",
  "geo" : { },
  "id_str" : "199458796899274754",
  "in_reply_to_user_id" : 144236944,
  "text" : "@sandymillin @lauraahaha Bref is a great series used it as a translation exercise blogged about here http:\/\/t.co\/MpB0bYuM",
  "id" : 199458796899274754,
  "in_reply_to_status_id" : 199420726917345280,
  "created_at" : "2012-05-07 11:20:57 +0000",
  "in_reply_to_screen_name" : "sandymillin",
  "in_reply_to_user_id_str" : "144236944",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stevemuir",
      "screen_name" : "steve_muir",
      "indices" : [ 0, 11 ],
      "id_str" : "18537988",
      "id" : 18537988
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/Nq4z8nz2",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-8V",
      "display_url" : "wp.me\/pgHyE-8V"
    } ]
  },
  "in_reply_to_status_id_str" : "199393505699827712",
  "geo" : { },
  "id_str" : "199456718529372160",
  "in_reply_to_user_id" : 18537988,
  "text" : "@steve_muir nice one steve! really appreciate RT of Lesson idea for engineering sts http:\/\/t.co\/Nq4z8nz2",
  "id" : 199456718529372160,
  "in_reply_to_status_id" : 199393505699827712,
  "created_at" : "2012-05-07 11:12:42 +0000",
  "in_reply_to_screen_name" : "steve_muir",
  "in_reply_to_user_id_str" : "18537988",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EFLengineers",
      "indices" : [ 65, 78 ]
    }, {
      "text" : "EAPengineers",
      "indices" : [ 79, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/Nq4z8nz2",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-8V",
      "display_url" : "wp.me\/pgHyE-8V"
    } ]
  },
  "geo" : { },
  "id_str" : "199390380515524609",
  "text" : "blog post - Lesson idea for engineering sts http:\/\/t.co\/Nq4z8nz2 #EFLengineers #EAPengineers",
  "id" : 199390380515524609,
  "created_at" : "2012-05-07 06:49:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Don Williams",
      "screen_name" : "donaldthesane",
      "indices" : [ 0, 14 ],
      "id_str" : "370274508",
      "id" : 370274508
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199373892014440448",
  "geo" : { },
  "id_str" : "199375762883756032",
  "in_reply_to_user_id" : 370274508,
  "text" : "@donaldthesane hehe some funny stuff there!",
  "id" : 199375762883756032,
  "in_reply_to_status_id" : 199373892014440448,
  "created_at" : "2012-05-07 05:51:00 +0000",
  "in_reply_to_screen_name" : "donaldthesane",
  "in_reply_to_user_id_str" : "370274508",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Rei",
      "screen_name" : "Charlesrei1",
      "indices" : [ 0, 12 ],
      "id_str" : "464454382",
      "id" : 464454382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199362077536686081",
  "geo" : { },
  "id_str" : "199374360279121920",
  "in_reply_to_user_id" : 464454382,
  "text" : "@Charlesrei1 yr welcome, liked how u applied bloom tax, some great thinking there!",
  "id" : 199374360279121920,
  "in_reply_to_status_id" : 199362077536686081,
  "created_at" : "2012-05-07 05:45:26 +0000",
  "in_reply_to_screen_name" : "Charlesrei1",
  "in_reply_to_user_id_str" : "464454382",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    }, {
      "name" : "Valerie R. Burton",
      "screen_name" : "MsBisOnline",
      "indices" : [ 9, 21 ],
      "id_str" : "53225056",
      "id" : 53225056
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199357113913458690",
  "geo" : { },
  "id_str" : "199373283215413248",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt @msbisonline that's a coincidence, i 'participated' in a google hangout a couple of weeks back with this teacher :)",
  "id" : 199373283215413248,
  "in_reply_to_status_id" : 199357113913458690,
  "created_at" : "2012-05-07 05:41:09 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Rei",
      "screen_name" : "Charlesrei1",
      "indices" : [ 3, 15 ],
      "id_str" : "464454382",
      "id" : 464454382
    }, {
      "name" : "Jim Scrivener",
      "screen_name" : "jimscriv",
      "indices" : [ 56, 65 ],
      "id_str" : "130149739",
      "id" : 130149739
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/s52K8k5c",
      "expanded_url" : "http:\/\/bit.ly\/IPgE01#besig",
      "display_url" : "bit.ly\/IPgE01#besig"
    } ]
  },
  "geo" : { },
  "id_str" : "199267851071270912",
  "text" : "MT @Charlesrei1: blog post inspired by Michelle Hunter, @jimscriv, benjamin bloom http:\/\/t.co\/s52K8k5c&lt;--int thoughts on CPD &amp;  materials",
  "id" : 199267851071270912,
  "created_at" : "2012-05-06 22:42:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sandy Millin",
      "screen_name" : "sandymillin",
      "indices" : [ 3, 15 ],
      "id_str" : "144236944",
      "id" : 144236944
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/kmNwl37s",
      "expanded_url" : "http:\/\/wp.me\/p18yiK-oA",
      "display_url" : "wp.me\/p18yiK-oA"
    } ]
  },
  "geo" : { },
  "id_str" : "199260688160530432",
  "text" : "MT @sandymillin: How to make two simple PowerPoint gamesUseful for vocabulary revision http:\/\/t.co\/kmNwl37s&lt;--nice how to",
  "id" : 199260688160530432,
  "created_at" : "2012-05-06 22:13:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tinashe Blanchet",
      "screen_name" : "mrsblanchetnet",
      "indices" : [ 55, 70 ],
      "id_str" : "1549369201",
      "id" : 1549369201
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/VIh8fpel",
      "expanded_url" : "http:\/\/www.google.com\/insidesearch\/searcheducation\/lessons.html",
      "display_url" : "google.com\/insidesearch\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "199256741068816385",
  "text" : "Google Search literacy lessons http:\/\/t.co\/VIh8fpel HT @mrsblanchetnet",
  "id" : 199256741068816385,
  "created_at" : "2012-05-06 21:58:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/hjF9JHpG",
      "expanded_url" : "http:\/\/www.zcommunications.org\/20-years-later-want-to-understand-the-92-la-riots-start-with-the-84-la-olympics-by-dave-zirin",
      "display_url" : "zcommunications.org\/20-years-later\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "198841375318491136",
  "text" : "London Olympics Inoculation no 2: 20 Years Later: Want to Understand the '92 LA Riots? Start with the '84 LA Olympics\nhttp:\/\/t.co\/hjF9JHpG",
  "id" : 198841375318491136,
  "created_at" : "2012-05-05 18:27:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Seymour",
      "screen_name" : "leninology",
      "indices" : [ 106, 117 ],
      "id_str" : "15557246",
      "id" : 15557246
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/NycEm0Xu",
      "expanded_url" : "http:\/\/www.leninology.com\/2012\/05\/anti-vote.html",
      "display_url" : "leninology.com\/2012\/05\/anti-v\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "198833402613477376",
  "text" : "LiberalDemocideLiberal DefenestrationLiberal DecompositionLiberalDebacle more at http:\/\/t.co\/NycEm0Xu via @leninology",
  "id" : 198833402613477376,
  "created_at" : "2012-05-05 17:55:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/zGbogzKY",
      "expanded_url" : "http:\/\/bbc.in\/KkQnHc",
      "display_url" : "bbc.in\/KkQnHc"
    } ]
  },
  "geo" : { },
  "id_str" : "198749467141345282",
  "text" : "BBC - BBC Internet Blog: BBC Online Briefing Spring 2012: The Participation Choice http:\/\/t.co\/zGbogzKY HT eurotrib",
  "id" : 198749467141345282,
  "created_at" : "2012-05-05 12:22:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 57, 67 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/myVO4BES",
      "expanded_url" : "http:\/\/bevansrun.blogspot.co.uk\/2012\/05\/madness-of-nhs-privatisation.html",
      "display_url" : "bevansrun.blogspot.co.uk\/2012\/05\/madnes\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "198721147762774016",
  "text" : "The madness of NHS privatisation http:\/\/t.co\/myVO4BES HT @medialens",
  "id" : 198721147762774016,
  "created_at" : "2012-05-05 10:29:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 41, 55 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/FWaDKG9A",
      "expanded_url" : "http:\/\/www.beastieboysannotated.com\/",
      "display_url" : "beastieboysannotated.com"
    } ]
  },
  "geo" : { },
  "id_str" : "198487565052022784",
  "text" : "http:\/\/t.co\/FWaDKG9A &lt;--great site HT @audreywatters peace to MCA",
  "id" : 198487565052022784,
  "created_at" : "2012-05-04 19:01:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Register Hardware",
      "screen_name" : "RegHardware",
      "indices" : [ 88, 100 ],
      "id_str" : "19707379",
      "id" : 19707379
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/9iTULrcE",
      "expanded_url" : "http:\/\/reg.cx\/1Wh1",
      "display_url" : "reg.cx\/1Wh1"
    } ]
  },
  "geo" : { },
  "id_str" : "198033433400836096",
  "text" : "Read how THE sellng point of ARM chips came about by accident  http:\/\/t.co\/9iTULrcE via @reghardware",
  "id" : 198033433400836096,
  "created_at" : "2012-05-03 12:57:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Pereira",
      "screen_name" : "creedpatton",
      "indices" : [ 3, 15 ],
      "id_str" : "23870533",
      "id" : 23870533
    }, {
      "name" : "Jon Ingold",
      "screen_name" : "joningold",
      "indices" : [ 20, 30 ],
      "id_str" : "176170634",
      "id" : 176170634
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/qvQilqw6",
      "expanded_url" : "http:\/\/bit.ly\/IJATGK",
      "display_url" : "bit.ly\/IJATGK"
    } ]
  },
  "geo" : { },
  "id_str" : "198006998887956482",
  "text" : "MT @creedpatton: RT @joningold: It is future of IF and has been for a while now. http:\/\/t.co\/qvQilqw6&lt;-s\/w like this tempts me to iDarkness!",
  "id" : 198006998887956482,
  "created_at" : "2012-05-03 11:12:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/axfSGS5O",
      "expanded_url" : "http:\/\/www.eurotrib.com\/story\/2012\/5\/2\/94723\/11008",
      "display_url" : "eurotrib.com\/story\/2012\/5\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "197989261394448385",
  "text" : "The rubble of neo-liberalism http:\/\/t.co\/axfSGS5O via eurotrib",
  "id" : 197989261394448385,
  "created_at" : "2012-05-03 10:01:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/nhVnu4mN",
      "expanded_url" : "http:\/\/bit.ly\/IV3Lw0",
      "display_url" : "bit.ly\/IV3Lw0"
    } ]
  },
  "geo" : { },
  "id_str" : "197803300295426048",
  "text" : "if you are up at about 0300 and int in digi literacies join Howard Rheingold http:\/\/t.co\/nhVnu4mN with Teachers Teaching Teachers",
  "id" : 197803300295426048,
  "created_at" : "2012-05-02 21:42:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Allison",
      "screen_name" : "paulallison",
      "indices" : [ 3, 15 ],
      "id_str" : "3124961",
      "id" : 3124961
    }, {
      "name" : "Fred Mindlin",
      "screen_name" : "fmindlin",
      "indices" : [ 49, 58 ],
      "id_str" : "11105382",
      "id" : 11105382
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 59, 68 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Vinnie Vrotny",
      "screen_name" : "vvrotny",
      "indices" : [ 69, 77 ],
      "id_str" : "5167861",
      "id" : 5167861
    }, {
      "name" : "Simply Mz.Vee",
      "screen_name" : "vrburton",
      "indices" : [ 78, 87 ],
      "id_str" : "478889714",
      "id" : 478889714
    }, {
      "name" : "Sarah Rolle",
      "screen_name" : "artdabbler13",
      "indices" : [ 88, 101 ],
      "id_str" : "10156842",
      "id" : 10156842
    }, {
      "name" : "Tinashe Blanchet",
      "screen_name" : "mrsblanchetnet",
      "indices" : [ 102, 117 ],
      "id_str" : "1549369201",
      "id" : 1549369201
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/9mhnuTFM",
      "expanded_url" : "http:\/\/bit.ly\/IYudb2",
      "display_url" : "bit.ly\/IYudb2"
    } ]
  },
  "geo" : { },
  "id_str" : "197801263172292609",
  "text" : "MT @paulallison: D\/L TTT #294 Discuss NetSmart w\/@fmindlin @muranava @vvrotny @VRBurton @artdabbler13 @mrsblanchetnet  http:\/\/t.co\/9mhnuTFM",
  "id" : 197801263172292609,
  "created_at" : "2012-05-02 21:34:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephanie McIntosh",
      "screen_name" : "purple_steph",
      "indices" : [ 0, 13 ],
      "id_str" : "18678010",
      "id" : 18678010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197714829212004352",
  "geo" : { },
  "id_str" : "197727970952097792",
  "in_reply_to_user_id" : 18678010,
  "text" : "@purple_steph hear hear! another one to add ot twitter netiquette!",
  "id" : 197727970952097792,
  "in_reply_to_status_id" : 197714829212004352,
  "created_at" : "2012-05-02 16:43:16 +0000",
  "in_reply_to_screen_name" : "purple_steph",
  "in_reply_to_user_id_str" : "18678010",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephanie McIntosh",
      "screen_name" : "purple_steph",
      "indices" : [ 0, 13 ],
      "id_str" : "18678010",
      "id" : 18678010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197562025042386944",
  "geo" : { },
  "id_str" : "197677217285816321",
  "in_reply_to_user_id" : 18678010,
  "text" : "@purple_steph true, though, what i find is that a lot of students have already had loads of lessons based on say valentine's day, xmas etc.",
  "id" : 197677217285816321,
  "in_reply_to_status_id" : 197562025042386944,
  "created_at" : "2012-05-02 13:21:35 +0000",
  "in_reply_to_screen_name" : "purple_steph",
  "in_reply_to_user_id_str" : "18678010",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephanie McIntosh",
      "screen_name" : "purple_steph",
      "indices" : [ 0, 13 ],
      "id_str" : "18678010",
      "id" : 18678010
    }, {
      "name" : "JoHart",
      "screen_name" : "JoHart",
      "indices" : [ 14, 21 ],
      "id_str" : "17484662",
      "id" : 17484662
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197671818587414529",
  "geo" : { },
  "id_str" : "197676092641906688",
  "in_reply_to_user_id" : 18678010,
  "text" : "@purple_steph @JoHart Digital Literacy = Technical Literacy + Social Literacy (e.g. see Howard Rheingold)",
  "id" : 197676092641906688,
  "in_reply_to_status_id" : 197671818587414529,
  "created_at" : "2012-05-02 13:17:07 +0000",
  "in_reply_to_screen_name" : "purple_steph",
  "in_reply_to_user_id_str" : "18678010",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephanie McIntosh",
      "screen_name" : "purple_steph",
      "indices" : [ 0, 13 ],
      "id_str" : "18678010",
      "id" : 18678010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "197422805657206786",
  "geo" : { },
  "id_str" : "197434228928028673",
  "in_reply_to_user_id" : 18678010,
  "text" : "@purple_steph always good to ELT-exploit a people's originated holiday as opposed to commercially-originated holidays! :)",
  "id" : 197434228928028673,
  "in_reply_to_status_id" : 197422805657206786,
  "created_at" : "2012-05-01 21:16:02 +0000",
  "in_reply_to_screen_name" : "purple_steph",
  "in_reply_to_user_id_str" : "18678010",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Seymour",
      "screen_name" : "leninology",
      "indices" : [ 98, 109 ],
      "id_str" : "15557246",
      "id" : 15557246
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/XmF1XhlQ",
      "expanded_url" : "http:\/\/gu.com\/p\/378qk\/tw",
      "display_url" : "gu.com\/p\/378qk\/tw"
    } ]
  },
  "geo" : { },
  "id_str" : "197418823496892417",
  "text" : "May Day is not about maypoles: the history of international workers' day http:\/\/t.co\/XmF1XhlQ via @leninology&lt;-possible jigsaw read activity",
  "id" : 197418823496892417,
  "created_at" : "2012-05-01 20:14:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
} ]