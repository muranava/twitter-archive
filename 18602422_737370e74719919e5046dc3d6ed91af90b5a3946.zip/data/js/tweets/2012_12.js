Grailbird.data.tweets_2012_12 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim George",
      "screen_name" : "oyajimbo",
      "indices" : [ 0, 9 ],
      "id_str" : "96103979",
      "id" : 96103979
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "285434141925842944",
  "geo" : { },
  "id_str" : "285434420503138304",
  "in_reply_to_user_id" : 96103979,
  "text" : "@oyajimbo erm try piratebay? ;)",
  "id" : 285434420503138304,
  "in_reply_to_status_id" : 285434141925842944,
  "created_at" : "2012-12-30 17:17:23 +0000",
  "in_reply_to_screen_name" : "oyajimbo",
  "in_reply_to_user_id_str" : "96103979",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim George",
      "screen_name" : "oyajimbo",
      "indices" : [ 0, 9 ],
      "id_str" : "96103979",
      "id" : 96103979
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "285433846663618560",
  "in_reply_to_user_id" : 96103979,
  "text" : "@oyajimbo re Tony Grieg interview, have u seen Howzat!Kery Packer's War it's no bad",
  "id" : 285433846663618560,
  "created_at" : "2012-12-30 17:15:06 +0000",
  "in_reply_to_screen_name" : "oyajimbo",
  "in_reply_to_user_id_str" : "96103979",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John T. Spencer",
      "screen_name" : "JohnTSpencer",
      "indices" : [ 0, 13 ],
      "id_str" : "2285706270",
      "id" : 2285706270
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "285383890602971137",
  "geo" : { },
  "id_str" : "285425156573245442",
  "in_reply_to_user_id" : 18389166,
  "text" : "@johntspencer a strategy that can't be adapted?",
  "id" : 285425156573245442,
  "in_reply_to_status_id" : 285383890602971137,
  "created_at" : "2012-12-30 16:40:34 +0000",
  "in_reply_to_screen_name" : "spencerideas",
  "in_reply_to_user_id_str" : "18389166",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 40, 56 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELTchat",
      "indices" : [ 106, 114 ]
    }, {
      "text" : "KELTchat",
      "indices" : [ 115, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/sb3ueXJm",
      "expanded_url" : "http:\/\/eltrantsreviewsreflections.wordpress.com\/2012\/12\/30\/12-before-the-end-of-12\/rantsreviewsreflections.wordpress.com\/2012\/12\/30\/12-",
      "display_url" : "\u2026rantsreviewsreflections.wordpress.com\/2012\/12\/30\/12-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "285421154070568961",
  "text" : "comments r the lifeblood of blogs&gt;MT @michaelegriffin 12 before the end of 12  http:\/\/t.co\/sb3ueXJm\u2026 \u2026 #ELTchat #KELTchat",
  "id" : 285421154070568961,
  "created_at" : "2012-12-30 16:24:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UCU West Mids Women",
      "screen_name" : "UCU_wm_women",
      "indices" : [ 3, 16 ],
      "id_str" : "413886175",
      "id" : 413886175
    }, {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "indices" : [ 18, 31 ],
      "id_str" : "1685397408",
      "id" : 1685397408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/wCSKkNXF",
      "expanded_url" : "http:\/\/www.change.org\/en-GB\/petitions\/halesowen-college-reinstate-david-muritu-as-a-maths-lecturer-at-the-college?utm_campaign=autopublish&",
      "display_url" : "change.org\/en-GB\/petition\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "285136008754909184",
  "text" : "RT @UCU_wm_women: @harrisonmike Please sign &amp; share, West Mids UCU activist sacked in attack on trades unionism http:\/\/t.co\/wCSKkNXF ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mike Harrison",
        "screen_name" : "harrisonmike",
        "indices" : [ 0, 13 ],
        "id_str" : "1685397408",
        "id" : 1685397408
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 118 ],
        "url" : "http:\/\/t.co\/wCSKkNXF",
        "expanded_url" : "http:\/\/www.change.org\/en-GB\/petitions\/halesowen-college-reinstate-david-muritu-as-a-maths-lecturer-at-the-college?utm_campaign=autopublish&",
        "display_url" : "change.org\/en-GB\/petition\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "285119588449005568",
    "text" : "@harrisonmike Please sign &amp; share, West Mids UCU activist sacked in attack on trades unionism http:\/\/t.co\/wCSKkNXF \u2026 \u2026 \u2026 \u2026 \u2026 \u2026 \u2026",
    "id" : 285119588449005568,
    "created_at" : "2012-12-29 20:26:21 +0000",
    "user" : {
      "name" : "UCU West Mids Women",
      "screen_name" : "UCU_wm_women",
      "protected" : false,
      "id_str" : "413886175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000789418726\/edc9619302658a9174e62d929fe3ffb0_normal.jpeg",
      "id" : 413886175,
      "verified" : false
    }
  },
  "id" : 285136008754909184,
  "created_at" : "2012-12-29 21:31:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "royan lee",
      "screen_name" : "royanlee",
      "indices" : [ 0, 9 ],
      "id_str" : "30651485",
      "id" : 30651485
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "285127853434105856",
  "geo" : { },
  "id_str" : "285131992851427328",
  "in_reply_to_user_id" : 30651485,
  "text" : "@royanlee simply awesome, Kurtis Blow would abide :)",
  "id" : 285131992851427328,
  "in_reply_to_status_id" : 285127853434105856,
  "created_at" : "2012-12-29 21:15:39 +0000",
  "in_reply_to_screen_name" : "royanlee",
  "in_reply_to_user_id_str" : "30651485",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenn Greenwald",
      "screen_name" : "ggreenwald",
      "indices" : [ 3, 14 ],
      "id_str" : "16076032",
      "id" : 16076032
    }, {
      "name" : "Jacob Appelbaum",
      "screen_name" : "ioerror",
      "indices" : [ 51, 59 ],
      "id_str" : "13862172",
      "id" : 13862172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/h0HVyqYj",
      "expanded_url" : "http:\/\/is.gd\/xzOlun",
      "display_url" : "is.gd\/xzOlun"
    } ]
  },
  "geo" : { },
  "id_str" : "285117308245004288",
  "text" : "RT @ggreenwald: The always-smart Jacob Appelbaum - @ioerror - on the evils of the Surveillance State and how to resist it http:\/\/t.co\/h0 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jacob Appelbaum",
        "screen_name" : "ioerror",
        "indices" : [ 35, 43 ],
        "id_str" : "13862172",
        "id" : 13862172
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 126 ],
        "url" : "http:\/\/t.co\/h0HVyqYj",
        "expanded_url" : "http:\/\/is.gd\/xzOlun",
        "display_url" : "is.gd\/xzOlun"
      } ]
    },
    "geo" : { },
    "id_str" : "285104932783276033",
    "text" : "The always-smart Jacob Appelbaum - @ioerror - on the evils of the Surveillance State and how to resist it http:\/\/t.co\/h0HVyqYj",
    "id" : 285104932783276033,
    "created_at" : "2012-12-29 19:28:07 +0000",
    "user" : {
      "name" : "Glenn Greenwald",
      "screen_name" : "ggreenwald",
      "protected" : false,
      "id_str" : "16076032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/659383028771364869\/G9HHnjiI_normal.jpg",
      "id" : 16076032,
      "verified" : true
    }
  },
  "id" : 285117308245004288,
  "created_at" : "2012-12-29 20:17:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/jZGuHN2e",
      "expanded_url" : "http:\/\/www.indymedia.org.uk\/en\/regions\/world\/2012\/12\/505058.html",
      "display_url" : "indymedia.org.uk\/en\/regions\/wor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "285010843979100160",
  "text" : "Yuletide in Parliament Square \u2013 War and Peace http:\/\/t.co\/jZGuHN2e",
  "id" : 285010843979100160,
  "created_at" : "2012-12-29 13:14:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284682664798195713",
  "geo" : { },
  "id_str" : "284981932830359552",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow i usd measrments one time before a test and the tchr invigiltng remarked my sts lkd very relaxed, i gave hr a copy of yr story",
  "id" : 284981932830359552,
  "in_reply_to_status_id" : 284682664798195713,
  "created_at" : "2012-12-29 11:19:22 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/GZbhMOxw",
      "expanded_url" : "http:\/\/repo.openpandora.org\/?page=detail&app=scratch",
      "display_url" : "repo.openpandora.org\/?page=detail&a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "284810656639758337",
  "text" : "very very niche but VERY VERY cool Scratch ported to OpenPandora http:\/\/t.co\/GZbhMOxw",
  "id" : 284810656639758337,
  "created_at" : "2012-12-28 23:58:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John T. Spencer",
      "screen_name" : "JohnTSpencer",
      "indices" : [ 14, 27 ],
      "id_str" : "2285706270",
      "id" : 2285706270
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edtech",
      "indices" : [ 67, 74 ]
    }, {
      "text" : "edchat",
      "indices" : [ 75, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/0U8QkkDm",
      "expanded_url" : "http:\/\/bit.ly\/TnhSCy",
      "display_url" : "bit.ly\/TnhSCy"
    } ]
  },
  "geo" : { },
  "id_str" : "284686373858971650",
  "text" : "well said! MT @johntspencer How About Linux? http:\/\/t.co\/0U8QkkDm  #edtech #edchat why not a system that reflects values we want ?",
  "id" : 284686373858971650,
  "created_at" : "2012-12-28 15:44:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284681392426721280",
  "geo" : { },
  "id_str" : "284682187599642624",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow wierder elt trends have happnd! very very humbled to be mentioned in yr gratitude shoutout, here's to a thankful 2013 :)",
  "id" : 284682187599642624,
  "in_reply_to_status_id" : 284681392426721280,
  "created_at" : "2012-12-28 15:28:17 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 80, 91 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EFL",
      "indices" : [ 116, 120 ]
    }, {
      "text" : "TESOL",
      "indices" : [ 121, 127 ]
    }, {
      "text" : "ELTchat",
      "indices" : [ 128, 136 ]
    }, {
      "text" : "JALT",
      "indices" : [ 137, 142 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/R8TkapH2",
      "expanded_url" : "http:\/\/theotherthingsmatter.blogspot.jp\/2012\/12\/a-new-dream-for-new-year-with-side.html",
      "display_url" : "theotherthingsmatter.blogspot.jp\/2012\/12\/a-new-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "284680887357026304",
  "text" : "setting a new elt trend adapting drinking games all wrapd in a grt story!&gt;MT @kevchanwow  http:\/\/t.co\/R8TkapH2 \u2026 #EFL #TESOL #ELTchat #JALT",
  "id" : 284680887357026304,
  "created_at" : "2012-12-28 15:23:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheLanguagePoint",
      "screen_name" : "Marie_Sanako",
      "indices" : [ 3, 16 ],
      "id_str" : "356176087",
      "id" : 356176087
    }, {
      "name" : "phil wade",
      "screen_name" : "phil3wade",
      "indices" : [ 21, 31 ],
      "id_str" : "248864761",
      "id" : 248864761
    }, {
      "name" : "Vicky Loras",
      "screen_name" : "vickyloras",
      "indices" : [ 114, 125 ],
      "id_str" : "95957241",
      "id" : 95957241
    }, {
      "name" : "Gary Jones",
      "screen_name" : "GaryJones01",
      "indices" : [ 139, 140 ],
      "id_str" : "96137539",
      "id" : 96137539
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 139, 140 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Cadu Souza",
      "screen_name" : "ducaduedu",
      "indices" : [ 139, 140 ],
      "id_str" : "203967089",
      "id" : 203967089
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/03HD8YF1",
      "expanded_url" : "http:\/\/tesolfrance.blogspot.com\/",
      "display_url" : "tesolfrance.blogspot.com"
    } ]
  },
  "geo" : { },
  "id_str" : "284585306739576832",
  "text" : "RT @Marie_Sanako: MT @phil3wade: Check out The LanguagePoint's Top 5 lessons of 2012 http:\/\/t.co\/03HD8YF1 -&gt;by @vickyloras @GaryJones ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "phil wade",
        "screen_name" : "phil3wade",
        "indices" : [ 3, 13 ],
        "id_str" : "248864761",
        "id" : 248864761
      }, {
        "name" : "Vicky Loras",
        "screen_name" : "vickyloras",
        "indices" : [ 96, 107 ],
        "id_str" : "95957241",
        "id" : 95957241
      }, {
        "name" : "Gary Jones",
        "screen_name" : "GaryJones01",
        "indices" : [ 108, 120 ],
        "id_str" : "96137539",
        "id" : 96137539
      }, {
        "name" : "Mura Nava",
        "screen_name" : "muranava",
        "indices" : [ 121, 130 ],
        "id_str" : "18602422",
        "id" : 18602422
      }, {
        "name" : "Cadu Souza",
        "screen_name" : "ducaduedu",
        "indices" : [ 137, 147 ],
        "id_str" : "203967089",
        "id" : 203967089
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 87 ],
        "url" : "http:\/\/t.co\/03HD8YF1",
        "expanded_url" : "http:\/\/tesolfrance.blogspot.com\/",
        "display_url" : "tesolfrance.blogspot.com"
      } ]
    },
    "geo" : { },
    "id_str" : "284409316834934784",
    "text" : "MT @phil3wade: Check out The LanguagePoint's Top 5 lessons of 2012 http:\/\/t.co\/03HD8YF1 -&gt;by @vickyloras @GaryJones01 @muranava &amp; @ducaduedu",
    "id" : 284409316834934784,
    "created_at" : "2012-12-27 21:23:59 +0000",
    "user" : {
      "name" : "TheLanguagePoint",
      "screen_name" : "Marie_Sanako",
      "protected" : false,
      "id_str" : "356176087",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1810381097\/lpcombined_normal.jpg",
      "id" : 356176087,
      "verified" : false
    }
  },
  "id" : 284585306739576832,
  "created_at" : "2012-12-28 09:03:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anonymous",
      "screen_name" : "YourAnonNews",
      "indices" : [ 3, 16 ],
      "id_str" : "279390084",
      "id" : 279390084
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NDAA",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "FISA",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284453995773308929",
  "text" : "RT @YourAnonNews: \u2588\u2588 \u2588 \u2588\u2588\u2588\u2588 everything \u2588\u2588\u2588 \u2588\u2588\u2588\u2588\u2588 is \u2588\u2588\u2588\u2588\u2588 \u2588\u2588\u2588\u2588 \u2588\u2588\u2588\u2588 fine \u2588\u2588\u2588\u2588 \u2588\u2588\u2588 \u2588 \u2588\u2588\u2588\u2588\u2588\u2588 love. \u2588\u2588\u2588\u2588\u2588 \u2588\u2588\u2588\u2588\u2588\u2588\u2588 \u2588\u2588\u2588 your \u2588\u2588\u2588\u2588\u2588 \u2588\u2588\u2588\u2588 gover ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.GroupTweet.com\" rel=\"nofollow\"\u003EGroupTweet\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NDAA",
        "indices" : [ 124, 129 ]
      }, {
        "text" : "FISA",
        "indices" : [ 130, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "284438040041115648",
    "text" : "\u2588\u2588 \u2588 \u2588\u2588\u2588\u2588 everything \u2588\u2588\u2588 \u2588\u2588\u2588\u2588\u2588 is \u2588\u2588\u2588\u2588\u2588 \u2588\u2588\u2588\u2588 \u2588\u2588\u2588\u2588 fine \u2588\u2588\u2588\u2588 \u2588\u2588\u2588 \u2588 \u2588\u2588\u2588\u2588\u2588\u2588 love. \u2588\u2588\u2588\u2588\u2588 \u2588\u2588\u2588\u2588\u2588\u2588\u2588 \u2588\u2588\u2588 your \u2588\u2588\u2588\u2588\u2588 \u2588\u2588\u2588\u2588 government #NDAA #FISA",
    "id" : 284438040041115648,
    "created_at" : "2012-12-27 23:18:08 +0000",
    "user" : {
      "name" : "Anonymous",
      "screen_name" : "YourAnonNews",
      "protected" : false,
      "id_str" : "279390084",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/715985177395261441\/ad0f_tAp_normal.jpg",
      "id" : 279390084,
      "verified" : false
    }
  },
  "id" : 284453995773308929,
  "created_at" : "2012-12-28 00:21:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheLanguagePoint",
      "screen_name" : "Marie_Sanako",
      "indices" : [ 0, 13 ],
      "id_str" : "356176087",
      "id" : 356176087
    }, {
      "name" : "phil wade",
      "screen_name" : "phil3wade",
      "indices" : [ 14, 24 ],
      "id_str" : "248864761",
      "id" : 248864761
    }, {
      "name" : "Vicky Loras",
      "screen_name" : "vickyloras",
      "indices" : [ 25, 36 ],
      "id_str" : "95957241",
      "id" : 95957241
    }, {
      "name" : "Gary Jones",
      "screen_name" : "GaryJones01",
      "indices" : [ 37, 49 ],
      "id_str" : "96137539",
      "id" : 96137539
    }, {
      "name" : "Cadu Souza",
      "screen_name" : "ducaduedu",
      "indices" : [ 50, 60 ],
      "id_str" : "203967089",
      "id" : 203967089
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284409316834934784",
  "geo" : { },
  "id_str" : "284442816267042817",
  "in_reply_to_user_id" : 356176087,
  "text" : "@Marie_Sanako @phil3wade @vickyloras @GaryJones01 @ducaduedu wow thanks marie! gonna check out that list!",
  "id" : 284442816267042817,
  "in_reply_to_status_id" : 284409316834934784,
  "created_at" : "2012-12-27 23:37:06 +0000",
  "in_reply_to_screen_name" : "Marie_Sanako",
  "in_reply_to_user_id_str" : "356176087",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.slices.me\" rel=\"nofollow\"\u003ESlices for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/AiLVUINf",
      "expanded_url" : "http:\/\/ondemand.tv3.co.nz\/Media-3-Season-1-Ep-16\/tabid\/59\/articleID\/8890\/MCat\/540\/Default.aspx",
      "display_url" : "ondemand.tv3.co.nz\/Media-3-Season\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "284340781970518016",
  "text" : "i remember tweeting the video the actual story is just as fascinating http:\/\/t.co\/AiLVUINf",
  "id" : 284340781970518016,
  "created_at" : "2012-12-27 16:51:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 32 ],
      "url" : "http:\/\/t.co\/v9SnAbkh",
      "expanded_url" : "http:\/\/crayonslookbetterthantheytaste.blogspot.fr\/2012\/12\/the-receipt.html",
      "display_url" : "\u2026nslookbetterthantheytaste.blogspot.fr\/2012\/12\/the-re\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "284086428344926209",
  "text" : "The Receipt http:\/\/t.co\/v9SnAbkh",
  "id" : 284086428344926209,
  "created_at" : "2012-12-27 00:00:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EL Gazette",
      "screen_name" : "ELGazette",
      "indices" : [ 0, 10 ],
      "id_str" : "614186998",
      "id" : 614186998
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "283988545142661120",
  "geo" : { },
  "id_str" : "283995834666844162",
  "in_reply_to_user_id" : 614186998,
  "text" : "@ELGazette yeah or \"X ways to use Y tech in yr class!\" :0",
  "id" : 283995834666844162,
  "in_reply_to_status_id" : 283988545142661120,
  "created_at" : "2012-12-26 18:00:58 +0000",
  "in_reply_to_screen_name" : "ELGazette",
  "in_reply_to_user_id_str" : "614186998",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.slices.me\" rel=\"nofollow\"\u003ESlices for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "edulang",
      "screen_name" : "edulang",
      "indices" : [ 3, 11 ],
      "id_str" : "2877002950",
      "id" : 2877002950
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tesol",
      "indices" : [ 93, 99 ]
    }, {
      "text" : "france",
      "indices" : [ 100, 107 ]
    }, {
      "text" : "elt",
      "indices" : [ 108, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/A6gL1Bn2",
      "expanded_url" : "http:\/\/ow.ly\/gm6Iw",
      "display_url" : "ow.ly\/gm6Iw"
    } ]
  },
  "geo" : { },
  "id_str" : "283960788589350913",
  "text" : "RT @Edulang: Julie\u2019s story: ELT Freelancing in France for over 30 years http:\/\/t.co\/A6gL1Bn2 #tesol #france #elt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tesol",
        "indices" : [ 80, 86 ]
      }, {
        "text" : "france",
        "indices" : [ 87, 94 ]
      }, {
        "text" : "elt",
        "indices" : [ 95, 99 ]
      } ],
      "urls" : [ {
        "indices" : [ 59, 79 ],
        "url" : "http:\/\/t.co\/A6gL1Bn2",
        "expanded_url" : "http:\/\/ow.ly\/gm6Iw",
        "display_url" : "ow.ly\/gm6Iw"
      } ]
    },
    "geo" : { },
    "id_str" : "283950421737881600",
    "text" : "Julie\u2019s story: ELT Freelancing in France for over 30 years http:\/\/t.co\/A6gL1Bn2 #tesol #france #elt",
    "id" : 283950421737881600,
    "created_at" : "2012-12-26 15:00:30 +0000",
    "user" : {
      "name" : "WordTov",
      "screen_name" : "wordtov",
      "protected" : false,
      "id_str" : "236921161",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/612985595749617664\/YMxtQC1g_normal.png",
      "id" : 236921161,
      "verified" : false
    }
  },
  "id" : 283960788589350913,
  "created_at" : "2012-12-26 15:41:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Gurr",
      "screen_name" : "tonygurr",
      "indices" : [ 0, 9 ],
      "id_str" : "257930941",
      "id" : 257930941
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "283477711727517696",
  "geo" : { },
  "id_str" : "283479573054750720",
  "in_reply_to_user_id" : 257930941,
  "text" : "@tonygurr colour coded black socks genius idea!",
  "id" : 283479573054750720,
  "in_reply_to_status_id" : 283477711727517696,
  "created_at" : "2012-12-25 07:49:31 +0000",
  "in_reply_to_screen_name" : "tonygurr",
  "in_reply_to_user_id_str" : "257930941",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Stults",
      "screen_name" : "JustinStults",
      "indices" : [ 0, 13 ],
      "id_str" : "294217312",
      "id" : 294217312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/zp0GcoIj",
      "expanded_url" : "http:\/\/youtu.be\/w-llZmPPNwU",
      "display_url" : "youtu.be\/w-llZmPPNwU"
    } ]
  },
  "in_reply_to_status_id_str" : "283159057886482432",
  "geo" : { },
  "id_str" : "283160779035906048",
  "in_reply_to_user_id" : 294217312,
  "text" : "@JustinStults sweet, next step do it for real like this chap http:\/\/t.co\/zp0GcoIj :) maybe on a velib instead of horse?",
  "id" : 283160779035906048,
  "in_reply_to_status_id" : 283159057886482432,
  "created_at" : "2012-12-24 10:42:45 +0000",
  "in_reply_to_screen_name" : "JustinStults",
  "in_reply_to_user_id_str" : "294217312",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/JAsQuBfe",
      "expanded_url" : "http:\/\/www.zcommunications.org\/on-moving-backwards-not-forwards-agee-manning-and-zero-dark-thirty-by-joe-emersberger",
      "display_url" : "zcommunications.org\/on-moving-back\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "283123313671286785",
  "text" : "On Moving Backwards not Forwards - Agee, Manning and Zero Dark Thirty\nhttp:\/\/t.co\/JAsQuBfe",
  "id" : 283123313671286785,
  "created_at" : "2012-12-24 08:13:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 43, 58 ],
      "id_str" : "20760283",
      "id" : 20760283
    }, {
      "name" : "Paul Snookes",
      "screen_name" : "paulsnookes",
      "indices" : [ 104, 116 ],
      "id_str" : "14842823",
      "id" : 14842823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "282957071308189696",
  "text" : "grt to hear the voice of god in person aka @MrChrisJWilson in a google hangout and to link with EAP bod @paulsnookes, happyxmas!",
  "id" : 282957071308189696,
  "created_at" : "2012-12-23 21:13:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/wgkBfqa6",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-2H",
      "display_url" : "wp.me\/pgHyE-2H"
    } ]
  },
  "geo" : { },
  "id_str" : "282162931607674881",
  "text" : "a small update to \"Online whiteboard to enhance reading activity\" post http:\/\/t.co\/wgkBfqa6 - screencast of sts working on Google doc",
  "id" : 282162931607674881,
  "created_at" : "2012-12-21 16:37:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "royan lee",
      "screen_name" : "royanlee",
      "indices" : [ 133, 142 ],
      "id_str" : "30651485",
      "id" : 30651485
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/dhfNLvB3",
      "expanded_url" : "http:\/\/spicylearning.wordpress.com\/2012\/12\/19\/bringing-back-my-calluses\/",
      "display_url" : "spicylearning.wordpress.com\/2012\/12\/19\/bri\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "281885386416992257",
  "text" : "great post&gt;\"We\u2019re always ... talking about BYOD this and 1:1 that. ...think outside the glowing screen...\"http:\/\/t.co\/dhfNLvB3 by @royanlee",
  "id" : 281885386416992257,
  "created_at" : "2012-12-20 22:14:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/yUxxsDBr",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-cQ",
      "display_url" : "wp.me\/pgHyE-cQ"
    } ]
  },
  "geo" : { },
  "id_str" : "281806282955038720",
  "text" : "thx to @Karris72 for liking Quick cup of coca - synonym post http:\/\/t.co\/yUxxsDBr",
  "id" : 281806282955038720,
  "created_at" : "2012-12-20 17:00:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Scrivener",
      "screen_name" : "jimscriv",
      "indices" : [ 0, 9 ],
      "id_str" : "130149739",
      "id" : 130149739
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281780365633392641",
  "geo" : { },
  "id_str" : "281805114145120258",
  "in_reply_to_user_id" : 130149739,
  "text" : "@jimscriv Oh no it isn't! &gt;&gt;&gt;",
  "id" : 281805114145120258,
  "in_reply_to_status_id" : 281780365633392641,
  "created_at" : "2012-12-20 16:55:49 +0000",
  "in_reply_to_screen_name" : "jimscriv",
  "in_reply_to_user_id_str" : "130149739",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Alexander",
      "screen_name" : "BryanAlexander",
      "indices" : [ 3, 18 ],
      "id_str" : "755991",
      "id" : 755991
    }, {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 72, 78 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/nr6KqZW4",
      "expanded_url" : "http:\/\/bit.ly\/UTh8TW",
      "display_url" : "bit.ly\/UTh8TW"
    } ]
  },
  "geo" : { },
  "id_str" : "281759714981838848",
  "text" : "RT @BryanAlexander Taking Nate Silver to task: http:\/\/t.co\/nr6KqZW4 cc  @EBEFL re yr last post on expert authority",
  "id" : 281759714981838848,
  "created_at" : "2012-12-20 13:55:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/HiDmX1Fi",
      "expanded_url" : "http:\/\/www.facebook.com\/photo.php?v=10151337852540149",
      "display_url" : "facebook.com\/photo.php?v=10\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "281754702172004352",
  "text" : "another ex of limitations and creativity Landfill harmonic http:\/\/t.co\/HiDmX1Fi",
  "id" : 281754702172004352,
  "created_at" : "2012-12-20 13:35:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281749362642661376",
  "geo" : { },
  "id_str" : "281749940542255104",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow heard you had moved recently hope all went smoothly.",
  "id" : 281749940542255104,
  "in_reply_to_status_id" : 281749362642661376,
  "created_at" : "2012-12-20 13:16:35 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    }, {
      "name" : "Luiz Otavio Barros",
      "screen_name" : "luizotavioELT",
      "indices" : [ 64, 78 ],
      "id_str" : "54798894",
      "id" : 54798894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281735568147230720",
  "geo" : { },
  "id_str" : "281744385123708928",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow there was mention of demand high (serious) blogs by @luizotavioELT yet demand high silly blgs needed as well - yrs is a grt mix!",
  "id" : 281744385123708928,
  "in_reply_to_status_id" : 281735568147230720,
  "created_at" : "2012-12-20 12:54:30 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chiew Pang",
      "screen_name" : "aClilToClimb",
      "indices" : [ 0, 13 ],
      "id_str" : "76160458",
      "id" : 76160458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281706378291191808",
  "geo" : { },
  "id_str" : "281733130883325953",
  "in_reply_to_user_id" : 76160458,
  "text" : "@aClilToClimb those review stats would be one way to validate the overall stats they do release",
  "id" : 281733130883325953,
  "in_reply_to_status_id" : 281706378291191808,
  "created_at" : "2012-12-20 12:09:47 +0000",
  "in_reply_to_screen_name" : "aClilToClimb",
  "in_reply_to_user_id_str" : "76160458",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ds106",
      "indices" : [ 23, 29 ]
    }, {
      "text" : "GIFfest",
      "indices" : [ 30, 38 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 62, 70 ]
    }, {
      "text" : "edchat",
      "indices" : [ 71, 78 ]
    }, {
      "text" : "efl",
      "indices" : [ 79, 83 ]
    }, {
      "text" : "tefl",
      "indices" : [ 84, 89 ]
    }, {
      "text" : "elt",
      "indices" : [ 90, 94 ]
    }, {
      "text" : "gifsrgreat",
      "indices" : [ 95, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/yW8h1U9l",
      "expanded_url" : "http:\/\/assignments.ds106.us\/assignments\/giffed-language-teaching-or-learning\/",
      "display_url" : "assignments.ds106.us\/assignments\/gi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "281732611137761280",
  "text" : "ELT peeps have a go at #ds106 #GIFfest http:\/\/t.co\/yW8h1U9l \u2026 #eltchat #edchat #efl #tefl #elt #gifsrgreat",
  "id" : 281732611137761280,
  "created_at" : "2012-12-20 12:07:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281686977747759104",
  "geo" : { },
  "id_str" : "281706277283966976",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson it's a great post, the US teachers seem to be able to move things forward amazingly!",
  "id" : 281706277283966976,
  "in_reply_to_status_id" : 281686977747759104,
  "created_at" : "2012-12-20 10:23:05 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chiew Pang",
      "screen_name" : "aClilToClimb",
      "indices" : [ 0, 13 ],
      "id_str" : "76160458",
      "id" : 76160458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281702644110725121",
  "geo" : { },
  "id_str" : "281705023191269377",
  "in_reply_to_user_id" : 76160458,
  "text" : "@aClilToClimb or the very very bad teachers in ethiopia?! are there stats on the reviews they do after people have taken the course?",
  "id" : 281705023191269377,
  "in_reply_to_status_id" : 281702644110725121,
  "created_at" : "2012-12-20 10:18:06 +0000",
  "in_reply_to_screen_name" : "aClilToClimb",
  "in_reply_to_user_id_str" : "76160458",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chiew Pang",
      "screen_name" : "aClilToClimb",
      "indices" : [ 0, 13 ],
      "id_str" : "76160458",
      "id" : 76160458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281689356048142337",
  "geo" : { },
  "id_str" : "281701944219803649",
  "in_reply_to_user_id" : 76160458,
  "text" : "@aClilToClimb those celta stats are interesting, in what sense should they be taken with a pinch of slat?",
  "id" : 281701944219803649,
  "in_reply_to_status_id" : 281689356048142337,
  "created_at" : "2012-12-20 10:05:51 +0000",
  "in_reply_to_screen_name" : "aClilToClimb",
  "in_reply_to_user_id_str" : "76160458",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chadsansing",
      "screen_name" : "chadsansing",
      "indices" : [ 110, 122 ],
      "id_str" : "76810409",
      "id" : 76810409
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 24, 32 ]
    }, {
      "text" : "gamification",
      "indices" : [ 33, 46 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/aGH5U2NM",
      "expanded_url" : "http:\/\/digitalis.nwp.org\/resource\/4274",
      "display_url" : "digitalis.nwp.org\/resource\/4274"
    } ]
  },
  "geo" : { },
  "id_str" : "281547299820294144",
  "text" : "better late than never! #eltchat #gamification\nStudent-made badges as self-assessment\nhttp:\/\/t.co\/aGH5U2NM by @chadsansing",
  "id" : 281547299820294144,
  "created_at" : "2012-12-19 23:51:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chadsansing",
      "screen_name" : "chadsansing",
      "indices" : [ 0, 12 ],
      "id_str" : "76810409",
      "id" : 76810409
    }, {
      "name" : "NWP Digital Is",
      "screen_name" : "NWPDigital_Is",
      "indices" : [ 13, 27 ],
      "id_str" : "393621343",
      "id" : 393621343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281522893840592896",
  "geo" : { },
  "id_str" : "281546897909497858",
  "in_reply_to_user_id" : 76810409,
  "text" : "@chadsansing @NWPDigital_Is okay many thx!",
  "id" : 281546897909497858,
  "in_reply_to_status_id" : 281522893840592896,
  "created_at" : "2012-12-19 23:49:46 +0000",
  "in_reply_to_screen_name" : "chadsansing",
  "in_reply_to_user_id_str" : "76810409",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chadsansing",
      "screen_name" : "chadsansing",
      "indices" : [ 0, 12 ],
      "id_str" : "76810409",
      "id" : 76810409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281517859472031746",
  "geo" : { },
  "id_str" : "281520188669718529",
  "in_reply_to_user_id" : 76810409,
  "text" : "@chadsansing r u still blogging on yr older blog? was lookign fr article u did on badges?",
  "id" : 281520188669718529,
  "in_reply_to_status_id" : 281517859472031746,
  "created_at" : "2012-12-19 22:03:38 +0000",
  "in_reply_to_screen_name" : "chadsansing",
  "in_reply_to_user_id_str" : "76810409",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 17, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281519214622281728",
  "text" : "thx all and mods #eltchat",
  "id" : 281519214622281728,
  "created_at" : "2012-12-19 21:59:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281518096613785600",
  "text" : "i c often parallel btw hollywood trying to attract youth with game remakes and gamefication in ELT #eltchat",
  "id" : 281518096613785600,
  "created_at" : "2012-12-19 21:55:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chadsansing",
      "screen_name" : "chadsansing",
      "indices" : [ 67, 79 ],
      "id_str" : "76810409",
      "id" : 76810409
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 95, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/8IdDCmIx",
      "expanded_url" : "http:\/\/democratizingcomposition.wordpress.com\/",
      "display_url" : "democratizingcomposition.wordpress.com"
    } ]
  },
  "geo" : { },
  "id_str" : "281516484126187520",
  "text" : "taking it beyond gamefication for YLs  see http:\/\/t.co\/8IdDCmIx by @chadsansing amongst othrs  #eltchat",
  "id" : 281516484126187520,
  "created_at" : "2012-12-19 21:48:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wiktorkompe",
      "screen_name" : "wiktor_k",
      "indices" : [ 0, 9 ],
      "id_str" : "733704413383168000",
      "id" : 733704413383168000
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 83, 91 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281510067390537728",
  "geo" : { },
  "id_str" : "281510802521989121",
  "in_reply_to_user_id" : 222498082,
  "text" : "@Wiktor_K true, though playing games is diff from using game elements in class no? #eltchat",
  "id" : 281510802521989121,
  "in_reply_to_status_id" : 281510067390537728,
  "created_at" : "2012-12-19 21:26:20 +0000",
  "in_reply_to_screen_name" : "BRAVE_Learning",
  "in_reply_to_user_id_str" : "222498082",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 65, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281509570487140353",
  "text" : "hi all, any qualms about the behaviourist basis of gamefication? #eltchat",
  "id" : 281509570487140353,
  "created_at" : "2012-12-19 21:21:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luiz Otavio Barros",
      "screen_name" : "luizotavioELT",
      "indices" : [ 0, 14 ],
      "id_str" : "54798894",
      "id" : 54798894
    }, {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 15, 26 ],
      "id_str" : "282659955",
      "id" : 282659955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281495426614558720",
  "geo" : { },
  "id_str" : "281497857146617860",
  "in_reply_to_user_id" : 54798894,
  "text" : "@luizotavioELT @teflerinha demand high blogs? :)",
  "id" : 281497857146617860,
  "in_reply_to_status_id" : 281495426614558720,
  "created_at" : "2012-12-19 20:34:53 +0000",
  "in_reply_to_screen_name" : "luizotavioELT",
  "in_reply_to_user_id_str" : "54798894",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luiz Otavio Barros",
      "screen_name" : "luizotavioELT",
      "indices" : [ 0, 14 ],
      "id_str" : "54798894",
      "id" : 54798894
    }, {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 15, 26 ],
      "id_str" : "282659955",
      "id" : 282659955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281493451558760448",
  "geo" : { },
  "id_str" : "281494556644622336",
  "in_reply_to_user_id" : 54798894,
  "text" : "@luizotavioELT @teflerinha only a bit tired? ;)",
  "id" : 281494556644622336,
  "in_reply_to_status_id" : 281493451558760448,
  "created_at" : "2012-12-19 20:21:46 +0000",
  "in_reply_to_screen_name" : "luizotavioELT",
  "in_reply_to_user_id_str" : "54798894",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tbxmoose",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/6h0VkmtR",
      "expanded_url" : "http:\/\/bit.ly\/tbxmoose",
      "display_url" : "bit.ly\/tbxmoose"
    } ]
  },
  "geo" : { },
  "id_str" : "281475552974606338",
  "text" : "i am only here because they could not get the rat #tbxmoose http:\/\/t.co\/6h0VkmtR",
  "id" : 281475552974606338,
  "created_at" : "2012-12-19 19:06:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Levine",
      "screen_name" : "cogdog",
      "indices" : [ 3, 10 ],
      "id_str" : "740343",
      "id" : 740343
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ds106",
      "indices" : [ 28, 34 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/WWtekhJL",
      "expanded_url" : "http:\/\/wp.me\/pf0PM-4Du",
      "display_url" : "wp.me\/pf0PM-4Du"
    } ]
  },
  "geo" : { },
  "id_str" : "281473278797828097",
  "text" : "RT @cogdog: CogDogBlogged:  #ds106 GIFfest http:\/\/t.co\/WWtekhJL Let the GIFfestivities begin (or continue)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sopresto.mailchimp.com\" rel=\"nofollow\"\u003ESocial Proxy by Mailchimp\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ds106",
        "indices" : [ 16, 22 ]
      } ],
      "urls" : [ {
        "indices" : [ 31, 51 ],
        "url" : "http:\/\/t.co\/WWtekhJL",
        "expanded_url" : "http:\/\/wp.me\/pf0PM-4Du",
        "display_url" : "wp.me\/pf0PM-4Du"
      } ]
    },
    "geo" : { },
    "id_str" : "281467488611495936",
    "text" : "CogDogBlogged:  #ds106 GIFfest http:\/\/t.co\/WWtekhJL Let the GIFfestivities begin (or continue)",
    "id" : 281467488611495936,
    "created_at" : "2012-12-19 18:34:13 +0000",
    "user" : {
      "name" : "Alan Levine",
      "screen_name" : "cogdog",
      "protected" : false,
      "id_str" : "740343",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/740063389527859201\/BN9buLB9_normal.jpg",
      "id" : 740343,
      "verified" : false
    }
  },
  "id" : 281473278797828097,
  "created_at" : "2012-12-19 18:57:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chiew Pang",
      "screen_name" : "aClilToClimb",
      "indices" : [ 0, 13 ],
      "id_str" : "76160458",
      "id" : 76160458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281465831777529856",
  "in_reply_to_user_id" : 76160458,
  "text" : "@aClilToClimb did u see  Gary Anderson - Which comes first ... language development or exam preparation? missed it will wait for recording",
  "id" : 281465831777529856,
  "created_at" : "2012-12-19 18:27:38 +0000",
  "in_reply_to_screen_name" : "aClilToClimb",
  "in_reply_to_user_id_str" : "76160458",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Baio",
      "screen_name" : "waxpancake",
      "indices" : [ 3, 14 ],
      "id_str" : "13461",
      "id" : 13461
    }, {
      "name" : "Playfic",
      "screen_name" : "playfic",
      "indices" : [ 103, 111 ],
      "id_str" : "164426667",
      "id" : 164426667
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/W403IS6d",
      "expanded_url" : "http:\/\/www.wired.com\/gamelife\/2012\/12\/zork-infocom-pioneer-award\/",
      "display_url" : "wired.com\/gamelife\/2012\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "281460613971075072",
  "text" : "RT @waxpancake: Wired published an interview with the creators of Zork\u2026 as a text adventure powered by @playfic! http:\/\/t.co\/W403IS6d",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Playfic",
        "screen_name" : "playfic",
        "indices" : [ 87, 95 ],
        "id_str" : "164426667",
        "id" : 164426667
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 117 ],
        "url" : "http:\/\/t.co\/W403IS6d",
        "expanded_url" : "http:\/\/www.wired.com\/gamelife\/2012\/12\/zork-infocom-pioneer-award\/",
        "display_url" : "wired.com\/gamelife\/2012\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "281433902671876097",
    "text" : "Wired published an interview with the creators of Zork\u2026 as a text adventure powered by @playfic! http:\/\/t.co\/W403IS6d",
    "id" : 281433902671876097,
    "created_at" : "2012-12-19 16:20:45 +0000",
    "user" : {
      "name" : "Andy Baio",
      "screen_name" : "waxpancake",
      "protected" : false,
      "id_str" : "13461",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/590385501179289602\/qvTvxmCX_normal.png",
      "id" : 13461,
      "verified" : true
    }
  },
  "id" : 281460613971075072,
  "created_at" : "2012-12-19 18:06:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 81, 89 ]
    }, {
      "text" : "edchat",
      "indices" : [ 90, 97 ]
    }, {
      "text" : "efl",
      "indices" : [ 98, 102 ]
    }, {
      "text" : "cupofcoca",
      "indices" : [ 103, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/yUxxsDBr",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-cQ",
      "display_url" : "wp.me\/pgHyE-cQ"
    } ]
  },
  "geo" : { },
  "id_str" : "281346987947851776",
  "text" : "can u guess the phrasal verb in my latest Cup of COCA post? http:\/\/t.co\/yUxxsDBr #eltchat #edchat #efl #cupofcoca",
  "id" : 281346987947851776,
  "created_at" : "2012-12-19 10:35:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George Chilton",
      "screen_name" : "designerlessons",
      "indices" : [ 0, 16 ],
      "id_str" : "432090149",
      "id" : 432090149
    }, {
      "name" : "phil wade",
      "screen_name" : "phil3wade",
      "indices" : [ 17, 27 ],
      "id_str" : "248864761",
      "id" : 248864761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281306984328871936",
  "geo" : { },
  "id_str" : "281330171640950784",
  "in_reply_to_user_id" : 432090149,
  "text" : "@designerlessons @phil3wade indeed not enough hyperbole to describe his funkiness mighty george clinton :)",
  "id" : 281330171640950784,
  "in_reply_to_status_id" : 281306984328871936,
  "created_at" : "2012-12-19 09:28:34 +0000",
  "in_reply_to_screen_name" : "designerlessons",
  "in_reply_to_user_id_str" : "432090149",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/1hvVMFLu",
      "expanded_url" : "http:\/\/eltsquared.co.uk\/minimalism-in-the-classroom\/",
      "display_url" : "eltsquared.co.uk\/minimalism-in-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "281320363101667328",
  "geo" : { },
  "id_str" : "281323045128372225",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson personally really enjoyed your series on minimilism http:\/\/t.co\/1hvVMFLu &gt;PLN do check it out if u have not done so",
  "id" : 281323045128372225,
  "in_reply_to_status_id" : 281320363101667328,
  "created_at" : "2012-12-19 09:00:15 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 3, 18 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 126, 134 ]
    }, {
      "text" : "esl",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "esol",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "tefl",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/mawcfzsY",
      "expanded_url" : "http:\/\/elt2.co.uk\/U7YclO",
      "display_url" : "elt2.co.uk\/U7YclO"
    } ]
  },
  "geo" : { },
  "id_str" : "281322793600184321",
  "text" : "RT @MrChrisJWilson: Just posted the best of EltSquared from the year. I'd love to know to your favourite http:\/\/t.co\/mawcfzsY #eltchat # ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "eltchat",
        "indices" : [ 106, 114 ]
      }, {
        "text" : "esl",
        "indices" : [ 115, 119 ]
      }, {
        "text" : "esol",
        "indices" : [ 120, 125 ]
      }, {
        "text" : "tefl",
        "indices" : [ 126, 131 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 105 ],
        "url" : "http:\/\/t.co\/mawcfzsY",
        "expanded_url" : "http:\/\/elt2.co.uk\/U7YclO",
        "display_url" : "elt2.co.uk\/U7YclO"
      } ]
    },
    "geo" : { },
    "id_str" : "281320363101667328",
    "text" : "Just posted the best of EltSquared from the year. I'd love to know to your favourite http:\/\/t.co\/mawcfzsY #eltchat #esl #esol #tefl",
    "id" : 281320363101667328,
    "created_at" : "2012-12-19 08:49:35 +0000",
    "user" : {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "protected" : false,
      "id_str" : "20760283",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744952885595758592\/H4bmsUn3_normal.jpg",
      "id" : 20760283,
      "verified" : false
    }
  },
  "id" : 281322793600184321,
  "created_at" : "2012-12-19 08:59:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "phil wade",
      "screen_name" : "phil3wade",
      "indices" : [ 0, 10 ],
      "id_str" : "248864761",
      "id" : 248864761
    }, {
      "name" : "George Chilton",
      "screen_name" : "designerlessons",
      "indices" : [ 11, 27 ],
      "id_str" : "432090149",
      "id" : 432090149
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/HUlR6vca",
      "expanded_url" : "http:\/\/www.zero-g.co.uk\/media\/images\/GeorgeClintonLarge.jpg",
      "display_url" : "zero-g.co.uk\/media\/images\/G\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "281270378939154432",
  "geo" : { },
  "id_str" : "281272392037310464",
  "in_reply_to_user_id" : 248864761,
  "text" : "@phil3wade @designerlessons http:\/\/t.co\/HUlR6vca",
  "id" : 281272392037310464,
  "in_reply_to_status_id" : 281270378939154432,
  "created_at" : "2012-12-19 05:38:58 +0000",
  "in_reply_to_screen_name" : "phil3wade",
  "in_reply_to_user_id_str" : "248864761",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "phil wade",
      "screen_name" : "phil3wade",
      "indices" : [ 0, 10 ],
      "id_str" : "248864761",
      "id" : 248864761
    }, {
      "name" : "George Chilton",
      "screen_name" : "designerlessons",
      "indices" : [ 11, 27 ],
      "id_str" : "432090149",
      "id" : 432090149
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281262641748537345",
  "geo" : { },
  "id_str" : "281270192598831104",
  "in_reply_to_user_id" : 248864761,
  "text" : "@phil3wade @designerlessons that's pretty FUNKADELIC man ;0",
  "id" : 281270192598831104,
  "in_reply_to_status_id" : 281262641748537345,
  "created_at" : "2012-12-19 05:30:14 +0000",
  "in_reply_to_screen_name" : "phil3wade",
  "in_reply_to_user_id_str" : "248864761",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Sample",
      "screen_name" : "samplereality",
      "indices" : [ 0, 14 ],
      "id_str" : "8497292",
      "id" : 8497292
    }, {
      "name" : "Siva Vaidhyanathan",
      "screen_name" : "sivavaid",
      "indices" : [ 15, 24 ],
      "id_str" : "20406724",
      "id" : 20406724
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "maybetooearlyforjokes",
      "indices" : [ 109, 131 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281154783140798464",
  "geo" : { },
  "id_str" : "281160026855460864",
  "in_reply_to_user_id" : 8497292,
  "text" : "@samplereality @sivavaid hmm imagine going into yr next salary\/perf\/clssrm review with a sidearm some appeal #maybetooearlyforjokes",
  "id" : 281160026855460864,
  "in_reply_to_status_id" : 281154783140798464,
  "created_at" : "2012-12-18 22:12:28 +0000",
  "in_reply_to_screen_name" : "samplereality",
  "in_reply_to_user_id_str" : "8497292",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 65, 73 ]
    }, {
      "text" : "efl",
      "indices" : [ 74, 78 ]
    }, {
      "text" : "edchat",
      "indices" : [ 79, 86 ]
    }, {
      "text" : "cupofcoca",
      "indices" : [ 87, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/yUxxsDBr",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-cQ",
      "display_url" : "wp.me\/pgHyE-cQ"
    } ]
  },
  "geo" : { },
  "id_str" : "281141840084877313",
  "text" : "Quick cup of COCA - synonym brackets equals http:\/\/t.co\/yUxxsDBr #eltchat #efl #edchat #cupofcoca &gt;with a puzzle for any readers",
  "id" : 281141840084877313,
  "created_at" : "2012-12-18 21:00:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 3, 18 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 35, 39 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 132, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 131 ],
      "url" : "https:\/\/t.co\/kdDUDk6s",
      "expanded_url" : "https:\/\/plus.google.com\/events\/cocpatmtgp8uleiv7t3ht4d4beg?authkey=CJX3i8rfks32iAE",
      "display_url" : "plus.google.com\/events\/cocpatm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "281128344572022784",
  "text" : "RT @MrChrisJWilson: I'm hosting an #elt google+ party (or hangout as they're know ) on Sunday 8pm GMT join in https:\/\/t.co\/kdDUDk6s #eltchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.metrotwit.com\/\" rel=\"nofollow\"\u003EMetroTwit\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "elt",
        "indices" : [ 15, 19 ]
      }, {
        "text" : "eltchat",
        "indices" : [ 112, 120 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 111 ],
        "url" : "https:\/\/t.co\/kdDUDk6s",
        "expanded_url" : "https:\/\/plus.google.com\/events\/cocpatmtgp8uleiv7t3ht4d4beg?authkey=CJX3i8rfks32iAE",
        "display_url" : "plus.google.com\/events\/cocpatm\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "280660359956815873",
    "text" : "I'm hosting an #elt google+ party (or hangout as they're know ) on Sunday 8pm GMT join in https:\/\/t.co\/kdDUDk6s #eltchat",
    "id" : 280660359956815873,
    "created_at" : "2012-12-17 13:06:58 +0000",
    "user" : {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "protected" : false,
      "id_str" : "20760283",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744952885595758592\/H4bmsUn3_normal.jpg",
      "id" : 20760283,
      "verified" : false
    }
  },
  "id" : 281128344572022784,
  "created_at" : "2012-12-18 20:06:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281021288619859968",
  "geo" : { },
  "id_str" : "281034765111525376",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson i too blame linux ... for raising the game :)",
  "id" : 281034765111525376,
  "in_reply_to_status_id" : 281021288619859968,
  "created_at" : "2012-12-18 13:54:44 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281031929132875777",
  "geo" : { },
  "id_str" : "281033092112715776",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson either\/or DARPA\/Berners Lee &gt;tax-payer money, reslient network means open network no?",
  "id" : 281033092112715776,
  "in_reply_to_status_id" : 281031929132875777,
  "created_at" : "2012-12-18 13:48:05 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281021230520356864",
  "geo" : { },
  "id_str" : "281029098778816512",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson dont forget  the internet was founded on openess before being handed on a plate to business :\/",
  "id" : 281029098778816512,
  "in_reply_to_status_id" : 281021230520356864,
  "created_at" : "2012-12-18 13:32:13 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 72, 80 ]
    }, {
      "text" : "efl",
      "indices" : [ 81, 85 ]
    }, {
      "text" : "elt",
      "indices" : [ 86, 90 ]
    }, {
      "text" : "edchat",
      "indices" : [ 91, 98 ]
    }, {
      "text" : "cupofcoca",
      "indices" : [ 99, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/jQiPQD7Z",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-cc",
      "display_url" : "wp.me\/pgHyE-cc"
    } ]
  },
  "geo" : { },
  "id_str" : "280997694321852416",
  "text" : "new blog post Quick cup of COCA - wildcard asterix http:\/\/t.co\/jQiPQD7Z #eltchat #efl #elt #edchat #cupofcoca",
  "id" : 280997694321852416,
  "created_at" : "2012-12-18 11:27:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    }, {
      "name" : "TeachingEnglish",
      "screen_name" : "TeachingEnglish",
      "indices" : [ 48, 64 ],
      "id_str" : "21313816",
      "id" : 21313816
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "British",
      "indices" : [ 65, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/Oplar8Dp",
      "expanded_url" : "http:\/\/bit.ly\/V0G2Pj",
      "display_url" : "bit.ly\/V0G2Pj"
    } ]
  },
  "in_reply_to_status_id_str" : "280980653217050624",
  "geo" : { },
  "id_str" : "280983736391200768",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson see this promotion of edmodo by @TeachingEnglish #British Council http:\/\/t.co\/Oplar8Dp",
  "id" : 280983736391200768,
  "in_reply_to_status_id" : 280980653217050624,
  "created_at" : "2012-12-18 10:31:57 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280976994802483200",
  "geo" : { },
  "id_str" : "280979830453985280",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson the 'news' about edmodo reg users as well as instagram got me wondering about teachers, more so than gen population",
  "id" : 280979830453985280,
  "in_reply_to_status_id" : 280976994802483200,
  "created_at" : "2012-12-18 10:16:26 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280972541428891648",
  "geo" : { },
  "id_str" : "280975194607194112",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson been thinking recently how much teachers care or not about openness of software systems?",
  "id" : 280975194607194112,
  "in_reply_to_status_id" : 280972541428891648,
  "created_at" : "2012-12-18 09:58:01 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jo",
      "screen_name" : "IndoorsType",
      "indices" : [ 0, 12 ],
      "id_str" : "269260520",
      "id" : 269260520
    }, {
      "name" : "Sophia Khan",
      "screen_name" : "SophiaKhan4",
      "indices" : [ 13, 25 ],
      "id_str" : "351390617",
      "id" : 351390617
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280785191843291137",
  "geo" : { },
  "id_str" : "280971378700730368",
  "in_reply_to_user_id" : 269260520,
  "text" : "@IndoorsType @SophiaKhan4 re-reading air conditioned nightmare by henry miller, not made me late for work but has made me neglect twitter :)",
  "id" : 280971378700730368,
  "in_reply_to_status_id" : 280785191843291137,
  "created_at" : "2012-12-18 09:42:51 +0000",
  "in_reply_to_screen_name" : "IndoorsType",
  "in_reply_to_user_id_str" : "269260520",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/s9ytCkRp",
      "expanded_url" : "http:\/\/bits.blogs.nytimes.com\/2012\/12\/17\/what-instagrams-new-terms-of-service-mean-for-you\/",
      "display_url" : "bits.blogs.nytimes.com\/2012\/12\/17\/wha\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "280970155520049154",
  "text" : "What Instagram\u2019s New Terms of Service Mean for You http:\/\/t.co\/s9ytCkRp",
  "id" : 280970155520049154,
  "created_at" : "2012-12-18 09:37:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "280944994259447808",
  "text" : "still stumped why some schools opt for closed platforms like edmodo?",
  "id" : 280944994259447808,
  "created_at" : "2012-12-18 07:58:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John T. Spencer",
      "screen_name" : "JohnTSpencer",
      "indices" : [ 3, 16 ],
      "id_str" : "2285706270",
      "id" : 2285706270
    }, {
      "name" : "royan lee",
      "screen_name" : "royanlee",
      "indices" : [ 86, 95 ],
      "id_str" : "30651485",
      "id" : 30651485
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/095X5g9w",
      "expanded_url" : "http:\/\/ow.ly\/gba13",
      "display_url" : "ow.ly\/gba13"
    } ]
  },
  "geo" : { },
  "id_str" : "280942912345350144",
  "text" : "RT @johntspencer: Interesting read: Why I Left Instagram \u00AB The Spicy Learning Blog by @royanlee http:\/\/t.co\/095X5g9w",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "royan lee",
        "screen_name" : "royanlee",
        "indices" : [ 68, 77 ],
        "id_str" : "30651485",
        "id" : 30651485
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 98 ],
        "url" : "http:\/\/t.co\/095X5g9w",
        "expanded_url" : "http:\/\/ow.ly\/gba13",
        "display_url" : "ow.ly\/gba13"
      } ]
    },
    "geo" : { },
    "id_str" : "280872135747051521",
    "text" : "Interesting read: Why I Left Instagram \u00AB The Spicy Learning Blog by @royanlee http:\/\/t.co\/095X5g9w",
    "id" : 280872135747051521,
    "created_at" : "2012-12-18 03:08:30 +0000",
    "user" : {
      "name" : "John Spencer",
      "screen_name" : "spencerideas",
      "protected" : false,
      "id_str" : "18389166",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751913559160795136\/eU7NtYy4_normal.jpg",
      "id" : 18389166,
      "verified" : false
    }
  },
  "id" : 280942912345350144,
  "created_at" : "2012-12-18 07:49:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valentina Morgana",
      "screen_name" : "vmorgana",
      "indices" : [ 0, 9 ],
      "id_str" : "62479177",
      "id" : 62479177
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280695739477270528",
  "geo" : { },
  "id_str" : "280744868014333952",
  "in_reply_to_user_id" : 62479177,
  "text" : "@vmorgana that's great to hear!",
  "id" : 280744868014333952,
  "in_reply_to_status_id" : 280695739477270528,
  "created_at" : "2012-12-17 18:42:47 +0000",
  "in_reply_to_screen_name" : "vmorgana",
  "in_reply_to_user_id_str" : "62479177",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valentina Morgana",
      "screen_name" : "vmorgana",
      "indices" : [ 0, 9 ],
      "id_str" : "62479177",
      "id" : 62479177
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280695321489715200",
  "geo" : { },
  "id_str" : "280744766633828352",
  "in_reply_to_user_id" : 62479177,
  "text" : "@vmorgana i liked in particular the tools you linked to and lk fwd to reading that reference on visuals and lang learning",
  "id" : 280744766633828352,
  "in_reply_to_status_id" : 280695321489715200,
  "created_at" : "2012-12-17 18:42:23 +0000",
  "in_reply_to_screen_name" : "vmorgana",
  "in_reply_to_user_id_str" : "62479177",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    }, {
      "name" : "Julie Moore",
      "screen_name" : "lexicojules",
      "indices" : [ 9, 21 ],
      "id_str" : "424320799",
      "id" : 424320799
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 69, 77 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280743822802157569",
  "geo" : { },
  "id_str" : "280744444695822337",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt @lexicojules what about piggybacking onto ning EULEAP have? #eapchat",
  "id" : 280744444695822337,
  "in_reply_to_status_id" : 280743822802157569,
  "created_at" : "2012-12-17 18:41:06 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valentina Morgana",
      "screen_name" : "vmorgana",
      "indices" : [ 3, 12 ],
      "id_str" : "62479177",
      "id" : 62479177
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELT",
      "indices" : [ 113, 117 ]
    }, {
      "text" : "ELTChat",
      "indices" : [ 118, 126 ]
    }, {
      "text" : "YLEng",
      "indices" : [ 127, 133 ]
    }, {
      "text" : "YL",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "YLsig",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "edtech",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/1b4IWmSX",
      "expanded_url" : "http:\/\/wp.me\/p1WVfI-4k",
      "display_url" : "wp.me\/p1WVfI-4k"
    } ]
  },
  "geo" : { },
  "id_str" : "280688757538172928",
  "text" : "RT @vmorgana: Just blogged: Reading The Lion, the Witch and the Wardrobe: a visual approach http:\/\/t.co\/1b4IWmSX #ELT #ELTChat #YLEng #Y ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELT",
        "indices" : [ 99, 103 ]
      }, {
        "text" : "ELTChat",
        "indices" : [ 104, 112 ]
      }, {
        "text" : "YLEng",
        "indices" : [ 113, 119 ]
      }, {
        "text" : "YL",
        "indices" : [ 120, 123 ]
      }, {
        "text" : "YLsig",
        "indices" : [ 124, 130 ]
      }, {
        "text" : "edtech",
        "indices" : [ 131, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 98 ],
        "url" : "http:\/\/t.co\/1b4IWmSX",
        "expanded_url" : "http:\/\/wp.me\/p1WVfI-4k",
        "display_url" : "wp.me\/p1WVfI-4k"
      } ]
    },
    "geo" : { },
    "id_str" : "280655704459730944",
    "text" : "Just blogged: Reading The Lion, the Witch and the Wardrobe: a visual approach http:\/\/t.co\/1b4IWmSX #ELT #ELTChat #YLEng #YL #YLsig #edtech",
    "id" : 280655704459730944,
    "created_at" : "2012-12-17 12:48:28 +0000",
    "user" : {
      "name" : "Valentina Morgana",
      "screen_name" : "vmorgana",
      "protected" : false,
      "id_str" : "62479177",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000642806271\/d0017663cf2148182377c7facaff6a59_normal.jpeg",
      "id" : 62479177,
      "verified" : false
    }
  },
  "id" : 280688757538172928,
  "created_at" : "2012-12-17 14:59:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Pinker",
      "screen_name" : "sapinker",
      "indices" : [ 0, 9 ],
      "id_str" : "107225267",
      "id" : 107225267
    }, {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 10, 16 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280345802184990720",
  "geo" : { },
  "id_str" : "280442391989735425",
  "in_reply_to_user_id" : 107225267,
  "text" : "@sapinker @EBEFL the comment near bottom by Trofim is a great comment to this 'article'",
  "id" : 280442391989735425,
  "in_reply_to_status_id" : 280345802184990720,
  "created_at" : "2012-12-16 22:40:51 +0000",
  "in_reply_to_screen_name" : "sapinker",
  "in_reply_to_user_id_str" : "107225267",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280422925922877440",
  "geo" : { },
  "id_str" : "280423307902320640",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson making soup without a blender!? hardcore cooking fella!",
  "id" : 280423307902320640,
  "in_reply_to_status_id" : 280422925922877440,
  "created_at" : "2012-12-16 21:25:01 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280422005449322497",
  "geo" : { },
  "id_str" : "280422621106020352",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson first half is good didn't think much of the second! david the android and the ship were the most interesting characters!",
  "id" : 280422621106020352,
  "in_reply_to_status_id" : 280422005449322497,
  "created_at" : "2012-12-16 21:22:17 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/NwlToBDE",
      "expanded_url" : "http:\/\/www.spiegel.de\/international\/world\/pain-continues-after-war-for-american-drone-pilot-a-872726.html",
      "display_url" : "spiegel.de\/international\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "280418534440456192",
  "text" : "eye opening article&gt; The Woes of an American Drone Operator http:\/\/t.co\/NwlToBDE",
  "id" : 280418534440456192,
  "created_at" : "2012-12-16 21:06:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280416458704560128",
  "geo" : { },
  "id_str" : "280418236175114241",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson true dat! though it was just a fun little post :)",
  "id" : 280418236175114241,
  "in_reply_to_status_id" : 280416458704560128,
  "created_at" : "2012-12-16 21:04:52 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chia Suan Chong",
      "screen_name" : "chiasuan",
      "indices" : [ 0, 9 ],
      "id_str" : "71588589",
      "id" : 71588589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "280413498092187648",
  "in_reply_to_user_id" : 71588589,
  "text" : "@chiasuan thx for retweet of androids love direct method post, hope u enjoyed it and thx for inspiration!",
  "id" : 280413498092187648,
  "created_at" : "2012-12-16 20:46:02 +0000",
  "in_reply_to_screen_name" : "chiasuan",
  "in_reply_to_user_id_str" : "71588589",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "phil wade",
      "screen_name" : "phil3wade",
      "indices" : [ 0, 10 ],
      "id_str" : "248864761",
      "id" : 248864761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280259195868176384",
  "geo" : { },
  "id_str" : "280260577992011777",
  "in_reply_to_user_id" : 248864761,
  "text" : "@phil3wade quite a disturbed article though no surprise coming from a bloomberg publication i suppose",
  "id" : 280260577992011777,
  "in_reply_to_status_id" : 280259195868176384,
  "created_at" : "2012-12-16 10:38:23 +0000",
  "in_reply_to_screen_name" : "phil3wade",
  "in_reply_to_user_id_str" : "248864761",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http:\/\/t.co\/5jep4yKS",
      "expanded_url" : "http:\/\/bit.ly\/TU0rXh",
      "display_url" : "bit.ly\/TU0rXh"
    } ]
  },
  "geo" : { },
  "id_str" : "280059917254160384",
  "text" : "The trouble with TED talks http:\/\/t.co\/5jep4yKS",
  "id" : 280059917254160384,
  "created_at" : "2012-12-15 21:21:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 0, 13 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280053164709924865",
  "geo" : { },
  "id_str" : "280054438570385408",
  "in_reply_to_user_id" : 88655243,
  "text" : "@rosemerebard welcome to u too :)",
  "id" : 280054438570385408,
  "in_reply_to_status_id" : 280053164709924865,
  "created_at" : "2012-12-15 20:59:15 +0000",
  "in_reply_to_screen_name" : "rosemerebard",
  "in_reply_to_user_id_str" : "88655243",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valentina Morgana",
      "screen_name" : "vmorgana",
      "indices" : [ 0, 9 ],
      "id_str" : "62479177",
      "id" : 62479177
    }, {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 10, 21 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "Luiz Otavio Barros",
      "screen_name" : "luizotavioELT",
      "indices" : [ 22, 36 ],
      "id_str" : "54798894",
      "id" : 54798894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/X0rwAqCa",
      "expanded_url" : "http:\/\/bit.ly\/XrBYK1",
      "display_url" : "bit.ly\/XrBYK1"
    } ]
  },
  "in_reply_to_status_id_str" : "280020089263247361",
  "geo" : { },
  "id_str" : "280044436556230656",
  "in_reply_to_user_id" : 62479177,
  "text" : "@vmorgana @leoselivan @luizotavioELT seems like possible useful collection of ELT scans? http:\/\/t.co\/X0rwAqCa",
  "id" : 280044436556230656,
  "in_reply_to_status_id" : 280020089263247361,
  "created_at" : "2012-12-15 20:19:31 +0000",
  "in_reply_to_screen_name" : "vmorgana",
  "in_reply_to_user_id_str" : "62479177",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rechat",
      "indices" : [ 70, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279956180372168706",
  "text" : "can we say project based learning is a series of task based learning? #rechat",
  "id" : 279956180372168706,
  "created_at" : "2012-12-15 14:28:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chia Suan Chong",
      "screen_name" : "chiasuan",
      "indices" : [ 84, 93 ],
      "id_str" : "71588589",
      "id" : 71588589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/fwp1vbaW",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-bo",
      "display_url" : "wp.me\/pgHyE-bo"
    } ]
  },
  "geo" : { },
  "id_str" : "279757639490080768",
  "text" : "new blog post Why androids in space love the direct method http:\/\/t.co\/fwp1vbaW  cc @chiasuan",
  "id" : 279757639490080768,
  "created_at" : "2012-12-15 01:19:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 0, 11 ],
      "id_str" : "282659955",
      "id" : 282659955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279712154859487232",
  "geo" : { },
  "id_str" : "279712679713701888",
  "in_reply_to_user_id" : 282659955,
  "text" : "@teflerinha guess for US peeps would be the teflboard 100? :)",
  "id" : 279712679713701888,
  "in_reply_to_status_id" : 279712154859487232,
  "created_at" : "2012-12-14 22:21:14 +0000",
  "in_reply_to_screen_name" : "teflerinha",
  "in_reply_to_user_id_str" : "282659955",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John T. Spencer",
      "screen_name" : "JohnTSpencer",
      "indices" : [ 0, 13 ],
      "id_str" : "2285706270",
      "id" : 2285706270
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/ljEhDrci",
      "expanded_url" : "http:\/\/bit.ly\/UMUcDH",
      "display_url" : "bit.ly\/UMUcDH"
    } ]
  },
  "in_reply_to_status_id_str" : "279705941191057408",
  "geo" : { },
  "id_str" : "279706889594478592",
  "in_reply_to_user_id" : 18389166,
  "text" : "@johntspencer psychiatrist here on how media makes it worse http:\/\/t.co\/ljEhDrci",
  "id" : 279706889594478592,
  "in_reply_to_status_id" : 279705941191057408,
  "created_at" : "2012-12-14 21:58:13 +0000",
  "in_reply_to_screen_name" : "spencerideas",
  "in_reply_to_user_id_str" : "18389166",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 0, 11 ],
      "id_str" : "282659955",
      "id" : 282659955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279652979689263104",
  "geo" : { },
  "id_str" : "279663694978359297",
  "in_reply_to_user_id" : 282659955,
  "text" : "@teflerinha top of the tefl pops! nice :)",
  "id" : 279663694978359297,
  "in_reply_to_status_id" : 279652979689263104,
  "created_at" : "2012-12-14 19:06:35 +0000",
  "in_reply_to_screen_name" : "teflerinha",
  "in_reply_to_user_id_str" : "282659955",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279612635702493184",
  "in_reply_to_user_id" : 61521432,
  "text" : "@ICAL_TEFL thx for comments on corpus post, have a gd w\/e",
  "id" : 279612635702493184,
  "created_at" : "2012-12-14 15:43:41 +0000",
  "in_reply_to_screen_name" : "ICALTEFL",
  "in_reply_to_user_id_str" : "61521432",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valentina Morgana",
      "screen_name" : "vmorgana",
      "indices" : [ 0, 9 ],
      "id_str" : "62479177",
      "id" : 62479177
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FF",
      "indices" : [ 65, 68 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279608637360578560",
  "geo" : { },
  "id_str" : "279611508370075648",
  "in_reply_to_user_id" : 62479177,
  "text" : "@vmorgana thx valentina! enjoy yr writings\/tweets a lot, bon w\/e #FF",
  "id" : 279611508370075648,
  "in_reply_to_status_id" : 279608637360578560,
  "created_at" : "2012-12-14 15:39:13 +0000",
  "in_reply_to_screen_name" : "vmorgana",
  "in_reply_to_user_id_str" : "62479177",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279572484880232448",
  "geo" : { },
  "id_str" : "279610318710255617",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson oh noes dont feel too special now! :(",
  "id" : 279610318710255617,
  "in_reply_to_status_id" : 279572484880232448,
  "created_at" : "2012-12-14 15:34:29 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279525585502486529",
  "geo" : { },
  "id_str" : "279610188682629120",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan many thx for RT leo, have a great w\/e!",
  "id" : 279610188682629120,
  "in_reply_to_status_id" : 279525585502486529,
  "created_at" : "2012-12-14 15:33:58 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boing Boing",
      "screen_name" : "BoingBoing",
      "indices" : [ 43, 54 ],
      "id_str" : "5971922",
      "id" : 5971922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 39 ],
      "url" : "http:\/\/t.co\/PGP3dv2b",
      "expanded_url" : "http:\/\/bit.ly\/RHYEca",
      "display_url" : "bit.ly\/RHYEca"
    } ]
  },
  "geo" : { },
  "id_str" : "279495113732935680",
  "text" : "Literacy Privilege http:\/\/t.co\/PGP3dv2b HT @boingboing",
  "id" : 279495113732935680,
  "created_at" : "2012-12-14 07:56:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/s4WupVOt",
      "expanded_url" : "http:\/\/yhoo.it\/UX7xO2",
      "display_url" : "yhoo.it\/UX7xO2"
    } ]
  },
  "geo" : { },
  "id_str" : "279485879834267648",
  "text" : "Teachers 'Giving Food Handouts To Poor Pupils' http:\/\/t.co\/s4WupVOt",
  "id" : 279485879834267648,
  "created_at" : "2012-12-14 07:20:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John T. Spencer",
      "screen_name" : "JohnTSpencer",
      "indices" : [ 95, 108 ],
      "id_str" : "2285706270",
      "id" : 2285706270
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/DZXxjdfo",
      "expanded_url" : "http:\/\/carlanderson.blogspot.ca\/2012\/12\/sal-khan-teacher-or-opportunist-ties12.html",
      "display_url" : "carlanderson.blogspot.ca\/2012\/12\/sal-kh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "279353966679166976",
  "text" : "&gt; fixed :) &gt;The education community needs to quit [...] Apple, Google or Microsoft [...] @johntspencer http:\/\/t.co\/DZXxjdfo",
  "id" : 279353966679166976,
  "created_at" : "2012-12-13 22:35:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vicky Loras",
      "screen_name" : "vickyloras",
      "indices" : [ 0, 11 ],
      "id_str" : "95957241",
      "id" : 95957241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279294904356700160",
  "geo" : { },
  "id_str" : "279326487893659648",
  "in_reply_to_user_id" : 95957241,
  "text" : "@vickyloras don't mention the mention :)",
  "id" : 279326487893659648,
  "in_reply_to_status_id" : 279294904356700160,
  "created_at" : "2012-12-13 20:46:39 +0000",
  "in_reply_to_screen_name" : "vickyloras",
  "in_reply_to_user_id_str" : "95957241",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279293069474545664",
  "geo" : { },
  "id_str" : "279326298738946049",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson whayhay a a double RT, an RT spare? many thanks!",
  "id" : 279326298738946049,
  "in_reply_to_status_id" : 279293069474545664,
  "created_at" : "2012-12-13 20:45:53 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George Siemens",
      "screen_name" : "gsiemens",
      "indices" : [ 14, 23 ],
      "id_str" : "18613",
      "id" : 18613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/Xu6URJx5",
      "expanded_url" : "http:\/\/www.youtube.com\/user\/PublicisGroupe\/2013wishes",
      "display_url" : "youtube.com\/user\/PublicisG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "279254839530237952",
  "text" : "v funny &gt;RT@gsiemens v. clever use of youtube - try pausing, fast forwarding, or viewing full screen: http:\/\/t.co\/Xu6URJx5 \u2026 rather meta.",
  "id" : 279254839530237952,
  "created_at" : "2012-12-13 16:01:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anna Loseva",
      "screen_name" : "AnnLoseva",
      "indices" : [ 0, 10 ],
      "id_str" : "38822368",
      "id" : 38822368
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279216530397462528",
  "geo" : { },
  "id_str" : "279234475341271040",
  "in_reply_to_user_id" : 38822368,
  "text" : "@AnnLoseva one year in blog land is like 5 years in non blog land :)",
  "id" : 279234475341271040,
  "in_reply_to_status_id" : 279216530397462528,
  "created_at" : "2012-12-13 14:41:01 +0000",
  "in_reply_to_screen_name" : "AnnLoseva",
  "in_reply_to_user_id_str" : "38822368",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 3, 14 ],
      "id_str" : "144663117",
      "id" : 144663117
    }, {
      "name" : "Josette LeBlanc",
      "screen_name" : "JosetteLB",
      "indices" : [ 16, 26 ],
      "id_str" : "33503694",
      "id" : 33503694
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "amazing",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/Pb53ro0l",
      "expanded_url" : "http:\/\/tokenteach.wordpress.com\/2012\/12\/11\/storybooks-written-by-english-teachers\/",
      "display_url" : "tokenteach.wordpress.com\/2012\/12\/11\/sto\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "279213279446986752",
  "text" : "RT @kevchanwow: @JosetteLB new post has me thinking it's not so crazy to kiss a fish, love your cow, and fart on a frog: http:\/\/t.co\/Pb5 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Josette LeBlanc",
        "screen_name" : "JosetteLB",
        "indices" : [ 0, 10 ],
        "id_str" : "33503694",
        "id" : 33503694
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "amazing",
        "indices" : [ 126, 134 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 125 ],
        "url" : "http:\/\/t.co\/Pb53ro0l",
        "expanded_url" : "http:\/\/tokenteach.wordpress.com\/2012\/12\/11\/storybooks-written-by-english-teachers\/",
        "display_url" : "tokenteach.wordpress.com\/2012\/12\/11\/sto\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "279209710580793344",
    "in_reply_to_user_id" : 33503694,
    "text" : "@JosetteLB new post has me thinking it's not so crazy to kiss a fish, love your cow, and fart on a frog: http:\/\/t.co\/Pb53ro0l #amazing",
    "id" : 279209710580793344,
    "created_at" : "2012-12-13 13:02:37 +0000",
    "in_reply_to_screen_name" : "JosetteLB",
    "in_reply_to_user_id_str" : "33503694",
    "user" : {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "protected" : false,
      "id_str" : "144663117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/559618421839507456\/nPF7dP47_normal.jpeg",
      "id" : 144663117,
      "verified" : false
    }
  },
  "id" : 279213279446986752,
  "created_at" : "2012-12-13 13:16:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vicky Loras",
      "screen_name" : "vickyloras",
      "indices" : [ 18, 29 ],
      "id_str" : "95957241",
      "id" : 95957241
    }, {
      "name" : "Anna Loseva",
      "screen_name" : "AnnLoseva",
      "indices" : [ 58, 68 ],
      "id_str" : "38822368",
      "id" : 38822368
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELT",
      "indices" : [ 127, 131 ]
    }, {
      "text" : "esol",
      "indices" : [ 132, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/sqJsPEQ8",
      "expanded_url" : "http:\/\/post.ly\/9y8Qd",
      "display_url" : "post.ly\/9y8Qd"
    } ]
  },
  "geo" : { },
  "id_str" : "279212487948259330",
  "text" : "congrats anna! MT @vickyloras Happy blog birthday!!!!! RT @AnnLoseva: December 13th. my blog's birthday. http:\/\/t.co\/sqJsPEQ8  #ELT #esol",
  "id" : 279212487948259330,
  "created_at" : "2012-12-13 13:13:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 31 ],
      "url" : "http:\/\/t.co\/2MSL9JiY",
      "expanded_url" : "http:\/\/members5.boardhost.com\/medialens\/msg\/1355396330.html",
      "display_url" : "members5.boardhost.com\/medialens\/msg\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "279186366804398081",
  "text" : "85% guilty http:\/\/t.co\/2MSL9JiY",
  "id" : 279186366804398081,
  "created_at" : "2012-12-13 11:29:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279158043583852544",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson many thanks for RT of last blog post, Eric Cartman thx u also for respecting his authoritah! :)",
  "id" : 279158043583852544,
  "created_at" : "2012-12-13 09:37:18 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Smith",
      "screen_name" : "mothtims",
      "indices" : [ 87, 96 ],
      "id_str" : "582859167",
      "id" : 582859167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/KM784iZA",
      "expanded_url" : "http:\/\/wp.me\/p2mDjs-37",
      "display_url" : "wp.me\/p2mDjs-37"
    } ]
  },
  "geo" : { },
  "id_str" : "278991833474940930",
  "text" : "very nice metaphor&gt;Accuracy and fluency: keeping a balance http:\/\/t.co\/KM784iZA via @mothtims",
  "id" : 278991833474940930,
  "created_at" : "2012-12-12 22:36:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "englishfortheweb",
      "indices" : [ 76, 93 ]
    }, {
      "text" : "englishformultimedia",
      "indices" : [ 94, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/7tYe56Fg",
      "expanded_url" : "http:\/\/bit.ly\/UCkyKB",
      "display_url" : "bit.ly\/UCkyKB"
    } ]
  },
  "geo" : { },
  "id_str" : "278985949797560320",
  "text" : "new blog post SouthPark, web user requirements meeting http:\/\/t.co\/7tYe56Fg #englishfortheweb #englishformultimedia",
  "id" : 278985949797560320,
  "created_at" : "2012-12-12 22:13:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stan Carey",
      "screen_name" : "StanCarey",
      "indices" : [ 3, 13 ],
      "id_str" : "34347535",
      "id" : 34347535
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/d4U0Pn4i",
      "expanded_url" : "http:\/\/bit.ly\/XS4jhy",
      "display_url" : "bit.ly\/XS4jhy"
    } ]
  },
  "geo" : { },
  "id_str" : "278870058548199424",
  "text" : "RT @StanCarey: How do you pronounce GIF? Does it matter? http:\/\/t.co\/d4U0Pn4i (new blog post, with a poll)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 62 ],
        "url" : "http:\/\/t.co\/d4U0Pn4i",
        "expanded_url" : "http:\/\/bit.ly\/XS4jhy",
        "display_url" : "bit.ly\/XS4jhy"
      } ]
    },
    "geo" : { },
    "id_str" : "278863060045811713",
    "text" : "How do you pronounce GIF? Does it matter? http:\/\/t.co\/d4U0Pn4i (new blog post, with a poll)",
    "id" : 278863060045811713,
    "created_at" : "2012-12-12 14:05:09 +0000",
    "user" : {
      "name" : "Stan Carey",
      "screen_name" : "StanCarey",
      "protected" : false,
      "id_str" : "34347535",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/611193710240514048\/w5lUpuqq_normal.jpg",
      "id" : 34347535,
      "verified" : false
    }
  },
  "id" : 278870058548199424,
  "created_at" : "2012-12-12 14:32:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278796048699371520",
  "geo" : { },
  "id_str" : "278811771047915520",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson hehe well logging in from uni computer so could explain then again am sure noticed similar results from home computer eeek!",
  "id" : 278811771047915520,
  "in_reply_to_status_id" : 278796048699371520,
  "created_at" : "2012-12-12 10:41:20 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278786788036861953",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson the Recommended for You Links on yr blog always raises a smile -\nJessica Alba's Cozy Winter Style Turns Heads...hmmm",
  "id" : 278786788036861953,
  "created_at" : "2012-12-12 09:02:04 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Sample",
      "screen_name" : "samplereality",
      "indices" : [ 3, 17 ],
      "id_str" : "8497292",
      "id" : 8497292
    }, {
      "name" : "The Daily Beast",
      "screen_name" : "thedailybeast",
      "indices" : [ 22, 36 ],
      "id_str" : "16012783",
      "id" : 16012783
    }, {
      "name" : "Josh Begley",
      "screen_name" : "joshbegley",
      "indices" : [ 76, 87 ],
      "id_str" : "19158981",
      "id" : 19158981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/TlCRUOdN",
      "expanded_url" : "http:\/\/flip.it\/FlD0M",
      "display_url" : "flip.it\/FlD0M"
    } ]
  },
  "geo" : { },
  "id_str" : "278738324926128128",
  "text" : "RT @samplereality: RT @thedailybeast: After Apple rejects app, grad student @JoshBegley will tweet every drone strike from 2002 to today ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.flipboard.com\" rel=\"nofollow\"\u003EFlipboard\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Daily Beast",
        "screen_name" : "thedailybeast",
        "indices" : [ 3, 17 ],
        "id_str" : "16012783",
        "id" : 16012783
      }, {
        "name" : "Josh Begley",
        "screen_name" : "joshbegley",
        "indices" : [ 57, 68 ],
        "id_str" : "19158981",
        "id" : 19158981
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/TlCRUOdN",
        "expanded_url" : "http:\/\/flip.it\/FlD0M",
        "display_url" : "flip.it\/FlD0M"
      } ]
    },
    "geo" : { },
    "id_str" : "278722727085494272",
    "text" : "RT @thedailybeast: After Apple rejects app, grad student @JoshBegley will tweet every drone strike from 2002 to today http:\/\/t.co\/TlCRUOdN",
    "id" : 278722727085494272,
    "created_at" : "2012-12-12 04:47:31 +0000",
    "user" : {
      "name" : "Mark Sample",
      "screen_name" : "samplereality",
      "protected" : false,
      "id_str" : "8497292",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000707852410\/a86167716ecb748acc89638ad165a162_normal.jpeg",
      "id" : 8497292,
      "verified" : false
    }
  },
  "id" : 278738324926128128,
  "created_at" : "2012-12-12 05:49:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sophia Khan",
      "screen_name" : "SophiaKhan4",
      "indices" : [ 0, 12 ],
      "id_str" : "351390617",
      "id" : 351390617
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278630481719877633",
  "geo" : { },
  "id_str" : "278631122995404800",
  "in_reply_to_user_id" : 351390617,
  "text" : "@SophiaKhan4 the way there are taught eng follows french lang model - structured\/heavily grammar based, though it is slowly changing",
  "id" : 278631122995404800,
  "in_reply_to_status_id" : 278630481719877633,
  "created_at" : "2012-12-11 22:43:31 +0000",
  "in_reply_to_screen_name" : "SophiaKhan4",
  "in_reply_to_user_id_str" : "351390617",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 3, 18 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oldeltpost",
      "indices" : [ 92, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/8XNGoYGa",
      "expanded_url" : "http:\/\/elt2.co.uk\/YUjbMO",
      "display_url" : "elt2.co.uk\/YUjbMO"
    } ]
  },
  "geo" : { },
  "id_str" : "278619243006803969",
  "text" : "RT @MrChrisJWilson: Some people still haven't recommended one of their blog posts for their #oldeltpost of the year. Time is running out ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "oldeltpost",
        "indices" : [ 72, 83 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/8XNGoYGa",
        "expanded_url" : "http:\/\/elt2.co.uk\/YUjbMO",
        "display_url" : "elt2.co.uk\/YUjbMO"
      } ]
    },
    "geo" : { },
    "id_str" : "278568438983696384",
    "text" : "Some people still haven't recommended one of their blog posts for their #oldeltpost of the year. Time is running out http:\/\/t.co\/8XNGoYGa",
    "id" : 278568438983696384,
    "created_at" : "2012-12-11 18:34:26 +0000",
    "user" : {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "protected" : false,
      "id_str" : "20760283",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744952885595758592\/H4bmsUn3_normal.jpg",
      "id" : 20760283,
      "verified" : false
    }
  },
  "id" : 278619243006803969,
  "created_at" : "2012-12-11 21:56:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephanie McIntosh",
      "screen_name" : "purple_steph",
      "indices" : [ 33, 46 ],
      "id_str" : "18678010",
      "id" : 18678010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/YzFVU99Y",
      "expanded_url" : "http:\/\/anothergreatteachingblog.blogspot.co.uk\/2012\/12\/interactive-resources-doing-it-right.html",
      "display_url" : "\u2026othergreatteachingblog.blogspot.co.uk\/2012\/12\/intera\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "278617303996854272",
  "text" : "some nice use cases here &gt; RT @purple_steph: http:\/\/t.co\/YzFVU99Y - (Me - blogging for my college)",
  "id" : 278617303996854272,
  "created_at" : "2012-12-11 21:48:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sophia Khan",
      "screen_name" : "SophiaKhan4",
      "indices" : [ 0, 12 ],
      "id_str" : "351390617",
      "id" : 351390617
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278603115329114112",
  "geo" : { },
  "id_str" : "278615798996688897",
  "in_reply_to_user_id" : 351390617,
  "text" : "@SophiaKhan4 informative post! the first point happens to a lesser extent with french students at secondary level(lycee,college)",
  "id" : 278615798996688897,
  "in_reply_to_status_id" : 278603115329114112,
  "created_at" : "2012-12-11 21:42:37 +0000",
  "in_reply_to_screen_name" : "SophiaKhan4",
  "in_reply_to_user_id_str" : "351390617",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George Chilton",
      "screen_name" : "designerlessons",
      "indices" : [ 0, 16 ],
      "id_str" : "432090149",
      "id" : 432090149
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278590788206747648",
  "geo" : { },
  "id_str" : "278613750582501377",
  "in_reply_to_user_id" : 432090149,
  "text" : "@designerlessons many thx for fab compliment and tweet of strangelove post! striving to get to your level! :)",
  "id" : 278613750582501377,
  "in_reply_to_status_id" : 278590788206747648,
  "created_at" : "2012-12-11 21:34:29 +0000",
  "in_reply_to_screen_name" : "designerlessons",
  "in_reply_to_user_id_str" : "432090149",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "Anna Loseva",
      "screen_name" : "AnnLoseva",
      "indices" : [ 12, 22 ],
      "id_str" : "38822368",
      "id" : 38822368
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278479036718673920",
  "geo" : { },
  "id_str" : "278507767583617024",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan @AnnLoseva not aware of that conspiracy, what is it?",
  "id" : 278507767583617024,
  "in_reply_to_status_id" : 278479036718673920,
  "created_at" : "2012-12-11 14:33:20 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278506416363421697",
  "geo" : { },
  "id_str" : "278507554865307648",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan is that one can look up refs whilst participating",
  "id" : 278507554865307648,
  "in_reply_to_status_id" : 278506416363421697,
  "created_at" : "2012-12-11 14:32:30 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 32, 43 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/UfcBxKNv",
      "expanded_url" : "http:\/\/www.digitalcounterrevolution.co.uk\/2012\/personalising-education-person-centred-critique\/",
      "display_url" : "digitalcounterrevolution.co.uk\/2012\/personali\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "278465121003659264",
  "text" : "another cracking missive &gt;RT @tornhalves: Personalising education - is this the way forward? http:\/\/t.co\/UfcBxKNv",
  "id" : 278465121003659264,
  "created_at" : "2012-12-11 11:43:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278460664245280768",
  "geo" : { },
  "id_str" : "278462055479115776",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan hmm sorry to state obvious but did u check spelling on u\/n or email address?",
  "id" : 278462055479115776,
  "in_reply_to_status_id" : 278460664245280768,
  "created_at" : "2012-12-11 11:31:42 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278460008864296960",
  "geo" : { },
  "id_str" : "278460504517783552",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan you can reset p\/w?",
  "id" : 278460504517783552,
  "in_reply_to_status_id" : 278460008864296960,
  "created_at" : "2012-12-11 11:25:32 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boing Boing",
      "screen_name" : "BoingBoing",
      "indices" : [ 106, 117 ],
      "id_str" : "5971922",
      "id" : 5971922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 38 ],
      "url" : "http:\/\/t.co\/IPx8q2Bm",
      "expanded_url" : "http:\/\/www.billhickssays.com\/permalink\/quote-119.html",
      "display_url" : "billhickssays.com\/permalink\/quot\u2026"
    }, {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/Z3dWdWBP",
      "expanded_url" : "http:\/\/boingboing.net\/2012\/12\/10\/burrito-bomber-open-source-ha.html",
      "display_url" : "boingboing.net\/2012\/12\/10\/bur\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "278459666214838274",
  "text" : "Bill Hicks vision http:\/\/t.co\/IPx8q2Bm comes a next step closer - Burrito Bomber http:\/\/t.co\/Z3dWdWBP via @boingboing",
  "id" : 278459666214838274,
  "created_at" : "2012-12-11 11:22:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278453169342787584",
  "geo" : { },
  "id_str" : "278454139866972160",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson going back to original meanings is all good :)",
  "id" : 278454139866972160,
  "in_reply_to_status_id" : 278453169342787584,
  "created_at" : "2012-12-11 11:00:15 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278450639590277120",
  "geo" : { },
  "id_str" : "278451864482230272",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson nice one, those miscreants should be called net vandals rather than hackers!",
  "id" : 278451864482230272,
  "in_reply_to_status_id" : 278450639590277120,
  "created_at" : "2012-12-11 10:51:12 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 30, 44 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/rVosPD3P",
      "expanded_url" : "http:\/\/pmarca-archive.posterous.com\/the-three-kinds-of-platforms-you-meet-on-the-0",
      "display_url" : "pmarca-archive.posterous.com\/the-three-kind\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "278445154476630017",
  "text" : "a lotta good stuff here&gt;RT @audreywatters: Andreessen wrote a great post on platforms circa 2007 http:\/\/t.co\/rVosPD3P",
  "id" : 278445154476630017,
  "created_at" : "2012-12-11 10:24:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TeachingEnglish",
      "screen_name" : "TeachingEnglish",
      "indices" : [ 19, 35 ],
      "id_str" : "21313816",
      "id" : 21313816
    }, {
      "name" : "George Chilton",
      "screen_name" : "designerlessons",
      "indices" : [ 91, 107 ],
      "id_str" : "432090149",
      "id" : 432090149
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "britishcouncil",
      "indices" : [ 36, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278439506334597120",
  "text" : "i was a contender! @teachingenglish #britishcouncil december blog post well done to winner @designerlessons and other noms",
  "id" : 278439506334597120,
  "created_at" : "2012-12-11 10:02:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/iuMn0F6Z",
      "expanded_url" : "http:\/\/bit.ly\/VsRl3P",
      "display_url" : "bit.ly\/VsRl3P"
    } ]
  },
  "geo" : { },
  "id_str" : "277882956582879232",
  "text" : "Singing about killing people v. constantly doing it http:\/\/t.co\/iuMn0F6Z",
  "id" : 277882956582879232,
  "created_at" : "2012-12-09 21:10:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sandy Millin",
      "screen_name" : "sandymillin",
      "indices" : [ 0, 12 ],
      "id_str" : "144236944",
      "id" : 144236944
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277535872407195649",
  "geo" : { },
  "id_str" : "277664656833777664",
  "in_reply_to_user_id" : 144236944,
  "text" : "@sandymillin a pleasure for sure",
  "id" : 277664656833777664,
  "in_reply_to_status_id" : 277535872407195649,
  "created_at" : "2012-12-09 06:43:07 +0000",
  "in_reply_to_screen_name" : "sandymillin",
  "in_reply_to_user_id_str" : "144236944",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277380315411005441",
  "geo" : { },
  "id_str" : "277664508502241280",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin pleasure, enjoyed reading it",
  "id" : 277664508502241280,
  "in_reply_to_status_id" : 277380315411005441,
  "created_at" : "2012-12-09 06:42:32 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George Chilton",
      "screen_name" : "designerlessons",
      "indices" : [ 13, 29 ],
      "id_str" : "432090149",
      "id" : 432090149
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELT",
      "indices" : [ 99, 103 ]
    }, {
      "text" : "TEFL",
      "indices" : [ 104, 109 ]
    }, {
      "text" : "IATEFL",
      "indices" : [ 110, 117 ]
    }, {
      "text" : "KELTchat",
      "indices" : [ 118, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "277664341292105728",
  "text" : "congrats! RT @designerlessons: Designer Lessons is 1 year old today - thanks for all your support! #ELT #TEFL #IATEFL #KELTchat",
  "id" : 277664341292105728,
  "created_at" : "2012-12-09 06:41:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/2hK7nHOA",
      "expanded_url" : "http:\/\/www.salon.com\/2012\/12\/08\/psy_apologizes_for_anti_american_rap\/",
      "display_url" : "salon.com\/2012\/12\/08\/psy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "277369451517718528",
  "text" : "at last something interesting about Gangnam Style - PSY apologizes for anti-American rap http:\/\/t.co\/2hK7nHOA",
  "id" : 277369451517718528,
  "created_at" : "2012-12-08 11:10:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Ding",
      "screen_name" : "alexanderding",
      "indices" : [ 0, 14 ],
      "id_str" : "118014141",
      "id" : 118014141
    }, {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 15, 23 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277358164641472513",
  "geo" : { },
  "id_str" : "277360321834930176",
  "in_reply_to_user_id" : 118014141,
  "text" : "@alexanderding @seburnt that's int do u have sme ex in mind?",
  "id" : 277360321834930176,
  "in_reply_to_status_id" : 277358164641472513,
  "created_at" : "2012-12-08 10:33:48 +0000",
  "in_reply_to_screen_name" : "alexanderding",
  "in_reply_to_user_id_str" : "118014141",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stan Carey",
      "screen_name" : "StanCarey",
      "indices" : [ 85, 95 ],
      "id_str" : "34347535",
      "id" : 34347535
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/rsmXwods",
      "expanded_url" : "http:\/\/stancarey.wordpress.com\/2012\/12\/06\/non-cognate-interlexical-homographs-text-vote\/",
      "display_url" : "stancarey.wordpress.com\/2012\/12\/06\/non\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "277348698277695489",
  "text" : "(Probably not)Non-cognate interlexical homographs text vote http:\/\/t.co\/rsmXwods via @StanCarey",
  "id" : 277348698277695489,
  "created_at" : "2012-12-08 09:47:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sandy Millin",
      "screen_name" : "sandymillin",
      "indices" : [ 68, 80 ],
      "id_str" : "144236944",
      "id" : 144236944
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/VGPgfLBP",
      "expanded_url" : "http:\/\/sandymillin.wordpress.com\/2012\/12\/07\/reading-a-short-story\/",
      "display_url" : "sandymillin.wordpress.com\/2012\/12\/07\/rea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "277346279116382210",
  "text" : "a grt class desc&gt; Reading a short story http:\/\/t.co\/VGPgfLBP via @sandymillin",
  "id" : 277346279116382210,
  "created_at" : "2012-12-08 09:38:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "c m kerr",
      "screen_name" : "KerrCarolyn",
      "indices" : [ 3, 15 ],
      "id_str" : "468676296",
      "id" : 468676296
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TESOLFR",
      "indices" : [ 16, 24 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/EW3VmNQK",
      "expanded_url" : "http:\/\/www.tesol-france.org\/workshopAGM.php",
      "display_url" : "tesol-france.org\/workshopAGM.php"
    } ]
  },
  "geo" : { },
  "id_str" : "277341068268294144",
  "text" : "MT @KerrCarolyn #TESOLFR Workshop + AGM in Paris! with Damian Corcoran. ^see you soon^ http:\/\/t.co\/EW3VmNQK &lt;-have a good one Damian",
  "id" : 277341068268294144,
  "created_at" : "2012-12-08 09:17:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/Npaxk9Eh",
      "expanded_url" : "http:\/\/boingboing.net\/2012\/12\/07\/improve-your-soundstage-dvd-c.html",
      "display_url" : "boingboing.net\/2012\/12\/07\/imp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "277329382157189120",
  "text" : "move over NLP, out the way Learning Styles, u need some of these bad boys to enhance yr class http:\/\/t.co\/Npaxk9Eh :)",
  "id" : 277329382157189120,
  "created_at" : "2012-12-08 08:30:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EDTECH HULK",
      "screen_name" : "EDTECHHULK",
      "indices" : [ 39, 50 ],
      "id_str" : "235000147",
      "id" : 235000147
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 35 ],
      "url" : "http:\/\/t.co\/XwoQa5X6",
      "expanded_url" : "http:\/\/fnoschese.wordpress.com\/2011\/02\/21\/pt-pseudoteaching-mit-physics\/",
      "display_url" : "fnoschese.wordpress.com\/2011\/02\/21\/pt-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "277198889164095488",
  "text" : "pseudoteaching http:\/\/t.co\/XwoQa5X6 HT @EDTECHHULK",
  "id" : 277198889164095488,
  "created_at" : "2012-12-07 23:52:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 0, 11 ],
      "id_str" : "282659955",
      "id" : 282659955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277126894372130816",
  "geo" : { },
  "id_str" : "277152042622017536",
  "in_reply_to_user_id" : 282659955,
  "text" : "@teflerinha pleasure! have a good w\/e!",
  "id" : 277152042622017536,
  "in_reply_to_status_id" : 277126894372130816,
  "created_at" : "2012-12-07 20:46:10 +0000",
  "in_reply_to_screen_name" : "teflerinha",
  "in_reply_to_user_id_str" : "282659955",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "277151900317655040",
  "text" : "not on FB can't like myself! hmm sure this is Mark Z's way of luring me back on FB! :?",
  "id" : 277151900317655040,
  "created_at" : "2012-12-07 20:45:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TeachingEnglish",
      "screen_name" : "TeachingEnglish",
      "indices" : [ 3, 19 ],
      "id_str" : "21313816",
      "id" : 21313816
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeachingEnglish",
      "indices" : [ 32, 48 ]
    }, {
      "text" : "BritishCouncil",
      "indices" : [ 93, 108 ]
    }, {
      "text" : "elt",
      "indices" : [ 109, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/WCqc2NHL",
      "expanded_url" : "http:\/\/bit.ly\/YIKUkw",
      "display_url" : "bit.ly\/YIKUkw"
    } ]
  },
  "geo" : { },
  "id_str" : "277151505033879554",
  "text" : "MT @TeachingEnglish Shortlisted #TeachingEnglish blog award! Mura Nava http:\/\/t.co\/WCqc2NHL  #BritishCouncil #elt &lt;-Mr Kubrick abides :)",
  "id" : 277151505033879554,
  "created_at" : "2012-12-07 20:44:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valentina Morgana",
      "screen_name" : "vmorgana",
      "indices" : [ 0, 9 ],
      "id_str" : "62479177",
      "id" : 62479177
    }, {
      "name" : "Julia Nikonova",
      "screen_name" : "jnikonova",
      "indices" : [ 10, 20 ],
      "id_str" : "580490858",
      "id" : 580490858
    }, {
      "name" : "Joan Queralt\u00F3",
      "screen_name" : "joanqueralto",
      "indices" : [ 21, 34 ],
      "id_str" : "499683768",
      "id" : 499683768
    }, {
      "name" : "Alfredo Corell",
      "screen_name" : "virtuAlf7_0",
      "indices" : [ 35, 47 ],
      "id_str" : "196124212",
      "id" : 196124212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277070449739980800",
  "geo" : { },
  "id_str" : "277072079021547521",
  "in_reply_to_user_id" : 62479177,
  "text" : "@vmorgana @jnikonova @joanqueralto @virtuAlf7_0 enjoy the snow and the w\/e :)",
  "id" : 277072079021547521,
  "in_reply_to_status_id" : 277070449739980800,
  "created_at" : "2012-12-07 15:28:26 +0000",
  "in_reply_to_screen_name" : "vmorgana",
  "in_reply_to_user_id_str" : "62479177",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "phil wade",
      "screen_name" : "phil3wade",
      "indices" : [ 0, 10 ],
      "id_str" : "248864761",
      "id" : 248864761
    }, {
      "name" : "TeachingEnglish",
      "screen_name" : "TeachingEnglish",
      "indices" : [ 11, 27 ],
      "id_str" : "21313816",
      "id" : 21313816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277028194740215809",
  "geo" : { },
  "id_str" : "277069637294882818",
  "in_reply_to_user_id" : 248864761,
  "text" : "@phil3wade @TeachingEnglish i heartily agree moviesegmentstoassessgrammargoals  is a great resource, just used one of his lessons today :)",
  "id" : 277069637294882818,
  "in_reply_to_status_id" : 277028194740215809,
  "created_at" : "2012-12-07 15:18:43 +0000",
  "in_reply_to_screen_name" : "phil3wade",
  "in_reply_to_user_id_str" : "248864761",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 3, 19 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/zaoiMKAY",
      "expanded_url" : "http:\/\/eltrantsreviewsreflections.wordpress.com\/2012\/12\/07\/happiness-from-students-discussing-happiness\/",
      "display_url" : "\u2026rantsreviewsreflections.wordpress.com\/2012\/12\/07\/hap\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "277068054817550336",
  "text" : "RT @michaelegriffin: Just blogged: Happiness from Hearing Students Discussing Happiness http:\/\/t.co\/zaoiMKAY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 87 ],
        "url" : "http:\/\/t.co\/zaoiMKAY",
        "expanded_url" : "http:\/\/eltrantsreviewsreflections.wordpress.com\/2012\/12\/07\/happiness-from-students-discussing-happiness\/",
        "display_url" : "\u2026rantsreviewsreflections.wordpress.com\/2012\/12\/07\/hap\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "277052227531702272",
    "text" : "Just blogged: Happiness from Hearing Students Discussing Happiness http:\/\/t.co\/zaoiMKAY",
    "id" : 277052227531702272,
    "created_at" : "2012-12-07 14:09:33 +0000",
    "user" : {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "protected" : false,
      "id_str" : "394053348",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766911330645315584\/il5gKyOJ_normal.jpg",
      "id" : 394053348,
      "verified" : false
    }
  },
  "id" : 277068054817550336,
  "created_at" : "2012-12-07 15:12:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 3, 14 ],
      "id_str" : "282659955",
      "id" : 282659955
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 48, 56 ]
    }, {
      "text" : "elt",
      "indices" : [ 57, 61 ]
    }, {
      "text" : "esol",
      "indices" : [ 62, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/LDrRgkR0",
      "expanded_url" : "http:\/\/wp.me\/p2e2Wf-9h",
      "display_url" : "wp.me\/p2e2Wf-9h"
    } ]
  },
  "geo" : { },
  "id_str" : "277067836772462593",
  "text" : "RT @teflerinha: 'Real world' writing activities #eltchat #elt #esol http:\/\/t.co\/LDrRgkR0&gt; any more ideas to add?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "eltchat",
        "indices" : [ 32, 40 ]
      }, {
        "text" : "elt",
        "indices" : [ 41, 45 ]
      }, {
        "text" : "esol",
        "indices" : [ 46, 51 ]
      } ],
      "urls" : [ {
        "indices" : [ 52, 72 ],
        "url" : "http:\/\/t.co\/LDrRgkR0",
        "expanded_url" : "http:\/\/wp.me\/p2e2Wf-9h",
        "display_url" : "wp.me\/p2e2Wf-9h"
      } ]
    },
    "geo" : { },
    "id_str" : "277050737660403714",
    "text" : "'Real world' writing activities #eltchat #elt #esol http:\/\/t.co\/LDrRgkR0&gt; any more ideas to add?",
    "id" : 277050737660403714,
    "created_at" : "2012-12-07 14:03:37 +0000",
    "user" : {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "protected" : false,
      "id_str" : "282659955",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2149898907\/Rachael_Roberts_headshot_square_normal.jpg",
      "id" : 282659955,
      "verified" : false
    }
  },
  "id" : 277067836772462593,
  "created_at" : "2012-12-07 15:11:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mieke Kenis",
      "screen_name" : "mkofab",
      "indices" : [ 3, 10 ],
      "id_str" : "96527212",
      "id" : 96527212
    }, {
      "name" : "Vicky Loras",
      "screen_name" : "vickyloras",
      "indices" : [ 139, 140 ],
      "id_str" : "95957241",
      "id" : 95957241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/ICFYsGc7",
      "expanded_url" : "http:\/\/wp.me\/pIrrb-qu",
      "display_url" : "wp.me\/pIrrb-qu"
    } ]
  },
  "geo" : { },
  "id_str" : "277067698893111296",
  "text" : "RT @mkofab: Interviews with Three New Bloggers for My Three Years of Blogging - Number One: Din\u00E7er Demir http:\/\/t.co\/ICFYsGc7 via @vicky ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vicky Loras",
        "screen_name" : "vickyloras",
        "indices" : [ 118, 129 ],
        "id_str" : "95957241",
        "id" : 95957241
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 113 ],
        "url" : "http:\/\/t.co\/ICFYsGc7",
        "expanded_url" : "http:\/\/wp.me\/pIrrb-qu",
        "display_url" : "wp.me\/pIrrb-qu"
      } ]
    },
    "geo" : { },
    "id_str" : "277045947576496129",
    "text" : "Interviews with Three New Bloggers for My Three Years of Blogging - Number One: Din\u00E7er Demir http:\/\/t.co\/ICFYsGc7 via @vickyloras",
    "id" : 277045947576496129,
    "created_at" : "2012-12-07 13:44:35 +0000",
    "user" : {
      "name" : "Mieke Kenis",
      "screen_name" : "mkofab",
      "protected" : false,
      "id_str" : "96527212",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/642333852199952385\/XKkzUhRv_normal.jpg",
      "id" : 96527212,
      "verified" : false
    }
  },
  "id" : 277067698893111296,
  "created_at" : "2012-12-07 15:11:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 51 ],
      "url" : "https:\/\/t.co\/bIOm16XB",
      "expanded_url" : "https:\/\/kielikompassi.jyu.fi\/kookit06\/corpus\/view\/viewmain.html#",
      "display_url" : "kielikompassi.jyu.fi\/kookit06\/corpu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "276859702166568960",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow have u seen this? https:\/\/t.co\/bIOm16XB",
  "id" : 276859702166568960,
  "created_at" : "2012-12-07 01:24:31 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vicky Loras",
      "screen_name" : "vickyloras",
      "indices" : [ 0, 11 ],
      "id_str" : "95957241",
      "id" : 95957241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276279390587981824",
  "geo" : { },
  "id_str" : "276408228483575808",
  "in_reply_to_user_id" : 95957241,
  "text" : "@vickyloras pleasure hope u had a good one as well.",
  "id" : 276408228483575808,
  "in_reply_to_status_id" : 276279390587981824,
  "created_at" : "2012-12-05 19:30:31 +0000",
  "in_reply_to_screen_name" : "vickyloras",
  "in_reply_to_user_id_str" : "95957241",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "c m kerr",
      "screen_name" : "KerrCarolyn",
      "indices" : [ 28, 40 ],
      "id_str" : "468676296",
      "id" : 468676296
    }, {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 42, 53 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 123, 143 ],
      "url" : "http:\/\/t.co\/bhuveYjG",
      "expanded_url" : "http:\/\/amodisco.wordpress.com",
      "display_url" : "amodisco.wordpress.com"
    } ]
  },
  "geo" : { },
  "id_str" : "276407039079624705",
  "text" : "a cracking classrm post&gt; @KerrCarolyn  @leoselivan Business Lexicalising Business English teaching - 'problem vs issue' http:\/\/t.co\/bhuveYjG",
  "id" : 276407039079624705,
  "created_at" : "2012-12-05 19:25:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lewis School HR",
      "screen_name" : "alatlewisschool",
      "indices" : [ 3, 19 ],
      "id_str" : "473783869",
      "id" : 473783869
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/E6yHR04E",
      "expanded_url" : "http:\/\/bit.ly\/VB98HM",
      "display_url" : "bit.ly\/VB98HM"
    } ]
  },
  "geo" : { },
  "id_str" : "276251900683362304",
  "text" : "RT @alatlewisschool: Sentences: It\\\\\\'s a Jumble Out There! http:\/\/t.co\/E6yHR04E",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 59 ],
        "url" : "http:\/\/t.co\/E6yHR04E",
        "expanded_url" : "http:\/\/bit.ly\/VB98HM",
        "display_url" : "bit.ly\/VB98HM"
      } ]
    },
    "geo" : { },
    "id_str" : "276250187876417536",
    "text" : "Sentences: It\\\\\\'s a Jumble Out There! http:\/\/t.co\/E6yHR04E",
    "id" : 276250187876417536,
    "created_at" : "2012-12-05 09:02:31 +0000",
    "user" : {
      "name" : "Lewis School HR",
      "screen_name" : "alatlewisschool",
      "protected" : false,
      "id_str" : "473783869",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1780093447\/lewis_logo_large_trans_normal_normal.png",
      "id" : 473783869,
      "verified" : false
    }
  },
  "id" : 276251900683362304,
  "created_at" : "2012-12-05 09:09:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vicky Loras",
      "screen_name" : "vickyloras",
      "indices" : [ 3, 14 ],
      "id_str" : "95957241",
      "id" : 95957241
    }, {
      "name" : "Kieran Donaghy",
      "screen_name" : "kierandonaghy",
      "indices" : [ 35, 49 ],
      "id_str" : "135272434",
      "id" : 135272434
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/swgzhpaK",
      "expanded_url" : "http:\/\/wp.me\/p2rW9O-U0",
      "display_url" : "wp.me\/p2rW9O-U0"
    }, {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/nMkYwXl0",
      "expanded_url" : "http:\/\/fb.me\/24UWrubMR",
      "display_url" : "fb.me\/24UWrubMR"
    } ]
  },
  "geo" : { },
  "id_str" : "276248356802658304",
  "text" : "RT @vickyloras: New lesson plan by @kierandonaghy at Film English based on beautiful Christmas short film. http:\/\/t.co\/swgzhpaK ... http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kieran Donaghy",
        "screen_name" : "kierandonaghy",
        "indices" : [ 19, 33 ],
        "id_str" : "135272434",
        "id" : 135272434
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 111 ],
        "url" : "http:\/\/t.co\/swgzhpaK",
        "expanded_url" : "http:\/\/wp.me\/p2rW9O-U0",
        "display_url" : "wp.me\/p2rW9O-U0"
      }, {
        "indices" : [ 116, 136 ],
        "url" : "http:\/\/t.co\/nMkYwXl0",
        "expanded_url" : "http:\/\/fb.me\/24UWrubMR",
        "display_url" : "fb.me\/24UWrubMR"
      } ]
    },
    "geo" : { },
    "id_str" : "276225458784333824",
    "text" : "New lesson plan by @kierandonaghy at Film English based on beautiful Christmas short film. http:\/\/t.co\/swgzhpaK ... http:\/\/t.co\/nMkYwXl0",
    "id" : 276225458784333824,
    "created_at" : "2012-12-05 07:24:16 +0000",
    "user" : {
      "name" : "Vicky Loras",
      "screen_name" : "vickyloras",
      "protected" : false,
      "id_str" : "95957241",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/649856172317519872\/zNL8t04-_normal.jpg",
      "id" : 95957241,
      "verified" : false
    }
  },
  "id" : 276248356802658304,
  "created_at" : "2012-12-05 08:55:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    }, {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 12, 23 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276109605480833024",
  "geo" : { },
  "id_str" : "276114931210911744",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow @leoselivan great tip there by leo, that coca sure is powerful! speaking of which think i'll go makeme some of that liquid sort",
  "id" : 276114931210911744,
  "in_reply_to_status_id" : 276109605480833024,
  "created_at" : "2012-12-05 00:05:04 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edward Banatt",
      "screen_name" : "ArmaVirumque",
      "indices" : [ 3, 16 ],
      "id_str" : "134207905",
      "id" : 134207905
    }, {
      "name" : "Oliver Sacks Fdn.",
      "screen_name" : "OliverSacks",
      "indices" : [ 21, 33 ],
      "id_str" : "52488565",
      "id" : 52488565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/VHTbKvqt",
      "expanded_url" : "http:\/\/nyti.ms\/VgWwUo",
      "display_url" : "nyti.ms\/VgWwUo"
    } ]
  },
  "geo" : { },
  "id_str" : "276105067168411649",
  "text" : "RT @ArmaVirumque: RT @OliverSacks: Very interesting! Pushing Science\u2019s Limits in Sign Language Lexicon http:\/\/t.co\/VHTbKvqt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/seesmic.com\/\" rel=\"nofollow\"\u003ESeesmic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Oliver Sacks Fdn.",
        "screen_name" : "OliverSacks",
        "indices" : [ 3, 15 ],
        "id_str" : "52488565",
        "id" : 52488565
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 105 ],
        "url" : "http:\/\/t.co\/VHTbKvqt",
        "expanded_url" : "http:\/\/nyti.ms\/VgWwUo",
        "display_url" : "nyti.ms\/VgWwUo"
      } ]
    },
    "geo" : { },
    "id_str" : "276101808823349248",
    "text" : "RT @OliverSacks: Very interesting! Pushing Science\u2019s Limits in Sign Language Lexicon http:\/\/t.co\/VHTbKvqt",
    "id" : 276101808823349248,
    "created_at" : "2012-12-04 23:12:55 +0000",
    "user" : {
      "name" : "Edward Banatt",
      "screen_name" : "ArmaVirumque",
      "protected" : false,
      "id_str" : "134207905",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/699281526182141953\/wVDinyf8_normal.jpg",
      "id" : 134207905,
      "verified" : false
    }
  },
  "id" : 276105067168411649,
  "created_at" : "2012-12-04 23:25:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Levine",
      "screen_name" : "cogdog",
      "indices" : [ 61, 68 ],
      "id_str" : "740343",
      "id" : 740343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/YkfxbvCQ",
      "expanded_url" : "http:\/\/www.wibbitz.com\/watch\/?id=a9db762d54de647d9917d8866e3536636&v=1&m=1&l=1&a=0",
      "display_url" : "wibbitz.com\/watch\/?id=a9db\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "276100093105541121",
  "text" : "hear all about it breaking blog news http:\/\/t.co\/YkfxbvCQ HT @cogdog",
  "id" : 276100093105541121,
  "created_at" : "2012-12-04 23:06:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 97, 107 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/VFuajFLN",
      "expanded_url" : "http:\/\/www.medialens.org\/index.php?option=com_content&view=article&id=711:the-special-one-celebrity-comedy-and-spiritual-egotism&catid=4:cogitations&Itemid=36",
      "display_url" : "medialens.org\/index.php?opti\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "276097504142053376",
  "text" : "http:\/\/t.co\/VFuajFLN Cogitation: 'The Special One' - Celebrity, Comedy And Spiritual Egotism via @medialens",
  "id" : 276097504142053376,
  "created_at" : "2012-12-04 22:55:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George Chilton",
      "screen_name" : "designerlessons",
      "indices" : [ 10, 26 ],
      "id_str" : "432090149",
      "id" : 432090149
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276059165087129601",
  "geo" : { },
  "id_str" : "276061532985651200",
  "in_reply_to_user_id" : 60425505,
  "text" : "@becksdad @designerlessons ooh not aware of youtube caption export nice tool for pronunciation work, ta v much",
  "id" : 276061532985651200,
  "in_reply_to_status_id" : 276059165087129601,
  "created_at" : "2012-12-04 20:32:53 +0000",
  "in_reply_to_screen_name" : "neil_mcm",
  "in_reply_to_user_id_str" : "60425505",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim George",
      "screen_name" : "oyajimbo",
      "indices" : [ 0, 9 ],
      "id_str" : "96103979",
      "id" : 96103979
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275945251477278721",
  "geo" : { },
  "id_str" : "275946939848200192",
  "in_reply_to_user_id" : 96103979,
  "text" : "@oyajimbo that's an int tool any description of use in class?",
  "id" : 275946939848200192,
  "in_reply_to_status_id" : 275945251477278721,
  "created_at" : "2012-12-04 12:57:31 +0000",
  "in_reply_to_screen_name" : "oyajimbo",
  "in_reply_to_user_id_str" : "96103979",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "c m kerr",
      "screen_name" : "KerrCarolyn",
      "indices" : [ 0, 12 ],
      "id_str" : "468676296",
      "id" : 468676296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275664270920912896",
  "geo" : { },
  "id_str" : "275944116997722113",
  "in_reply_to_user_id" : 468676296,
  "text" : "@KerrCarolyn pleaseure, replied to yr reply, also updated my post with yours!",
  "id" : 275944116997722113,
  "in_reply_to_status_id" : 275664270920912896,
  "created_at" : "2012-12-04 12:46:18 +0000",
  "in_reply_to_screen_name" : "KerrCarolyn",
  "in_reply_to_user_id_str" : "468676296",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    }, {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 12, 23 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275934228540170240",
  "geo" : { },
  "id_str" : "275943525965787136",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow @hughdellar just watched that adam sandler vid, nicely irrreverent :)wiki fact i just read: 3 fest of lights, happy hanukkah!",
  "id" : 275943525965787136,
  "in_reply_to_status_id" : 275934228540170240,
  "created_at" : "2012-12-04 12:43:58 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Sample",
      "screen_name" : "samplereality",
      "indices" : [ 3, 17 ],
      "id_str" : "8497292",
      "id" : 8497292
    }, {
      "name" : "le_mac",
      "screen_name" : "le_mac",
      "indices" : [ 115, 122 ],
      "id_str" : "17064137",
      "id" : 17064137
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/Niv3tUJa",
      "expanded_url" : "http:\/\/boniverotica.tumblr.com",
      "display_url" : "boniverotica.tumblr.com"
    } ]
  },
  "geo" : { },
  "id_str" : "275922723488813056",
  "text" : "RT @samplereality Good morning! You guys know about Bon Iver Erotica, right? Good morning! http:\/\/t.co\/Niv3tUJa cc @le_mac",
  "id" : 275922723488813056,
  "created_at" : "2012-12-04 11:21:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RootsAction",
      "screen_name" : "Roots_Action",
      "indices" : [ 69, 82 ],
      "id_str" : "234535697",
      "id" : 234535697
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/vZtqrtoe",
      "expanded_url" : "http:\/\/bit.ly\/R9OQ6J",
      "display_url" : "bit.ly\/R9OQ6J"
    } ]
  },
  "geo" : { },
  "id_str" : "275772306469564416",
  "text" : "Apple Inc. is censoring basic public information on drone wars. Help @Roots_Action ask Apple to change this policy http:\/\/t.co\/vZtqrtoe",
  "id" : 275772306469564416,
  "created_at" : "2012-12-04 01:23:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 39, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275663733257285633",
  "text" : "what about speeches and presentations? #eapchat",
  "id" : 275663733257285633,
  "created_at" : "2012-12-03 18:12:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharon Turner",
      "screen_name" : "Sharonzspace",
      "indices" : [ 0, 13 ],
      "id_str" : "235194378",
      "id" : 235194378
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 28, 36 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275663120171671552",
  "geo" : { },
  "id_str" : "275663430197862400",
  "in_reply_to_user_id" : 235194378,
  "text" : "@Sharonzspace how do you :) #eapchat",
  "id" : 275663430197862400,
  "in_reply_to_status_id" : 275663120171671552,
  "created_at" : "2012-12-03 18:10:57 +0000",
  "in_reply_to_screen_name" : "Sharonzspace",
  "in_reply_to_user_id_str" : "235194378",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 23, 31 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275662829850349568",
  "geo" : { },
  "id_str" : "275663385645965312",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt eh up chap :) #eapchat",
  "id" : 275663385645965312,
  "in_reply_to_status_id" : 275662829850349568,
  "created_at" : "2012-12-03 18:10:47 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 56, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275662519220199425",
  "text" : "here but will be lurking, hope to contribute when i can #eapchat",
  "id" : 275662519220199425,
  "created_at" : "2012-12-03 18:07:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/f3oNXctJ",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-aT",
      "display_url" : "wp.me\/pgHyE-aT"
    } ]
  },
  "geo" : { },
  "id_str" : "275658471817490432",
  "text" : "small update to Strangelove, telephoning post, added st example recording http:\/\/t.co\/f3oNXctJ",
  "id" : 275658471817490432,
  "created_at" : "2012-12-03 17:51:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nagehan Tunar",
      "screen_name" : "stiiiv",
      "indices" : [ 0, 7 ],
      "id_str" : "799058600",
      "id" : 799058600
    }, {
      "name" : "Rich Kiker",
      "screen_name" : "rkiker",
      "indices" : [ 8, 15 ],
      "id_str" : "19551063",
      "id" : 19551063
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275639699392057345",
  "geo" : { },
  "id_str" : "275656426536435713",
  "in_reply_to_user_id" : 69068757,
  "text" : "@stiiiv @rkiker hmm wondering if people still take Greenfield seriously?",
  "id" : 275656426536435713,
  "in_reply_to_status_id" : 275639699392057345,
  "created_at" : "2012-12-03 17:43:08 +0000",
  "in_reply_to_screen_name" : "stiivkirk",
  "in_reply_to_user_id_str" : "69068757",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 3, 11 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EAPchat",
      "indices" : [ 13, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275526366257086464",
  "text" : "RT @seburnt: #EAPchat, Monday Dec 3 1PM EST: Are conversation driven classes relevant in EAP?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EAPchat",
        "indices" : [ 0, 8 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "275478488314695680",
    "text" : "#EAPchat, Monday Dec 3 1PM EST: Are conversation driven classes relevant in EAP?",
    "id" : 275478488314695680,
    "created_at" : "2012-12-03 05:56:04 +0000",
    "user" : {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "protected" : false,
      "id_str" : "20650366",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/743248377563971584\/9d9xlHlz_normal.jpg",
      "id" : 20650366,
      "verified" : false
    }
  },
  "id" : 275526366257086464,
  "created_at" : "2012-12-03 09:06:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nikki Fortova",
      "screen_name" : "NikkiFortova",
      "indices" : [ 0, 13 ],
      "id_str" : "35838394",
      "id" : 35838394
    }, {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 27, 38 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/d8O5gbxj",
      "expanded_url" : "http:\/\/leoxicon.blogspot.co.uk\/p\/essential-lexical-tools.html",
      "display_url" : "leoxicon.blogspot.co.uk\/p\/essential-le\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "275511730837258240",
  "geo" : { },
  "id_str" : "275525729893105665",
  "in_reply_to_user_id" : 35838394,
  "text" : "@NikkiFortova have us seen @leoselivan list of tools? http:\/\/t.co\/d8O5gbxj, i find just-the-word good for sts, though site uptime varies",
  "id" : 275525729893105665,
  "in_reply_to_status_id" : 275511730837258240,
  "created_at" : "2012-12-03 09:03:47 +0000",
  "in_reply_to_screen_name" : "NikkiFortova",
  "in_reply_to_user_id_str" : "35838394",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blair Teacher",
      "screen_name" : "blairteacher",
      "indices" : [ 3, 16 ],
      "id_str" : "20932918",
      "id" : 20932918
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/b72YdAjS",
      "expanded_url" : "http:\/\/www.guardian.co.uk\/books\/2012\/dec\/02\/science-writing-debate-pinker-gleick-greene-frank-foer",
      "display_url" : "guardian.co.uk\/books\/2012\/dec\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "275328519427469312",
  "text" : "RT @blairteacher: Science writing: how do you make complex issues accessible and readable? http:\/\/t.co\/b72YdAjS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 93 ],
        "url" : "http:\/\/t.co\/b72YdAjS",
        "expanded_url" : "http:\/\/www.guardian.co.uk\/books\/2012\/dec\/02\/science-writing-debate-pinker-gleick-greene-frank-foer",
        "display_url" : "guardian.co.uk\/books\/2012\/dec\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "275327922494111744",
    "text" : "Science writing: how do you make complex issues accessible and readable? http:\/\/t.co\/b72YdAjS",
    "id" : 275327922494111744,
    "created_at" : "2012-12-02 19:57:46 +0000",
    "user" : {
      "name" : "Blair Teacher",
      "screen_name" : "blairteacher",
      "protected" : false,
      "id_str" : "20932918",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/473405104729493504\/mK908m7N_normal.jpeg",
      "id" : 20932918,
      "verified" : false
    }
  },
  "id" : 275328519427469312,
  "created_at" : "2012-12-02 20:00:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/7nyW42Gk",
      "expanded_url" : "http:\/\/www.bbc.co.uk\/news\/uk-20563871",
      "display_url" : "bbc.co.uk\/news\/uk-205638\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "275280886474358784",
  "text" : "http:\/\/t.co\/7nyW42Gk Julian Assange BBC state broadcaster interview",
  "id" : 275280886474358784,
  "created_at" : "2012-12-02 16:50:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/I7UlY39q",
      "expanded_url" : "http:\/\/www.guardian.co.uk\/world\/2012\/nov\/30\/footballers-u21-european-championship-israel",
      "display_url" : "guardian.co.uk\/world\/2012\/nov\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "274861543999557632",
  "text" : "Footballers condemn plans to hold U21 European championship in Israel http:\/\/t.co\/I7UlY39q",
  "id" : 274861543999557632,
  "created_at" : "2012-12-01 13:04:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Petrie",
      "screen_name" : "teflgeek",
      "indices" : [ 3, 12 ],
      "id_str" : "305260555",
      "id" : 305260555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/2JybbwEg",
      "expanded_url" : "http:\/\/wp.me\/p1kzD1-yz",
      "display_url" : "wp.me\/p1kzD1-yz"
    } ]
  },
  "geo" : { },
  "id_str" : "274839209150382080",
  "text" : "RT @teflgeek: Research Papers from \"Language Teaching\" http:\/\/t.co\/2JybbwEg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 61 ],
        "url" : "http:\/\/t.co\/2JybbwEg",
        "expanded_url" : "http:\/\/wp.me\/p1kzD1-yz",
        "display_url" : "wp.me\/p1kzD1-yz"
      } ]
    },
    "geo" : { },
    "id_str" : "274834432630857729",
    "text" : "Research Papers from \"Language Teaching\" http:\/\/t.co\/2JybbwEg",
    "id" : 274834432630857729,
    "created_at" : "2012-12-01 11:16:49 +0000",
    "user" : {
      "name" : "David Petrie",
      "screen_name" : "teflgeek",
      "protected" : false,
      "id_str" : "305260555",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/431754836795613184\/0uiw9Mhs_normal.jpeg",
      "id" : 305260555,
      "verified" : false
    }
  },
  "id" : 274839209150382080,
  "created_at" : "2012-12-01 11:35:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stevemuir",
      "screen_name" : "steve_muir",
      "indices" : [ 0, 11 ],
      "id_str" : "18537988",
      "id" : 18537988
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "274819388551593984",
  "geo" : { },
  "id_str" : "274839000697696256",
  "in_reply_to_user_id" : 18537988,
  "text" : "@steve_muir many thanks steve, just updated post with ex sts recording, chuffed to get a recc from master of video activities :)",
  "id" : 274839000697696256,
  "in_reply_to_status_id" : 274819388551593984,
  "created_at" : "2012-12-01 11:34:58 +0000",
  "in_reply_to_screen_name" : "steve_muir",
  "in_reply_to_user_id_str" : "18537988",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/JB7xHc4c",
      "expanded_url" : "http:\/\/www.newint.org\/blog\/2012\/11\/30\/facebook-tax-boycott\/",
      "display_url" : "newint.org\/blog\/2012\/11\/3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "274807027597967361",
  "text" : "http:\/\/t.co\/JB7xHc4c &lt;-Facebook tax dodgers wondr any data on Twitter tax dealing?",
  "id" : 274807027597967361,
  "created_at" : "2012-12-01 09:27:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chia Suan Chong",
      "screen_name" : "chiasuan",
      "indices" : [ 0, 9 ],
      "id_str" : "71588589",
      "id" : 71588589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "274805976643805184",
  "in_reply_to_user_id" : 71588589,
  "text" : "@chiasuan hi managed to miss yr talk for a 2nd time! heard it went brilliantly. is it available online to watch?",
  "id" : 274805976643805184,
  "created_at" : "2012-12-01 09:23:45 +0000",
  "in_reply_to_screen_name" : "chiasuan",
  "in_reply_to_user_id_str" : "71588589",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "274797908254158848",
  "geo" : { },
  "id_str" : "274805024679399425",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow nice one, hoping we europeans can catch your presentations\/workshops sometime :)",
  "id" : 274805024679399425,
  "in_reply_to_status_id" : 274797908254158848,
  "created_at" : "2012-12-01 09:19:58 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "274802659125493760",
  "text" : "@EBEFL is it a version of gangnam style? we must be told? ;)",
  "id" : 274802659125493760,
  "created_at" : "2012-12-01 09:10:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
} ]