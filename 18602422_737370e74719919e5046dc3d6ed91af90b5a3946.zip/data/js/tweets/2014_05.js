Grailbird.data.tweets_2014_05 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "472799685015793664",
  "geo" : { },
  "id_str" : "472814341612646400",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco nice, imagine it was in the sun as well? :)  can we look fwd to any write-ups?",
  "id" : 472814341612646400,
  "in_reply_to_status_id" : 472799685015793664,
  "created_at" : "2014-05-31 18:58:18 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "radioexplorer",
      "indices" : [ 23, 37 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 93, 101 ]
    }, {
      "text" : "listening",
      "indices" : [ 102, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/o0e86XA3Y8",
      "expanded_url" : "http:\/\/www.bbc.co.uk\/radio\/explorer\/",
      "display_url" : "bbc.co.uk\/radio\/explorer\/"
    } ]
  },
  "geo" : { },
  "id_str" : "472731141485887488",
  "text" : "although search on BBC #radioexplorer is very basic still very useful http:\/\/t.co\/o0e86XA3Y8 #eltchat #listening",
  "id" : 472731141485887488,
  "created_at" : "2014-05-31 13:27:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KBarrs",
      "screen_name" : "corpusloanword",
      "indices" : [ 0, 15 ],
      "id_str" : "95419070",
      "id" : 95419070
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "472542992163545090",
  "geo" : { },
  "id_str" : "472714178747453440",
  "in_reply_to_user_id" : 95419070,
  "text" : "@corpusloanword hi, will u be doing any writeups of talks?",
  "id" : 472714178747453440,
  "in_reply_to_status_id" : 472542992163545090,
  "created_at" : "2014-05-31 12:20:17 +0000",
  "in_reply_to_screen_name" : "corpusloanword",
  "in_reply_to_user_id_str" : "95419070",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Sample",
      "screen_name" : "samplereality",
      "indices" : [ 3, 17 ],
      "id_str" : "8497292",
      "id" : 8497292
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "https:\/\/t.co\/D6LCKohjYn",
      "expanded_url" : "https:\/\/medium.com\/@samplereality\/a-protest-bot-is-a-bot-so-specific-you-cant-mistake-it-for-bullshit-90fe10b7fbaa",
      "display_url" : "medium.com\/@samplereality\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "472713351773302784",
  "text" : "RT @samplereality: A protest bot is a bot so specific you can\u2019t mistake it for bullshit: A call for bots of conviction: https:\/\/t.co\/D6LCKo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.metrotwit.com\/\" rel=\"nofollow\"\u003EMetroTwit\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/D6LCKohjYn",
        "expanded_url" : "https:\/\/medium.com\/@samplereality\/a-protest-bot-is-a-bot-so-specific-you-cant-mistake-it-for-bullshit-90fe10b7fbaa",
        "display_url" : "medium.com\/@samplereality\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "472409875885359104",
    "text" : "A protest bot is a bot so specific you can\u2019t mistake it for bullshit: A call for bots of conviction: https:\/\/t.co\/D6LCKohjYn",
    "id" : 472409875885359104,
    "created_at" : "2014-05-30 16:11:06 +0000",
    "user" : {
      "name" : "Mark Sample",
      "screen_name" : "samplereality",
      "protected" : false,
      "id_str" : "8497292",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000707852410\/a86167716ecb748acc89638ad165a162_normal.jpeg",
      "id" : 8497292,
      "verified" : false
    }
  },
  "id" : 472713351773302784,
  "created_at" : "2014-05-31 12:17:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allison Parrish",
      "screen_name" : "aparrish",
      "indices" : [ 84, 93 ],
      "id_str" : "6857962",
      "id" : 6857962
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 94, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/oRoCcCbOJE",
      "expanded_url" : "http:\/\/www.rewordable.com\/",
      "display_url" : "rewordable.com"
    } ]
  },
  "geo" : { },
  "id_str" : "472656892108742656",
  "text" : "looking for a word game for class why not try rewordable? http:\/\/t.co\/oRoCcCbOJE by @aparrish #eltchat",
  "id" : 472656892108742656,
  "created_at" : "2014-05-31 08:32:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media UK (old a\/c)",
      "screen_name" : "mediauk",
      "indices" : [ 76, 84 ],
      "id_str" : "5752672",
      "id" : 5752672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/A7TID4kdYX",
      "expanded_url" : "http:\/\/www.mediauk.com\/article\/34502\/bbc-radio-explorer-a-new-way-to-listen-to-radio",
      "display_url" : "mediauk.com\/article\/34502\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "472643278764916736",
  "text" : "BBC Radio Explorer: a new way to listen to radio http:\/\/t.co\/A7TID4kdYX via @mediauk",
  "id" : 472643278764916736,
  "created_at" : "2014-05-31 07:38:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 3, 18 ],
      "id_str" : "285614027",
      "id" : 285614027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/EQOVcj9hCN",
      "expanded_url" : "http:\/\/ift.tt\/1kPib6u",
      "display_url" : "ift.tt\/1kPib6u"
    } ]
  },
  "geo" : { },
  "id_str" : "472470342435614720",
  "text" : "RT @AnthonyTeacher: Am I Really Helping Students Become More Autonomous? http:\/\/t.co\/EQOVcj9hCN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 75 ],
        "url" : "http:\/\/t.co\/EQOVcj9hCN",
        "expanded_url" : "http:\/\/ift.tt\/1kPib6u",
        "display_url" : "ift.tt\/1kPib6u"
      } ]
    },
    "geo" : { },
    "id_str" : "472169205891342336",
    "text" : "Am I Really Helping Students Become More Autonomous? http:\/\/t.co\/EQOVcj9hCN",
    "id" : 472169205891342336,
    "created_at" : "2014-05-30 00:14:45 +0000",
    "user" : {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "protected" : false,
      "id_str" : "285614027",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/412336845658132481\/Om5kKuMQ_normal.jpeg",
      "id" : 285614027,
      "verified" : false
    }
  },
  "id" : 472470342435614720,
  "created_at" : "2014-05-30 20:11:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "indices" : [ 3, 14 ],
      "id_str" : "152051625",
      "id" : 152051625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/nleWHXqgoS",
      "expanded_url" : "http:\/\/bit.ly\/SjmDQi",
      "display_url" : "bit.ly\/SjmDQi"
    } ]
  },
  "geo" : { },
  "id_str" : "472446720442658817",
  "text" : "RT @heatherfro: ah yes, our favorite test and our favorite show: Does Dr Who diachronically pass the Bechdel test? http:\/\/t.co\/nleWHXqgoS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/nleWHXqgoS",
        "expanded_url" : "http:\/\/bit.ly\/SjmDQi",
        "display_url" : "bit.ly\/SjmDQi"
      } ]
    },
    "geo" : { },
    "id_str" : "472438639478452224",
    "text" : "ah yes, our favorite test and our favorite show: Does Dr Who diachronically pass the Bechdel test? http:\/\/t.co\/nleWHXqgoS",
    "id" : 472438639478452224,
    "created_at" : "2014-05-30 18:05:23 +0000",
    "user" : {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "protected" : false,
      "id_str" : "152051625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/688767277022494720\/KMrzOBc1_normal.jpg",
      "id" : 152051625,
      "verified" : false
    }
  },
  "id" : 472446720442658817,
  "created_at" : "2014-05-30 18:37:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth Anne",
      "screen_name" : "eannegrenoble",
      "indices" : [ 3, 17 ],
      "id_str" : "19869781",
      "id" : 19869781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/jbCMlP27au",
      "expanded_url" : "https:\/\/present.me\/view\/65217-c-is-for-corpus",
      "display_url" : "present.me\/view\/65217-c-i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "472110620478021633",
  "text" : "RT @eannegrenoble: Better with the link ! https:\/\/t.co\/jbCMlP27au 12 min intro to using COCA on the BYU site",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 23, 46 ],
        "url" : "https:\/\/t.co\/jbCMlP27au",
        "expanded_url" : "https:\/\/present.me\/view\/65217-c-is-for-corpus",
        "display_url" : "present.me\/view\/65217-c-i\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "471990667531808768",
    "geo" : { },
    "id_str" : "472069786714005504",
    "in_reply_to_user_id" : 19869781,
    "text" : "Better with the link ! https:\/\/t.co\/jbCMlP27au 12 min intro to using COCA on the BYU site",
    "id" : 472069786714005504,
    "in_reply_to_status_id" : 471990667531808768,
    "created_at" : "2014-05-29 17:39:42 +0000",
    "in_reply_to_screen_name" : "eannegrenoble",
    "in_reply_to_user_id_str" : "19869781",
    "user" : {
      "name" : "Elizabeth Anne",
      "screen_name" : "eannegrenoble",
      "protected" : false,
      "id_str" : "19869781",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/486151060419907584\/DQRq7qOi_normal.jpeg",
      "id" : 19869781,
      "verified" : false
    }
  },
  "id" : 472110620478021633,
  "created_at" : "2014-05-29 20:21:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 3, 14 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 109, 113 ]
    }, {
      "text" : "tefl",
      "indices" : [ 114, 119 ]
    }, {
      "text" : "tesol",
      "indices" : [ 120, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 127, 140 ],
      "url" : "http:\/\/t.co\/7Z587adn9n",
      "expanded_url" : "http:\/\/bit.ly\/RG6GTt",
      "display_url" : "bit.ly\/RG6GTt"
    } ]
  },
  "geo" : { },
  "id_str" : "472063329998233600",
  "text" : "RT @tornhalves: Our meditation on the complicity of ELT in the international unpleasantness of globalization #elt #tefl #tesol http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "elt",
        "indices" : [ 93, 97 ]
      }, {
        "text" : "tefl",
        "indices" : [ 98, 103 ]
      }, {
        "text" : "tesol",
        "indices" : [ 104, 110 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/7Z587adn9n",
        "expanded_url" : "http:\/\/bit.ly\/RG6GTt",
        "display_url" : "bit.ly\/RG6GTt"
      } ]
    },
    "geo" : { },
    "id_str" : "472044614376251394",
    "text" : "Our meditation on the complicity of ELT in the international unpleasantness of globalization #elt #tefl #tesol http:\/\/t.co\/7Z587adn9n",
    "id" : 472044614376251394,
    "created_at" : "2014-05-29 15:59:40 +0000",
    "user" : {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "protected" : false,
      "id_str" : "87902543",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3059742703\/1d3c7a2052db17d29644fa0a49af6480_normal.jpeg",
      "id" : 87902543,
      "verified" : false
    }
  },
  "id" : 472063329998233600,
  "created_at" : "2014-05-29 17:14:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BELTA Belgium",
      "screen_name" : "BELTABelgium",
      "indices" : [ 3, 16 ],
      "id_str" : "884934438",
      "id" : 884934438
    }, {
      "name" : "BELTA Belgium",
      "screen_name" : "BELTABelgium",
      "indices" : [ 44, 57 ],
      "id_str" : "884934438",
      "id" : 884934438
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 140 ],
      "url" : "http:\/\/t.co\/oQ1uve1Cdx",
      "expanded_url" : "http:\/\/ow.ly\/xk9Ok",
      "display_url" : "ow.ly\/xk9Ok"
    } ]
  },
  "geo" : { },
  "id_str" : "471976843315535873",
  "text" : "RT @BELTABelgium: Announcing the first ever @BELTABelgium and TESL Toronto joint online conference - we need presenters! http:\/\/t.co\/oQ1uve\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BELTA Belgium",
        "screen_name" : "BELTABelgium",
        "indices" : [ 26, 39 ],
        "id_str" : "884934438",
        "id" : 884934438
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "eltchat",
        "indices" : [ 126, 134 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/oQ1uve1Cdx",
        "expanded_url" : "http:\/\/ow.ly\/xk9Ok",
        "display_url" : "ow.ly\/xk9Ok"
      } ]
    },
    "geo" : { },
    "id_str" : "471954247123501056",
    "text" : "Announcing the first ever @BELTABelgium and TESL Toronto joint online conference - we need presenters! http:\/\/t.co\/oQ1uve1Cdx #eltchat",
    "id" : 471954247123501056,
    "created_at" : "2014-05-29 10:00:35 +0000",
    "user" : {
      "name" : "BELTA Belgium",
      "screen_name" : "BELTABelgium",
      "protected" : false,
      "id_str" : "884934438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3130800745\/d36391a9857692e6c2aab76d0033ade0_normal.png",
      "id" : 884934438,
      "verified" : false
    }
  },
  "id" : 471976843315535873,
  "created_at" : "2014-05-29 11:30:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UCRELResearchCentre",
      "screen_name" : "UCREL_Lancaster",
      "indices" : [ 3, 19 ],
      "id_str" : "1423596631",
      "id" : 1423596631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/O7Wy3x35hR",
      "expanded_url" : "http:\/\/ucrel.lancs.ac.uk\/talc2014",
      "display_url" : "ucrel.lancs.ac.uk\/talc2014"
    } ]
  },
  "geo" : { },
  "id_str" : "471976736096518145",
  "text" : "RT @UCREL_Lancaster: 11th Teaching and Language Corpora Conference, 2014 (TaLC 11) July 20-24  http:\/\/t.co\/O7Wy3x35hR Registration open unt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/O7Wy3x35hR",
        "expanded_url" : "http:\/\/ucrel.lancs.ac.uk\/talc2014",
        "display_url" : "ucrel.lancs.ac.uk\/talc2014"
      } ]
    },
    "geo" : { },
    "id_str" : "471957028613931008",
    "text" : "11th Teaching and Language Corpora Conference, 2014 (TaLC 11) July 20-24  http:\/\/t.co\/O7Wy3x35hR Registration open until June 29.",
    "id" : 471957028613931008,
    "created_at" : "2014-05-29 10:11:38 +0000",
    "user" : {
      "name" : "UCRELResearchCentre",
      "screen_name" : "UCREL_Lancaster",
      "protected" : false,
      "id_str" : "1423596631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3651470503\/879f06f9a62c1fa2c41a427843506859_normal.png",
      "id" : 1423596631,
      "verified" : false
    }
  },
  "id" : 471976736096518145,
  "created_at" : "2014-05-29 11:29:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 109, 125 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/u06Jo0rqOh",
      "expanded_url" : "http:\/\/wp.me\/pjaNC-16L",
      "display_url" : "wp.me\/pjaNC-16L"
    } ]
  },
  "geo" : { },
  "id_str" : "471716798207762432",
  "text" : "How to Learn Collocations: Independence from Teachers and Dependence on Resources http:\/\/t.co\/u06Jo0rqOh via @wordpressdotcom",
  "id" : 471716798207762432,
  "created_at" : "2014-05-28 18:17:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Magnus Nissel",
      "screen_name" : "u203d",
      "indices" : [ 0, 6 ],
      "id_str" : "533114985",
      "id" : 533114985
    }, {
      "name" : "Noor Adnan",
      "screen_name" : "n00rbaizura",
      "indices" : [ 7, 19 ],
      "id_str" : "412094121",
      "id" : 412094121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/Y5WNZUqmDy",
      "expanded_url" : "http:\/\/elfaproject.wordpress.com\/2013\/06\/30\/in-defense-of-good-data-the-question-of-third-person-singular-s\/",
      "display_url" : "elfaproject.wordpress.com\/2013\/06\/30\/in-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "471227538975780865",
  "geo" : { },
  "id_str" : "471289084774977536",
  "in_reply_to_user_id" : 533114985,
  "text" : "@u203d @n00rbaizura useful ex to study of code processing xml in python elfablog posts some e:g: http:\/\/t.co\/Y5WNZUqmDy",
  "id" : 471289084774977536,
  "in_reply_to_status_id" : 471227538975780865,
  "created_at" : "2014-05-27 13:57:28 +0000",
  "in_reply_to_screen_name" : "u203d",
  "in_reply_to_user_id_str" : "533114985",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "indices" : [ 0, 12 ],
      "id_str" : "192437743",
      "id" : 192437743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "471054670765379584",
  "geo" : { },
  "id_str" : "471057685002350592",
  "in_reply_to_user_id" : 192437743,
  "text" : "@nathanghall thanks for the summaries :)",
  "id" : 471057685002350592,
  "in_reply_to_status_id" : 471054670765379584,
  "created_at" : "2014-05-26 22:37:58 +0000",
  "in_reply_to_screen_name" : "nathanghall",
  "in_reply_to_user_id_str" : "192437743",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Taylor",
      "screen_name" : "theteacherjames",
      "indices" : [ 33, 49 ],
      "id_str" : "71746265",
      "id" : 71746265
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 28 ],
      "url" : "http:\/\/t.co\/RUrrHOn2tR",
      "expanded_url" : "http:\/\/wp.me\/s2gBMI-voice",
      "display_url" : "wp.me\/s2gBMI-voice"
    } ]
  },
  "geo" : { },
  "id_str" : "471057658791743488",
  "text" : "Voice http:\/\/t.co\/RUrrHOn2tR via @theteacherjames",
  "id" : 471057658791743488,
  "created_at" : "2014-05-26 22:37:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "indices" : [ 36, 48 ],
      "id_str" : "192437743",
      "id" : 192437743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/kCyaJfjOnO",
      "expanded_url" : "http:\/\/wp.me\/s3xFPk-building",
      "display_url" : "wp.me\/s3xFPk-building"
    } ]
  },
  "geo" : { },
  "id_str" : "471054087954235392",
  "text" : "Building http:\/\/t.co\/kCyaJfjOnO via @nathanghall",
  "id" : 471054087954235392,
  "created_at" : "2014-05-26 22:23:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pando",
      "screen_name" : "PandoDaily",
      "indices" : [ 120, 131 ],
      "id_str" : "419710142",
      "id" : 419710142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/UcdTjiIoCe",
      "expanded_url" : "http:\/\/pando.com\/2014\/05\/26\/revealed-the-head-of-omidyar-networks-in-india-had-a-secret-second-job-helping-elect-narendra-modi\/",
      "display_url" : "pando.com\/2014\/05\/26\/rev\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "471031174391795712",
  "text" : "The head of Omidyar Networks in India had a secret second job... Helping elect Narendra Modi http:\/\/t.co\/UcdTjiIoCe via @pandodaily",
  "id" : 471031174391795712,
  "created_at" : "2014-05-26 20:52:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/hpDdxtwpRz",
      "expanded_url" : "http:\/\/perezparedes.blogspot.com\/2014\/05\/enhancing-and-extending-corpora-and.html",
      "display_url" : "perezparedes.blogspot.com\/2014\/05\/enhanc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "470972851374149632",
  "text" : "Enhancing and extending corpora and corpora tools for learning and teaching http:\/\/t.co\/hpDdxtwpRz",
  "id" : 470972851374149632,
  "created_at" : "2014-05-26 17:00:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Moore",
      "screen_name" : "lexicojules",
      "indices" : [ 3, 15 ],
      "id_str" : "424320799",
      "id" : 424320799
    }, {
      "name" : "Oxford ELT",
      "screen_name" : "OUPELTGlobal",
      "indices" : [ 137, 140 ],
      "id_str" : "74177226",
      "id" : 74177226
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tleap",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/45qflsjAFa",
      "expanded_url" : "http:\/\/ow.ly\/xgvQJ",
      "display_url" : "ow.ly\/xgvQJ"
    } ]
  },
  "geo" : { },
  "id_str" : "470972067660447744",
  "text" : "RT @lexicojules: EAP: A PARSNIP-free zone? A taster of my session at London South Bank Uni EAP event next weekend http:\/\/t.co\/45qflsjAFa @O\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Oxford ELT",
        "screen_name" : "OUPELTGlobal",
        "indices" : [ 120, 133 ],
        "id_str" : "74177226",
        "id" : 74177226
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tleap",
        "indices" : [ 134, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/45qflsjAFa",
        "expanded_url" : "http:\/\/ow.ly\/xgvQJ",
        "display_url" : "ow.ly\/xgvQJ"
      } ]
    },
    "geo" : { },
    "id_str" : "470955011036684288",
    "text" : "EAP: A PARSNIP-free zone? A taster of my session at London South Bank Uni EAP event next weekend http:\/\/t.co\/45qflsjAFa @OUPELTGlobal #tleap",
    "id" : 470955011036684288,
    "created_at" : "2014-05-26 15:49:59 +0000",
    "user" : {
      "name" : "Julie Moore",
      "screen_name" : "lexicojules",
      "protected" : false,
      "id_str" : "424320799",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/478823971870109696\/AzIax4m3_normal.jpeg",
      "id" : 424320799,
      "verified" : false
    }
  },
  "id" : 470972067660447744,
  "created_at" : "2014-05-26 16:57:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bella Caledonia",
      "screen_name" : "bellacaledonia",
      "indices" : [ 73, 88 ],
      "id_str" : "103554348",
      "id" : 103554348
    }, {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 93, 105 ],
      "id_str" : "223771625",
      "id" : 223771625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/yM41ZlcMY5",
      "expanded_url" : "http:\/\/wp.me\/p93oK-3MM",
      "display_url" : "wp.me\/p93oK-3MM"
    } ]
  },
  "geo" : { },
  "id_str" : "470842513708695552",
  "text" : "Why You Should Support Scottish Independence  http:\/\/t.co\/yM41ZlcMY5 via @bellacaledonia h\/t @johnwhilley",
  "id" : 470842513708695552,
  "created_at" : "2014-05-26 08:22:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ana\u00EFs Hamayon",
      "screen_name" : "AnaisHamayon",
      "indices" : [ 3, 16 ],
      "id_str" : "2218674660",
      "id" : 2218674660
    }, {
      "name" : "peter franklin",
      "screen_name" : "peterfranklin",
      "indices" : [ 40, 54 ],
      "id_str" : "140925110",
      "id" : 140925110
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EP2014",
      "indices" : [ 134, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "470645968787230720",
  "text" : "RT @AnaisHamayon: Aouch, that hurts: RT @peterfranklin France's Eurovision song was about wanting a moustache - now we know what kind #EP20\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "peter franklin",
        "screen_name" : "peterfranklin",
        "indices" : [ 22, 36 ],
        "id_str" : "140925110",
        "id" : 140925110
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EP2014",
        "indices" : [ 116, 123 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "470643076881711104",
    "text" : "Aouch, that hurts: RT @peterfranklin France's Eurovision song was about wanting a moustache - now we know what kind #EP2014",
    "id" : 470643076881711104,
    "created_at" : "2014-05-25 19:10:28 +0000",
    "user" : {
      "name" : "Ana\u00EFs Hamayon",
      "screen_name" : "AnaisHamayon",
      "protected" : false,
      "id_str" : "2218674660",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000799870622\/8312f92a938d0a15ba3b3c5b6ae04e17_normal.jpeg",
      "id" : 2218674660,
      "verified" : false
    }
  },
  "id" : 470645968787230720,
  "created_at" : "2014-05-25 19:21:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StartJOIN",
      "screen_name" : "StartJOIN",
      "indices" : [ 57, 67 ],
      "id_str" : "1951038848",
      "id" : 1951038848
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/4eJTf8fLQB",
      "expanded_url" : "http:\/\/startjo.in\/NHS_SellOff",
      "display_url" : "startjo.in\/NHS_SellOff"
    } ]
  },
  "geo" : { },
  "id_str" : "470599021120065536",
  "text" : "I just supported Sell-Off - The Abolition of Your NHS on @StartJOIN http:\/\/t.co\/4eJTf8fLQB",
  "id" : 470599021120065536,
  "created_at" : "2014-05-25 16:15:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Edwards",
      "screen_name" : "EdLaur",
      "indices" : [ 83, 90 ],
      "id_str" : "1834826917",
      "id" : 1834826917
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/IM862ZvDPr",
      "expanded_url" : "http:\/\/grownupenglish.com\/facebook-groups-uni\/",
      "display_url" : "grownupenglish.com\/facebook-group\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "470208860393721857",
  "text" : "Facebook Groups at University. (Presentation- EAP2014) http:\/\/t.co\/IM862ZvDPr via @@EdLaur",
  "id" : 470208860393721857,
  "created_at" : "2014-05-24 14:25:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Adele Soracco",
      "screen_name" : "LauraSoracco",
      "indices" : [ 3, 16 ],
      "id_str" : "15663328",
      "id" : 15663328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "470206452444172288",
  "text" : "RT @LauraSoracco: Need advice for a friend thinking about moving to France to teach ESOL. What are good cities considering cost of living?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "470172791854350336",
    "text" : "Need advice for a friend thinking about moving to France to teach ESOL. What are good cities considering cost of living?",
    "id" : 470172791854350336,
    "created_at" : "2014-05-24 12:01:43 +0000",
    "user" : {
      "name" : "Laura Adele Soracco",
      "screen_name" : "LauraSoracco",
      "protected" : false,
      "id_str" : "15663328",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766919326427254785\/4J5Q1zgQ_normal.jpg",
      "id" : 15663328,
      "verified" : false
    }
  },
  "id" : 470206452444172288,
  "created_at" : "2014-05-24 14:15:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hana Tich\u00E1",
      "screen_name" : "HanaTicha",
      "indices" : [ 0, 10 ],
      "id_str" : "512296705",
      "id" : 512296705
    }, {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 11, 23 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/qQffe2A4cS",
      "expanded_url" : "http:\/\/www.theguardian.com\/education\/2004\/jan\/29\/tefl",
      "display_url" : "theguardian.com\/education\/2004\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "470116908269076480",
  "geo" : { },
  "id_str" : "470118560350892032",
  "in_reply_to_user_id" : 512296705,
  "text" : "@HanaTicha @AnneHendler luke meddings did a response http:\/\/t.co\/qQffe2A4cS",
  "id" : 470118560350892032,
  "in_reply_to_status_id" : 470116908269076480,
  "created_at" : "2014-05-24 08:26:13 +0000",
  "in_reply_to_screen_name" : "HanaTicha",
  "in_reply_to_user_id_str" : "512296705",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George Chilton",
      "screen_name" : "designerlessons",
      "indices" : [ 0, 16 ],
      "id_str" : "432090149",
      "id" : 432090149
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "469870697930817536",
  "geo" : { },
  "id_str" : "469874938535739392",
  "in_reply_to_user_id" : 432090149,
  "text" : "@designerlessons cheers george :) have a great w\/e",
  "id" : 469874938535739392,
  "in_reply_to_status_id" : 469870697930817536,
  "created_at" : "2014-05-23 16:18:09 +0000",
  "in_reply_to_screen_name" : "designerlessons",
  "in_reply_to_user_id_str" : "432090149",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "piratebox",
      "indices" : [ 0, 10 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/ltWad9TtAC",
      "expanded_url" : "https:\/\/play.google.com\/store\/apps\/details?id=de.fun2code.android.piratebox",
      "display_url" : "play.google.com\/store\/apps\/det\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "469857855458119680",
  "text" : "#piratebox for android now available on Google Play https:\/\/t.co\/ltWad9TtAC",
  "id" : 469857855458119680,
  "created_at" : "2014-05-23 15:10:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "indices" : [ 0, 12 ],
      "id_str" : "192437743",
      "id" : 192437743
    }, {
      "name" : "Ela Wassell",
      "screen_name" : "elawassell",
      "indices" : [ 13, 24 ],
      "id_str" : "51157050",
      "id" : 51157050
    }, {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 25, 41 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/Oqrta6xhNJ",
      "expanded_url" : "http:\/\/eflnotes.wordpress.com\/elt-research-open-access-repositories-and-directories\/",
      "display_url" : "eflnotes.wordpress.com\/elt-research-o\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "469728279394779136",
  "geo" : { },
  "id_str" : "469750889218318337",
  "in_reply_to_user_id" : 192437743,
  "text" : "@nathanghall @elawassell @michaelegriffin have a list here for (mostly) open access articles http:\/\/t.co\/Oqrta6xhNJ",
  "id" : 469750889218318337,
  "in_reply_to_status_id" : 469728279394779136,
  "created_at" : "2014-05-23 08:05:14 +0000",
  "in_reply_to_screen_name" : "nathanghall",
  "in_reply_to_user_id_str" : "192437743",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eily Murphy",
      "screen_name" : "eilymurphy",
      "indices" : [ 3, 14 ],
      "id_str" : "111091623",
      "id" : 111091623
    }, {
      "name" : "John Chrimes",
      "screen_name" : "ELTwriter",
      "indices" : [ 19, 29 ],
      "id_str" : "2464809235",
      "id" : 2464809235
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/MwCvYfSZGS",
      "expanded_url" : "http:\/\/vocabkitchen.com\/CEFR_Profiler.aspx",
      "display_url" : "vocabkitchen.com\/CEFR_Profiler.\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "469592917917855744",
  "text" : "RT @eilymurphy: RT @ELTwriter: Text to vocab by CEFR levels - have U tried  Vocab Kitchen: CEFR Profiler tab ?http:\/\/t.co\/MwCvYfSZGS for AW\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Chrimes",
        "screen_name" : "ELTwriter",
        "indices" : [ 3, 13 ],
        "id_str" : "2464809235",
        "id" : 2464809235
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/MwCvYfSZGS",
        "expanded_url" : "http:\/\/vocabkitchen.com\/CEFR_Profiler.aspx",
        "display_url" : "vocabkitchen.com\/CEFR_Profiler.\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "469576034854400000",
    "text" : "RT @ELTwriter: Text to vocab by CEFR levels - have U tried  Vocab Kitchen: CEFR Profiler tab ?http:\/\/t.co\/MwCvYfSZGS for AWL highlighter?",
    "id" : 469576034854400000,
    "created_at" : "2014-05-22 20:30:25 +0000",
    "user" : {
      "name" : "Eily Murphy",
      "screen_name" : "eilymurphy",
      "protected" : false,
      "id_str" : "111091623",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746422529405894656\/gSFQlPqA_normal.jpg",
      "id" : 111091623,
      "verified" : false
    }
  },
  "id" : 469592917917855744,
  "created_at" : "2014-05-22 21:37:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Douglas Carnall",
      "screen_name" : "JuliuzBeezer",
      "indices" : [ 3, 16 ],
      "id_str" : "25936824",
      "id" : 25936824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/kYaNVk1Moy",
      "expanded_url" : "http:\/\/youtu.be\/YVwbxp1FyiE",
      "display_url" : "youtu.be\/YVwbxp1FyiE"
    } ]
  },
  "geo" : { },
  "id_str" : "469463092070715392",
  "text" : "RT @JuliuzBeezer: Les pires habitudes vocales des Fran\u00E7ais: http:\/\/t.co\/kYaNVk1Moy \u00C0 la fois pr\u00E9cis et amusant.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/kYaNVk1Moy",
        "expanded_url" : "http:\/\/youtu.be\/YVwbxp1FyiE",
        "display_url" : "youtu.be\/YVwbxp1FyiE"
      } ]
    },
    "geo" : { },
    "id_str" : "469442020797198337",
    "text" : "Les pires habitudes vocales des Fran\u00E7ais: http:\/\/t.co\/kYaNVk1Moy \u00C0 la fois pr\u00E9cis et amusant.",
    "id" : 469442020797198337,
    "created_at" : "2014-05-22 11:37:54 +0000",
    "user" : {
      "name" : "Douglas Carnall",
      "screen_name" : "JuliuzBeezer",
      "protected" : false,
      "id_str" : "25936824",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/114211651\/robert_burns247x165_normal.jpg",
      "id" : 25936824,
      "verified" : false
    }
  },
  "id" : 469463092070715392,
  "created_at" : "2014-05-22 13:01:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpuslinguistics",
      "indices" : [ 67, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/nXOmqRb76Q",
      "expanded_url" : "http:\/\/tm.durusau.net\/?p=53251",
      "display_url" : "tm.durusau.net\/?p=53251"
    } ]
  },
  "geo" : { },
  "id_str" : "469406564190023680",
  "text" : "Corpus-based Empirical Software Engineering http:\/\/t.co\/nXOmqRb76Q #corpuslinguistics",
  "id" : 469406564190023680,
  "created_at" : "2014-05-22 09:17:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Levine",
      "screen_name" : "cogdog",
      "indices" : [ 3, 10 ],
      "id_str" : "740343",
      "id" : 740343
    }, {
      "name" : "Laura Hilliger",
      "screen_name" : "epilepticrabbit",
      "indices" : [ 85, 101 ],
      "id_str" : "212475110",
      "id" : 212475110
    }, {
      "name" : "Mozilla Webmaker",
      "screen_name" : "Webmaker",
      "indices" : [ 102, 111 ],
      "id_str" : "1242429835",
      "id" : 1242429835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/KQfSnzymHq",
      "expanded_url" : "http:\/\/wp.me\/pf0PM-7U9",
      "display_url" : "wp.me\/pf0PM-7U9"
    } ]
  },
  "geo" : { },
  "id_str" : "469404251421442048",
  "text" : "RT @cogdog: CogDogBlogged: Image Seek: A Mozilla Thimble Make http:\/\/t.co\/KQfSnzymHq @epilepticrabbit @webmaker",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sopresto.mailchimp.com\" rel=\"nofollow\"\u003ESocial Proxy by Mailchimp\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Laura Hilliger",
        "screen_name" : "epilepticrabbit",
        "indices" : [ 73, 89 ],
        "id_str" : "212475110",
        "id" : 212475110
      }, {
        "name" : "Mozilla Webmaker",
        "screen_name" : "Webmaker",
        "indices" : [ 90, 99 ],
        "id_str" : "1242429835",
        "id" : 1242429835
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 72 ],
        "url" : "http:\/\/t.co\/KQfSnzymHq",
        "expanded_url" : "http:\/\/wp.me\/pf0PM-7U9",
        "display_url" : "wp.me\/pf0PM-7U9"
      } ]
    },
    "geo" : { },
    "id_str" : "469253588271648769",
    "text" : "CogDogBlogged: Image Seek: A Mozilla Thimble Make http:\/\/t.co\/KQfSnzymHq @epilepticrabbit @webmaker",
    "id" : 469253588271648769,
    "created_at" : "2014-05-21 23:09:08 +0000",
    "user" : {
      "name" : "Alan Levine",
      "screen_name" : "cogdog",
      "protected" : false,
      "id_str" : "740343",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/740063389527859201\/BN9buLB9_normal.jpg",
      "id" : 740343,
      "verified" : false
    }
  },
  "id" : 469404251421442048,
  "created_at" : "2014-05-22 09:07:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "P\u00E9rez-Paredes",
      "screen_name" : "perezparedes",
      "indices" : [ 3, 16 ],
      "id_str" : "28528850",
      "id" : 28528850
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpuslinguistics",
      "indices" : [ 18, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 125, 140 ],
      "url" : "https:\/\/t.co\/aDCF2co2kO",
      "expanded_url" : "https:\/\/valence.ujf-grenoble.fr\/recherche-valence\/actualites\/seminaire-mardi-27-mai-2014",
      "display_url" : "valence.ujf-grenoble.fr\/recherche-vale\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "469186985169801216",
  "text" : "RT @perezparedes: #corpuslinguistics Enhancing and extending corpora and corpora tools for learning and teaching UJF VALENCE https:\/\/t.co\/a\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpuslinguistics",
        "indices" : [ 0, 18 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/aDCF2co2kO",
        "expanded_url" : "https:\/\/valence.ujf-grenoble.fr\/recherche-valence\/actualites\/seminaire-mardi-27-mai-2014",
        "display_url" : "valence.ujf-grenoble.fr\/recherche-vale\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "469181722014539776",
    "text" : "#corpuslinguistics Enhancing and extending corpora and corpora tools for learning and teaching UJF VALENCE https:\/\/t.co\/aDCF2co2kO",
    "id" : 469181722014539776,
    "created_at" : "2014-05-21 18:23:34 +0000",
    "user" : {
      "name" : "P\u00E9rez-Paredes",
      "screen_name" : "perezparedes",
      "protected" : false,
      "id_str" : "28528850",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746249968139313153\/2-1yieTh_normal.jpg",
      "id" : 28528850,
      "verified" : false
    }
  },
  "id" : 469186985169801216,
  "created_at" : "2014-05-21 18:44:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth Anne",
      "screen_name" : "eannegrenoble",
      "indices" : [ 0, 14 ],
      "id_str" : "19869781",
      "id" : 19869781
    }, {
      "name" : "Lizzie Pinard",
      "screen_name" : "LizziePinard",
      "indices" : [ 15, 28 ],
      "id_str" : "287093748",
      "id" : 287093748
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 123, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/C5OEvVF31d",
      "expanded_url" : "https:\/\/plus.google.com\/u\/0\/communities\/101266284417587206243",
      "display_url" : "plus.google.com\/u\/0\/communitie\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "469076040682590208",
  "geo" : { },
  "id_str" : "469145366882160640",
  "in_reply_to_user_id" : 19869781,
  "text" : "@eannegrenoble @LizziePinard thx for shout out, here's the G+ CL link for all your CL cpd needs :) https:\/\/t.co\/C5OEvVF31d #eltchat",
  "id" : 469145366882160640,
  "in_reply_to_status_id" : 469076040682590208,
  "created_at" : "2014-05-21 15:59:06 +0000",
  "in_reply_to_screen_name" : "eannegrenoble",
  "in_reply_to_user_id_str" : "19869781",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyler Schnoebelen",
      "screen_name" : "TSchnoebelen",
      "indices" : [ 3, 16 ],
      "id_str" : "14969147",
      "id" : 14969147
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/1jjPFnD0nd",
      "expanded_url" : "http:\/\/ow.ly\/x4NNj",
      "display_url" : "ow.ly\/x4NNj"
    } ]
  },
  "geo" : { },
  "id_str" : "469063705188388864",
  "text" : "RT @TSchnoebelen: A Netflix app is glitching and creating weird new films we wish were real - Us Vs Th3m http:\/\/t.co\/1jjPFnD0nd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/1jjPFnD0nd",
        "expanded_url" : "http:\/\/ow.ly\/x4NNj",
        "display_url" : "ow.ly\/x4NNj"
      } ]
    },
    "geo" : { },
    "id_str" : "468919202699825152",
    "text" : "A Netflix app is glitching and creating weird new films we wish were real - Us Vs Th3m http:\/\/t.co\/1jjPFnD0nd",
    "id" : 468919202699825152,
    "created_at" : "2014-05-21 01:00:24 +0000",
    "user" : {
      "name" : "Tyler Schnoebelen",
      "screen_name" : "TSchnoebelen",
      "protected" : false,
      "id_str" : "14969147",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/604427674203779072\/Y4t_NODB_normal.jpg",
      "id" : 14969147,
      "verified" : false
    }
  },
  "id" : 469063705188388864,
  "created_at" : "2014-05-21 10:34:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anonymous",
      "screen_name" : "YourAnonNews",
      "indices" : [ 3, 16 ],
      "id_str" : "279390084",
      "id" : 279390084
    }, {
      "name" : "Glenn Greenwald",
      "screen_name" : "ggreenwald",
      "indices" : [ 32, 43 ],
      "id_str" : "16076032",
      "id" : 16076032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/oZGDafNM6o",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=ktRzyiIK1p8",
      "display_url" : "youtube.com\/watch?v=ktRzyi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "468850334719545344",
  "text" : "RT @YourAnonNews: Full video of @ggreenwald &amp; Noam Chomsky talk at Harvard bookstore https:\/\/t.co\/oZGDafNM6o",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Glenn Greenwald",
        "screen_name" : "ggreenwald",
        "indices" : [ 14, 25 ],
        "id_str" : "16076032",
        "id" : 16076032
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/oZGDafNM6o",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=ktRzyiIK1p8",
        "display_url" : "youtube.com\/watch?v=ktRzyi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "468636202988732416",
    "text" : "Full video of @ggreenwald &amp; Noam Chomsky talk at Harvard bookstore https:\/\/t.co\/oZGDafNM6o",
    "id" : 468636202988732416,
    "created_at" : "2014-05-20 06:15:52 +0000",
    "user" : {
      "name" : "Anonymous",
      "screen_name" : "YourAnonNews",
      "protected" : false,
      "id_str" : "279390084",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/715985177395261441\/ad0f_tAp_normal.jpg",
      "id" : 279390084,
      "verified" : false
    }
  },
  "id" : 468850334719545344,
  "created_at" : "2014-05-20 20:26:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eily Murphy",
      "screen_name" : "eilymurphy",
      "indices" : [ 0, 11 ],
      "id_str" : "111091623",
      "id" : 111091623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "468505494496505856",
  "geo" : { },
  "id_str" : "468506085007978499",
  "in_reply_to_user_id" : 111091623,
  "text" : "@eilymurphy it is fun, living in the future they say :o",
  "id" : 468506085007978499,
  "in_reply_to_status_id" : 468505494496505856,
  "created_at" : "2014-05-19 21:38:49 +0000",
  "in_reply_to_screen_name" : "eilymurphy",
  "in_reply_to_user_id_str" : "111091623",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "projectnaptha",
      "indices" : [ 20, 34 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/YITK5joufd",
      "expanded_url" : "https:\/\/chrome.google.com\/webstore\/detail\/project-naptha\/molncoemjfmpgdkbdlbjmhlcgniigdnf?hl=en-US&utm_source=chrome-ntp-launcher",
      "display_url" : "chrome.google.com\/webstore\/detai\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "468503496871141376",
  "geo" : { },
  "id_str" : "468504093615738880",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl with help of #projectnaptha for google chrome https:\/\/t.co\/YITK5joufd",
  "id" : 468504093615738880,
  "in_reply_to_status_id" : 468503496871141376,
  "created_at" : "2014-05-19 21:30:54 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Bunyan",
      "screen_name" : "bunyanchris",
      "indices" : [ 3, 15 ],
      "id_str" : "237402639",
      "id" : 237402639
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/ib0gZiQ5W7",
      "expanded_url" : "http:\/\/www.businessinsider.com.au\/communication-charts-around-the-world-2014-3",
      "display_url" : "businessinsider.com.au\/communication-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "468503001834209281",
  "text" : "RT @bunyanchris: Cultural comparison of business meeting schema. http:\/\/t.co\/ib0gZiQ5W7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 70 ],
        "url" : "http:\/\/t.co\/ib0gZiQ5W7",
        "expanded_url" : "http:\/\/www.businessinsider.com.au\/communication-charts-around-the-world-2014-3",
        "display_url" : "businessinsider.com.au\/communication-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "468285883461144576",
    "text" : "Cultural comparison of business meeting schema. http:\/\/t.co\/ib0gZiQ5W7",
    "id" : 468285883461144576,
    "created_at" : "2014-05-19 07:03:49 +0000",
    "user" : {
      "name" : "Chris Bunyan",
      "screen_name" : "bunyanchris",
      "protected" : false,
      "id_str" : "237402639",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/554586048504688640\/nlCbeuHQ_normal.jpeg",
      "id" : 237402639,
      "verified" : false
    }
  },
  "id" : 468503001834209281,
  "created_at" : "2014-05-19 21:26:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/468499990663659522\/photo\/1",
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/9AbfYdWKkQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BoByQeRCIAAgpKU.png",
      "id_str" : "468499988574511104",
      "id" : 468499988574511104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BoByQeRCIAAgpKU.png",
      "sizes" : [ {
        "h" : 271,
        "resize" : "fit",
        "w" : 179
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 271,
        "resize" : "fit",
        "w" : 179
      }, {
        "h" : 271,
        "resize" : "fit",
        "w" : 179
      }, {
        "h" : 271,
        "resize" : "fit",
        "w" : 179
      } ],
      "display_url" : "pic.twitter.com\/9AbfYdWKkQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "468487579235803136",
  "geo" : { },
  "id_str" : "468499990663659522",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl he has a new book out i believe :) http:\/\/t.co\/9AbfYdWKkQ",
  "id" : 468499990663659522,
  "in_reply_to_status_id" : 468487579235803136,
  "created_at" : "2014-05-19 21:14:36 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/cvvcdQQXOJ",
      "expanded_url" : "http:\/\/tm.durusau.net\/?p=53141",
      "display_url" : "tm.durusau.net\/?p=53141"
    } ]
  },
  "geo" : { },
  "id_str" : "468484695064588288",
  "text" : "Banksy on advertising and tolerance for risk http:\/\/t.co\/cvvcdQQXOJ",
  "id" : 468484695064588288,
  "created_at" : "2014-05-19 20:13:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nic Subtirelu",
      "screen_name" : "linguisticpulse",
      "indices" : [ 3, 19 ],
      "id_str" : "1400748798",
      "id" : 1400748798
    }, {
      "name" : "Lynne Murphy",
      "screen_name" : "lynneguist",
      "indices" : [ 126, 137 ],
      "id_str" : "16316886",
      "id" : 16316886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/VQjOf4GJUt",
      "expanded_url" : "http:\/\/bit.ly\/1gHbzrF",
      "display_url" : "bit.ly\/1gHbzrF"
    } ]
  },
  "geo" : { },
  "id_str" : "468416325954854912",
  "text" : "RT @linguisticpulse: Just finished post (http:\/\/t.co\/VQjOf4GJUt) analyzing gendered use of PUSHY and CONDESCENDING. Thanks to @lynneguist f\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lynne Murphy",
        "screen_name" : "lynneguist",
        "indices" : [ 105, 116 ],
        "id_str" : "16316886",
        "id" : 16316886
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 20, 42 ],
        "url" : "http:\/\/t.co\/VQjOf4GJUt",
        "expanded_url" : "http:\/\/bit.ly\/1gHbzrF",
        "display_url" : "bit.ly\/1gHbzrF"
      } ]
    },
    "geo" : { },
    "id_str" : "468414987632119809",
    "text" : "Just finished post (http:\/\/t.co\/VQjOf4GJUt) analyzing gendered use of PUSHY and CONDESCENDING. Thanks to @lynneguist for suggestion!",
    "id" : 468414987632119809,
    "created_at" : "2014-05-19 15:36:50 +0000",
    "user" : {
      "name" : "Nic Subtirelu",
      "screen_name" : "linguisticpulse",
      "protected" : false,
      "id_str" : "1400748798",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3609632834\/4ae2ef11e9cffa43e820f3ef7e18b016_normal.jpeg",
      "id" : 1400748798,
      "verified" : false
    }
  },
  "id" : 468416325954854912,
  "created_at" : "2014-05-19 15:42:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/Qd4ukUnf9P",
      "expanded_url" : "http:\/\/wp.me\/p3EMrr-6Y",
      "display_url" : "wp.me\/p3EMrr-6Y"
    } ]
  },
  "geo" : { },
  "id_str" : "467672815118729216",
  "text" : "Can teachers stop believing in nonsense? http:\/\/t.co\/Qd4ukUnf9P via @turnfordblog",
  "id" : 467672815118729216,
  "created_at" : "2014-05-17 14:27:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u795E\u8C37\u5065\u4E00",
      "screen_name" : "kmyken1",
      "indices" : [ 3, 11 ],
      "id_str" : "97443893",
      "id" : 97443893
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/ZuJ8LDvehx",
      "expanded_url" : "http:\/\/www.robwaring.org\/presentations\/vocab\/2014_5_17_principles_of_vocabulary_LET.ppt",
      "display_url" : "robwaring.org\/presentations\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "467665371655585793",
  "text" : "RT @kmyken1: LET\u95A2\u897F\u652F\u90E8\u6625\u671F\u7814\u7A76\u5927\u4F1A1\u4EF6\u76EE\u306F Dealing with Vocabulary in the English Language Classroom by Dr. Robert Waring \u3092\u8074\u8B1B\u3002\u30B9\u30E9\u30A4\u30C9\u306F http:\/\/t.co\/ZuJ8LDv\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/ZuJ8LDvehx",
        "expanded_url" : "http:\/\/www.robwaring.org\/presentations\/vocab\/2014_5_17_principles_of_vocabulary_LET.ppt",
        "display_url" : "robwaring.org\/presentations\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "467502650758397953",
    "text" : "LET\u95A2\u897F\u652F\u90E8\u6625\u671F\u7814\u7A76\u5927\u4F1A1\u4EF6\u76EE\u306F Dealing with Vocabulary in the English Language Classroom by Dr. Robert Waring \u3092\u8074\u8B1B\u3002\u30B9\u30E9\u30A4\u30C9\u306F http:\/\/t.co\/ZuJ8LDvehx \u3067\u516C\u958B\u3055\u308C\u3066\u3044\u307E\u3059\u3002",
    "id" : 467502650758397953,
    "created_at" : "2014-05-17 03:11:32 +0000",
    "user" : {
      "name" : "\u795E\u8C37\u5065\u4E00",
      "screen_name" : "kmyken1",
      "protected" : false,
      "id_str" : "97443893",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/442928087978627072\/Qc_LYJW7_normal.png",
      "id" : 97443893,
      "verified" : false
    }
  },
  "id" : 467665371655585793,
  "created_at" : "2014-05-17 13:58:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Natallia Novikava",
      "screen_name" : "Natashetta",
      "indices" : [ 3, 14 ],
      "id_str" : "56308635",
      "id" : 56308635
    }, {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 80, 95 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/UvP68Brpa0",
      "expanded_url" : "http:\/\/wp.me\/p3qkCB-PK",
      "display_url" : "wp.me\/p3qkCB-PK"
    } ]
  },
  "geo" : { },
  "id_str" : "467575540992737280",
  "text" : "RT @Natashetta: Rose Bard's Blog: Teaching Journal   http:\/\/t.co\/UvP68Brpa0 via @GeoffreyJordan",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Geoffrey Jordan",
        "screen_name" : "GeoffreyJordan",
        "indices" : [ 64, 79 ],
        "id_str" : "334332424",
        "id" : 334332424
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 59 ],
        "url" : "http:\/\/t.co\/UvP68Brpa0",
        "expanded_url" : "http:\/\/wp.me\/p3qkCB-PK",
        "display_url" : "wp.me\/p3qkCB-PK"
      } ]
    },
    "geo" : { },
    "id_str" : "467573330992586752",
    "text" : "Rose Bard's Blog: Teaching Journal   http:\/\/t.co\/UvP68Brpa0 via @GeoffreyJordan",
    "id" : 467573330992586752,
    "created_at" : "2014-05-17 07:52:23 +0000",
    "user" : {
      "name" : "Natallia Novikava",
      "screen_name" : "Natashetta",
      "protected" : false,
      "id_str" : "56308635",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2877370292\/d6370dfafaa5506c53671f1bd1da0cdc_normal.jpeg",
      "id" : 56308635,
      "verified" : false
    }
  },
  "id" : 467575540992737280,
  "created_at" : "2014-05-17 08:01:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 0, 13 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "467283224767778817",
  "geo" : { },
  "id_str" : "467365740254097408",
  "in_reply_to_user_id" : 88655243,
  "text" : "@rosemerebard am good thanks hope u r enjoying your studies :)",
  "id" : 467365740254097408,
  "in_reply_to_status_id" : 467283224767778817,
  "created_at" : "2014-05-16 18:07:30 +0000",
  "in_reply_to_screen_name" : "rosemerebard",
  "in_reply_to_user_id_str" : "88655243",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doug Belshaw",
      "screen_name" : "dajbelshaw",
      "indices" : [ 0, 11 ],
      "id_str" : "764365",
      "id" : 764365
    }, {
      "name" : "Mozilla Webmaker",
      "screen_name" : "Webmaker",
      "indices" : [ 12, 21 ],
      "id_str" : "1242429835",
      "id" : 1242429835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "467236571042045952",
  "geo" : { },
  "id_str" : "467270216381394944",
  "in_reply_to_user_id" : 764365,
  "text" : "@dajbelshaw @webmaker how does the forum calculate est. reading time?",
  "id" : 467270216381394944,
  "in_reply_to_status_id" : 467236571042045952,
  "created_at" : "2014-05-16 11:47:55 +0000",
  "in_reply_to_screen_name" : "dajbelshaw",
  "in_reply_to_user_id_str" : "764365",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lizzie Pinard",
      "screen_name" : "LizziePinard",
      "indices" : [ 114, 127 ],
      "id_str" : "287093748",
      "id" : 287093748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/xDaSBRgfJl",
      "expanded_url" : "http:\/\/wp.me\/p1wSAy-AM",
      "display_url" : "wp.me\/p1wSAy-AM"
    } ]
  },
  "geo" : { },
  "id_str" : "467255254208110592",
  "text" : "ELTchat summary (14\/05\/14) - \"Intercultural awareness: what our students need to know\" http:\/\/t.co\/xDaSBRgfJl via @lizziepinard",
  "id" : 467255254208110592,
  "created_at" : "2014-05-16 10:48:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Parise",
      "screen_name" : "peterrenshu",
      "indices" : [ 0, 12 ],
      "id_str" : "631949549",
      "id" : 631949549
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/GoiMZ0dvFK",
      "expanded_url" : "http:\/\/wronghands1.files.wordpress.com\/2013\/09\/a-tense-situation.jpg",
      "display_url" : "wronghands1.files.wordpress.com\/2013\/09\/a-tens\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "467215000902193152",
  "geo" : { },
  "id_str" : "467219990954127360",
  "in_reply_to_user_id" : 631949549,
  "text" : "@peterrenshu not sure but there are some badass tenses out there http:\/\/t.co\/GoiMZ0dvFK :)",
  "id" : 467219990954127360,
  "in_reply_to_status_id" : 467215000902193152,
  "created_at" : "2014-05-16 08:28:21 +0000",
  "in_reply_to_screen_name" : "peterrenshu",
  "in_reply_to_user_id_str" : "631949549",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Parise",
      "screen_name" : "peterrenshu",
      "indices" : [ 0, 12 ],
      "id_str" : "631949549",
      "id" : 631949549
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/QQ2stKZSsK",
      "expanded_url" : "https:\/\/github.com\/reubenfb\/Deadspin_Draftwords",
      "display_url" : "github.com\/reubenfb\/Deads\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "467202707384578048",
  "geo" : { },
  "id_str" : "467215677267652608",
  "in_reply_to_user_id" : 631949549,
  "text" : "@peterrenshu hi used the github files https:\/\/t.co\/QQ2stKZSsK &amp; xml scripting to extract gender spoken data, will do quick post soon",
  "id" : 467215677267652608,
  "in_reply_to_status_id" : 467202707384578048,
  "created_at" : "2014-05-16 08:11:12 +0000",
  "in_reply_to_screen_name" : "peterrenshu",
  "in_reply_to_user_id_str" : "631949549",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    }, {
      "name" : "Rob Drummond",
      "screen_name" : "robdrummond",
      "indices" : [ 7, 19 ],
      "id_str" : "257670599",
      "id" : 257670599
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/467215108285157376\/photo\/1",
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/GLhgyO2T1V",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BnvhqfzIcAAhNRL.png",
      "id_str" : "467215106569695232",
      "id" : 467215106569695232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnvhqfzIcAAhNRL.png",
      "sizes" : [ {
        "h" : 213,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/GLhgyO2T1V"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/5ob0viwJ1b",
      "expanded_url" : "http:\/\/bncgender.englishup.me\/",
      "display_url" : "bncgender.englishup.me"
    } ]
  },
  "in_reply_to_status_id_str" : "467212957802565632",
  "geo" : { },
  "id_str" : "467215108285157376",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl @robdrummond no gender difference in use :) http:\/\/t.co\/5ob0viwJ1b http:\/\/t.co\/GLhgyO2T1V",
  "id" : 467215108285157376,
  "in_reply_to_status_id" : 467212957802565632,
  "created_at" : "2014-05-16 08:08:56 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 0, 13 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "467082876874657792",
  "in_reply_to_user_id" : 88655243,
  "text" : "@rosemerebard thanks for that rapid rt rose :)",
  "id" : 467082876874657792,
  "created_at" : "2014-05-15 23:23:30 +0000",
  "in_reply_to_screen_name" : "rosemerebard",
  "in_reply_to_user_id_str" : "88655243",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 40, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/dbleQJYqpS",
      "expanded_url" : "https:\/\/plus.google.com\/104940199413423400545\/posts\/Tr4QgD3X2nv",
      "display_url" : "plus.google.com\/10494019941342\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "467080893459615744",
  "text" : "BNCgender words https:\/\/t.co\/dbleQJYqpS #corpusmooc",
  "id" : 467080893459615744,
  "created_at" : "2014-05-15 23:15:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "indices" : [ 3, 14 ],
      "id_str" : "152051625",
      "id" : 152051625
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AntConc",
      "indices" : [ 46, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/gwyNBbROSc",
      "expanded_url" : "http:\/\/bit.ly\/1nP9yM1",
      "display_url" : "bit.ly\/1nP9yM1"
    } ]
  },
  "geo" : { },
  "id_str" : "467057158446923776",
  "text" : "RT @heatherfro: And in advance of my upcoming #AntConc workshop: Getting Started with Antconc (a how-to guide) http:\/\/t.co\/gwyNBbROSc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AntConc",
        "indices" : [ 30, 38 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/gwyNBbROSc",
        "expanded_url" : "http:\/\/bit.ly\/1nP9yM1",
        "display_url" : "bit.ly\/1nP9yM1"
      } ]
    },
    "geo" : { },
    "id_str" : "467026355440586752",
    "text" : "And in advance of my upcoming #AntConc workshop: Getting Started with Antconc (a how-to guide) http:\/\/t.co\/gwyNBbROSc",
    "id" : 467026355440586752,
    "created_at" : "2014-05-15 19:38:54 +0000",
    "user" : {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "protected" : false,
      "id_str" : "152051625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/688767277022494720\/KMrzOBc1_normal.jpg",
      "id" : 152051625,
      "verified" : false
    }
  },
  "id" : 467057158446923776,
  "created_at" : "2014-05-15 21:41:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ETpro",
      "screen_name" : "ETprofessional",
      "indices" : [ 0, 15 ],
      "id_str" : "501629829",
      "id" : 501629829
    }, {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 16, 26 ],
      "id_str" : "525274103",
      "id" : 525274103
    }, {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 27, 33 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "466938084987527168",
  "geo" : { },
  "id_str" : "466957735675068416",
  "in_reply_to_user_id" : 501629829,
  "text" : "@ETprofessional @ElkySmith @ebefl ok thx for info :)",
  "id" : 466957735675068416,
  "in_reply_to_status_id" : 466938084987527168,
  "created_at" : "2014-05-15 15:06:14 +0000",
  "in_reply_to_screen_name" : "ETprofessional",
  "in_reply_to_user_id_str" : "501629829",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "466831444409868288",
  "geo" : { },
  "id_str" : "466834215750090752",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl hi which corpus site r u referring to here?",
  "id" : 466834215750090752,
  "in_reply_to_status_id" : 466831444409868288,
  "created_at" : "2014-05-15 06:55:25 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 0, 14 ],
      "id_str" : "25388528",
      "id" : 25388528
    }, {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 15, 25 ],
      "id_str" : "525274103",
      "id" : 525274103
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/466728878900535296\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/Lb9pF0IqpH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BnoncQgIMAI-VJZ.png",
      "id_str" : "466728877805809666",
      "id" : 466728877805809666,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnoncQgIMAI-VJZ.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 306,
        "resize" : "fit",
        "w" : 312
      }, {
        "h" : 306,
        "resize" : "fit",
        "w" : 312
      }, {
        "h" : 306,
        "resize" : "fit",
        "w" : 312
      }, {
        "h" : 306,
        "resize" : "fit",
        "w" : 312
      } ],
      "display_url" : "pic.twitter.com\/Lb9pF0IqpH"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/AZioxa30Ag",
      "expanded_url" : "http:\/\/www.collinsdictionary.com\/dictionary\/american\/innovation",
      "display_url" : "collinsdictionary.com\/dictionary\/ame\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "466657010956918784",
  "geo" : { },
  "id_str" : "466728878900535296",
  "in_reply_to_user_id" : 25388528,
  "text" : "@audreywatters @ElkySmith great stuff but caution noisy ngrms c innovation using collins USeng http:\/\/t.co\/AZioxa30Ag http:\/\/t.co\/Lb9pF0IqpH",
  "id" : 466728878900535296,
  "in_reply_to_status_id" : 466657010956918784,
  "created_at" : "2014-05-14 23:56:50 +0000",
  "in_reply_to_screen_name" : "audreywatters",
  "in_reply_to_user_id_str" : "25388528",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/qjAcV7naGp",
      "expanded_url" : "http:\/\/bps-research-digest.blogspot.fr\/2014\/05\/kidding-ourselves-on-educational.html#.U3PIHo4Ultk.twitter",
      "display_url" : "bps-research-digest.blogspot.fr\/2014\/05\/kiddin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466665973966069760",
  "text" : "Kidding ourselves on educational interventions? http:\/\/t.co\/qjAcV7naGp",
  "id" : 466665973966069760,
  "created_at" : "2014-05-14 19:46:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELTchinwag",
      "indices" : [ 15, 26 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 27, 35 ]
    }, {
      "text" : "KELTchat",
      "indices" : [ 120, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "466657768653750272",
  "text" : "RT @HadaLitim: #ELTchinwag #eltchat tonight 9pm BST \"Intercultural Communication \u2013 what do our learners need to know..' #KELTchat 9pmBST",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELTchinwag",
        "indices" : [ 0, 11 ]
      }, {
        "text" : "eltchat",
        "indices" : [ 12, 20 ]
      }, {
        "text" : "KELTchat",
        "indices" : [ 105, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "466656576078872576",
    "text" : "#ELTchinwag #eltchat tonight 9pm BST \"Intercultural Communication \u2013 what do our learners need to know..' #KELTchat 9pmBST",
    "id" : 466656576078872576,
    "created_at" : "2014-05-14 19:09:32 +0000",
    "user" : {
      "name" : "Hada ELT",
      "screen_name" : "Hada_ELT",
      "protected" : false,
      "id_str" : "44631065",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729282562783326209\/2tQuUs5L_normal.jpg",
      "id" : 44631065,
      "verified" : false
    }
  },
  "id" : 466657768653750272,
  "created_at" : "2014-05-14 19:14:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SanakoUK",
      "screen_name" : "sanakouk",
      "indices" : [ 3, 12 ],
      "id_str" : "2617356576",
      "id" : 2617356576
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whatwouldyouscore",
      "indices" : [ 85, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/wQ5zKuHopw",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=2d-eL2x88yI",
      "display_url" : "youtube.com\/watch?v=2d-eL2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466532623310147584",
  "text" : "RT @SanakoUK: Want to win an iPad Air? Watch and Share our new Pronounce video using #whatwouldyouscore for your chance to win! https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whatwouldyouscore",
        "indices" : [ 71, 89 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/wQ5zKuHopw",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=2d-eL2x88yI",
        "display_url" : "youtube.com\/watch?v=2d-eL2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "466520630616395776",
    "text" : "Want to win an iPad Air? Watch and Share our new Pronounce video using #whatwouldyouscore for your chance to win! https:\/\/t.co\/wQ5zKuHopw",
    "id" : 466520630616395776,
    "created_at" : "2014-05-14 10:09:20 +0000",
    "user" : {
      "name" : "Sanako",
      "screen_name" : "SanakoOy",
      "protected" : false,
      "id_str" : "563784687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458888082754764800\/IyKJdDQO_normal.jpeg",
      "id" : 563784687,
      "verified" : false
    }
  },
  "id" : 466532623310147584,
  "created_at" : "2014-05-14 10:56:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Guardian",
      "screen_name" : "guardian",
      "indices" : [ 3, 12 ],
      "id_str" : "87818409",
      "id" : 87818409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/uBah412UmQ",
      "expanded_url" : "http:\/\/gu.com\/p\/3p2eq\/tw",
      "display_url" : "gu.com\/p\/3p2eq\/tw"
    } ]
  },
  "geo" : { },
  "id_str" : "466325315258949632",
  "text" : "RT @guardian: Ken Loach: 'What I've always tried to do is capture the truth of the moment'   http:\/\/t.co\/uBah412UmQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/uBah412UmQ",
        "expanded_url" : "http:\/\/gu.com\/p\/3p2eq\/tw",
        "display_url" : "gu.com\/p\/3p2eq\/tw"
      } ]
    },
    "geo" : { },
    "id_str" : "465758792303800320",
    "text" : "Ken Loach: 'What I've always tried to do is capture the truth of the moment'   http:\/\/t.co\/uBah412UmQ",
    "id" : 465758792303800320,
    "created_at" : "2014-05-12 07:42:04 +0000",
    "user" : {
      "name" : "The Guardian",
      "screen_name" : "guardian",
      "protected" : false,
      "id_str" : "87818409",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/715857640853741568\/nfNt_pGn_normal.jpg",
      "id" : 87818409,
      "verified" : true
    }
  },
  "id" : 466325315258949632,
  "created_at" : "2014-05-13 21:13:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 0, 15 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "466297101584846848",
  "geo" : { },
  "id_str" : "466301163173081088",
  "in_reply_to_user_id" : 334332424,
  "text" : "@GeoffreyJordan quentin's talk is so dip, it's wursting my conchitas man :)",
  "id" : 466301163173081088,
  "in_reply_to_status_id" : 466297101584846848,
  "created_at" : "2014-05-13 19:37:15 +0000",
  "in_reply_to_screen_name" : "GeoffreyJordan",
  "in_reply_to_user_id_str" : "334332424",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lesley Cooke",
      "screen_name" : "lesley777",
      "indices" : [ 3, 13 ],
      "id_str" : "26990587",
      "id" : 26990587
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USA",
      "indices" : [ 15, 19 ]
    }, {
      "text" : "priceless",
      "indices" : [ 123, 133 ]
    }, {
      "text" : "Ukraine",
      "indices" : [ 134, 140 ]
    }, {
      "text" : "russia",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "466235678507163649",
  "text" : "RT @lesley777: #USA spokeswoman : there was carousel voting in Donetsk. Reporter: what's that? Spokeswoman: I don't know.  #priceless #Ukra\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "USA",
        "indices" : [ 0, 4 ]
      }, {
        "text" : "priceless",
        "indices" : [ 108, 118 ]
      }, {
        "text" : "Ukraine",
        "indices" : [ 119, 127 ]
      }, {
        "text" : "russia",
        "indices" : [ 128, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "465978237219115008",
    "text" : "#USA spokeswoman : there was carousel voting in Donetsk. Reporter: what's that? Spokeswoman: I don't know.  #priceless #Ukraine #russia",
    "id" : 465978237219115008,
    "created_at" : "2014-05-12 22:14:03 +0000",
    "user" : {
      "name" : "Lesley Cooke",
      "screen_name" : "lesley777",
      "protected" : false,
      "id_str" : "26990587",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623470388622848000\/7JsPDQsK_normal.jpg",
      "id" : 26990587,
      "verified" : false
    }
  },
  "id" : 466235678507163649,
  "created_at" : "2014-05-13 15:17:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noor Adnan",
      "screen_name" : "n00rbaizura",
      "indices" : [ 0, 12 ],
      "id_str" : "412094121",
      "id" : 412094121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "466211552421756928",
  "in_reply_to_user_id" : 412094121,
  "text" : "@n00rbaizura thx for RT :)",
  "id" : 466211552421756928,
  "created_at" : "2014-05-13 13:41:10 +0000",
  "in_reply_to_screen_name" : "n00rbaizura",
  "in_reply_to_user_id_str" : "412094121",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boing Boing",
      "screen_name" : "BoingBoing",
      "indices" : [ 3, 14 ],
      "id_str" : "5971922",
      "id" : 5971922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/PQg0f9gNMu",
      "expanded_url" : "http:\/\/dlvr.it\/5fGCPj",
      "display_url" : "dlvr.it\/5fGCPj"
    } ]
  },
  "geo" : { },
  "id_str" : "466174887858814976",
  "text" : "RT @BoingBoing: You are a Gmail user http:\/\/t.co\/PQg0f9gNMu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/dlvr.it\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 21, 43 ],
        "url" : "http:\/\/t.co\/PQg0f9gNMu",
        "expanded_url" : "http:\/\/dlvr.it\/5fGCPj",
        "display_url" : "dlvr.it\/5fGCPj"
      } ]
    },
    "geo" : { },
    "id_str" : "465933604053213184",
    "text" : "You are a Gmail user http:\/\/t.co\/PQg0f9gNMu",
    "id" : 465933604053213184,
    "created_at" : "2014-05-12 19:16:42 +0000",
    "user" : {
      "name" : "Boing Boing",
      "screen_name" : "BoingBoing",
      "protected" : false,
      "id_str" : "5971922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616924998226153472\/0EfZYjr2_normal.png",
      "id" : 5971922,
      "verified" : true
    }
  },
  "id" : 466174887858814976,
  "created_at" : "2014-05-13 11:15:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 3, 14 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edtech",
      "indices" : [ 99, 106 ]
    }, {
      "text" : "SethGodin",
      "indices" : [ 107, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/T2Pex4lp2r",
      "expanded_url" : "http:\/\/bit.ly\/RKNMLY",
      "display_url" : "bit.ly\/RKNMLY"
    } ]
  },
  "geo" : { },
  "id_str" : "466131068748591104",
  "text" : "RT @tornhalves: Prometheus and the digital revolution, and the case against Promethean deschooling #edtech #SethGodin http:\/\/t.co\/T2Pex4lp2r",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "edtech",
        "indices" : [ 83, 90 ]
      }, {
        "text" : "SethGodin",
        "indices" : [ 91, 101 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/T2Pex4lp2r",
        "expanded_url" : "http:\/\/bit.ly\/RKNMLY",
        "display_url" : "bit.ly\/RKNMLY"
      } ]
    },
    "geo" : { },
    "id_str" : "466116553667530754",
    "text" : "Prometheus and the digital revolution, and the case against Promethean deschooling #edtech #SethGodin http:\/\/t.co\/T2Pex4lp2r",
    "id" : 466116553667530754,
    "created_at" : "2014-05-13 07:23:41 +0000",
    "user" : {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "protected" : false,
      "id_str" : "87902543",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3059742703\/1d3c7a2052db17d29644fa0a49af6480_normal.jpeg",
      "id" : 87902543,
      "verified" : false
    }
  },
  "id" : 466131068748591104,
  "created_at" : "2014-05-13 08:21:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "indices" : [ 0, 11 ],
      "id_str" : "152051625",
      "id" : 152051625
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nopressure",
      "indices" : [ 54, 65 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "465944855387336704",
  "geo" : { },
  "id_str" : "465983558268780544",
  "in_reply_to_user_id" : 152051625,
  "text" : "@heatherfro an idiot's guide to xml scripting be cool #nopressure :)",
  "id" : 465983558268780544,
  "in_reply_to_status_id" : 465944855387336704,
  "created_at" : "2014-05-12 22:35:12 +0000",
  "in_reply_to_screen_name" : "heatherfro",
  "in_reply_to_user_id_str" : "152051625",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 55, 71 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/J7L1LHMfN7",
      "expanded_url" : "http:\/\/wp.me\/p37ScC-9h",
      "display_url" : "wp.me\/p37ScC-9h"
    } ]
  },
  "geo" : { },
  "id_str" : "465981568624762880",
  "text" : "Make or Do: Place Your Bets http:\/\/t.co\/J7L1LHMfN7 via @wordpressdotcom",
  "id" : 465981568624762880,
  "created_at" : "2014-05-12 22:27:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "android",
      "indices" : [ 26, 34 ]
    }, {
      "text" : "piratebox",
      "indices" : [ 59, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/VcYgCwhl6C",
      "expanded_url" : "http:\/\/eflnotes.wordpress.com\/2012\/06\/01\/piratebox-a-way-to-share-files-in-class\/",
      "display_url" : "eflnotes.wordpress.com\/2012\/06\/01\/pir\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465979892216385537",
  "text" : "want to share files on yr #android with your class? latest #piratebox reloaded just made it much easier see update 3 http:\/\/t.co\/VcYgCwhl6C",
  "id" : 465979892216385537,
  "created_at" : "2014-05-12 22:20:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mari Yamauchi",
      "screen_name" : "m_yam",
      "indices" : [ 0, 6 ],
      "id_str" : "21755807",
      "id" : 21755807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "465905107071033346",
  "geo" : { },
  "id_str" : "465910788533010432",
  "in_reply_to_user_id" : 21755807,
  "text" : "@m_yam it can be involved :) if u have any q'sfor android version let me know",
  "id" : 465910788533010432,
  "in_reply_to_status_id" : 465905107071033346,
  "created_at" : "2014-05-12 17:46:02 +0000",
  "in_reply_to_screen_name" : "m_yam",
  "in_reply_to_user_id_str" : "21755807",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mari Yamauchi",
      "screen_name" : "m_yam",
      "indices" : [ 26, 32 ],
      "id_str" : "21755807",
      "id" : 21755807
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "piratebox",
      "indices" : [ 15, 25 ]
    } ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/VcYgCwhl6C",
      "expanded_url" : "http:\/\/eflnotes.wordpress.com\/2012\/06\/01\/piratebox-a-way-to-share-files-in-class\/",
      "display_url" : "eflnotes.wordpress.com\/2012\/06\/01\/pir\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "465900039337156608",
  "geo" : { },
  "id_str" : "465900939162169345",
  "in_reply_to_user_id" : 21755807,
  "text" : "have you tried #piratebox @m_yam ? fyi http:\/\/t.co\/VcYgCwhl6C",
  "id" : 465900939162169345,
  "in_reply_to_status_id" : 465900039337156608,
  "created_at" : "2014-05-12 17:06:54 +0000",
  "in_reply_to_screen_name" : "m_yam",
  "in_reply_to_user_id_str" : "21755807",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 49, 58 ],
      "id_str" : "134211317",
      "id" : 134211317
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/uPfQ4jTRoZ",
      "expanded_url" : "http:\/\/wp.me\/p3Wm0j-hB",
      "display_url" : "wp.me\/p3Wm0j-hB"
    } ]
  },
  "geo" : { },
  "id_str" : "465853052109336576",
  "text" : "Starfish and Teachers http:\/\/t.co\/uPfQ4jTRoZ via @josipa74",
  "id" : 465853052109336576,
  "created_at" : "2014-05-12 13:56:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Thornbury",
      "screen_name" : "thornburyscott",
      "indices" : [ 3, 18 ],
      "id_str" : "23090474",
      "id" : 23090474
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edtech",
      "indices" : [ 48, 55 ]
    }, {
      "text" : "eltjam",
      "indices" : [ 91, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/KPQfOe1SNS",
      "expanded_url" : "http:\/\/www.eltjam.com\/narratives-of-change-in-education\/",
      "display_url" : "eltjam.com\/narratives-of-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465837823686631424",
  "text" : "RT @thornburyscott: If you read nothing else on #edtech, read this: http:\/\/t.co\/KPQfOe1SNS #eltjam",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "edtech",
        "indices" : [ 28, 35 ]
      }, {
        "text" : "eltjam",
        "indices" : [ 71, 78 ]
      } ],
      "urls" : [ {
        "indices" : [ 48, 70 ],
        "url" : "http:\/\/t.co\/KPQfOe1SNS",
        "expanded_url" : "http:\/\/www.eltjam.com\/narratives-of-change-in-education\/",
        "display_url" : "eltjam.com\/narratives-of-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "465797102984261632",
    "text" : "If you read nothing else on #edtech, read this: http:\/\/t.co\/KPQfOe1SNS #eltjam",
    "id" : 465797102984261632,
    "created_at" : "2014-05-12 10:14:18 +0000",
    "user" : {
      "name" : "Scott Thornbury",
      "screen_name" : "thornburyscott",
      "protected" : false,
      "id_str" : "23090474",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892392697\/twitter03_normal.jpg",
      "id" : 23090474,
      "verified" : false
    }
  },
  "id" : 465837823686631424,
  "created_at" : "2014-05-12 12:56:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George Chilton",
      "screen_name" : "designerlessons",
      "indices" : [ 0, 16 ],
      "id_str" : "432090149",
      "id" : 432090149
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "465835748915445760",
  "in_reply_to_user_id" : 432090149,
  "text" : "@designerlessons cheers for RT :)",
  "id" : 465835748915445760,
  "created_at" : "2014-05-12 12:47:52 +0000",
  "in_reply_to_screen_name" : "designerlessons",
  "in_reply_to_user_id_str" : "432090149",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Teacher Judy",
      "screen_name" : "JudyisBlue",
      "indices" : [ 0, 11 ],
      "id_str" : "150359676",
      "id" : 150359676
    }, {
      "name" : "Ken Lackman",
      "screen_name" : "kenlackman",
      "indices" : [ 12, 23 ],
      "id_str" : "114929243",
      "id" : 114929243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "465495509835448320",
  "geo" : { },
  "id_str" : "465557466953302016",
  "in_reply_to_user_id" : 150359676,
  "text" : "@JudyisBlue @kenlackman sounds good do teachers pick topics as well?",
  "id" : 465557466953302016,
  "in_reply_to_status_id" : 465495509835448320,
  "created_at" : "2014-05-11 18:22:04 +0000",
  "in_reply_to_screen_name" : "JudyisBlue",
  "in_reply_to_user_id_str" : "150359676",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "indices" : [ 3, 14 ],
      "id_str" : "152051625",
      "id" : 152051625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/776C9P1qYc",
      "expanded_url" : "http:\/\/bit.ly\/1mPgapT",
      "display_url" : "bit.ly\/1mPgapT"
    } ]
  },
  "geo" : { },
  "id_str" : "465556955696992256",
  "text" : "RT @heatherfro: IT'S HERE: an introductory bibliography to corpus linguistics http:\/\/t.co\/776C9P1qYc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 84 ],
        "url" : "http:\/\/t.co\/776C9P1qYc",
        "expanded_url" : "http:\/\/bit.ly\/1mPgapT",
        "display_url" : "bit.ly\/1mPgapT"
      } ]
    },
    "geo" : { },
    "id_str" : "465536395185250304",
    "text" : "IT'S HERE: an introductory bibliography to corpus linguistics http:\/\/t.co\/776C9P1qYc",
    "id" : 465536395185250304,
    "created_at" : "2014-05-11 16:58:20 +0000",
    "user" : {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "protected" : false,
      "id_str" : "152051625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/688767277022494720\/KMrzOBc1_normal.jpg",
      "id" : 152051625,
      "verified" : false
    }
  },
  "id" : 465556955696992256,
  "created_at" : "2014-05-11 18:20:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Timothy Tate",
      "screen_name" : "Timothy_Tate",
      "indices" : [ 0, 13 ],
      "id_str" : "1084531170",
      "id" : 1084531170
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/fjCqAtrOvJ",
      "expanded_url" : "http:\/\/wronghands1.wordpress.com\/",
      "display_url" : "wronghands1.wordpress.com"
    } ]
  },
  "geo" : { },
  "id_str" : "465482423942529024",
  "in_reply_to_user_id" : 1084531170,
  "text" : "@Timothy_Tate u may like this http:\/\/t.co\/fjCqAtrOvJ",
  "id" : 465482423942529024,
  "created_at" : "2014-05-11 13:23:52 +0000",
  "in_reply_to_screen_name" : "Timothy_Tate",
  "in_reply_to_user_id_str" : "1084531170",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alberto Bruzos",
      "screen_name" : "abruzos",
      "indices" : [ 3, 11 ],
      "id_str" : "150242940",
      "id" : 150242940
    }, {
      "name" : "Hack Education",
      "screen_name" : "hackeducation",
      "indices" : [ 88, 102 ],
      "id_str" : "149029700",
      "id" : 149029700
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bccagora",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/e28G6Qna8C",
      "expanded_url" : "http:\/\/www.hackeducation.com\/2014\/05\/10\/robots-and-education-labor\/",
      "display_url" : "hackeducation.com\/2014\/05\/10\/rob\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465228979755311105",
  "text" : "RT @abruzos: Must Read: Robots and Education Labor #bccagora http:\/\/t.co\/e28G6Qna8C via @hackeducation",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hack Education",
        "screen_name" : "hackeducation",
        "indices" : [ 75, 89 ],
        "id_str" : "149029700",
        "id" : 149029700
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bccagora",
        "indices" : [ 38, 47 ]
      } ],
      "urls" : [ {
        "indices" : [ 48, 70 ],
        "url" : "http:\/\/t.co\/e28G6Qna8C",
        "expanded_url" : "http:\/\/www.hackeducation.com\/2014\/05\/10\/robots-and-education-labor\/",
        "display_url" : "hackeducation.com\/2014\/05\/10\/rob\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "465227461156802560",
    "text" : "Must Read: Robots and Education Labor #bccagora http:\/\/t.co\/e28G6Qna8C via @hackeducation",
    "id" : 465227461156802560,
    "created_at" : "2014-05-10 20:30:44 +0000",
    "user" : {
      "name" : "Alberto Bruzos",
      "screen_name" : "abruzos",
      "protected" : false,
      "id_str" : "150242940",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/946606779\/aj__normal.JPG",
      "id" : 150242940,
      "verified" : false
    }
  },
  "id" : 465228979755311105,
  "created_at" : "2014-05-10 20:36:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 87, 103 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/oK1cr2T8mI",
      "expanded_url" : "http:\/\/wp.me\/p354NQ-5R",
      "display_url" : "wp.me\/p354NQ-5R"
    } ]
  },
  "geo" : { },
  "id_str" : "465174316833722368",
  "text" : "I\u2019m Tired of Your Cheesecake: The Lyrics of Eurovision 2014 http:\/\/t.co\/oK1cr2T8mI via @wordpressdotcom",
  "id" : 465174316833722368,
  "created_at" : "2014-05-10 16:59:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monterey Herald",
      "screen_name" : "MontereyHerald",
      "indices" : [ 94, 109 ],
      "id_str" : "13134892",
      "id" : 13134892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/DazhGrd2I4",
      "expanded_url" : "http:\/\/MontereyHerald.com",
      "display_url" : "MontereyHerald.com"
    }, {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/c6yapOefjA",
      "expanded_url" : "http:\/\/www.montereyherald.com\/opinion\/ci_25645285\/commentary-when-bad-teachers-are-good",
      "display_url" : "montereyherald.com\/opinion\/ci_256\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "465164623306432514",
  "text" : "Paul Karrer: When bad teachers are good - http:\/\/t.co\/DazhGrd2I4 : http:\/\/t.co\/c6yapOefjA via @MontereyHerald",
  "id" : 465164623306432514,
  "created_at" : "2014-05-10 16:21:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Divya Madhavan",
      "screen_name" : "_divyamadhavan",
      "indices" : [ 3, 18 ],
      "id_str" : "408492806",
      "id" : 408492806
    }, {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 110, 126 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KELTchat",
      "indices" : [ 70, 79 ]
    }, {
      "text" : "CriticalPedagogy",
      "indices" : [ 83, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "465152297031696384",
  "text" : "RT @_divyamadhavan: What does your teacher voice sound like? Join the #KELTchat on #CriticalPedagogy tomorrow @michaelegriffin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Michael Griffin",
        "screen_name" : "michaelegriffin",
        "indices" : [ 90, 106 ],
        "id_str" : "394053348",
        "id" : 394053348
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "KELTchat",
        "indices" : [ 50, 59 ]
      }, {
        "text" : "CriticalPedagogy",
        "indices" : [ 63, 80 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "465144099176460288",
    "text" : "What does your teacher voice sound like? Join the #KELTchat on #CriticalPedagogy tomorrow @michaelegriffin",
    "id" : 465144099176460288,
    "created_at" : "2014-05-10 14:59:29 +0000",
    "user" : {
      "name" : "Divya Madhavan",
      "screen_name" : "_divyamadhavan",
      "protected" : false,
      "id_str" : "408492806",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/764501890071666688\/jyS8Y-Ag_normal.jpg",
      "id" : 408492806,
      "verified" : false
    }
  },
  "id" : 465152297031696384,
  "created_at" : "2014-05-10 15:32:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mieke Kenis",
      "screen_name" : "mkofab",
      "indices" : [ 3, 10 ],
      "id_str" : "96527212",
      "id" : 96527212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/USwL7Y0OgJ",
      "expanded_url" : "http:\/\/econ.st\/1kwfwvX",
      "display_url" : "econ.st\/1kwfwvX"
    } ]
  },
  "geo" : { },
  "id_str" : "464850660262182914",
  "text" : "RT @mkofab: English at universities: Johnson: Not just studying English, but in English | The Economist http:\/\/t.co\/USwL7Y0OgJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/USwL7Y0OgJ",
        "expanded_url" : "http:\/\/econ.st\/1kwfwvX",
        "display_url" : "econ.st\/1kwfwvX"
      } ]
    },
    "geo" : { },
    "id_str" : "464837761787105281",
    "text" : "English at universities: Johnson: Not just studying English, but in English | The Economist http:\/\/t.co\/USwL7Y0OgJ",
    "id" : 464837761787105281,
    "created_at" : "2014-05-09 18:42:13 +0000",
    "user" : {
      "name" : "Mieke Kenis",
      "screen_name" : "mkofab",
      "protected" : false,
      "id_str" : "96527212",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/642333852199952385\/XKkzUhRv_normal.jpg",
      "id" : 96527212,
      "verified" : false
    }
  },
  "id" : 464850660262182914,
  "created_at" : "2014-05-09 19:33:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Claire Hardaker",
      "screen_name" : "DrClaireH",
      "indices" : [ 3, 13 ],
      "id_str" : "237842162",
      "id" : 237842162
    }, {
      "name" : "English & Media Ctr",
      "screen_name" : "EngMediaCentre",
      "indices" : [ 35, 50 ],
      "id_str" : "432590539",
      "id" : 432590539
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/5ICzczVaVv",
      "expanded_url" : "http:\/\/englishandmedia.wordpress.com\/2014\/05\/09\/putting-the-facts-straight-ocremcs-a-level-language-and-literature\/",
      "display_url" : "englishandmedia.wordpress.com\/2014\/05\/09\/put\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464836036091445248",
  "text" : "RT @DrClaireH: A super response by @EngMediaCentre to the frankly absurd hysteria in the media about the \"Russell Brand A Level\". http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "English & Media Ctr",
        "screen_name" : "EngMediaCentre",
        "indices" : [ 20, 35 ],
        "id_str" : "432590539",
        "id" : 432590539
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/5ICzczVaVv",
        "expanded_url" : "http:\/\/englishandmedia.wordpress.com\/2014\/05\/09\/putting-the-facts-straight-ocremcs-a-level-language-and-literature\/",
        "display_url" : "englishandmedia.wordpress.com\/2014\/05\/09\/put\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "464790204579319808",
    "text" : "A super response by @EngMediaCentre to the frankly absurd hysteria in the media about the \"Russell Brand A Level\". http:\/\/t.co\/5ICzczVaVv",
    "id" : 464790204579319808,
    "created_at" : "2014-05-09 15:33:14 +0000",
    "user" : {
      "name" : "Dr Claire Hardaker",
      "screen_name" : "DrClaireH",
      "protected" : false,
      "id_str" : "237842162",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744470254177390592\/ZhYTy0JE_normal.jpg",
      "id" : 237842162,
      "verified" : false
    }
  },
  "id" : 464836036091445248,
  "created_at" : "2014-05-09 18:35:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noor Adnan",
      "screen_name" : "n00rbaizura",
      "indices" : [ 0, 12 ],
      "id_str" : "412094121",
      "id" : 412094121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "464827868942319616",
  "geo" : { },
  "id_str" : "464830649636233216",
  "in_reply_to_user_id" : 412094121,
  "text" : "@n00rbaizura ah yeah true guess the \"genorosity\" of publishers limited!",
  "id" : 464830649636233216,
  "in_reply_to_status_id" : 464827868942319616,
  "created_at" : "2014-05-09 18:13:57 +0000",
  "in_reply_to_screen_name" : "n00rbaizura",
  "in_reply_to_user_id_str" : "412094121",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noor Adnan",
      "screen_name" : "n00rbaizura",
      "indices" : [ 0, 12 ],
      "id_str" : "412094121",
      "id" : 412094121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "464825957413433346",
  "geo" : { },
  "id_str" : "464827139691671552",
  "in_reply_to_user_id" : 412094121,
  "text" : "@n00rbaizura erm my last fav was not a book?",
  "id" : 464827139691671552,
  "in_reply_to_status_id" : 464825957413433346,
  "created_at" : "2014-05-09 18:00:00 +0000",
  "in_reply_to_screen_name" : "n00rbaizura",
  "in_reply_to_user_id_str" : "412094121",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil McMahon",
      "screen_name" : "mcneilmahon",
      "indices" : [ 34, 46 ],
      "id_str" : "23536576",
      "id" : 23536576
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "stringnet",
      "indices" : [ 0, 10 ]
    }, {
      "text" : "IHTOC6",
      "indices" : [ 11, 18 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/1UapjMydCU",
      "expanded_url" : "https:\/\/ihworld.adobeconnect.com\/_a1083514828\/ihto6afternoon\/?launcher=false&disclaimer-consent=true",
      "display_url" : "ihworld.adobeconnect.com\/_a1083514828\/i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464825781144006657",
  "text" : "#stringnet #IHTOC6 10 min talk by @mcneilmahon about to start https:\/\/t.co\/1UapjMydCU",
  "id" : 464825781144006657,
  "created_at" : "2014-05-09 17:54:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noor Adnan",
      "screen_name" : "n00rbaizura",
      "indices" : [ 0, 12 ],
      "id_str" : "412094121",
      "id" : 412094121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "464824864935641088",
  "geo" : { },
  "id_str" : "464825218645913601",
  "in_reply_to_user_id" : 412094121,
  "text" : "@n00rbaizura sorry what book?",
  "id" : 464825218645913601,
  "in_reply_to_status_id" : 464824864935641088,
  "created_at" : "2014-05-09 17:52:22 +0000",
  "in_reply_to_screen_name" : "n00rbaizura",
  "in_reply_to_user_id_str" : "412094121",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IHTOC6",
      "indices" : [ 13, 20 ]
    }, {
      "text" : "stringnet",
      "indices" : [ 27, 37 ]
    }, {
      "text" : "corpusmooc",
      "indices" : [ 79, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/k1TUXb6Wbg",
      "expanded_url" : "http:\/\/ihtocmay2014.blogspot.com.ar\/2014\/05\/stringing-students-along-neil-mcmahon.html",
      "display_url" : "ihtocmay2014.blogspot.com.ar\/2014\/05\/string\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464789170414977024",
  "text" : "last talk in #IHTOC6 is on #stringnet check slides here http:\/\/t.co\/k1TUXb6Wbg #corpusmooc",
  "id" : 464789170414977024,
  "created_at" : "2014-05-09 15:29:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chadsansing",
      "screen_name" : "chadsansing",
      "indices" : [ 3, 15 ],
      "id_str" : "76810409",
      "id" : 76810409
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "openschools",
      "indices" : [ 39, 51 ]
    }, {
      "text" : "teachtheweb",
      "indices" : [ 90, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/uTIDt5AxHc",
      "expanded_url" : "http:\/\/classroots.org\/2014\/05\/09\/on-net-neutrality-in-openschools\/",
      "display_url" : "classroots.org\/2014\/05\/09\/on-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464785108650979328",
  "text" : "RT @chadsansing: 'On Net Neutrality in #openschools' on Classroots http:\/\/t.co\/uTIDt5AxHc #teachtheweb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "openschools",
        "indices" : [ 22, 34 ]
      }, {
        "text" : "teachtheweb",
        "indices" : [ 73, 85 ]
      } ],
      "urls" : [ {
        "indices" : [ 50, 72 ],
        "url" : "http:\/\/t.co\/uTIDt5AxHc",
        "expanded_url" : "http:\/\/classroots.org\/2014\/05\/09\/on-net-neutrality-in-openschools\/",
        "display_url" : "classroots.org\/2014\/05\/09\/on-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "464778571450699776",
    "text" : "'On Net Neutrality in #openschools' on Classroots http:\/\/t.co\/uTIDt5AxHc #teachtheweb",
    "id" : 464778571450699776,
    "created_at" : "2014-05-09 14:47:01 +0000",
    "user" : {
      "name" : "chadsansing",
      "screen_name" : "chadsansing",
      "protected" : false,
      "id_str" : "76810409",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712740640111652869\/NvEwLRy__normal.jpg",
      "id" : 76810409,
      "verified" : false
    }
  },
  "id" : 464785108650979328,
  "created_at" : "2014-05-09 15:12:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Hilliger",
      "screen_name" : "epilepticrabbit",
      "indices" : [ 3, 19 ],
      "id_str" : "212475110",
      "id" : 212475110
    }, {
      "name" : "Mozilla Webmaker",
      "screen_name" : "Webmaker",
      "indices" : [ 44, 53 ],
      "id_str" : "1242429835",
      "id" : 1242429835
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeachTheWeb",
      "indices" : [ 123, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/jAO7rkGb7F",
      "expanded_url" : "http:\/\/mzl.la\/training",
      "display_url" : "mzl.la\/training"
    } ]
  },
  "geo" : { },
  "id_str" : "464731023063142400",
  "text" : "RT @epilepticrabbit: Have you signed up for @webmaker Training yet? The first course starts MONDAY! http:\/\/t.co\/jAO7rkGb7F #TeachTheWeb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mozilla Webmaker",
        "screen_name" : "Webmaker",
        "indices" : [ 23, 32 ],
        "id_str" : "1242429835",
        "id" : 1242429835
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TeachTheWeb",
        "indices" : [ 102, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/jAO7rkGb7F",
        "expanded_url" : "http:\/\/mzl.la\/training",
        "display_url" : "mzl.la\/training"
      } ]
    },
    "geo" : { },
    "id_str" : "464703930224873472",
    "text" : "Have you signed up for @webmaker Training yet? The first course starts MONDAY! http:\/\/t.co\/jAO7rkGb7F #TeachTheWeb",
    "id" : 464703930224873472,
    "created_at" : "2014-05-09 09:50:25 +0000",
    "user" : {
      "name" : "Laura Hilliger",
      "screen_name" : "epilepticrabbit",
      "protected" : false,
      "id_str" : "212475110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1161722291\/profilepic_normal.jpg",
      "id" : 212475110,
      "verified" : false
    }
  },
  "id" : 464731023063142400,
  "created_at" : "2014-05-09 11:38:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yasu",
      "screen_name" : "casualconc",
      "indices" : [ 0, 11 ],
      "id_str" : "132412691",
      "id" : 132412691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "464721366147928064",
  "in_reply_to_user_id" : 132412691,
  "text" : "@casualconc hi got a Q about casualconc on google groups if u get time to read it be great :) thx",
  "id" : 464721366147928064,
  "created_at" : "2014-05-09 10:59:42 +0000",
  "in_reply_to_screen_name" : "casualconc",
  "in_reply_to_user_id_str" : "132412691",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 0, 15 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/SwPc6Qzrse",
      "expanded_url" : "http:\/\/zeega.com\/126131",
      "display_url" : "zeega.com\/126131"
    } ]
  },
  "in_reply_to_status_id_str" : "464512349445959680",
  "geo" : { },
  "id_str" : "464516501786333185",
  "in_reply_to_user_id" : 334332424,
  "text" : "@GeoffreyJordan hi geoff u may enjoy this or not http:\/\/t.co\/SwPc6Qzrse :)",
  "id" : 464516501786333185,
  "in_reply_to_status_id" : 464512349445959680,
  "created_at" : "2014-05-08 21:25:38 +0000",
  "in_reply_to_screen_name" : "GeoffreyJordan",
  "in_reply_to_user_id_str" : "334332424",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 3, 18 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/R7Qre2t69O",
      "expanded_url" : "http:\/\/wp.me\/p3qkCB-Pt",
      "display_url" : "wp.me\/p3qkCB-Pt"
    } ]
  },
  "geo" : { },
  "id_str" : "464514708201287681",
  "text" : "RT @GeoffreyJordan: Blogging: Sense and\u00A0Nonsense http:\/\/t.co\/R7Qre2t69O",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 29, 51 ],
        "url" : "http:\/\/t.co\/R7Qre2t69O",
        "expanded_url" : "http:\/\/wp.me\/p3qkCB-Pt",
        "display_url" : "wp.me\/p3qkCB-Pt"
      } ]
    },
    "geo" : { },
    "id_str" : "464512349445959680",
    "text" : "Blogging: Sense and\u00A0Nonsense http:\/\/t.co\/R7Qre2t69O",
    "id" : 464512349445959680,
    "created_at" : "2014-05-08 21:09:08 +0000",
    "user" : {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "protected" : false,
      "id_str" : "334332424",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/455317817537986561\/SD4wNKO3_normal.jpeg",
      "id" : 334332424,
      "verified" : false
    }
  },
  "id" : 464514708201287681,
  "created_at" : "2014-05-08 21:18:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "indices" : [ 0, 12 ],
      "id_str" : "192437743",
      "id" : 192437743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "464496469509410816",
  "geo" : { },
  "id_str" : "464497322278522880",
  "in_reply_to_user_id" : 192437743,
  "text" : "@nathanghall if it was BBC they would parse it as \/PUTIN paper you\/ and declare he has annexed the photocopier :)",
  "id" : 464497322278522880,
  "in_reply_to_status_id" : 464496469509410816,
  "created_at" : "2014-05-08 20:09:26 +0000",
  "in_reply_to_screen_name" : "nathanghall",
  "in_reply_to_user_id_str" : "192437743",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 64, 80 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/FE9INRpqUl",
      "expanded_url" : "http:\/\/wp.me\/p2CPYN-cb",
      "display_url" : "wp.me\/p2CPYN-cb"
    } ]
  },
  "geo" : { },
  "id_str" : "464416153322786816",
  "text" : "International Justice, empire style. http:\/\/t.co\/FE9INRpqUl via @wordpressdotcom",
  "id" : 464416153322786816,
  "created_at" : "2014-05-08 14:46:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nic Subtirelu",
      "screen_name" : "linguisticpulse",
      "indices" : [ 3, 19 ],
      "id_str" : "1400748798",
      "id" : 1400748798
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sociolinguistics",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/2D8fK0AHQR",
      "expanded_url" : "http:\/\/bit.ly\/1iuRtL6",
      "display_url" : "bit.ly\/1iuRtL6"
    } ]
  },
  "geo" : { },
  "id_str" : "464396356569030657",
  "text" : "RT @linguisticpulse: Biased media descriptions of POC as ARTICULATE (http:\/\/t.co\/2D8fK0AHQR) Who is articulate?: Biased perceptions of lang\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "sociolinguistics",
        "indices" : [ 123, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 48, 70 ],
        "url" : "http:\/\/t.co\/2D8fK0AHQR",
        "expanded_url" : "http:\/\/bit.ly\/1iuRtL6",
        "display_url" : "bit.ly\/1iuRtL6"
      } ]
    },
    "geo" : { },
    "id_str" : "464393964410249216",
    "text" : "Biased media descriptions of POC as ARTICULATE (http:\/\/t.co\/2D8fK0AHQR) Who is articulate?: Biased perceptions of language #sociolinguistics",
    "id" : 464393964410249216,
    "created_at" : "2014-05-08 13:18:43 +0000",
    "user" : {
      "name" : "Nic Subtirelu",
      "screen_name" : "linguisticpulse",
      "protected" : false,
      "id_str" : "1400748798",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3609632834\/4ae2ef11e9cffa43e820f3ef7e18b016_normal.jpeg",
      "id" : 1400748798,
      "verified" : false
    }
  },
  "id" : 464396356569030657,
  "created_at" : "2014-05-08 13:28:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Chesnut",
      "screen_name" : "MichaelChesnut2",
      "indices" : [ 0, 16 ],
      "id_str" : "820940430",
      "id" : 820940430
    }, {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 17, 23 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "464322997222780928",
  "geo" : { },
  "id_str" : "464325110581977088",
  "in_reply_to_user_id" : 820940430,
  "text" : "@MichaelChesnut2 @ebefl lol i got answers other way round! ogden?",
  "id" : 464325110581977088,
  "in_reply_to_status_id" : 464322997222780928,
  "created_at" : "2014-05-08 08:45:07 +0000",
  "in_reply_to_screen_name" : "MichaelChesnut2",
  "in_reply_to_user_id_str" : "820940430",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 0, 15 ],
      "id_str" : "285614027",
      "id" : 285614027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "464229157560258562",
  "geo" : { },
  "id_str" : "464319978985242624",
  "in_reply_to_user_id" : 285614027,
  "text" : "@AnthonyTeacher that article is great isn't it? John Higgins worked with Tim Johns",
  "id" : 464319978985242624,
  "in_reply_to_status_id" : 464229157560258562,
  "created_at" : "2014-05-08 08:24:44 +0000",
  "in_reply_to_screen_name" : "AnthonyTeacher",
  "in_reply_to_user_id_str" : "285614027",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 3, 18 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/NvXCpUqO7H",
      "expanded_url" : "http:\/\/wp.me\/p3qkCB-O1",
      "display_url" : "wp.me\/p3qkCB-O1"
    } ]
  },
  "geo" : { },
  "id_str" : "464318005577408512",
  "text" : "RT @GeoffreyJordan: Criticisms of The Monitor\u00A0Model http:\/\/t.co\/NvXCpUqO7H",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 32, 54 ],
        "url" : "http:\/\/t.co\/NvXCpUqO7H",
        "expanded_url" : "http:\/\/wp.me\/p3qkCB-O1",
        "display_url" : "wp.me\/p3qkCB-O1"
      } ]
    },
    "geo" : { },
    "id_str" : "464298442827640832",
    "text" : "Criticisms of The Monitor\u00A0Model http:\/\/t.co\/NvXCpUqO7H",
    "id" : 464298442827640832,
    "created_at" : "2014-05-08 06:59:09 +0000",
    "user" : {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "protected" : false,
      "id_str" : "334332424",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/455317817537986561\/SD4wNKO3_normal.jpeg",
      "id" : 334332424,
      "verified" : false
    }
  },
  "id" : 464318005577408512,
  "created_at" : "2014-05-08 08:16:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ellensclass",
      "screen_name" : "ellensclass",
      "indices" : [ 3, 15 ],
      "id_str" : "451058137",
      "id" : 451058137
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/t2GCVjEmYk",
      "expanded_url" : "http:\/\/wp.me\/p3KAlG-AC",
      "display_url" : "wp.me\/p3KAlG-AC"
    } ]
  },
  "geo" : { },
  "id_str" : "464178942581440512",
  "text" : "RT @ellensclass: Sweet Search http:\/\/t.co\/t2GCVjEmYk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 13, 35 ],
        "url" : "http:\/\/t.co\/t2GCVjEmYk",
        "expanded_url" : "http:\/\/wp.me\/p3KAlG-AC",
        "display_url" : "wp.me\/p3KAlG-AC"
      } ]
    },
    "geo" : { },
    "id_str" : "464168378370772992",
    "text" : "Sweet Search http:\/\/t.co\/t2GCVjEmYk",
    "id" : 464168378370772992,
    "created_at" : "2014-05-07 22:22:19 +0000",
    "user" : {
      "name" : "ellensclass",
      "screen_name" : "ellensclass",
      "protected" : false,
      "id_str" : "451058137",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1724689649\/NYThatWay_normal.jpg",
      "id" : 451058137,
      "verified" : false
    }
  },
  "id" : 464178942581440512,
  "created_at" : "2014-05-07 23:04:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Ash FRSA",
      "screen_name" : "Ashowski",
      "indices" : [ 0, 9 ],
      "id_str" : "316596356",
      "id" : 316596356
    }, {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 10, 25 ],
      "id_str" : "285614027",
      "id" : 285614027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/ihpOz5ZduU",
      "expanded_url" : "http:\/\/myweb.tiscali.co.uk\/wordscape\/wordlist\/fuelforlearning.html",
      "display_url" : "myweb.tiscali.co.uk\/wordscape\/word\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "464005094594605056",
  "geo" : { },
  "id_str" : "464169542428938240",
  "in_reply_to_user_id" : 316596356,
  "text" : "@Ashowski @AnthonyTeacher or diddle\/doddle :) http:\/\/t.co\/ihpOz5ZduU",
  "id" : 464169542428938240,
  "in_reply_to_status_id" : 464005094594605056,
  "created_at" : "2014-05-07 22:26:57 +0000",
  "in_reply_to_screen_name" : "Ashowski",
  "in_reply_to_user_id_str" : "316596356",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 3, 12 ],
      "id_str" : "134211317",
      "id" : 134211317
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 22, 26 ]
    }, {
      "text" : "tefl",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/dzFksazYET",
      "expanded_url" : "http:\/\/goo.gl\/9X6hIZ",
      "display_url" : "goo.gl\/9X6hIZ"
    } ]
  },
  "geo" : { },
  "id_str" : "464160606346805248",
  "text" : "RT @josipa74: Calling #elt teachers! Do you think a 'Teachers As Workers' SIG is a good idea? Vote at http:\/\/t.co\/dzFksazYET  and plz share\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "elt",
        "indices" : [ 8, 12 ]
      }, {
        "text" : "tefl",
        "indices" : [ 127, 132 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/dzFksazYET",
        "expanded_url" : "http:\/\/goo.gl\/9X6hIZ",
        "display_url" : "goo.gl\/9X6hIZ"
      } ]
    },
    "geo" : { },
    "id_str" : "464159871378948096",
    "text" : "Calling #elt teachers! Do you think a 'Teachers As Workers' SIG is a good idea? Vote at http:\/\/t.co\/dzFksazYET  and plz share! #tefl",
    "id" : 464159871378948096,
    "created_at" : "2014-05-07 21:48:31 +0000",
    "user" : {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "protected" : false,
      "id_str" : "134211317",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/526853654377021441\/MtEFhYIs_normal.jpeg",
      "id" : 134211317,
      "verified" : false
    }
  },
  "id" : 464160606346805248,
  "created_at" : "2014-05-07 21:51:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike S. Boyle",
      "screen_name" : "heyboyle",
      "indices" : [ 0, 9 ],
      "id_str" : "612840231",
      "id" : 612840231
    }, {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 10, 16 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "464155850970374144",
  "geo" : { },
  "id_str" : "464156433530253312",
  "in_reply_to_user_id" : 612840231,
  "text" : "@heyboyle @ebefl corrections require that they are regard themselves as journalists :) no no idea if they have or not",
  "id" : 464156433530253312,
  "in_reply_to_status_id" : 464155850970374144,
  "created_at" : "2014-05-07 21:34:52 +0000",
  "in_reply_to_screen_name" : "heyboyle",
  "in_reply_to_user_id_str" : "612840231",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/mvqXIIKT1X",
      "expanded_url" : "http:\/\/www.dailymail.co.uk\/news\/article-2540955\/Beijing-clouded-smog-way-sunrise-watch-giant-commercial-screens-Tiananmen-Square.html",
      "display_url" : "dailymail.co.uk\/news\/article-2\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "464142170967252992",
  "geo" : { },
  "id_str" : "464154011198062592",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl from the people who brought such hits as http:\/\/t.co\/mvqXIIKT1X",
  "id" : 464154011198062592,
  "in_reply_to_status_id" : 464142170967252992,
  "created_at" : "2014-05-07 21:25:14 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Harrison Photo",
      "screen_name" : "mjhfoto",
      "indices" : [ 0, 8 ],
      "id_str" : "2415859058",
      "id" : 2415859058
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/oISM7bH1Vw",
      "expanded_url" : "https:\/\/pbs.twimg.com\/media\/Bm9QlCsIAAAiZIL.png:large",
      "display_url" : "pbs.twimg.com\/media\/Bm9QlCsI\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "464127189412495360",
  "geo" : { },
  "id_str" : "464131130565099520",
  "in_reply_to_user_id" : 2415859058,
  "text" : "@mjhfoto @mikejhldn probably planning it's next power grid takedown :) https:\/\/t.co\/oISM7bH1Vw",
  "id" : 464131130565099520,
  "in_reply_to_status_id" : 464127189412495360,
  "created_at" : "2014-05-07 19:54:19 +0000",
  "in_reply_to_screen_name" : "mjhfoto",
  "in_reply_to_user_id_str" : "2415859058",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/464124044800192513\/photo\/1",
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/Sngtx81GA9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BnDmWwZIgAAj4gO.png",
      "id_str" : "464124040240988160",
      "id" : 464124040240988160,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnDmWwZIgAAj4gO.png",
      "sizes" : [ {
        "h" : 332,
        "resize" : "fit",
        "w" : 715
      }, {
        "h" : 158,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 332,
        "resize" : "fit",
        "w" : 715
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 279,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/Sngtx81GA9"
    } ],
    "hashtags" : [ {
      "text" : "projectnapthaiscool",
      "indices" : [ 17, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "464124044800192513",
  "text" : "RT if u agree :\/ #projectnapthaiscool http:\/\/t.co\/Sngtx81GA9",
  "id" : 464124044800192513,
  "created_at" : "2014-05-07 19:26:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicola Prentis",
      "screen_name" : "NicolaPrentis",
      "indices" : [ 3, 17 ],
      "id_str" : "810667033",
      "id" : 810667033
    }, {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 43, 52 ],
      "id_str" : "134211317",
      "id" : 134211317
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iatefl",
      "indices" : [ 110, 117 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 118, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "464066551977869312",
  "text" : "RT @NicolaPrentis: 5 sec survey created by @josipa74 Do you think a \"Teachers as Workers\" SIG is a good idea? #iatefl #eltchat I say a big \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "paulw",
        "screen_name" : "josipa74",
        "indices" : [ 24, 33 ],
        "id_str" : "134211317",
        "id" : 134211317
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "iatefl",
        "indices" : [ 91, 98 ]
      }, {
        "text" : "eltchat",
        "indices" : [ 99, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "464061212003958784",
    "text" : "5 sec survey created by @josipa74 Do you think a \"Teachers as Workers\" SIG is a good idea? #iatefl #eltchat I say a big fat YES",
    "id" : 464061212003958784,
    "created_at" : "2014-05-07 15:16:29 +0000",
    "user" : {
      "name" : "Nicola Prentis",
      "screen_name" : "NicolaPrentis",
      "protected" : false,
      "id_str" : "810667033",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3046181441\/a51ef543c16ff30fdb8966f23237790d_normal.jpeg",
      "id" : 810667033,
      "verified" : false
    }
  },
  "id" : 464066551977869312,
  "created_at" : "2014-05-07 15:37:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hana Tich\u00E1",
      "screen_name" : "HanaTicha",
      "indices" : [ 0, 10 ],
      "id_str" : "512296705",
      "id" : 512296705
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "464046691872550912",
  "geo" : { },
  "id_str" : "464051820055527424",
  "in_reply_to_user_id" : 512296705,
  "text" : "@HanaTicha thx suggestions welcome :)",
  "id" : 464051820055527424,
  "in_reply_to_status_id" : 464046691872550912,
  "created_at" : "2014-05-07 14:39:10 +0000",
  "in_reply_to_screen_name" : "HanaTicha",
  "in_reply_to_user_id_str" : "512296705",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 55, 71 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/9nyCxtHI0k",
      "expanded_url" : "http:\/\/wp.me\/p2CPYN-c0",
      "display_url" : "wp.me\/p2CPYN-c0"
    } ]
  },
  "geo" : { },
  "id_str" : "464045039543283713",
  "text" : "Exterminate All The Brutes! http:\/\/t.co\/9nyCxtHI0k via @wordpressdotcom",
  "id" : 464045039543283713,
  "created_at" : "2014-05-07 14:12:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/H8mOgGgHhc",
      "expanded_url" : "http:\/\/tm.durusau.net\/?p=52811",
      "display_url" : "tm.durusau.net\/?p=52811"
    } ]
  },
  "geo" : { },
  "id_str" : "464028034337886209",
  "text" : "Cyberterrorists vs. Squirrels http:\/\/t.co\/H8mOgGgHhc",
  "id" : 464028034337886209,
  "created_at" : "2014-05-07 13:04:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "464022836982472705",
  "geo" : { },
  "id_str" : "464023767744667648",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin cheers mike let me know what to add :)",
  "id" : 464023767744667648,
  "in_reply_to_status_id" : 464022836982472705,
  "created_at" : "2014-05-07 12:47:42 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike S. Boyle",
      "screen_name" : "heyboyle",
      "indices" : [ 3, 12 ],
      "id_str" : "612840231",
      "id" : 612840231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 140 ],
      "url" : "http:\/\/t.co\/uzGslbPLZS",
      "expanded_url" : "http:\/\/www.macmillanenglish.com\/event\/mike-boyle-skills-for-academic-success\/",
      "display_url" : "macmillanenglish.com\/event\/mike-boy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464017699509506049",
  "text" : "RT @heyboyle: Join me for a FREE webinar at 3pm UK time TODAY: Essential Skills for Academic Success -- register here: http:\/\/t.co\/uzGslbPL\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/uzGslbPLZS",
        "expanded_url" : "http:\/\/www.macmillanenglish.com\/event\/mike-boyle-skills-for-academic-success\/",
        "display_url" : "macmillanenglish.com\/event\/mike-boy\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "463706395292868608",
    "geo" : { },
    "id_str" : "464016643463454721",
    "in_reply_to_user_id" : 612840231,
    "text" : "Join me for a FREE webinar at 3pm UK time TODAY: Essential Skills for Academic Success -- register here: http:\/\/t.co\/uzGslbPLZS",
    "id" : 464016643463454721,
    "in_reply_to_status_id" : 463706395292868608,
    "created_at" : "2014-05-07 12:19:23 +0000",
    "in_reply_to_screen_name" : "heyboyle",
    "in_reply_to_user_id_str" : "612840231",
    "user" : {
      "name" : "Mike S. Boyle",
      "screen_name" : "heyboyle",
      "protected" : false,
      "id_str" : "612840231",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/604115272849575936\/ln05gCwx_normal.jpg",
      "id" : 612840231,
      "verified" : false
    }
  },
  "id" : 464017699509506049,
  "created_at" : "2014-05-07 12:23:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELTjam",
      "screen_name" : "eltjam",
      "indices" : [ 59, 66 ],
      "id_str" : "1356363686",
      "id" : 1356363686
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elttalkbingo",
      "indices" : [ 9, 22 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 70, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/C0IDLT30FE",
      "expanded_url" : "http:\/\/49ad644b0c.url-de-test.ws\/newcard.html",
      "display_url" : "49ad644b0c.url-de-test.ws\/newcard.html"
    } ]
  },
  "geo" : { },
  "id_str" : "464011838012006400",
  "text" : "play the #elttalkbingo http:\/\/t.co\/C0IDLT30FE  inspired by @eltjam :) #eltchat",
  "id" : 464011838012006400,
  "created_at" : "2014-05-07 12:00:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BBC News Magazine",
      "screen_name" : "BBCNewsMagazine",
      "indices" : [ 0, 16 ],
      "id_str" : "14697685",
      "id" : 14697685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/HPZODvh5bW",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Mat_%28Russian_profanity%29#cite_note-1",
      "display_url" : "en.wikipedia.org\/wiki\/Mat_%28Ru\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "463644747970924544",
  "geo" : { },
  "id_str" : "463935582000140288",
  "in_reply_to_user_id" : 14697685,
  "text" : "@BBCNewsMagazine it shurely must have crossed paths with a BBC overeggingbot over the last 10 years http:\/\/t.co\/HPZODvh5bW",
  "id" : 463935582000140288,
  "in_reply_to_status_id" : 463644747970924544,
  "created_at" : "2014-05-07 06:57:16 +0000",
  "in_reply_to_screen_name" : "BBCNewsMagazine",
  "in_reply_to_user_id_str" : "14697685",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beatrice Reed",
      "screen_name" : "BB_Reed",
      "indices" : [ 0, 8 ],
      "id_str" : "2502542837",
      "id" : 2502542837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/BuV1IB1yl3",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Mat_%28Russian_profanity%29#cite_note-1",
      "display_url" : "en.wikipedia.org\/wiki\/Mat_%28Ru\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "463918820395331585",
  "geo" : { },
  "id_str" : "463934703137853443",
  "in_reply_to_user_id" : 2502542837,
  "text" : "@BB_Reed a swearbot must have been patrolling for at 10 years http:\/\/t.co\/BuV1IB1yl3, must have crossed a BBC overeggingbot at a point",
  "id" : 463934703137853443,
  "in_reply_to_status_id" : 463918820395331585,
  "created_at" : "2014-05-07 06:53:47 +0000",
  "in_reply_to_screen_name" : "BB_Reed",
  "in_reply_to_user_id_str" : "2502542837",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roxane Harrison",
      "screen_name" : "roxaneharrison",
      "indices" : [ 0, 15 ],
      "id_str" : "267494842",
      "id" : 267494842
    }, {
      "name" : "Noor Adnan",
      "screen_name" : "n00rbaizura",
      "indices" : [ 16, 28 ],
      "id_str" : "412094121",
      "id" : 412094121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "463933150385950720",
  "in_reply_to_user_id" : 267494842,
  "text" : "@roxaneharrison @n00rbaizura thanks for RT :)",
  "id" : 463933150385950720,
  "created_at" : "2014-05-07 06:47:37 +0000",
  "in_reply_to_screen_name" : "roxaneharrison",
  "in_reply_to_user_id_str" : "267494842",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 56, 72 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/geLrBKdgP5",
      "expanded_url" : "http:\/\/wp.me\/p3augf-dz",
      "display_url" : "wp.me\/p3augf-dz"
    } ]
  },
  "geo" : { },
  "id_str" : "463796148323364866",
  "text" : "What do we mean by \"I mean\"? http:\/\/t.co\/geLrBKdgP5 via @wordpressdotcom",
  "id" : 463796148323364866,
  "created_at" : "2014-05-06 21:43:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NewSchool",
      "indices" : [ 27, 37 ]
    }, {
      "text" : "corpusmooc",
      "indices" : [ 85, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/pMhav29uQi",
      "expanded_url" : "https:\/\/plus.google.com\/104940199413423400545\/posts\/YKiLX2F61db",
      "display_url" : "plus.google.com\/10494019941342\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463792768695803904",
  "text" : "v quick review and link to #NewSchool talk Corpus Confidence https:\/\/t.co\/pMhav29uQi #corpusmooc",
  "id" : 463792768695803904,
  "created_at" : "2014-05-06 21:29:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELTjam",
      "screen_name" : "eltjam",
      "indices" : [ 3, 10 ],
      "id_str" : "1356363686",
      "id" : 1356363686
    }, {
      "name" : "Lindsay Clandfield",
      "screen_name" : "lclandfield",
      "indices" : [ 33, 45 ],
      "id_str" : "30663558",
      "id" : 30663558
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELT",
      "indices" : [ 66, 70 ]
    }, {
      "text" : "EdTech",
      "indices" : [ 71, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/9x8wo9Y8Gw",
      "expanded_url" : "http:\/\/www.eltjam.com\/six-cool-tropes-in-elt-edtech\/",
      "display_url" : "eltjam.com\/six-cool-trope\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463683812929839104",
  "text" : "RT @eltjam: New on the blog from @lclandfield! Six Cool Tropes in #ELT #EdTech http:\/\/t.co\/9x8wo9Y8Gw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lindsay Clandfield",
        "screen_name" : "lclandfield",
        "indices" : [ 21, 33 ],
        "id_str" : "30663558",
        "id" : 30663558
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELT",
        "indices" : [ 54, 58 ]
      }, {
        "text" : "EdTech",
        "indices" : [ 59, 66 ]
      } ],
      "urls" : [ {
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/9x8wo9Y8Gw",
        "expanded_url" : "http:\/\/www.eltjam.com\/six-cool-tropes-in-elt-edtech\/",
        "display_url" : "eltjam.com\/six-cool-trope\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "463626334733082624",
    "text" : "New on the blog from @lclandfield! Six Cool Tropes in #ELT #EdTech http:\/\/t.co\/9x8wo9Y8Gw",
    "id" : 463626334733082624,
    "created_at" : "2014-05-06 10:28:26 +0000",
    "user" : {
      "name" : "ELTjam",
      "screen_name" : "eltjam",
      "protected" : false,
      "id_str" : "1356363686",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700706017441554432\/vqyiSHTx_normal.png",
      "id" : 1356363686,
      "verified" : false
    }
  },
  "id" : 463683812929839104,
  "created_at" : "2014-05-06 14:16:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Alexander",
      "screen_name" : "BryanAlexander",
      "indices" : [ 3, 18 ],
      "id_str" : "755991",
      "id" : 755991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/97rSoliqg5",
      "expanded_url" : "http:\/\/wp.me\/p5oc-1yC",
      "display_url" : "wp.me\/p5oc-1yC"
    } ]
  },
  "geo" : { },
  "id_str" : "463599781328478208",
  "text" : "RT @BryanAlexander: Piketty on higher\u00A0education http:\/\/t.co\/97rSoliqg5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 28, 50 ],
        "url" : "http:\/\/t.co\/97rSoliqg5",
        "expanded_url" : "http:\/\/wp.me\/p5oc-1yC",
        "display_url" : "wp.me\/p5oc-1yC"
      } ]
    },
    "geo" : { },
    "id_str" : "463340484274843651",
    "text" : "Piketty on higher\u00A0education http:\/\/t.co\/97rSoliqg5",
    "id" : 463340484274843651,
    "created_at" : "2014-05-05 15:32:34 +0000",
    "user" : {
      "name" : "Bryan Alexander",
      "screen_name" : "BryanAlexander",
      "protected" : false,
      "id_str" : "755991",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/654391499686313986\/1Fx2eBCq_normal.jpg",
      "id" : 755991,
      "verified" : false
    }
  },
  "id" : 463599781328478208,
  "created_at" : "2014-05-06 08:42:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Champion",
      "screen_name" : "_ElChampion",
      "indices" : [ 0, 12 ],
      "id_str" : "435117701",
      "id" : 435117701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/HPZODvh5bW",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Mat_%28Russian_profanity%29#cite_note-1",
      "display_url" : "en.wikipedia.org\/wiki\/Mat_%28Ru\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "463461004190699520",
  "geo" : { },
  "id_str" : "463462923458080768",
  "in_reply_to_user_id" : 435117701,
  "text" : "@_ElChampion been \"pathetic\" since at least 2003 http:\/\/t.co\/HPZODvh5bW",
  "id" : 463462923458080768,
  "in_reply_to_status_id" : 463461004190699520,
  "created_at" : "2014-05-05 23:39:06 +0000",
  "in_reply_to_screen_name" : "_ElChampion",
  "in_reply_to_user_id_str" : "435117701",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Cole",
      "screen_name" : "MerryOldCole",
      "indices" : [ 0, 13 ],
      "id_str" : "302904759",
      "id" : 302904759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/HPZODvh5bW",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Mat_%28Russian_profanity%29#cite_note-1",
      "display_url" : "en.wikipedia.org\/wiki\/Mat_%28Ru\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "463454697831940097",
  "geo" : { },
  "id_str" : "463462793828900864",
  "in_reply_to_user_id" : 302904759,
  "text" : "@MerryOldCole dont know but it's been going on since 2003 at least http:\/\/t.co\/HPZODvh5bW",
  "id" : 463462793828900864,
  "in_reply_to_status_id" : 463454697831940097,
  "created_at" : "2014-05-05 23:38:35 +0000",
  "in_reply_to_screen_name" : "MerryOldCole",
  "in_reply_to_user_id_str" : "302904759",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Casey Mac",
      "screen_name" : "WordOfCase",
      "indices" : [ 0, 11 ],
      "id_str" : "269503597",
      "id" : 269503597
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463454796301619200",
  "geo" : { },
  "id_str" : "463455278101721088",
  "in_reply_to_user_id" : 269503597,
  "text" : "@WordOfCase ah the world of no tweets, halcyon days :\/",
  "id" : 463455278101721088,
  "in_reply_to_status_id" : 463454796301619200,
  "created_at" : "2014-05-05 23:08:43 +0000",
  "in_reply_to_screen_name" : "WordOfCase",
  "in_reply_to_user_id_str" : "269503597",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/HPZODvh5bW",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Mat_%28Russian_profanity%29#cite_note-1",
      "display_url" : "en.wikipedia.org\/wiki\/Mat_%28Ru\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "463453479919296512",
  "geo" : { },
  "id_str" : "463453903875735552",
  "in_reply_to_user_id" : 1464559975,
  "text" : "@banjolasse_ been going wrong places since at least 2003 apparently http:\/\/t.co\/HPZODvh5bW",
  "id" : 463453903875735552,
  "in_reply_to_status_id" : 463453479919296512,
  "created_at" : "2014-05-05 23:03:15 +0000",
  "in_reply_to_screen_name" : "superbanjolasse",
  "in_reply_to_user_id_str" : "1464559975",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina K...",
      "screen_name" : "NoTranslations",
      "indices" : [ 0, 15 ],
      "id_str" : "2423297911",
      "id" : 2423297911
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463452973113573377",
  "geo" : { },
  "id_str" : "463453583321866240",
  "in_reply_to_user_id" : 2423297911,
  "text" : "@NoTranslations so u can apply again and perform again?",
  "id" : 463453583321866240,
  "in_reply_to_status_id" : 463452973113573377,
  "created_at" : "2014-05-05 23:01:59 +0000",
  "in_reply_to_screen_name" : "NoTranslations",
  "in_reply_to_user_id_str" : "2423297911",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina K...",
      "screen_name" : "NoTranslations",
      "indices" : [ 0, 15 ],
      "id_str" : "2423297911",
      "id" : 2423297911
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/HPZODvh5bW",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Mat_%28Russian_profanity%29#cite_note-1",
      "display_url" : "en.wikipedia.org\/wiki\/Mat_%28Ru\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "463452176539340801",
  "geo" : { },
  "id_str" : "463452696914440193",
  "in_reply_to_user_id" : 2423297911,
  "text" : "@NoTranslations could u have performed in 2003? http:\/\/t.co\/HPZODvh5bW",
  "id" : 463452696914440193,
  "in_reply_to_status_id" : 463452176539340801,
  "created_at" : "2014-05-05 22:58:28 +0000",
  "in_reply_to_screen_name" : "NoTranslations",
  "in_reply_to_user_id_str" : "2423297911",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Matt Osborne)))",
      "screen_name" : "OsborneInk",
      "indices" : [ 0, 11 ],
      "id_str" : "63065243",
      "id" : 63065243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/HPZODvh5bW",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Mat_%28Russian_profanity%29#cite_note-1",
      "display_url" : "en.wikipedia.org\/wiki\/Mat_%28Ru\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "459110123684651008",
  "geo" : { },
  "id_str" : "463452326939074560",
  "in_reply_to_user_id" : 63065243,
  "text" : "@OsborneInk should have paged him in 2003 http:\/\/t.co\/HPZODvh5bW",
  "id" : 463452326939074560,
  "in_reply_to_status_id" : 459110123684651008,
  "created_at" : "2014-05-05 22:56:59 +0000",
  "in_reply_to_screen_name" : "OsborneInk",
  "in_reply_to_user_id_str" : "63065243",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Al Federber",
      "screen_name" : "al_federber",
      "indices" : [ 0, 12 ],
      "id_str" : "2349324164",
      "id" : 2349324164
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/HPZODvh5bW",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Mat_%28Russian_profanity%29#cite_note-1",
      "display_url" : "en.wikipedia.org\/wiki\/Mat_%28Ru\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "463450645249269760",
  "geo" : { },
  "id_str" : "463451618001055744",
  "in_reply_to_user_id" : 2349324164,
  "text" : "@al_federber yr scheme was dead since at least 2003 http:\/\/t.co\/HPZODvh5bW",
  "id" : 463451618001055744,
  "in_reply_to_status_id" : 463450645249269760,
  "created_at" : "2014-05-05 22:54:10 +0000",
  "in_reply_to_screen_name" : "al_federber",
  "in_reply_to_user_id_str" : "2349324164",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Telly Monster",
      "screen_name" : "spenasy3",
      "indices" : [ 0, 9 ],
      "id_str" : "318163161",
      "id" : 318163161
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/HPZODvh5bW",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Mat_%28Russian_profanity%29#cite_note-1",
      "display_url" : "en.wikipedia.org\/wiki\/Mat_%28Ru\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "463449403009675264",
  "geo" : { },
  "id_str" : "463451509003657216",
  "in_reply_to_user_id" : 318163161,
  "text" : "@spenasy3 been happening since 2003 http:\/\/t.co\/HPZODvh5bW",
  "id" : 463451509003657216,
  "in_reply_to_status_id" : 463449403009675264,
  "created_at" : "2014-05-05 22:53:44 +0000",
  "in_reply_to_screen_name" : "spenasy3",
  "in_reply_to_user_id_str" : "318163161",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "indices" : [ 0, 12 ],
      "id_str" : "849729062",
      "id" : 849729062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/HPZODvh5bW",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Mat_%28Russian_profanity%29#cite_note-1",
      "display_url" : "en.wikipedia.org\/wiki\/Mat_%28Ru\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "463441003975045120",
  "geo" : { },
  "id_str" : "463449419309150210",
  "in_reply_to_user_id" : 849729062,
  "text" : "@TonyMcEnery this is ref to 2003 law http:\/\/t.co\/HPZODvh5bW",
  "id" : 463449419309150210,
  "in_reply_to_status_id" : 463441003975045120,
  "created_at" : "2014-05-05 22:45:26 +0000",
  "in_reply_to_screen_name" : "TonyMcEnery",
  "in_reply_to_user_id_str" : "849729062",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stan Carey",
      "screen_name" : "StanCarey",
      "indices" : [ 0, 10 ],
      "id_str" : "34347535",
      "id" : 34347535
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/HPZODvh5bW",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Mat_%28Russian_profanity%29#cite_note-1",
      "display_url" : "en.wikipedia.org\/wiki\/Mat_%28Ru\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "463396272112930816",
  "geo" : { },
  "id_str" : "463448607262515201",
  "in_reply_to_user_id" : 34347535,
  "text" : "@StanCarey how's it different from 2003 law FFS http:\/\/t.co\/HPZODvh5bW ?",
  "id" : 463448607262515201,
  "in_reply_to_status_id" : 463396272112930816,
  "created_at" : "2014-05-05 22:42:13 +0000",
  "in_reply_to_screen_name" : "StanCarey",
  "in_reply_to_user_id_str" : "34347535",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nachikethass Bharat",
      "screen_name" : "nachikethass",
      "indices" : [ 0, 13 ],
      "id_str" : "48088306",
      "id" : 48088306
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/HPZODvh5bW",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Mat_%28Russian_profanity%29#cite_note-1",
      "display_url" : "en.wikipedia.org\/wiki\/Mat_%28Ru\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "463445750391656448",
  "geo" : { },
  "id_str" : "463446116231819264",
  "in_reply_to_user_id" : 48088306,
  "text" : "@nachikethass must have been letting him off for at least 10 years http:\/\/t.co\/HPZODvh5bW",
  "id" : 463446116231819264,
  "in_reply_to_status_id" : 463445750391656448,
  "created_at" : "2014-05-05 22:32:19 +0000",
  "in_reply_to_screen_name" : "nachikethass",
  "in_reply_to_user_id_str" : "48088306",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Perry Sullivan",
      "screen_name" : "PerryArtist",
      "indices" : [ 0, 12 ],
      "id_str" : "2819565916",
      "id" : 2819565916
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/HPZODvh5bW",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Mat_%28Russian_profanity%29#cite_note-1",
      "display_url" : "en.wikipedia.org\/wiki\/Mat_%28Ru\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463445908911579136",
  "text" : "@PerryArtist \"dragging back to dark ages\" since at least 2003 when swear law in effect http:\/\/t.co\/HPZODvh5bW",
  "id" : 463445908911579136,
  "created_at" : "2014-05-05 22:31:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Casey Mac",
      "screen_name" : "WordOfCase",
      "indices" : [ 0, 11 ],
      "id_str" : "269503597",
      "id" : 269503597
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/HPZODvh5bW",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Mat_%28Russian_profanity%29#cite_note-1",
      "display_url" : "en.wikipedia.org\/wiki\/Mat_%28Ru\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "463444505048256512",
  "geo" : { },
  "id_str" : "463445588525477889",
  "in_reply_to_user_id" : 269503597,
  "text" : "@WordOfCase how's it different from 2003 law? http:\/\/t.co\/HPZODvh5bW",
  "id" : 463445588525477889,
  "in_reply_to_status_id" : 463444505048256512,
  "created_at" : "2014-05-05 22:30:13 +0000",
  "in_reply_to_screen_name" : "WordOfCase",
  "in_reply_to_user_id_str" : "269503597",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "indices" : [ 0, 12 ],
      "id_str" : "849729062",
      "id" : 849729062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/6T7GDCgHNy",
      "expanded_url" : "http:\/\/www.theguardian.com\/football\/2009\/may\/18\/seven-deadly-sins-football-russia-wales-wrath",
      "display_url" : "theguardian.com\/football\/2009\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "463441003975045120",
  "geo" : { },
  "id_str" : "463443681740349440",
  "in_reply_to_user_id" : 849729062,
  "text" : "@TonyMcEnery been doing it over 10yrs since 2003 apparently http:\/\/t.co\/6T7GDCgHNy",
  "id" : 463443681740349440,
  "in_reply_to_status_id" : 463441003975045120,
  "created_at" : "2014-05-05 22:22:38 +0000",
  "in_reply_to_screen_name" : "TonyMcEnery",
  "in_reply_to_user_id_str" : "849729062",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 61, 77 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/widiHWdkTD",
      "expanded_url" : "http:\/\/wp.me\/p1Ayq4-6L",
      "display_url" : "wp.me\/p1Ayq4-6L"
    } ]
  },
  "geo" : { },
  "id_str" : "463300541896867840",
  "text" : "3, 6, 9- Step 1: Cultural Capital http:\/\/t.co\/widiHWdkTD via @wordpressdotcom",
  "id" : 463300541896867840,
  "created_at" : "2014-05-05 12:53:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Belma",
      "screen_name" : "KiwiBelma",
      "indices" : [ 0, 10 ],
      "id_str" : "144092431",
      "id" : 144092431
    }, {
      "name" : "Silvia K. Spiva",
      "screen_name" : "silviakspiva",
      "indices" : [ 11, 24 ],
      "id_str" : "185898176",
      "id" : 185898176
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463269623748505600",
  "geo" : { },
  "id_str" : "463299330502586368",
  "in_reply_to_user_id" : 144092431,
  "text" : "@KiwiBelma @silviakspiva would have thought mainframes were the true daddies (&amp; less funky nomenclature) to \"cloud\" computing? :)",
  "id" : 463299330502586368,
  "in_reply_to_status_id" : 463269623748505600,
  "created_at" : "2014-05-05 12:49:02 +0000",
  "in_reply_to_screen_name" : "KiwiBelma",
  "in_reply_to_user_id_str" : "144092431",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Magnus Nissel",
      "screen_name" : "u203d",
      "indices" : [ 0, 6 ],
      "id_str" : "533114985",
      "id" : 533114985
    }, {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "indices" : [ 7, 18 ],
      "id_str" : "152051625",
      "id" : 152051625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463038740810960896",
  "geo" : { },
  "id_str" : "463048839990358016",
  "in_reply_to_user_id" : 533114985,
  "text" : "@u203d @heatherfro well anything linking to nltk is not all bad :)",
  "id" : 463048839990358016,
  "in_reply_to_status_id" : 463038740810960896,
  "created_at" : "2014-05-04 20:13:41 +0000",
  "in_reply_to_screen_name" : "u203d",
  "in_reply_to_user_id_str" : "533114985",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kat Gupta",
      "screen_name" : "mixosaurus",
      "indices" : [ 0, 11 ],
      "id_str" : "21158543",
      "id" : 21158543
    }, {
      "name" : "Magnus Nissel",
      "screen_name" : "u203d",
      "indices" : [ 12, 18 ],
      "id_str" : "533114985",
      "id" : 533114985
    }, {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "indices" : [ 19, 30 ],
      "id_str" : "152051625",
      "id" : 152051625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463046157808435200",
  "geo" : { },
  "id_str" : "463046246178254848",
  "in_reply_to_user_id" : 21158543,
  "text" : "@mixosaurus @u203d @heatherfro exactly :)",
  "id" : 463046246178254848,
  "in_reply_to_status_id" : 463046157808435200,
  "created_at" : "2014-05-04 20:03:22 +0000",
  "in_reply_to_screen_name" : "mixosaurus",
  "in_reply_to_user_id_str" : "21158543",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Magnus Nissel",
      "screen_name" : "u203d",
      "indices" : [ 0, 6 ],
      "id_str" : "533114985",
      "id" : 533114985
    }, {
      "name" : "Kat Gupta",
      "screen_name" : "mixosaurus",
      "indices" : [ 7, 18 ],
      "id_str" : "21158543",
      "id" : 21158543
    }, {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "indices" : [ 19, 30 ],
      "id_str" : "152051625",
      "id" : 152051625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/swfSvnBYGi",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=gdk8g22A9bM",
      "display_url" : "youtube.com\/watch?v=gdk8g2\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "463043223435608064",
  "geo" : { },
  "id_str" : "463044991557074944",
  "in_reply_to_user_id" : 533114985,
  "text" : "@u203d @mixosaurus @heatherfro for CL folk POS is a must :) https:\/\/t.co\/swfSvnBYGi",
  "id" : 463044991557074944,
  "in_reply_to_status_id" : 463043223435608064,
  "created_at" : "2014-05-04 19:58:23 +0000",
  "in_reply_to_screen_name" : "u203d",
  "in_reply_to_user_id_str" : "533114985",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Daniels",
      "screen_name" : "matthew_daniels",
      "indices" : [ 80, 96 ],
      "id_str" : "14328463",
      "id" : 14328463
    }, {
      "name" : "KevinHodgson",
      "screen_name" : "dogtrax",
      "indices" : [ 101, 109 ],
      "id_str" : "13307352",
      "id" : 13307352
    }, {
      "name" : "Doug Belshaw",
      "screen_name" : "dajbelshaw",
      "indices" : [ 116, 127 ],
      "id_str" : "764365",
      "id" : 764365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/wcPVjRJEv9",
      "expanded_url" : "http:\/\/www.mdaniels.com\/vocab\/analysis.html",
      "display_url" : "mdaniels.com\/vocab\/analysis\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463043783756480512",
  "text" : "plotting 80 rappers against Shakespeare and Melville http:\/\/t.co\/wcPVjRJEv9 via @matthew_daniels h\/t @dogtrax &amp; @dajbelshaw",
  "id" : 463043783756480512,
  "created_at" : "2014-05-04 19:53:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Yau",
      "screen_name" : "flowingdata",
      "indices" : [ 3, 15 ],
      "id_str" : "14109167",
      "id" : 14109167
    }, {
      "name" : "nytlabs",
      "screen_name" : "nytlabs",
      "indices" : [ 89, 97 ],
      "id_str" : "673953",
      "id" : 673953
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/ARywzsXExo",
      "expanded_url" : "http:\/\/blog.nytlabs.com\/2014\/04\/25\/vellum-a-reading-layer-for-your-twitter-feed\/",
      "display_url" : "blog.nytlabs.com\/2014\/04\/25\/vel\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463008166763307009",
  "text" : "RT @flowingdata: Vellum: A reading layer for your Twitter feed http:\/\/t.co\/ARywzsXExo by @nytlabs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "nytlabs",
        "screen_name" : "nytlabs",
        "indices" : [ 72, 80 ],
        "id_str" : "673953",
        "id" : 673953
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/ARywzsXExo",
        "expanded_url" : "http:\/\/blog.nytlabs.com\/2014\/04\/25\/vellum-a-reading-layer-for-your-twitter-feed\/",
        "display_url" : "blog.nytlabs.com\/2014\/04\/25\/vel\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "463001386024992768",
    "text" : "Vellum: A reading layer for your Twitter feed http:\/\/t.co\/ARywzsXExo by @nytlabs",
    "id" : 463001386024992768,
    "created_at" : "2014-05-04 17:05:07 +0000",
    "user" : {
      "name" : "Nathan Yau",
      "screen_name" : "flowingdata",
      "protected" : false,
      "id_str" : "14109167",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/585826994526355456\/R3tYT5Kj_normal.png",
      "id" : 14109167,
      "verified" : false
    }
  },
  "id" : 463008166763307009,
  "created_at" : "2014-05-04 17:32:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Ash FRSA",
      "screen_name" : "Ashowski",
      "indices" : [ 0, 9 ],
      "id_str" : "316596356",
      "id" : 316596356
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "462999378207059968",
  "geo" : { },
  "id_str" : "462999904273846272",
  "in_reply_to_user_id" : 316596356,
  "text" : "@Ashowski thx for post important area i need to focus more on :)",
  "id" : 462999904273846272,
  "in_reply_to_status_id" : 462999378207059968,
  "created_at" : "2014-05-04 16:59:13 +0000",
  "in_reply_to_screen_name" : "Ashowski",
  "in_reply_to_user_id_str" : "316596356",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Ash FRSA",
      "screen_name" : "Ashowski",
      "indices" : [ 74, 83 ],
      "id_str" : "316596356",
      "id" : 316596356
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/qQSoq5j8I5",
      "expanded_url" : "http:\/\/wp.me\/p3MdWw-6W",
      "display_url" : "wp.me\/p3MdWw-6W"
    } ]
  },
  "geo" : { },
  "id_str" : "462998616471130112",
  "text" : "Reviewing and Demonstrating Learners' Progress http:\/\/t.co\/qQSoq5j8I5 via @Ashowski",
  "id" : 462998616471130112,
  "created_at" : "2014-05-04 16:54:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "462855097756942336",
  "geo" : { },
  "id_str" : "462855768627503104",
  "in_reply_to_user_id" : 54656671,
  "text" : "@SLT_Kat :)",
  "id" : 462855768627503104,
  "in_reply_to_status_id" : 462855097756942336,
  "created_at" : "2014-05-04 07:26:29 +0000",
  "in_reply_to_screen_name" : "Kat_S76",
  "in_reply_to_user_id_str" : "54656671",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "462853700386816000",
  "in_reply_to_user_id" : 54656671,
  "text" : "@SLT_Kat hi thx for follow but i accidently blocked u after following u and stopped u following!",
  "id" : 462853700386816000,
  "created_at" : "2014-05-04 07:18:16 +0000",
  "in_reply_to_screen_name" : "Kat_S76",
  "in_reply_to_user_id_str" : "54656671",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah KB",
      "screen_name" : "sarah_SKB",
      "indices" : [ 9, 19 ],
      "id_str" : "54518314",
      "id" : 54518314
    }, {
      "name" : "Bryan Harris",
      "screen_name" : "Harris_Bryan",
      "indices" : [ 20, 33 ],
      "id_str" : "16635335",
      "id" : 16635335
    }, {
      "name" : "Shelly Sanchez",
      "screen_name" : "ShellTerrell",
      "indices" : [ 43, 56 ],
      "id_str" : "29655018",
      "id" : 29655018
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/1ZjM5BmCoB",
      "expanded_url" : "http:\/\/www.willatworklearning.com\/2006\/05\/people_remember.html",
      "display_url" : "willatworklearning.com\/2006\/05\/people\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "462657078273015809",
  "geo" : { },
  "id_str" : "462689897690959872",
  "in_reply_to_user_id" : 54656671,
  "text" : "@SLT_Kat @sarah_SKB @Harris_Bryan @kylefcs @ShellTerrell the zombie pyramid of made up numbers lumbers on http:\/\/t.co\/1ZjM5BmCoB",
  "id" : 462689897690959872,
  "in_reply_to_status_id" : 462657078273015809,
  "created_at" : "2014-05-03 20:27:22 +0000",
  "in_reply_to_screen_name" : "Kat_S76",
  "in_reply_to_user_id_str" : "54656671",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "William Ian O'Byrne",
      "screen_name" : "wiobyrne",
      "indices" : [ 3, 12 ],
      "id_str" : "88676762",
      "id" : 88676762
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/wiobyrne\/status\/462529514959282176\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/hXrREhRQSR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bms8JKHIUAACiBD.png",
      "id_str" : "462529514766356480",
      "id" : 462529514766356480,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bms8JKHIUAACiBD.png",
      "sizes" : [ {
        "h" : 100,
        "resize" : "fit",
        "w" : 100
      }, {
        "h" : 100,
        "resize" : "fit",
        "w" : 100
      }, {
        "h" : 100,
        "resize" : "fit",
        "w" : 100
      }, {
        "h" : 100,
        "resize" : "crop",
        "w" : 100
      }, {
        "h" : 100,
        "resize" : "fit",
        "w" : 100
      } ],
      "display_url" : "pic.twitter.com\/hXrREhRQSR"
    } ],
    "hashtags" : [ {
      "text" : "RaspberryPi",
      "indices" : [ 64, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/vujHiSl5EX",
      "expanded_url" : "http:\/\/bit.ly\/1rOMPwX",
      "display_url" : "bit.ly\/1rOMPwX"
    } ]
  },
  "geo" : { },
  "id_str" : "462580454210945024",
  "text" : "RT @wiobyrne: Gustav Lessing will you show me how to build this #RaspberryPi magic mirror? http:\/\/t.co\/vujHiSl5EX http:\/\/t.co\/hXrREhRQSR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/friendsplus.me\" rel=\"nofollow\"\u003EFriends Me\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/wiobyrne\/status\/462529514959282176\/photo\/1",
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/hXrREhRQSR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bms8JKHIUAACiBD.png",
        "id_str" : "462529514766356480",
        "id" : 462529514766356480,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bms8JKHIUAACiBD.png",
        "sizes" : [ {
          "h" : 100,
          "resize" : "fit",
          "w" : 100
        }, {
          "h" : 100,
          "resize" : "fit",
          "w" : 100
        }, {
          "h" : 100,
          "resize" : "fit",
          "w" : 100
        }, {
          "h" : 100,
          "resize" : "crop",
          "w" : 100
        }, {
          "h" : 100,
          "resize" : "fit",
          "w" : 100
        } ],
        "display_url" : "pic.twitter.com\/hXrREhRQSR"
      } ],
      "hashtags" : [ {
        "text" : "RaspberryPi",
        "indices" : [ 50, 62 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/vujHiSl5EX",
        "expanded_url" : "http:\/\/bit.ly\/1rOMPwX",
        "display_url" : "bit.ly\/1rOMPwX"
      } ]
    },
    "geo" : { },
    "id_str" : "462529514959282176",
    "text" : "Gustav Lessing will you show me how to build this #RaspberryPi magic mirror? http:\/\/t.co\/vujHiSl5EX http:\/\/t.co\/hXrREhRQSR",
    "id" : 462529514959282176,
    "created_at" : "2014-05-03 09:50:04 +0000",
    "user" : {
      "name" : "William Ian O'Byrne",
      "screen_name" : "wiobyrne",
      "protected" : false,
      "id_str" : "88676762",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/519580082\/twitter_normal.jpg",
      "id" : 88676762,
      "verified" : false
    }
  },
  "id" : 462580454210945024,
  "created_at" : "2014-05-03 13:12:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bethany Nowviskie",
      "screen_name" : "nowviskie",
      "indices" : [ 3, 13 ],
      "id_str" : "14221013",
      "id" : 14221013
    }, {
      "name" : "Julianne Nyhan",
      "screen_name" : "juliannenyhan",
      "indices" : [ 45, 59 ],
      "id_str" : "77436748",
      "id" : 77436748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/dGw6rzoJWE",
      "expanded_url" : "http:\/\/archelogos.hypotheses.org\/135",
      "display_url" : "archelogos.hypotheses.org\/135"
    } ]
  },
  "geo" : { },
  "id_str" : "462579036901081089",
  "text" : "RT @nowviskie: Wonderful work in progress by @juliannenyhan! Gender, knowledge and hierarchy: on Busa's female punch card operators: http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Julianne Nyhan",
        "screen_name" : "juliannenyhan",
        "indices" : [ 30, 44 ],
        "id_str" : "77436748",
        "id" : 77436748
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/dGw6rzoJWE",
        "expanded_url" : "http:\/\/archelogos.hypotheses.org\/135",
        "display_url" : "archelogos.hypotheses.org\/135"
      } ]
    },
    "in_reply_to_status_id_str" : "462548437763108865",
    "geo" : { },
    "id_str" : "462557129963241473",
    "in_reply_to_user_id" : 77436748,
    "text" : "Wonderful work in progress by @juliannenyhan! Gender, knowledge and hierarchy: on Busa's female punch card operators: http:\/\/t.co\/dGw6rzoJWE",
    "id" : 462557129963241473,
    "in_reply_to_status_id" : 462548437763108865,
    "created_at" : "2014-05-03 11:39:48 +0000",
    "in_reply_to_screen_name" : "juliannenyhan",
    "in_reply_to_user_id_str" : "77436748",
    "user" : {
      "name" : "Bethany Nowviskie",
      "screen_name" : "nowviskie",
      "protected" : false,
      "id_str" : "14221013",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751794036365594625\/xIEFm3Jp_normal.jpg",
      "id" : 14221013,
      "verified" : false
    }
  },
  "id" : 462579036901081089,
  "created_at" : "2014-05-03 13:06:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "indices" : [ 3, 18 ],
      "id_str" : "27716419",
      "id" : 27716419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/8Db5W7CUZR",
      "expanded_url" : "http:\/\/bit.ly\/1mk2qD4",
      "display_url" : "bit.ly\/1mk2qD4"
    } ]
  },
  "geo" : { },
  "id_str" : "462291052414902272",
  "text" : "RT @CraigMurrayOrg: New post: BBC Propaganda Hits New All-Time Low http:\/\/t.co\/8Db5W7CUZR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.craigmurray.org.uk\" rel=\"nofollow\"\u003ECraig Murray posting plugin\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 69 ],
        "url" : "http:\/\/t.co\/8Db5W7CUZR",
        "expanded_url" : "http:\/\/bit.ly\/1mk2qD4",
        "display_url" : "bit.ly\/1mk2qD4"
      } ]
    },
    "geo" : { },
    "id_str" : "462165670369980417",
    "text" : "New post: BBC Propaganda Hits New All-Time Low http:\/\/t.co\/8Db5W7CUZR",
    "id" : 462165670369980417,
    "created_at" : "2014-05-02 09:44:17 +0000",
    "user" : {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "protected" : false,
      "id_str" : "27716419",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1388436826\/cm_normal.jpg",
      "id" : 27716419,
      "verified" : false
    }
  },
  "id" : 462291052414902272,
  "created_at" : "2014-05-02 18:02:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boing Boing",
      "screen_name" : "BoingBoing",
      "indices" : [ 3, 14 ],
      "id_str" : "5971922",
      "id" : 5971922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/ycixQ3Scki",
      "expanded_url" : "http:\/\/dlvr.it\/5YNMC1",
      "display_url" : "dlvr.it\/5YNMC1"
    } ]
  },
  "geo" : { },
  "id_str" : "462232798670389249",
  "text" : "RT @BoingBoing: Standardized testing and schools as factories: Louis CK versus Common Core http:\/\/t.co\/ycixQ3Scki",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/dlvr.it\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/ycixQ3Scki",
        "expanded_url" : "http:\/\/dlvr.it\/5YNMC1",
        "display_url" : "dlvr.it\/5YNMC1"
      } ]
    },
    "geo" : { },
    "id_str" : "462231949734461440",
    "text" : "Standardized testing and schools as factories: Louis CK versus Common Core http:\/\/t.co\/ycixQ3Scki",
    "id" : 462231949734461440,
    "created_at" : "2014-05-02 14:07:39 +0000",
    "user" : {
      "name" : "Boing Boing",
      "screen_name" : "BoingBoing",
      "protected" : false,
      "id_str" : "5971922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616924998226153472\/0EfZYjr2_normal.png",
      "id" : 5971922,
      "verified" : true
    }
  },
  "id" : 462232798670389249,
  "created_at" : "2014-05-02 14:11:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 89, 103 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/hr5JUWxMgI",
      "expanded_url" : "http:\/\/www.dissentmagazine.org\/article\/the-computer-did-it-technology-and-inequality",
      "display_url" : "dissentmagazine.org\/article\/the-co\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462226788228538369",
  "text" : "The computer did it? Technology and inequality. http:\/\/t.co\/hr5JUWxMgI last 2 tweets h\/t @audreywatters newsletter",
  "id" : 462226788228538369,
  "created_at" : "2014-05-02 13:47:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/rn21KshcHo",
      "expanded_url" : "http:\/\/qz.com\/202312\/is-your-job-at-risk-from-robot-labor-check-this-handy-interactive\/",
      "display_url" : "qz.com\/202312\/is-your\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462223246054940672",
  "text" : "Is your job at risk from robot labor? Check this handy interactive http:\/\/t.co\/rn21KshcHo",
  "id" : 462223246054940672,
  "created_at" : "2014-05-02 13:33:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sophia Khan",
      "screen_name" : "SophiaKhan4",
      "indices" : [ 0, 12 ],
      "id_str" : "351390617",
      "id" : 351390617
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "461381212523610112",
  "geo" : { },
  "id_str" : "462214204863557633",
  "in_reply_to_user_id" : 351390617,
  "text" : "@SophiaKhan4 there is a fairy godmother aka granny in the cloud that can help you :o",
  "id" : 462214204863557633,
  "in_reply_to_status_id" : 461381212523610112,
  "created_at" : "2014-05-02 12:57:08 +0000",
  "in_reply_to_screen_name" : "SophiaKhan4",
  "in_reply_to_user_id_str" : "351390617",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessica Frye",
      "screen_name" : "JessFrye1",
      "indices" : [ 3, 13 ],
      "id_str" : "533509442",
      "id" : 533509442
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "icame35",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "462200667323793409",
  "text" : "RT @JessFrye1: Learners are less likely to make native-like choices when using the passive. \"Exploring the EFL\/ESL paradigm gap\" by Gries\/D\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "icame35",
        "indices" : [ 131, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "462183236714909696",
    "text" : "Learners are less likely to make native-like choices when using the passive. \"Exploring the EFL\/ESL paradigm gap\" by Gries\/Deshors #icame35",
    "id" : 462183236714909696,
    "created_at" : "2014-05-02 10:54:05 +0000",
    "user" : {
      "name" : "Jessica Frye",
      "screen_name" : "JessFrye1",
      "protected" : false,
      "id_str" : "533509442",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/444916386608193537\/9xiOTsl0_normal.jpeg",
      "id" : 533509442,
      "verified" : false
    }
  },
  "id" : 462200667323793409,
  "created_at" : "2014-05-02 12:03:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "indices" : [ 3, 16 ],
      "id_str" : "1685397408",
      "id" : 1685397408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/GKNlGIqYjp",
      "expanded_url" : "http:\/\/wp.me\/p15Ewi-360",
      "display_url" : "wp.me\/p15Ewi-360"
    } ]
  },
  "geo" : { },
  "id_str" : "462177606826459136",
  "text" : "RT @harrisonmike: It\u2019s not beautiful and it\u2019s not\u00A0noble http:\/\/t.co\/GKNlGIqYjp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 60 ],
        "url" : "http:\/\/t.co\/GKNlGIqYjp",
        "expanded_url" : "http:\/\/wp.me\/p15Ewi-360",
        "display_url" : "wp.me\/p15Ewi-360"
      } ]
    },
    "geo" : { },
    "id_str" : "462128419510030336",
    "text" : "It\u2019s not beautiful and it\u2019s not\u00A0noble http:\/\/t.co\/GKNlGIqYjp",
    "id" : 462128419510030336,
    "created_at" : "2014-05-02 07:16:15 +0000",
    "user" : {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "protected" : false,
      "id_str" : "1685397408",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/697937835127672832\/Z5BuTNo2_normal.jpg",
      "id" : 1685397408,
      "verified" : false
    }
  },
  "id" : 462177606826459136,
  "created_at" : "2014-05-02 10:31:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beatrice Reed",
      "screen_name" : "BB_Reed",
      "indices" : [ 3, 11 ],
      "id_str" : "2502542837",
      "id" : 2502542837
    }, {
      "name" : "linguisten.de",
      "screen_name" : "linguisten",
      "indices" : [ 66, 77 ],
      "id_str" : "299216459",
      "id" : 299216459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/8mEyi3vlmg",
      "expanded_url" : "http:\/\/tmblr.co\/Zvwpgr1EivWA5",
      "display_url" : "tmblr.co\/Zvwpgr1EivWA5"
    } ]
  },
  "geo" : { },
  "id_str" : "462177171034083328",
  "text" : "RT @BB_Reed: Excellent prompt to consider meaning of 'meaning' MT\u201C@linguisten: Meaningful non-speech sounds... - languagevillage http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "linguisten.de",
        "screen_name" : "linguisten",
        "indices" : [ 53, 64 ],
        "id_str" : "299216459",
        "id" : 299216459
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/8mEyi3vlmg",
        "expanded_url" : "http:\/\/tmblr.co\/Zvwpgr1EivWA5",
        "display_url" : "tmblr.co\/Zvwpgr1EivWA5"
      } ]
    },
    "in_reply_to_status_id_str" : "462150010709495808",
    "geo" : { },
    "id_str" : "462153059028967424",
    "in_reply_to_user_id" : 299216459,
    "text" : "Excellent prompt to consider meaning of 'meaning' MT\u201C@linguisten: Meaningful non-speech sounds... - languagevillage http:\/\/t.co\/8mEyi3vlmg\u201D",
    "id" : 462153059028967424,
    "in_reply_to_status_id" : 462150010709495808,
    "created_at" : "2014-05-02 08:54:10 +0000",
    "in_reply_to_screen_name" : "linguisten",
    "in_reply_to_user_id_str" : "299216459",
    "user" : {
      "name" : "Beatrice Reed",
      "screen_name" : "BB_Reed",
      "protected" : false,
      "id_str" : "2502542837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/580495049575763968\/nTERlTr9_normal.jpg",
      "id" : 2502542837,
      "verified" : false
    }
  },
  "id" : 462177171034083328,
  "created_at" : "2014-05-02 10:29:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 3, 16 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/1CncSXaJ7L",
      "expanded_url" : "http:\/\/wp.me\/pKFOt-tQ",
      "display_url" : "wp.me\/pKFOt-tQ"
    } ]
  },
  "geo" : { },
  "id_str" : "461978853079261184",
  "text" : "RT @rosemerebard: My own story, the story of\u00A0thousands http:\/\/t.co\/1CncSXaJ7L",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 59 ],
        "url" : "http:\/\/t.co\/1CncSXaJ7L",
        "expanded_url" : "http:\/\/wp.me\/pKFOt-tQ",
        "display_url" : "wp.me\/pKFOt-tQ"
      } ]
    },
    "geo" : { },
    "id_str" : "461972503963770880",
    "text" : "My own story, the story of\u00A0thousands http:\/\/t.co\/1CncSXaJ7L",
    "id" : 461972503963770880,
    "created_at" : "2014-05-01 20:56:42 +0000",
    "user" : {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "protected" : false,
      "id_str" : "88655243",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/706508144160145410\/pKzknb5H_normal.jpg",
      "id" : 88655243,
      "verified" : false
    }
  },
  "id" : 461978853079261184,
  "created_at" : "2014-05-01 21:21:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donald Clark",
      "screen_name" : "DonaldClark",
      "indices" : [ 3, 15 ],
      "id_str" : "1632891",
      "id" : 1632891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/QkSK4kfaSY",
      "expanded_url" : "http:\/\/bit.ly\/1khYT5E",
      "display_url" : "bit.ly\/1khYT5E"
    } ]
  },
  "geo" : { },
  "id_str" : "461973986348654592",
  "text" : "RT @DonaldClark: \u2018Mindfulness\u2019 another educational fad? http:\/\/t.co\/QkSK4kfaSY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 61 ],
        "url" : "http:\/\/t.co\/QkSK4kfaSY",
        "expanded_url" : "http:\/\/bit.ly\/1khYT5E",
        "display_url" : "bit.ly\/1khYT5E"
      } ]
    },
    "geo" : { },
    "id_str" : "461824181341278209",
    "text" : "\u2018Mindfulness\u2019 another educational fad? http:\/\/t.co\/QkSK4kfaSY",
    "id" : 461824181341278209,
    "created_at" : "2014-05-01 11:07:19 +0000",
    "user" : {
      "name" : "Donald Clark",
      "screen_name" : "DonaldClark",
      "protected" : false,
      "id_str" : "1632891",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/513085530695663616\/BfWK4n6u_normal.jpeg",
      "id" : 1632891,
      "verified" : false
    }
  },
  "id" : 461973986348654592,
  "created_at" : "2014-05-01 21:02:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Bogost",
      "screen_name" : "ibogost",
      "indices" : [ 3, 11 ],
      "id_str" : "6825792",
      "id" : 6825792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/VjwHnadDtw",
      "expanded_url" : "http:\/\/paleofuture.gizmodo.com\/the-language-of-silicon-valley-is-slowly-poisoning-our-1570390699",
      "display_url" : "paleofuture.gizmodo.com\/the-language-o\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "461973005506461698",
  "text" : "RT @ibogost: \"The language of start-ups has seeped into our brains and it's slowly poisoning us.\" http:\/\/t.co\/VjwHnadDtw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/VjwHnadDtw",
        "expanded_url" : "http:\/\/paleofuture.gizmodo.com\/the-language-of-silicon-valley-is-slowly-poisoning-our-1570390699",
        "display_url" : "paleofuture.gizmodo.com\/the-language-o\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "461958053718679552",
    "text" : "\"The language of start-ups has seeped into our brains and it's slowly poisoning us.\" http:\/\/t.co\/VjwHnadDtw",
    "id" : 461958053718679552,
    "created_at" : "2014-05-01 19:59:17 +0000",
    "user" : {
      "name" : "Ian Bogost",
      "screen_name" : "ibogost",
      "protected" : false,
      "id_str" : "6825792",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/677930477752193025\/DUdmOVVK_normal.jpg",
      "id" : 6825792,
      "verified" : true
    }
  },
  "id" : 461973005506461698,
  "created_at" : "2014-05-01 20:58:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELTjam",
      "screen_name" : "eltjam",
      "indices" : [ 24, 31 ],
      "id_str" : "1356363686",
      "id" : 1356363686
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461964332713410560",
  "text" : "edu gospel according to @eltjam Mitra interview - make money but don't defend jobs?",
  "id" : 461964332713410560,
  "created_at" : "2014-05-01 20:24:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "461810301500149760",
  "geo" : { },
  "id_str" : "461956838637174784",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco what an ugly word :)",
  "id" : 461956838637174784,
  "in_reply_to_status_id" : 461810301500149760,
  "created_at" : "2014-05-01 19:54:27 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/raO57NmNBt",
      "expanded_url" : "http:\/\/bit.ly\/1rJJ4su",
      "display_url" : "bit.ly\/1rJJ4su"
    } ]
  },
  "geo" : { },
  "id_str" : "461939583614464000",
  "text" : "Mitra provides a lovely case study in how a once-revolutionary philosophy can be thinned down and made so shallow... http:\/\/t.co\/raO57NmNBt",
  "id" : 461939583614464000,
  "created_at" : "2014-05-01 18:45:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Adele Soracco",
      "screen_name" : "LauraSoracco",
      "indices" : [ 3, 16 ],
      "id_str" : "15663328",
      "id" : 15663328
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "vocab",
      "indices" : [ 135, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/OlmRFUenPC",
      "expanded_url" : "http:\/\/www.lextutor.ca\/freq\/train\/",
      "display_url" : "lextutor.ca\/freq\/train\/"
    } ]
  },
  "geo" : { },
  "id_str" : "461913740603305984",
  "text" : "RT @LauraSoracco: Want to know how good you are at guessing a word's frequency? take this fun test! (I got 85%) http:\/\/t.co\/OlmRFUenPC #voc\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "vocab",
        "indices" : [ 117, 123 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/OlmRFUenPC",
        "expanded_url" : "http:\/\/www.lextutor.ca\/freq\/train\/",
        "display_url" : "lextutor.ca\/freq\/train\/"
      } ]
    },
    "geo" : { },
    "id_str" : "461910932151873536",
    "text" : "Want to know how good you are at guessing a word's frequency? take this fun test! (I got 85%) http:\/\/t.co\/OlmRFUenPC #vocab",
    "id" : 461910932151873536,
    "created_at" : "2014-05-01 16:52:02 +0000",
    "user" : {
      "name" : "Laura Adele Soracco",
      "screen_name" : "LauraSoracco",
      "protected" : false,
      "id_str" : "15663328",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766919326427254785\/4J5Q1zgQ_normal.jpg",
      "id" : 15663328,
      "verified" : false
    }
  },
  "id" : 461913740603305984,
  "created_at" : "2014-05-01 17:03:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessica Frye",
      "screen_name" : "JessFrye1",
      "indices" : [ 3, 13 ],
      "id_str" : "533509442",
      "id" : 533509442
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "icame35",
      "indices" : [ 117, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 126, 140 ],
      "url" : "http:\/\/t.co\/P30MJ3fMwA",
      "expanded_url" : "http:\/\/bit.ly\/1mhFmVD",
      "display_url" : "bit.ly\/1mhFmVD"
    } ]
  },
  "geo" : { },
  "id_str" : "461908685053493248",
  "text" : "RT @JessFrye1: Interesting presentation by Knut Hofland on corpuscle, a v useful corpus management and analysis tool #icame35 http:\/\/t.co\/P\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "icame35",
        "indices" : [ 102, 110 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/P30MJ3fMwA",
        "expanded_url" : "http:\/\/bit.ly\/1mhFmVD",
        "display_url" : "bit.ly\/1mhFmVD"
      } ]
    },
    "geo" : { },
    "id_str" : "461907902421557248",
    "text" : "Interesting presentation by Knut Hofland on corpuscle, a v useful corpus management and analysis tool #icame35 http:\/\/t.co\/P30MJ3fMwA",
    "id" : 461907902421557248,
    "created_at" : "2014-05-01 16:40:00 +0000",
    "user" : {
      "name" : "Jessica Frye",
      "screen_name" : "JessFrye1",
      "protected" : false,
      "id_str" : "533509442",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/444916386608193537\/9xiOTsl0_normal.jpeg",
      "id" : 533509442,
      "verified" : false
    }
  },
  "id" : 461908685053493248,
  "created_at" : "2014-05-01 16:43:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessica Frye",
      "screen_name" : "JessFrye1",
      "indices" : [ 0, 10 ],
      "id_str" : "533509442",
      "id" : 533509442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/NzncrYur5a",
      "expanded_url" : "http:\/\/clarino.uib.no\/korpuskel",
      "display_url" : "clarino.uib.no\/korpuskel"
    } ]
  },
  "in_reply_to_status_id_str" : "461898718707744768",
  "geo" : { },
  "id_str" : "461905498795950080",
  "in_reply_to_user_id" : 533509442,
  "text" : "@JessFrye1 hi thanks though i think this is correct link http:\/\/t.co\/NzncrYur5a",
  "id" : 461905498795950080,
  "in_reply_to_status_id" : 461898718707744768,
  "created_at" : "2014-05-01 16:30:27 +0000",
  "in_reply_to_screen_name" : "JessFrye1",
  "in_reply_to_user_id_str" : "533509442",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "461895576490373120",
  "geo" : { },
  "id_str" : "461897334037966848",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco additional benefits of similarity to pulp and gulp :)",
  "id" : 461897334037966848,
  "in_reply_to_status_id" : 461895576490373120,
  "created_at" : "2014-05-01 15:58:00 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461894584445206529",
  "text" : "suggestion, let's use NuLP &amp; reserve NLP for natural language processing :)",
  "id" : 461894584445206529,
  "created_at" : "2014-05-01 15:47:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chuck sandy",
      "screen_name" : "chucksandy",
      "indices" : [ 3, 14 ],
      "id_str" : "18880320",
      "id" : 18880320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 126, 140 ],
      "url" : "http:\/\/t.co\/AwWyMIzm7K",
      "expanded_url" : "http:\/\/fb.me\/1eQVsJosc",
      "display_url" : "fb.me\/1eQVsJosc"
    } ]
  },
  "geo" : { },
  "id_str" : "461887966525554689",
  "text" : "RT @chucksandy: Instead of reading poetry tonight I decided to listen to Bill Callahan. It's hard to decide which of these... http:\/\/t.co\/A\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/AwWyMIzm7K",
        "expanded_url" : "http:\/\/fb.me\/1eQVsJosc",
        "display_url" : "fb.me\/1eQVsJosc"
      } ]
    },
    "geo" : { },
    "id_str" : "461887551952154624",
    "text" : "Instead of reading poetry tonight I decided to listen to Bill Callahan. It's hard to decide which of these... http:\/\/t.co\/AwWyMIzm7K",
    "id" : 461887551952154624,
    "created_at" : "2014-05-01 15:19:08 +0000",
    "user" : {
      "name" : "chuck sandy",
      "screen_name" : "chucksandy",
      "protected" : false,
      "id_str" : "18880320",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/620217802465513472\/poN-d2nR_normal.jpg",
      "id" : 18880320,
      "verified" : false
    }
  },
  "id" : 461887966525554689,
  "created_at" : "2014-05-01 15:20:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemma Lunn",
      "screen_name" : "GemL1",
      "indices" : [ 0, 6 ],
      "id_str" : "486146568",
      "id" : 486146568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "461885301473148928",
  "geo" : { },
  "id_str" : "461885550417682432",
  "in_reply_to_user_id" : 486146568,
  "text" : "@GemL1 i hear that!",
  "id" : 461885550417682432,
  "in_reply_to_status_id" : 461885301473148928,
  "created_at" : "2014-05-01 15:11:11 +0000",
  "in_reply_to_screen_name" : "GemL1",
  "in_reply_to_user_id_str" : "486146568",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemma Lunn",
      "screen_name" : "GemL1",
      "indices" : [ 3, 9 ],
      "id_str" : "486146568",
      "id" : 486146568
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 97, 101 ]
    }, {
      "text" : "corpora",
      "indices" : [ 102, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/jmHRMSJkPH",
      "expanded_url" : "http:\/\/journals.cambridge.org\/action\/displayIssue?decade=2010&jid=REC&volumeId=26&issueId=02&iid=9231572",
      "display_url" : "journals.cambridge.org\/action\/display\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "461882965086453760",
  "text" : "RT @GemL1: Articles on uses of corpora for language teaching and learning http:\/\/t.co\/jmHRMSJkPH #elt #corpora",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "elt",
        "indices" : [ 86, 90 ]
      }, {
        "text" : "corpora",
        "indices" : [ 91, 99 ]
      } ],
      "urls" : [ {
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/jmHRMSJkPH",
        "expanded_url" : "http:\/\/journals.cambridge.org\/action\/displayIssue?decade=2010&jid=REC&volumeId=26&issueId=02&iid=9231572",
        "display_url" : "journals.cambridge.org\/action\/display\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "461878863866249216",
    "text" : "Articles on uses of corpora for language teaching and learning http:\/\/t.co\/jmHRMSJkPH #elt #corpora",
    "id" : 461878863866249216,
    "created_at" : "2014-05-01 14:44:37 +0000",
    "user" : {
      "name" : "Gemma Lunn",
      "screen_name" : "GemL1",
      "protected" : false,
      "id_str" : "486146568",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/652399796112740353\/sQhaCdI__normal.jpg",
      "id" : 486146568,
      "verified" : false
    }
  },
  "id" : 461882965086453760,
  "created_at" : "2014-05-01 15:00:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemma Lunn",
      "screen_name" : "GemL1",
      "indices" : [ 0, 6 ],
      "id_str" : "486146568",
      "id" : 486146568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "461878863866249216",
  "geo" : { },
  "id_str" : "461882950305718272",
  "in_reply_to_user_id" : 486146568,
  "text" : "@GemL1 nice they are now all open access :)",
  "id" : 461882950305718272,
  "in_reply_to_status_id" : 461878863866249216,
  "created_at" : "2014-05-01 15:00:51 +0000",
  "in_reply_to_screen_name" : "GemL1",
  "in_reply_to_user_id_str" : "486146568",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 0, 15 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "461835053669314560",
  "geo" : { },
  "id_str" : "461839100329603072",
  "in_reply_to_user_id" : 334332424,
  "text" : "@GeoffreyJordan thx do you know of any papers actually testing theory?",
  "id" : 461839100329603072,
  "in_reply_to_status_id" : 461835053669314560,
  "created_at" : "2014-05-01 12:06:36 +0000",
  "in_reply_to_screen_name" : "GeoffreyJordan",
  "in_reply_to_user_id_str" : "334332424",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AusELT",
      "indices" : [ 53, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461832086442491904",
  "text" : "chaos theory another untestable theory in education? #AusELT",
  "id" : 461832086442491904,
  "created_at" : "2014-05-01 11:38:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim George",
      "screen_name" : "oyajimbo",
      "indices" : [ 0, 9 ],
      "id_str" : "96103979",
      "id" : 96103979
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/461831863909105664\/photo\/1",
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/Z4o9K0QSKd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BmjBoiKCQAAtwLO.jpg",
      "id_str" : "461831863913299968",
      "id" : 461831863913299968,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmjBoiKCQAAtwLO.jpg",
      "sizes" : [ {
        "h" : 500,
        "resize" : "fit",
        "w" : 493
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 493
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 345,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 493
      } ],
      "display_url" : "pic.twitter.com\/Z4o9K0QSKd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "461831035353710592",
  "geo" : { },
  "id_str" : "461831863909105664",
  "in_reply_to_user_id" : 96103979,
  "text" : "@oyajimbo :) http:\/\/t.co\/Z4o9K0QSKd",
  "id" : 461831863909105664,
  "in_reply_to_status_id" : 461831035353710592,
  "created_at" : "2014-05-01 11:37:51 +0000",
  "in_reply_to_screen_name" : "oyajimbo",
  "in_reply_to_user_id_str" : "96103979",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/X0qvgErpTN",
      "expanded_url" : "http:\/\/standpointmag.co.uk\/features-may-14-islington-children-guinea-pigs-the-left-robert-peal-schools\/Islington",
      "display_url" : "standpointmag.co.uk\/features-may-1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "461826980829081600",
  "text" : "http:\/\/t.co\/X0qvgErpTN: Children as Guinea Pigs of the Left",
  "id" : 461826980829081600,
  "created_at" : "2014-05-01 11:18:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "larry cuban",
      "screen_name" : "CubanLarry",
      "indices" : [ 68, 79 ],
      "id_str" : "2324494104",
      "id" : 2324494104
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/aa52Yxr8iw",
      "expanded_url" : "http:\/\/wp.me\/pBm7c-27W",
      "display_url" : "wp.me\/pBm7c-27W"
    } ]
  },
  "geo" : { },
  "id_str" : "461821741728145408",
  "text" : "Is It Worth Being a Teacher? (Dave Reid) http:\/\/t.co\/aa52Yxr8iw via @CubanLarry",
  "id" : 461821741728145408,
  "created_at" : "2014-05-01 10:57:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELTjam",
      "screen_name" : "eltjam",
      "indices" : [ 3, 10 ],
      "id_str" : "1356363686",
      "id" : 1356363686
    }, {
      "name" : "Nick Robinson",
      "screen_name" : "nmkrobinson",
      "indices" : [ 13, 25 ],
      "id_str" : "20425399",
      "id" : 20425399
    }, {
      "name" : "Sugata Mitra",
      "screen_name" : "Sugatam",
      "indices" : [ 60, 68 ],
      "id_str" : "9242922",
      "id" : 9242922
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 119, 123 ]
    }, {
      "text" : "esl",
      "indices" : [ 124, 128 ]
    }, {
      "text" : "edtech",
      "indices" : [ 129, 136 ]
    }, {
      "text" : "iatefl",
      "indices" : [ 137, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/equHQErz5w",
      "expanded_url" : "http:\/\/www.eltjam.com\/eltjam-meets-sugata-mitra\/",
      "display_url" : "eltjam.com\/eltjam-meets-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "461819784557236224",
  "text" : "RT @eltjam: .@nmkrobinson went to Newcastle for a chat with @Sugatam: ELTjam meets Sugata Mitra http:\/\/t.co\/equHQErz5w #elt #esl #edtech #i\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Robinson",
        "screen_name" : "nmkrobinson",
        "indices" : [ 1, 13 ],
        "id_str" : "20425399",
        "id" : 20425399
      }, {
        "name" : "Sugata Mitra",
        "screen_name" : "Sugatam",
        "indices" : [ 48, 56 ],
        "id_str" : "9242922",
        "id" : 9242922
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "elt",
        "indices" : [ 107, 111 ]
      }, {
        "text" : "esl",
        "indices" : [ 112, 116 ]
      }, {
        "text" : "edtech",
        "indices" : [ 117, 124 ]
      }, {
        "text" : "iatefl",
        "indices" : [ 125, 132 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/equHQErz5w",
        "expanded_url" : "http:\/\/www.eltjam.com\/eltjam-meets-sugata-mitra\/",
        "display_url" : "eltjam.com\/eltjam-meets-s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "461788587072430080",
    "text" : ".@nmkrobinson went to Newcastle for a chat with @Sugatam: ELTjam meets Sugata Mitra http:\/\/t.co\/equHQErz5w #elt #esl #edtech #iatefl",
    "id" : 461788587072430080,
    "created_at" : "2014-05-01 08:45:53 +0000",
    "user" : {
      "name" : "ELTjam",
      "screen_name" : "eltjam",
      "protected" : false,
      "id_str" : "1356363686",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700706017441554432\/vqyiSHTx_normal.png",
      "id" : 1356363686,
      "verified" : false
    }
  },
  "id" : 461819784557236224,
  "created_at" : "2014-05-01 10:49:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hana Tich\u00E1",
      "screen_name" : "HanaTicha",
      "indices" : [ 3, 13 ],
      "id_str" : "512296705",
      "id" : 512296705
    }, {
      "name" : "Nicola Prentis",
      "screen_name" : "NicolaPrentis",
      "indices" : [ 118, 132 ],
      "id_str" : "810667033",
      "id" : 810667033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/2lENcSYeQd",
      "expanded_url" : "http:\/\/simpleenglishuk.wordpress.com\/2014\/05\/01\/whos-the-wolf-in-elt\/",
      "display_url" : "simpleenglishuk.wordpress.com\/2014\/05\/01\/who\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "461788138860720128",
  "text" : "RT @HanaTicha: The disgusting lack of respect and the abuse of teachers\u2019 circumstances doesn\u2019t come from Sugata Mitra @NicolaPrentis http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nicola Prentis",
        "screen_name" : "NicolaPrentis",
        "indices" : [ 103, 117 ],
        "id_str" : "810667033",
        "id" : 810667033
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/2lENcSYeQd",
        "expanded_url" : "http:\/\/simpleenglishuk.wordpress.com\/2014\/05\/01\/whos-the-wolf-in-elt\/",
        "display_url" : "simpleenglishuk.wordpress.com\/2014\/05\/01\/who\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "461786585961607168",
    "text" : "The disgusting lack of respect and the abuse of teachers\u2019 circumstances doesn\u2019t come from Sugata Mitra @NicolaPrentis http:\/\/t.co\/2lENcSYeQd",
    "id" : 461786585961607168,
    "created_at" : "2014-05-01 08:37:56 +0000",
    "user" : {
      "name" : "Hana Tich\u00E1",
      "screen_name" : "HanaTicha",
      "protected" : false,
      "id_str" : "512296705",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/699528253598494721\/HL9Np6Gu_normal.jpg",
      "id" : 512296705,
      "verified" : false
    }
  },
  "id" : 461788138860720128,
  "created_at" : "2014-05-01 08:44:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
} ]