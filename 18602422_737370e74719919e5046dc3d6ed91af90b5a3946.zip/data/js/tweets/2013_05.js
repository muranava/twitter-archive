Grailbird.data.tweets_2013_05 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth Anne",
      "screen_name" : "eannegrenoble",
      "indices" : [ 0, 14 ],
      "id_str" : "19869781",
      "id" : 19869781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340575301631344641",
  "geo" : { },
  "id_str" : "340583051933405184",
  "in_reply_to_user_id" : 19869781,
  "text" : "@eannegrenoble thanks :) the zeega thang is pretty cool, load of potential",
  "id" : 340583051933405184,
  "in_reply_to_status_id" : 340575301631344641,
  "created_at" : "2013-05-31 21:38:21 +0000",
  "in_reply_to_screen_name" : "eannegrenoble",
  "in_reply_to_user_id_str" : "19869781",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emma Herrod",
      "screen_name" : "EHerrod",
      "indices" : [ 3, 11 ],
      "id_str" : "20005930",
      "id" : 20005930
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/r9SxSiBhfa",
      "expanded_url" : "http:\/\/emmaherrod.com\/growing-your-vocabulary-for-esol-learners-how-to-do-a-google-news-search\/",
      "display_url" : "emmaherrod.com\/growing-your-v\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "340545521028579330",
  "text" : "RT @EHerrod: Growing your vocabulary for ESOL learners: How to do a Google News Search. http:\/\/t.co\/r9SxSiBhfa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/r9SxSiBhfa",
        "expanded_url" : "http:\/\/emmaherrod.com\/growing-your-vocabulary-for-esol-learners-how-to-do-a-google-news-search\/",
        "display_url" : "emmaherrod.com\/growing-your-v\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "340099702336942080",
    "text" : "Growing your vocabulary for ESOL learners: How to do a Google News Search. http:\/\/t.co\/r9SxSiBhfa",
    "id" : 340099702336942080,
    "created_at" : "2013-05-30 13:37:42 +0000",
    "user" : {
      "name" : "Emma Herrod",
      "screen_name" : "EHerrod",
      "protected" : false,
      "id_str" : "20005930",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1170718661\/Emma_HerrodPINK_normal.jpg",
      "id" : 20005930,
      "verified" : false
    }
  },
  "id" : 340545521028579330,
  "created_at" : "2013-05-31 19:09:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 77, 85 ],
      "id_str" : "10228272",
      "id" : 10228272
    }, {
      "name" : "Timothy Tate",
      "screen_name" : "Timothy_Tate",
      "indices" : [ 89, 102 ],
      "id_str" : "1084531170",
      "id" : 1084531170
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/ndNJBTyydd",
      "expanded_url" : "http:\/\/youtu.be\/vYPBVDZ8_Bs",
      "display_url" : "youtu.be\/vYPBVDZ8_Bs"
    } ]
  },
  "geo" : { },
  "id_str" : "340539295846764544",
  "text" : "Life On The Road | Learn Guitar With David Brent: http:\/\/t.co\/ndNJBTyydd via @youtube cc @Timothy_Tate",
  "id" : 340539295846764544,
  "created_at" : "2013-05-31 18:44:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Moore",
      "screen_name" : "lexicojules",
      "indices" : [ 3, 15 ],
      "id_str" : "424320799",
      "id" : 424320799
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EAPchat",
      "indices" : [ 37, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/RZHaslPX2l",
      "expanded_url" : "http:\/\/ow.ly\/lAzUR",
      "display_url" : "ow.ly\/lAzUR"
    } ]
  },
  "geo" : { },
  "id_str" : "340532914192261120",
  "text" : "RT @lexicojules: Sadly going to miss #EAPchat on Mon, but my contribution about tech tools in EAP is on my blog: http:\/\/t.co\/RZHaslPX2l Hav\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EAPchat",
        "indices" : [ 20, 28 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/RZHaslPX2l",
        "expanded_url" : "http:\/\/ow.ly\/lAzUR",
        "display_url" : "ow.ly\/lAzUR"
      } ]
    },
    "geo" : { },
    "id_str" : "340519822012059648",
    "text" : "Sadly going to miss #EAPchat on Mon, but my contribution about tech tools in EAP is on my blog: http:\/\/t.co\/RZHaslPX2l Have a good chat :)",
    "id" : 340519822012059648,
    "created_at" : "2013-05-31 17:27:06 +0000",
    "user" : {
      "name" : "Julie Moore",
      "screen_name" : "lexicojules",
      "protected" : false,
      "id_str" : "424320799",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/478823971870109696\/AzIax4m3_normal.jpeg",
      "id" : 424320799,
      "verified" : false
    }
  },
  "id" : 340532914192261120,
  "created_at" : "2013-05-31 18:19:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 65, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/aKCZ3wkMKv",
      "expanded_url" : "http:\/\/ihlteachers.co.uk\/?page_id=1287",
      "display_url" : "ihlteachers.co.uk\/?page_id=1287"
    } ]
  },
  "geo" : { },
  "id_str" : "340522579515297792",
  "text" : "some v nice stuff here Systems and skills http:\/\/t.co\/aKCZ3wkMKv #eltchat",
  "id" : 340522579515297792,
  "created_at" : "2013-05-31 17:38:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jo Sayers",
      "screen_name" : "jo_sayers",
      "indices" : [ 0, 10 ],
      "id_str" : "87176766",
      "id" : 87176766
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "teachtheweb",
      "indices" : [ 42, 54 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340442200456458240",
  "geo" : { },
  "id_str" : "340481208590950400",
  "in_reply_to_user_id" : 87176766,
  "text" : "@jo_sayers ak, need to spend more time on #teachtheweb! nice round up.",
  "id" : 340481208590950400,
  "in_reply_to_status_id" : 340442200456458240,
  "created_at" : "2013-05-31 14:53:40 +0000",
  "in_reply_to_screen_name" : "jo_sayers",
  "in_reply_to_user_id_str" : "87176766",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chia Suan Chong",
      "screen_name" : "chiasuan",
      "indices" : [ 0, 9 ],
      "id_str" : "71588589",
      "id" : 71588589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340471608907010048",
  "geo" : { },
  "id_str" : "340474163733073920",
  "in_reply_to_user_id" : 71588589,
  "text" : "@chiasuan good luck hope the weather holds out for you :)",
  "id" : 340474163733073920,
  "in_reply_to_status_id" : 340471608907010048,
  "created_at" : "2013-05-31 14:25:40 +0000",
  "in_reply_to_screen_name" : "chiasuan",
  "in_reply_to_user_id_str" : "71588589",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 0, 13 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340436218506526720",
  "geo" : { },
  "id_str" : "340473965082460160",
  "in_reply_to_user_id" : 88655243,
  "text" : "@rosemerebard hehe no i have yet to, also i missed my chance to get a signed autograph with nick bilborough as well!",
  "id" : 340473965082460160,
  "in_reply_to_status_id" : 340436218506526720,
  "created_at" : "2013-05-31 14:24:53 +0000",
  "in_reply_to_screen_name" : "rosemerebard",
  "in_reply_to_user_id_str" : "88655243",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WIRED",
      "screen_name" : "WIRED",
      "indices" : [ 3, 9 ],
      "id_str" : "1344951",
      "id" : 1344951
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/4Uul1dbcId",
      "expanded_url" : "http:\/\/bit.ly\/10DlPaa",
      "display_url" : "bit.ly\/10DlPaa"
    } ]
  },
  "geo" : { },
  "id_str" : "340472235133382656",
  "text" : "RT @wired: How many retweets will I get? This MIT savant will tell you.  http:\/\/t.co\/4Uul1dbcId",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/adobe.com\" rel=\"nofollow\"\u003EAdobe\u00AE Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 84 ],
        "url" : "http:\/\/t.co\/4Uul1dbcId",
        "expanded_url" : "http:\/\/bit.ly\/10DlPaa",
        "display_url" : "bit.ly\/10DlPaa"
      } ]
    },
    "geo" : { },
    "id_str" : "340445297970929665",
    "text" : "How many retweets will I get? This MIT savant will tell you.  http:\/\/t.co\/4Uul1dbcId",
    "id" : 340445297970929665,
    "created_at" : "2013-05-31 12:30:58 +0000",
    "user" : {
      "name" : "WIRED",
      "screen_name" : "WIRED",
      "protected" : false,
      "id_str" : "1344951",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615598832726970372\/jsK-gBSt_normal.png",
      "id" : 1344951,
      "verified" : true
    }
  },
  "id" : 340472235133382656,
  "created_at" : "2013-05-31 14:18:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KevinHodgson",
      "screen_name" : "dogtrax",
      "indices" : [ 3, 11 ],
      "id_str" : "13307352",
      "id" : 13307352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/gTH1MKUbDy",
      "expanded_url" : "http:\/\/dogtrax.edublogs.org\/2013\/05\/31\/letting-the-poem-go-a-collaborative-writing-experiment-with-teach-the-web\/",
      "display_url" : "dogtrax.edublogs.org\/2013\/05\/31\/let\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "340468928679645184",
  "text" : "RT @dogtrax: Letting the Poem Go: A Collaborative Writing Experiment with Teach the Web http:\/\/t.co\/gTH1MKUbDy Kevin's Meandering Mind",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/mr.-reader\/id412874834?mt=8&uo=4\" rel=\"nofollow\"\u003EMr. Reader on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/gTH1MKUbDy",
        "expanded_url" : "http:\/\/dogtrax.edublogs.org\/2013\/05\/31\/letting-the-poem-go-a-collaborative-writing-experiment-with-teach-the-web\/",
        "display_url" : "dogtrax.edublogs.org\/2013\/05\/31\/let\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "340456432526839808",
    "text" : "Letting the Poem Go: A Collaborative Writing Experiment with Teach the Web http:\/\/t.co\/gTH1MKUbDy Kevin's Meandering Mind",
    "id" : 340456432526839808,
    "created_at" : "2013-05-31 13:15:13 +0000",
    "user" : {
      "name" : "KevinHodgson",
      "screen_name" : "dogtrax",
      "protected" : false,
      "id_str" : "13307352",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629952065809334272\/BKXrDkoi_normal.png",
      "id" : 13307352,
      "verified" : false
    }
  },
  "id" : 340468928679645184,
  "created_at" : "2013-05-31 14:04:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Burcu Akyol",
      "screen_name" : "burcuakyol",
      "indices" : [ 3, 14 ],
      "id_str" : "25390789",
      "id" : 25390789
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "occupygezi",
      "indices" : [ 51, 62 ]
    }, {
      "text" : "direngeziparki",
      "indices" : [ 63, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/yHD22W8yiY",
      "expanded_url" : "https:\/\/docs.google.com\/document\/d\/1j0oh1qHxf-KAtnrklBuV78xSbZ9yGq1ErBrl1NDFAB4\/preview?sle=true",
      "display_url" : "docs.google.com\/document\/d\/1j0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "340450503395778560",
  "text" : "RT @burcuakyol: Please RT. https:\/\/t.co\/yHD22W8yiY #occupygezi #direngeziparki",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "occupygezi",
        "indices" : [ 35, 46 ]
      }, {
        "text" : "direngeziparki",
        "indices" : [ 47, 62 ]
      } ],
      "urls" : [ {
        "indices" : [ 11, 34 ],
        "url" : "https:\/\/t.co\/yHD22W8yiY",
        "expanded_url" : "https:\/\/docs.google.com\/document\/d\/1j0oh1qHxf-KAtnrklBuV78xSbZ9yGq1ErBrl1NDFAB4\/preview?sle=true",
        "display_url" : "docs.google.com\/document\/d\/1j0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "340448049656631297",
    "text" : "Please RT. https:\/\/t.co\/yHD22W8yiY #occupygezi #direngeziparki",
    "id" : 340448049656631297,
    "created_at" : "2013-05-31 12:41:54 +0000",
    "user" : {
      "name" : "Burcu Akyol",
      "screen_name" : "burcuakyol",
      "protected" : false,
      "id_str" : "25390789",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700720343103598592\/XRlAc6i__normal.jpg",
      "id" : 25390789,
      "verified" : false
    }
  },
  "id" : 340450503395778560,
  "created_at" : "2013-05-31 12:51:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephanie McIntosh",
      "screen_name" : "purple_steph",
      "indices" : [ 3, 16 ],
      "id_str" : "18678010",
      "id" : 18678010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/kN9LWt72kx",
      "expanded_url" : "http:\/\/bbc.in\/1aGHG1e",
      "display_url" : "bbc.in\/1aGHG1e"
    } ]
  },
  "geo" : { },
  "id_str" : "340357567949705216",
  "text" : "RT @purple_steph: BBC News - What can we learn from children's writing? http:\/\/t.co\/kN9LWt72kx - fascinating amalysis of vocabulary.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 76 ],
        "url" : "http:\/\/t.co\/kN9LWt72kx",
        "expanded_url" : "http:\/\/bbc.in\/1aGHG1e",
        "display_url" : "bbc.in\/1aGHG1e"
      } ]
    },
    "geo" : { },
    "id_str" : "340353471184252929",
    "text" : "BBC News - What can we learn from children's writing? http:\/\/t.co\/kN9LWt72kx - fascinating amalysis of vocabulary.",
    "id" : 340353471184252929,
    "created_at" : "2013-05-31 06:26:05 +0000",
    "user" : {
      "name" : "Stephanie McIntosh",
      "screen_name" : "purple_steph",
      "protected" : false,
      "id_str" : "18678010",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1869709851\/IMG_2933_-_square_normal.jpg",
      "id" : 18678010,
      "verified" : false
    }
  },
  "id" : 340357567949705216,
  "created_at" : "2013-05-31 06:42:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 0, 13 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340352923546550272",
  "in_reply_to_user_id" : 88655243,
  "text" : "@rosemerebard thanks for rt rose, have a grt w\/e :)",
  "id" : 340352923546550272,
  "created_at" : "2013-05-31 06:23:55 +0000",
  "in_reply_to_screen_name" : "rosemerebard",
  "in_reply_to_user_id_str" : "88655243",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angus B Grieve-Smith",
      "screen_name" : "grvsmth",
      "indices" : [ 3, 11 ],
      "id_str" : "22381639",
      "id" : 22381639
    }, {
      "name" : "Coleman Donaldson",
      "screen_name" : "DonaldsonCD",
      "indices" : [ 25, 37 ],
      "id_str" : "557497345",
      "id" : 557497345
    }, {
      "name" : "H. Samy Alim",
      "screen_name" : "HSamyAlim",
      "indices" : [ 139, 140 ],
      "id_str" : "109747548",
      "id" : 109747548
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/2wtKBiEzPQ",
      "expanded_url" : "http:\/\/speechevents.wordpress.com\/2013\/05\/30\/suc",
      "display_url" : "speechevents.wordpress.com\/2013\/05\/30\/suc"
    } ]
  },
  "geo" : { },
  "id_str" : "340351538339917824",
  "text" : "RT @grvsmth: Tsk, tsk RT @DonaldsonCD On t'a d\u00E9j\u00E0 tchip\u00E9? My look at the verbal gesture sometimes known as suckteeth\nhttp:\/\/t.co\/2wtKBiEzPQ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Coleman Donaldson",
        "screen_name" : "DonaldsonCD",
        "indices" : [ 12, 24 ],
        "id_str" : "557497345",
        "id" : 557497345
      }, {
        "name" : "H. Samy Alim",
        "screen_name" : "HSamyAlim",
        "indices" : [ 130, 140 ],
        "id_str" : "109747548",
        "id" : 109747548
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/2wtKBiEzPQ",
        "expanded_url" : "http:\/\/speechevents.wordpress.com\/2013\/05\/30\/suc",
        "display_url" : "speechevents.wordpress.com\/2013\/05\/30\/suc"
      } ]
    },
    "geo" : { },
    "id_str" : "340263244746874880",
    "text" : "Tsk, tsk RT @DonaldsonCD On t'a de\u0301ja\u0300 tchipe\u0301? My look at the verbal gesture sometimes known as suckteeth\nhttp:\/\/t.co\/2wtKBiEzPQ @HSamyAlim",
    "id" : 340263244746874880,
    "created_at" : "2013-05-31 00:27:33 +0000",
    "user" : {
      "name" : "Angus B Grieve-Smith",
      "screen_name" : "grvsmth",
      "protected" : false,
      "id_str" : "22381639",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/94827231\/portrait_normal.png",
      "id" : 22381639,
      "verified" : false
    }
  },
  "id" : 340351538339917824,
  "created_at" : "2013-05-31 06:18:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WIRED",
      "screen_name" : "WIRED",
      "indices" : [ 3, 9 ],
      "id_str" : "1344951",
      "id" : 1344951
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/zuQGojhTyU",
      "expanded_url" : "http:\/\/oak.ctx.ly\/r\/5pzr",
      "display_url" : "oak.ctx.ly\/r\/5pzr"
    } ]
  },
  "geo" : { },
  "id_str" : "340257422650253312",
  "text" : "RT @wired: NYU grad student builds a tool for sorting and visualizing drone-strike data. http:\/\/t.co\/zuQGojhTyU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/adobe.com\" rel=\"nofollow\"\u003EAdobe\u00AE Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/zuQGojhTyU",
        "expanded_url" : "http:\/\/oak.ctx.ly\/r\/5pzr",
        "display_url" : "oak.ctx.ly\/r\/5pzr"
      } ]
    },
    "geo" : { },
    "id_str" : "340251425479196672",
    "text" : "NYU grad student builds a tool for sorting and visualizing drone-strike data. http:\/\/t.co\/zuQGojhTyU",
    "id" : 340251425479196672,
    "created_at" : "2013-05-30 23:40:36 +0000",
    "user" : {
      "name" : "WIRED",
      "screen_name" : "WIRED",
      "protected" : false,
      "id_str" : "1344951",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615598832726970372\/jsK-gBSt_normal.png",
      "id" : 1344951,
      "verified" : true
    }
  },
  "id" : 340257422650253312,
  "created_at" : "2013-05-31 00:04:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Les Adams",
      "screen_name" : "LesAdams3",
      "indices" : [ 3, 13 ],
      "id_str" : "581792166",
      "id" : 581792166
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SibelEdmonds",
      "indices" : [ 58, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/ZG4ixZTx5Y",
      "expanded_url" : "http:\/\/ceasefiremagazine.co.uk\/whistleblower-al-qaeda-chief-u-s-asset\/",
      "display_url" : "ceasefiremagazine.co.uk\/whistleblower-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "340247946492772352",
  "text" : "RT @LesAdams3: Wow. Quite a story. http:\/\/t.co\/ZG4ixZTx5Y #SibelEdmonds",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SibelEdmonds",
        "indices" : [ 43, 56 ]
      } ],
      "urls" : [ {
        "indices" : [ 20, 42 ],
        "url" : "http:\/\/t.co\/ZG4ixZTx5Y",
        "expanded_url" : "http:\/\/ceasefiremagazine.co.uk\/whistleblower-al-qaeda-chief-u-s-asset\/",
        "display_url" : "ceasefiremagazine.co.uk\/whistleblower-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "340228683568664576",
    "text" : "Wow. Quite a story. http:\/\/t.co\/ZG4ixZTx5Y #SibelEdmonds",
    "id" : 340228683568664576,
    "created_at" : "2013-05-30 22:10:13 +0000",
    "user" : {
      "name" : "Les Adams",
      "screen_name" : "LesAdams3",
      "protected" : false,
      "id_str" : "581792166",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2330611582\/rldnjf1zjs9alsju5w02_normal.jpeg",
      "id" : 581792166,
      "verified" : false
    }
  },
  "id" : 340247946492772352,
  "created_at" : "2013-05-30 23:26:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike S. Boyle",
      "screen_name" : "heyboyle",
      "indices" : [ 0, 9 ],
      "id_str" : "612840231",
      "id" : 612840231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/k46CzCdQaB",
      "expanded_url" : "http:\/\/splasho.com\/upgoer5\/",
      "display_url" : "splasho.com\/upgoer5\/"
    } ]
  },
  "in_reply_to_status_id_str" : "340240053966077956",
  "geo" : { },
  "id_str" : "340242874035748864",
  "in_reply_to_user_id" : 612840231,
  "text" : "@heyboyle data shows not says that? the oxford peeps suggest 90-95% so 7K-50K lemmas. maybe100 word version of http:\/\/t.co\/k46CzCdQaB? :)",
  "id" : 340242874035748864,
  "in_reply_to_status_id" : 340240053966077956,
  "created_at" : "2013-05-30 23:06:37 +0000",
  "in_reply_to_screen_name" : "heyboyle",
  "in_reply_to_user_id_str" : "612840231",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "phil wade",
      "screen_name" : "phil3wade",
      "indices" : [ 0, 10 ],
      "id_str" : "248864761",
      "id" : 248864761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340132878044258306",
  "geo" : { },
  "id_str" : "340239716333015041",
  "in_reply_to_user_id" : 248864761,
  "text" : "@phil3wade what does yr student says it means?",
  "id" : 340239716333015041,
  "in_reply_to_status_id" : 340132878044258306,
  "created_at" : "2013-05-30 22:54:04 +0000",
  "in_reply_to_screen_name" : "phil3wade",
  "in_reply_to_user_id_str" : "248864761",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 83, 91 ]
    }, {
      "text" : "corpuslinguistics",
      "indices" : [ 92, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/4eqsbZ7NtV",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-DC",
      "display_url" : "wp.me\/pgHyE-DC"
    } ]
  },
  "geo" : { },
  "id_str" : "340226382552522752",
  "text" : "new post Dictionnaire Cobra \u2013 A striking corpus based tool http:\/\/t.co\/4eqsbZ7NtV  #eltchat #corpuslinguistics",
  "id" : 340226382552522752,
  "created_at" : "2013-05-30 22:01:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gigsinparis",
      "screen_name" : "gigsinparis",
      "indices" : [ 3, 15 ],
      "id_str" : "220038090",
      "id" : 220038090
    }, {
      "name" : "Iron & Wine",
      "screen_name" : "IronAndWine",
      "indices" : [ 55, 67 ],
      "id_str" : "174381739",
      "id" : 174381739
    }, {
      "name" : "La Cigale",
      "screen_name" : "LaCigaleParis",
      "indices" : [ 73, 87 ],
      "id_str" : "382115015",
      "id" : 382115015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340210127862898688",
  "text" : "RT @gigsinparis: We're giving away four tickets to see @IronAndWine play @LaCigaleParis on Saturday, if you want to be in with a chance jus\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Iron & Wine",
        "screen_name" : "IronAndWine",
        "indices" : [ 38, 50 ],
        "id_str" : "174381739",
        "id" : 174381739
      }, {
        "name" : "La Cigale",
        "screen_name" : "LaCigaleParis",
        "indices" : [ 56, 70 ],
        "id_str" : "382115015",
        "id" : 382115015
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "340163644417523713",
    "text" : "We're giving away four tickets to see @IronAndWine play @LaCigaleParis on Saturday, if you want to be in with a chance just RT this message!",
    "id" : 340163644417523713,
    "created_at" : "2013-05-30 17:51:47 +0000",
    "user" : {
      "name" : "gigsinparis",
      "screen_name" : "gigsinparis",
      "protected" : false,
      "id_str" : "220038090",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/557775021536342016\/wteymqXK_normal.jpeg",
      "id" : 220038090,
      "verified" : false
    }
  },
  "id" : 340210127862898688,
  "created_at" : "2013-05-30 20:56:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stan Carey",
      "screen_name" : "StanCarey",
      "indices" : [ 3, 13 ],
      "id_str" : "34347535",
      "id" : 34347535
    }, {
      "name" : "Robert Lane Greene",
      "screen_name" : "lanegreene",
      "indices" : [ 110, 121 ],
      "id_str" : "49170981",
      "id" : 49170981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/OKrjwF3tpE",
      "expanded_url" : "http:\/\/econ.st\/11qwIrh",
      "display_url" : "econ.st\/11qwIrh"
    } ]
  },
  "geo" : { },
  "id_str" : "340133495525478401",
  "text" : "RT @StanCarey: Fiction typically has a wider range of vocabulary than non-fiction: http:\/\/t.co\/OKrjwF3tpE h\/t @lanegreene",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Robert Lane Greene",
        "screen_name" : "lanegreene",
        "indices" : [ 95, 106 ],
        "id_str" : "49170981",
        "id" : 49170981
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/OKrjwF3tpE",
        "expanded_url" : "http:\/\/econ.st\/11qwIrh",
        "display_url" : "econ.st\/11qwIrh"
      } ]
    },
    "geo" : { },
    "id_str" : "340026972639989760",
    "text" : "Fiction typically has a wider range of vocabulary than non-fiction: http:\/\/t.co\/OKrjwF3tpE h\/t @lanegreene",
    "id" : 340026972639989760,
    "created_at" : "2013-05-30 08:48:42 +0000",
    "user" : {
      "name" : "Stan Carey",
      "screen_name" : "StanCarey",
      "protected" : false,
      "id_str" : "34347535",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/611193710240514048\/w5lUpuqq_normal.jpg",
      "id" : 34347535,
      "verified" : false
    }
  },
  "id" : 340133495525478401,
  "created_at" : "2013-05-30 15:51:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Antoine Besnehard",
      "screen_name" : "Languages2_0",
      "indices" : [ 0, 13 ],
      "id_str" : "28194214",
      "id" : 28194214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340008258515369984",
  "geo" : { },
  "id_str" : "340125057554722816",
  "in_reply_to_user_id" : 28194214,
  "text" : "@Languages2_0 salut, vouz savez sur quelle corpus est-ce que ca s'est base? merci",
  "id" : 340125057554722816,
  "in_reply_to_status_id" : 340008258515369984,
  "created_at" : "2013-05-30 15:18:27 +0000",
  "in_reply_to_screen_name" : "Languages2_0",
  "in_reply_to_user_id_str" : "28194214",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hedonometer",
      "screen_name" : "hedonometer",
      "indices" : [ 90, 102 ],
      "id_str" : "611941887",
      "id" : 611941887
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/lUwmjUrIlt",
      "expanded_url" : "http:\/\/www.hedonometer.org",
      "display_url" : "hedonometer.org"
    } ]
  },
  "geo" : { },
  "id_str" : "340104899763269633",
  "text" : "A Remote-Sensor of Population Level Happiness: The Hedonometer http:\/\/t.co\/lUwmjUrIlt via @hedonometer",
  "id" : 340104899763269633,
  "created_at" : "2013-05-30 13:58:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adi Rajan",
      "screen_name" : "adi_rajan",
      "indices" : [ 0, 10 ],
      "id_str" : "1011323449",
      "id" : 1011323449
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340100209923194880",
  "geo" : { },
  "id_str" : "340103197173624833",
  "in_reply_to_user_id" : 1011323449,
  "text" : "@adi_rajan hehe, there are some interesting stats e.g. readabilty index",
  "id" : 340103197173624833,
  "in_reply_to_status_id" : 340100209923194880,
  "created_at" : "2013-05-30 13:51:35 +0000",
  "in_reply_to_screen_name" : "adi_rajan",
  "in_reply_to_user_id_str" : "1011323449",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Levine",
      "screen_name" : "cogdog",
      "indices" : [ 23, 30 ],
      "id_str" : "740343",
      "id" : 740343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340099564486918144",
  "text" : "not sure whether to HT @cogdog for those lost tweeting time on my tweeting personality :\/",
  "id" : 340099564486918144,
  "created_at" : "2013-05-30 13:37:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/whSgEJ6BXU",
      "expanded_url" : "http:\/\/twanalyst.com\/",
      "display_url" : "twanalyst.com"
    } ]
  },
  "geo" : { },
  "id_str" : "340099201226661888",
  "text" : "My Twitter personality: popular inquisitive cautious My style: chatty academic PARROT http:\/\/t.co\/whSgEJ6BXU",
  "id" : 340099201226661888,
  "created_at" : "2013-05-30 13:35:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/W8UUCtS6kz",
      "expanded_url" : "http:\/\/analyzewords.com\/?handle=muranava",
      "display_url" : "analyzewords.com\/?handle=murana\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "340098837945405440",
  "text" : "i tweet arrogant, what a load of... :)&gt;Currently reading http:\/\/t.co\/W8UUCtS6kz",
  "id" : 340098837945405440,
  "created_at" : "2013-05-30 13:34:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 46, 55 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Dan Zarrella",
      "screen_name" : "danzarrella",
      "indices" : [ 85, 97 ],
      "id_str" : "3611041",
      "id" : 3611041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/OwCoivivVt",
      "expanded_url" : "http:\/\/TweetPsych.com?q=muranava",
      "display_url" : "TweetPsych.com\/?q=muranava"
    } ]
  },
  "geo" : { },
  "id_str" : "340097783254097920",
  "text" : "neat tool&gt;Twitter Psychological Profile of @muranava: http:\/\/t.co\/OwCoivivVt from @danzarrella\/",
  "id" : 340097783254097920,
  "created_at" : "2013-05-30 13:30:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "phil wade",
      "screen_name" : "phil3wade",
      "indices" : [ 0, 10 ],
      "id_str" : "248864761",
      "id" : 248864761
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/340069894408265728\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/ekYyoM2Zrw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BLgrxGeCYAA6KIH.png",
      "id_str" : "340069894416654336",
      "id" : 340069894416654336,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BLgrxGeCYAA6KIH.png",
      "sizes" : [ {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1366
      } ],
      "display_url" : "pic.twitter.com\/ekYyoM2Zrw"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/m9Uk3lPEzI",
      "expanded_url" : "http:\/\/corpus2.byu.edu\/glowbe\/?c=glowbe&q=23477703",
      "display_url" : "corpus2.byu.edu\/glowbe\/?c=glow\u2026"
    }, {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/ul8BcDYzjQ",
      "expanded_url" : "http:\/\/langbank.engl.polyu.edu.hk\/HKFSC\/",
      "display_url" : "langbank.engl.polyu.edu.hk\/HKFSC\/"
    } ]
  },
  "in_reply_to_status_id_str" : "339666602335293441",
  "geo" : { },
  "id_str" : "340069894408265728",
  "in_reply_to_user_id" : 248864761,
  "text" : "@phil3wade only 2 entries in GloWbE http:\/\/t.co\/m9Uk3lPEzI bt 'entry time', non in HKFSC http:\/\/t.co\/ul8BcDYzjQ c pic http:\/\/t.co\/ekYyoM2Zrw",
  "id" : 340069894408265728,
  "in_reply_to_status_id" : 339666602335293441,
  "created_at" : "2013-05-30 11:39:15 +0000",
  "in_reply_to_screen_name" : "phil3wade",
  "in_reply_to_user_id_str" : "248864761",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/6whO5lXYH8",
      "expanded_url" : "http:\/\/wp.me\/p2tYU2-b3",
      "display_url" : "wp.me\/p2tYU2-b3"
    } ]
  },
  "geo" : { },
  "id_str" : "340048180488073216",
  "text" : "New British Council Award for ELT Masters Dissertations http:\/\/t.co\/6whO5lXYH8 via @CLERAatAston",
  "id" : 340048180488073216,
  "created_at" : "2013-05-30 10:12:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Antoine Besnehard",
      "screen_name" : "Languages2_0",
      "indices" : [ 3, 16 ],
      "id_str" : "28194214",
      "id" : 28194214
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowTalking",
      "indices" : [ 18, 29 ]
    }, {
      "text" : "CLV2013",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/pBNQZtNRye",
      "expanded_url" : "http:\/\/webapps.fundp.ac.be\/elv\/nederlex\/dico\/dico.php?language=EN",
      "display_url" : "webapps.fundp.ac.be\/elv\/nederlex\/d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "340020246939312128",
  "text" : "RT @Languages2_0: #NowTalking Guy Deville : CoBRA = Corpus Based Reading Assistance. L'application se trouve ici : http:\/\/t.co\/pBNQZtNRye #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NowTalking",
        "indices" : [ 0, 11 ]
      }, {
        "text" : "CLV2013",
        "indices" : [ 120, 128 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/pBNQZtNRye",
        "expanded_url" : "http:\/\/webapps.fundp.ac.be\/elv\/nederlex\/dico\/dico.php?language=EN",
        "display_url" : "webapps.fundp.ac.be\/elv\/nederlex\/d\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "340008258515369984",
    "text" : "#NowTalking Guy Deville : CoBRA = Corpus Based Reading Assistance. L'application se trouve ici : http:\/\/t.co\/pBNQZtNRye #CLV2013",
    "id" : 340008258515369984,
    "created_at" : "2013-05-30 07:34:20 +0000",
    "user" : {
      "name" : "Antoine Besnehard",
      "screen_name" : "Languages2_0",
      "protected" : false,
      "id_str" : "28194214",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/518049201561690114\/LW4jd5u0_normal.jpeg",
      "id" : 28194214,
      "verified" : false
    }
  },
  "id" : 340020246939312128,
  "created_at" : "2013-05-30 08:21:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/JeN0eIicUG",
      "expanded_url" : "http:\/\/ow.ly\/luwLW",
      "display_url" : "ow.ly\/luwLW"
    } ]
  },
  "geo" : { },
  "id_str" : "339810212481466368",
  "text" : "RT @medialens: Media Alert: 'The Planet Can't Keep Doing Us A Favour' http:\/\/t.co\/JeN0eIicUG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/JeN0eIicUG",
        "expanded_url" : "http:\/\/ow.ly\/luwLW",
        "display_url" : "ow.ly\/luwLW"
      } ]
    },
    "geo" : { },
    "id_str" : "339642971714621440",
    "text" : "Media Alert: 'The Planet Can't Keep Doing Us A Favour' http:\/\/t.co\/JeN0eIicUG",
    "id" : 339642971714621440,
    "created_at" : "2013-05-29 07:22:49 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 339810212481466368,
  "created_at" : "2013-05-29 18:27:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 0, 11 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "339699260167688193",
  "geo" : { },
  "id_str" : "339792158515146752",
  "in_reply_to_user_id" : 87902543,
  "text" : "@tornhalves after looking up monadology none the wiser, thgh monads does rhyme with something funny :)",
  "id" : 339792158515146752,
  "in_reply_to_status_id" : 339699260167688193,
  "created_at" : "2013-05-29 17:15:38 +0000",
  "in_reply_to_screen_name" : "tornhalves",
  "in_reply_to_user_id_str" : "87902543",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lexconf2013",
      "indices" : [ 82, 94 ]
    }, {
      "text" : "elt",
      "indices" : [ 95, 99 ]
    }, {
      "text" : "grammar",
      "indices" : [ 100, 108 ]
    }, {
      "text" : "translation",
      "indices" : [ 109, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 123, 140 ],
      "url" : "http:\/\/t.co\/1BjNf90TzO",
      "expanded_url" : "http:\/\/bit.ly\/112IS9N",
      "display_url" : "bit.ly\/112IS9N"
    } ]
  },
  "geo" : { },
  "id_str" : "339790813431205888",
  "text" : "RT @CELTtraining: Two more postings on talks from the lexical teaching conference.#lexconf2013 #elt #grammar #translation. http:\/\/t.co\/1BjN\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "lexconf2013",
        "indices" : [ 64, 76 ]
      }, {
        "text" : "elt",
        "indices" : [ 77, 81 ]
      }, {
        "text" : "grammar",
        "indices" : [ 82, 90 ]
      }, {
        "text" : "translation",
        "indices" : [ 91, 103 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/1BjNf90TzO",
        "expanded_url" : "http:\/\/bit.ly\/112IS9N",
        "display_url" : "bit.ly\/112IS9N"
      } ]
    },
    "geo" : { },
    "id_str" : "339777815236976641",
    "text" : "Two more postings on talks from the lexical teaching conference.#lexconf2013 #elt #grammar #translation. http:\/\/t.co\/1BjNf90TzO",
    "id" : 339777815236976641,
    "created_at" : "2013-05-29 16:18:38 +0000",
    "user" : {
      "name" : "Lexical Lab",
      "screen_name" : "LexicalLab",
      "protected" : false,
      "id_str" : "857732892",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/559654844831506432\/F4HWliCf_normal.jpeg",
      "id" : 857732892,
      "verified" : false
    }
  },
  "id" : 339790813431205888,
  "created_at" : "2013-05-29 17:10:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Timothy Tate",
      "screen_name" : "Timothy_Tate",
      "indices" : [ 3, 16 ],
      "id_str" : "1084531170",
      "id" : 1084531170
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/Ls5hZ1auuv",
      "expanded_url" : "http:\/\/Spectable.com",
      "display_url" : "Spectable.com"
    }, {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/hl45P2e4iW",
      "expanded_url" : "http:\/\/www.spectable.com\/concert-de-guitare-montmartre-samedi-juin-20h\/217483\/270600#.UaXT0KN5dnY.twitter",
      "display_url" : "spectable.com\/concert-de-gui\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "339690433846317059",
  "text" : "RT @Timothy_Tate: Concert de guitare \u00E0 Montmartre - samedi 8 juin, 20h - Paris 18 Buttes-Montmartre (75018) - http:\/\/t.co\/Ls5hZ1auuv http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/Ls5hZ1auuv",
        "expanded_url" : "http:\/\/Spectable.com",
        "display_url" : "Spectable.com"
      }, {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/hl45P2e4iW",
        "expanded_url" : "http:\/\/www.spectable.com\/concert-de-guitare-montmartre-samedi-juin-20h\/217483\/270600#.UaXT0KN5dnY.twitter",
        "display_url" : "spectable.com\/concert-de-gui\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "339684995310424065",
    "text" : "Concert de guitare \u00E0 Montmartre - samedi 8 juin, 20h - Paris 18 Buttes-Montmartre (75018) - http:\/\/t.co\/Ls5hZ1auuv http:\/\/t.co\/hl45P2e4iW",
    "id" : 339684995310424065,
    "created_at" : "2013-05-29 10:09:48 +0000",
    "user" : {
      "name" : "Timothy Tate",
      "screen_name" : "Timothy_Tate",
      "protected" : false,
      "id_str" : "1084531170",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3578723900\/41c4d3a262e0defc1126475c46be261f_normal.jpeg",
      "id" : 1084531170,
      "verified" : false
    }
  },
  "id" : 339690433846317059,
  "created_at" : "2013-05-29 10:31:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BELTA Belgium",
      "screen_name" : "BELTABelgium",
      "indices" : [ 3, 16 ],
      "id_str" : "884934438",
      "id" : 884934438
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iatefl",
      "indices" : [ 99, 106 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 107, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/AVX2Gyzg7x",
      "expanded_url" : "http:\/\/ow.ly\/luMl2",
      "display_url" : "ow.ly\/luMl2"
    } ]
  },
  "geo" : { },
  "id_str" : "339689081896321024",
  "text" : "RT @BELTABelgium: You can still register for our first ever BELTA day here: http:\/\/t.co\/AVX2Gyzg7x #iatefl #eltchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "iatefl",
        "indices" : [ 81, 88 ]
      }, {
        "text" : "eltchat",
        "indices" : [ 89, 97 ]
      } ],
      "urls" : [ {
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/AVX2Gyzg7x",
        "expanded_url" : "http:\/\/ow.ly\/luMl2",
        "display_url" : "ow.ly\/luMl2"
      } ]
    },
    "geo" : { },
    "id_str" : "339685817427566593",
    "text" : "You can still register for our first ever BELTA day here: http:\/\/t.co\/AVX2Gyzg7x #iatefl #eltchat",
    "id" : 339685817427566593,
    "created_at" : "2013-05-29 10:13:04 +0000",
    "user" : {
      "name" : "BELTA Belgium",
      "screen_name" : "BELTABelgium",
      "protected" : false,
      "id_str" : "884934438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3130800745\/d36391a9857692e6c2aab76d0033ade0_normal.png",
      "id" : 884934438,
      "verified" : false
    }
  },
  "id" : 339689081896321024,
  "created_at" : "2013-05-29 10:26:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zeega",
      "screen_name" : "Zeega",
      "indices" : [ 48, 54 ],
      "id_str" : "356158929",
      "id" : 356158929
    }, {
      "name" : "Seeta",
      "screen_name" : "Seeta_eu",
      "indices" : [ 105, 114 ],
      "id_str" : "401339993",
      "id" : 401339993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/BTpB4YYhmE",
      "expanded_url" : "http:\/\/zeega.com\/126131",
      "display_url" : "zeega.com\/126131"
    } ]
  },
  "geo" : { },
  "id_str" : "339683834029301761",
  "text" : "Why do you blog? http:\/\/t.co\/BTpB4YYhmE made w\/ @zeega &gt; a reflection based on initial discussions at @Seeta_eu webchat and teachers lounge",
  "id" : 339683834029301761,
  "created_at" : "2013-05-29 10:05:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Willingham",
      "screen_name" : "DTWillingham",
      "indices" : [ 3, 16 ],
      "id_str" : "84619537",
      "id" : 84619537
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edchat",
      "indices" : [ 109, 116 ]
    }, {
      "text" : "ukedchat",
      "indices" : [ 117, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/oATZbx7dVw",
      "expanded_url" : "http:\/\/bit.ly\/142rOmi",
      "display_url" : "bit.ly\/142rOmi"
    } ]
  },
  "geo" : { },
  "id_str" : "339410095374995458",
  "text" : "RT @DTWillingham: Willingham blog: Learning styles, science, practice, and Disneyland\nhttp:\/\/t.co\/oATZbx7dVw #edchat #ukedchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "edchat",
        "indices" : [ 91, 98 ]
      }, {
        "text" : "ukedchat",
        "indices" : [ 99, 108 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/oATZbx7dVw",
        "expanded_url" : "http:\/\/bit.ly\/142rOmi",
        "display_url" : "bit.ly\/142rOmi"
      } ]
    },
    "geo" : { },
    "id_str" : "339383141057826816",
    "text" : "Willingham blog: Learning styles, science, practice, and Disneyland\nhttp:\/\/t.co\/oATZbx7dVw #edchat #ukedchat",
    "id" : 339383141057826816,
    "created_at" : "2013-05-28 14:10:20 +0000",
    "user" : {
      "name" : "Daniel Willingham",
      "screen_name" : "DTWillingham",
      "protected" : false,
      "id_str" : "84619537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1815678310\/Daniel_Willingham_Color_lowres_normal.JPG",
      "id" : 84619537,
      "verified" : false
    }
  },
  "id" : 339410095374995458,
  "created_at" : "2013-05-28 15:57:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 3, 19 ],
      "id_str" : "394053348",
      "id" : 394053348
    }, {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 26, 37 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "er",
      "indices" : [ 107, 110 ]
    }, {
      "text" : "erchat",
      "indices" : [ 111, 118 ]
    }, {
      "text" : "ELTchat",
      "indices" : [ 119, 127 ]
    }, {
      "text" : "keltchat",
      "indices" : [ 128, 137 ]
    }, {
      "text" : "reading",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "efl",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "esl",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/B6H2dz0woN",
      "expanded_url" : "http:\/\/theotherthingsmatter.blogspot.jp\/2013\/05\/extensive-reading-but-what-if.html",
      "display_url" : "theotherthingsmatter.blogspot.jp\/2013\/05\/extens\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "339320043043168256",
  "text" : "RT @michaelegriffin: Here @kevchanwow demystifies and decultifies extensive reading http:\/\/t.co\/B6H2dz0woN #er #erchat #ELTchat #keltchat #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kevin Stein",
        "screen_name" : "kevchanwow",
        "indices" : [ 5, 16 ],
        "id_str" : "144663117",
        "id" : 144663117
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "er",
        "indices" : [ 86, 89 ]
      }, {
        "text" : "erchat",
        "indices" : [ 90, 97 ]
      }, {
        "text" : "ELTchat",
        "indices" : [ 98, 106 ]
      }, {
        "text" : "keltchat",
        "indices" : [ 107, 116 ]
      }, {
        "text" : "reading",
        "indices" : [ 117, 125 ]
      }, {
        "text" : "efl",
        "indices" : [ 126, 130 ]
      }, {
        "text" : "esl",
        "indices" : [ 131, 135 ]
      } ],
      "urls" : [ {
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/B6H2dz0woN",
        "expanded_url" : "http:\/\/theotherthingsmatter.blogspot.jp\/2013\/05\/extensive-reading-but-what-if.html",
        "display_url" : "theotherthingsmatter.blogspot.jp\/2013\/05\/extens\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "339254190771675136",
    "geo" : { },
    "id_str" : "339302889350635520",
    "in_reply_to_user_id" : 144663117,
    "text" : "Here @kevchanwow demystifies and decultifies extensive reading http:\/\/t.co\/B6H2dz0woN #er #erchat #ELTchat #keltchat #reading #efl #esl",
    "id" : 339302889350635520,
    "in_reply_to_status_id" : 339254190771675136,
    "created_at" : "2013-05-28 08:51:27 +0000",
    "in_reply_to_screen_name" : "kevchanwow",
    "in_reply_to_user_id_str" : "144663117",
    "user" : {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "protected" : false,
      "id_str" : "394053348",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766911330645315584\/il5gKyOJ_normal.jpg",
      "id" : 394053348,
      "verified" : false
    }
  },
  "id" : 339320043043168256,
  "created_at" : "2013-05-28 09:59:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jo Sayers",
      "screen_name" : "jo_sayers",
      "indices" : [ 3, 13 ],
      "id_str" : "87176766",
      "id" : 87176766
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "teachtheweb",
      "indices" : [ 89, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/PiguyNDynz",
      "expanded_url" : "http:\/\/www.eltplustech.com\/2013\/05\/the-importance-of-being-open-teachtheweb.html",
      "display_url" : "eltplustech.com\/2013\/05\/the-im\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "339319912398991360",
  "text" : "RT @jo_sayers: The importance of being Open, new reflection post: http:\/\/t.co\/PiguyNDynz #teachtheweb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "teachtheweb",
        "indices" : [ 74, 86 ]
      } ],
      "urls" : [ {
        "indices" : [ 51, 73 ],
        "url" : "http:\/\/t.co\/PiguyNDynz",
        "expanded_url" : "http:\/\/www.eltplustech.com\/2013\/05\/the-importance-of-being-open-teachtheweb.html",
        "display_url" : "eltplustech.com\/2013\/05\/the-im\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "339319119650365440",
    "text" : "The importance of being Open, new reflection post: http:\/\/t.co\/PiguyNDynz #teachtheweb",
    "id" : 339319119650365440,
    "created_at" : "2013-05-28 09:55:57 +0000",
    "user" : {
      "name" : "Jo Sayers",
      "screen_name" : "jo_sayers",
      "protected" : false,
      "id_str" : "87176766",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/466896591480037376\/EssZHYa4_normal.jpeg",
      "id" : 87176766,
      "verified" : false
    }
  },
  "id" : 339319912398991360,
  "created_at" : "2013-05-28 09:59:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 26, 37 ],
      "id_str" : "282659955",
      "id" : 282659955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339319536849399808",
  "text" : "last-minute-prep blues: 0 @teflerinha downloadable lessons: 2\n:)",
  "id" : 339319536849399808,
  "created_at" : "2013-05-28 09:57:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anne Hodgson",
      "screen_name" : "annehodg",
      "indices" : [ 0, 9 ],
      "id_str" : "17589213",
      "id" : 17589213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "339032335326515200",
  "geo" : { },
  "id_str" : "339052011725131776",
  "in_reply_to_user_id" : 17589213,
  "text" : "@annehodg cheers anne:)",
  "id" : 339052011725131776,
  "in_reply_to_status_id" : 339032335326515200,
  "created_at" : "2013-05-27 16:14:33 +0000",
  "in_reply_to_screen_name" : "annehodg",
  "in_reply_to_user_id_str" : "17589213",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Hilliger",
      "screen_name" : "epilepticrabbit",
      "indices" : [ 3, 19 ],
      "id_str" : "212475110",
      "id" : 212475110
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "teachtheweb",
      "indices" : [ 49, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/ScessYMqol",
      "expanded_url" : "http:\/\/mzl.la\/gpluswebmaker",
      "display_url" : "mzl.la\/gpluswebmaker"
    } ]
  },
  "geo" : { },
  "id_str" : "339051924764635136",
  "text" : "RT @epilepticrabbit: If you're feeling behind in #teachtheweb DON'T!! There is no behind, no deadlines, no pressure. Join us, make stuff - \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "teachtheweb",
        "indices" : [ 28, 40 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/ScessYMqol",
        "expanded_url" : "http:\/\/mzl.la\/gpluswebmaker",
        "display_url" : "mzl.la\/gpluswebmaker"
      } ]
    },
    "geo" : { },
    "id_str" : "339021691252523009",
    "text" : "If you're feeling behind in #teachtheweb DON'T!! There is no behind, no deadlines, no pressure. Join us, make stuff - http:\/\/t.co\/ScessYMqol",
    "id" : 339021691252523009,
    "created_at" : "2013-05-27 14:14:04 +0000",
    "user" : {
      "name" : "Laura Hilliger",
      "screen_name" : "epilepticrabbit",
      "protected" : false,
      "id_str" : "212475110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1161722291\/profilepic_normal.jpg",
      "id" : 212475110,
      "verified" : false
    }
  },
  "id" : 339051924764635136,
  "created_at" : "2013-05-27 16:14:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELTjam",
      "screen_name" : "eltjam",
      "indices" : [ 3, 10 ],
      "id_str" : "1356363686",
      "id" : 1356363686
    }, {
      "name" : "Applied Linguistics",
      "screen_name" : "ACLA_CAAL",
      "indices" : [ 13, 23 ],
      "id_str" : "616455707",
      "id" : 616455707
    }, {
      "name" : "The Week",
      "screen_name" : "TheWeek",
      "indices" : [ 105, 113 ],
      "id_str" : "16439471",
      "id" : 16439471
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/ccyVsrZDTA",
      "expanded_url" : "http:\/\/shar.es\/ZFGeH",
      "display_url" : "shar.es\/ZFGeH"
    } ]
  },
  "geo" : { },
  "id_str" : "339027877322436608",
  "text" : "RT @eltjam: \u201C@ACLA_CAAL: A linguistic dissection of 7 annoying teenage sounds http:\/\/t.co\/ccyVsrZDTA via @TheWeek\u201D Great, if you haven't se\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Applied Linguistics",
        "screen_name" : "ACLA_CAAL",
        "indices" : [ 1, 11 ],
        "id_str" : "616455707",
        "id" : 616455707
      }, {
        "name" : "The Week",
        "screen_name" : "TheWeek",
        "indices" : [ 93, 101 ],
        "id_str" : "16439471",
        "id" : 16439471
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 88 ],
        "url" : "http:\/\/t.co\/ccyVsrZDTA",
        "expanded_url" : "http:\/\/shar.es\/ZFGeH",
        "display_url" : "shar.es\/ZFGeH"
      } ]
    },
    "in_reply_to_status_id_str" : "338497122552918016",
    "geo" : { },
    "id_str" : "338565563565633536",
    "in_reply_to_user_id" : 616455707,
    "text" : "\u201C@ACLA_CAAL: A linguistic dissection of 7 annoying teenage sounds http:\/\/t.co\/ccyVsrZDTA via @TheWeek\u201D Great, if you haven't seen it already",
    "id" : 338565563565633536,
    "in_reply_to_status_id" : 338497122552918016,
    "created_at" : "2013-05-26 08:01:35 +0000",
    "in_reply_to_screen_name" : "ACLA_CAAL",
    "in_reply_to_user_id_str" : "616455707",
    "user" : {
      "name" : "ELTjam",
      "screen_name" : "eltjam",
      "protected" : false,
      "id_str" : "1356363686",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700706017441554432\/vqyiSHTx_normal.png",
      "id" : 1356363686,
      "verified" : false
    }
  },
  "id" : 339027877322436608,
  "created_at" : "2013-05-27 14:38:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil Longwell",
      "screen_name" : "teacherphili",
      "indices" : [ 3, 16 ],
      "id_str" : "67863264",
      "id" : 67863264
    }, {
      "name" : "Scott Thornbury",
      "screen_name" : "thornburyscott",
      "indices" : [ 76, 91 ],
      "id_str" : "23090474",
      "id" : 23090474
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELTchat",
      "indices" : [ 26, 34 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/c5VLWVIgsr",
      "expanded_url" : "http:\/\/bit.ly\/1293rCn",
      "display_url" : "bit.ly\/1293rCn"
    } ]
  },
  "geo" : { },
  "id_str" : "339020701069619200",
  "text" : "RT @teacherphili: Updated #ELTchat summary on using corpora, accounting for @thornburyscott taking up the COCA 'screencast' challenge. http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Scott Thornbury",
        "screen_name" : "thornburyscott",
        "indices" : [ 58, 73 ],
        "id_str" : "23090474",
        "id" : 23090474
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELTchat",
        "indices" : [ 8, 16 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/c5VLWVIgsr",
        "expanded_url" : "http:\/\/bit.ly\/1293rCn",
        "display_url" : "bit.ly\/1293rCn"
      } ]
    },
    "geo" : { },
    "id_str" : "338998933646897152",
    "text" : "Updated #ELTchat summary on using corpora, accounting for @thornburyscott taking up the COCA 'screencast' challenge. http:\/\/t.co\/c5VLWVIgsr",
    "id" : 338998933646897152,
    "created_at" : "2013-05-27 12:43:38 +0000",
    "user" : {
      "name" : "Phil Longwell",
      "screen_name" : "teacherphili",
      "protected" : false,
      "id_str" : "67863264",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637201716295933952\/4n4DCm-q_normal.jpg",
      "id" : 67863264,
      "verified" : false
    }
  },
  "id" : 339020701069619200,
  "created_at" : "2013-05-27 14:10:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonny Lewington",
      "screen_name" : "JonnyLewington",
      "indices" : [ 65, 80 ],
      "id_str" : "3361285445",
      "id" : 3361285445
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/xxOclnYQ1W",
      "expanded_url" : "http:\/\/wp.me\/p3jXAy-6p",
      "display_url" : "wp.me\/p3jXAy-6p"
    } ]
  },
  "geo" : { },
  "id_str" : "338779672978526208",
  "text" : "Why is pronunciation teaching so bad? http:\/\/t.co\/xxOclnYQ1W via @JonnyLewington",
  "id" : 338779672978526208,
  "created_at" : "2013-05-26 22:12:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 106, 122 ],
      "id_str" : "823905",
      "id" : 823905
    }, {
      "name" : "P\u00E9rez-Paredes",
      "screen_name" : "perezparedes",
      "indices" : [ 126, 139 ],
      "id_str" : "28528850",
      "id" : 28528850
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/HS74HPoOqr",
      "expanded_url" : "http:\/\/wp.me\/p2vE3W-2f",
      "display_url" : "wp.me\/p2vE3W-2f"
    } ]
  },
  "geo" : { },
  "id_str" : "338692826512646144",
  "text" : "Time Out Of Mind: A corpus linguistic analysis of 50 years of Bob Dylan lyrics http:\/\/t.co\/HS74HPoOqr via @wordpressdotcom HT @perezparedes",
  "id" : 338692826512646144,
  "created_at" : "2013-05-26 16:27:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate Bowles",
      "screen_name" : "KateMfD",
      "indices" : [ 3, 11 ],
      "id_str" : "379065166",
      "id" : 379065166
    }, {
      "name" : "Valerie Robin",
      "screen_name" : "vrobin1000",
      "indices" : [ 16, 27 ],
      "id_str" : "567749800",
      "id" : 567749800
    }, {
      "name" : "Hybrid Pedagogy",
      "screen_name" : "HybridPed",
      "indices" : [ 30, 40 ],
      "id_str" : "416608920",
      "id" : 416608920
    }, {
      "name" : "Lee Skallerup",
      "screen_name" : "readywriting",
      "indices" : [ 106, 119 ],
      "id_str" : "124920374",
      "id" : 124920374
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/YwRUL1VoyV",
      "expanded_url" : "http:\/\/www.hybridpedagogy.com\/commons.html#\/discussion\/16\/hybrid-pedagogy-commons-virtual-unconference-may-2013",
      "display_url" : "hybridpedagogy.com\/commons.html#\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "338656496210558977",
  "text" : "RT @KateMfD: RT @vrobin1000: .@HybridPed Virtual Unconference Schedule is up! http:\/\/t.co\/YwRUL1VoyV (via @readywriting)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Valerie Robin",
        "screen_name" : "vrobin1000",
        "indices" : [ 3, 14 ],
        "id_str" : "567749800",
        "id" : 567749800
      }, {
        "name" : "Hybrid Pedagogy",
        "screen_name" : "HybridPed",
        "indices" : [ 17, 27 ],
        "id_str" : "416608920",
        "id" : 416608920
      }, {
        "name" : "Lee Skallerup",
        "screen_name" : "readywriting",
        "indices" : [ 93, 106 ],
        "id_str" : "124920374",
        "id" : 124920374
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/YwRUL1VoyV",
        "expanded_url" : "http:\/\/www.hybridpedagogy.com\/commons.html#\/discussion\/16\/hybrid-pedagogy-commons-virtual-unconference-may-2013",
        "display_url" : "hybridpedagogy.com\/commons.html#\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "338456324864090112",
    "text" : "RT @vrobin1000: .@HybridPed Virtual Unconference Schedule is up! http:\/\/t.co\/YwRUL1VoyV (via @readywriting)",
    "id" : 338456324864090112,
    "created_at" : "2013-05-26 00:47:30 +0000",
    "user" : {
      "name" : "Kate Bowles",
      "screen_name" : "KateMfD",
      "protected" : false,
      "id_str" : "379065166",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1557363696\/Screen_shot_2011-09-24_at_7.36.20_PM_normal.png",
      "id" : 379065166,
      "verified" : false
    }
  },
  "id" : 338656496210558977,
  "created_at" : "2013-05-26 14:02:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "edulang",
      "screen_name" : "edulang",
      "indices" : [ 3, 11 ],
      "id_str" : "2877002950",
      "id" : 2877002950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 140 ],
      "url" : "http:\/\/t.co\/DOtCezuvyO",
      "expanded_url" : "http:\/\/goo.gl\/BqmGi",
      "display_url" : "goo.gl\/BqmGi"
    } ]
  },
  "geo" : { },
  "id_str" : "338629925965807616",
  "text" : "RT @Edulang: From Craiglist to Starbucks: \"My Strange Language Exchange\" by Murray Rosenbaum 15 year old student in N-Y : http:\/\/t.co\/DOtCe\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/DOtCezuvyO",
        "expanded_url" : "http:\/\/goo.gl\/BqmGi",
        "display_url" : "goo.gl\/BqmGi"
      } ]
    },
    "geo" : { },
    "id_str" : "338587235429531649",
    "text" : "From Craiglist to Starbucks: \"My Strange Language Exchange\" by Murray Rosenbaum 15 year old student in N-Y : http:\/\/t.co\/DOtCezuvyO",
    "id" : 338587235429531649,
    "created_at" : "2013-05-26 09:27:42 +0000",
    "user" : {
      "name" : "WordTov",
      "screen_name" : "wordtov",
      "protected" : false,
      "id_str" : "236921161",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/612985595749617664\/YMxtQC1g_normal.png",
      "id" : 236921161,
      "verified" : false
    }
  },
  "id" : 338629925965807616,
  "created_at" : "2013-05-26 12:17:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Hardie",
      "screen_name" : "HardieResearch",
      "indices" : [ 52, 67 ],
      "id_str" : "970452764",
      "id" : 970452764
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lexconf2013",
      "indices" : [ 68, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/j9DMTMiW9m",
      "expanded_url" : "http:\/\/metaphorhacker.net\/2010\/08\/why-chomsky-doesnt-count-as-a-gifted-linguist\/",
      "display_url" : "metaphorhacker.net\/2010\/08\/why-ch\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "338619580320739329",
  "text" : "Hoey gets some props here http:\/\/t.co\/j9DMTMiW9m HT @HardieResearch #lexconf2013",
  "id" : 338619580320739329,
  "created_at" : "2013-05-26 11:36:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angus B Grieve-Smith",
      "screen_name" : "grvsmth",
      "indices" : [ 3, 11 ],
      "id_str" : "22381639",
      "id" : 22381639
    }, {
      "name" : "Stan Carey",
      "screen_name" : "StanCarey",
      "indices" : [ 81, 91 ],
      "id_str" : "34347535",
      "id" : 34347535
    }, {
      "name" : "Arika Okrent",
      "screen_name" : "arikaokrent",
      "indices" : [ 92, 104 ],
      "id_str" : "47226743",
      "id" : 47226743
    }, {
      "name" : "Black Francis",
      "screen_name" : "MrBlackFrancis",
      "indices" : [ 105, 120 ],
      "id_str" : "28399797",
      "id" : 28399797
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/9RQ5aSD9Pz",
      "expanded_url" : "http:\/\/grieve-smith.com\/blog\/2013\/05\/the-politics-of-soft-g\/",
      "display_url" : "grieve-smith.com\/blog\/2013\/05\/t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "338395541572567041",
  "text" : "RT @grvsmth: New post: The politics of soft \"g\" http:\/\/t.co\/9RQ5aSD9Pz featuring @stancarey @arikaokrent @mrblackfrancis Dwight Bolinger an\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stan Carey",
        "screen_name" : "StanCarey",
        "indices" : [ 68, 78 ],
        "id_str" : "34347535",
        "id" : 34347535
      }, {
        "name" : "Arika Okrent",
        "screen_name" : "arikaokrent",
        "indices" : [ 79, 91 ],
        "id_str" : "47226743",
        "id" : 47226743
      }, {
        "name" : "Black Francis",
        "screen_name" : "MrBlackFrancis",
        "indices" : [ 92, 107 ],
        "id_str" : "28399797",
        "id" : 28399797
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 57 ],
        "url" : "http:\/\/t.co\/9RQ5aSD9Pz",
        "expanded_url" : "http:\/\/grieve-smith.com\/blog\/2013\/05\/the-politics-of-soft-g\/",
        "display_url" : "grieve-smith.com\/blog\/2013\/05\/t\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "338369176450252800",
    "text" : "New post: The politics of soft \"g\" http:\/\/t.co\/9RQ5aSD9Pz featuring @stancarey @arikaokrent @mrblackfrancis Dwight Bolinger and Los Angeles.",
    "id" : 338369176450252800,
    "created_at" : "2013-05-25 19:01:12 +0000",
    "user" : {
      "name" : "Angus B Grieve-Smith",
      "screen_name" : "grvsmth",
      "protected" : false,
      "id_str" : "22381639",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/94827231\/portrait_normal.png",
      "id" : 22381639,
      "verified" : false
    }
  },
  "id" : 338395541572567041,
  "created_at" : "2013-05-25 20:45:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 3, 17 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/ZYHCFqhqI9",
      "expanded_url" : "http:\/\/hackeducation.com\/2013\/05\/24\/disruptive-innovation\/",
      "display_url" : "hackeducation.com\/2013\/05\/24\/dis\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "338328864373747712",
  "text" : "RT @audreywatters: The Myth and Millennialism of \"Disruptive Innovation\" http:\/\/t.co\/ZYHCFqhqI9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 76 ],
        "url" : "http:\/\/t.co\/ZYHCFqhqI9",
        "expanded_url" : "http:\/\/hackeducation.com\/2013\/05\/24\/disruptive-innovation\/",
        "display_url" : "hackeducation.com\/2013\/05\/24\/dis\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "338313274791706624",
    "text" : "The Myth and Millennialism of \"Disruptive Innovation\" http:\/\/t.co\/ZYHCFqhqI9",
    "id" : 338313274791706624,
    "created_at" : "2013-05-25 15:19:04 +0000",
    "user" : {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "protected" : false,
      "id_str" : "25388528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711668009723498496\/pauFZsdv_normal.jpg",
      "id" : 25388528,
      "verified" : false
    }
  },
  "id" : 338328864373747712,
  "created_at" : "2013-05-25 16:21:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyler Schnoebelen",
      "screen_name" : "TSchnoebelen",
      "indices" : [ 3, 16 ],
      "id_str" : "14969147",
      "id" : 14969147
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FridayFun",
      "indices" : [ 121, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/y7KdHc1f3P",
      "expanded_url" : "http:\/\/ow.ly\/lnClb",
      "display_url" : "ow.ly\/lnClb"
    } ]
  },
  "geo" : { },
  "id_str" : "338323184862498817",
  "text" : "RT @TSchnoebelen: Child language acquisition, meet discourse analysis | Convos with my 2-year old http:\/\/t.co\/y7KdHc1f3P #FridayFun",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FridayFun",
        "indices" : [ 103, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/y7KdHc1f3P",
        "expanded_url" : "http:\/\/ow.ly\/lnClb",
        "display_url" : "ow.ly\/lnClb"
      } ]
    },
    "geo" : { },
    "id_str" : "338065646032125952",
    "text" : "Child language acquisition, meet discourse analysis | Convos with my 2-year old http:\/\/t.co\/y7KdHc1f3P #FridayFun",
    "id" : 338065646032125952,
    "created_at" : "2013-05-24 22:55:05 +0000",
    "user" : {
      "name" : "Tyler Schnoebelen",
      "screen_name" : "TSchnoebelen",
      "protected" : false,
      "id_str" : "14969147",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/604427674203779072\/Y4t_NODB_normal.jpg",
      "id" : 14969147,
      "verified" : false
    }
  },
  "id" : 338323184862498817,
  "created_at" : "2013-05-25 15:58:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "indices" : [ 3, 14 ],
      "id_str" : "152051625",
      "id" : 152051625
    }, {
      "name" : "Sandra Jansen",
      "screen_name" : "sj2915",
      "indices" : [ 58, 65 ],
      "id_str" : "190676396",
      "id" : 190676396
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/mltsTgVQRG",
      "expanded_url" : "http:\/\/bit.ly\/12B9scu",
      "display_url" : "bit.ly\/12B9scu"
    } ]
  },
  "geo" : { },
  "id_str" : "337933669706629120",
  "text" : "RT @heatherfro: 25 Worst ESL textbooks &amp; lessons (via @sj2915 on fb) http:\/\/t.co\/mltsTgVQRG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sandra Jansen",
        "screen_name" : "sj2915",
        "indices" : [ 42, 49 ],
        "id_str" : "190676396",
        "id" : 190676396
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/mltsTgVQRG",
        "expanded_url" : "http:\/\/bit.ly\/12B9scu",
        "display_url" : "bit.ly\/12B9scu"
      } ]
    },
    "geo" : { },
    "id_str" : "337930414175948801",
    "text" : "25 Worst ESL textbooks &amp; lessons (via @sj2915 on fb) http:\/\/t.co\/mltsTgVQRG",
    "id" : 337930414175948801,
    "created_at" : "2013-05-24 13:57:43 +0000",
    "user" : {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "protected" : false,
      "id_str" : "152051625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/688767277022494720\/KMrzOBc1_normal.jpg",
      "id" : 152051625,
      "verified" : false
    }
  },
  "id" : 337933669706629120,
  "created_at" : "2013-05-24 14:10:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 66, 82 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/AuM5N1HuIo",
      "expanded_url" : "http:\/\/wp.me\/p28vDX-jr",
      "display_url" : "wp.me\/p28vDX-jr"
    } ]
  },
  "geo" : { },
  "id_str" : "337922145613139968",
  "text" : "Are some languages easier than others? http:\/\/t.co\/AuM5N1HuIo via @wordpressdotcom",
  "id" : 337922145613139968,
  "created_at" : "2013-05-24 13:24:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Kittle",
      "screen_name" : "pkittle",
      "indices" : [ 3, 11 ],
      "id_str" : "11322822",
      "id" : 11322822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/Dwezfqc6kB",
      "expanded_url" : "http:\/\/chronicle.com\/blogs\/onhiring\/a-pedagogys-punctuated-equilibrium\/38843?viewMobile=0",
      "display_url" : "chronicle.com\/blogs\/onhiring\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "337918394437345280",
  "text" : "RT @pkittle: A junior faculty member finally develops a real philosophy of teaching after 6 years as an instructor:  http:\/\/t.co\/Dwezfqc6kB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/Dwezfqc6kB",
        "expanded_url" : "http:\/\/chronicle.com\/blogs\/onhiring\/a-pedagogys-punctuated-equilibrium\/38843?viewMobile=0",
        "display_url" : "chronicle.com\/blogs\/onhiring\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "337916303950090242",
    "text" : "A junior faculty member finally develops a real philosophy of teaching after 6 years as an instructor:  http:\/\/t.co\/Dwezfqc6kB",
    "id" : 337916303950090242,
    "created_at" : "2013-05-24 13:01:39 +0000",
    "user" : {
      "name" : "Peter Kittle",
      "screen_name" : "pkittle",
      "protected" : false,
      "id_str" : "11322822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3092425785\/f39243edb590b4e470ff385be8f436a6_normal.png",
      "id" : 11322822,
      "verified" : false
    }
  },
  "id" : 337918394437345280,
  "created_at" : "2013-05-24 13:09:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jo Sayers",
      "screen_name" : "jo_sayers",
      "indices" : [ 3, 13 ],
      "id_str" : "87176766",
      "id" : 87176766
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 52, 61 ],
      "id_str" : "18602422",
      "id" : 18602422
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "teachtheweb",
      "indices" : [ 15, 27 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/IDcKJkQbwt",
      "expanded_url" : "http:\/\/jsbin.com\/asidaj\/15",
      "display_url" : "jsbin.com\/asidaj\/15"
    } ]
  },
  "geo" : { },
  "id_str" : "337901777548611584",
  "text" : "RT @jo_sayers: #teachtheweb Week 3 make from me and @muranava to help students with common chunks http:\/\/t.co\/IDcKJkQbwt add \/edit to chang\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mura Nava",
        "screen_name" : "muranava",
        "indices" : [ 37, 46 ],
        "id_str" : "18602422",
        "id" : 18602422
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "teachtheweb",
        "indices" : [ 0, 12 ]
      } ],
      "urls" : [ {
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/IDcKJkQbwt",
        "expanded_url" : "http:\/\/jsbin.com\/asidaj\/15",
        "display_url" : "jsbin.com\/asidaj\/15"
      } ]
    },
    "geo" : { },
    "id_str" : "337889171014295552",
    "text" : "#teachtheweb Week 3 make from me and @muranava to help students with common chunks http:\/\/t.co\/IDcKJkQbwt add \/edit to change\/add\/adapt",
    "id" : 337889171014295552,
    "created_at" : "2013-05-24 11:13:50 +0000",
    "user" : {
      "name" : "Jo Sayers",
      "screen_name" : "jo_sayers",
      "protected" : false,
      "id_str" : "87176766",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/466896591480037376\/EssZHYa4_normal.jpeg",
      "id" : 87176766,
      "verified" : false
    }
  },
  "id" : 337901777548611584,
  "created_at" : "2013-05-24 12:03:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 47, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/PCgalbdkPa",
      "expanded_url" : "http:\/\/elteachertrainer.com\/2013\/05\/24\/cuisenaire-rods-in-elt\/",
      "display_url" : "elteachertrainer.com\/2013\/05\/24\/cui\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "337898496214568961",
  "text" : "Cuisenaire rods in ELT  http:\/\/t.co\/PCgalbdkPa #eltchat",
  "id" : 337898496214568961,
  "created_at" : "2013-05-24 11:50:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/ORRPXJZPiv",
      "expanded_url" : "http:\/\/www.researched2013.co.uk\/why-are-we-still-talking-about-learning-styles\/",
      "display_url" : "researched2013.co.uk\/why-are-we-sti\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "337712030775640066",
  "text" : "RT @researchED2013: NEW BLOG! Why are we still talking about learning styles? by our guest author @TessaLMatthews  http:\/\/t.co\/ORRPXJZPiv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/ORRPXJZPiv",
        "expanded_url" : "http:\/\/www.researched2013.co.uk\/why-are-we-still-talking-about-learning-styles\/",
        "display_url" : "researched2013.co.uk\/why-are-we-sti\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "337677779590074368",
    "text" : "NEW BLOG! Why are we still talking about learning styles? by our guest author @TessaLMatthews  http:\/\/t.co\/ORRPXJZPiv",
    "id" : 337677779590074368,
    "created_at" : "2013-05-23 21:13:51 +0000",
    "user" : {
      "name" : "researchED",
      "screen_name" : "researchED1",
      "protected" : false,
      "id_str" : "1289037060",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3452207574\/b7eaef9bcdf06ec1fbc881d50a3f920c_normal.png",
      "id" : 1289037060,
      "verified" : false
    }
  },
  "id" : 337712030775640066,
  "created_at" : "2013-05-23 23:29:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/k1AVDvf4Qe",
      "expanded_url" : "http:\/\/www.medialens.org\/index.php\/current-alert-sp-298539227\/cogitations-archive\/733-the-next-moment-matters-more-the-special-one-part-3.html",
      "display_url" : "medialens.org\/index.php\/curr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "337670467781537795",
  "text" : "When The Next Moment Matters More: 'The Special One' - Part 3 http:\/\/t.co\/k1AVDvf4Qe",
  "id" : 337670467781537795,
  "created_at" : "2013-05-23 20:44:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "William Ian O'Byrne",
      "screen_name" : "wiobyrne",
      "indices" : [ 0, 9 ],
      "id_str" : "88676762",
      "id" : 88676762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337556063425536002",
  "geo" : { },
  "id_str" : "337646052020723713",
  "in_reply_to_user_id" : 88676762,
  "text" : "@wiobyrne that's a great implementation, how much work was it?",
  "id" : 337646052020723713,
  "in_reply_to_status_id" : 337556063425536002,
  "created_at" : "2013-05-23 19:07:46 +0000",
  "in_reply_to_screen_name" : "wiobyrne",
  "in_reply_to_user_id_str" : "88676762",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anne Hodgson",
      "screen_name" : "annehodg",
      "indices" : [ 0, 9 ],
      "id_str" : "17589213",
      "id" : 17589213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337552807970357248",
  "geo" : { },
  "id_str" : "337645876195495936",
  "in_reply_to_user_id" : 17589213,
  "text" : "@annehodg yr welocme, wld have missed it if not for your tweets about quitting mark zukerbergs website :)",
  "id" : 337645876195495936,
  "in_reply_to_status_id" : 337552807970357248,
  "created_at" : "2013-05-23 19:07:04 +0000",
  "in_reply_to_screen_name" : "annehodg",
  "in_reply_to_user_id_str" : "17589213",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 80, 96 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/pspH8v8RYw",
      "expanded_url" : "http:\/\/wp.me\/p1WUM0-5L",
      "display_url" : "wp.me\/p1WUM0-5L"
    } ]
  },
  "geo" : { },
  "id_str" : "337597636867653632",
  "text" : "GIF pronunciations and the CMU Pronuncing Dictionary http:\/\/t.co\/pspH8v8RYw via @wordpressdotcom",
  "id" : 337597636867653632,
  "created_at" : "2013-05-23 15:55:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "William Ian O'Byrne",
      "screen_name" : "wiobyrne",
      "indices" : [ 3, 12 ],
      "id_str" : "88676762",
      "id" : 88676762
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CCSS",
      "indices" : [ 77, 82 ]
    }, {
      "text" : "weblitstd",
      "indices" : [ 83, 93 ]
    }, {
      "text" : "teachtheweb",
      "indices" : [ 96, 108 ]
    }, {
      "text" : "edtech",
      "indices" : [ 111, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 140 ],
      "url" : "http:\/\/t.co\/FHC9wNxJWB",
      "expanded_url" : "http:\/\/bit.ly\/14BJTKM",
      "display_url" : "bit.ly\/14BJTKM"
    } ]
  },
  "geo" : { },
  "id_str" : "337550255463743489",
  "text" : "RT @wiobyrne: An open, educational resource on embedding technology into the #CCSS #weblitstd   #teachtheweb   #edtech http:\/\/t.co\/FHC9wNxJ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CCSS",
        "indices" : [ 63, 68 ]
      }, {
        "text" : "weblitstd",
        "indices" : [ 69, 79 ]
      }, {
        "text" : "teachtheweb",
        "indices" : [ 82, 94 ]
      }, {
        "text" : "edtech",
        "indices" : [ 97, 104 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/FHC9wNxJWB",
        "expanded_url" : "http:\/\/bit.ly\/14BJTKM",
        "display_url" : "bit.ly\/14BJTKM"
      } ]
    },
    "geo" : { },
    "id_str" : "337543683006156800",
    "text" : "An open, educational resource on embedding technology into the #CCSS #weblitstd   #teachtheweb   #edtech http:\/\/t.co\/FHC9wNxJWB",
    "id" : 337543683006156800,
    "created_at" : "2013-05-23 12:20:59 +0000",
    "user" : {
      "name" : "William Ian O'Byrne",
      "screen_name" : "wiobyrne",
      "protected" : false,
      "id_str" : "88676762",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/519580082\/twitter_normal.jpg",
      "id" : 88676762,
      "verified" : false
    }
  },
  "id" : 337550255463743489,
  "created_at" : "2013-05-23 12:47:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 84, 92 ]
    }, {
      "text" : "corpuslinguistics",
      "indices" : [ 93, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/1Bx82m1HPT",
      "expanded_url" : "http:\/\/collocation.stringnet.org\/",
      "display_url" : "collocation.stringnet.org"
    } ]
  },
  "geo" : { },
  "id_str" : "337535617292439552",
  "text" : "http:\/\/t.co\/1Bx82m1HPT pretty neat uses BNC; use MI squared or cubed for score type #eltchat #corpuslinguistics",
  "id" : 337535617292439552,
  "created_at" : "2013-05-23 11:48:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anne Hodgson",
      "screen_name" : "annehodg",
      "indices" : [ 35, 44 ],
      "id_str" : "17589213",
      "id" : 17589213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/u2o3BNklZ9",
      "expanded_url" : "http:\/\/annehodgson.de\/2013\/05\/05\/eap-2013\/",
      "display_url" : "annehodgson.de\/2013\/05\/05\/eap\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "337488012860612608",
  "text" : "EAP 2013 http:\/\/t.co\/u2o3BNklZ9 by @annehodg",
  "id" : 337488012860612608,
  "created_at" : "2013-05-23 08:39:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hakan \u015Eent\u00FCrk",
      "screen_name" : "hakan_sentrk",
      "indices" : [ 0, 13 ],
      "id_str" : "118198984",
      "id" : 118198984
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337254543886802944",
  "geo" : { },
  "id_str" : "337259586073546752",
  "in_reply_to_user_id" : 118198984,
  "text" : "@hakan_sentrk yes",
  "id" : 337259586073546752,
  "in_reply_to_status_id" : 337254543886802944,
  "created_at" : "2013-05-22 17:32:05 +0000",
  "in_reply_to_screen_name" : "hakan_sentrk",
  "in_reply_to_user_id_str" : "118198984",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Potts",
      "screen_name" : "WatchedPotts",
      "indices" : [ 3, 16 ],
      "id_str" : "702925903",
      "id" : 702925903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/wNxBrhtXJ9",
      "expanded_url" : "http:\/\/cass.lancs.ac.uk\/?p=512",
      "display_url" : "cass.lancs.ac.uk\/?p=512"
    } ]
  },
  "geo" : { },
  "id_str" : "337235775865356289",
  "text" : "RT @WatchedPotts: Beyond \u2018auto-complete search forms\u2019: Notes on the reaction to \u2018Why do white people have thin lips?\u2019 http:\/\/t.co\/wNxBrhtXJ9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/wNxBrhtXJ9",
        "expanded_url" : "http:\/\/cass.lancs.ac.uk\/?p=512",
        "display_url" : "cass.lancs.ac.uk\/?p=512"
      } ]
    },
    "geo" : { },
    "id_str" : "337218203182854144",
    "text" : "Beyond \u2018auto-complete search forms\u2019: Notes on the reaction to \u2018Why do white people have thin lips?\u2019 http:\/\/t.co\/wNxBrhtXJ9",
    "id" : 337218203182854144,
    "created_at" : "2013-05-22 14:47:39 +0000",
    "user" : {
      "name" : "Amanda Potts",
      "screen_name" : "WatchedPotts",
      "protected" : false,
      "id_str" : "702925903",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/697731311428100096\/7yDHWq88_normal.jpg",
      "id" : 702925903,
      "verified" : false
    }
  },
  "id" : 337235775865356289,
  "created_at" : "2013-05-22 15:57:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pitchfork",
      "screen_name" : "pitchforkmedia",
      "indices" : [ 3, 18 ],
      "id_str" : "2707054218",
      "id" : 2707054218
    }, {
      "name" : "RedBullMusicAcademy",
      "screen_name" : "RBMA",
      "indices" : [ 85, 90 ],
      "id_str" : "18924406",
      "id" : 18924406
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/U08ThZ7mhu",
      "expanded_url" : "http:\/\/p4k.in\/10KyIdW",
      "display_url" : "p4k.in\/10KyIdW"
    } ]
  },
  "geo" : { },
  "id_str" : "337228415012843520",
  "text" : "RT @pitchforkmedia: Listen to Giorgio Moroder's first-ever DJ set, from last night's @RBMA event in NYC http:\/\/t.co\/U08ThZ7mhu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "RedBullMusicAcademy",
        "screen_name" : "RBMA",
        "indices" : [ 65, 70 ],
        "id_str" : "18924406",
        "id" : 18924406
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/U08ThZ7mhu",
        "expanded_url" : "http:\/\/p4k.in\/10KyIdW",
        "display_url" : "p4k.in\/10KyIdW"
      } ]
    },
    "geo" : { },
    "id_str" : "336996695407747072",
    "text" : "Listen to Giorgio Moroder's first-ever DJ set, from last night's @RBMA event in NYC http:\/\/t.co\/U08ThZ7mhu",
    "id" : 336996695407747072,
    "created_at" : "2013-05-22 00:07:27 +0000",
    "user" : {
      "name" : "Pitchfork",
      "screen_name" : "pitchfork",
      "protected" : false,
      "id_str" : "14089195",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615703473678585856\/6DxJO5o0_normal.jpg",
      "id" : 14089195,
      "verified" : true
    }
  },
  "id" : 337228415012843520,
  "created_at" : "2013-05-22 15:28:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lexconf2013",
      "indices" : [ 59, 71 ]
    }, {
      "text" : "elt",
      "indices" : [ 72, 76 ]
    }, {
      "text" : "speechinaction",
      "indices" : [ 77, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/maz17tS4o0",
      "expanded_url" : "http:\/\/bit.ly\/11bvS7H",
      "display_url" : "bit.ly\/11bvS7H"
    } ]
  },
  "geo" : { },
  "id_str" : "337205458639142912",
  "text" : "RT @CELTtraining: Lexis and Listening post with powerpoint #lexconf2013 #elt #speechinaction  http:\/\/t.co\/maz17tS4o0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "lexconf2013",
        "indices" : [ 41, 53 ]
      }, {
        "text" : "elt",
        "indices" : [ 54, 58 ]
      }, {
        "text" : "speechinaction",
        "indices" : [ 59, 74 ]
      } ],
      "urls" : [ {
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/maz17tS4o0",
        "expanded_url" : "http:\/\/bit.ly\/11bvS7H",
        "display_url" : "bit.ly\/11bvS7H"
      } ]
    },
    "geo" : { },
    "id_str" : "337200465274077184",
    "text" : "Lexis and Listening post with powerpoint #lexconf2013 #elt #speechinaction  http:\/\/t.co\/maz17tS4o0",
    "id" : 337200465274077184,
    "created_at" : "2013-05-22 13:37:10 +0000",
    "user" : {
      "name" : "Lexical Lab",
      "screen_name" : "LexicalLab",
      "protected" : false,
      "id_str" : "857732892",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/559654844831506432\/F4HWliCf_normal.jpeg",
      "id" : 857732892,
      "verified" : false
    }
  },
  "id" : 337205458639142912,
  "created_at" : "2013-05-22 13:57:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337200465274077184",
  "geo" : { },
  "id_str" : "337203116808220672",
  "in_reply_to_user_id" : 857732892,
  "text" : "@CELTtraining hi link to slides is broken",
  "id" : 337203116808220672,
  "in_reply_to_status_id" : 337200465274077184,
  "created_at" : "2013-05-22 13:47:42 +0000",
  "in_reply_to_screen_name" : "LexicalLab",
  "in_reply_to_user_id_str" : "857732892",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Huw Jarvis",
      "screen_name" : "TESOLacademic",
      "indices" : [ 0, 14 ],
      "id_str" : "43409552",
      "id" : 43409552
    }, {
      "name" : "Stephen Krashen",
      "screen_name" : "skrashen",
      "indices" : [ 102, 111 ],
      "id_str" : "25624708",
      "id" : 25624708
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337121710195236864",
  "geo" : { },
  "id_str" : "337171815606665216",
  "in_reply_to_user_id" : 43409552,
  "text" : "@TESOLacademic  unfortunately imo it is plain that there is a new push to privatise public education, @skrashen is pretty spot on here",
  "id" : 337171815606665216,
  "in_reply_to_status_id" : 337121710195236864,
  "created_at" : "2013-05-22 11:43:19 +0000",
  "in_reply_to_screen_name" : "TESOLacademic",
  "in_reply_to_user_id_str" : "43409552",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil Longwell",
      "screen_name" : "teacherphili",
      "indices" : [ 0, 13 ],
      "id_str" : "67863264",
      "id" : 67863264
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337141149947027456",
  "geo" : { },
  "id_str" : "337145770639765505",
  "in_reply_to_user_id" : 67863264,
  "text" : "@teacherphili congrats :)",
  "id" : 337145770639765505,
  "in_reply_to_status_id" : 337141149947027456,
  "created_at" : "2013-05-22 09:59:50 +0000",
  "in_reply_to_screen_name" : "teacherphili",
  "in_reply_to_user_id_str" : "67863264",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Kirby",
      "screen_name" : "joe__kirby",
      "indices" : [ 113, 124 ],
      "id_str" : "1055231498",
      "id" : 1055231498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/NlF3dZlkFI",
      "expanded_url" : "http:\/\/www.researched2013.co.uk\/310\/",
      "display_url" : "researched2013.co.uk\/310\/"
    } ]
  },
  "geo" : { },
  "id_str" : "337115680610594816",
  "text" : "RT @researchED2013: What can science tell us about how students learn best? http:\/\/t.co\/NlF3dZlkFI the excellent @joe__kirby on the @resear\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Joe Kirby",
        "screen_name" : "joe__kirby",
        "indices" : [ 93, 104 ],
        "id_str" : "1055231498",
        "id" : 1055231498
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/NlF3dZlkFI",
        "expanded_url" : "http:\/\/www.researched2013.co.uk\/310\/",
        "display_url" : "researched2013.co.uk\/310\/"
      } ]
    },
    "in_reply_to_status_id_str" : "336903660204335104",
    "geo" : { },
    "id_str" : "336934657230786560",
    "in_reply_to_user_id" : 1055231498,
    "text" : "What can science tell us about how students learn best? http:\/\/t.co\/NlF3dZlkFI the excellent @joe__kirby on the @researchED2013 website",
    "id" : 336934657230786560,
    "in_reply_to_status_id" : 336903660204335104,
    "created_at" : "2013-05-21 20:00:56 +0000",
    "in_reply_to_screen_name" : "joe__kirby",
    "in_reply_to_user_id_str" : "1055231498",
    "user" : {
      "name" : "researchED",
      "screen_name" : "researchED1",
      "protected" : false,
      "id_str" : "1289037060",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3452207574\/b7eaef9bcdf06ec1fbc881d50a3f920c_normal.png",
      "id" : 1289037060,
      "verified" : false
    }
  },
  "id" : 337115680610594816,
  "created_at" : "2013-05-22 08:00:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ed Pegg",
      "screen_name" : "EdPegg",
      "indices" : [ 0, 7 ],
      "id_str" : "294186494",
      "id" : 294186494
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337093415386898432",
  "geo" : { },
  "id_str" : "337111891455377408",
  "in_reply_to_user_id" : 294186494,
  "text" : "@EdPegg c. Thrilling and Dull? ;)",
  "id" : 337111891455377408,
  "in_reply_to_status_id" : 337093415386898432,
  "created_at" : "2013-05-22 07:45:12 +0000",
  "in_reply_to_screen_name" : "EdPegg",
  "in_reply_to_user_id_str" : "294186494",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 3, 14 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lexconf2013",
      "indices" : [ 85, 97 ]
    }, {
      "text" : "elt",
      "indices" : [ 129, 133 ]
    }, {
      "text" : "tefl",
      "indices" : [ 134, 139 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 140, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/Sj1jMkcn03",
      "expanded_url" : "http:\/\/bit.ly\/14MrKcC",
      "display_url" : "bit.ly\/14MrKcC"
    } ]
  },
  "geo" : { },
  "id_str" : "336977545792724992",
  "text" : "RT @leoselivan: Summaries of talks &amp; workshops from Lexical Conference on 11 May #lexconf2013 + links http:\/\/t.co\/Sj1jMkcn03 #elt #tefl #el\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "lexconf2013",
        "indices" : [ 69, 81 ]
      }, {
        "text" : "elt",
        "indices" : [ 113, 117 ]
      }, {
        "text" : "tefl",
        "indices" : [ 118, 123 ]
      }, {
        "text" : "eltchat",
        "indices" : [ 124, 132 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/Sj1jMkcn03",
        "expanded_url" : "http:\/\/bit.ly\/14MrKcC",
        "display_url" : "bit.ly\/14MrKcC"
      } ]
    },
    "geo" : { },
    "id_str" : "336888683133292544",
    "text" : "Summaries of talks &amp; workshops from Lexical Conference on 11 May #lexconf2013 + links http:\/\/t.co\/Sj1jMkcn03 #elt #tefl #eltchat",
    "id" : 336888683133292544,
    "created_at" : "2013-05-21 16:58:15 +0000",
    "user" : {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "protected" : false,
      "id_str" : "408365496",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/460546508601819136\/12ivDBb__normal.jpeg",
      "id" : 408365496,
      "verified" : false
    }
  },
  "id" : 336977545792724992,
  "created_at" : "2013-05-21 22:51:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ETpro",
      "screen_name" : "ETprofessional",
      "indices" : [ 0, 15 ],
      "id_str" : "501629829",
      "id" : 501629829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/h9Lu0oF9G8",
      "expanded_url" : "http:\/\/qz.com\/67991\/you-didnt-make-the-harlem-shake-go-viral-corporations-did\/",
      "display_url" : "qz.com\/67991\/you-didn\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "336869109943910401",
  "geo" : { },
  "id_str" : "336939650990108675",
  "in_reply_to_user_id" : 501629829,
  "text" : "@ETprofessional\" natural\" selection of viral videos not necessarily \"natural\" e.g. http:\/\/t.co\/h9Lu0oF9G8",
  "id" : 336939650990108675,
  "in_reply_to_status_id" : 336869109943910401,
  "created_at" : "2013-05-21 20:20:47 +0000",
  "in_reply_to_screen_name" : "ETprofessional",
  "in_reply_to_user_id_str" : "501629829",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jo Sayers",
      "screen_name" : "jo_sayers",
      "indices" : [ 0, 10 ],
      "id_str" : "87176766",
      "id" : 87176766
    }, {
      "name" : "Tom Randolph",
      "screen_name" : "TomTesol",
      "indices" : [ 15, 24 ],
      "id_str" : "1039673456",
      "id" : 1039673456
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336869577076117504",
  "in_reply_to_user_id" : 87176766,
  "text" : "@jo_sayers and @TomTesol appreciate share of latest post :) have a good week",
  "id" : 336869577076117504,
  "created_at" : "2013-05-21 15:42:20 +0000",
  "in_reply_to_screen_name" : "jo_sayers",
  "in_reply_to_user_id_str" : "87176766",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/G4F4hnEYwH",
      "expanded_url" : "http:\/\/wp.me\/p2svM7-Zn",
      "display_url" : "wp.me\/p2svM7-Zn"
    } ]
  },
  "geo" : { },
  "id_str" : "336802190012334080",
  "text" : "Aphasia: Language lost and found: http:\/\/t.co\/G4F4hnEYwH via @leakygrammar",
  "id" : 336802190012334080,
  "created_at" : "2013-05-21 11:14:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paper Machines",
      "screen_name" : "PaperMachines",
      "indices" : [ 11, 25 ],
      "id_str" : "1160911620",
      "id" : 1160911620
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 80, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/TAHpFr5uG8",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-Df",
      "display_url" : "wp.me\/pgHyE-Df"
    } ]
  },
  "geo" : { },
  "id_str" : "336780536725004288",
  "text" : "New post - @PaperMachines, Look ma no concordance lines http:\/\/t.co\/TAHpFr5uG8  #eltchat",
  "id" : 336780536725004288,
  "created_at" : "2013-05-21 09:48:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 63, 79 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/1gHvmNr2l1",
      "expanded_url" : "http:\/\/wp.me\/p3xK9D-1c",
      "display_url" : "wp.me\/p3xK9D-1c"
    } ]
  },
  "geo" : { },
  "id_str" : "336748466686533634",
  "text" : "So, do you really want to do DELTA? http:\/\/t.co\/1gHvmNr2l1 via @wordpressdotcom",
  "id" : 336748466686533634,
  "created_at" : "2013-05-21 07:41:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpuslinguistics",
      "indices" : [ 79, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/TAHpFr5uG8",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-Df",
      "display_url" : "wp.me\/pgHyE-Df"
    } ]
  },
  "geo" : { },
  "id_str" : "336632172221964290",
  "text" : "New post - Paper Machines, Look ma no concordance lines http:\/\/t.co\/TAHpFr5uG8 #corpuslinguistics",
  "id" : 336632172221964290,
  "created_at" : "2013-05-20 23:58:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336526252187996160",
  "geo" : { },
  "id_str" : "336554481800081409",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan u need to look at your comments setting for sure leo ;)",
  "id" : 336554481800081409,
  "in_reply_to_status_id" : 336526252187996160,
  "created_at" : "2013-05-20 18:50:15 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 3, 14 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 117, 121 ]
    }, {
      "text" : "tefl",
      "indices" : [ 122, 127 ]
    }, {
      "text" : "lexis",
      "indices" : [ 128, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/EV9rHZ5wql",
      "expanded_url" : "http:\/\/bit.ly\/14lDS4y",
      "display_url" : "bit.ly\/14lDS4y"
    } ]
  },
  "geo" : { },
  "id_str" : "336553192882044929",
  "text" : "RT @leoselivan: A very intelligent comment by Andrew Walkley on 'In context or with co-text?' http:\/\/t.co\/EV9rHZ5wql #elt #tefl #lexis",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "elt",
        "indices" : [ 101, 105 ]
      }, {
        "text" : "tefl",
        "indices" : [ 106, 111 ]
      }, {
        "text" : "lexis",
        "indices" : [ 112, 118 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/EV9rHZ5wql",
        "expanded_url" : "http:\/\/bit.ly\/14lDS4y",
        "display_url" : "bit.ly\/14lDS4y"
      } ]
    },
    "geo" : { },
    "id_str" : "336526252187996160",
    "text" : "A very intelligent comment by Andrew Walkley on 'In context or with co-text?' http:\/\/t.co\/EV9rHZ5wql #elt #tefl #lexis",
    "id" : 336526252187996160,
    "created_at" : "2013-05-20 16:58:05 +0000",
    "user" : {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "protected" : false,
      "id_str" : "408365496",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/460546508601819136\/12ivDBb__normal.jpeg",
      "id" : 408365496,
      "verified" : false
    }
  },
  "id" : 336553192882044929,
  "created_at" : "2013-05-20 18:45:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 57, 73 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/DP9w4kmz8t",
      "expanded_url" : "http:\/\/wp.me\/p2KE8s-3ox",
      "display_url" : "wp.me\/p2KE8s-3ox"
    } ]
  },
  "geo" : { },
  "id_str" : "336447652784914432",
  "text" : "Teaching headlines vocabulary http:\/\/t.co\/DP9w4kmz8t via @wordpressdotcom",
  "id" : 336447652784914432,
  "created_at" : "2013-05-20 11:45:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "markwarschauer",
      "screen_name" : "markwarschauer",
      "indices" : [ 21, 36 ],
      "id_str" : "17316060",
      "id" : 17316060
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/D62f8thUdL",
      "expanded_url" : "https:\/\/www.econstor.eu\/dspace\/bitstream\/10419\/69985\/1\/73669059X.pdf",
      "display_url" : "econstor.eu\/dspace\/bitstre\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "336403393583132672",
  "text" : "v interesting!&gt;MT @markwarschauer No effects of hme cmptrs on school wrk https:\/\/t.co\/D62f8thUdL",
  "id" : 336403393583132672,
  "created_at" : "2013-05-20 08:49:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Timothy Tate",
      "screen_name" : "Timothy_Tate",
      "indices" : [ 0, 13 ],
      "id_str" : "1084531170",
      "id" : 1084531170
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "forgotmycoatillleavenow",
      "indices" : [ 69, 93 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336202585281277955",
  "geo" : { },
  "id_str" : "336208774111043584",
  "in_reply_to_user_id" : 1084531170,
  "text" : "@Timothy_Tate am appreciating  your deep pong insights, keep pinging #forgotmycoatillleavenow",
  "id" : 336208774111043584,
  "in_reply_to_status_id" : 336202585281277955,
  "created_at" : "2013-05-19 19:56:32 +0000",
  "in_reply_to_screen_name" : "Timothy_Tate",
  "in_reply_to_user_id_str" : "1084531170",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ela Wassell",
      "screen_name" : "elawassell",
      "indices" : [ 3, 14 ],
      "id_str" : "51157050",
      "id" : 51157050
    }, {
      "name" : "Sandy Millin",
      "screen_name" : "sandymillin",
      "indices" : [ 20, 32 ],
      "id_str" : "144236944",
      "id" : 144236944
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "efl",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "elt",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/vbM0JHDsk0",
      "expanded_url" : "http:\/\/bit.ly\/112iT8h",
      "display_url" : "bit.ly\/112iT8h"
    } ]
  },
  "geo" : { },
  "id_str" : "336192847185326080",
  "text" : "RT @elawassell: via @sandymillin The Hitchhiker\u2019s Guide to the Galaxy: The Hitchhiker\u2019s Guide to the Galaxy has been... http:\/\/t.co\/vbM0JHD\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sandy Millin",
        "screen_name" : "sandymillin",
        "indices" : [ 4, 16 ],
        "id_str" : "144236944",
        "id" : 144236944
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "efl",
        "indices" : [ 127, 131 ]
      }, {
        "text" : "elt",
        "indices" : [ 132, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/vbM0JHDsk0",
        "expanded_url" : "http:\/\/bit.ly\/112iT8h",
        "display_url" : "bit.ly\/112iT8h"
      } ]
    },
    "geo" : { },
    "id_str" : "336192006319636481",
    "text" : "via @sandymillin The Hitchhiker\u2019s Guide to the Galaxy: The Hitchhiker\u2019s Guide to the Galaxy has been... http:\/\/t.co\/vbM0JHDsk0 #efl #elt",
    "id" : 336192006319636481,
    "created_at" : "2013-05-19 18:49:55 +0000",
    "user" : {
      "name" : "Ela Wassell",
      "screen_name" : "elawassell",
      "protected" : false,
      "id_str" : "51157050",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1879392732\/11elwas_normal.jpg",
      "id" : 51157050,
      "verified" : false
    }
  },
  "id" : 336192847185326080,
  "created_at" : "2013-05-19 18:53:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jo Sayers",
      "screen_name" : "jo_sayers",
      "indices" : [ 3, 13 ],
      "id_str" : "87176766",
      "id" : 87176766
    }, {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 78, 94 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 118, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/gTZsPk3S3A",
      "expanded_url" : "http:\/\/eltplustech.blogspot.com\/2013\/05\/lesson-plan-statement-survey.html",
      "display_url" : "eltplustech.blogspot.com\/2013\/05\/lesson\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "336156240050786306",
  "text" : "RT @jo_sayers: What do you think of lesson plans? A survey based on post from @michaelegriffin http:\/\/t.co\/gTZsPk3S3A #elt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Michael Griffin",
        "screen_name" : "michaelegriffin",
        "indices" : [ 63, 79 ],
        "id_str" : "394053348",
        "id" : 394053348
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "elt",
        "indices" : [ 103, 107 ]
      } ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/gTZsPk3S3A",
        "expanded_url" : "http:\/\/eltplustech.blogspot.com\/2013\/05\/lesson-plan-statement-survey.html",
        "display_url" : "eltplustech.blogspot.com\/2013\/05\/lesson\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "336132561313091584",
    "text" : "What do you think of lesson plans? A survey based on post from @michaelegriffin http:\/\/t.co\/gTZsPk3S3A #elt",
    "id" : 336132561313091584,
    "created_at" : "2013-05-19 14:53:42 +0000",
    "user" : {
      "name" : "Jo Sayers",
      "screen_name" : "jo_sayers",
      "protected" : false,
      "id_str" : "87176766",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/466896591480037376\/EssZHYa4_normal.jpeg",
      "id" : 87176766,
      "verified" : false
    }
  },
  "id" : 336156240050786306,
  "created_at" : "2013-05-19 16:27:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheConsultantsE",
      "screen_name" : "TheConsultantsE",
      "indices" : [ 3, 19 ],
      "id_str" : "13435662",
      "id" : 13435662
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elearning",
      "indices" : [ 107, 117 ]
    }, {
      "text" : "edtech",
      "indices" : [ 118, 125 ]
    }, {
      "text" : "edchat",
      "indices" : [ 126, 133 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 134, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/CAMXhLe4bm",
      "expanded_url" : "http:\/\/ow.ly\/l9Fz2",
      "display_url" : "ow.ly\/l9Fz2"
    } ]
  },
  "geo" : { },
  "id_str" : "336155040194625537",
  "text" : "RT @TheConsultantsE: Great Ideas for Teaching Digital Literacies: Challenge Winners http:\/\/t.co\/CAMXhLe4bm #elearning #edtech #edchat #eltc\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "elearning",
        "indices" : [ 86, 96 ]
      }, {
        "text" : "edtech",
        "indices" : [ 97, 104 ]
      }, {
        "text" : "edchat",
        "indices" : [ 105, 112 ]
      }, {
        "text" : "eltchat",
        "indices" : [ 113, 121 ]
      } ],
      "urls" : [ {
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/CAMXhLe4bm",
        "expanded_url" : "http:\/\/ow.ly\/l9Fz2",
        "display_url" : "ow.ly\/l9Fz2"
      } ]
    },
    "geo" : { },
    "id_str" : "335692542093971457",
    "text" : "Great Ideas for Teaching Digital Literacies: Challenge Winners http:\/\/t.co\/CAMXhLe4bm #elearning #edtech #edchat #eltchat",
    "id" : 335692542093971457,
    "created_at" : "2013-05-18 09:45:13 +0000",
    "user" : {
      "name" : "TheConsultantsE",
      "screen_name" : "TheConsultantsE",
      "protected" : false,
      "id_str" : "13435662",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/741978194044162048\/-uFGjiTN_normal.jpg",
      "id" : 13435662,
      "verified" : false
    }
  },
  "id" : 336155040194625537,
  "created_at" : "2013-05-19 16:23:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "le_mac",
      "screen_name" : "le_mac",
      "indices" : [ 0, 7 ],
      "id_str" : "17064137",
      "id" : 17064137
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "illgetmycoat",
      "indices" : [ 52, 65 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336117471746605056",
  "geo" : { },
  "id_str" : "336118505919365120",
  "in_reply_to_user_id" : 17064137,
  "text" : "@le_mac u must be pinging an ponging in yr decision #illgetmycoat",
  "id" : 336118505919365120,
  "in_reply_to_status_id" : 336117471746605056,
  "created_at" : "2013-05-19 13:57:51 +0000",
  "in_reply_to_screen_name" : "le_mac",
  "in_reply_to_user_id_str" : "17064137",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/S8JFXxWtS0",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=DIC3Lr90cJA",
      "display_url" : "youtube.com\/watch?v=DIC3Lr\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "336097707523465216",
  "geo" : { },
  "id_str" : "336109696635260928",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow grt post kev, u may like \"they don't care about vocabulary they care about characters\" http:\/\/t.co\/S8JFXxWtS0",
  "id" : 336109696635260928,
  "in_reply_to_status_id" : 336097707523465216,
  "created_at" : "2013-05-19 13:22:50 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naomi Epstein",
      "screen_name" : "naomishema",
      "indices" : [ 3, 14 ],
      "id_str" : "228469472",
      "id" : 228469472
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "efl",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/3QQJnNi4XJ",
      "expanded_url" : "http:\/\/theotherthingsmatter.blogspot.com\/2013\/05\/make-all-mistakes-you-want-but-just.html?spref=tw",
      "display_url" : "theotherthingsmatter.blogspot.com\/2013\/05\/make-a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "336108558695407616",
  "text" : "RT @naomishema: The Other Things Matter: Make all the mistakes you want, but just tell me a... http:\/\/t.co\/3QQJnNi4XJ THIS ISSOMETHING TO T\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "eltchat",
        "indices" : [ 127, 135 ]
      }, {
        "text" : "efl",
        "indices" : [ 136, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/3QQJnNi4XJ",
        "expanded_url" : "http:\/\/theotherthingsmatter.blogspot.com\/2013\/05\/make-all-mistakes-you-want-but-just.html?spref=tw",
        "display_url" : "theotherthingsmatter.blogspot.com\/2013\/05\/make-a\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "336100318674837505",
    "text" : "The Other Things Matter: Make all the mistakes you want, but just tell me a... http:\/\/t.co\/3QQJnNi4XJ THIS ISSOMETHING TO TRY! #eltchat #efl",
    "id" : 336100318674837505,
    "created_at" : "2013-05-19 12:45:35 +0000",
    "user" : {
      "name" : "Naomi Epstein",
      "screen_name" : "naomishema",
      "protected" : false,
      "id_str" : "228469472",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1236538360\/PICT00108_normal.JPG",
      "id" : 228469472,
      "verified" : false
    }
  },
  "id" : 336108558695407616,
  "created_at" : "2013-05-19 13:18:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 72, 87 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/imWqwG23RQ",
      "expanded_url" : "http:\/\/wp.me\/p3qkCB-j3",
      "display_url" : "wp.me\/p3qkCB-j3"
    } ]
  },
  "geo" : { },
  "id_str" : "336081432713781248",
  "text" : "ELTJ Special Issue: The Janus papers, 2012   http:\/\/t.co\/imWqwG23RQ via @GeoffreyJordan",
  "id" : 336081432713781248,
  "created_at" : "2013-05-19 11:30:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/DwjmLLChh8",
      "expanded_url" : "http:\/\/random-idea-english.blogspot.com\/2013\/05\/phrasal-verb-or-multi-word-verb-is.html?spref=tw",
      "display_url" : "random-idea-english.blogspot.com\/2013\/05\/phrasa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "335770145962213376",
  "text" : "Random Idea English: Phrasal verb or multi-word verb? Is there any diff... http:\/\/t.co\/DwjmLLChh8",
  "id" : 335770145962213376,
  "created_at" : "2013-05-18 14:53:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim George",
      "screen_name" : "oyajimbo",
      "indices" : [ 0, 9 ],
      "id_str" : "96103979",
      "id" : 96103979
    }, {
      "name" : "Adi Rajan",
      "screen_name" : "adi_rajan",
      "indices" : [ 25, 35 ],
      "id_str" : "1011323449",
      "id" : 1011323449
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GeoGuessr",
      "indices" : [ 44, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/YnhlM7yQfK",
      "expanded_url" : "http:\/\/adirajan.wordpress.com\/2013\/05\/14\/geogloss-a-geographical-dictogloss\/",
      "display_url" : "adirajan.wordpress.com\/2013\/05\/14\/geo\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "335739096955752449",
  "geo" : { },
  "id_str" : "335740279514611713",
  "in_reply_to_user_id" : 96103979,
  "text" : "@oyajimbo reccommend add @adi_rajan post on #GeoGuessr http:\/\/t.co\/YnhlM7yQfK",
  "id" : 335740279514611713,
  "in_reply_to_status_id" : 335739096955752449,
  "created_at" : "2013-05-18 12:54:55 +0000",
  "in_reply_to_screen_name" : "oyajimbo",
  "in_reply_to_user_id_str" : "96103979",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Potts",
      "screen_name" : "WatchedPotts",
      "indices" : [ 3, 16 ],
      "id_str" : "702925903",
      "id" : 702925903
    }, {
      "name" : "Paul Baker",
      "screen_name" : "_paulbaker_",
      "indices" : [ 30, 42 ],
      "id_str" : "1026683874",
      "id" : 1026683874
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/4rmJYt6gdg",
      "expanded_url" : "http:\/\/www.dailymail.co.uk\/sciencetech\/article-2326101\/Is-Google-making-RACIST-researchers-claim-auto-complete-function-perpetuates-prejudices.html",
      "display_url" : "dailymail.co.uk\/sciencetech\/ar\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "335734892006617088",
  "text" : "RT @WatchedPotts: Research by @_paulbaker_ and me (really) in the Daily Mail: http:\/\/t.co\/4rmJYt6gdg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Paul Baker",
        "screen_name" : "_paulbaker_",
        "indices" : [ 12, 24 ],
        "id_str" : "1026683874",
        "id" : 1026683874
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/4rmJYt6gdg",
        "expanded_url" : "http:\/\/www.dailymail.co.uk\/sciencetech\/article-2326101\/Is-Google-making-RACIST-researchers-claim-auto-complete-function-perpetuates-prejudices.html",
        "display_url" : "dailymail.co.uk\/sciencetech\/ar\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "335709721338187777",
    "text" : "Research by @_paulbaker_ and me (really) in the Daily Mail: http:\/\/t.co\/4rmJYt6gdg",
    "id" : 335709721338187777,
    "created_at" : "2013-05-18 10:53:29 +0000",
    "user" : {
      "name" : "Amanda Potts",
      "screen_name" : "WatchedPotts",
      "protected" : false,
      "id_str" : "702925903",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/697731311428100096\/7yDHWq88_normal.jpg",
      "id" : 702925903,
      "verified" : false
    }
  },
  "id" : 335734892006617088,
  "created_at" : "2013-05-18 12:33:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 48, 64 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/TIWD4JLaOH",
      "expanded_url" : "http:\/\/wp.me\/p1WUM0-5n",
      "display_url" : "wp.me\/p1WUM0-5n"
    } ]
  },
  "geo" : { },
  "id_str" : "335698616196931584",
  "text" : "Top pop songs corpus http:\/\/t.co\/TIWD4JLaOH via @wordpressdotcom",
  "id" : 335698616196931584,
  "created_at" : "2013-05-18 10:09:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sophia Khan",
      "screen_name" : "SophiaKhan4",
      "indices" : [ 0, 12 ],
      "id_str" : "351390617",
      "id" : 351390617
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NetworkedTeacher",
      "indices" : [ 13, 30 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335514671081725953",
  "geo" : { },
  "id_str" : "335517556163084288",
  "in_reply_to_user_id" : 351390617,
  "text" : "@SophiaKhan4 #NetworkedTeacher dialogues that somehow don't\/can't arise offline :)",
  "id" : 335517556163084288,
  "in_reply_to_status_id" : 335514671081725953,
  "created_at" : "2013-05-17 22:09:53 +0000",
  "in_reply_to_screen_name" : "SophiaKhan4",
  "in_reply_to_user_id_str" : "351390617",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/9JOCrt8oPN",
      "expanded_url" : "http:\/\/strata.oreilly.com\/2013\/02\/how-the-world-communicates-in-2013.html",
      "display_url" : "strata.oreilly.com\/2013\/02\/how-th\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "335504972647120896",
  "text" : "\"we simply aren\u2019t adding that much content when counting by words produced\" http:\/\/t.co\/9JOCrt8oPN       \nHow the world communicates in 2013",
  "id" : 335504972647120896,
  "created_at" : "2013-05-17 21:19:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 74, 90 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/Gm05phMuQ8",
      "expanded_url" : "http:\/\/wp.me\/p3augf-68",
      "display_url" : "wp.me\/p3augf-68"
    } ]
  },
  "geo" : { },
  "id_str" : "335484174611918848",
  "text" : "ELF couples: cross-cultural love relationships http:\/\/t.co\/Gm05phMuQ8 via @wordpressdotcom",
  "id" : 335484174611918848,
  "created_at" : "2013-05-17 19:57:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 62, 78 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/M543D3iAlP",
      "expanded_url" : "http:\/\/wp.me\/p3qkCB-iP",
      "display_url" : "wp.me\/p3qkCB-iP"
    } ]
  },
  "geo" : { },
  "id_str" : "335468169382739969",
  "text" : "Using Concordancers with students  http:\/\/t.co\/M543D3iAlP via @wordpressdotcom",
  "id" : 335468169382739969,
  "created_at" : "2013-05-17 18:53:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chadsansing",
      "screen_name" : "chadsansing",
      "indices" : [ 0, 12 ],
      "id_str" : "76810409",
      "id" : 76810409
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "open_is",
      "indices" : [ 39, 47 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335432030349295616",
  "geo" : { },
  "id_str" : "335438620402003968",
  "in_reply_to_user_id" : 76810409,
  "text" : "@chadsansing does it pick up tweets to #open_is?",
  "id" : 335438620402003968,
  "in_reply_to_status_id" : 335432030349295616,
  "created_at" : "2013-05-17 16:56:13 +0000",
  "in_reply_to_screen_name" : "chadsansing",
  "in_reply_to_user_id_str" : "76810409",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "open_is",
      "indices" : [ 0, 8 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335437868463976448",
  "text" : "#open_is enacting your voice",
  "id" : 335437868463976448,
  "created_at" : "2013-05-17 16:53:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lexconf2013",
      "indices" : [ 41, 53 ]
    }, {
      "text" : "collocation",
      "indices" : [ 54, 66 ]
    }, {
      "text" : "vocab",
      "indices" : [ 67, 73 ]
    }, {
      "text" : "elt",
      "indices" : [ 74, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/ihMNJkufwC",
      "expanded_url" : "http:\/\/bit.ly\/Z16FMU",
      "display_url" : "bit.ly\/Z16FMU"
    } ]
  },
  "geo" : { },
  "id_str" : "335429717278736385",
  "text" : "RT @CELTtraining: Leo Selivan's workshop #lexconf2013 #collocation #vocab #elt http:\/\/t.co\/ihMNJkufwC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "lexconf2013",
        "indices" : [ 23, 35 ]
      }, {
        "text" : "collocation",
        "indices" : [ 36, 48 ]
      }, {
        "text" : "vocab",
        "indices" : [ 49, 55 ]
      }, {
        "text" : "elt",
        "indices" : [ 56, 60 ]
      } ],
      "urls" : [ {
        "indices" : [ 61, 83 ],
        "url" : "http:\/\/t.co\/ihMNJkufwC",
        "expanded_url" : "http:\/\/bit.ly\/Z16FMU",
        "display_url" : "bit.ly\/Z16FMU"
      } ]
    },
    "geo" : { },
    "id_str" : "335392768006430720",
    "text" : "Leo Selivan's workshop #lexconf2013 #collocation #vocab #elt http:\/\/t.co\/ihMNJkufwC",
    "id" : 335392768006430720,
    "created_at" : "2013-05-17 13:54:01 +0000",
    "user" : {
      "name" : "Lexical Lab",
      "screen_name" : "LexicalLab",
      "protected" : false,
      "id_str" : "857732892",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/559654844831506432\/F4HWliCf_normal.jpeg",
      "id" : 857732892,
      "verified" : false
    }
  },
  "id" : 335429717278736385,
  "created_at" : "2013-05-17 16:20:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lexconff2013",
      "indices" : [ 35, 48 ]
    }, {
      "text" : "vocab",
      "indices" : [ 49, 55 ]
    }, {
      "text" : "coursebooks",
      "indices" : [ 56, 68 ]
    }, {
      "text" : "elt",
      "indices" : [ 69, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/aOMgajV1wb",
      "expanded_url" : "http:\/\/blog.westminster.ac.uk\/celt\/2013\/05\/16\/working-exercises-hard\/",
      "display_url" : "blog.westminster.ac.uk\/celt\/2013\/05\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "335429675184693250",
  "text" : "RT @CELTtraining: Hugh's workshop. #lexconff2013 #vocab #coursebooks #elt http:\/\/t.co\/aOMgajV1wb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "lexconff2013",
        "indices" : [ 17, 30 ]
      }, {
        "text" : "vocab",
        "indices" : [ 31, 37 ]
      }, {
        "text" : "coursebooks",
        "indices" : [ 38, 50 ]
      }, {
        "text" : "elt",
        "indices" : [ 51, 55 ]
      } ],
      "urls" : [ {
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/aOMgajV1wb",
        "expanded_url" : "http:\/\/blog.westminster.ac.uk\/celt\/2013\/05\/16\/working-exercises-hard\/",
        "display_url" : "blog.westminster.ac.uk\/celt\/2013\/05\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "335019357455384576",
    "text" : "Hugh's workshop. #lexconff2013 #vocab #coursebooks #elt http:\/\/t.co\/aOMgajV1wb",
    "id" : 335019357455384576,
    "created_at" : "2013-05-16 13:10:13 +0000",
    "user" : {
      "name" : "Lexical Lab",
      "screen_name" : "LexicalLab",
      "protected" : false,
      "id_str" : "857732892",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/559654844831506432\/F4HWliCf_normal.jpeg",
      "id" : 857732892,
      "verified" : false
    }
  },
  "id" : 335429675184693250,
  "created_at" : "2013-05-17 16:20:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335392768006430720",
  "geo" : { },
  "id_str" : "335429585690841088",
  "in_reply_to_user_id" : 857732892,
  "text" : "@CELTtraining hi andrew, the link to leo's prezi is broken",
  "id" : 335429585690841088,
  "in_reply_to_status_id" : 335392768006430720,
  "created_at" : "2013-05-17 16:20:19 +0000",
  "in_reply_to_screen_name" : "LexicalLab",
  "in_reply_to_user_id_str" : "857732892",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/AW2mzbaBME",
      "expanded_url" : "http:\/\/boingboing.net\/2013\/05\/15\/dictionary-of-numbers-browser.html",
      "display_url" : "boingboing.net\/2013\/05\/15\/dic\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "335347785559846914",
  "text" : "Dictionary of Numbers: browser extension humanizes the numbers on the&amp;nbsp;Web: http:\/\/t.co\/AW2mzbaBME",
  "id" : 335347785559846914,
  "created_at" : "2013-05-17 10:55:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Rago",
      "screen_name" : "tesolwar",
      "indices" : [ 3, 12 ],
      "id_str" : "234781682",
      "id" : 234781682
    }, {
      "name" : "Thomas Avery",
      "screen_name" : "Toms_elt",
      "indices" : [ 95, 104 ],
      "id_str" : "1004068988",
      "id" : 1004068988
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/FCUd92g8O6",
      "expanded_url" : "http:\/\/wp.me\/p2Z88c-1d",
      "display_url" : "wp.me\/p2Z88c-1d"
    } ]
  },
  "geo" : { },
  "id_str" : "335312104854798336",
  "text" : "RT @tesolwar: L1 in the EFL Classroom? Part 1 - The Bilingual Turn: http:\/\/t.co\/FCUd92g8O6 via @Toms_elt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Thomas Avery",
        "screen_name" : "Toms_elt",
        "indices" : [ 81, 90 ],
        "id_str" : "1004068988",
        "id" : 1004068988
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 76 ],
        "url" : "http:\/\/t.co\/FCUd92g8O6",
        "expanded_url" : "http:\/\/wp.me\/p2Z88c-1d",
        "display_url" : "wp.me\/p2Z88c-1d"
      } ]
    },
    "geo" : { },
    "id_str" : "335287043515092992",
    "text" : "L1 in the EFL Classroom? Part 1 - The Bilingual Turn: http:\/\/t.co\/FCUd92g8O6 via @Toms_elt",
    "id" : 335287043515092992,
    "created_at" : "2013-05-17 06:53:55 +0000",
    "user" : {
      "name" : "Bill Rago",
      "screen_name" : "tesolwar",
      "protected" : false,
      "id_str" : "234781682",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/646499301141573632\/BQfwxt1a_normal.jpg",
      "id" : 234781682,
      "verified" : false
    }
  },
  "id" : 335312104854798336,
  "created_at" : "2013-05-17 08:33:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 0, 11 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "334970445537349632",
  "geo" : { },
  "id_str" : "335165374922387457",
  "in_reply_to_user_id" : 88202140,
  "text" : "@hughdellar screenr thgh cld not get utube uplder to wrk but can d\/l vid thn upld to utube; less noise, no mse\/keybrd clicks cmprd to jing",
  "id" : 335165374922387457,
  "in_reply_to_status_id" : 334970445537349632,
  "created_at" : "2013-05-16 22:50:27 +0000",
  "in_reply_to_screen_name" : "hughdellar",
  "in_reply_to_user_id_str" : "88202140",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Bunyan",
      "screen_name" : "bunyanchris",
      "indices" : [ 0, 12 ],
      "id_str" : "237402639",
      "id" : 237402639
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335088531745685504",
  "geo" : { },
  "id_str" : "335149349732487168",
  "in_reply_to_user_id" : 237402639,
  "text" : "@bunyanchris possibly but imo this essay more about criteria for choosing corpus results in addition to description of corpora",
  "id" : 335149349732487168,
  "in_reply_to_status_id" : 335088531745685504,
  "created_at" : "2013-05-16 21:46:46 +0000",
  "in_reply_to_screen_name" : "bunyanchris",
  "in_reply_to_user_id_str" : "237402639",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 61, 77 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/VMc0JNUbqD",
      "expanded_url" : "http:\/\/wp.me\/p3qkCB-iA",
      "display_url" : "wp.me\/p3qkCB-iA"
    } ]
  },
  "geo" : { },
  "id_str" : "335056516698742785",
  "text" : "Concorndancers, corpora, and ELT  http:\/\/t.co\/VMc0JNUbqD via @wordpressdotcom",
  "id" : 335056516698742785,
  "created_at" : "2013-05-16 15:37:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulmaglione",
      "screen_name" : "paulmaglione",
      "indices" : [ 3, 16 ],
      "id_str" : "14094921",
      "id" : 14094921
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "efl",
      "indices" : [ 103, 107 ]
    }, {
      "text" : "esl",
      "indices" : [ 108, 112 ]
    }, {
      "text" : "elt",
      "indices" : [ 113, 117 ]
    }, {
      "text" : "iatefl",
      "indices" : [ 118, 125 ]
    }, {
      "text" : "tesol",
      "indices" : [ 126, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/DOaIRprdZC",
      "expanded_url" : "http:\/\/www.agencecle.fr\/inscription-conference-linnovation-au-service-de-lapprentissage-de-langlais\/",
      "display_url" : "agencecle.fr\/inscription-co\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "335042188645896193",
  "text" : "RT @paulmaglione: In one week, Paris May 23rd: Conference on Innovation in English Language Teaching.  #efl #esl #elt #iatefl #tesol http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "efl",
        "indices" : [ 85, 89 ]
      }, {
        "text" : "esl",
        "indices" : [ 90, 94 ]
      }, {
        "text" : "elt",
        "indices" : [ 95, 99 ]
      }, {
        "text" : "iatefl",
        "indices" : [ 100, 107 ]
      }, {
        "text" : "tesol",
        "indices" : [ 108, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/DOaIRprdZC",
        "expanded_url" : "http:\/\/www.agencecle.fr\/inscription-conference-linnovation-au-service-de-lapprentissage-de-langlais\/",
        "display_url" : "agencecle.fr\/inscription-co\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "335006689512259585",
    "text" : "In one week, Paris May 23rd: Conference on Innovation in English Language Teaching.  #efl #esl #elt #iatefl #tesol http:\/\/t.co\/DOaIRprdZC",
    "id" : 335006689512259585,
    "created_at" : "2013-05-16 12:19:53 +0000",
    "user" : {
      "name" : "paulmaglione",
      "screen_name" : "paulmaglione",
      "protected" : false,
      "id_str" : "14094921",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/206852089\/twitterpic1_normal.jpg",
      "id" : 14094921,
      "verified" : false
    }
  },
  "id" : 335042188645896193,
  "created_at" : "2013-05-16 14:40:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lexconf2013",
      "indices" : [ 65, 77 ]
    }, {
      "text" : "lexical",
      "indices" : [ 78, 86 ]
    }, {
      "text" : "priming",
      "indices" : [ 96, 104 ]
    }, {
      "text" : "elt",
      "indices" : [ 105, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/tPCo0XRGR6",
      "expanded_url" : "http:\/\/bit.ly\/17z3C17",
      "display_url" : "bit.ly\/17z3C17"
    } ]
  },
  "geo" : { },
  "id_str" : "335018813542248448",
  "text" : "RT @CELTtraining: Michael Hoey plenary - summary and powerpoint. #lexconf2013 #lexical approach #priming #elt. http:\/\/t.co\/tPCo0XRGR6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "lexconf2013",
        "indices" : [ 47, 59 ]
      }, {
        "text" : "lexical",
        "indices" : [ 60, 68 ]
      }, {
        "text" : "priming",
        "indices" : [ 78, 86 ]
      }, {
        "text" : "elt",
        "indices" : [ 87, 91 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/tPCo0XRGR6",
        "expanded_url" : "http:\/\/bit.ly\/17z3C17",
        "display_url" : "bit.ly\/17z3C17"
      } ]
    },
    "geo" : { },
    "id_str" : "335012764105990144",
    "text" : "Michael Hoey plenary - summary and powerpoint. #lexconf2013 #lexical approach #priming #elt. http:\/\/t.co\/tPCo0XRGR6",
    "id" : 335012764105990144,
    "created_at" : "2013-05-16 12:44:01 +0000",
    "user" : {
      "name" : "Lexical Lab",
      "screen_name" : "LexicalLab",
      "protected" : false,
      "id_str" : "857732892",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/559654844831506432\/F4HWliCf_normal.jpeg",
      "id" : 857732892,
      "verified" : false
    }
  },
  "id" : 335018813542248448,
  "created_at" : "2013-05-16 13:08:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/YvnlWef8hr",
      "expanded_url" : "http:\/\/arxiv.org\/abs\/1304.3480v1",
      "display_url" : "arxiv.org\/abs\/1304.3480v1"
    } ]
  },
  "geo" : { },
  "id_str" : "334996129030758400",
  "text" : "Friendship Paradox Redux: Your Friends Are More Interesting Than You\nhttp:\/\/t.co\/YvnlWef8hr",
  "id" : 334996129030758400,
  "created_at" : "2013-05-16 11:37:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jo Sayers",
      "screen_name" : "jo_sayers",
      "indices" : [ 3, 13 ],
      "id_str" : "87176766",
      "id" : 87176766
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELTchat",
      "indices" : [ 15, 23 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/kNy0ShGmwy",
      "expanded_url" : "http:\/\/eltplustech.blogspot.com\/2013\/05\/eltchat-summary-motivation-la-hadfield.html",
      "display_url" : "eltplustech.blogspot.com\/2013\/05\/eltcha\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "334992670495752192",
  "text" : "RT @jo_sayers: #ELTchat summary for 12bst chat yesterday. Motivation &amp; L2 self http:\/\/t.co\/kNy0ShGmwy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELTchat",
        "indices" : [ 0, 8 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/kNy0ShGmwy",
        "expanded_url" : "http:\/\/eltplustech.blogspot.com\/2013\/05\/eltchat-summary-motivation-la-hadfield.html",
        "display_url" : "eltplustech.blogspot.com\/2013\/05\/eltcha\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "334990791531442176",
    "text" : "#ELTchat summary for 12bst chat yesterday. Motivation &amp; L2 self http:\/\/t.co\/kNy0ShGmwy",
    "id" : 334990791531442176,
    "created_at" : "2013-05-16 11:16:43 +0000",
    "user" : {
      "name" : "Jo Sayers",
      "screen_name" : "jo_sayers",
      "protected" : false,
      "id_str" : "87176766",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/466896591480037376\/EssZHYa4_normal.jpeg",
      "id" : 87176766,
      "verified" : false
    }
  },
  "id" : 334992670495752192,
  "created_at" : "2013-05-16 11:24:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 3, 18 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oldeltpost",
      "indices" : [ 60, 71 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 110, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/lrNgfcMznD",
      "expanded_url" : "http:\/\/wp.me\/p2hCXG-EG",
      "display_url" : "wp.me\/p2hCXG-EG"
    } ]
  },
  "geo" : { },
  "id_str" : "334981949758259200",
  "text" : "RT @MrChrisJWilson: Finally got round to finishing The best #oldeltpost by Leo Selivan http:\/\/t.co\/lrNgfcMznD #eltchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "oldeltpost",
        "indices" : [ 40, 51 ]
      }, {
        "text" : "eltchat",
        "indices" : [ 90, 98 ]
      } ],
      "urls" : [ {
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/lrNgfcMznD",
        "expanded_url" : "http:\/\/wp.me\/p2hCXG-EG",
        "display_url" : "wp.me\/p2hCXG-EG"
      } ]
    },
    "geo" : { },
    "id_str" : "334805875296456704",
    "text" : "Finally got round to finishing The best #oldeltpost by Leo Selivan http:\/\/t.co\/lrNgfcMznD #eltchat",
    "id" : 334805875296456704,
    "created_at" : "2013-05-15 23:01:55 +0000",
    "user" : {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "protected" : false,
      "id_str" : "20760283",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744952885595758592\/H4bmsUn3_normal.jpg",
      "id" : 20760283,
      "verified" : false
    }
  },
  "id" : 334981949758259200,
  "created_at" : "2013-05-16 10:41:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lexconf2013",
      "indices" : [ 0, 12 ]
    } ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/cWSGC4L2Pd",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-CE",
      "display_url" : "wp.me\/pgHyE-CE"
    } ]
  },
  "geo" : { },
  "id_str" : "334976016965570560",
  "text" : "#lexconf2013 \nNovice workshop-talk hues http:\/\/t.co\/cWSGC4L2Pd",
  "id" : 334976016965570560,
  "created_at" : "2013-05-16 10:18:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jo Sayers",
      "screen_name" : "jo_sayers",
      "indices" : [ 0, 10 ],
      "id_str" : "87176766",
      "id" : 87176766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "334923825772912641",
  "geo" : { },
  "id_str" : "334942577352642560",
  "in_reply_to_user_id" : 87176766,
  "text" : "@jo_sayers You are not a park bench:You are a pseudo-interactive advert which is making me feel guilty for not working on my day off&lt;grt art",
  "id" : 334942577352642560,
  "in_reply_to_status_id" : 334923825772912641,
  "created_at" : "2013-05-16 08:05:08 +0000",
  "in_reply_to_screen_name" : "jo_sayers",
  "in_reply_to_user_id_str" : "87176766",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0414\u0438\u0430\u043D\u043A\u0430 \u0428\u043A\u0443\u0440\u0441\u043A\u0430\u044F",
      "screen_name" : "TheSecretDoS",
      "indices" : [ 0, 13 ],
      "id_str" : "440292980",
      "id" : 440292980
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334800492402188288",
  "text" : "@TheSecretDoS avec plaisir :)",
  "id" : 334800492402188288,
  "created_at" : "2013-05-15 22:40:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0414\u0438\u0430\u043D\u043A\u0430 \u0428\u043A\u0443\u0440\u0441\u043A\u0430\u044F",
      "screen_name" : "TheSecretDoS",
      "indices" : [ 0, 13 ],
      "id_str" : "440292980",
      "id" : 440292980
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/wDjSjigGsA",
      "expanded_url" : "http:\/\/eflnotes.wordpress.com\/2013\/05\/06\/what-to-teach-from-corpora-output-frequency-and-transparency\/",
      "display_url" : "eflnotes.wordpress.com\/2013\/05\/06\/wha\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "334796761350668288",
  "text" : "@TheSecretDoS if it's that martinez article u shld re-check my post http:\/\/t.co\/wDjSjigGsA :)",
  "id" : 334796761350668288,
  "created_at" : "2013-05-15 22:25:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 0, 11 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/DpdqdmqEi9",
      "expanded_url" : "http:\/\/journals.cambridge.org\/action\/displayFulltext?type=6&fid=8771499&jid=APL&volumeId=32&issueId=-1&aid=8771498&bodyId=&membershipNumber=&societyETOCSession=&fulltextType=RA&fileId=S026719051200013X&specialArticle=Y",
      "display_url" : "journals.cambridge.org\/action\/display\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "334790212397965312",
  "geo" : { },
  "id_str" : "334793589974511617",
  "in_reply_to_user_id" : 88202140,
  "text" : "@hughdellar btw read a reference to 'ambient meaning' by Sinclair cited -&gt; http:\/\/t.co\/DpdqdmqEi9",
  "id" : 334793589974511617,
  "in_reply_to_status_id" : 334790212397965312,
  "created_at" : "2013-05-15 22:13:06 +0000",
  "in_reply_to_screen_name" : "hughdellar",
  "in_reply_to_user_id_str" : "88202140",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0414\u0438\u0430\u043D\u043A\u0430 \u0428\u043A\u0443\u0440\u0441\u043A\u0430\u044F",
      "screen_name" : "TheSecretDoS",
      "indices" : [ 0, 13 ],
      "id_str" : "440292980",
      "id" : 440292980
    }, {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 14, 25 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "Scott Thornbury",
      "screen_name" : "thornburyscott",
      "indices" : [ 26, 41 ],
      "id_str" : "23090474",
      "id" : 23090474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334791587559251969",
  "text" : "@TheSecretDoS @leoselivan @thornburyscott glad to share, LUG looks pretty powerful",
  "id" : 334791587559251969,
  "created_at" : "2013-05-15 22:05:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 0, 11 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "334779540851290112",
  "geo" : { },
  "id_str" : "334789111934222336",
  "in_reply_to_user_id" : 88202140,
  "text" : "@hughdellar hi hugh, brainshark giving \"the presentation you have selected is not currently active\" message",
  "id" : 334789111934222336,
  "in_reply_to_status_id" : 334779540851290112,
  "created_at" : "2013-05-15 21:55:19 +0000",
  "in_reply_to_screen_name" : "hughdellar",
  "in_reply_to_user_id_str" : "88202140",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Phelps",
      "screen_name" : "pterolaur",
      "indices" : [ 0, 10 ],
      "id_str" : "90093887",
      "id" : 90093887
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "334709560105398273",
  "geo" : { },
  "id_str" : "334734211489611777",
  "in_reply_to_user_id" : 90093887,
  "text" : "@pterolaur NICE! :)",
  "id" : 334734211489611777,
  "in_reply_to_status_id" : 334709560105398273,
  "created_at" : "2013-05-15 18:17:09 +0000",
  "in_reply_to_screen_name" : "pterolaur",
  "in_reply_to_user_id_str" : "90093887",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0414\u0438\u0430\u043D\u043A\u0430 \u0428\u043A\u0443\u0440\u0441\u043A\u0430\u044F",
      "screen_name" : "TheSecretDoS",
      "indices" : [ 0, 13 ],
      "id_str" : "440292980",
      "id" : 440292980
    }, {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 14, 25 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "Scott Thornbury",
      "screen_name" : "thornburyscott",
      "indices" : [ 26, 41 ],
      "id_str" : "23090474",
      "id" : 23090474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/X7oWyCPSQm",
      "expanded_url" : "http:\/\/elfaproject.wordpress.com\/2013\/03\/25\/fluent-chunks-intro-to-lug\/",
      "display_url" : "elfaproject.wordpress.com\/2013\/03\/25\/flu\u2026"
    }, {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/f1MU0AbfYD",
      "expanded_url" : "http:\/\/elfaproject.wordpress.com\/2013\/05\/12\/fluent-chunks-2-how-to-label-your-chunks\/",
      "display_url" : "elfaproject.wordpress.com\/2013\/05\/12\/flu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "334733332803891200",
  "text" : "@TheSecretDoS @leoselivan @thornburyscott LUG approach wrth a lk http:\/\/t.co\/X7oWyCPSQm and http:\/\/t.co\/f1MU0AbfYD",
  "id" : 334733332803891200,
  "created_at" : "2013-05-15 18:13:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "Ela Wassell",
      "screen_name" : "elawassell",
      "indices" : [ 12, 23 ],
      "id_str" : "51157050",
      "id" : 51157050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "334719476643799040",
  "geo" : { },
  "id_str" : "334720150165135360",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan @elawassell sorry what's vrt6?",
  "id" : 334720150165135360,
  "in_reply_to_status_id" : 334719476643799040,
  "created_at" : "2013-05-15 17:21:17 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ela Wassell",
      "screen_name" : "elawassell",
      "indices" : [ 0, 11 ],
      "id_str" : "51157050",
      "id" : 51157050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "334704319649693697",
  "geo" : { },
  "id_str" : "334719080495976448",
  "in_reply_to_user_id" : 51157050,
  "text" : "@elawassell sweet! don't hesitate to ask if u have any questions",
  "id" : 334719080495976448,
  "in_reply_to_status_id" : 334704319649693697,
  "created_at" : "2013-05-15 17:17:02 +0000",
  "in_reply_to_screen_name" : "elawassell",
  "in_reply_to_user_id_str" : "51157050",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Colleen Brown",
      "screen_name" : "c_brune",
      "indices" : [ 0, 8 ],
      "id_str" : "34247658",
      "id" : 34247658
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "334462924955455488",
  "geo" : { },
  "id_str" : "334675505817214976",
  "in_reply_to_user_id" : 34247658,
  "text" : "@c_brune cool DMed you",
  "id" : 334675505817214976,
  "in_reply_to_status_id" : 334462924955455488,
  "created_at" : "2013-05-15 14:23:53 +0000",
  "in_reply_to_screen_name" : "c_brune",
  "in_reply_to_user_id_str" : "34247658",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jo Sayers",
      "screen_name" : "jo_sayers",
      "indices" : [ 3, 13 ],
      "id_str" : "87176766",
      "id" : 87176766
    }, {
      "name" : "Peter Kittle",
      "screen_name" : "pkittle",
      "indices" : [ 70, 78 ],
      "id_str" : "11322822",
      "id" : 11322822
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 83, 92 ],
      "id_str" : "18602422",
      "id" : 18602422
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "teachtheweb",
      "indices" : [ 15, 27 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/CGUmpBlTva",
      "expanded_url" : "https:\/\/thimble.webmaker.org\/p\/lkml\/",
      "display_url" : "thimble.webmaker.org\/p\/lkml\/"
    } ]
  },
  "geo" : { },
  "id_str" : "334674879225933824",
  "text" : "RT @jo_sayers: #teachtheweb dartsdartsdarts language in this remix of @pkittle via @muranava https:\/\/t.co\/CGUmpBlTva",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Peter Kittle",
        "screen_name" : "pkittle",
        "indices" : [ 55, 63 ],
        "id_str" : "11322822",
        "id" : 11322822
      }, {
        "name" : "Mura Nava",
        "screen_name" : "muranava",
        "indices" : [ 68, 77 ],
        "id_str" : "18602422",
        "id" : 18602422
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "teachtheweb",
        "indices" : [ 0, 12 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/CGUmpBlTva",
        "expanded_url" : "https:\/\/thimble.webmaker.org\/p\/lkml\/",
        "display_url" : "thimble.webmaker.org\/p\/lkml\/"
      } ]
    },
    "geo" : { },
    "id_str" : "334673256252596224",
    "text" : "#teachtheweb dartsdartsdarts language in this remix of @pkittle via @muranava https:\/\/t.co\/CGUmpBlTva",
    "id" : 334673256252596224,
    "created_at" : "2013-05-15 14:14:56 +0000",
    "user" : {
      "name" : "Jo Sayers",
      "screen_name" : "jo_sayers",
      "protected" : false,
      "id_str" : "87176766",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/466896591480037376\/EssZHYa4_normal.jpeg",
      "id" : 87176766,
      "verified" : false
    }
  },
  "id" : 334674879225933824,
  "created_at" : "2013-05-15 14:21:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jo Sayers",
      "screen_name" : "jo_sayers",
      "indices" : [ 0, 10 ],
      "id_str" : "87176766",
      "id" : 87176766
    }, {
      "name" : "Peter Kittle",
      "screen_name" : "pkittle",
      "indices" : [ 11, 19 ],
      "id_str" : "11322822",
      "id" : 11322822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "334673256252596224",
  "geo" : { },
  "id_str" : "334674803510366210",
  "in_reply_to_user_id" : 87176766,
  "text" : "@jo_sayers @pkittle that Isaac Newton ref is a classic hehe :)",
  "id" : 334674803510366210,
  "in_reply_to_status_id" : 334673256252596224,
  "created_at" : "2013-05-15 14:21:05 +0000",
  "in_reply_to_screen_name" : "jo_sayers",
  "in_reply_to_user_id_str" : "87176766",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/BUwWGWKEtz",
      "expanded_url" : "http:\/\/libertymagazine.co.uk\/2013\/05\/mau-mau-the-epic-calm-of-state-violence-in-occupied-kenya\/",
      "display_url" : "libertymagazine.co.uk\/2013\/05\/mau-ma\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "334621416420950018",
  "text" : "Mau Mau: The Epic Calm of State Violence in Occupied Kenya\nhttp:\/\/t.co\/BUwWGWKEtz",
  "id" : 334621416420950018,
  "created_at" : "2013-05-15 10:48:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CUP Linguistics",
      "screen_name" : "CambUP_LangLing",
      "indices" : [ 3, 19 ],
      "id_str" : "117051544",
      "id" : 117051544
    }, {
      "name" : "Cambridge Journals",
      "screen_name" : "CambridgeJnls",
      "indices" : [ 114, 128 ],
      "id_str" : "89701184",
      "id" : 89701184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/OlRbocNYnP",
      "expanded_url" : "http:\/\/bit.ly\/18G9Vzd",
      "display_url" : "bit.ly\/18G9Vzd"
    } ]
  },
  "geo" : { },
  "id_str" : "334335241000988672",
  "text" : "RT @CambUP_LangLing: Download three pieces of research on formulaic language at no charge: http:\/\/t.co\/OlRbocNYnP @CambridgeJnls",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Cambridge Journals",
        "screen_name" : "CambridgeJnls",
        "indices" : [ 93, 107 ],
        "id_str" : "89701184",
        "id" : 89701184
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/OlRbocNYnP",
        "expanded_url" : "http:\/\/bit.ly\/18G9Vzd",
        "display_url" : "bit.ly\/18G9Vzd"
      } ]
    },
    "geo" : { },
    "id_str" : "334328895455260672",
    "text" : "Download three pieces of research on formulaic language at no charge: http:\/\/t.co\/OlRbocNYnP @CambridgeJnls",
    "id" : 334328895455260672,
    "created_at" : "2013-05-14 15:26:34 +0000",
    "user" : {
      "name" : "CUP Linguistics",
      "screen_name" : "CambUP_LangLing",
      "protected" : false,
      "id_str" : "117051544",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/511827278641115137\/DQP0K7Vb_normal.jpeg",
      "id" : 117051544,
      "verified" : false
    }
  },
  "id" : 334335241000988672,
  "created_at" : "2013-05-14 15:51:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hakan \u015Eent\u00FCrk",
      "screen_name" : "hakan_sentrk",
      "indices" : [ 0, 13 ],
      "id_str" : "118198984",
      "id" : 118198984
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cet103",
      "indices" : [ 17, 24 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "334270720265818113",
  "geo" : { },
  "id_str" : "334273051657109506",
  "in_reply_to_user_id" : 118198984,
  "text" : "@hakan_sentrk hi #cet103 class greetings from france :)",
  "id" : 334273051657109506,
  "in_reply_to_status_id" : 334270720265818113,
  "created_at" : "2013-05-14 11:44:40 +0000",
  "in_reply_to_screen_name" : "hakan_sentrk",
  "in_reply_to_user_id_str" : "118198984",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Thornbury",
      "screen_name" : "thornburyscott",
      "indices" : [ 3, 18 ],
      "id_str" : "23090474",
      "id" : 23090474
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Stringnet",
      "indices" : [ 53, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/67mYusUMlK",
      "expanded_url" : "http:\/\/blog.stringnet.org\/?p=84",
      "display_url" : "blog.stringnet.org\/?p=84"
    } ]
  },
  "geo" : { },
  "id_str" : "334256006735478785",
  "text" : "RT @thornburyscott: Very clear explanation as to why #Stringnet is not a corpus and why this is a Good Thing! http:\/\/t.co\/67mYusUMlK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Stringnet",
        "indices" : [ 33, 43 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/67mYusUMlK",
        "expanded_url" : "http:\/\/blog.stringnet.org\/?p=84",
        "display_url" : "blog.stringnet.org\/?p=84"
      } ]
    },
    "geo" : { },
    "id_str" : "334253954638704640",
    "text" : "Very clear explanation as to why #Stringnet is not a corpus and why this is a Good Thing! http:\/\/t.co\/67mYusUMlK",
    "id" : 334253954638704640,
    "created_at" : "2013-05-14 10:28:47 +0000",
    "user" : {
      "name" : "Scott Thornbury",
      "screen_name" : "thornburyscott",
      "protected" : false,
      "id_str" : "23090474",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892392697\/twitter03_normal.jpg",
      "id" : 23090474,
      "verified" : false
    }
  },
  "id" : 334256006735478785,
  "created_at" : "2013-05-14 10:36:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Akira Murakami",
      "screen_name" : "mrkm_a",
      "indices" : [ 3, 10 ],
      "id_str" : "116922669",
      "id" : 116922669
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/KNHrkQ3897",
      "expanded_url" : "http:\/\/www.jneurosci.org\/content\/33\/19\/8528",
      "display_url" : "jneurosci.org\/content\/33\/19\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "334036771463643137",
  "text" : "RT @mrkm_a: Batterink &amp; Neville (2013) The human brain processes syntax in the absence of conscious awareness. http:\/\/t.co\/KNHrkQ3897",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/KNHrkQ3897",
        "expanded_url" : "http:\/\/www.jneurosci.org\/content\/33\/19\/8528",
        "display_url" : "jneurosci.org\/content\/33\/19\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "334005895828750336",
    "text" : "Batterink &amp; Neville (2013) The human brain processes syntax in the absence of conscious awareness. http:\/\/t.co\/KNHrkQ3897",
    "id" : 334005895828750336,
    "created_at" : "2013-05-13 18:03:05 +0000",
    "user" : {
      "name" : "Akira Murakami",
      "screen_name" : "mrkm_a",
      "protected" : false,
      "id_str" : "116922669",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/491819353784860672\/LqdQ1Sye_normal.jpeg",
      "id" : 116922669,
      "verified" : false
    }
  },
  "id" : 334036771463643137,
  "created_at" : "2013-05-13 20:05:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chadsansing",
      "screen_name" : "chadsansing",
      "indices" : [ 0, 12 ],
      "id_str" : "76810409",
      "id" : 76810409
    }, {
      "name" : "KevinHodgson",
      "screen_name" : "dogtrax",
      "indices" : [ 13, 21 ],
      "id_str" : "13307352",
      "id" : 13307352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "333163446453563392",
  "geo" : { },
  "id_str" : "333580594447527938",
  "in_reply_to_user_id" : 76810409,
  "text" : "@chadsansing @dogtrax very cool! :) i used the 3d tool in a presentation the othwr day, think it went down well :)",
  "id" : 333580594447527938,
  "in_reply_to_status_id" : 333163446453563392,
  "created_at" : "2013-05-12 13:53:06 +0000",
  "in_reply_to_screen_name" : "chadsansing",
  "in_reply_to_user_id_str" : "76810409",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    }, {
      "name" : "010-8575-6630",
      "screen_name" : "djnada",
      "indices" : [ 17, 24 ],
      "id_str" : "2271666128",
      "id" : 2271666128
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "333577265923379200",
  "geo" : { },
  "id_str" : "333579986126639104",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin @djnada thanks for the props Mike:) how's yr sunday?",
  "id" : 333579986126639104,
  "in_reply_to_status_id" : 333577265923379200,
  "created_at" : "2013-05-12 13:50:40 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Taylor",
      "screen_name" : "theteacherjames",
      "indices" : [ 0, 16 ],
      "id_str" : "71746265",
      "id" : 71746265
    }, {
      "name" : "chadsansing",
      "screen_name" : "chadsansing",
      "indices" : [ 53, 65 ],
      "id_str" : "76810409",
      "id" : 76810409
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "teachtheweb",
      "indices" : [ 118, 130 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "333576094148075520",
  "geo" : { },
  "id_str" : "333579879914283009",
  "in_reply_to_user_id" : 71746265,
  "text" : "@theteacherjames forget to add that original text is @chadsansing purposively written to be reused\/remixed as part of #teachtheweb",
  "id" : 333579879914283009,
  "in_reply_to_status_id" : 333576094148075520,
  "created_at" : "2013-05-12 13:50:15 +0000",
  "in_reply_to_screen_name" : "theteacherjames",
  "in_reply_to_user_id_str" : "71746265",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 69, 85 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/dpK9ZTM0Jh",
      "expanded_url" : "http:\/\/wp.me\/p3augf-4O",
      "display_url" : "wp.me\/p3augf-4O"
    } ]
  },
  "geo" : { },
  "id_str" : "333578399140429826",
  "text" : "Fluent chunks 2: How to label your chunks http:\/\/t.co\/dpK9ZTM0Jh via @wordpressdotcom",
  "id" : 333578399140429826,
  "created_at" : "2013-05-12 13:44:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u672C\u3000\u7BE4",
      "screen_name" : "MizumotoAtsushi",
      "indices" : [ 0, 16 ],
      "id_str" : "298592919",
      "id" : 298592919
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "333556653867798528",
  "geo" : { },
  "id_str" : "333564631501127680",
  "in_reply_to_user_id" : 298592919,
  "text" : "@MizumotoAtsushi thank you for sharing :)",
  "id" : 333564631501127680,
  "in_reply_to_status_id" : 333556653867798528,
  "created_at" : "2013-05-12 12:49:40 +0000",
  "in_reply_to_screen_name" : "MizumotoAtsushi",
  "in_reply_to_user_id_str" : "298592919",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ela Wassell",
      "screen_name" : "elawassell",
      "indices" : [ 0, 11 ],
      "id_str" : "51157050",
      "id" : 51157050
    }, {
      "name" : "Laura Patsko",
      "screen_name" : "lauraahaha",
      "indices" : [ 12, 23 ],
      "id_str" : "97957137",
      "id" : 97957137
    }, {
      "name" : "Huw Jarvis",
      "screen_name" : "TESOLacademic",
      "indices" : [ 24, 38 ],
      "id_str" : "43409552",
      "id" : 43409552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "333545662492864512",
  "geo" : { },
  "id_str" : "333564397945503744",
  "in_reply_to_user_id" : 51157050,
  "text" : "@elawassell @lauraahaha @TESOLacademic thanks v much  for share, RTs and comments :)",
  "id" : 333564397945503744,
  "in_reply_to_status_id" : 333545662492864512,
  "created_at" : "2013-05-12 12:48:44 +0000",
  "in_reply_to_screen_name" : "elawassell",
  "in_reply_to_user_id_str" : "51157050",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0414\u0438\u0430\u043D\u043A\u0430 \u0428\u043A\u0443\u0440\u0441\u043A\u0430\u044F",
      "screen_name" : "TheSecretDoS",
      "indices" : [ 0, 13 ],
      "id_str" : "440292980",
      "id" : 440292980
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333522394658516993",
  "text" : "@TheSecretDoS many thanks for share :) hope yr sunday is going well",
  "id" : 333522394658516993,
  "created_at" : "2013-05-12 10:01:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 0, 11 ],
      "id_str" : "282659955",
      "id" : 282659955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "332964062910627841",
  "geo" : { },
  "id_str" : "333481127840980992",
  "in_reply_to_user_id" : 282659955,
  "text" : "@teflerinha a pleasure it was a cracking post :)",
  "id" : 333481127840980992,
  "in_reply_to_status_id" : 332964062910627841,
  "created_at" : "2013-05-12 07:17:51 +0000",
  "in_reply_to_screen_name" : "teflerinha",
  "in_reply_to_user_id_str" : "282659955",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 50, 66 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/H8R1nDHWDs",
      "expanded_url" : "http:\/\/wp.me\/pJw7u-1ct",
      "display_url" : "wp.me\/pJw7u-1ct"
    } ]
  },
  "geo" : { },
  "id_str" : "333470841046171648",
  "text" : "C is for (COCA) Corpus http:\/\/t.co\/H8R1nDHWDs via @wordpressdotcom",
  "id" : 333470841046171648,
  "created_at" : "2013-05-12 06:36:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ela Wassell",
      "screen_name" : "elawassell",
      "indices" : [ 0, 11 ],
      "id_str" : "51157050",
      "id" : 51157050
    }, {
      "name" : "Agy Luczak",
      "screen_name" : "AgyLuczak",
      "indices" : [ 12, 22 ],
      "id_str" : "1347711498",
      "id" : 1347711498
    }, {
      "name" : "Laura Patsko",
      "screen_name" : "lauraahaha",
      "indices" : [ 23, 34 ],
      "id_str" : "97957137",
      "id" : 97957137
    }, {
      "name" : "Laura Laubacher",
      "screen_name" : "LaubacherLaura",
      "indices" : [ 35, 50 ],
      "id_str" : "517621042",
      "id" : 517621042
    }, {
      "name" : "Luke Fletcher",
      "screen_name" : "LukeFletcher7",
      "indices" : [ 51, 65 ],
      "id_str" : "365535654",
      "id" : 365535654
    }, {
      "name" : "Not Michael Phelps",
      "screen_name" : "harrisonmike",
      "indices" : [ 66, 79 ],
      "id_str" : "1685397408",
      "id" : 1685397408
    }, {
      "name" : "Nick Robinson",
      "screen_name" : "nmkrobinson",
      "indices" : [ 80, 92 ],
      "id_str" : "20425399",
      "id" : 20425399
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "333359418987143168",
  "geo" : { },
  "id_str" : "333469422389977089",
  "in_reply_to_user_id" : 51157050,
  "text" : "@elawassell @AgyLuczak @lauraahaha @LaubacherLaura @LukeFletcher7 @harrisonmike @nmkrobinson fab fab people :)",
  "id" : 333469422389977089,
  "in_reply_to_status_id" : 333359418987143168,
  "created_at" : "2013-05-12 06:31:20 +0000",
  "in_reply_to_screen_name" : "elawassell",
  "in_reply_to_user_id_str" : "51157050",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Patsko",
      "screen_name" : "lauraahaha",
      "indices" : [ 0, 11 ],
      "id_str" : "97957137",
      "id" : 97957137
    }, {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 12, 23 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "Ela Wassell",
      "screen_name" : "elawassell",
      "indices" : [ 24, 35 ],
      "id_str" : "51157050",
      "id" : 51157050
    }, {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 36, 47 ],
      "id_str" : "88202140",
      "id" : 88202140
    }, {
      "name" : "Agy Luczak",
      "screen_name" : "AgyLuczak",
      "indices" : [ 48, 58 ],
      "id_str" : "1347711498",
      "id" : 1347711498
    }, {
      "name" : "Laura Laubacher",
      "screen_name" : "LaubacherLaura",
      "indices" : [ 59, 74 ],
      "id_str" : "517621042",
      "id" : 517621042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "333346882380251137",
  "geo" : { },
  "id_str" : "333469223651270656",
  "in_reply_to_user_id" : 97957137,
  "text" : "@lauraahaha @leoselivan @elawassell @hughdellar @AgyLuczak @LaubacherLaura good fun for sure!",
  "id" : 333469223651270656,
  "in_reply_to_status_id" : 333346882380251137,
  "created_at" : "2013-05-12 06:30:33 +0000",
  "in_reply_to_screen_name" : "lauraahaha",
  "in_reply_to_user_id_str" : "97957137",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Taylor",
      "screen_name" : "theteacherjames",
      "indices" : [ 0, 16 ],
      "id_str" : "71746265",
      "id" : 71746265
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "333267885076131841",
  "geo" : { },
  "id_str" : "333469066654265344",
  "in_reply_to_user_id" : 71746265,
  "text" : "@theteacherjames sure no problems :)",
  "id" : 333469066654265344,
  "in_reply_to_status_id" : 333267885076131841,
  "created_at" : "2013-05-12 06:29:55 +0000",
  "in_reply_to_screen_name" : "theteacherjames",
  "in_reply_to_user_id_str" : "71746265",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 0, 11 ],
      "id_str" : "88202140",
      "id" : 88202140
    }, {
      "name" : "Ela Wassell",
      "screen_name" : "elawassell",
      "indices" : [ 12, 23 ],
      "id_str" : "51157050",
      "id" : 51157050
    }, {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 24, 35 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "The Hands Up Project",
      "screen_name" : "nickbilbrough",
      "indices" : [ 36, 50 ],
      "id_str" : "273391079",
      "id" : 273391079
    }, {
      "name" : "Luke Fletcher",
      "screen_name" : "LukeFletcher7",
      "indices" : [ 51, 65 ],
      "id_str" : "365535654",
      "id" : 365535654
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "333233133984026625",
  "geo" : { },
  "id_str" : "333468946130939904",
  "in_reply_to_user_id" : 88202140,
  "text" : "@hughdellar @elawassell @leoselivan @nickbilbrough @LukeFletcher7 @CELTtraining great event great people!",
  "id" : 333468946130939904,
  "in_reply_to_status_id" : 333233133984026625,
  "created_at" : "2013-05-12 06:29:26 +0000",
  "in_reply_to_screen_name" : "hughdellar",
  "in_reply_to_user_id_str" : "88202140",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lexconf2013",
      "indices" : [ 17, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/nCrm1YHZVQ",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-Bj",
      "display_url" : "wp.me\/pgHyE-Bj"
    } ]
  },
  "geo" : { },
  "id_str" : "333468814656303104",
  "text" : "quick notes from #lexconf2013 http:\/\/t.co\/nCrm1YHZVQ",
  "id" : 333468814656303104,
  "created_at" : "2013-05-12 06:28:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 72, 83 ],
      "id_str" : "282659955",
      "id" : 282659955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/Ro2sqC9nLg",
      "expanded_url" : "http:\/\/wp.me\/p2e2Wf-dJ",
      "display_url" : "wp.me\/p2e2Wf-dJ"
    } ]
  },
  "geo" : { },
  "id_str" : "332893546128502785",
  "text" : "A short guide to concept checking vocabulary http:\/\/t.co\/Ro2sqC9nLg via @teflerinha",
  "id" : 332893546128502785,
  "created_at" : "2013-05-10 16:23:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lexconf2013",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/wT3LojVVCZ",
      "expanded_url" : "http:\/\/bit.ly\/ZMTxWM",
      "display_url" : "bit.ly\/ZMTxWM"
    } ]
  },
  "geo" : { },
  "id_str" : "332826353378410496",
  "text" : "RT @CELTtraining: Register comments and questions on Lexical teaching conference at Westminster Uni from tomorrow.   http:\/\/t.co\/wT3LojVVCZ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "lexconf2013",
        "indices" : [ 122, 134 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/wT3LojVVCZ",
        "expanded_url" : "http:\/\/bit.ly\/ZMTxWM",
        "display_url" : "bit.ly\/ZMTxWM"
      } ]
    },
    "geo" : { },
    "id_str" : "332814539886313472",
    "text" : "Register comments and questions on Lexical teaching conference at Westminster Uni from tomorrow.   http:\/\/t.co\/wT3LojVVCZ #lexconf2013",
    "id" : 332814539886313472,
    "created_at" : "2013-05-10 11:09:04 +0000",
    "user" : {
      "name" : "Lexical Lab",
      "screen_name" : "LexicalLab",
      "protected" : false,
      "id_str" : "857732892",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/559654844831506432\/F4HWliCf_normal.jpeg",
      "id" : 857732892,
      "verified" : false
    }
  },
  "id" : 332826353378410496,
  "created_at" : "2013-05-10 11:56:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/jnFlMd31qn",
      "expanded_url" : "https:\/\/plus.google.com\/u\/0\/107478410160659334381\/posts\/RPKYgfSLqED",
      "display_url" : "plus.google.com\/u\/0\/1074784101\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "332423983330893824",
  "text" : "fascinating link btw ling diversity and biodiversity https:\/\/t.co\/jnFlMd31qn",
  "id" : 332423983330893824,
  "created_at" : "2013-05-09 09:17:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Rago",
      "screen_name" : "tesolwar",
      "indices" : [ 19, 28 ],
      "id_str" : "234781682",
      "id" : 234781682
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELTchat",
      "indices" : [ 106, 114 ]
    }, {
      "text" : "tesol",
      "indices" : [ 115, 121 ]
    }, {
      "text" : "edchat",
      "indices" : [ 122, 129 ]
    }, {
      "text" : "KELTchat",
      "indices" : [ 130, 139 ]
    }, {
      "text" : "tefl",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/lJfny3kWeJ",
      "expanded_url" : "http:\/\/goo.gl\/99fcZ",
      "display_url" : "goo.gl\/99fcZ"
    } ]
  },
  "geo" : { },
  "id_str" : "332416494191378432",
  "text" : "RT @AlexSWalsh: RT @tesolwar: The CLT Hyperbola - a visual guide to CLT principles http:\/\/t.co\/lJfny3kWeJ #ELTchat #tesol #edchat #KELTchat\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bill Rago",
        "screen_name" : "tesolwar",
        "indices" : [ 3, 12 ],
        "id_str" : "234781682",
        "id" : 234781682
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELTchat",
        "indices" : [ 90, 98 ]
      }, {
        "text" : "tesol",
        "indices" : [ 99, 105 ]
      }, {
        "text" : "edchat",
        "indices" : [ 106, 113 ]
      }, {
        "text" : "KELTchat",
        "indices" : [ 114, 123 ]
      }, {
        "text" : "tefl",
        "indices" : [ 124, 129 ]
      } ],
      "urls" : [ {
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/lJfny3kWeJ",
        "expanded_url" : "http:\/\/goo.gl\/99fcZ",
        "display_url" : "goo.gl\/99fcZ"
      } ]
    },
    "geo" : { },
    "id_str" : "332391643397361664",
    "text" : "RT @tesolwar: The CLT Hyperbola - a visual guide to CLT principles http:\/\/t.co\/lJfny3kWeJ #ELTchat #tesol #edchat #KELTchat #tefl",
    "id" : 332391643397361664,
    "created_at" : "2013-05-09 07:08:37 +0000",
    "user" : {
      "name" : "Alex Walsh",
      "screen_name" : "AlexSRWalsh",
      "protected" : false,
      "id_str" : "228747458",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738934802355617793\/veV8228l_normal.jpg",
      "id" : 228747458,
      "verified" : false
    }
  },
  "id" : 332416494191378432,
  "created_at" : "2013-05-09 08:47:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Taylor",
      "screen_name" : "theteacherjames",
      "indices" : [ 0, 16 ],
      "id_str" : "71746265",
      "id" : 71746265
    }, {
      "name" : "chadsansing",
      "screen_name" : "chadsansing",
      "indices" : [ 72, 84 ],
      "id_str" : "76810409",
      "id" : 76810409
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "teachtheweb",
      "indices" : [ 56, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/FlX5pqxdRE",
      "expanded_url" : "https:\/\/thimble.webmaker.org\/p\/l70c\/",
      "display_url" : "thimble.webmaker.org\/p\/l70c\/"
    } ]
  },
  "in_reply_to_status_id_str" : "332195507168481280",
  "geo" : { },
  "id_str" : "332279781997543424",
  "in_reply_to_user_id" : 71746265,
  "text" : "@theteacherjames thx inspired to do a blackout poem for #teachtheweb of @chadsansing text https:\/\/t.co\/FlX5pqxdRE",
  "id" : 332279781997543424,
  "in_reply_to_status_id" : 332195507168481280,
  "created_at" : "2013-05-08 23:44:08 +0000",
  "in_reply_to_screen_name" : "theteacherjames",
  "in_reply_to_user_id_str" : "71746265",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    }, {
      "name" : "\u0414\u0438\u0430\u043D\u043A\u0430 \u0428\u043A\u0443\u0440\u0441\u043A\u0430\u044F",
      "screen_name" : "TheSecretDoS",
      "indices" : [ 17, 30 ],
      "id_str" : "440292980",
      "id" : 440292980
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "332062178536472577",
  "geo" : { },
  "id_str" : "332123415236472832",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin @TheSecretDoS put them into aTwitter list? lists are great!",
  "id" : 332123415236472832,
  "in_reply_to_status_id" : 332062178536472577,
  "created_at" : "2013-05-08 13:22:47 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 3, 11 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/gJhWsWiZYs",
      "expanded_url" : "http:\/\/fourc.ca\/toronto1\/",
      "display_url" : "fourc.ca\/toronto1\/"
    }, {
      "indices" : [ 121, 140 ],
      "url" : "http:\/\/t.co\/zyP6JhfjVL",
      "expanded_url" : "http:\/\/fourc.ca\/toronto2\/",
      "display_url" : "fourc.ca\/toronto2\/"
    } ]
  },
  "geo" : { },
  "id_str" : "332121734629175299",
  "text" : "RT @seburnt: Two posts on student writing assignments - Toronto in May, post (1) http:\/\/t.co\/gJhWsWiZYs   &amp; post (2) http:\/\/t.co\/zyP6Jh\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/gJhWsWiZYs",
        "expanded_url" : "http:\/\/fourc.ca\/toronto1\/",
        "display_url" : "fourc.ca\/toronto1\/"
      }, {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/zyP6JhfjVL",
        "expanded_url" : "http:\/\/fourc.ca\/toronto2\/",
        "display_url" : "fourc.ca\/toronto2\/"
      } ]
    },
    "geo" : { },
    "id_str" : "332108547779354624",
    "text" : "Two posts on student writing assignments - Toronto in May, post (1) http:\/\/t.co\/gJhWsWiZYs   &amp; post (2) http:\/\/t.co\/zyP6JhfjVL",
    "id" : 332108547779354624,
    "created_at" : "2013-05-08 12:23:42 +0000",
    "user" : {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "protected" : false,
      "id_str" : "20650366",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/743248377563971584\/9d9xlHlz_normal.jpg",
      "id" : 20650366,
      "verified" : false
    }
  },
  "id" : 332121734629175299,
  "created_at" : "2013-05-08 13:16:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "331793116493406208",
  "geo" : { },
  "id_str" : "331802215746523137",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan yeah share mine dropin spot! sure we can cook up a double act on the day :)",
  "id" : 331802215746523137,
  "in_reply_to_status_id" : 331793116493406208,
  "created_at" : "2013-05-07 16:06:27 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian H\u00F6ferle",
      "screen_name" : "Hoeferle",
      "indices" : [ 15, 24 ],
      "id_str" : "23107822",
      "id" : 23107822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331802031075516417",
  "text" : "@MattHalsdorff @Hoeferle had a qk look looks very nice,cheers",
  "id" : 331802031075516417,
  "created_at" : "2013-05-07 16:05:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "EDUKWEST",
      "screen_name" : "edukwest",
      "indices" : [ 12, 21 ],
      "id_str" : "63241187",
      "id" : 63241187
    }, {
      "name" : "BenjaminStewart, PhD",
      "screen_name" : "bnleez",
      "indices" : [ 22, 29 ],
      "id_str" : "14634055",
      "id" : 14634055
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lexconf13",
      "indices" : [ 87, 97 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "331694162481119233",
  "geo" : { },
  "id_str" : "331781056892112896",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan @edukwest @bnleez yr welcome, just noticed gonna miss yr talk once more at #lexconf13! clashing wrkshps :\/",
  "id" : 331781056892112896,
  "in_reply_to_status_id" : 331694162481119233,
  "created_at" : "2013-05-07 14:42:22 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331771101287944194",
  "text" : "@MattHalsdorff yr welcome, yes and one on thursday as well :)",
  "id" : 331771101287944194,
  "created_at" : "2013-05-07 14:02:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    }, {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 13, 29 ],
      "id_str" : "394053348",
      "id" : 394053348
    }, {
      "name" : "\uBCA0\uB9AC\uAD7F",
      "screen_name" : "ESLBarry",
      "indices" : [ 30, 39 ],
      "id_str" : "630249484",
      "id" : 630249484
    }, {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 45, 56 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/6OIA0hlYlL",
      "expanded_url" : "http:\/\/hughdellar.wordpress.com\/2013\/04\/21\/conecting-the-classroom-to-the-world-outside\/",
      "display_url" : "hughdellar.wordpress.com\/2013\/04\/21\/con\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "331697541689262082",
  "geo" : { },
  "id_str" : "331704968811790336",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler @michaelegriffin @ESLBarry &gt; @hughdellar had some int things to say on this if u haven't read it http:\/\/t.co\/6OIA0hlYlL",
  "id" : 331704968811790336,
  "in_reply_to_status_id" : 331697541689262082,
  "created_at" : "2013-05-07 09:40:02 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 75, 91 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/m5vUHz5lur",
      "expanded_url" : "http:\/\/wp.me\/p3sNrs-25",
      "display_url" : "wp.me\/p3sNrs-25"
    } ]
  },
  "geo" : { },
  "id_str" : "331685993977638912",
  "text" : "Evernote Comparisons | A Business English Jolt  http:\/\/t.co\/m5vUHz5lur via @wordpressdotcom",
  "id" : 331685993977638912,
  "created_at" : "2013-05-07 08:24:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/ZCsrxdXtFQ",
      "expanded_url" : "http:\/\/wp.me\/p33cOf-37",
      "display_url" : "wp.me\/p33cOf-37"
    } ]
  },
  "geo" : { },
  "id_str" : "331685203808485376",
  "text" : "Book Review: \"Communication for International Business\" http:\/\/t.co\/ZCsrxdXtFQ via @MattHalsdorff",
  "id" : 331685203808485376,
  "created_at" : "2013-05-07 08:21:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol Read",
      "screen_name" : "carolread",
      "indices" : [ 0, 10 ],
      "id_str" : "98188554",
      "id" : 98188554
    }, {
      "name" : "Ela Wassell",
      "screen_name" : "elawassell",
      "indices" : [ 11, 22 ],
      "id_str" : "51157050",
      "id" : 51157050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/jTVnHuJoad",
      "expanded_url" : "http:\/\/www.genderremixer.com\/lego\/",
      "display_url" : "genderremixer.com\/lego\/"
    } ]
  },
  "in_reply_to_status_id_str" : "331654770131623936",
  "geo" : { },
  "id_str" : "331677686277754880",
  "in_reply_to_user_id" : 98188554,
  "text" : "@carolread @elawassell this gender lego remixer is pretty neat to raise awareness http:\/\/t.co\/jTVnHuJoad",
  "id" : 331677686277754880,
  "in_reply_to_status_id" : 331654770131623936,
  "created_at" : "2013-05-07 07:51:37 +0000",
  "in_reply_to_screen_name" : "carolread",
  "in_reply_to_user_id_str" : "98188554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 84, 92 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "331499942843674624",
  "geo" : { },
  "id_str" : "331501210265874433",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt was lurking at earlier chat :), thx tgh there were only 2 other entries :\/ #eapchat",
  "id" : 331501210265874433,
  "in_reply_to_status_id" : 331499942843674624,
  "created_at" : "2013-05-06 20:10:22 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 9, 17 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331499067408543744",
  "text" : "thx all  #eapchat",
  "id" : 331499067408543744,
  "created_at" : "2013-05-06 20:01:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 116, 124 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "331493792794415104",
  "geo" : { },
  "id_str" : "331494917685772289",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt teach one course on report writing and aim is to generate writing continuously which is q diff to achieve! #eapchat",
  "id" : 331494917685772289,
  "in_reply_to_status_id" : 331493792794415104,
  "created_at" : "2013-05-06 19:45:21 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 87, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/P6zMEcriQi",
      "expanded_url" : "https:\/\/whatslanguagedoinghere.wordpress.com\/",
      "display_url" : "whatslanguagedoinghere.wordpress.com"
    } ]
  },
  "geo" : { },
  "id_str" : "331494496409903104",
  "text" : "more details of genre approach to history writing on this blog https:\/\/t.co\/P6zMEcriQi #eapchat",
  "id" : 331494496409903104,
  "created_at" : "2013-05-06 19:43:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 107, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/JNXeb7Q82G",
      "expanded_url" : "http:\/\/bit.ly\/13k0HVX",
      "display_url" : "bit.ly\/13k0HVX"
    } ]
  },
  "geo" : { },
  "id_str" : "331493120560754688",
  "text" : "this article offers tantalising glimpse of using func ling to teach history writing http:\/\/t.co\/JNXeb7Q82G #eapchat",
  "id" : 331493120560754688,
  "created_at" : "2013-05-06 19:38:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valentina Morgana",
      "screen_name" : "vmorgana",
      "indices" : [ 0, 9 ],
      "id_str" : "62479177",
      "id" : 62479177
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "331398674808729601",
  "geo" : { },
  "id_str" : "331416729223839744",
  "in_reply_to_user_id" : 62479177,
  "text" : "@vmorgana many thanks for share Valentina, wishing u a good week :)",
  "id" : 331416729223839744,
  "in_reply_to_status_id" : 331398674808729601,
  "created_at" : "2013-05-06 14:34:40 +0000",
  "in_reply_to_screen_name" : "vmorgana",
  "in_reply_to_user_id_str" : "62479177",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Randolph",
      "screen_name" : "TomTesol",
      "indices" : [ 0, 9 ],
      "id_str" : "1039673456",
      "id" : 1039673456
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "331414571870978048",
  "geo" : { },
  "id_str" : "331416581001342976",
  "in_reply_to_user_id" : 1039673456,
  "text" : "@TomTesol awesome post is awesome; thanks for the Bill Rago hook up",
  "id" : 331416581001342976,
  "in_reply_to_status_id" : 331414571870978048,
  "created_at" : "2013-05-06 14:34:04 +0000",
  "in_reply_to_screen_name" : "TomTesol",
  "in_reply_to_user_id_str" : "1039673456",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Timothy Tate",
      "screen_name" : "Timothy_Tate",
      "indices" : [ 0, 13 ],
      "id_str" : "1084531170",
      "id" : 1084531170
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "331361230415618048",
  "geo" : { },
  "id_str" : "331386358344073216",
  "in_reply_to_user_id" : 1084531170,
  "text" : "@Timothy_Tate it did work on a pop song but the measure\/bar feature seemed to be out a bit",
  "id" : 331386358344073216,
  "in_reply_to_status_id" : 331361230415618048,
  "created_at" : "2013-05-06 12:33:59 +0000",
  "in_reply_to_screen_name" : "Timothy_Tate",
  "in_reply_to_user_id_str" : "1084531170",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331385016384888832",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler nice one for RTing Anne, enjoy the day\/night",
  "id" : 331385016384888832,
  "created_at" : "2013-05-06 12:28:39 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Randolph",
      "screen_name" : "TomTesol",
      "indices" : [ 3, 12 ],
      "id_str" : "1039673456",
      "id" : 1039673456
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 107, 115 ]
    }, {
      "text" : "keltchat",
      "indices" : [ 116, 125 ]
    }, {
      "text" : "auselt",
      "indices" : [ 126, 133 ]
    }, {
      "text" : "efl",
      "indices" : [ 134, 138 ]
    }, {
      "text" : "tesol",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/e1Loeg3Ehu",
      "expanded_url" : "http:\/\/wp.me\/p3bfrS-mF",
      "display_url" : "wp.me\/p3bfrS-mF"
    } ]
  },
  "geo" : { },
  "id_str" : "331382445431730176",
  "text" : "RT @TomTesol: Update: VIDEOS ADDED Pronunciation: 11 quick multi-sensory techniques http:\/\/t.co\/e1Loeg3Ehu #eltchat #keltchat #auselt #efl \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "eltchat",
        "indices" : [ 93, 101 ]
      }, {
        "text" : "keltchat",
        "indices" : [ 102, 111 ]
      }, {
        "text" : "auselt",
        "indices" : [ 112, 119 ]
      }, {
        "text" : "efl",
        "indices" : [ 120, 124 ]
      }, {
        "text" : "tesol",
        "indices" : [ 125, 131 ]
      } ],
      "urls" : [ {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/e1Loeg3Ehu",
        "expanded_url" : "http:\/\/wp.me\/p3bfrS-mF",
        "display_url" : "wp.me\/p3bfrS-mF"
      } ]
    },
    "geo" : { },
    "id_str" : "331377734544658432",
    "text" : "Update: VIDEOS ADDED Pronunciation: 11 quick multi-sensory techniques http:\/\/t.co\/e1Loeg3Ehu #eltchat #keltchat #auselt #efl #tesol",
    "id" : 331377734544658432,
    "created_at" : "2013-05-06 11:59:43 +0000",
    "user" : {
      "name" : "Tom Randolph",
      "screen_name" : "TomTesol",
      "protected" : false,
      "id_str" : "1039673456",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3032150495\/9652e9187ec1987380345c59bfce97b9_normal.jpeg",
      "id" : 1039673456,
      "verified" : false
    }
  },
  "id" : 331382445431730176,
  "created_at" : "2013-05-06 12:18:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 96, 104 ]
    }, {
      "text" : "corpuslinguistics",
      "indices" : [ 105, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/5TL4CNWLUT",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-AO",
      "display_url" : "wp.me\/pgHyE-AO"
    } ]
  },
  "geo" : { },
  "id_str" : "331377567309385728",
  "text" : "new post \nWhat to teach from corpora output \u2013 frequency and transparency http:\/\/t.co\/5TL4CNWLUT #eltchat #corpuslinguistics",
  "id" : 331377567309385728,
  "created_at" : "2013-05-06 11:59:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/Invwy1H6j3",
      "expanded_url" : "http:\/\/leoxicon.blogspot.com\/2013\/05\/context-or-co-text.html?spref=tw",
      "display_url" : "leoxicon.blogspot.com\/2013\/05\/contex\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "331348991696596992",
  "text" : "Leoxicon: In context or with co-text? http:\/\/t.co\/Invwy1H6j3",
  "id" : 331348991696596992,
  "created_at" : "2013-05-06 10:05:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 46, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/YwkNlHDwoT",
      "expanded_url" : "http:\/\/www.academia.edu\/1297347\/A_Phrasal_Expressions_List_The_PHRASE_List_-_Martinez_R._and_Schmitt_N._2012_._Applied_Linguistics_33_3_pp._299-320",
      "display_url" : "academia.edu\/1297347\/A_Phra\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "331347282073112577",
  "text" : "Top 505 Phrase List - http:\/\/t.co\/YwkNlHDwoT  #eltchat",
  "id" : 331347282073112577,
  "created_at" : "2013-05-06 09:58:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Timothy Tate",
      "screen_name" : "Timothy_Tate",
      "indices" : [ 36, 49 ],
      "id_str" : "1084531170",
      "id" : 1084531170
    }, {
      "name" : "4TUNE Teller App",
      "screen_name" : "4tunetellernet",
      "indices" : [ 50, 65 ],
      "id_str" : "467634146",
      "id" : 467634146
    }, {
      "name" : "P\u00E9rez-Paredes",
      "screen_name" : "perezparedes",
      "indices" : [ 69, 82 ],
      "id_str" : "28528850",
      "id" : 28528850
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/LMVOasYgNN",
      "expanded_url" : "http:\/\/chordify.net",
      "display_url" : "chordify.net"
    } ]
  },
  "geo" : { },
  "id_str" : "331126510004080641",
  "text" : "very cool http:\/\/t.co\/LMVOasYgNN cc @Timothy_Tate @4tunetellernet HT @perezparedes",
  "id" : 331126510004080641,
  "created_at" : "2013-05-05 19:21:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 64, 80 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/ywXTk90HFa",
      "expanded_url" : "http:\/\/wp.me\/p3augf-5s",
      "display_url" : "wp.me\/p3augf-5s"
    } ]
  },
  "geo" : { },
  "id_str" : "331006691103621120",
  "text" : "Creativity and color in academic ELF http:\/\/t.co\/ywXTk90HFa via @wordpressdotcom",
  "id" : 331006691103621120,
  "created_at" : "2013-05-05 11:25:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 42, 58 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 59, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/s0fBP8ZMN3",
      "expanded_url" : "http:\/\/wp.me\/p3hsrD-9l",
      "display_url" : "wp.me\/p3hsrD-9l"
    } ]
  },
  "geo" : { },
  "id_str" : "330481526812852224",
  "text" : "Play the game? http:\/\/t.co\/s0fBP8ZMN3 via @wordpressdotcom #eltchat",
  "id" : 330481526812852224,
  "created_at" : "2013-05-04 00:38:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "330441216078516224",
  "geo" : { },
  "id_str" : "330446023552032768",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson did read that this week and is worth reading again :)",
  "id" : 330446023552032768,
  "in_reply_to_status_id" : 330441216078516224,
  "created_at" : "2013-05-03 22:17:26 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chadsansing",
      "screen_name" : "chadsansing",
      "indices" : [ 3, 15 ],
      "id_str" : "76810409",
      "id" : 76810409
    }, {
      "name" : "Chuck Leddy",
      "screen_name" : "ChuckLeddy",
      "indices" : [ 20, 31 ],
      "id_str" : "98217183",
      "id" : 98217183
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/bskvnWBdB3",
      "expanded_url" : "http:\/\/news.harvard.edu\/gazette\/story\/2013\/05\/subversive-education\/",
      "display_url" : "news.harvard.edu\/gazette\/story\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "330437497962242049",
  "text" : "RT @chadsansing: MT @ChuckLeddy:...Noam Chomsky discusses the \"subversive\" legacy of Paulo Freire's \"Pedagogy of the Oppressed\" http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Chuck Leddy",
        "screen_name" : "ChuckLeddy",
        "indices" : [ 3, 14 ],
        "id_str" : "98217183",
        "id" : 98217183
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/bskvnWBdB3",
        "expanded_url" : "http:\/\/news.harvard.edu\/gazette\/story\/2013\/05\/subversive-education\/",
        "display_url" : "news.harvard.edu\/gazette\/story\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "330247120684720128",
    "text" : "MT @ChuckLeddy:...Noam Chomsky discusses the \"subversive\" legacy of Paulo Freire's \"Pedagogy of the Oppressed\" http:\/\/t.co\/bskvnWBdB3",
    "id" : 330247120684720128,
    "created_at" : "2013-05-03 09:07:03 +0000",
    "user" : {
      "name" : "chadsansing",
      "screen_name" : "chadsansing",
      "protected" : false,
      "id_str" : "76810409",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712740640111652869\/NvEwLRy__normal.jpg",
      "id" : 76810409,
      "verified" : false
    }
  },
  "id" : 330437497962242049,
  "created_at" : "2013-05-03 21:43:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "teachtheweb",
      "indices" : [ 88, 100 ]
    }, {
      "text" : "englishfortheweb",
      "indices" : [ 101, 118 ]
    }, {
      "text" : "multimediaenglish",
      "indices" : [ 119, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/D2g2zdROyW",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-Au",
      "display_url" : "wp.me\/pgHyE-Au"
    } ]
  },
  "geo" : { },
  "id_str" : "330409363871252480",
  "text" : "New post - Using NoScript to raise awareness of web page scripts http:\/\/t.co\/D2g2zdROyW #teachtheweb #englishfortheweb #multimediaenglish",
  "id" : 330409363871252480,
  "created_at" : "2013-05-03 19:51:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheConsultantsE",
      "screen_name" : "TheConsultantsE",
      "indices" : [ 0, 16 ],
      "id_str" : "13435662",
      "id" : 13435662
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "329935766341971969",
  "geo" : { },
  "id_str" : "329962077772992514",
  "in_reply_to_user_id" : 13435662,
  "text" : "@TheConsultantsE sweet :)",
  "id" : 329962077772992514,
  "in_reply_to_status_id" : 329935766341971969,
  "created_at" : "2013-05-02 14:14:24 +0000",
  "in_reply_to_screen_name" : "TheConsultantsE",
  "in_reply_to_user_id_str" : "13435662",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Levine",
      "screen_name" : "cogdog",
      "indices" : [ 3, 10 ],
      "id_str" : "740343",
      "id" : 740343
    }, {
      "name" : "Zach Wise",
      "screen_name" : "zlwise",
      "indices" : [ 43, 50 ],
      "id_str" : "930581",
      "id" : 930581
    }, {
      "name" : "miranda mulligan",
      "screen_name" : "jmm",
      "indices" : [ 51, 55 ],
      "id_str" : "19035047",
      "id" : 19035047
    }, {
      "name" : "Mike Davidson",
      "screen_name" : "mikeindustries",
      "indices" : [ 56, 71 ],
      "id_str" : "74523",
      "id" : 74523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 125, 140 ],
      "url" : "http:\/\/t.co\/PkOKQLqSiF",
      "expanded_url" : "http:\/\/www.vinetune.com",
      "display_url" : "vinetune.com"
    } ]
  },
  "geo" : { },
  "id_str" : "329958021348327425",
  "text" : "RT @cogdog: Something interesting vined MT @zlwise @jmm @mikeindustries VineTune dynamically created video based on hashtags http:\/\/t.co\/Pk\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Zach Wise",
        "screen_name" : "zlwise",
        "indices" : [ 31, 38 ],
        "id_str" : "930581",
        "id" : 930581
      }, {
        "name" : "miranda mulligan",
        "screen_name" : "jmm",
        "indices" : [ 39, 43 ],
        "id_str" : "19035047",
        "id" : 19035047
      }, {
        "name" : "Mike Davidson",
        "screen_name" : "mikeindustries",
        "indices" : [ 44, 59 ],
        "id_str" : "74523",
        "id" : 74523
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/PkOKQLqSiF",
        "expanded_url" : "http:\/\/www.vinetune.com",
        "display_url" : "vinetune.com"
      } ]
    },
    "geo" : { },
    "id_str" : "329700638470578177",
    "text" : "Something interesting vined MT @zlwise @jmm @mikeindustries VineTune dynamically created video based on hashtags http:\/\/t.co\/PkOKQLqSiF",
    "id" : 329700638470578177,
    "created_at" : "2013-05-01 20:55:32 +0000",
    "user" : {
      "name" : "Alan Levine",
      "screen_name" : "cogdog",
      "protected" : false,
      "id_str" : "740343",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/740063389527859201\/BN9buLB9_normal.jpg",
      "id" : 740343,
      "verified" : false
    }
  },
  "id" : 329958021348327425,
  "created_at" : "2013-05-02 13:58:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
} ]