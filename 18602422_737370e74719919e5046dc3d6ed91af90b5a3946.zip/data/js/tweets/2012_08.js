Grailbird.data.tweets_2012_08 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boing Boing",
      "screen_name" : "BoingBoing",
      "indices" : [ 36, 47 ],
      "id_str" : "5971922",
      "id" : 5971922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 31 ],
      "url" : "http:\/\/t.co\/a9F0p0RL",
      "expanded_url" : "http:\/\/boingboing.net\/2012\/08\/03\/babelfish-adafruits-arduino.html",
      "display_url" : "boingboing.net\/2012\/08\/03\/bab\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "232100783997456384",
  "text" : "Babel Fish http:\/\/t.co\/a9F0p0RL via @boingboing &lt;-hobby electronics and language learning project very nice indeed!",
  "id" : 232100783997456384,
  "created_at" : "2012-08-05 13:08:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
} ]