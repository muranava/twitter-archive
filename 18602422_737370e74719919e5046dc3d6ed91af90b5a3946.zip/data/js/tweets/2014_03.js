Grailbird.data.tweets_2014_03 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jo Sayers",
      "screen_name" : "jo_sayers",
      "indices" : [ 0, 10 ],
      "id_str" : "87176766",
      "id" : 87176766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "450724217655689216",
  "geo" : { },
  "id_str" : "450729834399166465",
  "in_reply_to_user_id" : 87176766,
  "text" : "@jo_sayers there's a joke to be had here am sure, hmm, a teachers train to train, i'll get me coat",
  "id" : 450729834399166465,
  "in_reply_to_status_id" : 450724217655689216,
  "created_at" : "2014-03-31 20:22:21 +0000",
  "in_reply_to_screen_name" : "jo_sayers",
  "in_reply_to_user_id_str" : "87176766",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wiktorkompe",
      "screen_name" : "wiktor_k",
      "indices" : [ 3, 12 ],
      "id_str" : "733704413383168000",
      "id" : 733704413383168000
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/P9A1w3HSOQ",
      "expanded_url" : "http:\/\/buff.ly\/1pE7tPa",
      "display_url" : "buff.ly\/1pE7tPa"
    } ]
  },
  "geo" : { },
  "id_str" : "450726811002220544",
  "text" : "RT @Wiktor_K: US Department of State to Offer Massive Online Course for English Language ... http:\/\/t.co\/P9A1w3HSOQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/P9A1w3HSOQ",
        "expanded_url" : "http:\/\/buff.ly\/1pE7tPa",
        "display_url" : "buff.ly\/1pE7tPa"
      } ]
    },
    "geo" : { },
    "id_str" : "450726231496208384",
    "text" : "US Department of State to Offer Massive Online Course for English Language ... http:\/\/t.co\/P9A1w3HSOQ",
    "id" : 450726231496208384,
    "created_at" : "2014-03-31 20:08:02 +0000",
    "user" : {
      "name" : "BRAVE Learning",
      "screen_name" : "BRAVE_Learning",
      "protected" : false,
      "id_str" : "222498082",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714724460461473792\/_xHUkSmB_normal.jpg",
      "id" : 222498082,
      "verified" : false
    }
  },
  "id" : 450726811002220544,
  "created_at" : "2014-03-31 20:10:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Macmillan Dictionary",
      "screen_name" : "MacDictionary",
      "indices" : [ 76, 90 ],
      "id_str" : "23783700",
      "id" : 23783700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/nBW1W4wGJ0",
      "expanded_url" : "http:\/\/www.macmillandictionaryblog.com\/as-versus-so-in-negative-comparisons",
      "display_url" : "macmillandictionaryblog.com\/as-versus-so-i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "450377421028474880",
  "text" : "As versus so in negative comparisons | Macmillan http:\/\/t.co\/nBW1W4wGJ0 via @MacDictionary",
  "id" : 450377421028474880,
  "created_at" : "2014-03-30 21:01:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "markwarschauer",
      "screen_name" : "markwarschauer",
      "indices" : [ 3, 18 ],
      "id_str" : "17316060",
      "id" : 17316060
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/nWnfebM3ie",
      "expanded_url" : "http:\/\/www.psychologicalscience.org\/index.php\/news\/were-only-human\/ink-on-paper-some-notes-on-note-taking.html",
      "display_url" : "psychologicalscience.org\/index.php\/news\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "450310657976836096",
  "text" : "RT @markwarschauer: Is the pen mightier than the keyboard? http:\/\/t.co\/nWnfebM3ie",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 61 ],
        "url" : "http:\/\/t.co\/nWnfebM3ie",
        "expanded_url" : "http:\/\/www.psychologicalscience.org\/index.php\/news\/were-only-human\/ink-on-paper-some-notes-on-note-taking.html",
        "display_url" : "psychologicalscience.org\/index.php\/news\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "450303380347293696",
    "text" : "Is the pen mightier than the keyboard? http:\/\/t.co\/nWnfebM3ie",
    "id" : 450303380347293696,
    "created_at" : "2014-03-30 16:07:46 +0000",
    "user" : {
      "name" : "markwarschauer",
      "screen_name" : "markwarschauer",
      "protected" : false,
      "id_str" : "17316060",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535141210432622592\/ZXqkNrhW_normal.jpeg",
      "id" : 17316060,
      "verified" : false
    }
  },
  "id" : 450310657976836096,
  "created_at" : "2014-03-30 16:36:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Akira Murakami",
      "screen_name" : "mrkm_a",
      "indices" : [ 3, 10 ],
      "id_str" : "116922669",
      "id" : 116922669
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/rLVIzTAF3d",
      "expanded_url" : "http:\/\/scholar.google.com\/scholar_url?hl=ja&q=http:\/\/www.macrothink.org\/journal\/index.php\/ijele\/article\/download\/5348\/4290&sa=X&scisig=AAGBfm0K3lQ9zWZh8YgxtEmSk15P4zi0jA&oi=scholaralrt",
      "display_url" : "scholar.google.com\/scholar_url?hl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "450296997363585024",
  "text" : "RT @mrkm_a: Nicholson (2014). An Analysis of the Task-Based Syllabus\nhttp:\/\/t.co\/rLVIzTAF3d",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/rLVIzTAF3d",
        "expanded_url" : "http:\/\/scholar.google.com\/scholar_url?hl=ja&q=http:\/\/www.macrothink.org\/journal\/index.php\/ijele\/article\/download\/5348\/4290&sa=X&scisig=AAGBfm0K3lQ9zWZh8YgxtEmSk15P4zi0jA&oi=scholaralrt",
        "display_url" : "scholar.google.com\/scholar_url?hl\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "450085225121734657",
    "text" : "Nicholson (2014). An Analysis of the Task-Based Syllabus\nhttp:\/\/t.co\/rLVIzTAF3d",
    "id" : 450085225121734657,
    "created_at" : "2014-03-30 01:40:54 +0000",
    "user" : {
      "name" : "Akira Murakami",
      "screen_name" : "mrkm_a",
      "protected" : false,
      "id_str" : "116922669",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/491819353784860672\/LqdQ1Sye_normal.jpeg",
      "id" : 116922669,
      "verified" : false
    }
  },
  "id" : 450296997363585024,
  "created_at" : "2014-03-30 15:42:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pando",
      "screen_name" : "PandoDaily",
      "indices" : [ 110, 121 ],
      "id_str" : "419710142",
      "id" : 419710142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/TxZy8WLJQA",
      "expanded_url" : "http:\/\/pando.com\/2014\/03\/27\/how-steve-jobs-forced-google-to-cancel-its-plan-to-open-a-paris-office\/",
      "display_url" : "pando.com\/2014\/03\/27\/how\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "450262305293357056",
  "text" : "Google begged Steve Jobs for permission to hire engineers for its new Paris office http:\/\/t.co\/TxZy8WLJQA via @pandodaily",
  "id" : 450262305293357056,
  "created_at" : "2014-03-30 13:24:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Edmond",
      "screen_name" : "jgedmond",
      "indices" : [ 3, 12 ],
      "id_str" : "2259823108",
      "id" : 2259823108
    }, {
      "name" : "Stack Exchange",
      "screen_name" : "StackExchange",
      "indices" : [ 87, 101 ],
      "id_str" : "179698068",
      "id" : 179698068
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/N3iaCzL80z",
      "expanded_url" : "http:\/\/ell.stackexchange.com\/",
      "display_url" : "ell.stackexchange.com"
    }, {
      "indices" : [ 125, 140 ],
      "url" : "http:\/\/t.co\/xfBsxgowBN",
      "expanded_url" : "http:\/\/ell.stackexchange.com\/",
      "display_url" : "ell.stackexchange.com"
    } ]
  },
  "geo" : { },
  "id_str" : "450232097903767552",
  "text" : "RT @jgedmond: Check out the new English Language Learners Stack Exchange QnA site from @StackExchange http:\/\/t.co\/N3iaCzL80z http:\/\/t.co\/xf\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stack Exchange",
        "screen_name" : "StackExchange",
        "indices" : [ 73, 87 ],
        "id_str" : "179698068",
        "id" : 179698068
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/N3iaCzL80z",
        "expanded_url" : "http:\/\/ell.stackexchange.com\/",
        "display_url" : "ell.stackexchange.com"
      }, {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/xfBsxgowBN",
        "expanded_url" : "http:\/\/ell.stackexchange.com\/",
        "display_url" : "ell.stackexchange.com"
      } ]
    },
    "geo" : { },
    "id_str" : "450227817804886016",
    "text" : "Check out the new English Language Learners Stack Exchange QnA site from @StackExchange http:\/\/t.co\/N3iaCzL80z http:\/\/t.co\/xfBsxgowBN",
    "id" : 450227817804886016,
    "created_at" : "2014-03-30 11:07:31 +0000",
    "user" : {
      "name" : "John Edmond",
      "screen_name" : "jgedmond",
      "protected" : false,
      "id_str" : "2259823108",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/421165121289740289\/24RZhRhs_normal.jpeg",
      "id" : 2259823108,
      "verified" : false
    }
  },
  "id" : 450232097903767552,
  "created_at" : "2014-03-30 11:24:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/MXMrIWuYt5",
      "expanded_url" : "http:\/\/juergenkurtz.wordpress.com\/2014\/03\/29\/theoretical-approaches-to-secondforeign-language-acquisition-andor-learning\/",
      "display_url" : "juergenkurtz.wordpress.com\/2014\/03\/29\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "449933293564473344",
  "text" : "@TESOLatRennert this is a good post on using concepts from other disciplines http:\/\/t.co\/MXMrIWuYt5",
  "id" : 449933293564473344,
  "created_at" : "2014-03-29 15:37:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449931982928371712",
  "text" : "@TESOLatRennert i c what u did there :)",
  "id" : 449931982928371712,
  "created_at" : "2014-03-29 15:31:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sophia Khan",
      "screen_name" : "SophiaKhan4",
      "indices" : [ 0, 12 ],
      "id_str" : "351390617",
      "id" : 351390617
    }, {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "indices" : [ 13, 26 ],
      "id_str" : "1685397408",
      "id" : 1685397408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/NM1rINujmp",
      "expanded_url" : "http:\/\/elfaproject.wordpress.com\/2014\/03\/28\/why-mixing-languages-isnt-so-bad-after-all\/",
      "display_url" : "elfaproject.wordpress.com\/2014\/03\/28\/why\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "449916521561595905",
  "geo" : { },
  "id_str" : "449921808482189312",
  "in_reply_to_user_id" : 351390617,
  "text" : "@SophiaKhan4 @harrisonmike evidence on ELF couples here germane http:\/\/t.co\/NM1rINujmp",
  "id" : 449921808482189312,
  "in_reply_to_status_id" : 449916521561595905,
  "created_at" : "2014-03-29 14:51:32 +0000",
  "in_reply_to_screen_name" : "SophiaKhan4",
  "in_reply_to_user_id_str" : "351390617",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449876487295225857",
  "geo" : { },
  "id_str" : "449877963795070976",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco should be able to join using that direct link to adobe?",
  "id" : 449877963795070976,
  "in_reply_to_status_id" : 449876487295225857,
  "created_at" : "2014-03-29 11:57:19 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/449872837696712705\/photo\/1",
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/lF6vpDybDr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bj5E9l2CcAAcB8L.png",
      "id_str" : "449872837705101312",
      "id" : 449872837705101312,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bj5E9l2CcAAcB8L.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 616,
        "resize" : "fit",
        "w" : 775
      }, {
        "h" : 477,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 616,
        "resize" : "fit",
        "w" : 775
      } ],
      "display_url" : "pic.twitter.com\/lF6vpDybDr"
    } ],
    "hashtags" : [ {
      "text" : "merlin",
      "indices" : [ 10, 17 ]
    }, {
      "text" : "CEFRwebcon",
      "indices" : [ 26, 37 ]
    }, {
      "text" : "corpusmooc",
      "indices" : [ 38, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449872837696712705",
  "text" : "data  for #merlin project #CEFRwebcon #corpusmooc http:\/\/t.co\/lF6vpDybDr",
  "id" : 449872837696712705,
  "created_at" : "2014-03-29 11:36:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 0, 11 ]
    }, {
      "text" : "CEFRwebcon",
      "indices" : [ 39, 50 ]
    }, {
      "text" : "merlin",
      "indices" : [ 90, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/ZN03ergfN4",
      "expanded_url" : "http:\/\/lancelot.adobeconnect.com\/B1",
      "display_url" : "lancelot.adobeconnect.com\/B1"
    } ]
  },
  "geo" : { },
  "id_str" : "449865998221713408",
  "text" : "#corpusmooc peeps may be interested in #CEFRwebcon web conference on mulitlingual corpora #merlin about to start http:\/\/t.co\/ZN03ergfN4",
  "id" : 449865998221713408,
  "created_at" : "2014-03-29 11:09:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Joseph Watson",
      "screen_name" : "PrisonPlanet",
      "indices" : [ 3, 16 ],
      "id_str" : "18643437",
      "id" : 18643437
    }, {
      "name" : "_nasdaf_",
      "screen_name" : "_nasdaf_",
      "indices" : [ 35, 44 ],
      "id_str" : "80743782",
      "id" : 80743782
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/PrisonPlanet\/status\/449697157621489664\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/cFn9PGnlRE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bj2lLp4IEAErUYZ.jpg",
      "id_str" : "449697157445324801",
      "id" : 449697157445324801,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bj2lLp4IEAErUYZ.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 677,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 384,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 907
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 907
      } ],
      "display_url" : "pic.twitter.com\/cFn9PGnlRE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449860982182277120",
  "text" : "RT @PrisonPlanet: Great graphic by @_nasdaf_  exposes the media cover-up of the Turkey false flag story. http:\/\/t.co\/cFn9PGnlRE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "_nasdaf_",
        "screen_name" : "_nasdaf_",
        "indices" : [ 17, 26 ],
        "id_str" : "80743782",
        "id" : 80743782
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/PrisonPlanet\/status\/449697157621489664\/photo\/1",
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/cFn9PGnlRE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bj2lLp4IEAErUYZ.jpg",
        "id_str" : "449697157445324801",
        "id" : 449697157445324801,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bj2lLp4IEAErUYZ.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 677,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 384,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 907
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 907
        } ],
        "display_url" : "pic.twitter.com\/cFn9PGnlRE"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "449697157621489664",
    "text" : "Great graphic by @_nasdaf_  exposes the media cover-up of the Turkey false flag story. http:\/\/t.co\/cFn9PGnlRE",
    "id" : 449697157621489664,
    "created_at" : "2014-03-28 23:58:52 +0000",
    "user" : {
      "name" : "Paul Joseph Watson",
      "screen_name" : "PrisonPlanet",
      "protected" : false,
      "id_str" : "18643437",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/756825397388533760\/yXYx6CNC_normal.jpg",
      "id" : 18643437,
      "verified" : true
    }
  },
  "id" : 449860982182277120,
  "created_at" : "2014-03-29 10:49:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 0, 11 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/GqaagkkA5s",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=nDjdJCbteKA#t=1107",
      "display_url" : "youtube.com\/watch?v=nDjdJC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "449850182772211712",
  "text" : "#corpusmooc chat video available from last night\/day https:\/\/t.co\/GqaagkkA5s",
  "id" : 449850182772211712,
  "created_at" : "2014-03-29 10:06:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 71, 87 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/uXmPMOV2Uy",
      "expanded_url" : "http:\/\/wp.me\/p3augf-dc",
      "display_url" : "wp.me\/p3augf-dc"
    } ]
  },
  "geo" : { },
  "id_str" : "449848616702578688",
  "text" : "Why mixing languages isn\u2019t so bad after all http:\/\/t.co\/uXmPMOV2Uy via @wordpressdotcom",
  "id" : 449848616702578688,
  "created_at" : "2014-03-29 10:00:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Aisha Brown",
      "screen_name" : "amyaishab",
      "indices" : [ 3, 13 ],
      "id_str" : "900029641",
      "id" : 900029641
    }, {
      "name" : "Nic Subtirelu",
      "screen_name" : "linguisticpulse",
      "indices" : [ 42, 58 ],
      "id_str" : "1400748798",
      "id" : 1400748798
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CorpusMOOC",
      "indices" : [ 15, 26 ]
    } ],
    "urls" : [ {
      "indices" : [ 124, 140 ],
      "url" : "http:\/\/t.co\/lrwM1lhozD",
      "expanded_url" : "http:\/\/bit.ly\/1i1YRzc",
      "display_url" : "bit.ly\/1i1YRzc"
    } ]
  },
  "geo" : { },
  "id_str" : "449840690160476160",
  "text" : "RT @amyaishab: #CorpusMOOC folk will like @linguisticpulse's blog posts. Journalists doing CL with Google led to this post: http:\/\/t.co\/lrw\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nic Subtirelu",
        "screen_name" : "linguisticpulse",
        "indices" : [ 27, 43 ],
        "id_str" : "1400748798",
        "id" : 1400748798
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CorpusMOOC",
        "indices" : [ 0, 11 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/lrwM1lhozD",
        "expanded_url" : "http:\/\/bit.ly\/1i1YRzc",
        "display_url" : "bit.ly\/1i1YRzc"
      } ]
    },
    "geo" : { },
    "id_str" : "449649707397443585",
    "text" : "#CorpusMOOC folk will like @linguisticpulse's blog posts. Journalists doing CL with Google led to this post: http:\/\/t.co\/lrwM1lhozD",
    "id" : 449649707397443585,
    "created_at" : "2014-03-28 20:50:18 +0000",
    "user" : {
      "name" : "Amy Aisha Brown",
      "screen_name" : "amyaishab",
      "protected" : false,
      "id_str" : "900029641",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/620604005799067648\/nD3nCCXK_normal.jpg",
      "id" : 900029641,
      "verified" : false
    }
  },
  "id" : 449840690160476160,
  "created_at" : "2014-03-29 09:29:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Aisha Brown",
      "screen_name" : "amyaishab",
      "indices" : [ 0, 10 ],
      "id_str" : "900029641",
      "id" : 900029641
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449663995059134464",
  "geo" : { },
  "id_str" : "449683525118468096",
  "in_reply_to_user_id" : 900029641,
  "text" : "@amyaishab many apologies amy!",
  "id" : 449683525118468096,
  "in_reply_to_status_id" : 449663995059134464,
  "created_at" : "2014-03-28 23:04:41 +0000",
  "in_reply_to_screen_name" : "amyaishab",
  "in_reply_to_user_id_str" : "900029641",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Douglas Carnall",
      "screen_name" : "JuliuzBeezer",
      "indices" : [ 0, 13 ],
      "id_str" : "25936824",
      "id" : 25936824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449654563281571840",
  "geo" : { },
  "id_str" : "449670296745046016",
  "in_reply_to_user_id" : 25936824,
  "text" : "@JuliuzBeezer oh no! Ak due to my noobiness with hoa! :( time was 2130cet",
  "id" : 449670296745046016,
  "in_reply_to_status_id" : 449654563281571840,
  "created_at" : "2014-03-28 22:12:07 +0000",
  "in_reply_to_screen_name" : "JuliuzBeezer",
  "in_reply_to_user_id_str" : "25936824",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Moravec",
      "screen_name" : "ProfessMoravec",
      "indices" : [ 0, 15 ],
      "id_str" : "369529173",
      "id" : 369529173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449638377147875328",
  "geo" : { },
  "id_str" : "449659660623433728",
  "in_reply_to_user_id" : 369529173,
  "text" : "@ProfessMoravec so great to meet u there! will try to put up recording when i can figure it out...",
  "id" : 449659660623433728,
  "in_reply_to_status_id" : 449638377147875328,
  "created_at" : "2014-03-28 21:29:52 +0000",
  "in_reply_to_screen_name" : "ProfessMoravec",
  "in_reply_to_user_id_str" : "369529173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jo Sayers",
      "screen_name" : "jo_sayers",
      "indices" : [ 0, 10 ],
      "id_str" : "87176766",
      "id" : 87176766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449523078692106240",
  "geo" : { },
  "id_str" : "449557822452555776",
  "in_reply_to_user_id" : 87176766,
  "text" : "@jo_sayers not of top off my head but if u search for sentiment analysis stuff cld find datasets they use e.g. amazon product reviews",
  "id" : 449557822452555776,
  "in_reply_to_status_id" : 449523078692106240,
  "created_at" : "2014-03-28 14:45:11 +0000",
  "in_reply_to_screen_name" : "jo_sayers",
  "in_reply_to_user_id_str" : "87176766",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iatefl",
      "indices" : [ 7, 14 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449303102563577856",
  "text" : "occupy #iatefl from alex case sound good :)",
  "id" : 449303102563577856,
  "created_at" : "2014-03-27 21:53:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Moravec",
      "screen_name" : "ProfessMoravec",
      "indices" : [ 3, 18 ],
      "id_str" : "369529173",
      "id" : 369529173
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 34, 45 ]
    }, {
      "text" : "moocinpublic",
      "indices" : [ 105, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/HTpprABNEo",
      "expanded_url" : "http:\/\/bit.ly\/1b2aLoU",
      "display_url" : "bit.ly\/1b2aLoU"
    } ]
  },
  "geo" : { },
  "id_str" : "449283125643055104",
  "text" : "RT @ProfessMoravec: final week of #corpusmooc blogged http:\/\/t.co\/HTpprABNEo I finished but 2 days late! #moocinpublic",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpusmooc",
        "indices" : [ 14, 25 ]
      }, {
        "text" : "moocinpublic",
        "indices" : [ 85, 98 ]
      } ],
      "urls" : [ {
        "indices" : [ 34, 56 ],
        "url" : "http:\/\/t.co\/HTpprABNEo",
        "expanded_url" : "http:\/\/bit.ly\/1b2aLoU",
        "display_url" : "bit.ly\/1b2aLoU"
      } ]
    },
    "geo" : { },
    "id_str" : "449251672687382528",
    "text" : "final week of #corpusmooc blogged http:\/\/t.co\/HTpprABNEo I finished but 2 days late! #moocinpublic",
    "id" : 449251672687382528,
    "created_at" : "2014-03-27 18:28:40 +0000",
    "user" : {
      "name" : "Michelle Moravec",
      "screen_name" : "ProfessMoravec",
      "protected" : false,
      "id_str" : "369529173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751214483113013248\/qxxQX7mg_normal.jpg",
      "id" : 369529173,
      "verified" : false
    }
  },
  "id" : 449283125643055104,
  "created_at" : "2014-03-27 20:33:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Graham",
      "screen_name" : "onalifeglug",
      "indices" : [ 3, 15 ],
      "id_str" : "19516039",
      "id" : 19516039
    }, {
      "name" : "Tony Benn Film",
      "screen_name" : "TonyBennFilm",
      "indices" : [ 98, 111 ],
      "id_str" : "1092555913",
      "id" : 1092555913
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/HhysFwoar4",
      "expanded_url" : "http:\/\/youtu.be\/oTOZM77CrMU",
      "display_url" : "youtu.be\/oTOZM77CrMU"
    } ]
  },
  "geo" : { },
  "id_str" : "449158334789455872",
  "text" : "RT @onalifeglug: Trailer for upcoming Tony Benn film - Will and Testament: http:\/\/t.co\/HhysFwoar4 @TonyBennFilm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tony Benn Film",
        "screen_name" : "TonyBennFilm",
        "indices" : [ 81, 94 ],
        "id_str" : "1092555913",
        "id" : 1092555913
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/HhysFwoar4",
        "expanded_url" : "http:\/\/youtu.be\/oTOZM77CrMU",
        "display_url" : "youtu.be\/oTOZM77CrMU"
      } ]
    },
    "geo" : { },
    "id_str" : "449156989525176320",
    "text" : "Trailer for upcoming Tony Benn film - Will and Testament: http:\/\/t.co\/HhysFwoar4 @TonyBennFilm",
    "id" : 449156989525176320,
    "created_at" : "2014-03-27 12:12:25 +0000",
    "user" : {
      "name" : "Graham",
      "screen_name" : "onalifeglug",
      "protected" : false,
      "id_str" : "19516039",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/586664577095622656\/NwBHdlk5_normal.jpg",
      "id" : 19516039,
      "verified" : false
    }
  },
  "id" : 449158334789455872,
  "created_at" : "2014-03-27 12:17:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449141329705324544",
  "geo" : { },
  "id_str" : "449144067642109952",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco great minds they say :)",
  "id" : 449144067642109952,
  "in_reply_to_status_id" : 449141329705324544,
  "created_at" : "2014-03-27 11:21:05 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maria Pia Montoro",
      "screen_name" : "WordLo",
      "indices" : [ 3, 10 ],
      "id_str" : "190569306",
      "id" : 190569306
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Terminology",
      "indices" : [ 38, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/2FAFuxB3PL",
      "expanded_url" : "http:\/\/recremisi.blogspot.com\/p\/online-terminology-tools.html",
      "display_url" : "recremisi.blogspot.com\/p\/online-termi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "449142289081065473",
  "text" : "RT @WordLo: I just updated the Online #Terminology Tools page on my blog, please let me know if I missed anything :) http:\/\/t.co\/2FAFuxB3PL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Terminology",
        "indices" : [ 26, 38 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/2FAFuxB3PL",
        "expanded_url" : "http:\/\/recremisi.blogspot.com\/p\/online-terminology-tools.html",
        "display_url" : "recremisi.blogspot.com\/p\/online-termi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "449118825208762368",
    "text" : "I just updated the Online #Terminology Tools page on my blog, please let me know if I missed anything :) http:\/\/t.co\/2FAFuxB3PL",
    "id" : 449118825208762368,
    "created_at" : "2014-03-27 09:40:46 +0000",
    "user" : {
      "name" : "Maria Pia Montoro",
      "screen_name" : "WordLo",
      "protected" : false,
      "id_str" : "190569306",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/660652749881782272\/BB1P3zUR_normal.jpg",
      "id" : 190569306,
      "verified" : false
    }
  },
  "id" : 449142289081065473,
  "created_at" : "2014-03-27 11:14:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 131, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/r1q1AW4J0L",
      "expanded_url" : "http:\/\/eltj.oxfordjournals.org\/content\/68\/1\/89.extract",
      "display_url" : "eltj.oxfordjournals.org\/content\/68\/1\/8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "449133318488195072",
  "text" : "\"a situation where CEFR definitions for English are identified with the definitions of one examining body?\" http:\/\/t.co\/r1q1AW4J0L #eltchat",
  "id" : 449133318488195072,
  "created_at" : "2014-03-27 10:38:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicola Prentis",
      "screen_name" : "NicolaPrentis",
      "indices" : [ 0, 14 ],
      "id_str" : "810667033",
      "id" : 810667033
    }, {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 16, 25 ],
      "id_str" : "134211317",
      "id" : 134211317
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/QiM0aeLgxu",
      "expanded_url" : "http:\/\/decentralisedteachingandlearning.wordpress.com\/2014\/01\/13\/4%C2%BD-ways-of-reporting-speech\/",
      "display_url" : "\u2026isedteachingandlearning.wordpress.com\/2014\/01\/13\/4%C\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "449117318602174465",
  "geo" : { },
  "id_str" : "449121204679766016",
  "in_reply_to_user_id" : 810667033,
  "text" : "@NicolaPrentis, @josipa74 has a neat post on this with a link to a paper on quotatives http:\/\/t.co\/QiM0aeLgxu",
  "id" : 449121204679766016,
  "in_reply_to_status_id" : 449117318602174465,
  "created_at" : "2014-03-27 09:50:14 +0000",
  "in_reply_to_screen_name" : "NicolaPrentis",
  "in_reply_to_user_id_str" : "810667033",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicola Prentis",
      "screen_name" : "NicolaPrentis",
      "indices" : [ 3, 17 ],
      "id_str" : "810667033",
      "id" : 810667033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EFL",
      "indices" : [ 61, 65 ]
    }, {
      "text" : "materials",
      "indices" : [ 66, 76 ]
    }, {
      "text" : "teachingEnglish",
      "indices" : [ 85, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/eaaHBBNm5R",
      "expanded_url" : "http:\/\/wp.me\/p1RJaO-es",
      "display_url" : "wp.me\/p1RJaO-es"
    } ]
  },
  "geo" : { },
  "id_str" : "449120312421265408",
  "text" : "RT @NicolaPrentis: \"Sod off, Reported Speech!\" she exclaimed.#EFL #materials writing #teachingEnglish http:\/\/t.co\/eaaHBBNm5R",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EFL",
        "indices" : [ 42, 46 ]
      }, {
        "text" : "materials",
        "indices" : [ 47, 57 ]
      }, {
        "text" : "teachingEnglish",
        "indices" : [ 66, 82 ]
      } ],
      "urls" : [ {
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/eaaHBBNm5R",
        "expanded_url" : "http:\/\/wp.me\/p1RJaO-es",
        "display_url" : "wp.me\/p1RJaO-es"
      } ]
    },
    "geo" : { },
    "id_str" : "449117318602174465",
    "text" : "\"Sod off, Reported Speech!\" she exclaimed.#EFL #materials writing #teachingEnglish http:\/\/t.co\/eaaHBBNm5R",
    "id" : 449117318602174465,
    "created_at" : "2014-03-27 09:34:47 +0000",
    "user" : {
      "name" : "Nicola Prentis",
      "screen_name" : "NicolaPrentis",
      "protected" : false,
      "id_str" : "810667033",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3046181441\/a51ef543c16ff30fdb8966f23237790d_normal.jpeg",
      "id" : 810667033,
      "verified" : false
    }
  },
  "id" : 449120312421265408,
  "created_at" : "2014-03-27 09:46:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cefr",
      "indices" : [ 46, 51 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 52, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ebimhesu4p",
      "expanded_url" : "http:\/\/clients.squareeye.net\/uploads\/eaquals2011\/documents\/EAQUALS_British_Council_Core_Curriculum_April2011.pdf",
      "display_url" : "clients.squareeye.net\/uploads\/eaqual\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "449114459433615360",
  "text" : "http:\/\/t.co\/ebimhesu4p core inventory for Eng #cefr #eltchat",
  "id" : 449114459433615360,
  "created_at" : "2014-03-27 09:23:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 0, 11 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449102361332838400",
  "geo" : { },
  "id_str" : "449107890255953921",
  "in_reply_to_user_id" : 87902543,
  "text" : "@tornhalves as u said in yr last blogpost love\/compassion...though very big ?s indeed",
  "id" : 449107890255953921,
  "in_reply_to_status_id" : 449102361332838400,
  "created_at" : "2014-03-27 08:57:19 +0000",
  "in_reply_to_screen_name" : "tornhalves",
  "in_reply_to_user_id_str" : "87902543",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 0, 11 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "449079429218975745",
  "geo" : { },
  "id_str" : "449090815303090176",
  "in_reply_to_user_id" : 87902543,
  "text" : "@tornhalves also one of the weaknesses of docu, as every sane person agrees on whole picture no?(even under barrage of corporate propaganda)",
  "id" : 449090815303090176,
  "in_reply_to_status_id" : 449079429218975745,
  "created_at" : "2014-03-27 07:49:28 +0000",
  "in_reply_to_screen_name" : "tornhalves",
  "in_reply_to_user_id_str" : "87902543",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WhiskVer",
      "screen_name" : "WhiskersVeritas",
      "indices" : [ 0, 16 ],
      "id_str" : "458848864",
      "id" : 458848864
    }, {
      "name" : "Joe Pereira",
      "screen_name" : "creedpatton",
      "indices" : [ 68, 80 ],
      "id_str" : "23870533",
      "id" : 23870533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/Kzfrxho1ZW",
      "expanded_url" : "http:\/\/theswanstation.com",
      "display_url" : "theswanstation.com"
    } ]
  },
  "in_reply_to_status_id_str" : "449041893079252992",
  "geo" : { },
  "id_str" : "449086560047493120",
  "in_reply_to_user_id" : 458848864,
  "text" : "@WhiskersVeritas great let me know if u have any questions or check @creedpatton blog http:\/\/t.co\/Kzfrxho1ZW",
  "id" : 449086560047493120,
  "in_reply_to_status_id" : 449041893079252992,
  "created_at" : "2014-03-27 07:32:34 +0000",
  "in_reply_to_screen_name" : "WhiskersVeritas",
  "in_reply_to_user_id_str" : "458848864",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 0, 11 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448818765246255104",
  "geo" : { },
  "id_str" : "448963949653159936",
  "in_reply_to_user_id" : 87902543,
  "text" : "@tornhalves &lt;&lt;a sage on the stage an image which, even though sage is also a herb, the horticulturalists are united in denouncing&gt;&gt; hehe",
  "id" : 448963949653159936,
  "in_reply_to_status_id" : 448818765246255104,
  "created_at" : "2014-03-26 23:25:21 +0000",
  "in_reply_to_screen_name" : "tornhalves",
  "in_reply_to_user_id_str" : "87902543",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 3, 14 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kenrobinson",
      "indices" : [ 125, 137 ]
    }, {
      "text" : "edtech",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "pedagogy",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/r5TIle9NHr",
      "expanded_url" : "http:\/\/bit.ly\/1o0NxKW",
      "display_url" : "bit.ly\/1o0NxKW"
    } ]
  },
  "geo" : { },
  "id_str" : "448963462363115520",
  "text" : "RT @tornhalves: The child as unfolding bud? Say \"No\" to the organic\/horticultural model of education  http:\/\/t.co\/r5TIle9NHr #kenrobinson #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "kenrobinson",
        "indices" : [ 109, 121 ]
      }, {
        "text" : "edtech",
        "indices" : [ 122, 129 ]
      }, {
        "text" : "pedagogy",
        "indices" : [ 130, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/r5TIle9NHr",
        "expanded_url" : "http:\/\/bit.ly\/1o0NxKW",
        "display_url" : "bit.ly\/1o0NxKW"
      } ]
    },
    "geo" : { },
    "id_str" : "448818765246255104",
    "text" : "The child as unfolding bud? Say \"No\" to the organic\/horticultural model of education  http:\/\/t.co\/r5TIle9NHr #kenrobinson #edtech #pedagogy",
    "id" : 448818765246255104,
    "created_at" : "2014-03-26 13:48:26 +0000",
    "user" : {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "protected" : false,
      "id_str" : "87902543",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3059742703\/1d3c7a2052db17d29644fa0a49af6480_normal.jpeg",
      "id" : 87902543,
      "verified" : false
    }
  },
  "id" : 448963462363115520,
  "created_at" : "2014-03-26 23:23:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 16, 24 ]
    }, {
      "text" : "lurkingcanbeproductive",
      "indices" : [ 25, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448943240130351104",
  "text" : "thanks everyone #eltchat #lurkingcanbeproductive :)",
  "id" : 448943240130351104,
  "created_at" : "2014-03-26 22:03:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpora",
      "indices" : [ 8, 16 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/WoU36U8qg4",
      "expanded_url" : "http:\/\/corpus.leeds.ac.uk\/itweb\/htdocs\/Query.html",
      "display_url" : "corpus.leeds.ac.uk\/itweb\/htdocs\/Q\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "448941868932689920",
  "text" : "fyi for #corpora peeps leeds intellitext http:\/\/t.co\/WoU36U8qg4 shows CEFR levels for concordances #eltchat",
  "id" : 448941868932689920,
  "created_at" : "2014-03-26 21:57:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Cook",
      "screen_name" : "idc74",
      "indices" : [ 0, 6 ],
      "id_str" : "290521216",
      "id" : 290521216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448937649525764096",
  "geo" : { },
  "id_str" : "448939612707491841",
  "in_reply_to_user_id" : 290521216,
  "text" : "@idc74 possibly though am sure a Swan critique would look at some conceptual problems :)",
  "id" : 448939612707491841,
  "in_reply_to_status_id" : 448937649525764096,
  "created_at" : "2014-03-26 21:48:39 +0000",
  "in_reply_to_screen_name" : "idc74",
  "in_reply_to_user_id_str" : "290521216",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaunwilden",
      "screen_name" : "Shaunwilden",
      "indices" : [ 0, 12 ],
      "id_str" : "15350512",
      "id" : 15350512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448937510052560897",
  "geo" : { },
  "id_str" : "448939035307016193",
  "in_reply_to_user_id" : 15350512,
  "text" : "@Shaunwilden great :)",
  "id" : 448939035307016193,
  "in_reply_to_status_id" : 448937510052560897,
  "created_at" : "2014-03-26 21:46:21 +0000",
  "in_reply_to_screen_name" : "Shaunwilden",
  "in_reply_to_user_id_str" : "15350512",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 119, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/r1q1AW4J0L",
      "expanded_url" : "http:\/\/eltj.oxfordjournals.org\/content\/68\/1\/89.extract",
      "display_url" : "eltj.oxfordjournals.org\/content\/68\/1\/8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "448936682558332928",
  "text" : "can anyone get a copy of the full text of this http:\/\/t.co\/r1q1AW4J0L Michael Swan critique of english profile project #eltchat ?",
  "id" : 448936682558332928,
  "created_at" : "2014-03-26 21:37:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 8, 16 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448927480079196161",
  "text" : "lurking #eltchat",
  "id" : 448927480079196161,
  "created_at" : "2014-03-26 21:00:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OculusRift",
      "indices" : [ 17, 28 ]
    }, {
      "text" : "openpandora",
      "indices" : [ 37, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/jdTRhOQMQh",
      "expanded_url" : "http:\/\/boards.openpandora.org\/topic\/15985-is-the-oculus-rift-doomed\/?p=325957",
      "display_url" : "boards.openpandora.org\/topic\/15985-is\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "448926622914449408",
  "text" : "a perspective on #OculusRift sale by #openpandora main bod http:\/\/t.co\/jdTRhOQMQh",
  "id" : 448926622914449408,
  "created_at" : "2014-03-26 20:57:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 0, 11 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "448900660495654912",
  "geo" : { },
  "id_str" : "448914703495213056",
  "in_reply_to_user_id" : 87902543,
  "text" : "@tornhalves it may well be though most of us won't be laughing :\/",
  "id" : 448914703495213056,
  "in_reply_to_status_id" : 448900660495654912,
  "created_at" : "2014-03-26 20:09:40 +0000",
  "in_reply_to_screen_name" : "tornhalves",
  "in_reply_to_user_id_str" : "87902543",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Newsnet.Scot",
      "screen_name" : "NewsnetScotland",
      "indices" : [ 3, 19 ],
      "id_str" : "126628908",
      "id" : 126628908
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "indyref",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 127, 140 ],
      "url" : "http:\/\/t.co\/iZeI9Bf9qU",
      "expanded_url" : "http:\/\/www.newsnetscotland.com\/index.php\/scottish-opinion\/8937-fairness-in-february",
      "display_url" : "newsnetscotland.com\/index.php\/scot\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "448766547746897920",
  "text" : "RT @NewsnetScotland: Professor John Robertson's analysis of February TV news coverage of the referendum: Fairness in February? http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "indyref",
        "indices" : [ 129, 137 ]
      } ],
      "urls" : [ {
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/iZeI9Bf9qU",
        "expanded_url" : "http:\/\/www.newsnetscotland.com\/index.php\/scottish-opinion\/8937-fairness-in-february",
        "display_url" : "newsnetscotland.com\/index.php\/scot\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "448597515613782016",
    "text" : "Professor John Robertson's analysis of February TV news coverage of the referendum: Fairness in February? http:\/\/t.co\/iZeI9Bf9qU #indyref",
    "id" : 448597515613782016,
    "created_at" : "2014-03-25 23:09:16 +0000",
    "user" : {
      "name" : "Newsnet.Scot",
      "screen_name" : "NewsnetScotland",
      "protected" : false,
      "id_str" : "126628908",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/549538386843688962\/nxLdMShb_normal.png",
      "id" : 126628908,
      "verified" : false
    }
  },
  "id" : 448766547746897920,
  "created_at" : "2014-03-26 10:20:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Carlson",
      "screen_name" : "sloopie72",
      "indices" : [ 3, 13 ],
      "id_str" : "20377590",
      "id" : 20377590
    }, {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "indices" : [ 128, 140 ],
      "id_str" : "849729062",
      "id" : 849729062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusMOOC",
      "indices" : [ 116, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/ulE4Bog1kP",
      "expanded_url" : "http:\/\/wp.me\/pKTmH-3HD",
      "display_url" : "wp.me\/pKTmH-3HD"
    } ]
  },
  "geo" : { },
  "id_str" : "448460830007627776",
  "text" : "RT @sloopie72: MOOCing: Corpus Linguistics? What's that? It's a terrific class, for starters http:\/\/t.co\/ulE4Bog1kP #corpusMOOC @TonyMcEnery",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tony McEnery",
        "screen_name" : "TonyMcEnery",
        "indices" : [ 113, 125 ],
        "id_str" : "849729062",
        "id" : 849729062
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpusMOOC",
        "indices" : [ 101, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/ulE4Bog1kP",
        "expanded_url" : "http:\/\/wp.me\/pKTmH-3HD",
        "display_url" : "wp.me\/pKTmH-3HD"
      } ]
    },
    "geo" : { },
    "id_str" : "448429481254854657",
    "text" : "MOOCing: Corpus Linguistics? What's that? It's a terrific class, for starters http:\/\/t.co\/ulE4Bog1kP #corpusMOOC @TonyMcEnery",
    "id" : 448429481254854657,
    "created_at" : "2014-03-25 12:01:34 +0000",
    "user" : {
      "name" : "Karen Carlson",
      "screen_name" : "sloopie72",
      "protected" : false,
      "id_str" : "20377590",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/709715050316091392\/Xmk8FxgU_normal.jpg",
      "id" : 20377590,
      "verified" : false
    }
  },
  "id" : 448460830007627776,
  "created_at" : "2014-03-25 14:06:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Duygu \u00C7andarl\u0131",
      "screen_name" : "duygucandarli",
      "indices" : [ 3, 17 ],
      "id_str" : "48839094",
      "id" : 48839094
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusMOOC",
      "indices" : [ 113, 124 ]
    }, {
      "text" : "MOOC",
      "indices" : [ 125, 130 ]
    }, {
      "text" : "FutureLearn",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/gZEOkIkBn0",
      "expanded_url" : "http:\/\/duygucandarli.wordpress.com\/2014\/03\/24\/corpusmooc\/",
      "display_url" : "duygucandarli.wordpress.com\/2014\/03\/24\/cor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "448381869550501888",
  "text" : "RT @duygucandarli: New blog post: CorpusMOOC - The most brilliant MOOC I have completed! http:\/\/t.co\/gZEOkIkBn0  #corpusMOOC #MOOC #FutureL\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpusMOOC",
        "indices" : [ 94, 105 ]
      }, {
        "text" : "MOOC",
        "indices" : [ 106, 111 ]
      }, {
        "text" : "FutureLearn",
        "indices" : [ 112, 124 ]
      } ],
      "urls" : [ {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/gZEOkIkBn0",
        "expanded_url" : "http:\/\/duygucandarli.wordpress.com\/2014\/03\/24\/corpusmooc\/",
        "display_url" : "duygucandarli.wordpress.com\/2014\/03\/24\/cor\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "448368735267463173",
    "text" : "New blog post: CorpusMOOC - The most brilliant MOOC I have completed! http:\/\/t.co\/gZEOkIkBn0  #corpusMOOC #MOOC #FutureLearn",
    "id" : 448368735267463173,
    "created_at" : "2014-03-25 08:00:11 +0000",
    "user" : {
      "name" : "Duygu \u00C7andarl\u0131",
      "screen_name" : "duygucandarli",
      "protected" : false,
      "id_str" : "48839094",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/473607105765576704\/DIiO0Cy7_normal.jpeg",
      "id" : 48839094,
      "verified" : false
    }
  },
  "id" : 448381869550501888,
  "created_at" : "2014-03-25 08:52:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Douglas Carnall",
      "screen_name" : "JuliuzBeezer",
      "indices" : [ 73, 86 ],
      "id_str" : "25936824",
      "id" : 25936824
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 0, 11 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/v5gbc6oMRN",
      "expanded_url" : "https:\/\/plus.google.com\/events\/c519h0i0p0broopgu914mg7ais4?authkey=CIO7k430ls-_EQ",
      "display_url" : "plus.google.com\/events\/c519h0i\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "448288692181139456",
  "geo" : { },
  "id_str" : "448335365276200960",
  "in_reply_to_user_id" : 25936824,
  "text" : "#corpusmooc hangout this friday 28 march 2130CET https:\/\/t.co\/v5gbc6oMRN @JuliuzBeezer",
  "id" : 448335365276200960,
  "in_reply_to_status_id" : 448288692181139456,
  "created_at" : "2014-03-25 05:47:35 +0000",
  "in_reply_to_screen_name" : "JuliuzBeezer",
  "in_reply_to_user_id_str" : "25936824",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 3, 11 ],
      "id_str" : "20650366",
      "id" : 20650366
    }, {
      "name" : "David Dodgson",
      "screen_name" : "DaveDodgson",
      "indices" : [ 124, 136 ],
      "id_str" : "112962705",
      "id" : 112962705
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/1nhew2j3BY",
      "expanded_url" : "http:\/\/eltsandbox.weebly.com\/1\/post\/2014\/03\/why-minecraft-may-well-be-one-of-the-best-games-for-language-learning.html#.UzCo6FbX8lo.twitter",
      "display_url" : "eltsandbox.weebly.com\/1\/post\/2014\/03\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "448216615369572353",
  "text" : "RT @seburnt: Why Minecraft may well be one of the best games for language learning - ELT Sandbox http:\/\/t.co\/1nhew2j3BY via @DaveDodgson",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "David Dodgson",
        "screen_name" : "DaveDodgson",
        "indices" : [ 111, 123 ],
        "id_str" : "112962705",
        "id" : 112962705
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/1nhew2j3BY",
        "expanded_url" : "http:\/\/eltsandbox.weebly.com\/1\/post\/2014\/03\/why-minecraft-may-well-be-one-of-the-best-games-for-language-learning.html#.UzCo6FbX8lo.twitter",
        "display_url" : "eltsandbox.weebly.com\/1\/post\/2014\/03\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "448215614545350656",
    "text" : "Why Minecraft may well be one of the best games for language learning - ELT Sandbox http:\/\/t.co\/1nhew2j3BY via @DaveDodgson",
    "id" : 448215614545350656,
    "created_at" : "2014-03-24 21:51:44 +0000",
    "user" : {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "protected" : false,
      "id_str" : "20650366",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/743248377563971584\/9d9xlHlz_normal.jpg",
      "id" : 20650366,
      "verified" : false
    }
  },
  "id" : 448216615369572353,
  "created_at" : "2014-03-24 21:55:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/Xd5ejJJT6M",
      "expanded_url" : "http:\/\/ow.ly\/uTkks",
      "display_url" : "ow.ly\/uTkks"
    } ]
  },
  "geo" : { },
  "id_str" : "448210289784549376",
  "text" : "RT @medialens: Scotlandshire: BBC Scotland Coverage Of The Independence Referendum http:\/\/t.co\/Xd5ejJJT6M",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/Xd5ejJJT6M",
        "expanded_url" : "http:\/\/ow.ly\/uTkks",
        "display_url" : "ow.ly\/uTkks"
      } ]
    },
    "geo" : { },
    "id_str" : "448046096968073216",
    "text" : "Scotlandshire: BBC Scotland Coverage Of The Independence Referendum http:\/\/t.co\/Xd5ejJJT6M",
    "id" : 448046096968073216,
    "created_at" : "2014-03-24 10:38:08 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 448210289784549376,
  "created_at" : "2014-03-24 21:30:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 0, 11 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448168804221468672",
  "text" : "#corpusmooc peeps anyone interested in Google hangout to mark &amp; reflect on official end?",
  "id" : 448168804221468672,
  "created_at" : "2014-03-24 18:45:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CamillaMariannaBaran",
      "screen_name" : "baran_camilla",
      "indices" : [ 0, 14 ],
      "id_str" : "2365687700",
      "id" : 2365687700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "447519884369727488",
  "geo" : { },
  "id_str" : "448154422045319168",
  "in_reply_to_user_id" : 2365687700,
  "text" : "@baran_camilla indeed docu talks about the economic factors",
  "id" : 448154422045319168,
  "in_reply_to_status_id" : 447519884369727488,
  "created_at" : "2014-03-24 17:48:35 +0000",
  "in_reply_to_screen_name" : "baran_camilla",
  "in_reply_to_user_id_str" : "2365687700",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Spencer",
      "screen_name" : "edrethink",
      "indices" : [ 3, 13 ],
      "id_str" : "3057524486",
      "id" : 3057524486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/3g7ayDco2o",
      "expanded_url" : "https:\/\/docs.google.com\/document\/d\/102lPhuhV1YZfXofP3z9hcPXW26YIcsrpOhtYI5n4mdg\/edit",
      "display_url" : "docs.google.com\/document\/d\/102\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "447494915057283072",
  "text" : "RT @edrethink: What does Pearson own? Please add to this list: https:\/\/t.co\/3g7ayDco2o",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 71 ],
        "url" : "https:\/\/t.co\/3g7ayDco2o",
        "expanded_url" : "https:\/\/docs.google.com\/document\/d\/102lPhuhV1YZfXofP3z9hcPXW26YIcsrpOhtYI5n4mdg\/edit",
        "display_url" : "docs.google.com\/document\/d\/102\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "447494398008238080",
    "text" : "What does Pearson own? Please add to this list: https:\/\/t.co\/3g7ayDco2o",
    "id" : 447494398008238080,
    "created_at" : "2014-03-22 22:05:53 +0000",
    "user" : {
      "name" : "John Spencer",
      "screen_name" : "spencerideas",
      "protected" : false,
      "id_str" : "18389166",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751913559160795136\/eU7NtYy4_normal.jpg",
      "id" : 18389166,
      "verified" : false
    }
  },
  "id" : 447494915057283072,
  "created_at" : "2014-03-22 22:07:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 90, 98 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/oC164fZMVP",
      "expanded_url" : "http:\/\/youtu.be\/pMgOTQ7D_lk",
      "display_url" : "youtu.be\/pMgOTQ7D_lk"
    } ]
  },
  "geo" : { },
  "id_str" : "447483540255436800",
  "text" : "The Crisis of Civilization - Full Length Documentary Movie HD: http:\/\/t.co\/oC164fZMVP via @YouTube",
  "id" : 447483540255436800,
  "created_at" : "2014-03-22 21:22:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Thornbury",
      "screen_name" : "thornburyscott",
      "indices" : [ 17, 32 ],
      "id_str" : "23090474",
      "id" : 23090474
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iatefl",
      "indices" : [ 44, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "447312024419450880",
  "text" : "@nomadicsinclair @thornburyscott thanks for #iatefl post share :)",
  "id" : 447312024419450880,
  "created_at" : "2014-03-22 10:01:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Divya Madhavan",
      "screen_name" : "_divyamadhavan",
      "indices" : [ 3, 18 ],
      "id_str" : "408492806",
      "id" : 408492806
    }, {
      "name" : "centraleparis",
      "screen_name" : "centraleparis",
      "indices" : [ 112, 126 ],
      "id_str" : "3384225669",
      "id" : 3384225669
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/_divyamadhavan\/status\/447308042766680064\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/VgLIUMSlJK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BjUoS3tIcAAdZN-.jpg",
      "id_str" : "447308042649235456",
      "id" : 447308042649235456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjUoS3tIcAAdZN-.jpg",
      "sizes" : [ {
        "h" : 456,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 804,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 764
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 764
      } ],
      "display_url" : "pic.twitter.com\/VgLIUMSlJK"
    } ],
    "hashtags" : [ {
      "text" : "CriticalPedagogy",
      "indices" : [ 55, 72 ]
    }, {
      "text" : "BELTABelgium",
      "indices" : [ 87, 100 ]
    }, {
      "text" : "HigherEd",
      "indices" : [ 127, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "447310130988978176",
  "text" : "RT @_divyamadhavan: Getting ready to give a talk about #CriticalPedagogy at the second #BELTABelgium conference @centraleparis #HigherEd ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "centraleparis",
        "screen_name" : "centraleparis",
        "indices" : [ 92, 106 ],
        "id_str" : "3384225669",
        "id" : 3384225669
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/_divyamadhavan\/status\/447308042766680064\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/VgLIUMSlJK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BjUoS3tIcAAdZN-.jpg",
        "id_str" : "447308042649235456",
        "id" : 447308042649235456,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjUoS3tIcAAdZN-.jpg",
        "sizes" : [ {
          "h" : 456,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 804,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 764
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 764
        } ],
        "display_url" : "pic.twitter.com\/VgLIUMSlJK"
      } ],
      "hashtags" : [ {
        "text" : "CriticalPedagogy",
        "indices" : [ 35, 52 ]
      }, {
        "text" : "BELTABelgium",
        "indices" : [ 67, 80 ]
      }, {
        "text" : "HigherEd",
        "indices" : [ 107, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "447308042766680064",
    "text" : "Getting ready to give a talk about #CriticalPedagogy at the second #BELTABelgium conference @centraleparis #HigherEd http:\/\/t.co\/VgLIUMSlJK",
    "id" : 447308042766680064,
    "created_at" : "2014-03-22 09:45:22 +0000",
    "user" : {
      "name" : "Divya Madhavan",
      "screen_name" : "_divyamadhavan",
      "protected" : false,
      "id_str" : "408492806",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/764501890071666688\/jyS8Y-Ag_normal.jpg",
      "id" : 408492806,
      "verified" : false
    }
  },
  "id" : 447310130988978176,
  "created_at" : "2014-03-22 09:53:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BDS",
      "indices" : [ 132, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/DZGG4MCA4t",
      "expanded_url" : "http:\/\/johnhilley.blogspot.co.uk\/2014\/03\/david-camerons-benign-part-in-middle.html",
      "display_url" : "johnhilley.blogspot.co.uk\/2014\/03\/david-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "447138050427322368",
  "text" : "RT @johnwhilley: David Cameron's 'benign' part in the 'Middle East peace process' - an exchange with the BBC http:\/\/t.co\/DZGG4MCA4t #BDS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BDS",
        "indices" : [ 115, 119 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/DZGG4MCA4t",
        "expanded_url" : "http:\/\/johnhilley.blogspot.co.uk\/2014\/03\/david-camerons-benign-part-in-middle.html",
        "display_url" : "johnhilley.blogspot.co.uk\/2014\/03\/david-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "446950567244726272",
    "text" : "David Cameron's 'benign' part in the 'Middle East peace process' - an exchange with the BBC http:\/\/t.co\/DZGG4MCA4t #BDS",
    "id" : 446950567244726272,
    "created_at" : "2014-03-21 10:04:53 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 447138050427322368,
  "created_at" : "2014-03-21 22:29:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 49, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/3m4A3SvuxR",
      "expanded_url" : "http:\/\/eflnotes.wordpress.com\/2014\/03\/21\/alcohol-drink-driving-porn-and-happy-iatefl-harrogate-2014\/",
      "display_url" : "eflnotes.wordpress.com\/2014\/03\/21\/alc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "447127855928188929",
  "text" : "could not resist this title fr 1st blog post for #IATEFL Harrogate 2014 http:\/\/t.co\/3m4A3SvuxR",
  "id" : 447127855928188929,
  "created_at" : "2014-03-21 21:49:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 3, 13 ],
      "id_str" : "525274103",
      "id" : 525274103
    }, {
      "name" : "Learning\/New Media",
      "screen_name" : "LNM_Monash",
      "indices" : [ 16, 27 ],
      "id_str" : "544202376",
      "id" : 544202376
    }, {
      "name" : "Neil Selwyn",
      "screen_name" : "Neil_Selwyn",
      "indices" : [ 77, 89 ],
      "id_str" : "142598896",
      "id" : 142598896
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edtech",
      "indices" : [ 130, 137 ]
    }, {
      "text" : "elearning",
      "indices" : [ 138, 144 ]
    }, {
      "text" : "AusELT",
      "indices" : [ 143, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/rJmoFMrH6v",
      "expanded_url" : "http:\/\/ow.ly\/uMugQ",
      "display_url" : "ow.ly\/uMugQ"
    } ]
  },
  "geo" : { },
  "id_str" : "446972387440209920",
  "text" : "RT @ElkySmith: \u201C@LNM_Monash: 'The Internet &amp; Education' - new chapter by @Neil_Selwyn - [open access] http:\/\/t.co\/rJmoFMrH6v  #edtech #elea\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Learning\/New Media",
        "screen_name" : "LNM_Monash",
        "indices" : [ 1, 12 ],
        "id_str" : "544202376",
        "id" : 544202376
      }, {
        "name" : "Neil Selwyn",
        "screen_name" : "Neil_Selwyn",
        "indices" : [ 62, 74 ],
        "id_str" : "142598896",
        "id" : 142598896
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "edtech",
        "indices" : [ 115, 122 ]
      }, {
        "text" : "elearning",
        "indices" : [ 123, 133 ]
      }, {
        "text" : "AusELT",
        "indices" : [ 135, 142 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/rJmoFMrH6v",
        "expanded_url" : "http:\/\/ow.ly\/uMugQ",
        "display_url" : "ow.ly\/uMugQ"
      } ]
    },
    "in_reply_to_status_id_str" : "446742318381424641",
    "geo" : { },
    "id_str" : "446943016700223488",
    "in_reply_to_user_id" : 544202376,
    "text" : "\u201C@LNM_Monash: 'The Internet &amp; Education' - new chapter by @Neil_Selwyn - [open access] http:\/\/t.co\/rJmoFMrH6v  #edtech #elearning\u201D #AusELT",
    "id" : 446943016700223488,
    "in_reply_to_status_id" : 446742318381424641,
    "created_at" : "2014-03-21 09:34:53 +0000",
    "in_reply_to_screen_name" : "LNM_Monash",
    "in_reply_to_user_id_str" : "544202376",
    "user" : {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "protected" : false,
      "id_str" : "525274103",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/690658566370263041\/qggTYEb3_normal.jpg",
      "id" : 525274103,
      "verified" : false
    }
  },
  "id" : 446972387440209920,
  "created_at" : "2014-03-21 11:31:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roger Dupuy",
      "screen_name" : "rogerdupuy",
      "indices" : [ 3, 14 ],
      "id_str" : "13498092",
      "id" : 13498092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/D36baR3maM",
      "expanded_url" : "http:\/\/tefl.posthaven.com\/21-lessons-learned-from-the-language-classroom-1-of-25",
      "display_url" : "tefl.posthaven.com\/21-lessons-lea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "446969080294440960",
  "text" : "RT @rogerdupuy: 21 Lessons Learned From the Language Classroom (1 of 25) http:\/\/t.co\/D36baR3maM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/posthaven.com\" rel=\"nofollow\"\u003EPosthaven\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/D36baR3maM",
        "expanded_url" : "http:\/\/tefl.posthaven.com\/21-lessons-learned-from-the-language-classroom-1-of-25",
        "display_url" : "tefl.posthaven.com\/21-lessons-lea\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "446968728698519552",
    "text" : "21 Lessons Learned From the Language Classroom (1 of 25) http:\/\/t.co\/D36baR3maM",
    "id" : 446968728698519552,
    "created_at" : "2014-03-21 11:17:03 +0000",
    "user" : {
      "name" : "Roger Dupuy",
      "screen_name" : "rogerdupuy",
      "protected" : false,
      "id_str" : "13498092",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/708559032143912960\/gINmiTzD_normal.jpg",
      "id" : 13498092,
      "verified" : false
    }
  },
  "id" : 446969080294440960,
  "created_at" : "2014-03-21 11:18:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicola Prentis",
      "screen_name" : "NicolaPrentis",
      "indices" : [ 39, 53 ],
      "id_str" : "810667033",
      "id" : 810667033
    }, {
      "name" : "Martin Hawksey",
      "screen_name" : "mhawksey",
      "indices" : [ 80, 89 ],
      "id_str" : "13046992",
      "id" : 13046992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/XDBvCYA0hM",
      "expanded_url" : "http:\/\/mashe.hawksey.info\/2013\/01\/sync-twitter-archive-with-google-drive\/",
      "display_url" : "mashe.hawksey.info\/2013\/01\/sync-t\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "446949393078312961",
  "geo" : { },
  "id_str" : "446953657750528000",
  "in_reply_to_user_id" : 810667033,
  "text" : "why not keep your own twitter archive? @NicolaPrentis http:\/\/t.co\/XDBvCYA0hM by @mhawksey",
  "id" : 446953657750528000,
  "in_reply_to_status_id" : 446949393078312961,
  "created_at" : "2014-03-21 10:17:10 +0000",
  "in_reply_to_screen_name" : "NicolaPrentis",
  "in_reply_to_user_id_str" : "810667033",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CALPER",
      "screen_name" : "CALPERPA",
      "indices" : [ 3, 12 ],
      "id_str" : "34639201",
      "id" : 34639201
    }, {
      "name" : "LARC SDSU",
      "screen_name" : "LARC_SDSU",
      "indices" : [ 103, 113 ],
      "id_str" : "95282039",
      "id" : 95282039
    }, {
      "name" : "CALPER",
      "screen_name" : "CALPERPA",
      "indices" : [ 114, 123 ],
      "id_str" : "34639201",
      "id" : 34639201
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 124, 140 ],
      "url" : "http:\/\/t.co\/DSs2eRTHuO",
      "expanded_url" : "http:\/\/goo.gl\/NsBRGI",
      "display_url" : "goo.gl\/NsBRGI"
    } ]
  },
  "geo" : { },
  "id_str" : "446597416507437056",
  "text" : "RT @CALPERPA: Free LARC\/CALPER Webinar: John Norris handouts are now available. Task-based assessment  @LARC_SDSU @CALPERPA http:\/\/t.co\/DSs\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "LARC SDSU",
        "screen_name" : "LARC_SDSU",
        "indices" : [ 89, 99 ],
        "id_str" : "95282039",
        "id" : 95282039
      }, {
        "name" : "CALPER",
        "screen_name" : "CALPERPA",
        "indices" : [ 100, 109 ],
        "id_str" : "34639201",
        "id" : 34639201
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/DSs2eRTHuO",
        "expanded_url" : "http:\/\/goo.gl\/NsBRGI",
        "display_url" : "goo.gl\/NsBRGI"
      } ]
    },
    "in_reply_to_status_id_str" : "446315667902320640",
    "geo" : { },
    "id_str" : "446469146474467328",
    "in_reply_to_user_id" : 95282039,
    "text" : "Free LARC\/CALPER Webinar: John Norris handouts are now available. Task-based assessment  @LARC_SDSU @CALPERPA http:\/\/t.co\/DSs2eRTHuO",
    "id" : 446469146474467328,
    "in_reply_to_status_id" : 446315667902320640,
    "created_at" : "2014-03-20 02:11:54 +0000",
    "in_reply_to_screen_name" : "LARC_SDSU",
    "in_reply_to_user_id_str" : "95282039",
    "user" : {
      "name" : "CALPER",
      "screen_name" : "CALPERPA",
      "protected" : false,
      "id_str" : "34639201",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/634442828626563073\/ZRmLNoOU_normal.png",
      "id" : 34639201,
      "verified" : false
    }
  },
  "id" : 446597416507437056,
  "created_at" : "2014-03-20 10:41:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "eCPD Limited",
      "screen_name" : "eCPDWebinars",
      "indices" : [ 3, 16 ],
      "id_str" : "150273303",
      "id" : 150273303
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/7dtVE3BgHp",
      "expanded_url" : "http:\/\/fb.me\/RYoh4UDa",
      "display_url" : "fb.me\/RYoh4UDa"
    } ]
  },
  "geo" : { },
  "id_str" : "446569558527471616",
  "text" : "RT @eCPDWebinars: What Is Corpus Linguistics? | A Linguist in the... http:\/\/t.co\/7dtVE3BgHp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 73 ],
        "url" : "http:\/\/t.co\/7dtVE3BgHp",
        "expanded_url" : "http:\/\/fb.me\/RYoh4UDa",
        "display_url" : "fb.me\/RYoh4UDa"
      } ]
    },
    "geo" : { },
    "id_str" : "349229073840615424",
    "text" : "What Is Corpus Linguistics? | A Linguist in the... http:\/\/t.co\/7dtVE3BgHp",
    "id" : 349229073840615424,
    "created_at" : "2013-06-24 18:14:34 +0000",
    "user" : {
      "name" : "eCPD Limited",
      "screen_name" : "eCPDWebinars",
      "protected" : false,
      "id_str" : "150273303",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3601871637\/c99b414d3531640ba0f4fc65b64f8b56_normal.jpeg",
      "id" : 150273303,
      "verified" : false
    }
  },
  "id" : 446569558527471616,
  "created_at" : "2014-03-20 08:50:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Natallia Novikava",
      "screen_name" : "Natashetta",
      "indices" : [ 3, 14 ],
      "id_str" : "56308635",
      "id" : 56308635
    }, {
      "name" : "\u0414\u0438\u0430\u043D\u043A\u0430 \u0428\u043A\u0443\u0440\u0441\u043A\u0430\u044F",
      "screen_name" : "TheSecretDoS",
      "indices" : [ 76, 89 ],
      "id_str" : "440292980",
      "id" : 440292980
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 90, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/Gd7FAEDrKE",
      "expanded_url" : "http:\/\/wp.me\/p2crcD-Dx",
      "display_url" : "wp.me\/p2crcD-Dx"
    } ]
  },
  "geo" : { },
  "id_str" : "446567837625503744",
  "text" : "RT @Natashetta: Individual egos, crazy for love: http:\/\/t.co\/Gd7FAEDrKE via @TheSecretDoS #elt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u0414\u0438\u0430\u043D\u043A\u0430 \u0428\u043A\u0443\u0440\u0441\u043A\u0430\u044F",
        "screen_name" : "TheSecretDoS",
        "indices" : [ 60, 73 ],
        "id_str" : "440292980",
        "id" : 440292980
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "elt",
        "indices" : [ 74, 78 ]
      } ],
      "urls" : [ {
        "indices" : [ 33, 55 ],
        "url" : "http:\/\/t.co\/Gd7FAEDrKE",
        "expanded_url" : "http:\/\/wp.me\/p2crcD-Dx",
        "display_url" : "wp.me\/p2crcD-Dx"
      } ]
    },
    "geo" : { },
    "id_str" : "446554053187612672",
    "text" : "Individual egos, crazy for love: http:\/\/t.co\/Gd7FAEDrKE via @TheSecretDoS #elt",
    "id" : 446554053187612672,
    "created_at" : "2014-03-20 07:49:17 +0000",
    "user" : {
      "name" : "Natallia Novikava",
      "screen_name" : "Natashetta",
      "protected" : false,
      "id_str" : "56308635",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2877370292\/d6370dfafaa5506c53671f1bd1da0cdc_normal.jpeg",
      "id" : 56308635,
      "verified" : false
    }
  },
  "id" : 446567837625503744,
  "created_at" : "2014-03-20 08:44:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 3, 13 ],
      "id_str" : "525274103",
      "id" : 525274103
    }, {
      "name" : "Cameron Campbell",
      "screen_name" : "ronindotca",
      "indices" : [ 16, 27 ],
      "id_str" : "598583",
      "id" : 598583
    }, {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 29, 43 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AusELT",
      "indices" : [ 135, 140 ]
    }, {
      "text" : "PDFest2014",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/xvhOMNowSp",
      "expanded_url" : "http:\/\/onlinelibrary.wiley.com\/doi\/10.1111\/j.1467-8535.2011.01215.x\/abstract",
      "display_url" : "onlinelibrary.wiley.com\/doi\/10.1111\/j.\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "446567728573579264",
  "text" : "RT @ElkySmith: \u201C@ronindotca: @audreywatters (I think I'm done now, but holy crap these people all need to read http:\/\/t.co\/xvhOMNowSp\u201D #Aus\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Cameron Campbell",
        "screen_name" : "ronindotca",
        "indices" : [ 1, 12 ],
        "id_str" : "598583",
        "id" : 598583
      }, {
        "name" : "Audrey Watters",
        "screen_name" : "audreywatters",
        "indices" : [ 14, 28 ],
        "id_str" : "25388528",
        "id" : 25388528
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AusELT",
        "indices" : [ 120, 127 ]
      }, {
        "text" : "PDFest2014",
        "indices" : [ 128, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/xvhOMNowSp",
        "expanded_url" : "http:\/\/onlinelibrary.wiley.com\/doi\/10.1111\/j.1467-8535.2011.01215.x\/abstract",
        "display_url" : "onlinelibrary.wiley.com\/doi\/10.1111\/j.\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "446399685688066049",
    "geo" : { },
    "id_str" : "446559058368012289",
    "in_reply_to_user_id" : 598583,
    "text" : "\u201C@ronindotca: @audreywatters (I think I'm done now, but holy crap these people all need to read http:\/\/t.co\/xvhOMNowSp\u201D #AusELT #PDFest2014",
    "id" : 446559058368012289,
    "in_reply_to_status_id" : 446399685688066049,
    "created_at" : "2014-03-20 08:09:10 +0000",
    "in_reply_to_screen_name" : "ronindotca",
    "in_reply_to_user_id_str" : "598583",
    "user" : {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "protected" : false,
      "id_str" : "525274103",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/690658566370263041\/qggTYEb3_normal.jpg",
      "id" : 525274103,
      "verified" : false
    }
  },
  "id" : 446567728573579264,
  "created_at" : "2014-03-20 08:43:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "textivate",
      "screen_name" : "textivate",
      "indices" : [ 3, 13 ],
      "id_str" : "757151820",
      "id" : 757151820
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "langchat",
      "indices" : [ 130, 139 ]
    }, {
      "text" : "edtech",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "elt",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/R0rOGbGJfa",
      "expanded_url" : "http:\/\/www.textivate.com\/4x4-6ihjn1",
      "display_url" : "textivate.com\/4x4-6ihjn1"
    } ]
  },
  "geo" : { },
  "id_str" : "446425919142780928",
  "text" : "RT @textivate: New feature on textivate. Click the film \/ video icon at the top of this resource: http:\/\/t.co\/R0rOGbGJfa\nCool eh?\n#langchat\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "langchat",
        "indices" : [ 115, 124 ]
      }, {
        "text" : "edtech",
        "indices" : [ 125, 132 ]
      }, {
        "text" : "elt",
        "indices" : [ 133, 137 ]
      } ],
      "urls" : [ {
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/R0rOGbGJfa",
        "expanded_url" : "http:\/\/www.textivate.com\/4x4-6ihjn1",
        "display_url" : "textivate.com\/4x4-6ihjn1"
      } ]
    },
    "geo" : { },
    "id_str" : "446424572230127617",
    "text" : "New feature on textivate. Click the film \/ video icon at the top of this resource: http:\/\/t.co\/R0rOGbGJfa\nCool eh?\n#langchat #edtech #elt",
    "id" : 446424572230127617,
    "created_at" : "2014-03-19 23:14:46 +0000",
    "user" : {
      "name" : "textivate",
      "screen_name" : "textivate",
      "protected" : false,
      "id_str" : "757151820",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616568320066764800\/rx5tLnzg_normal.png",
      "id" : 757151820,
      "verified" : false
    }
  },
  "id" : 446425919142780928,
  "created_at" : "2014-03-19 23:20:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/l6IgidY8J6",
      "expanded_url" : "http:\/\/ow.ly\/uJRDO",
      "display_url" : "ow.ly\/uJRDO"
    } ]
  },
  "geo" : { },
  "id_str" : "446417839529164800",
  "text" : "RT @medialens: Media Alert: Cruise missile liberals remembering Libya, March 19, 2011 and targeting Syria, 2014 http:\/\/t.co\/l6IgidY8J6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/l6IgidY8J6",
        "expanded_url" : "http:\/\/ow.ly\/uJRDO",
        "display_url" : "ow.ly\/uJRDO"
      } ]
    },
    "geo" : { },
    "id_str" : "446241301928108032",
    "text" : "Media Alert: Cruise missile liberals remembering Libya, March 19, 2011 and targeting Syria, 2014 http:\/\/t.co\/l6IgidY8J6",
    "id" : 446241301928108032,
    "created_at" : "2014-03-19 11:06:31 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 446417839529164800,
  "created_at" : "2014-03-19 22:48:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/n0p8BQmoy6",
      "expanded_url" : "http:\/\/www.truthdig.com\/report\/item\/israels_war_on_american_universities_20140316",
      "display_url" : "truthdig.com\/report\/item\/is\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "446212556110438400",
  "text" : "RT @johnwhilley: Chris Hedges: Israel\u2019s War on American Universities http:\/\/t.co\/n0p8BQmoy6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/n0p8BQmoy6",
        "expanded_url" : "http:\/\/www.truthdig.com\/report\/item\/israels_war_on_american_universities_20140316",
        "display_url" : "truthdig.com\/report\/item\/is\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "445943578251264000",
    "text" : "Chris Hedges: Israel\u2019s War on American Universities http:\/\/t.co\/n0p8BQmoy6",
    "id" : 445943578251264000,
    "created_at" : "2014-03-18 15:23:28 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 446212556110438400,
  "created_at" : "2014-03-19 09:12:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anne Hodgson",
      "screen_name" : "annehodg",
      "indices" : [ 0, 9 ],
      "id_str" : "17589213",
      "id" : 17589213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446206817891549184",
  "geo" : { },
  "id_str" : "446209484265103360",
  "in_reply_to_user_id" : 17589213,
  "text" : "@annehodg definitely more chances of that online for sure! u put such experiences well in your post :)",
  "id" : 446209484265103360,
  "in_reply_to_status_id" : 446206817891549184,
  "created_at" : "2014-03-19 09:00:05 +0000",
  "in_reply_to_screen_name" : "annehodg",
  "in_reply_to_user_id_str" : "17589213",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "indices" : [ 3, 19 ],
      "id_str" : "1326508478",
      "id" : 1326508478
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/EKTBEflKM2",
      "expanded_url" : "http:\/\/cass.lancs.ac.uk\/?p=1092",
      "display_url" : "cass.lancs.ac.uk\/?p=1092"
    } ]
  },
  "geo" : { },
  "id_str" : "446041627719917568",
  "text" : "RT @CorpusSocialSci: New CASS: Briefing now available. Download new research on \"Opposing gay rights in UK Parliament: Then and now\" at htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/EKTBEflKM2",
        "expanded_url" : "http:\/\/cass.lancs.ac.uk\/?p=1092",
        "display_url" : "cass.lancs.ac.uk\/?p=1092"
      } ]
    },
    "geo" : { },
    "id_str" : "445896369208066048",
    "text" : "New CASS: Briefing now available. Download new research on \"Opposing gay rights in UK Parliament: Then and now\" at http:\/\/t.co\/EKTBEflKM2",
    "id" : 445896369208066048,
    "created_at" : "2014-03-18 12:15:53 +0000",
    "user" : {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "protected" : false,
      "id_str" : "1326508478",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3493899777\/ced36fe15c32eb911cbe3d64377524dc_normal.jpeg",
      "id" : 1326508478,
      "verified" : false
    }
  },
  "id" : 446041627719917568,
  "created_at" : "2014-03-18 21:53:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pete Warden",
      "screen_name" : "petewarden",
      "indices" : [ 98, 109 ],
      "id_str" : "14642896",
      "id" : 14642896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/FQqa5pwzhS",
      "expanded_url" : "http:\/\/verificationhandbook.com\/",
      "display_url" : "verificationhandbook.com"
    } ]
  },
  "geo" : { },
  "id_str" : "446031085999509504",
  "text" : "http:\/\/t.co\/FQqa5pwzhS A definitive guide to verifying digital content for emergency coverage h\/t @petewarden",
  "id" : 446031085999509504,
  "created_at" : "2014-03-18 21:11:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Graham",
      "screen_name" : "onalifeglug",
      "indices" : [ 0, 12 ],
      "id_str" : "19516039",
      "id" : 19516039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "446026086380761088",
  "geo" : { },
  "id_str" : "446027383595106304",
  "in_reply_to_user_id" : 19516039,
  "text" : "@onalifeglug hehe :) more like hard of hearing talk, i'll get me coat",
  "id" : 446027383595106304,
  "in_reply_to_status_id" : 446026086380761088,
  "created_at" : "2014-03-18 20:56:29 +0000",
  "in_reply_to_screen_name" : "onalifeglug",
  "in_reply_to_user_id_str" : "19516039",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "British Council",
      "screen_name" : "BritishCouncil",
      "indices" : [ 58, 73 ],
      "id_str" : "14732889",
      "id" : 14732889
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 0, 11 ]
    }, {
      "text" : "Eltons",
      "indices" : [ 74, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/21YSIpZQa7",
      "expanded_url" : "http:\/\/corpus.sehir.edu.tr\/Pages\/Home.aspx",
      "display_url" : "corpus.sehir.edu.tr\/Pages\/Home.aspx"
    } ]
  },
  "geo" : { },
  "id_str" : "446023085440126976",
  "text" : "#corpusmooc corpus nominated in local innovation category @BritishCouncil #Eltons 2014 http:\/\/t.co\/21YSIpZQa7",
  "id" : 446023085440126976,
  "created_at" : "2014-03-18 20:39:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "445921510729871361",
  "geo" : { },
  "id_str" : "445925202976075776",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler NICE :)",
  "id" : 445925202976075776,
  "in_reply_to_status_id" : 445921510729871361,
  "created_at" : "2014-03-18 14:10:27 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "piratebox",
      "indices" : [ 34, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445925070855479296",
  "text" : "chalk up another win in class for #piratebox vs photocopying :)",
  "id" : 445925070855479296,
  "created_at" : "2014-03-18 14:09:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 51, 67 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 68, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/4prxGjlI4h",
      "expanded_url" : "http:\/\/wp.me\/p1fHxQ-13d",
      "display_url" : "wp.me\/p1fHxQ-13d"
    } ]
  },
  "geo" : { },
  "id_str" : "445800867094986753",
  "text" : "Wordcounts are amazing. http:\/\/t.co\/4prxGjlI4h via @wordpressdotcom #corpusmooc",
  "id" : 445800867094986753,
  "created_at" : "2014-03-18 05:56:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 44, 60 ],
      "id_str" : "823905",
      "id" : 823905
    }, {
      "name" : "Colleen Brown",
      "screen_name" : "c_brune",
      "indices" : [ 64, 72 ],
      "id_str" : "34247658",
      "id" : 34247658
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/LahVramYM0",
      "expanded_url" : "http:\/\/wp.me\/p37ScC-8c",
      "display_url" : "wp.me\/p37ScC-8c"
    } ]
  },
  "geo" : { },
  "id_str" : "445797324762390528",
  "text" : "CAE Conditionals http:\/\/t.co\/LahVramYM0 via @wordpressdotcom cc @c_brune",
  "id" : 445797324762390528,
  "created_at" : "2014-03-18 05:42:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "theSetup",
      "indices" : [ 35, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/hArsIqTw2Y",
      "expanded_url" : "http:\/\/john.mcafee.usesthis.com\/",
      "display_url" : "john.mcafee.usesthis.com"
    } ]
  },
  "geo" : { },
  "id_str" : "445720218284081152",
  "text" : "this has got to be one of the best #theSetup interviews John McAfee http:\/\/t.co\/hArsIqTw2Y",
  "id" : 445720218284081152,
  "created_at" : "2014-03-18 00:35:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Graham",
      "screen_name" : "onalifeglug",
      "indices" : [ 0, 12 ],
      "id_str" : "19516039",
      "id" : 19516039
    }, {
      "name" : "Tom",
      "screen_name" : "thmsbsh",
      "indices" : [ 13, 21 ],
      "id_str" : "18188880",
      "id" : 18188880
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/rXynbxf5ZR",
      "expanded_url" : "http:\/\/retconpunchdotcom.files.wordpress.com\/2013\/12\/the-opposite-of-war-is-fucking.jpg",
      "display_url" : "retconpunchdotcom.files.wordpress.com\/2013\/12\/the-op\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "445696791313252352",
  "geo" : { },
  "id_str" : "445704715813552128",
  "in_reply_to_user_id" : 19516039,
  "text" : "@onalifeglug @thmsbsh http:\/\/t.co\/rXynbxf5ZR :)",
  "id" : 445704715813552128,
  "in_reply_to_status_id" : 445696791313252352,
  "created_at" : "2014-03-17 23:34:19 +0000",
  "in_reply_to_screen_name" : "onalifeglug",
  "in_reply_to_user_id_str" : "19516039",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Seymour",
      "screen_name" : "leninology",
      "indices" : [ 3, 14 ],
      "id_str" : "15557246",
      "id" : 15557246
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/1cxs7UxpMe",
      "expanded_url" : "http:\/\/www.theguardian.com\/p\/3ntzb\/tw",
      "display_url" : "theguardian.com\/p\/3ntzb\/tw"
    } ]
  },
  "geo" : { },
  "id_str" : "445698363284287489",
  "text" : "RT @leninology: Britain's five richest families and it's class system:  http:\/\/t.co\/1cxs7UxpMe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/1cxs7UxpMe",
        "expanded_url" : "http:\/\/www.theguardian.com\/p\/3ntzb\/tw",
        "display_url" : "theguardian.com\/p\/3ntzb\/tw"
      } ]
    },
    "geo" : { },
    "id_str" : "445660564157894656",
    "text" : "Britain's five richest families and it's class system:  http:\/\/t.co\/1cxs7UxpMe",
    "id" : 445660564157894656,
    "created_at" : "2014-03-17 20:38:53 +0000",
    "user" : {
      "name" : "Richard Seymour",
      "screen_name" : "leninology",
      "protected" : false,
      "id_str" : "15557246",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762344914583781377\/UDn8tMrp_normal.jpg",
      "id" : 15557246,
      "verified" : false
    }
  },
  "id" : 445698363284287489,
  "created_at" : "2014-03-17 23:09:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Aisha Brown",
      "screen_name" : "amyaishab",
      "indices" : [ 3, 13 ],
      "id_str" : "900029641",
      "id" : 900029641
    }, {
      "name" : "James Chapman",
      "screen_name" : "chapmangamo",
      "indices" : [ 68, 80 ],
      "id_str" : "30633376",
      "id" : 30633376
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/amyaishab\/status\/445647898215067649\/photo\/1",
      "indices" : [ 121, 140 ],
      "url" : "http:\/\/t.co\/SD2msqnp6P",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bi9CZu6CMAA7TGp.png",
      "id_str" : "445647897988575232",
      "id" : 445647897988575232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bi9CZu6CMAA7TGp.png",
      "sizes" : [ {
        "h" : 710,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 710,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 483,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 710,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/SD2msqnp6P"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445654853554278400",
  "text" : "RT @amyaishab: Cute pictures comparing sounds across languages from @chapmangamo. Love this one of eating sounds. Nomnom http:\/\/t.co\/SD2msq\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "James Chapman",
        "screen_name" : "chapmangamo",
        "indices" : [ 53, 65 ],
        "id_str" : "30633376",
        "id" : 30633376
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/amyaishab\/status\/445647898215067649\/photo\/1",
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/SD2msqnp6P",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bi9CZu6CMAA7TGp.png",
        "id_str" : "445647897988575232",
        "id" : 445647897988575232,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bi9CZu6CMAA7TGp.png",
        "sizes" : [ {
          "h" : 710,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 710,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 483,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 710,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/SD2msqnp6P"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "445647898215067649",
    "text" : "Cute pictures comparing sounds across languages from @chapmangamo. Love this one of eating sounds. Nomnom http:\/\/t.co\/SD2msqnp6P",
    "id" : 445647898215067649,
    "created_at" : "2014-03-17 19:48:33 +0000",
    "user" : {
      "name" : "Amy Aisha Brown",
      "screen_name" : "amyaishab",
      "protected" : false,
      "id_str" : "900029641",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/620604005799067648\/nD3nCCXK_normal.jpg",
      "id" : 900029641,
      "verified" : false
    }
  },
  "id" : 445654853554278400,
  "created_at" : "2014-03-17 20:16:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RT",
      "screen_name" : "RT_com",
      "indices" : [ 3, 10 ],
      "id_str" : "64643056",
      "id" : 64643056
    }, {
      "name" : "Neil Clark",
      "screen_name" : "NeilClark66",
      "indices" : [ 90, 102 ],
      "id_str" : "728039605",
      "id" : 728039605
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Crimea",
      "indices" : [ 21, 28 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/cM01qiRkj7",
      "expanded_url" : "http:\/\/on.rt.com\/6duh2w",
      "display_url" : "on.rt.com\/6duh2w"
    } ]
  },
  "geo" : { },
  "id_str" : "445288265785286657",
  "text" : "RT @RT_com: Opinion: #Crimea \u2013 another artificially created crisis http:\/\/t.co\/cM01qiRkj7 @NeilClark66",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Neil Clark",
        "screen_name" : "NeilClark66",
        "indices" : [ 78, 90 ],
        "id_str" : "728039605",
        "id" : 728039605
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Crimea",
        "indices" : [ 9, 16 ]
      } ],
      "urls" : [ {
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/cM01qiRkj7",
        "expanded_url" : "http:\/\/on.rt.com\/6duh2w",
        "display_url" : "on.rt.com\/6duh2w"
      } ]
    },
    "geo" : { },
    "id_str" : "444664510771900416",
    "text" : "Opinion: #Crimea \u2013 another artificially created crisis http:\/\/t.co\/cM01qiRkj7 @NeilClark66",
    "id" : 444664510771900416,
    "created_at" : "2014-03-15 02:40:55 +0000",
    "user" : {
      "name" : "RT",
      "screen_name" : "RT_com",
      "protected" : false,
      "id_str" : "64643056",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/675283352862089216\/GE1X4ASz_normal.png",
      "id" : 64643056,
      "verified" : true
    }
  },
  "id" : 445288265785286657,
  "created_at" : "2014-03-16 19:59:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe McVeigh",
      "screen_name" : "EvilJoeMcVeigh",
      "indices" : [ 3, 18 ],
      "id_str" : "1327355143",
      "id" : 1327355143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/Zr2RUAxfBE",
      "expanded_url" : "http:\/\/andreadallover.com\/2010\/09\/09\/the-outliers-by-malcolm-gladwell\/",
      "display_url" : "andreadallover.com\/2010\/09\/09\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "444857333274132480",
  "text" : "RT @EvilJoeMcVeigh: Updating a very old post (as if we needed more reasons to be sure Malcom Gladwell is full of it): http:\/\/t.co\/Zr2RUAxfBE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/Zr2RUAxfBE",
        "expanded_url" : "http:\/\/andreadallover.com\/2010\/09\/09\/the-outliers-by-malcolm-gladwell\/",
        "display_url" : "andreadallover.com\/2010\/09\/09\/the\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "444856114304532480",
    "text" : "Updating a very old post (as if we needed more reasons to be sure Malcom Gladwell is full of it): http:\/\/t.co\/Zr2RUAxfBE",
    "id" : 444856114304532480,
    "created_at" : "2014-03-15 15:22:17 +0000",
    "user" : {
      "name" : "Joe McVeigh",
      "screen_name" : "EvilJoeMcVeigh",
      "protected" : false,
      "id_str" : "1327355143",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/633574005530693632\/omOKH3tm_normal.png",
      "id" : 1327355143,
      "verified" : false
    }
  },
  "id" : 444857333274132480,
  "created_at" : "2014-03-15 15:27:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/VOgt3SrgTo",
      "expanded_url" : "http:\/\/members5.boardhost.com\/medialens\/msg\/1394881794.html",
      "display_url" : "members5.boardhost.com\/medialens\/msg\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "444800519803248641",
  "text" : "US Navy Crap http:\/\/t.co\/VOgt3SrgTo",
  "id" : 444800519803248641,
  "created_at" : "2014-03-15 11:41:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Forensic Linguistics",
      "screen_name" : "FORGE_LU",
      "indices" : [ 3, 12 ],
      "id_str" : "2211139201",
      "id" : 2211139201
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 125, 140 ],
      "url" : "http:\/\/t.co\/p91qdNmYPL",
      "expanded_url" : "http:\/\/www.theguardian.com\/commentisfree\/2014\/mar\/11\/lie-detectors-tool-state-voice-risk-analysis-benefit-fraud",
      "display_url" : "theguardian.com\/commentisfree\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "444222101105684480",
  "text" : "RT @FORGE_LU: Polygraphs, voice risk analysis software, or rice grains? The science(-fiction) of stress-based lie detection. http:\/\/t.co\/p9\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/p91qdNmYPL",
        "expanded_url" : "http:\/\/www.theguardian.com\/commentisfree\/2014\/mar\/11\/lie-detectors-tool-state-voice-risk-analysis-benefit-fraud",
        "display_url" : "theguardian.com\/commentisfree\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "444190815628574720",
    "text" : "Polygraphs, voice risk analysis software, or rice grains? The science(-fiction) of stress-based lie detection. http:\/\/t.co\/p91qdNmYPL",
    "id" : 444190815628574720,
    "created_at" : "2014-03-13 19:18:37 +0000",
    "user" : {
      "name" : "Forensic Linguistics",
      "screen_name" : "FORGE_LU",
      "protected" : false,
      "id_str" : "2211139201",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/426766695777058817\/npxHPteK_normal.png",
      "id" : 2211139201,
      "verified" : false
    }
  },
  "id" : 444222101105684480,
  "created_at" : "2014-03-13 21:22:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessica Frye",
      "screen_name" : "JessFrye1",
      "indices" : [ 3, 13 ],
      "id_str" : "533509442",
      "id" : 533509442
    }, {
      "name" : "LINGUIST List",
      "screen_name" : "linguistlist",
      "indices" : [ 56, 69 ],
      "id_str" : "104943598",
      "id" : 104943598
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpuslinguistics",
      "indices" : [ 110, 128 ]
    }, {
      "text" : "linguistics",
      "indices" : [ 129, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/znXcp5hXk5",
      "expanded_url" : "http:\/\/bit.ly\/O7lXvu",
      "display_url" : "bit.ly\/O7lXvu"
    } ]
  },
  "geo" : { },
  "id_str" : "444163647120482304",
  "text" : "RT @JessFrye1: Featured linguist of \"Ask a linguist\" by @linguistlist is Douglas Biber http:\/\/t.co\/znXcp5hXk5 #corpuslinguistics #linguisti\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "LINGUIST List",
        "screen_name" : "linguistlist",
        "indices" : [ 41, 54 ],
        "id_str" : "104943598",
        "id" : 104943598
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpuslinguistics",
        "indices" : [ 95, 113 ]
      }, {
        "text" : "linguistics",
        "indices" : [ 114, 126 ]
      } ],
      "urls" : [ {
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/znXcp5hXk5",
        "expanded_url" : "http:\/\/bit.ly\/O7lXvu",
        "display_url" : "bit.ly\/O7lXvu"
      } ]
    },
    "geo" : { },
    "id_str" : "444159765653245952",
    "text" : "Featured linguist of \"Ask a linguist\" by @linguistlist is Douglas Biber http:\/\/t.co\/znXcp5hXk5 #corpuslinguistics #linguistics",
    "id" : 444159765653245952,
    "created_at" : "2014-03-13 17:15:14 +0000",
    "user" : {
      "name" : "Jessica Frye",
      "screen_name" : "JessFrye1",
      "protected" : false,
      "id_str" : "533509442",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/444916386608193537\/9xiOTsl0_normal.jpeg",
      "id" : 533509442,
      "verified" : false
    }
  },
  "id" : 444163647120482304,
  "created_at" : "2014-03-13 17:30:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 107, 123 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/KKQAaBm1we",
      "expanded_url" : "http:\/\/wp.me\/p2CPYN-aT",
      "display_url" : "wp.me\/p2CPYN-aT"
    } ]
  },
  "geo" : { },
  "id_str" : "444092742331670528",
  "text" : "Plurality of Libyans continue to think they're worse of now than under Gadaffi. http:\/\/t.co\/KKQAaBm1we via @wordpressdotcom",
  "id" : 444092742331670528,
  "created_at" : "2014-03-13 12:48:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "444027439736713216",
  "geo" : { },
  "id_str" : "444040985962905600",
  "in_reply_to_user_id" : 18602422,
  "text" : "&lt;&lt;i've referred to multiple phases of coding..i coded it twice..the 1st time..there was a stronger imbalance against yes campaign..&gt;&gt; 31:52",
  "id" : 444040985962905600,
  "in_reply_to_status_id" : 444027439736713216,
  "created_at" : "2014-03-13 09:23:15 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 98, 108 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/MK4cRYJLny",
      "expanded_url" : "http:\/\/bellacaledonia.org.uk\/2014\/03\/12\/silence-and-collusion\/",
      "display_url" : "bellacaledonia.org.uk\/2014\/03\/12\/sil\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "444027439736713216",
  "text" : "fascinating account of academic's experience of effect of his research http:\/\/t.co\/MK4cRYJLny h\/t @medialens",
  "id" : 444027439736713216,
  "created_at" : "2014-03-13 08:29:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusMOOC",
      "indices" : [ 59, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fD5xF1X4Mi",
      "expanded_url" : "http:\/\/corpora.lancs.ac.uk\/vocab\/",
      "display_url" : "corpora.lancs.ac.uk\/vocab\/"
    } ]
  },
  "geo" : { },
  "id_str" : "444005445309841408",
  "text" : "http:\/\/t.co\/fD5xF1X4Mi New(UK)GSL website for teachers h\/t #corpusMOOC",
  "id" : 444005445309841408,
  "created_at" : "2014-03-13 07:02:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Hardie",
      "screen_name" : "HardieResearch",
      "indices" : [ 3, 18 ],
      "id_str" : "970452764",
      "id" : 970452764
    }, {
      "name" : "Jamie Zawinski",
      "screen_name" : "jwz",
      "indices" : [ 35, 39 ],
      "id_str" : "7190742",
      "id" : 7190742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/5T9E1FIcQt",
      "expanded_url" : "http:\/\/jwz.org\/b\/yh01",
      "display_url" : "jwz.org\/b\/yh01"
    } ]
  },
  "geo" : { },
  "id_str" : "444004452878782464",
  "text" : "RT @HardieResearch: Impressive. RT @jwz William Shakespeare Presents Terminator the Second ... http:\/\/t.co\/5T9E1FIcQt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jamie Zawinski",
        "screen_name" : "jwz",
        "indices" : [ 15, 19 ],
        "id_str" : "7190742",
        "id" : 7190742
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/5T9E1FIcQt",
        "expanded_url" : "http:\/\/jwz.org\/b\/yh01",
        "display_url" : "jwz.org\/b\/yh01"
      } ]
    },
    "geo" : { },
    "id_str" : "443826672685838336",
    "text" : "Impressive. RT @jwz William Shakespeare Presents Terminator the Second ... http:\/\/t.co\/5T9E1FIcQt",
    "id" : 443826672685838336,
    "created_at" : "2014-03-12 19:11:39 +0000",
    "user" : {
      "name" : "Andrew Hardie",
      "screen_name" : "HardieResearch",
      "protected" : false,
      "id_str" : "970452764",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2895091886\/5274f8f34de87999703c0f92adfdf465_normal.jpeg",
      "id" : 970452764,
      "verified" : false
    }
  },
  "id" : 444004452878782464,
  "created_at" : "2014-03-13 06:58:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "natiserhost197",
      "screen_name" : "esl_robert",
      "indices" : [ 0, 11 ],
      "id_str" : "2982357761",
      "id" : 2982357761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/Xj76Lz5aQM",
      "expanded_url" : "http:\/\/sacodeyl.inf.um.es\/sacodeyl-search2\/",
      "display_url" : "sacodeyl.inf.um.es\/sacodeyl-searc\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "443917051380260864",
  "geo" : { },
  "id_str" : "444003716950396928",
  "in_reply_to_user_id" : 18526186,
  "text" : "@esl_robert have u seen the sacodyl multimedia corpus http:\/\/t.co\/Xj76Lz5aQM 13 to 18 yrs?",
  "id" : 444003716950396928,
  "in_reply_to_status_id" : 443917051380260864,
  "created_at" : "2014-03-13 06:55:09 +0000",
  "in_reply_to_screen_name" : "RobertEPoole",
  "in_reply_to_user_id_str" : "18526186",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30B3\u30FC\u30D1\u30B9\u8A00\u8A9E\u5B66\u305F\u3093",
      "screen_name" : "CorpusTan",
      "indices" : [ 3, 13 ],
      "id_str" : "2309797189",
      "id" : 2309797189
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/uPK8nV5K9K",
      "expanded_url" : "http:\/\/alaginrc.nict.go.jp\/nict_jle\/",
      "display_url" : "alaginrc.nict.go.jp\/nict_jle\/"
    } ]
  },
  "geo" : { },
  "id_str" : "444000220561833984",
  "text" : "RT @CorpusTan: NICT JLE Corpus\u306F\nhttp:\/\/t.co\/uPK8nV5K9K\n\u304B\u3089\u30C0\u30A6\u30F3\u30ED\u30FC\u30C9\u53EF\u80FD\u3088\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 17, 39 ],
        "url" : "http:\/\/t.co\/uPK8nV5K9K",
        "expanded_url" : "http:\/\/alaginrc.nict.go.jp\/nict_jle\/",
        "display_url" : "alaginrc.nict.go.jp\/nict_jle\/"
      } ]
    },
    "geo" : { },
    "id_str" : "443918786177925120",
    "text" : "NICT JLE Corpus\u306F\nhttp:\/\/t.co\/uPK8nV5K9K\n\u304B\u3089\u30C0\u30A6\u30F3\u30ED\u30FC\u30C9\u53EF\u80FD\u3088\u3002",
    "id" : 443918786177925120,
    "created_at" : "2014-03-13 01:17:40 +0000",
    "user" : {
      "name" : "\u30B3\u30FC\u30D1\u30B9\u8A00\u8A9E\u5B66\u305F\u3093",
      "screen_name" : "CorpusTan",
      "protected" : false,
      "id_str" : "2309797189",
      "profile_image_url_https" : "https:\/\/abs.twimg.com\/sticky\/default_profile_images\/default_profile_0_normal.png",
      "id" : 2309797189,
      "verified" : false
    }
  },
  "id" : 444000220561833984,
  "created_at" : "2014-03-13 06:41:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Akira Murakami",
      "screen_name" : "mrkm_a",
      "indices" : [ 141, 148 ],
      "id_str" : "116922669",
      "id" : 116922669
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/ygkOCWku9P",
      "expanded_url" : "http:\/\/youtu.be\/Gswifd4rCWU?t=8m12s",
      "display_url" : "youtu.be\/Gswifd4rCWU?t=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "443874399985598464",
  "text" : "Chomsky in Japan &lt;&lt;The biggest problem I have is not my job teaching but my conditions as a teacher&gt;&gt; http:\/\/t.co\/ygkOCWku9P h\/t @mrkm_a",
  "id" : 443874399985598464,
  "created_at" : "2014-03-12 22:21:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "popcorntime",
      "indices" : [ 4, 16 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443841006463877120",
  "text" : "man #popcorntime is pretty pretty sweet",
  "id" : 443841006463877120,
  "created_at" : "2014-03-12 20:08:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lewis School HR",
      "screen_name" : "alatlewisschool",
      "indices" : [ 3, 19 ],
      "id_str" : "473783869",
      "id" : 473783869
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/ZbTwQ6QNGP",
      "expanded_url" : "http:\/\/bit.ly\/1cwBWOv",
      "display_url" : "bit.ly\/1cwBWOv"
    } ]
  },
  "geo" : { },
  "id_str" : "443814544495091712",
  "text" : "RT @alatlewisschool: How to teach which words go together: Corpora in English language teaching http:\/\/t.co\/ZbTwQ6QNGP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/ZbTwQ6QNGP",
        "expanded_url" : "http:\/\/bit.ly\/1cwBWOv",
        "display_url" : "bit.ly\/1cwBWOv"
      } ]
    },
    "geo" : { },
    "id_str" : "443814135310991361",
    "text" : "How to teach which words go together: Corpora in English language teaching http:\/\/t.co\/ZbTwQ6QNGP",
    "id" : 443814135310991361,
    "created_at" : "2014-03-12 18:21:50 +0000",
    "user" : {
      "name" : "Lewis School HR",
      "screen_name" : "alatlewisschool",
      "protected" : false,
      "id_str" : "473783869",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1780093447\/lewis_logo_large_trans_normal_normal.png",
      "id" : 473783869,
      "verified" : false
    }
  },
  "id" : 443814544495091712,
  "created_at" : "2014-03-12 18:23:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicola Prentis",
      "screen_name" : "NicolaPrentis",
      "indices" : [ 3, 17 ],
      "id_str" : "810667033",
      "id" : 810667033
    }, {
      "name" : "David Liu",
      "screen_name" : "dliu8",
      "indices" : [ 57, 63 ],
      "id_str" : "20792099",
      "id" : 20792099
    }, {
      "name" : "ELTjam",
      "screen_name" : "eltjam",
      "indices" : [ 113, 120 ],
      "id_str" : "1356363686",
      "id" : 1356363686
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/L7sxPqU2Yk",
      "expanded_url" : "http:\/\/wp.me\/p1RJaO-dX",
      "display_url" : "wp.me\/p1RJaO-dX"
    } ]
  },
  "geo" : { },
  "id_str" : "443763306843893760",
  "text" : "RT @NicolaPrentis: Want me to do your marketing for ELT? @dliu8 Why Knewton need to Adapt http:\/\/t.co\/L7sxPqU2Yk @eltjam",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "David Liu",
        "screen_name" : "dliu8",
        "indices" : [ 38, 44 ],
        "id_str" : "20792099",
        "id" : 20792099
      }, {
        "name" : "ELTjam",
        "screen_name" : "eltjam",
        "indices" : [ 94, 101 ],
        "id_str" : "1356363686",
        "id" : 1356363686
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/L7sxPqU2Yk",
        "expanded_url" : "http:\/\/wp.me\/p1RJaO-dX",
        "display_url" : "wp.me\/p1RJaO-dX"
      } ]
    },
    "geo" : { },
    "id_str" : "443756163516362752",
    "text" : "Want me to do your marketing for ELT? @dliu8 Why Knewton need to Adapt http:\/\/t.co\/L7sxPqU2Yk @eltjam",
    "id" : 443756163516362752,
    "created_at" : "2014-03-12 14:31:28 +0000",
    "user" : {
      "name" : "Nicola Prentis",
      "screen_name" : "NicolaPrentis",
      "protected" : false,
      "id_str" : "810667033",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3046181441\/a51ef543c16ff30fdb8966f23237790d_normal.jpeg",
      "id" : 810667033,
      "verified" : false
    }
  },
  "id" : 443763306843893760,
  "created_at" : "2014-03-12 14:59:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "edulang",
      "screen_name" : "edulang",
      "indices" : [ 3, 11 ],
      "id_str" : "2877002950",
      "id" : 2877002950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/VhIoJq4mZX",
      "expanded_url" : "https:\/\/torrentfreak.com\/open-source-torrent-streaming-a-netflix-for-pirates-140308\/",
      "display_url" : "torrentfreak.com\/open-source-to\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "443751391388270593",
  "text" : "RT @Edulang: A Netflix for pirates, allowing users to stream the latest blockbusters at no cost:\nhttps:\/\/t.co\/VhIoJq4mZX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/VhIoJq4mZX",
        "expanded_url" : "https:\/\/torrentfreak.com\/open-source-torrent-streaming-a-netflix-for-pirates-140308\/",
        "display_url" : "torrentfreak.com\/open-source-to\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "443503682664292352",
    "text" : "A Netflix for pirates, allowing users to stream the latest blockbusters at no cost:\nhttps:\/\/t.co\/VhIoJq4mZX",
    "id" : 443503682664292352,
    "created_at" : "2014-03-11 21:48:12 +0000",
    "user" : {
      "name" : "WordTov",
      "screen_name" : "wordtov",
      "protected" : false,
      "id_str" : "236921161",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/612985595749617664\/YMxtQC1g_normal.png",
      "id" : 236921161,
      "verified" : false
    }
  },
  "id" : 443751391388270593,
  "created_at" : "2014-03-12 14:12:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Graham",
      "screen_name" : "onalifeglug",
      "indices" : [ 0, 12 ],
      "id_str" : "19516039",
      "id" : 19516039
    }, {
      "name" : "PoliticsHome",
      "screen_name" : "politicshome",
      "indices" : [ 13, 26 ],
      "id_str" : "16558943",
      "id" : 16558943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "443747292202684416",
  "geo" : { },
  "id_str" : "443748867260313600",
  "in_reply_to_user_id" : 19516039,
  "text" : "@onalifeglug @politicshome lol comedy writers have a tough job when faced with reality like thus :\/",
  "id" : 443748867260313600,
  "in_reply_to_status_id" : 443747292202684416,
  "created_at" : "2014-03-12 14:02:29 +0000",
  "in_reply_to_screen_name" : "onalifeglug",
  "in_reply_to_user_id_str" : "19516039",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30B3\u30FC\u30D1\u30B9\u8A00\u8A9E\u5B66\u305F\u3093",
      "screen_name" : "CorpusTan",
      "indices" : [ 67, 77 ],
      "id_str" : "2309797189",
      "id" : 2309797189
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/EPCi31Uyti",
      "expanded_url" : "http:\/\/scn.jkn21.com\/~jefll04\/jefll_top.html",
      "display_url" : "scn.jkn21.com\/~jefll04\/jefll\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "443708534380052480",
  "text" : "Japanese EFL Corpus, English interface http:\/\/t.co\/EPCi31Uyti h\/t\/ @CorpusTan",
  "id" : 443708534380052480,
  "created_at" : "2014-03-12 11:22:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "indices" : [ 3, 15 ],
      "id_str" : "849729062",
      "id" : 849729062
    }, {
      "name" : "Macmillan Dictionary",
      "screen_name" : "MacDictionary",
      "indices" : [ 105, 119 ],
      "id_str" : "23783700",
      "id" : 23783700
    }, {
      "name" : "ESRC",
      "screen_name" : "ESRC",
      "indices" : [ 120, 125 ],
      "id_str" : "19393236",
      "id" : 19393236
    }, {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "indices" : [ 126, 140 ],
      "id_str" : "1326508478",
      "id" : 1326508478
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusMOOC",
      "indices" : [ 50, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/EszhUSdiTh",
      "expanded_url" : "http:\/\/tinyurl.com\/qekbgmf",
      "display_url" : "tinyurl.com\/qekbgmf"
    } ]
  },
  "geo" : { },
  "id_str" : "443705906560524289",
  "text" : "RT @TonyMcEnery: A guest blog post from me on the #corpusMOOC for Macmillan. See: http:\/\/t.co\/EszhUSdiTh @MacDictionary @ESRC @CorpusSocial\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Macmillan Dictionary",
        "screen_name" : "MacDictionary",
        "indices" : [ 88, 102 ],
        "id_str" : "23783700",
        "id" : 23783700
      }, {
        "name" : "ESRC",
        "screen_name" : "ESRC",
        "indices" : [ 103, 108 ],
        "id_str" : "19393236",
        "id" : 19393236
      }, {
        "name" : "CASS",
        "screen_name" : "CorpusSocialSci",
        "indices" : [ 109, 125 ],
        "id_str" : "1326508478",
        "id" : 1326508478
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpusMOOC",
        "indices" : [ 33, 44 ]
      } ],
      "urls" : [ {
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/EszhUSdiTh",
        "expanded_url" : "http:\/\/tinyurl.com\/qekbgmf",
        "display_url" : "tinyurl.com\/qekbgmf"
      } ]
    },
    "geo" : { },
    "id_str" : "443704678707376128",
    "text" : "A guest blog post from me on the #corpusMOOC for Macmillan. See: http:\/\/t.co\/EszhUSdiTh @MacDictionary @ESRC @CorpusSocialSci",
    "id" : 443704678707376128,
    "created_at" : "2014-03-12 11:06:53 +0000",
    "user" : {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "protected" : false,
      "id_str" : "849729062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2676020930\/a4a1f40d56b447c9dfca1d7b9be4f4b4_normal.jpeg",
      "id" : 849729062,
      "verified" : false
    }
  },
  "id" : 443705906560524289,
  "created_at" : "2014-03-12 11:11:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Harbinson",
      "screen_name" : "DavidHarbinson",
      "indices" : [ 0, 15 ],
      "id_str" : "853078675",
      "id" : 853078675
    }, {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 16, 27 ],
      "id_str" : "282659955",
      "id" : 282659955
    }, {
      "name" : "BCSeminars",
      "screen_name" : "BCseminars",
      "indices" : [ 28, 39 ],
      "id_str" : "134099962",
      "id" : 134099962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "443673188220690432",
  "geo" : { },
  "id_str" : "443681583082786816",
  "in_reply_to_user_id" : 853078675,
  "text" : "@DavidHarbinson @teflerinha @BCseminars defo! the concrete output ideas particularly very useful, thanks :) a hard act for Adam K to follow!",
  "id" : 443681583082786816,
  "in_reply_to_status_id" : 443673188220690432,
  "created_at" : "2014-03-12 09:35:07 +0000",
  "in_reply_to_screen_name" : "DavidHarbinson",
  "in_reply_to_user_id_str" : "853078675",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 86, 102 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/cbd3k6d5Zd",
      "expanded_url" : "http:\/\/wp.me\/P2KE8s-cc",
      "display_url" : "wp.me\/P2KE8s-cc"
    } ]
  },
  "geo" : { },
  "id_str" : "443676081963290624",
  "text" : "The Trouble with Mr Bean (False friends and common errors) http:\/\/t.co\/cbd3k6d5Zd via @wordpressdotcom",
  "id" : 443676081963290624,
  "created_at" : "2014-03-12 09:13:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 3, 14 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELTchat",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 140 ],
      "url" : "http:\/\/t.co\/JtbBknER7M",
      "expanded_url" : "http:\/\/theotherthingsmatter.wordpress.com\/2014\/03\/12\/shaken-not-stirred-8-ways-to-start-your-class-different\/",
      "display_url" : "theotherthingsmatter.wordpress.com\/2014\/03\/12\/sha\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "443654312078884864",
  "text" : "RT @kevchanwow: Because the first minutes are (not always) that important: 8 ways to start an English class, a new post: http:\/\/t.co\/JtbBkn\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELTchat",
        "indices" : [ 130, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/JtbBknER7M",
        "expanded_url" : "http:\/\/theotherthingsmatter.wordpress.com\/2014\/03\/12\/shaken-not-stirred-8-ways-to-start-your-class-different\/",
        "display_url" : "theotherthingsmatter.wordpress.com\/2014\/03\/12\/sha\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "443651617561141248",
    "text" : "Because the first minutes are (not always) that important: 8 ways to start an English class, a new post: http:\/\/t.co\/JtbBknER7M \u2026 #ELTchat",
    "id" : 443651617561141248,
    "created_at" : "2014-03-12 07:36:02 +0000",
    "user" : {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "protected" : false,
      "id_str" : "144663117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/559618421839507456\/nPF7dP47_normal.jpeg",
      "id" : 144663117,
      "verified" : false
    }
  },
  "id" : 443654312078884864,
  "created_at" : "2014-03-12 07:46:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 0, 11 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/45ayNWWSLP",
      "expanded_url" : "https:\/\/plus.google.com\/104940199413423400545\/posts\/EdaXQdUQcJv",
      "display_url" : "plus.google.com\/10494019941342\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "443513134234734592",
  "text" : "#corpusmooc is a treasure chest Tim Johns program Contexts unearthed https:\/\/t.co\/45ayNWWSLP",
  "id" : 443513134234734592,
  "created_at" : "2014-03-11 22:25:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Aisha Brown",
      "screen_name" : "amyaishab",
      "indices" : [ 0, 10 ],
      "id_str" : "900029641",
      "id" : 900029641
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "443487287440326656",
  "geo" : { },
  "id_str" : "443488975328919553",
  "in_reply_to_user_id" : 900029641,
  "text" : "@amyaishab (^0^)",
  "id" : 443488975328919553,
  "in_reply_to_status_id" : 443487287440326656,
  "created_at" : "2014-03-11 20:49:46 +0000",
  "in_reply_to_screen_name" : "amyaishab",
  "in_reply_to_user_id_str" : "900029641",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 76, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/G8oVd3wd9s",
      "expanded_url" : "http:\/\/skell.sketchengine.co.uk\/",
      "display_url" : "skell.sketchengine.co.uk"
    } ]
  },
  "geo" : { },
  "id_str" : "443482485956292608",
  "text" : "sketchengine for elt now called sketchengine for ell http:\/\/t.co\/G8oVd3wd9s #corpusmooc",
  "id" : 443482485956292608,
  "created_at" : "2014-03-11 20:23:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "indices" : [ 3, 19 ],
      "id_str" : "1326508478",
      "id" : 1326508478
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/vCQwokSDt6",
      "expanded_url" : "http:\/\/cass.lancs.ac.uk\/?p=1064",
      "display_url" : "cass.lancs.ac.uk\/?p=1064"
    } ]
  },
  "geo" : { },
  "id_str" : "443398086896136192",
  "text" : "RT @CorpusSocialSci: Brand new DOOM Brief now available. Read fresh research on Twitter\u2019s reaction to the Benefits Britain live debate at h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/vCQwokSDt6",
        "expanded_url" : "http:\/\/cass.lancs.ac.uk\/?p=1064",
        "display_url" : "cass.lancs.ac.uk\/?p=1064"
      } ]
    },
    "geo" : { },
    "id_str" : "443354472711225344",
    "text" : "Brand new DOOM Brief now available. Read fresh research on Twitter\u2019s reaction to the Benefits Britain live debate at http:\/\/t.co\/vCQwokSDt6",
    "id" : 443354472711225344,
    "created_at" : "2014-03-11 11:55:18 +0000",
    "user" : {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "protected" : false,
      "id_str" : "1326508478",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3493899777\/ced36fe15c32eb911cbe3d64377524dc_normal.jpeg",
      "id" : 1326508478,
      "verified" : false
    }
  },
  "id" : 443398086896136192,
  "created_at" : "2014-03-11 14:48:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil Longwell",
      "screen_name" : "teacherphili",
      "indices" : [ 3, 16 ],
      "id_str" : "67863264",
      "id" : 67863264
    }, {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 78, 89 ],
      "id_str" : "282659955",
      "id" : 282659955
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 113, 117 ]
    }, {
      "text" : "authentic",
      "indices" : [ 118, 128 ]
    }, {
      "text" : "esl",
      "indices" : [ 129, 133 ]
    }, {
      "text" : "esol",
      "indices" : [ 134, 139 ]
    }, {
      "text" : "BradleyCooper",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/COdX5u0x5t",
      "expanded_url" : "http:\/\/bit.ly\/1nAMIoA",
      "display_url" : "bit.ly\/1nAMIoA"
    } ]
  },
  "geo" : { },
  "id_str" : "443392542315659264",
  "text" : "RT @teacherphili: How to use authentic texts \/ newspaper articles in class by @teflerinha http:\/\/t.co\/COdX5u0x5t #elt #authentic #esl #esol\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rachael Roberts",
        "screen_name" : "teflerinha",
        "indices" : [ 60, 71 ],
        "id_str" : "282659955",
        "id" : 282659955
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "elt",
        "indices" : [ 95, 99 ]
      }, {
        "text" : "authentic",
        "indices" : [ 100, 110 ]
      }, {
        "text" : "esl",
        "indices" : [ 111, 115 ]
      }, {
        "text" : "esol",
        "indices" : [ 116, 121 ]
      }, {
        "text" : "BradleyCooper",
        "indices" : [ 122, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/COdX5u0x5t",
        "expanded_url" : "http:\/\/bit.ly\/1nAMIoA",
        "display_url" : "bit.ly\/1nAMIoA"
      } ]
    },
    "geo" : { },
    "id_str" : "443041083510231040",
    "text" : "How to use authentic texts \/ newspaper articles in class by @teflerinha http:\/\/t.co\/COdX5u0x5t #elt #authentic #esl #esol #BradleyCooper",
    "id" : 443041083510231040,
    "created_at" : "2014-03-10 15:10:00 +0000",
    "user" : {
      "name" : "Phil Longwell",
      "screen_name" : "teacherphili",
      "protected" : false,
      "id_str" : "67863264",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637201716295933952\/4n4DCm-q_normal.jpg",
      "id" : 67863264,
      "verified" : false
    }
  },
  "id" : 443392542315659264,
  "created_at" : "2014-03-11 14:26:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 43, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443358574287536128",
  "text" : "lexical teddybears grt term picked up from #corpusmooc mentor discussion for those words sts tend to overuse",
  "id" : 443358574287536128,
  "created_at" : "2014-03-11 12:11:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boing Boing",
      "screen_name" : "BoingBoing",
      "indices" : [ 3, 14 ],
      "id_str" : "5971922",
      "id" : 5971922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/nZ5SEKCRBb",
      "expanded_url" : "http:\/\/boingboing.net\/2014\/03\/10\/bioengineer-builds-50-cent-pap.html",
      "display_url" : "boingboing.net\/2014\/03\/10\/bio\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "443352942545219584",
  "text" : "RT @BoingBoing: Stanford bioengineer Manu Prakash devised a pretty amazing 50-cent paper microscope http:\/\/t.co\/nZ5SEKCRBb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/nZ5SEKCRBb",
        "expanded_url" : "http:\/\/boingboing.net\/2014\/03\/10\/bioengineer-builds-50-cent-pap.html",
        "display_url" : "boingboing.net\/2014\/03\/10\/bio\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "443129969976549376",
    "text" : "Stanford bioengineer Manu Prakash devised a pretty amazing 50-cent paper microscope http:\/\/t.co\/nZ5SEKCRBb",
    "id" : 443129969976549376,
    "created_at" : "2014-03-10 21:03:12 +0000",
    "user" : {
      "name" : "Boing Boing",
      "screen_name" : "BoingBoing",
      "protected" : false,
      "id_str" : "5971922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616924998226153472\/0EfZYjr2_normal.png",
      "id" : 5971922,
      "verified" : true
    }
  },
  "id" : 443352942545219584,
  "created_at" : "2014-03-11 11:49:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Natallia Novikava",
      "screen_name" : "Natashetta",
      "indices" : [ 3, 14 ],
      "id_str" : "56308635",
      "id" : 56308635
    }, {
      "name" : "Lizzie Pinard",
      "screen_name" : "LizziePinard",
      "indices" : [ 139, 140 ],
      "id_str" : "287093748",
      "id" : 287093748
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "concordance",
      "indices" : [ 80, 92 ]
    }, {
      "text" : "elt",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/5jnE66KVLG",
      "expanded_url" : "http:\/\/wp.me\/p1wSAy-r6",
      "display_url" : "wp.me\/p1wSAy-r6"
    } ]
  },
  "geo" : { },
  "id_str" : "443333335944011776",
  "text" : "RT @Natashetta: Helping language learners become language researchers (part 3): #concordance activity outcomes http:\/\/t.co\/5jnE66KVLG via @\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lizzie Pinard",
        "screen_name" : "LizziePinard",
        "indices" : [ 122, 135 ],
        "id_str" : "287093748",
        "id" : 287093748
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "concordance",
        "indices" : [ 64, 76 ]
      }, {
        "text" : "elt",
        "indices" : [ 136, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/5jnE66KVLG",
        "expanded_url" : "http:\/\/wp.me\/p1wSAy-r6",
        "display_url" : "wp.me\/p1wSAy-r6"
      } ]
    },
    "geo" : { },
    "id_str" : "443300013460840449",
    "text" : "Helping language learners become language researchers (part 3): #concordance activity outcomes http:\/\/t.co\/5jnE66KVLG via @lizziepinard #elt",
    "id" : 443300013460840449,
    "created_at" : "2014-03-11 08:18:53 +0000",
    "user" : {
      "name" : "Natallia Novikava",
      "screen_name" : "Natashetta",
      "protected" : false,
      "id_str" : "56308635",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2877370292\/d6370dfafaa5506c53671f1bd1da0cdc_normal.jpeg",
      "id" : 56308635,
      "verified" : false
    }
  },
  "id" : 443333335944011776,
  "created_at" : "2014-03-11 10:31:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/VkIOfFoh4C",
      "expanded_url" : "http:\/\/ow.ly\/upVzC",
      "display_url" : "ow.ly\/upVzC"
    } ]
  },
  "geo" : { },
  "id_str" : "443139877644021760",
  "text" : "RT @medialens: Media Alert: The \u2018Professorial President\u2019 And The \u2018Small, Strutting Hard Man' http:\/\/t.co\/VkIOfFoh4C",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/VkIOfFoh4C",
        "expanded_url" : "http:\/\/ow.ly\/upVzC",
        "display_url" : "ow.ly\/upVzC"
      } ]
    },
    "geo" : { },
    "id_str" : "442999295583989760",
    "text" : "Media Alert: The \u2018Professorial President\u2019 And The \u2018Small, Strutting Hard Man' http:\/\/t.co\/VkIOfFoh4C",
    "id" : 442999295583989760,
    "created_at" : "2014-03-10 12:23:57 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 443139877644021760,
  "created_at" : "2014-03-10 21:42:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nic Subtirelu",
      "screen_name" : "linguisticpulse",
      "indices" : [ 3, 19 ],
      "id_str" : "1400748798",
      "id" : 1400748798
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "linguistics",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "banbossy",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/Mrlrlafd5C",
      "expanded_url" : "http:\/\/bit.ly\/1lqwfBX",
      "display_url" : "bit.ly\/1lqwfBX"
    } ]
  },
  "geo" : { },
  "id_str" : "443115856860823553",
  "text" : "RT @linguisticpulse: Following the calls to ban the word BOSSY, I gathered some data on the term's gendered use: http:\/\/t.co\/Mrlrlafd5C | #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "linguistics",
        "indices" : [ 117, 129 ]
      }, {
        "text" : "banbossy",
        "indices" : [ 130, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/Mrlrlafd5C",
        "expanded_url" : "http:\/\/bit.ly\/1lqwfBX",
        "display_url" : "bit.ly\/1lqwfBX"
      } ]
    },
    "geo" : { },
    "id_str" : "443112071605927937",
    "text" : "Following the calls to ban the word BOSSY, I gathered some data on the term's gendered use: http:\/\/t.co\/Mrlrlafd5C | #linguistics #banbossy",
    "id" : 443112071605927937,
    "created_at" : "2014-03-10 19:52:05 +0000",
    "user" : {
      "name" : "Nic Subtirelu",
      "screen_name" : "linguisticpulse",
      "protected" : false,
      "id_str" : "1400748798",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3609632834\/4ae2ef11e9cffa43e820f3ef7e18b016_normal.jpeg",
      "id" : 1400748798,
      "verified" : false
    }
  },
  "id" : 443115856860823553,
  "created_at" : "2014-03-10 20:07:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe McVeigh",
      "screen_name" : "EvilJoeMcVeigh",
      "indices" : [ 0, 15 ],
      "id_str" : "1327355143",
      "id" : 1327355143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "443109297241985024",
  "geo" : { },
  "id_str" : "443112117559119872",
  "in_reply_to_user_id" : 1327355143,
  "text" : "@EvilJoeMcVeigh sure he's not a shiftworker :?",
  "id" : 443112117559119872,
  "in_reply_to_status_id" : 443109297241985024,
  "created_at" : "2014-03-10 19:52:16 +0000",
  "in_reply_to_screen_name" : "EvilJoeMcVeigh",
  "in_reply_to_user_id_str" : "1327355143",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    }, {
      "name" : "Akira Murakami",
      "screen_name" : "mrkm_a",
      "indices" : [ 12, 19 ],
      "id_str" : "116922669",
      "id" : 116922669
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "443101807947313152",
  "geo" : { },
  "id_str" : "443102485696483328",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco @mrkm_a wordskew seems interesting anyone used full version?",
  "id" : 443102485696483328,
  "in_reply_to_status_id" : 443101807947313152,
  "created_at" : "2014-03-10 19:13:59 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IATEFL Head Office",
      "screen_name" : "iatefl",
      "indices" : [ 0, 7 ],
      "id_str" : "85042286",
      "id" : 85042286
    }, {
      "name" : "IATEFL BESIG",
      "screen_name" : "iatefl_besig",
      "indices" : [ 8, 21 ],
      "id_str" : "146913655",
      "id" : 146913655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "443039850468765696",
  "geo" : { },
  "id_str" : "443088944633511936",
  "in_reply_to_user_id" : 85042286,
  "text" : "@iatefl @iatefl_besig resolution alert :)",
  "id" : 443088944633511936,
  "in_reply_to_status_id" : 443039850468765696,
  "created_at" : "2014-03-10 18:20:11 +0000",
  "in_reply_to_screen_name" : "iatefl",
  "in_reply_to_user_id_str" : "85042286",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IATEFL Head Office",
      "screen_name" : "iatefl",
      "indices" : [ 3, 10 ],
      "id_str" : "85042286",
      "id" : 85042286
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 12, 19 ]
    }, {
      "text" : "Harrogate",
      "indices" : [ 41, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/JElfEsLirk",
      "expanded_url" : "http:\/\/instagram.com\/p\/lXdCeokFpZ\/",
      "display_url" : "instagram.com\/p\/lXdCeokFpZ\/"
    } ]
  },
  "geo" : { },
  "id_str" : "443088898949144576",
  "text" : "RT @iatefl: #IATEFL Annual Conference in #Harrogate\nPlenary Speaker\nMichael Hoey http:\/\/t.co\/JElfEsLirk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IATEFL",
        "indices" : [ 0, 7 ]
      }, {
        "text" : "Harrogate",
        "indices" : [ 29, 39 ]
      } ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/JElfEsLirk",
        "expanded_url" : "http:\/\/instagram.com\/p\/lXdCeokFpZ\/",
        "display_url" : "instagram.com\/p\/lXdCeokFpZ\/"
      } ]
    },
    "geo" : { },
    "id_str" : "443039850468765696",
    "text" : "#IATEFL Annual Conference in #Harrogate\nPlenary Speaker\nMichael Hoey http:\/\/t.co\/JElfEsLirk",
    "id" : 443039850468765696,
    "created_at" : "2014-03-10 15:05:06 +0000",
    "user" : {
      "name" : "IATEFL Head Office",
      "screen_name" : "iatefl",
      "protected" : false,
      "id_str" : "85042286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/489715570246291456\/kDRiQdXi_normal.png",
      "id" : 85042286,
      "verified" : false
    }
  },
  "id" : 443088898949144576,
  "created_at" : "2014-03-10 18:20:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Moravec",
      "screen_name" : "ProfessMoravec",
      "indices" : [ 3, 18 ],
      "id_str" : "369529173",
      "id" : 369529173
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusMOOC",
      "indices" : [ 20, 31 ]
    }, {
      "text" : "moocinpublic",
      "indices" : [ 143, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 126, 144 ],
      "url" : "http:\/\/t.co\/HTpprABNEo",
      "expanded_url" : "http:\/\/bit.ly\/1b2aLoU",
      "display_url" : "bit.ly\/1b2aLoU"
    } ]
  },
  "geo" : { },
  "id_str" : "443035774997762048",
  "text" : "RT @ProfessMoravec: #corpusMOOC wk 6 belatedly blogged I fail 2 follow instructions use Regex &amp; find  interesting results http:\/\/t.co\/HTppr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpusMOOC",
        "indices" : [ 0, 11 ]
      }, {
        "text" : "moocinpublic",
        "indices" : [ 129, 142 ]
      } ],
      "urls" : [ {
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/HTpprABNEo",
        "expanded_url" : "http:\/\/bit.ly\/1b2aLoU",
        "display_url" : "bit.ly\/1b2aLoU"
      } ]
    },
    "geo" : { },
    "id_str" : "443032523489435648",
    "text" : "#corpusMOOC wk 6 belatedly blogged I fail 2 follow instructions use Regex &amp; find  interesting results http:\/\/t.co\/HTpprABNEo #moocinpublic",
    "id" : 443032523489435648,
    "created_at" : "2014-03-10 14:35:59 +0000",
    "user" : {
      "name" : "Michelle Moravec",
      "screen_name" : "ProfessMoravec",
      "protected" : false,
      "id_str" : "369529173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751214483113013248\/qxxQX7mg_normal.jpg",
      "id" : 369529173,
      "verified" : false
    }
  },
  "id" : 443035774997762048,
  "created_at" : "2014-03-10 14:48:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Andrews",
      "screen_name" : "patrickelt",
      "indices" : [ 3, 14 ],
      "id_str" : "2292503990",
      "id" : 2292503990
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 46, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/p96KqlEV1A",
      "expanded_url" : "http:\/\/patrickdandrews.blogspot.co.uk\/2014\/03\/corpus-mooc-continued-chapter-by-paul.html",
      "display_url" : "patrickdandrews.blogspot.co.uk\/2014\/03\/corpus\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "442969351768260608",
  "text" : "RT @patrickelt: Reactions to a reading on the #corpusmooc http:\/\/t.co\/p96KqlEV1A",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpusmooc",
        "indices" : [ 30, 41 ]
      } ],
      "urls" : [ {
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/p96KqlEV1A",
        "expanded_url" : "http:\/\/patrickdandrews.blogspot.co.uk\/2014\/03\/corpus-mooc-continued-chapter-by-paul.html",
        "display_url" : "patrickdandrews.blogspot.co.uk\/2014\/03\/corpus\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "442967761040723968",
    "text" : "Reactions to a reading on the #corpusmooc http:\/\/t.co\/p96KqlEV1A",
    "id" : 442967761040723968,
    "created_at" : "2014-03-10 10:18:38 +0000",
    "user" : {
      "name" : "Patrick Andrews",
      "screen_name" : "patrickelt",
      "protected" : false,
      "id_str" : "2292503990",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/552069409120866304\/VqwBK4Lm_normal.jpeg",
      "id" : 2292503990,
      "verified" : false
    }
  },
  "id" : 442969351768260608,
  "created_at" : "2014-03-10 10:24:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 30, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "442928211136380928",
  "text" : "new terminology for me thx to #corpusmooc, long (with by) and short passives (with no by)",
  "id" : 442928211136380928,
  "created_at" : "2014-03-10 07:41:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iwona",
      "screen_name" : "yvetteinmb",
      "indices" : [ 0, 11 ],
      "id_str" : "90695737",
      "id" : 90695737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/OIPVpr7YJN",
      "expanded_url" : "https:\/\/plus.google.com\/104940199413423400545\/posts\/dRTRAE78N13",
      "display_url" : "plus.google.com\/10494019941342\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "442684671587921920",
  "geo" : { },
  "id_str" : "442692687058456576",
  "in_reply_to_user_id" : 90695737,
  "text" : "@yvetteinmb hi iwona thx fr mention have written about an aspect of this tool on G+ CL site if u not seen it already https:\/\/t.co\/OIPVpr7YJN",
  "id" : 442692687058456576,
  "in_reply_to_status_id" : 442684671587921920,
  "created_at" : "2014-03-09 16:05:36 +0000",
  "in_reply_to_screen_name" : "yvetteinmb",
  "in_reply_to_user_id_str" : "90695737",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Arnold",
      "screen_name" : "johnarnold723",
      "indices" : [ 0, 14 ],
      "id_str" : "1525232047",
      "id" : 1525232047
    }, {
      "name" : "BELTA Belgium",
      "screen_name" : "BELTABelgium",
      "indices" : [ 15, 28 ],
      "id_str" : "884934438",
      "id" : 884934438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/dZaZsvoSpK",
      "expanded_url" : "http:\/\/www.lextutor.ca",
      "display_url" : "lextutor.ca"
    } ]
  },
  "in_reply_to_status_id_str" : "442683386503897089",
  "geo" : { },
  "id_str" : "442691325092433920",
  "in_reply_to_user_id" : 1525232047,
  "text" : "@johnarnold723 @BELTABelgium not sure what textutor is but there is a lextutor http:\/\/t.co\/dZaZsvoSpK",
  "id" : 442691325092433920,
  "in_reply_to_status_id" : 442683386503897089,
  "created_at" : "2014-03-09 16:00:11 +0000",
  "in_reply_to_screen_name" : "johnarnold723",
  "in_reply_to_user_id_str" : "1525232047",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Arnold",
      "screen_name" : "johnarnold723",
      "indices" : [ 0, 14 ],
      "id_str" : "1525232047",
      "id" : 1525232047
    }, {
      "name" : "BELTA Belgium",
      "screen_name" : "BELTABelgium",
      "indices" : [ 15, 28 ],
      "id_str" : "884934438",
      "id" : 884934438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "442688347677659136",
  "geo" : { },
  "id_str" : "442690411979866113",
  "in_reply_to_user_id" : 1525232047,
  "text" : "@johnarnold723 @BELTABelgium just to clarify this pdf is about manual concordancing",
  "id" : 442690411979866113,
  "in_reply_to_status_id" : 442688347677659136,
  "created_at" : "2014-03-09 15:56:33 +0000",
  "in_reply_to_screen_name" : "johnarnold723",
  "in_reply_to_user_id_str" : "1525232047",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Arnold",
      "screen_name" : "johnarnold723",
      "indices" : [ 0, 14 ],
      "id_str" : "1525232047",
      "id" : 1525232047
    }, {
      "name" : "BELTA Belgium",
      "screen_name" : "BELTABelgium",
      "indices" : [ 15, 28 ],
      "id_str" : "884934438",
      "id" : 884934438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "442686520999575552",
  "geo" : { },
  "id_str" : "442689292708900864",
  "in_reply_to_user_id" : 1525232047,
  "text" : "@johnarnold723 @BELTABelgium thanks for share :)",
  "id" : 442689292708900864,
  "in_reply_to_status_id" : 442686520999575552,
  "created_at" : "2014-03-09 15:52:06 +0000",
  "in_reply_to_screen_name" : "johnarnold723",
  "in_reply_to_user_id_str" : "1525232047",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BELTA Belgium",
      "screen_name" : "BELTABelgium",
      "indices" : [ 38, 51 ],
      "id_str" : "884934438",
      "id" : 884934438
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 0, 11 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/oaMfPGiU2r",
      "expanded_url" : "http:\/\/lancelot.adobeconnect.com\/belta",
      "display_url" : "lancelot.adobeconnect.com\/belta"
    } ]
  },
  "geo" : { },
  "id_str" : "442675241392046080",
  "text" : "#corpusmooc folks maybe interested in @BELTABelgium Corpora in classroom webinar about to start http:\/\/t.co\/oaMfPGiU2r",
  "id" : 442675241392046080,
  "created_at" : "2014-03-09 14:56:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "indices" : [ 0, 13 ],
      "id_str" : "1685397408",
      "id" : 1685397408
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "surelywillbeagainstterms",
      "indices" : [ 44, 69 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "442281109574144000",
  "geo" : { },
  "id_str" : "442281990419922944",
  "in_reply_to_user_id" : 1685397408,
  "text" : "@harrisonmike it's got a nice ring to it :) #surelywillbeagainstterms",
  "id" : 442281990419922944,
  "in_reply_to_status_id" : 442281109574144000,
  "created_at" : "2014-03-08 12:53:38 +0000",
  "in_reply_to_screen_name" : "harrisonmike",
  "in_reply_to_user_id_str" : "1685397408",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "442280047479513088",
  "geo" : { },
  "id_str" : "442280349444628480",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava bugger have to pay though",
  "id" : 442280349444628480,
  "in_reply_to_status_id" : 442280047479513088,
  "created_at" : "2014-03-08 12:47:07 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "COCA",
      "indices" : [ 27, 32 ]
    }, {
      "text" : "corpusmooc",
      "indices" : [ 33, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/Pnohj3LUdQ",
      "expanded_url" : "http:\/\/corpus.byu.edu\/full-text\/",
      "display_url" : "corpus.byu.edu\/full-text\/"
    } ]
  },
  "geo" : { },
  "id_str" : "442280047479513088",
  "text" : "woah full text download of #COCA #corpusmooc http:\/\/t.co\/Pnohj3LUdQ",
  "id" : 442280047479513088,
  "created_at" : "2014-03-08 12:45:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "Elizabeth Anne",
      "screen_name" : "eannegrenoble",
      "indices" : [ 12, 26 ],
      "id_str" : "19869781",
      "id" : 19869781
    }, {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "indices" : [ 27, 39 ],
      "id_str" : "849729062",
      "id" : 849729062
    }, {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 40, 51 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "442251879960301568",
  "geo" : { },
  "id_str" : "442253052285038594",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan @eannegrenoble @TonyMcEnery @kevchanwow 2 afaik",
  "id" : 442253052285038594,
  "in_reply_to_status_id" : 442251879960301568,
  "created_at" : "2014-03-08 10:58:38 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jo Sayers",
      "screen_name" : "jo_sayers",
      "indices" : [ 0, 10 ],
      "id_str" : "87176766",
      "id" : 87176766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441923398017748994",
  "geo" : { },
  "id_str" : "442005953698103296",
  "in_reply_to_user_id" : 87176766,
  "text" : "@jo_sayers good thx looking fwd to warm weekend , enjoy yours :)",
  "id" : 442005953698103296,
  "in_reply_to_status_id" : 441923398017748994,
  "created_at" : "2014-03-07 18:36:46 +0000",
  "in_reply_to_screen_name" : "jo_sayers",
  "in_reply_to_user_id_str" : "87176766",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jo Sayers",
      "screen_name" : "jo_sayers",
      "indices" : [ 0, 10 ],
      "id_str" : "87176766",
      "id" : 87176766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441919059614257152",
  "geo" : { },
  "id_str" : "441920217594490880",
  "in_reply_to_user_id" : 87176766,
  "text" : "@jo_sayers nice one jon,  you got yr employer to sponser u in the end?",
  "id" : 441920217594490880,
  "in_reply_to_status_id" : 441919059614257152,
  "created_at" : "2014-03-07 12:56:05 +0000",
  "in_reply_to_screen_name" : "jo_sayers",
  "in_reply_to_user_id_str" : "87176766",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "Elizabeth Anne",
      "screen_name" : "eannegrenoble",
      "indices" : [ 12, 26 ],
      "id_str" : "19869781",
      "id" : 19869781
    }, {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "indices" : [ 27, 39 ],
      "id_str" : "849729062",
      "id" : 849729062
    }, {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 40, 51 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441892909714251776",
  "geo" : { },
  "id_str" : "441902024264019968",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan @eannegrenoble @TonyMcEnery @kevchanwow that article is the other list is based on word families",
  "id" : 441902024264019968,
  "in_reply_to_status_id" : 441892909714251776,
  "created_at" : "2014-03-07 11:43:47 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "Elizabeth Anne",
      "screen_name" : "eannegrenoble",
      "indices" : [ 12, 26 ],
      "id_str" : "19869781",
      "id" : 19869781
    }, {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "indices" : [ 27, 39 ],
      "id_str" : "849729062",
      "id" : 849729062
    }, {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 40, 51 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/KF1NnY8XGr",
      "expanded_url" : "http:\/\/applij.oxfordjournals.org\/cgi\/content\/long\/amt018v1",
      "display_url" : "applij.oxfordjournals.org\/cgi\/content\/lo\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "441886740929069056",
  "geo" : { },
  "id_str" : "441890199250145281",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan @eannegrenoble @TonyMcEnery @kevchanwow essentially lemmas easier for beginners than word families c  http:\/\/t.co\/KF1NnY8XGr",
  "id" : 441890199250145281,
  "in_reply_to_status_id" : 441886740929069056,
  "created_at" : "2014-03-07 10:56:48 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Phipps",
      "screen_name" : "lousylinguist",
      "indices" : [ 3, 17 ],
      "id_str" : "48459936",
      "id" : 48459936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/wcNeHo7RoH",
      "expanded_url" : "http:\/\/m.huffpost.com\/us\/entry\/4912793\/",
      "display_url" : "m.huffpost.com\/us\/entry\/49127\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "441866901430763520",
  "text" : "RT @lousylinguist: OMG! Gibberish woman made a sequel,  and she does Aussie English, Scottish,  Irish, but NOT Dutch... http:\/\/t.co\/wcNeHo7\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/wcNeHo7RoH",
        "expanded_url" : "http:\/\/m.huffpost.com\/us\/entry\/4912793\/",
        "display_url" : "m.huffpost.com\/us\/entry\/49127\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "441789479972773888",
    "text" : "OMG! Gibberish woman made a sequel,  and she does Aussie English, Scottish,  Irish, but NOT Dutch... http:\/\/t.co\/wcNeHo7RoH",
    "id" : 441789479972773888,
    "created_at" : "2014-03-07 04:16:34 +0000",
    "user" : {
      "name" : "Christopher Phipps",
      "screen_name" : "lousylinguist",
      "protected" : false,
      "id_str" : "48459936",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750789987113660416\/2IPugaM9_normal.jpg",
      "id" : 48459936,
      "verified" : false
    }
  },
  "id" : 441866901430763520,
  "created_at" : "2014-03-07 09:24:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Education Lens",
      "screen_name" : "EducationLens",
      "indices" : [ 3, 17 ],
      "id_str" : "2373851498",
      "id" : 2373851498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/CclIwhgdHz",
      "expanded_url" : "http:\/\/wp.me\/p4n2UG-1X",
      "display_url" : "wp.me\/p4n2UG-1X"
    } ]
  },
  "geo" : { },
  "id_str" : "441812135732330496",
  "text" : "RT @EducationLens: 12-Year Old Explains Why Most Countries Are in\u00A0Debt http:\/\/t.co\/CclIwhgdHz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/CclIwhgdHz",
        "expanded_url" : "http:\/\/wp.me\/p4n2UG-1X",
        "display_url" : "wp.me\/p4n2UG-1X"
      } ]
    },
    "geo" : { },
    "id_str" : "441630353552191488",
    "text" : "12-Year Old Explains Why Most Countries Are in\u00A0Debt http:\/\/t.co\/CclIwhgdHz",
    "id" : 441630353552191488,
    "created_at" : "2014-03-06 17:44:16 +0000",
    "user" : {
      "name" : "Education Lens",
      "screen_name" : "EducationLens",
      "protected" : false,
      "id_str" : "2373851498",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/441288618347220992\/sxO0iZf9_normal.jpeg",
      "id" : 2373851498,
      "verified" : false
    }
  },
  "id" : 441812135732330496,
  "created_at" : "2014-03-07 05:46:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    }, {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 127, 140 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/Jb1ro44ZsE",
      "expanded_url" : "http:\/\/wp.me\/puOTr-r4",
      "display_url" : "wp.me\/puOTr-r4"
    } ]
  },
  "geo" : { },
  "id_str" : "441811732718436352",
  "text" : "RT @johnwhilley: YOUNG PALESTINIAN PLAYERS ATTACKED AS GLOBAL PETITION TELLS FIFA \"SUSPEND ISRAEL\": http:\/\/t.co\/Jb1ro44ZsE via @wordpressdo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "WordPress.com",
        "screen_name" : "wordpressdotcom",
        "indices" : [ 110, 126 ],
        "id_str" : "823905",
        "id" : 823905
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/Jb1ro44ZsE",
        "expanded_url" : "http:\/\/wp.me\/puOTr-r4",
        "display_url" : "wp.me\/puOTr-r4"
      } ]
    },
    "geo" : { },
    "id_str" : "441729816224481282",
    "text" : "YOUNG PALESTINIAN PLAYERS ATTACKED AS GLOBAL PETITION TELLS FIFA \"SUSPEND ISRAEL\": http:\/\/t.co\/Jb1ro44ZsE via @wordpressdotcom",
    "id" : 441729816224481282,
    "created_at" : "2014-03-07 00:19:29 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 441811732718436352,
  "created_at" : "2014-03-07 05:45:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthias Strubel",
      "screen_name" : "MatthiasStrubel",
      "indices" : [ 0, 16 ],
      "id_str" : "563084632",
      "id" : 563084632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/XHY9aCuClI",
      "expanded_url" : "http:\/\/fun2code-blog.blogspot.fr\/2011\/12\/piratebox-on-android.html",
      "display_url" : "fun2code-blog.blogspot.fr\/2011\/12\/pirate\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "441732597337423872",
  "in_reply_to_user_id" : 563084632,
  "text" : "@MatthiasStrubel hi do u know how to change dns from pirate.box i am using this setup http:\/\/t.co\/XHY9aCuClI thanks!",
  "id" : 441732597337423872,
  "created_at" : "2014-03-07 00:30:32 +0000",
  "in_reply_to_screen_name" : "MatthiasStrubel",
  "in_reply_to_user_id_str" : "563084632",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Whyte",
      "screen_name" : "eslwriter",
      "indices" : [ 3, 13 ],
      "id_str" : "187481025",
      "id" : 187481025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/txm37yBxdF",
      "expanded_url" : "http:\/\/nyti.ms\/1gdi0Mc",
      "display_url" : "nyti.ms\/1gdi0Mc"
    } ]
  },
  "geo" : { },
  "id_str" : "441710085371609088",
  "text" : "RT @eslwriter: Serious Silliness:  High School Reading and Writing Inspired by Dr. Seuss http:\/\/t.co\/txm37yBxdF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/txm37yBxdF",
        "expanded_url" : "http:\/\/nyti.ms\/1gdi0Mc",
        "display_url" : "nyti.ms\/1gdi0Mc"
      } ]
    },
    "geo" : { },
    "id_str" : "441705370826711040",
    "text" : "Serious Silliness:  High School Reading and Writing Inspired by Dr. Seuss http:\/\/t.co\/txm37yBxdF",
    "id" : 441705370826711040,
    "created_at" : "2014-03-06 22:42:21 +0000",
    "user" : {
      "name" : "Rob Whyte",
      "screen_name" : "eslwriter",
      "protected" : false,
      "id_str" : "187481025",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2682332531\/cd44653e5843c08c6938f41dc15668bc_normal.png",
      "id" : 187481025,
      "verified" : false
    }
  },
  "id" : 441710085371609088,
  "created_at" : "2014-03-06 23:01:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthias Strubel",
      "screen_name" : "MatthiasStrubel",
      "indices" : [ 0, 16 ],
      "id_str" : "563084632",
      "id" : 563084632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441706536633909248",
  "geo" : { },
  "id_str" : "441707942560428032",
  "in_reply_to_user_id" : 563084632,
  "text" : "@MatthiasStrubel yet to find out, 1st rev txt on send button did result in less meme gifs, maybe 2nd rev txt chat will result more English!",
  "id" : 441707942560428032,
  "in_reply_to_status_id" : 441706536633909248,
  "created_at" : "2014-03-06 22:52:34 +0000",
  "in_reply_to_screen_name" : "MatthiasStrubel",
  "in_reply_to_user_id_str" : "563084632",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Spencer",
      "screen_name" : "edrethink",
      "indices" : [ 3, 13 ],
      "id_str" : "3057524486",
      "id" : 3057524486
    }, {
      "name" : "Luke",
      "screen_name" : "lukeneff",
      "indices" : [ 45, 54 ],
      "id_str" : "12188312",
      "id" : 12188312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/xrveasOSWR",
      "expanded_url" : "http:\/\/designthroughstorytelling.net\/periodic\/",
      "display_url" : "designthroughstorytelling.net\/periodic\/"
    } ]
  },
  "geo" : { },
  "id_str" : "441701733094662144",
  "text" : "RT @edrethink: I love this thing. Hat tip to @lukeneff http:\/\/t.co\/xrveasOSWR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Luke",
        "screen_name" : "lukeneff",
        "indices" : [ 30, 39 ],
        "id_str" : "12188312",
        "id" : 12188312
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 62 ],
        "url" : "http:\/\/t.co\/xrveasOSWR",
        "expanded_url" : "http:\/\/designthroughstorytelling.net\/periodic\/",
        "display_url" : "designthroughstorytelling.net\/periodic\/"
      } ]
    },
    "geo" : { },
    "id_str" : "441701394643316736",
    "text" : "I love this thing. Hat tip to @lukeneff http:\/\/t.co\/xrveasOSWR",
    "id" : 441701394643316736,
    "created_at" : "2014-03-06 22:26:33 +0000",
    "user" : {
      "name" : "John Spencer",
      "screen_name" : "spencerideas",
      "protected" : false,
      "id_str" : "18389166",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751913559160795136\/eU7NtYy4_normal.jpg",
      "id" : 18389166,
      "verified" : false
    }
  },
  "id" : 441701733094662144,
  "created_at" : "2014-03-06 22:27:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Idibon",
      "screen_name" : "idibon",
      "indices" : [ 3, 10 ],
      "id_str" : "749992082",
      "id" : 749992082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/zx7gxurSSp",
      "expanded_url" : "http:\/\/ow.ly\/ujKBE",
      "display_url" : "ow.ly\/ujKBE"
    }, {
      "indices" : [ 121, 140 ],
      "url" : "http:\/\/t.co\/88OG3hdSWL",
      "expanded_url" : "http:\/\/mojim.com\/usy112407x4x3.htm",
      "display_url" : "mojim.com\/usy112407x4x3.\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "441698034255425536",
  "text" : "RT @idibon: Heavy metal + Japanese teen pop = \"Gimme chocolate\", catchy refrain at 1min: http:\/\/t.co\/zx7gxurSSp (lyrics: http:\/\/t.co\/88OG3h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/zx7gxurSSp",
        "expanded_url" : "http:\/\/ow.ly\/ujKBE",
        "display_url" : "ow.ly\/ujKBE"
      }, {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/88OG3hdSWL",
        "expanded_url" : "http:\/\/mojim.com\/usy112407x4x3.htm",
        "display_url" : "mojim.com\/usy112407x4x3.\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "441670839092936704",
    "text" : "Heavy metal + Japanese teen pop = \"Gimme chocolate\", catchy refrain at 1min: http:\/\/t.co\/zx7gxurSSp (lyrics: http:\/\/t.co\/88OG3hdSWL)",
    "id" : 441670839092936704,
    "created_at" : "2014-03-06 20:25:08 +0000",
    "user" : {
      "name" : "Idibon",
      "screen_name" : "idibon",
      "protected" : false,
      "id_str" : "749992082",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/577899744749481985\/ospcUqfV_normal.jpeg",
      "id" : 749992082,
      "verified" : false
    }
  },
  "id" : 441698034255425536,
  "created_at" : "2014-03-06 22:13:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 120, 136 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/IkfxL20Nxg",
      "expanded_url" : "http:\/\/wp.me\/p4c373-b1",
      "display_url" : "wp.me\/p4c373-b1"
    } ]
  },
  "geo" : { },
  "id_str" : "441685835411238912",
  "text" : "On Freire, Hirsch and indoctrination: falling in love with statues is not always a good idea http:\/\/t.co\/IkfxL20Nxg via @wordpressdotcom",
  "id" : 441685835411238912,
  "created_at" : "2014-03-06 21:24:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 3, 18 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 77, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/743QgHVi5e",
      "expanded_url" : "http:\/\/wp.me\/p3X7Ks-GG",
      "display_url" : "wp.me\/p3X7Ks-GG"
    } ]
  },
  "geo" : { },
  "id_str" : "441670372271063042",
  "text" : "RT @MrChrisJWilson: How do you Feel after a Bad Lesson? - I need your voice! #eltchat http:\/\/t.co\/743QgHVi5e",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "eltchat",
        "indices" : [ 57, 65 ]
      } ],
      "urls" : [ {
        "indices" : [ 66, 88 ],
        "url" : "http:\/\/t.co\/743QgHVi5e",
        "expanded_url" : "http:\/\/wp.me\/p3X7Ks-GG",
        "display_url" : "wp.me\/p3X7Ks-GG"
      } ]
    },
    "geo" : { },
    "id_str" : "441649263676637184",
    "text" : "How do you Feel after a Bad Lesson? - I need your voice! #eltchat http:\/\/t.co\/743QgHVi5e",
    "id" : 441649263676637184,
    "created_at" : "2014-03-06 18:59:24 +0000",
    "user" : {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "protected" : false,
      "id_str" : "20760283",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744952885595758592\/H4bmsUn3_normal.jpg",
      "id" : 20760283,
      "verified" : false
    }
  },
  "id" : 441670372271063042,
  "created_at" : "2014-03-06 20:23:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Serveis Ling\u00FC\u00EDstics",
      "screen_name" : "SLBCoop",
      "indices" : [ 0, 8 ],
      "id_str" : "2365399801",
      "id" : 2365399801
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/s21rQU8ZQn",
      "expanded_url" : "http:\/\/antonynbritt.files.wordpress.com\/2012\/09\/sep-16-pauline.jpg",
      "display_url" : "antonynbritt.files.wordpress.com\/2012\/09\/sep-16\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "441611613536542720",
  "geo" : { },
  "id_str" : "441615322144321538",
  "in_reply_to_user_id" : 2365399801,
  "text" : "@SLBCoop lordy u sure this is not parody? maybe these consultants went to Pauline for their training? http:\/\/t.co\/s21rQU8ZQn",
  "id" : 441615322144321538,
  "in_reply_to_status_id" : 441611613536542720,
  "created_at" : "2014-03-06 16:44:32 +0000",
  "in_reply_to_screen_name" : "SLBCoop",
  "in_reply_to_user_id_str" : "2365399801",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Seymour",
      "screen_name" : "leninology",
      "indices" : [ 3, 14 ],
      "id_str" : "15557246",
      "id" : 15557246
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/kh5MxnuHIX",
      "expanded_url" : "http:\/\/www.leninology.com\/2014\/03\/ukraine-against-infantile-realpolitik.html",
      "display_url" : "leninology.com\/2014\/03\/ukrain\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "441612776424079360",
  "text" : "RT @leninology: Ukraine: against infantile realpolitik http:\/\/t.co\/kh5MxnuHIX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 61 ],
        "url" : "http:\/\/t.co\/kh5MxnuHIX",
        "expanded_url" : "http:\/\/www.leninology.com\/2014\/03\/ukraine-against-infantile-realpolitik.html",
        "display_url" : "leninology.com\/2014\/03\/ukrain\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "441362024573177856",
    "text" : "Ukraine: against infantile realpolitik http:\/\/t.co\/kh5MxnuHIX",
    "id" : 441362024573177856,
    "created_at" : "2014-03-05 23:58:01 +0000",
    "user" : {
      "name" : "Richard Seymour",
      "screen_name" : "leninology",
      "protected" : false,
      "id_str" : "15557246",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762344914583781377\/UDn8tMrp_normal.jpg",
      "id" : 15557246,
      "verified" : false
    }
  },
  "id" : 441612776424079360,
  "created_at" : "2014-03-06 16:34:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adi Rajan",
      "screen_name" : "adi_rajan",
      "indices" : [ 0, 10 ],
      "id_str" : "1011323449",
      "id" : 1011323449
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "441551710931005440",
  "geo" : { },
  "id_str" : "441553174542163968",
  "in_reply_to_user_id" : 1011323449,
  "text" : "@adi_rajan nope just the demo, i can see it coming in handy when short of time, though not sure very handy for language learning",
  "id" : 441553174542163968,
  "in_reply_to_status_id" : 441551710931005440,
  "created_at" : "2014-03-06 12:37:35 +0000",
  "in_reply_to_screen_name" : "adi_rajan",
  "in_reply_to_user_id_str" : "1011323449",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Graham",
      "screen_name" : "onalifeglug",
      "indices" : [ 3, 15 ],
      "id_str" : "19516039",
      "id" : 19516039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/jBTcEIyn8M",
      "expanded_url" : "http:\/\/elitedaily.com\/news\/technology\/this-insane-new-app-will-allow-you-to-read-novels-in-under-90-minutes\/",
      "display_url" : "elitedaily.com\/news\/technolog\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "441550389058744320",
  "text" : "RT @onalifeglug: New app allows you to read at 500wpm - i.e., read a novel in 90 minutes http:\/\/t.co\/jBTcEIyn8M (includes demonstration)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/jBTcEIyn8M",
        "expanded_url" : "http:\/\/elitedaily.com\/news\/technology\/this-insane-new-app-will-allow-you-to-read-novels-in-under-90-minutes\/",
        "display_url" : "elitedaily.com\/news\/technolog\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "441548418591498241",
    "text" : "New app allows you to read at 500wpm - i.e., read a novel in 90 minutes http:\/\/t.co\/jBTcEIyn8M (includes demonstration)",
    "id" : 441548418591498241,
    "created_at" : "2014-03-06 12:18:41 +0000",
    "user" : {
      "name" : "Graham",
      "screen_name" : "onalifeglug",
      "protected" : false,
      "id_str" : "19516039",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/586664577095622656\/NwBHdlk5_normal.jpg",
      "id" : 19516039,
      "verified" : false
    }
  },
  "id" : 441550389058744320,
  "created_at" : "2014-03-06 12:26:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Kern\u24C4h\u24B6n",
      "screen_name" : "dkernohan",
      "indices" : [ 3, 13 ],
      "id_str" : "12219232",
      "id" : 12219232
    }, {
      "name" : "audioBoo",
      "screen_name" : "audioBoo",
      "indices" : [ 79, 88 ],
      "id_str" : "2745269166",
      "id" : 2745269166
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/QkwTDOLhqf",
      "expanded_url" : "https:\/\/audioboo.fm\/boos\/1969683-the-pearson-bird-is-always-learning",
      "display_url" : "audioboo.fm\/boos\/1969683-t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "441522812835356673",
  "text" : "RT @dkernohan: The Pearson Bird Is Always Learning https:\/\/t.co\/QkwTDOLhqf via @audioboo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/audioboom.com\" rel=\"nofollow\"\u003EaudioBoom\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "audioBoo",
        "screen_name" : "audioBoo",
        "indices" : [ 64, 73 ],
        "id_str" : "2745269166",
        "id" : 2745269166
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 36, 59 ],
        "url" : "https:\/\/t.co\/QkwTDOLhqf",
        "expanded_url" : "https:\/\/audioboo.fm\/boos\/1969683-the-pearson-bird-is-always-learning",
        "display_url" : "audioboo.fm\/boos\/1969683-t\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "441335479133560832",
    "text" : "The Pearson Bird Is Always Learning https:\/\/t.co\/QkwTDOLhqf via @audioboo",
    "id" : 441335479133560832,
    "created_at" : "2014-03-05 22:12:32 +0000",
    "user" : {
      "name" : "David Kern\u24C4h\u24B6n",
      "screen_name" : "dkernohan",
      "protected" : false,
      "id_str" : "12219232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/757702202437804032\/4Xrm7IIe_normal.jpg",
      "id" : 12219232,
      "verified" : false
    }
  },
  "id" : 441522812835356673,
  "created_at" : "2014-03-06 10:36:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Weller",
      "screen_name" : "mweller",
      "indices" : [ 3, 11 ],
      "id_str" : "7127162",
      "id" : 7127162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/NY6R77wcEM",
      "expanded_url" : "http:\/\/www.bjp-online.com\/2014\/03\/getty-images-makes-35-million-images-free-in-fight-against-copyright-infringement\/",
      "display_url" : "bjp-online.com\/2014\/03\/getty-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "441521867896418306",
  "text" : "RT @mweller: Getty Images makes 35m images free to use http:\/\/t.co\/NY6R77wcEM - there is no excuse for clipart now",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/NY6R77wcEM",
        "expanded_url" : "http:\/\/www.bjp-online.com\/2014\/03\/getty-images-makes-35-million-images-free-in-fight-against-copyright-infringement\/",
        "display_url" : "bjp-online.com\/2014\/03\/getty-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "441483965107814400",
    "text" : "Getty Images makes 35m images free to use http:\/\/t.co\/NY6R77wcEM - there is no excuse for clipart now",
    "id" : 441483965107814400,
    "created_at" : "2014-03-06 08:02:34 +0000",
    "user" : {
      "name" : "Martin Weller",
      "screen_name" : "mweller",
      "protected" : false,
      "id_str" : "7127162",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/760047558404214784\/9BjBxogx_normal.jpg",
      "id" : 7127162,
      "verified" : false
    }
  },
  "id" : 441521867896418306,
  "created_at" : "2014-03-06 10:33:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Natallia Novikava",
      "screen_name" : "Natashetta",
      "indices" : [ 3, 14 ],
      "id_str" : "56308635",
      "id" : 56308635
    }, {
      "name" : "Lizzie Pinard",
      "screen_name" : "LizziePinard",
      "indices" : [ 130, 140 ],
      "id_str" : "287093748",
      "id" : 287093748
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/FyKoMT7Lzv",
      "expanded_url" : "http:\/\/wordandphrase.info",
      "display_url" : "wordandphrase.info"
    }, {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/R2CVfv6QQK",
      "expanded_url" : "http:\/\/wp.me\/p1wSAy-qn",
      "display_url" : "wp.me\/p1wSAy-qn"
    } ]
  },
  "geo" : { },
  "id_str" : "441503046498258945",
  "text" : "RT @Natashetta: Helping language learners become language researchers: http:\/\/t.co\/FyKoMT7Lzv (part 2) http:\/\/t.co\/R2CVfv6QQK via @lizziepi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lizzie Pinard",
        "screen_name" : "LizziePinard",
        "indices" : [ 114, 127 ],
        "id_str" : "287093748",
        "id" : 287093748
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "elt",
        "indices" : [ 128, 132 ]
      } ],
      "urls" : [ {
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/FyKoMT7Lzv",
        "expanded_url" : "http:\/\/wordandphrase.info",
        "display_url" : "wordandphrase.info"
      }, {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/R2CVfv6QQK",
        "expanded_url" : "http:\/\/wp.me\/p1wSAy-qn",
        "display_url" : "wp.me\/p1wSAy-qn"
      } ]
    },
    "geo" : { },
    "id_str" : "441500728373149696",
    "text" : "Helping language learners become language researchers: http:\/\/t.co\/FyKoMT7Lzv (part 2) http:\/\/t.co\/R2CVfv6QQK via @lizziepinard #elt",
    "id" : 441500728373149696,
    "created_at" : "2014-03-06 09:09:10 +0000",
    "user" : {
      "name" : "Natallia Novikava",
      "screen_name" : "Natashetta",
      "protected" : false,
      "id_str" : "56308635",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2877370292\/d6370dfafaa5506c53671f1bd1da0cdc_normal.jpeg",
      "id" : 56308635,
      "verified" : false
    }
  },
  "id" : 441503046498258945,
  "created_at" : "2014-03-06 09:18:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Hardie",
      "screen_name" : "HardieResearch",
      "indices" : [ 3, 18 ],
      "id_str" : "970452764",
      "id" : 970452764
    }, {
      "name" : "LAEL, Lancaster Uni",
      "screen_name" : "LAEL_LU",
      "indices" : [ 124, 132 ],
      "id_str" : "44577543",
      "id" : 44577543
    }, {
      "name" : "Lancaster University",
      "screen_name" : "LancasterUni",
      "indices" : [ 136, 140 ],
      "id_str" : "25521930",
      "id" : 25521930
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/nEeB94IHWL",
      "expanded_url" : "http:\/\/ucrel.lancs.ac.uk\/talc2014",
      "display_url" : "ucrel.lancs.ac.uk\/talc2014"
    } ]
  },
  "geo" : { },
  "id_str" : "441493096933883904",
  "text" : "RT @HardieResearch: Registration is now open for TaLC 11 (Teaching and Language Corpora): http:\/\/t.co\/nEeB94IHWL  hosted by @LAEL_LU at @La\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "LAEL, Lancaster Uni",
        "screen_name" : "LAEL_LU",
        "indices" : [ 104, 112 ],
        "id_str" : "44577543",
        "id" : 44577543
      }, {
        "name" : "Lancaster University",
        "screen_name" : "LancasterUni",
        "indices" : [ 116, 129 ],
        "id_str" : "25521930",
        "id" : 25521930
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/nEeB94IHWL",
        "expanded_url" : "http:\/\/ucrel.lancs.ac.uk\/talc2014",
        "display_url" : "ucrel.lancs.ac.uk\/talc2014"
      } ]
    },
    "geo" : { },
    "id_str" : "441491296403091456",
    "text" : "Registration is now open for TaLC 11 (Teaching and Language Corpora): http:\/\/t.co\/nEeB94IHWL  hosted by @LAEL_LU at @LancasterUni",
    "id" : 441491296403091456,
    "created_at" : "2014-03-06 08:31:42 +0000",
    "user" : {
      "name" : "Andrew Hardie",
      "screen_name" : "HardieResearch",
      "protected" : false,
      "id_str" : "970452764",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2895091886\/5274f8f34de87999703c0f92adfdf465_normal.jpeg",
      "id" : 970452764,
      "verified" : false
    }
  },
  "id" : 441493096933883904,
  "created_at" : "2014-03-06 08:38:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Education Lens",
      "screen_name" : "EducationLens",
      "indices" : [ 3, 17 ],
      "id_str" : "2373851498",
      "id" : 2373851498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/8SuVmqmMjP",
      "expanded_url" : "http:\/\/wp.me\/p4n2UG-1K",
      "display_url" : "wp.me\/p4n2UG-1K"
    } ]
  },
  "geo" : { },
  "id_str" : "441472962957684736",
  "text" : "RT @EducationLens: Education Lens Goes\u00A0Live http:\/\/t.co\/8SuVmqmMjP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 25, 47 ],
        "url" : "http:\/\/t.co\/8SuVmqmMjP",
        "expanded_url" : "http:\/\/wp.me\/p4n2UG-1K",
        "display_url" : "wp.me\/p4n2UG-1K"
      } ]
    },
    "geo" : { },
    "id_str" : "441386270036475904",
    "text" : "Education Lens Goes\u00A0Live http:\/\/t.co\/8SuVmqmMjP",
    "id" : 441386270036475904,
    "created_at" : "2014-03-06 01:34:21 +0000",
    "user" : {
      "name" : "Education Lens",
      "screen_name" : "EducationLens",
      "protected" : false,
      "id_str" : "2373851498",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/441288618347220992\/sxO0iZf9_normal.jpeg",
      "id" : 2373851498,
      "verified" : false
    }
  },
  "id" : 441472962957684736,
  "created_at" : "2014-03-06 07:18:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ukraine",
      "indices" : [ 109, 117 ]
    }, {
      "text" : "bbcpropaganda",
      "indices" : [ 118, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/MswNhQnJot",
      "expanded_url" : "http:\/\/johnhilley.blogspot.co.uk\/2014\/03\/duty-media-framing-options-on-russia.html",
      "display_url" : "johnhilley.blogspot.co.uk\/2014\/03\/duty-m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "441349604651831296",
  "text" : "RT @johnwhilley: Zenpolitics: Duty media: framing the options on Russia and Ukraine  http:\/\/t.co\/MswNhQnJot  #Ukraine #bbcpropaganda",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Ukraine",
        "indices" : [ 92, 100 ]
      }, {
        "text" : "bbcpropaganda",
        "indices" : [ 101, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/MswNhQnJot",
        "expanded_url" : "http:\/\/johnhilley.blogspot.co.uk\/2014\/03\/duty-media-framing-options-on-russia.html",
        "display_url" : "johnhilley.blogspot.co.uk\/2014\/03\/duty-m\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "441267838104268800",
    "text" : "Zenpolitics: Duty media: framing the options on Russia and Ukraine  http:\/\/t.co\/MswNhQnJot  #Ukraine #bbcpropaganda",
    "id" : 441267838104268800,
    "created_at" : "2014-03-05 17:43:45 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 441349604651831296,
  "created_at" : "2014-03-05 23:08:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/441345152422924288\/photo\/1",
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/5MOlEVz8Ju",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bh_5E-oCUAAhNah.png",
      "id_str" : "441345152431312896",
      "id" : 441345152431312896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bh_5E-oCUAAhNah.png",
      "sizes" : [ {
        "h" : 266,
        "resize" : "fit",
        "w" : 563
      }, {
        "h" : 266,
        "resize" : "fit",
        "w" : 563
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 266,
        "resize" : "fit",
        "w" : 563
      }, {
        "h" : 161,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/5MOlEVz8Ju"
    } ],
    "hashtags" : [ {
      "text" : "piratebox",
      "indices" : [ 0, 10 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441345152422924288",
  "text" : "#piratebox - spelling things out for my students, doubt it will have any effect though :0 http:\/\/t.co\/5MOlEVz8Ju",
  "id" : 441345152422924288,
  "created_at" : "2014-03-05 22:50:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "i_narrator",
      "screen_name" : "i_narrator",
      "indices" : [ 3, 14 ],
      "id_str" : "281361233",
      "id" : 281361233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/uJMLpErbUw",
      "expanded_url" : "http:\/\/phys.org\/news\/2014-03-biggest-linguistic-survey-twitter-selfie.html",
      "display_url" : "phys.org\/news\/2014-03-b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "440986739776028673",
  "text" : "RT @i_narrator: Biggest ever linguistic survey on Twitter could find the next 'selfie' or 'twerk' http:\/\/t.co\/uJMLpErbUw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/uJMLpErbUw",
        "expanded_url" : "http:\/\/phys.org\/news\/2014-03-biggest-linguistic-survey-twitter-selfie.html",
        "display_url" : "phys.org\/news\/2014-03-b\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "440882926104768512",
    "text" : "Biggest ever linguistic survey on Twitter could find the next 'selfie' or 'twerk' http:\/\/t.co\/uJMLpErbUw",
    "id" : 440882926104768512,
    "created_at" : "2014-03-04 16:14:15 +0000",
    "user" : {
      "name" : "i_narrator",
      "screen_name" : "i_narrator",
      "protected" : false,
      "id_str" : "281361233",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000410308329\/8ed838331668e90230fc3a90a453f21b_normal.jpeg",
      "id" : 281361233,
      "verified" : false
    }
  },
  "id" : 440986739776028673,
  "created_at" : "2014-03-04 23:06:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440984082671874049",
  "text" : "52% people still surprised polling figures with minimal info commissioned by interested party taken seriously :\/",
  "id" : 440984082671874049,
  "created_at" : "2014-03-04 22:56:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carl Dowse",
      "screen_name" : "carldowse",
      "indices" : [ 0, 10 ],
      "id_str" : "15609677",
      "id" : 15609677
    }, {
      "name" : "Charles Rei",
      "screen_name" : "Charlesrei1",
      "indices" : [ 11, 23 ],
      "id_str" : "464454382",
      "id" : 464454382
    }, {
      "name" : "evanfrendo",
      "screen_name" : "evanfrendo",
      "indices" : [ 24, 35 ],
      "id_str" : "17589664",
      "id" : 17589664
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440940788088713217",
  "geo" : { },
  "id_str" : "440982190063484928",
  "in_reply_to_user_id" : 15609677,
  "text" : "@carldowse @Charlesrei1 @evanfrendo according to developer more features planned :)",
  "id" : 440982190063484928,
  "in_reply_to_status_id" : 440940788088713217,
  "created_at" : "2014-03-04 22:48:41 +0000",
  "in_reply_to_screen_name" : "carldowse",
  "in_reply_to_user_id_str" : "15609677",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carl Dowse",
      "screen_name" : "carldowse",
      "indices" : [ 3, 13 ],
      "id_str" : "15609677",
      "id" : 15609677
    }, {
      "name" : "evanfrendo",
      "screen_name" : "evanfrendo",
      "indices" : [ 106, 117 ],
      "id_str" : "17589664",
      "id" : 17589664
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/0J90iHuw16",
      "expanded_url" : "http:\/\/www.staff.uni-mainz.de\/fantinuo\/corpuscreator.html",
      "display_url" : "staff.uni-mainz.de\/fantinuo\/corpu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "440981927739129857",
  "text" : "RT @carldowse: CorpusCreator - Tool to create specialized corpora from the Web http:\/\/t.co\/0J90iHuw16 via @evanfrendo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "evanfrendo",
        "screen_name" : "evanfrendo",
        "indices" : [ 91, 102 ],
        "id_str" : "17589664",
        "id" : 17589664
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/0J90iHuw16",
        "expanded_url" : "http:\/\/www.staff.uni-mainz.de\/fantinuo\/corpuscreator.html",
        "display_url" : "staff.uni-mainz.de\/fantinuo\/corpu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "440940788088713217",
    "text" : "CorpusCreator - Tool to create specialized corpora from the Web http:\/\/t.co\/0J90iHuw16 via @evanfrendo",
    "id" : 440940788088713217,
    "created_at" : "2014-03-04 20:04:10 +0000",
    "user" : {
      "name" : "Carl Dowse",
      "screen_name" : "carldowse",
      "protected" : false,
      "id_str" : "15609677",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1197067250\/MeatAGM2010_normal.jpg",
      "id" : 15609677,
      "verified" : false
    }
  },
  "id" : 440981927739129857,
  "created_at" : "2014-03-04 22:47:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440908605944897536",
  "geo" : { },
  "id_str" : "440958816201367552",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl nice! did not know do thing was called do support. typo alert much&lt;--&gt;many",
  "id" : 440958816201367552,
  "in_reply_to_status_id" : 440908605944897536,
  "created_at" : "2014-03-04 21:15:49 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440914215792951297",
  "geo" : { },
  "id_str" : "440942047441080320",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt great :)",
  "id" : 440942047441080320,
  "in_reply_to_status_id" : 440914215792951297,
  "created_at" : "2014-03-04 20:09:11 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Pride",
      "screen_name" : "ThomasPride",
      "indices" : [ 104, 116 ],
      "id_str" : "385867551",
      "id" : 385867551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/RY6fZGR9QS",
      "expanded_url" : "http:\/\/wp.me\/p1U04a-6Dw",
      "display_url" : "wp.me\/p1U04a-6Dw"
    } ]
  },
  "geo" : { },
  "id_str" : "440586336219574272",
  "text" : "Government sells entire NHS patient data to firm headed by disgraced banker: http:\/\/t.co\/RY6fZGR9QS via @ThomasPride",
  "id" : 440586336219574272,
  "created_at" : "2014-03-03 20:35:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hana Tich\u00E1",
      "screen_name" : "HanaTicha",
      "indices" : [ 3, 13 ],
      "id_str" : "512296705",
      "id" : 512296705
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/1tbFs8orij",
      "expanded_url" : "http:\/\/how-i-see-it-now.blogspot.cz\/2014\/03\/will-i-ever-have-guts-to-teach-unplugged.html",
      "display_url" : "how-i-see-it-now.blogspot.cz\/2014\/03\/will-i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "440577028350554112",
  "text" : "RT @HanaTicha: A new blog post about a recent experience and more ... http:\/\/t.co\/1tbFs8orij",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/1tbFs8orij",
        "expanded_url" : "http:\/\/how-i-see-it-now.blogspot.cz\/2014\/03\/will-i-ever-have-guts-to-teach-unplugged.html",
        "display_url" : "how-i-see-it-now.blogspot.cz\/2014\/03\/will-i\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "440569938852728832",
    "text" : "A new blog post about a recent experience and more ... http:\/\/t.co\/1tbFs8orij",
    "id" : 440569938852728832,
    "created_at" : "2014-03-03 19:30:33 +0000",
    "user" : {
      "name" : "Hana Tich\u00E1",
      "screen_name" : "HanaTicha",
      "protected" : false,
      "id_str" : "512296705",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/699528253598494721\/HL9Np6Gu_normal.jpg",
      "id" : 512296705,
      "verified" : false
    }
  },
  "id" : 440577028350554112,
  "created_at" : "2014-03-03 19:58:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 3, 14 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpora",
      "indices" : [ 104, 112 ]
    }, {
      "text" : "ELT",
      "indices" : [ 113, 117 ]
    }, {
      "text" : "MAWSIG",
      "indices" : [ 118, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/PQi1hi8hUo",
      "expanded_url" : "http:\/\/www.euppublishing.com\/doi\/pdfplus\/10.3366\/cor.2012.0019",
      "display_url" : "euppublishing.com\/doi\/pdfplus\/10\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "440564782387986433",
  "text" : "RT @lexicoloco: 'Corpora and coursebooks: destined to be strangers forever?' PDF http:\/\/t.co\/PQi1hi8hUo #corpora #ELT #MAWSIG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpora",
        "indices" : [ 88, 96 ]
      }, {
        "text" : "ELT",
        "indices" : [ 97, 101 ]
      }, {
        "text" : "MAWSIG",
        "indices" : [ 102, 109 ]
      } ],
      "urls" : [ {
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/PQi1hi8hUo",
        "expanded_url" : "http:\/\/www.euppublishing.com\/doi\/pdfplus\/10.3366\/cor.2012.0019",
        "display_url" : "euppublishing.com\/doi\/pdfplus\/10\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "440562955156213760",
    "text" : "'Corpora and coursebooks: destined to be strangers forever?' PDF http:\/\/t.co\/PQi1hi8hUo #corpora #ELT #MAWSIG",
    "id" : 440562955156213760,
    "created_at" : "2014-03-03 19:02:48 +0000",
    "user" : {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "protected" : false,
      "id_str" : "300734173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2403500097\/3nmx3kjaycyoc7irwe6s_normal.jpeg",
      "id" : 300734173,
      "verified" : false
    }
  },
  "id" : 440564782387986433,
  "created_at" : "2014-03-03 19:10:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "byucoca",
      "indices" : [ 26, 34 ]
    }, {
      "text" : "corpusMOOC",
      "indices" : [ 72, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440535993133703169",
  "text" : "woah first time have seen #byucoca acting up anyone else seeing glitch? #corpusMOOC",
  "id" : 440535993133703169,
  "created_at" : "2014-03-03 17:15:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/wrJlPBFh4C",
      "expanded_url" : "http:\/\/rt.com\/op-edge\/democracy-on-retreat-europe-ukraine-608\/",
      "display_url" : "rt.com\/op-edge\/democr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "440530497370746881",
  "text" : "Unelected power: Democracy on the retreat in Europe http:\/\/t.co\/wrJlPBFh4C",
  "id" : 440530497370746881,
  "created_at" : "2014-03-03 16:53:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Lee",
      "screen_name" : "desktopenglish",
      "indices" : [ 0, 15 ],
      "id_str" : "345925613",
      "id" : 345925613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "440529386572242944",
  "geo" : { },
  "id_str" : "440529880719958016",
  "in_reply_to_user_id" : 345925613,
  "text" : "@desktopenglish i have not seen such thick hypocrisy in a while :\/",
  "id" : 440529880719958016,
  "in_reply_to_status_id" : 440529386572242944,
  "created_at" : "2014-03-03 16:51:22 +0000",
  "in_reply_to_screen_name" : "desktopenglish",
  "in_reply_to_user_id_str" : "345925613",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440524984293675008",
  "text" : "@_FTaylor_ nice :)",
  "id" : 440524984293675008,
  "created_at" : "2014-03-03 16:31:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike S. Boyle",
      "screen_name" : "heyboyle",
      "indices" : [ 3, 12 ],
      "id_str" : "612840231",
      "id" : 612840231
    }, {
      "name" : "Quartz",
      "screen_name" : "qz",
      "indices" : [ 88, 91 ],
      "id_str" : "573918122",
      "id" : 573918122
    }, {
      "name" : "Newsmart",
      "screen_name" : "getnewsmart",
      "indices" : [ 139, 140 ],
      "id_str" : "1733043366",
      "id" : 1733043366
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qz\/status\/440498623881543681\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/tEfKSX0Nei",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bhz3KhrCMAAZfRv.png",
      "id_str" : "440498623785086976",
      "id" : 440498623785086976,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bhz3KhrCMAAZfRv.png",
      "sizes" : [ {
        "h" : 717,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1224,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 406,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1224,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/tEfKSX0Nei"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/hGc7ZHmzAm",
      "expanded_url" : "http:\/\/qz.com\/183016",
      "display_url" : "qz.com\/183016"
    } ]
  },
  "geo" : { },
  "id_str" : "440510860755496960",
  "text" : "RT @heyboyle: Most frequent words in 37 years of Warren Buffett shareholder letters via @qz http:\/\/t.co\/hGc7ZHmzAm http:\/\/t.co\/tEfKSX0Nei c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Quartz",
        "screen_name" : "qz",
        "indices" : [ 74, 77 ],
        "id_str" : "573918122",
        "id" : 573918122
      }, {
        "name" : "Newsmart",
        "screen_name" : "getnewsmart",
        "indices" : [ 127, 139 ],
        "id_str" : "1733043366",
        "id" : 1733043366
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/qz\/status\/440498623881543681\/photo\/1",
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/tEfKSX0Nei",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bhz3KhrCMAAZfRv.png",
        "id_str" : "440498623785086976",
        "id" : 440498623785086976,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bhz3KhrCMAAZfRv.png",
        "sizes" : [ {
          "h" : 717,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1224,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 406,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1224,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/tEfKSX0Nei"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/hGc7ZHmzAm",
        "expanded_url" : "http:\/\/qz.com\/183016",
        "display_url" : "qz.com\/183016"
      } ]
    },
    "geo" : { },
    "id_str" : "440507489428062208",
    "text" : "Most frequent words in 37 years of Warren Buffett shareholder letters via @qz http:\/\/t.co\/hGc7ZHmzAm http:\/\/t.co\/tEfKSX0Nei cc @getnewsmart",
    "id" : 440507489428062208,
    "created_at" : "2014-03-03 15:22:24 +0000",
    "user" : {
      "name" : "Mike S. Boyle",
      "screen_name" : "heyboyle",
      "protected" : false,
      "id_str" : "612840231",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/604115272849575936\/ln05gCwx_normal.jpg",
      "id" : 612840231,
      "verified" : false
    }
  },
  "id" : 440510860755496960,
  "created_at" : "2014-03-03 15:35:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Douglas Carnall",
      "screen_name" : "JuliuzBeezer",
      "indices" : [ 3, 16 ],
      "id_str" : "25936824",
      "id" : 25936824
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusMOOC",
      "indices" : [ 49, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/qERG0C6Nam",
      "expanded_url" : "http:\/\/juliusbeezer.blogspot.fr\/2014\/03\/shocking-resort-to-science-to-resolve.html",
      "display_url" : "juliusbeezer.blogspot.fr\/2014\/03\/shocki\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "440485828876591104",
  "text" : "RT @JuliuzBeezer: Inspired by the most excellent #corpusMOOC, and a trawl back over some old blog comments, I've had an effusion: http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpusMOOC",
        "indices" : [ 31, 42 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/qERG0C6Nam",
        "expanded_url" : "http:\/\/juliusbeezer.blogspot.fr\/2014\/03\/shocking-resort-to-science-to-resolve.html",
        "display_url" : "juliusbeezer.blogspot.fr\/2014\/03\/shocki\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "440206216854134784",
    "text" : "Inspired by the most excellent #corpusMOOC, and a trawl back over some old blog comments, I've had an effusion: http:\/\/t.co\/qERG0C6Nam",
    "id" : 440206216854134784,
    "created_at" : "2014-03-02 19:25:15 +0000",
    "user" : {
      "name" : "Douglas Carnall",
      "screen_name" : "JuliuzBeezer",
      "protected" : false,
      "id_str" : "25936824",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/114211651\/robert_burns247x165_normal.jpg",
      "id" : 25936824,
      "verified" : false
    }
  },
  "id" : 440485828876591104,
  "created_at" : "2014-03-03 13:56:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth Anne",
      "screen_name" : "eannegrenoble",
      "indices" : [ 0, 14 ],
      "id_str" : "19869781",
      "id" : 19869781
    }, {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 15, 26 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "indices" : [ 27, 39 ],
      "id_str" : "849729062",
      "id" : 849729062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/vBKIPDRM6d",
      "expanded_url" : "http:\/\/www.newgeneralservicelist.org\/",
      "display_url" : "newgeneralservicelist.org"
    } ]
  },
  "in_reply_to_status_id_str" : "440422565949890560",
  "geo" : { },
  "id_str" : "440485527771303938",
  "in_reply_to_user_id" : 19869781,
  "text" : "@eannegrenoble @leoselivan @TonyMcEnery  there is a \"rival\"(?) new GSL http:\/\/t.co\/vBKIPDRM6d based on word families rather than lemmas",
  "id" : 440485527771303938,
  "in_reply_to_status_id" : 440422565949890560,
  "created_at" : "2014-03-03 13:55:08 +0000",
  "in_reply_to_screen_name" : "eannegrenoble",
  "in_reply_to_user_id_str" : "19869781",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corpora Journal",
      "screen_name" : "CorporaJournal",
      "indices" : [ 3, 18 ],
      "id_str" : "2340183050",
      "id" : 2340183050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 125, 140 ],
      "url" : "http:\/\/t.co\/JK9Wmeh7MO",
      "expanded_url" : "http:\/\/www.euppublishing.com\/toc\/cor\/7\/1",
      "display_url" : "euppublishing.com\/toc\/cor\/7\/1"
    } ]
  },
  "geo" : { },
  "id_str" : "440483741245644800",
  "text" : "RT @CorporaJournal: Did you know? A full, free sample issue of Corpora (Volume 7 Issue 1, 2012) is available on our website! http:\/\/t.co\/JK\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/JK9Wmeh7MO",
        "expanded_url" : "http:\/\/www.euppublishing.com\/toc\/cor\/7\/1",
        "display_url" : "euppublishing.com\/toc\/cor\/7\/1"
      } ]
    },
    "geo" : { },
    "id_str" : "440474919218860032",
    "text" : "Did you know? A full, free sample issue of Corpora (Volume 7 Issue 1, 2012) is available on our website! http:\/\/t.co\/JK9Wmeh7MO",
    "id" : 440474919218860032,
    "created_at" : "2014-03-03 13:12:59 +0000",
    "user" : {
      "name" : "Corpora Journal",
      "screen_name" : "CorporaJournal",
      "protected" : false,
      "id_str" : "2340183050",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/433564609379700736\/d4vW52wm_normal.png",
      "id" : 2340183050,
      "verified" : false
    }
  },
  "id" : 440483741245644800,
  "created_at" : "2014-03-03 13:48:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Andrews",
      "screen_name" : "patrickelt",
      "indices" : [ 0, 11 ],
      "id_str" : "2292503990",
      "id" : 2292503990
    }, {
      "name" : "Mercedes Durham",
      "screen_name" : "drswissmiss",
      "indices" : [ 23, 35 ],
      "id_str" : "14970555",
      "id" : 14970555
    }, {
      "name" : "Achilleas Kostoulas",
      "screen_name" : "AchilleasK",
      "indices" : [ 36, 47 ],
      "id_str" : "134191406",
      "id" : 134191406
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/5HVxk4XdX6",
      "expanded_url" : "https:\/\/plus.google.com\/communities\/101266284417587206243",
      "display_url" : "plus.google.com\/communities\/10\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "440454465939050496",
  "geo" : { },
  "id_str" : "440483659733168130",
  "in_reply_to_user_id" : 2292503990,
  "text" : "@patrickelt @_FTaylor_ @drswissmiss @AchilleasK just nosing in do check G+ community for teach\/learn languages peeps https:\/\/t.co\/5HVxk4XdX6",
  "id" : 440483659733168130,
  "in_reply_to_status_id" : 440454465939050496,
  "created_at" : "2014-03-03 13:47:42 +0000",
  "in_reply_to_screen_name" : "patrickelt",
  "in_reply_to_user_id_str" : "2292503990",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Read",
      "screen_name" : "dreadnought001",
      "indices" : [ 3, 18 ],
      "id_str" : "83207734",
      "id" : 83207734
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 104, 112 ]
    }, {
      "text" : "ellchat",
      "indices" : [ 113, 121 ]
    }, {
      "text" : "efl",
      "indices" : [ 122, 126 ]
    }, {
      "text" : "esl",
      "indices" : [ 127, 131 ]
    }, {
      "text" : "eapchat",
      "indices" : [ 132, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/AHn6RxJfpe",
      "expanded_url" : "http:\/\/goo.gl\/kU1NNK",
      "display_url" : "goo.gl\/kU1NNK"
    } ]
  },
  "geo" : { },
  "id_str" : "440441782237929472",
  "text" : "RT @dreadnought001: my new blog post: an unusual approach to teacher development http:\/\/t.co\/AHn6RxJfpe #eltchat #ellchat #efl #esl #eapchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "eltchat",
        "indices" : [ 84, 92 ]
      }, {
        "text" : "ellchat",
        "indices" : [ 93, 101 ]
      }, {
        "text" : "efl",
        "indices" : [ 102, 106 ]
      }, {
        "text" : "esl",
        "indices" : [ 107, 111 ]
      }, {
        "text" : "eapchat",
        "indices" : [ 112, 120 ]
      } ],
      "urls" : [ {
        "indices" : [ 61, 83 ],
        "url" : "http:\/\/t.co\/AHn6RxJfpe",
        "expanded_url" : "http:\/\/goo.gl\/kU1NNK",
        "display_url" : "goo.gl\/kU1NNK"
      } ]
    },
    "geo" : { },
    "id_str" : "440425891148361728",
    "text" : "my new blog post: an unusual approach to teacher development http:\/\/t.co\/AHn6RxJfpe #eltchat #ellchat #efl #esl #eapchat",
    "id" : 440425891148361728,
    "created_at" : "2014-03-03 09:58:09 +0000",
    "user" : {
      "name" : "David Read",
      "screen_name" : "dreadnought001",
      "protected" : false,
      "id_str" : "83207734",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/503606579573178370\/GqHxIpPe_normal.jpeg",
      "id" : 83207734,
      "verified" : false
    }
  },
  "id" : 440441782237929472,
  "created_at" : "2014-03-03 11:01:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ioannis E. Saridakis",
      "screen_name" : "iesaridakis",
      "indices" : [ 3, 15 ],
      "id_str" : "319436319",
      "id" : 319436319
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/ONNO2918YY",
      "expanded_url" : "http:\/\/next.liberation.fr\/cinema\/2014\/03\/02\/le-realisateur-alain-resnais-est-mort_983913",
      "display_url" : "next.liberation.fr\/cinema\/2014\/03\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "440246285321633793",
  "text" : "RT @iesaridakis: Le r\u00E9alisateur Alain Resnais est mort http:\/\/t.co\/ONNO2918YY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 60 ],
        "url" : "http:\/\/t.co\/ONNO2918YY",
        "expanded_url" : "http:\/\/next.liberation.fr\/cinema\/2014\/03\/02\/le-realisateur-alain-resnais-est-mort_983913",
        "display_url" : "next.liberation.fr\/cinema\/2014\/03\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "440157064799592448",
    "text" : "Le r\u00E9alisateur Alain Resnais est mort http:\/\/t.co\/ONNO2918YY",
    "id" : 440157064799592448,
    "created_at" : "2014-03-02 16:09:56 +0000",
    "user" : {
      "name" : "Ioannis E. Saridakis",
      "screen_name" : "iesaridakis",
      "protected" : false,
      "id_str" : "319436319",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458954440406347777\/cRTX10yh_normal.jpeg",
      "id" : 319436319,
      "verified" : false
    }
  },
  "id" : 440246285321633793,
  "created_at" : "2014-03-02 22:04:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UbuWeb",
      "screen_name" : "ubuweb",
      "indices" : [ 3, 10 ],
      "id_str" : "38993997",
      "id" : 38993997
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/ubuweb\/status\/440154834856333312\/photo\/1",
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/7JMo5Exftx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bhu-fXrIMAAMOdG.jpg",
      "id_str" : "440154834738884608",
      "id" : 440154834738884608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bhu-fXrIMAAMOdG.jpg",
      "sizes" : [ {
        "h" : 375,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/7JMo5Exftx"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/CESrakYNdV",
      "expanded_url" : "http:\/\/is.gd\/hetFLo",
      "display_url" : "is.gd\/hetFLo"
    } ]
  },
  "geo" : { },
  "id_str" : "440204395649982465",
  "text" : "RT @ubuweb: John Berger, \"Ways of Seeing\" BBC TV series from 1972: http:\/\/t.co\/CESrakYNdV http:\/\/t.co\/7JMo5Exftx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ubuweb\/status\/440154834856333312\/photo\/1",
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/7JMo5Exftx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bhu-fXrIMAAMOdG.jpg",
        "id_str" : "440154834738884608",
        "id" : 440154834738884608,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bhu-fXrIMAAMOdG.jpg",
        "sizes" : [ {
          "h" : 375,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 375,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 375,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/7JMo5Exftx"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/CESrakYNdV",
        "expanded_url" : "http:\/\/is.gd\/hetFLo",
        "display_url" : "is.gd\/hetFLo"
      } ]
    },
    "geo" : { },
    "id_str" : "440154834856333312",
    "text" : "John Berger, \"Ways of Seeing\" BBC TV series from 1972: http:\/\/t.co\/CESrakYNdV http:\/\/t.co\/7JMo5Exftx",
    "id" : 440154834856333312,
    "created_at" : "2014-03-02 16:01:04 +0000",
    "user" : {
      "name" : "UbuWeb",
      "screen_name" : "ubuweb",
      "protected" : false,
      "id_str" : "38993997",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1765660640\/Ubu-Icon_normal.jpg",
      "id" : 38993997,
      "verified" : false
    }
  },
  "id" : 440204395649982465,
  "created_at" : "2014-03-02 19:18:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BELTA Belgium",
      "screen_name" : "BELTABelgium",
      "indices" : [ 3, 16 ],
      "id_str" : "884934438",
      "id" : 884934438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/KBfi9PARCW",
      "expanded_url" : "http:\/\/ow.ly\/u9kQ4",
      "display_url" : "ow.ly\/u9kQ4"
    } ]
  },
  "geo" : { },
  "id_str" : "440157037381836800",
  "text" : "RT @BELTABelgium: Our next BELTA webinar - join us on March 9th at 1600CET for \"Corpora in the English Classroom\" with Johan Strobbe: http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/KBfi9PARCW",
        "expanded_url" : "http:\/\/ow.ly\/u9kQ4",
        "display_url" : "ow.ly\/u9kQ4"
      } ]
    },
    "geo" : { },
    "id_str" : "440144073715101696",
    "text" : "Our next BELTA webinar - join us on March 9th at 1600CET for \"Corpora in the English Classroom\" with Johan Strobbe: http:\/\/t.co\/KBfi9PARCW",
    "id" : 440144073715101696,
    "created_at" : "2014-03-02 15:18:19 +0000",
    "user" : {
      "name" : "BELTA Belgium",
      "screen_name" : "BELTABelgium",
      "protected" : false,
      "id_str" : "884934438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3130800745\/d36391a9857692e6c2aab76d0033ade0_normal.png",
      "id" : 884934438,
      "verified" : false
    }
  },
  "id" : 440157037381836800,
  "created_at" : "2014-03-02 16:09:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Serveis Ling\u00FC\u00EDstics",
      "screen_name" : "SLBCoop",
      "indices" : [ 81, 89 ],
      "id_str" : "2365399801",
      "id" : 2365399801
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/Qa7J8CuDpx",
      "expanded_url" : "http:\/\/wp.me\/p3yH5T-15",
      "display_url" : "wp.me\/p3yH5T-15"
    } ]
  },
  "geo" : { },
  "id_str" : "440116277311336448",
  "text" : "Solidarity project 1: The Phoenix Projects, Guatemala http:\/\/t.co\/Qa7J8CuDpx via @SLBCoop",
  "id" : 440116277311336448,
  "created_at" : "2014-03-02 13:27:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sandy Millin",
      "screen_name" : "sandymillin",
      "indices" : [ 3, 15 ],
      "id_str" : "144236944",
      "id" : 144236944
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/YLa8WPtpyZ",
      "expanded_url" : "http:\/\/sandymillin.wordpress.com\/2014\/03\/02\/sevastopol-2nd-march-2014\/",
      "display_url" : "sandymillin.wordpress.com\/2014\/03\/02\/sev\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "440115690973184000",
  "text" : "RT @sandymillin: Sevastopol, 2nd March 2014 (from my blog) http:\/\/t.co\/YLa8WPtpyZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/YLa8WPtpyZ",
        "expanded_url" : "http:\/\/sandymillin.wordpress.com\/2014\/03\/02\/sevastopol-2nd-march-2014\/",
        "display_url" : "sandymillin.wordpress.com\/2014\/03\/02\/sev\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "440026372082503680",
    "text" : "Sevastopol, 2nd March 2014 (from my blog) http:\/\/t.co\/YLa8WPtpyZ",
    "id" : 440026372082503680,
    "created_at" : "2014-03-02 07:30:37 +0000",
    "user" : {
      "name" : "Sandy Millin",
      "screen_name" : "sandymillin",
      "protected" : false,
      "id_str" : "144236944",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/429614623923269632\/yY-O4eno_normal.jpeg",
      "id" : 144236944,
      "verified" : false
    }
  },
  "id" : 440115690973184000,
  "created_at" : "2014-03-02 13:25:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yolanda B. Schell",
      "screen_name" : "mattellman",
      "indices" : [ 3, 14 ],
      "id_str" : "725597315860434945",
      "id" : 725597315860434945
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ESL",
      "indices" : [ 79, 83 ]
    }, {
      "text" : "EFL",
      "indices" : [ 84, 88 ]
    }, {
      "text" : "ELTchat",
      "indices" : [ 89, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/slEp9EtccY",
      "expanded_url" : "http:\/\/teachertolearner.com\/2014\/03\/02\/my-learning-behaviour\/",
      "display_url" : "teachertolearner.com\/2014\/03\/02\/my-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "440095938674429953",
  "text" : "RT @mattellman: Latest blog post: My Learning Behaviour http:\/\/t.co\/slEp9EtccY #ESL #EFL #ELTchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ESL",
        "indices" : [ 63, 67 ]
      }, {
        "text" : "EFL",
        "indices" : [ 68, 72 ]
      }, {
        "text" : "ELTchat",
        "indices" : [ 73, 81 ]
      } ],
      "urls" : [ {
        "indices" : [ 40, 62 ],
        "url" : "http:\/\/t.co\/slEp9EtccY",
        "expanded_url" : "http:\/\/teachertolearner.com\/2014\/03\/02\/my-learning-behaviour\/",
        "display_url" : "teachertolearner.com\/2014\/03\/02\/my-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "440093654217023488",
    "text" : "Latest blog post: My Learning Behaviour http:\/\/t.co\/slEp9EtccY #ESL #EFL #ELTchat",
    "id" : 440093654217023488,
    "created_at" : "2014-03-02 11:57:58 +0000",
    "user" : {
      "name" : "Matthew Ellman",
      "screen_name" : "MatthewEllman",
      "protected" : false,
      "id_str" : "394987109",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1615371192\/classpic_normal.jpg",
      "id" : 394987109,
      "verified" : false
    }
  },
  "id" : 440095938674429953,
  "created_at" : "2014-03-02 12:07:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Natallia Novikava",
      "screen_name" : "Natashetta",
      "indices" : [ 3, 14 ],
      "id_str" : "56308635",
      "id" : 56308635
    }, {
      "name" : "Lizzie Pinard",
      "screen_name" : "LizziePinard",
      "indices" : [ 130, 140 ],
      "id_str" : "287093748",
      "id" : 287093748
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/FyKoMT7Lzv",
      "expanded_url" : "http:\/\/wordandphrase.info",
      "display_url" : "wordandphrase.info"
    }, {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/wNLJbIx5MY",
      "expanded_url" : "http:\/\/wp.me\/p1wSAy-nJ",
      "display_url" : "wp.me\/p1wSAy-nJ"
    } ]
  },
  "geo" : { },
  "id_str" : "440087075233480704",
  "text" : "RT @Natashetta: Helping language learners become language researchers: http:\/\/t.co\/FyKoMT7Lzv (part 1) http:\/\/t.co\/wNLJbIx5MY via @lizziepi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lizzie Pinard",
        "screen_name" : "LizziePinard",
        "indices" : [ 114, 127 ],
        "id_str" : "287093748",
        "id" : 287093748
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "elt",
        "indices" : [ 128, 132 ]
      } ],
      "urls" : [ {
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/FyKoMT7Lzv",
        "expanded_url" : "http:\/\/wordandphrase.info",
        "display_url" : "wordandphrase.info"
      }, {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/wNLJbIx5MY",
        "expanded_url" : "http:\/\/wp.me\/p1wSAy-nJ",
        "display_url" : "wp.me\/p1wSAy-nJ"
      } ]
    },
    "geo" : { },
    "id_str" : "440072732286279681",
    "text" : "Helping language learners become language researchers: http:\/\/t.co\/FyKoMT7Lzv (part 1) http:\/\/t.co\/wNLJbIx5MY via @lizziepinard #elt",
    "id" : 440072732286279681,
    "created_at" : "2014-03-02 10:34:50 +0000",
    "user" : {
      "name" : "Natallia Novikava",
      "screen_name" : "Natashetta",
      "protected" : false,
      "id_str" : "56308635",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2877370292\/d6370dfafaa5506c53671f1bd1da0cdc_normal.jpeg",
      "id" : 56308635,
      "verified" : false
    }
  },
  "id" : 440087075233480704,
  "created_at" : "2014-03-02 11:31:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alannah Fitzgerald",
      "screen_name" : "AlannahFitz",
      "indices" : [ 3, 15 ],
      "id_str" : "223613160",
      "id" : 223613160
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oerrh",
      "indices" : [ 58, 64 ]
    }, {
      "text" : "oer",
      "indices" : [ 65, 69 ]
    }, {
      "text" : "elearning",
      "indices" : [ 70, 80 ]
    }, {
      "text" : "elt",
      "indices" : [ 81, 85 ]
    }, {
      "text" : "mooc",
      "indices" : [ 86, 91 ]
    }, {
      "text" : "tirf",
      "indices" : [ 92, 97 ]
    }, {
      "text" : "tleap",
      "indices" : [ 98, 104 ]
    }, {
      "text" : "ocwc",
      "indices" : [ 105, 110 ]
    }, {
      "text" : "iatefl",
      "indices" : [ 111, 118 ]
    }, {
      "text" : "esl",
      "indices" : [ 119, 123 ]
    }, {
      "text" : "efl",
      "indices" : [ 124, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/Vg95Rl1lM3",
      "expanded_url" : "http:\/\/lnkd.in\/bqHz-VQ",
      "display_url" : "lnkd.in\/bqHz-VQ"
    } ]
  },
  "geo" : { },
  "id_str" : "439871222256783360",
  "text" : "RT @AlannahFitz: Educating in Beta http:\/\/t.co\/Vg95Rl1lM3 #oerrh #oer #elearning #elt #mooc #tirf #tleap #ocwc #iatefl #esl #efl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.linkedin.com\/\" rel=\"nofollow\"\u003ELinkedIn\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "oerrh",
        "indices" : [ 41, 47 ]
      }, {
        "text" : "oer",
        "indices" : [ 48, 52 ]
      }, {
        "text" : "elearning",
        "indices" : [ 53, 63 ]
      }, {
        "text" : "elt",
        "indices" : [ 64, 68 ]
      }, {
        "text" : "mooc",
        "indices" : [ 69, 74 ]
      }, {
        "text" : "tirf",
        "indices" : [ 75, 80 ]
      }, {
        "text" : "tleap",
        "indices" : [ 81, 87 ]
      }, {
        "text" : "ocwc",
        "indices" : [ 88, 93 ]
      }, {
        "text" : "iatefl",
        "indices" : [ 94, 101 ]
      }, {
        "text" : "esl",
        "indices" : [ 102, 106 ]
      }, {
        "text" : "efl",
        "indices" : [ 107, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 18, 40 ],
        "url" : "http:\/\/t.co\/Vg95Rl1lM3",
        "expanded_url" : "http:\/\/lnkd.in\/bqHz-VQ",
        "display_url" : "lnkd.in\/bqHz-VQ"
      } ]
    },
    "geo" : { },
    "id_str" : "439542118277595136",
    "text" : "Educating in Beta http:\/\/t.co\/Vg95Rl1lM3 #oerrh #oer #elearning #elt #mooc #tirf #tleap #ocwc #iatefl #esl #efl",
    "id" : 439542118277595136,
    "created_at" : "2014-02-28 23:26:21 +0000",
    "user" : {
      "name" : "Alannah Fitzgerald",
      "screen_name" : "AlannahFitz",
      "protected" : false,
      "id_str" : "223613160",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2645381550\/e07d3b354efdac11bce2725cbc44e94e_normal.png",
      "id" : 223613160,
      "verified" : false
    }
  },
  "id" : 439871222256783360,
  "created_at" : "2014-03-01 21:14:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/439868335023353856\/photo\/1",
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/I1NOLucbVV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bhq565GCcAA9eKX.jpg",
      "id_str" : "439868335031742464",
      "id" : 439868335031742464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bhq565GCcAA9eKX.jpg",
      "sizes" : [ {
        "h" : 283,
        "resize" : "fit",
        "w" : 310
      }, {
        "h" : 283,
        "resize" : "fit",
        "w" : 310
      }, {
        "h" : 283,
        "resize" : "fit",
        "w" : 310
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 283,
        "resize" : "fit",
        "w" : 310
      } ],
      "display_url" : "pic.twitter.com\/I1NOLucbVV"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/gnEFqIfjf8",
      "expanded_url" : "https:\/\/plus.google.com\/u\/0\/communities\/101266284417587206243",
      "display_url" : "plus.google.com\/u\/0\/communitie\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439868335023353856",
  "text" : "David Shepherd signals a Nelson 111 for G+ CL community https:\/\/t.co\/gnEFqIfjf8 http:\/\/t.co\/I1NOLucbVV",
  "id" : 439868335023353856,
  "created_at" : "2014-03-01 21:02:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Rayson",
      "screen_name" : "perayson",
      "indices" : [ 0, 9 ],
      "id_str" : "263108959",
      "id" : 263108959
    }, {
      "name" : "Alistair Baron",
      "screen_name" : "al586",
      "indices" : [ 10, 16 ],
      "id_str" : "50316421",
      "id" : 50316421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439830101627514880",
  "geo" : { },
  "id_str" : "439837403990491136",
  "in_reply_to_user_id" : 263108959,
  "text" : "@perayson @al586 thanks, will you be adding more nationalities from ICLE to the DICER?",
  "id" : 439837403990491136,
  "in_reply_to_status_id" : 439830101627514880,
  "created_at" : "2014-03-01 18:59:43 +0000",
  "in_reply_to_screen_name" : "perayson",
  "in_reply_to_user_id_str" : "263108959",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monika Sobejko",
      "screen_name" : "SobejM",
      "indices" : [ 0, 7 ],
      "id_str" : "380504775",
      "id" : 380504775
    }, {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 74, 85 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/T2Pk6FUxZf",
      "expanded_url" : "http:\/\/learnercorpus.blogspot.fr\/2014\/02\/openly-available-learner-corpora-1.html?spref=tw",
      "display_url" : "learnercorpus.blogspot.fr\/2014\/02\/openly\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "439671753896640512",
  "geo" : { },
  "id_str" : "439806453172686848",
  "in_reply_to_user_id" : 380504775,
  "text" : "@SobejM i think u a referring to series on open access learner corpora by @lexicoloco e.g. c 1st one here http:\/\/t.co\/T2Pk6FUxZf",
  "id" : 439806453172686848,
  "in_reply_to_status_id" : 439671753896640512,
  "created_at" : "2014-03-01 16:56:44 +0000",
  "in_reply_to_screen_name" : "SobejM",
  "in_reply_to_user_id_str" : "380504775",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/2ziNMu6qnp",
      "expanded_url" : "http:\/\/www.counterpunch.org\/2014\/02\/28\/on-academic-labor\/",
      "display_url" : "counterpunch.org\/2014\/02\/28\/on-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439796382946582528",
  "text" : "Noam Chomksy - On academic labour http:\/\/t.co\/2ziNMu6qnp",
  "id" : 439796382946582528,
  "created_at" : "2014-03-01 16:16:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "P\u00E9rez-Paredes",
      "screen_name" : "perezparedes",
      "indices" : [ 0, 13 ],
      "id_str" : "28528850",
      "id" : 28528850
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439654395656273920",
  "geo" : { },
  "id_str" : "439788306990387200",
  "in_reply_to_user_id" : 28528850,
  "text" : "@perezparedes file not available?",
  "id" : 439788306990387200,
  "in_reply_to_status_id" : 439654395656273920,
  "created_at" : "2014-03-01 15:44:37 +0000",
  "in_reply_to_screen_name" : "perezparedes",
  "in_reply_to_user_id_str" : "28528850",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Rayson",
      "screen_name" : "perayson",
      "indices" : [ 0, 9 ],
      "id_str" : "263108959",
      "id" : 263108959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439787421174353921",
  "in_reply_to_user_id" : 263108959,
  "text" : "@perayson hi paul in DICER what learner corpora are used? thanks",
  "id" : 439787421174353921,
  "created_at" : "2014-03-01 15:41:06 +0000",
  "in_reply_to_screen_name" : "perayson",
  "in_reply_to_user_id_str" : "263108959",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/401hc9xbc5",
      "expanded_url" : "https:\/\/plus.google.com\/104940199413423400545\/posts\/TALuyJ4rTAD",
      "display_url" : "plus.google.com\/10494019941342\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439787040822284288",
  "text" : "are u interested in spelling errors (Fr, Gr, Sp)? have a look here https:\/\/t.co\/401hc9xbc5",
  "id" : 439787040822284288,
  "created_at" : "2014-03-01 15:39:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 3, 14 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "efl",
      "indices" : [ 120, 124 ]
    }, {
      "text" : "esol",
      "indices" : [ 125, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/32c1h9PEh4",
      "expanded_url" : "http:\/\/bit.ly\/1fQELJs",
      "display_url" : "bit.ly\/1fQELJs"
    } ]
  },
  "geo" : { },
  "id_str" : "439776908436594689",
  "text" : "RT @leoselivan: Back to blogging! New post: Horizontal alternatives to vertical lists | Leoxicon http:\/\/t.co\/32c1h9PEh4 #efl #esol",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "efl",
        "indices" : [ 104, 108 ]
      }, {
        "text" : "esol",
        "indices" : [ 109, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/32c1h9PEh4",
        "expanded_url" : "http:\/\/bit.ly\/1fQELJs",
        "display_url" : "bit.ly\/1fQELJs"
      } ]
    },
    "geo" : { },
    "id_str" : "439751419353378817",
    "text" : "Back to blogging! New post: Horizontal alternatives to vertical lists | Leoxicon http:\/\/t.co\/32c1h9PEh4 #efl #esol",
    "id" : 439751419353378817,
    "created_at" : "2014-03-01 13:18:03 +0000",
    "user" : {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "protected" : false,
      "id_str" : "408365496",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/460546508601819136\/12ivDBb__normal.jpeg",
      "id" : 408365496,
      "verified" : false
    }
  },
  "id" : 439776908436594689,
  "created_at" : "2014-03-01 14:59:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
} ]