Grailbird.data.tweets_2016_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sec News Bot",
      "screen_name" : "SecNewsBot",
      "indices" : [ 3, 14 ],
      "id_str" : "4148888299",
      "id" : 4148888299
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/6YYbi2Zorm",
      "expanded_url" : "http:\/\/ift.tt\/1KfnNWY",
      "display_url" : "ift.tt\/1KfnNWY"
    } ]
  },
  "geo" : { },
  "id_str" : "693372602555981825",
  "text" : "RT @SecNewsBot: Hacker News - France's anti-terrorism laws leave Muslims in a state of fear https:\/\/t.co\/6YYbi2Zorm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/6YYbi2Zorm",
        "expanded_url" : "http:\/\/ift.tt\/1KfnNWY",
        "display_url" : "ift.tt\/1KfnNWY"
      } ]
    },
    "geo" : { },
    "id_str" : "693368338098081792",
    "text" : "Hacker News - France's anti-terrorism laws leave Muslims in a state of fear https:\/\/t.co\/6YYbi2Zorm",
    "id" : 693368338098081792,
    "created_at" : "2016-01-30 09:41:08 +0000",
    "user" : {
      "name" : "Sec News Bot",
      "screen_name" : "SecNewsBot",
      "protected" : false,
      "id_str" : "4148888299",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662701599769231360\/XUc4W7Xm_normal.jpg",
      "id" : 4148888299,
      "verified" : false
    }
  },
  "id" : 693372602555981825,
  "created_at" : "2016-01-30 09:58:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusresources",
      "indices" : [ 83, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/w7aSvhhoGk",
      "expanded_url" : "https:\/\/github.com\/ContentMine\/quickscrape",
      "display_url" : "github.com\/ContentMine\/qu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "693360139160686592",
  "text" : "quickscrape easy to use tool to d\/l various journal papers https:\/\/t.co\/w7aSvhhoGk #corpusresources",
  "id" : 693360139160686592,
  "created_at" : "2016-01-30 09:08:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angus B Grieve-Smith",
      "screen_name" : "grvsmth",
      "indices" : [ 3, 11 ],
      "id_str" : "22381639",
      "id" : 22381639
    }, {
      "name" : "AllThingsLinguistic",
      "screen_name" : "AllThingsLing",
      "indices" : [ 112, 126 ],
      "id_str" : "857291268",
      "id" : 857291268
    }, {
      "name" : "Jeremy Harmon",
      "screen_name" : "Harmonov",
      "indices" : [ 127, 136 ],
      "id_str" : "261005543",
      "id" : 261005543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/ySV4U0aWBu",
      "expanded_url" : "http:\/\/grieve-smith.com\/blog\/2016\/01\/its-got-to-be-deontic-necessity\/",
      "display_url" : "grieve-smith.com\/blog\/2016\/01\/i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "693343728354861058",
  "text" : "RT @grvsmth: New post: It's got to be deontic necessity in that Jackson Browne song https:\/\/t.co\/ySV4U0aWBu h\/t @AllThingsLing @Harmonov",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "AllThingsLinguistic",
        "screen_name" : "AllThingsLing",
        "indices" : [ 99, 113 ],
        "id_str" : "857291268",
        "id" : 857291268
      }, {
        "name" : "Jeremy Harmon",
        "screen_name" : "Harmonov",
        "indices" : [ 114, 123 ],
        "id_str" : "261005543",
        "id" : 261005543
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/ySV4U0aWBu",
        "expanded_url" : "http:\/\/grieve-smith.com\/blog\/2016\/01\/its-got-to-be-deontic-necessity\/",
        "display_url" : "grieve-smith.com\/blog\/2016\/01\/i\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "693323328690503680",
    "text" : "New post: It's got to be deontic necessity in that Jackson Browne song https:\/\/t.co\/ySV4U0aWBu h\/t @AllThingsLing @Harmonov",
    "id" : 693323328690503680,
    "created_at" : "2016-01-30 06:42:17 +0000",
    "user" : {
      "name" : "Angus B Grieve-Smith",
      "screen_name" : "grvsmth",
      "protected" : false,
      "id_str" : "22381639",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/94827231\/portrait_normal.png",
      "id" : 22381639,
      "verified" : false
    }
  },
  "id" : 693343728354861058,
  "created_at" : "2016-01-30 08:03:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/P0rgkdX84f",
      "expanded_url" : "https:\/\/plus.google.com\/+MuraNava\/posts\/FBJxCSXKQ5q",
      "display_url" : "plus.google.com\/+MuraNava\/post\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "693171943051300864",
  "text" : "Between genres: science journalism and science research https:\/\/t.co\/P0rgkdX84f",
  "id" : 693171943051300864,
  "created_at" : "2016-01-29 20:40:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will McCulloch",
      "screen_name" : "EnglishHamburg",
      "indices" : [ 0, 15 ],
      "id_str" : "387245091",
      "id" : 387245091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "693113020998914048",
  "geo" : { },
  "id_str" : "693144048496988160",
  "in_reply_to_user_id" : 387245091,
  "text" : "@EnglishHamburg indeed, there was a noticeable pause in the noise of the Tory audience behind Cameron in the video clip",
  "id" : 693144048496988160,
  "in_reply_to_status_id" : 693113020998914048,
  "created_at" : "2016-01-29 18:49:53 +0000",
  "in_reply_to_screen_name" : "EnglishHamburg",
  "in_reply_to_user_id_str" : "387245091",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "indices" : [ 3, 15 ],
      "id_str" : "849729062",
      "id" : 849729062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/DjqV0orRLj",
      "expanded_url" : "http:\/\/www.macmillandictionaryblog.com\/just-a-bunch-of-politicians",
      "display_url" : "macmillandictionaryblog.com\/just-a-bunch-o\u2026"
    }, {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/ubMxM1BDMa",
      "expanded_url" : "http:\/\/cass.lancs.ac.uk\/?p=1880",
      "display_url" : "cass.lancs.ac.uk\/?p=1880"
    } ]
  },
  "geo" : { },
  "id_str" : "693050133768990720",
  "text" : "RT @TonyMcEnery: A bunch of .... Nice piece from Macmillan Dictionaries: https:\/\/t.co\/DjqV0orRLj  Similar to the results for speech: https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/DjqV0orRLj",
        "expanded_url" : "http:\/\/www.macmillandictionaryblog.com\/just-a-bunch-of-politicians",
        "display_url" : "macmillandictionaryblog.com\/just-a-bunch-o\u2026"
      }, {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/ubMxM1BDMa",
        "expanded_url" : "http:\/\/cass.lancs.ac.uk\/?p=1880",
        "display_url" : "cass.lancs.ac.uk\/?p=1880"
      } ]
    },
    "geo" : { },
    "id_str" : "693043975922585601",
    "text" : "A bunch of .... Nice piece from Macmillan Dictionaries: https:\/\/t.co\/DjqV0orRLj  Similar to the results for speech: https:\/\/t.co\/ubMxM1BDMa",
    "id" : 693043975922585601,
    "created_at" : "2016-01-29 12:12:14 +0000",
    "user" : {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "protected" : false,
      "id_str" : "849729062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2676020930\/a4a1f40d56b447c9dfca1d7b9be4f4b4_normal.jpeg",
      "id" : 849729062,
      "verified" : false
    }
  },
  "id" : 693050133768990720,
  "created_at" : "2016-01-29 12:36:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bruno Leys",
      "screen_name" : "BrunoLeys",
      "indices" : [ 0, 10 ],
      "id_str" : "19535265",
      "id" : 19535265
    }, {
      "name" : "James Taylor",
      "screen_name" : "theteacherjames",
      "indices" : [ 11, 27 ],
      "id_str" : "71746265",
      "id" : 71746265
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/iubHIzghFQ",
      "expanded_url" : "https:\/\/books.google.fr\/books?id=qFuPBAAAQBAJ&lpg=PA124&ots=VXB8KSUfQ7&dq=finite%20non-finite%20verbs%20spoken%20english%20corpora&pg=PA126#v=onepage&q=finite%20non-finite%20verbs%20spoken%20english%20corpora&f=false",
      "display_url" : "books.google.fr\/books?id=qFuPB\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "693008908575719424",
  "geo" : { },
  "id_str" : "693022460602613760",
  "in_reply_to_user_id" : 19535265,
  "text" : "@BrunoLeys @theteacherjames maybe from this table https:\/\/t.co\/iubHIzghFQ",
  "id" : 693022460602613760,
  "in_reply_to_status_id" : 693008908575719424,
  "created_at" : "2016-01-29 10:46:44 +0000",
  "in_reply_to_screen_name" : "BrunoLeys",
  "in_reply_to_user_id_str" : "19535265",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 0, 9 ],
      "id_str" : "121063600",
      "id" : 121063600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "692949872874541056",
  "geo" : { },
  "id_str" : "693002411762454528",
  "in_reply_to_user_id" : 121063600,
  "text" : "@whyshona merci, je connaissais pas la chercheuse ni TXM mais pas r\u00E9ussi \u00E0 l'installer de Mac OSX :\/",
  "id" : 693002411762454528,
  "in_reply_to_status_id" : 692949872874541056,
  "created_at" : "2016-01-29 09:27:04 +0000",
  "in_reply_to_screen_name" : "whyshona",
  "in_reply_to_user_id_str" : "121063600",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/qER8N1N71c",
      "expanded_url" : "http:\/\/www.eurotrib.com\/story\/2016\/1\/27\/141848\/622",
      "display_url" : "eurotrib.com\/story\/2016\/1\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "692753780778127360",
  "text" : "Taubira resigns https:\/\/t.co\/qER8N1N71c",
  "id" : 692753780778127360,
  "created_at" : "2016-01-28 16:59:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexandria Hall",
      "screen_name" : "alxndghall",
      "indices" : [ 0, 11 ],
      "id_str" : "1656929592",
      "id" : 1656929592
    }, {
      "name" : "sina zare",
      "screen_name" : "sina7130",
      "indices" : [ 12, 21 ],
      "id_str" : "414256183",
      "id" : 414256183
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "692457580115943424",
  "geo" : { },
  "id_str" : "692743747986128897",
  "in_reply_to_user_id" : 1656929592,
  "text" : "@alxndghall @sina7130 dunno if i was Italian i may be more interested in the 17bill biz deals than whether sme statures were covered up :\/",
  "id" : 692743747986128897,
  "in_reply_to_status_id" : 692457580115943424,
  "created_at" : "2016-01-28 16:19:14 +0000",
  "in_reply_to_screen_name" : "alxndghall",
  "in_reply_to_user_id_str" : "1656929592",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Viola Wiegand",
      "screen_name" : "violawiegand",
      "indices" : [ 0, 13 ],
      "id_str" : "254378772",
      "id" : 254378772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "692728911353004032",
  "geo" : { },
  "id_str" : "692735140645212160",
  "in_reply_to_user_id" : 254378772,
  "text" : "@violawiegand glad to help all the best for your class : )",
  "id" : 692735140645212160,
  "in_reply_to_status_id" : 692728911353004032,
  "created_at" : "2016-01-28 15:45:02 +0000",
  "in_reply_to_screen_name" : "violawiegand",
  "in_reply_to_user_id_str" : "254378772",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "indices" : [ 3, 19 ],
      "id_str" : "1326508478",
      "id" : 1326508478
    }, {
      "name" : "Dr Claire Hardaker",
      "screen_name" : "DrClaireH",
      "indices" : [ 96, 106 ],
      "id_str" : "237842162",
      "id" : 237842162
    }, {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "indices" : [ 107, 116 ],
      "id_str" : "167020390",
      "id" : 167020390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/TchCtqYUFA",
      "expanded_url" : "http:\/\/cass.lancs.ac.uk\/?p=1874",
      "display_url" : "cass.lancs.ac.uk\/?p=1874"
    } ]
  },
  "geo" : { },
  "id_str" : "692724051144503296",
  "text" : "RT @CorpusSocialSci: FireAnt: a new tool for analysing social network data is being launched by @DrClaireH @antlabjp! Learn more here: http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dr Claire Hardaker",
        "screen_name" : "DrClaireH",
        "indices" : [ 75, 85 ],
        "id_str" : "237842162",
        "id" : 237842162
      }, {
        "name" : "Laurence Anthony",
        "screen_name" : "antlabjp",
        "indices" : [ 86, 95 ],
        "id_str" : "167020390",
        "id" : 167020390
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/TchCtqYUFA",
        "expanded_url" : "http:\/\/cass.lancs.ac.uk\/?p=1874",
        "display_url" : "cass.lancs.ac.uk\/?p=1874"
      } ]
    },
    "geo" : { },
    "id_str" : "692695572063584256",
    "text" : "FireAnt: a new tool for analysing social network data is being launched by @DrClaireH @antlabjp! Learn more here: https:\/\/t.co\/TchCtqYUFA",
    "id" : 692695572063584256,
    "created_at" : "2016-01-28 13:07:48 +0000",
    "user" : {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "protected" : false,
      "id_str" : "1326508478",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3493899777\/ced36fe15c32eb911cbe3d64377524dc_normal.jpeg",
      "id" : 1326508478,
      "verified" : false
    }
  },
  "id" : 692724051144503296,
  "created_at" : "2016-01-28 15:00:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "indices" : [ 3, 19 ],
      "id_str" : "1326508478",
      "id" : 1326508478
    }, {
      "name" : "Robbie Love",
      "screen_name" : "lovermob",
      "indices" : [ 85, 94 ],
      "id_str" : "19469715",
      "id" : 19469715
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BNC2014",
      "indices" : [ 107, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/YoDrWwxwpp",
      "expanded_url" : "http:\/\/cass.lancs.ac.uk\/?p=1880",
      "display_url" : "cass.lancs.ac.uk\/?p=1880"
    } ]
  },
  "geo" : { },
  "id_str" : "692723715554070528",
  "text" : "RT @CorpusSocialSci: What\u2019s wrong with David Cameron's use of \u201Ca bunch of migrants\u201D? @lovermob uses Spoken #BNC2014 to find out! https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Robbie Love",
        "screen_name" : "lovermob",
        "indices" : [ 64, 73 ],
        "id_str" : "19469715",
        "id" : 19469715
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BNC2014",
        "indices" : [ 86, 94 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/YoDrWwxwpp",
        "expanded_url" : "http:\/\/cass.lancs.ac.uk\/?p=1880",
        "display_url" : "cass.lancs.ac.uk\/?p=1880"
      } ]
    },
    "geo" : { },
    "id_str" : "692722258025058304",
    "text" : "What\u2019s wrong with David Cameron's use of \u201Ca bunch of migrants\u201D? @lovermob uses Spoken #BNC2014 to find out! https:\/\/t.co\/YoDrWwxwpp",
    "id" : 692722258025058304,
    "created_at" : "2016-01-28 14:53:51 +0000",
    "user" : {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "protected" : false,
      "id_str" : "1326508478",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3493899777\/ced36fe15c32eb911cbe3d64377524dc_normal.jpeg",
      "id" : 1326508478,
      "verified" : false
    }
  },
  "id" : 692723715554070528,
  "created_at" : "2016-01-28 14:59:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Viola Wiegand",
      "screen_name" : "violawiegand",
      "indices" : [ 0, 13 ],
      "id_str" : "254378772",
      "id" : 254378772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/HacAUI3ZUJ",
      "expanded_url" : "http:\/\/www.thegrammarlab.com\/?portfolio=michigan-corpus-of-upper-level-student-papers",
      "display_url" : "thegrammarlab.com\/?portfolio=mic\u2026"
    }, {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/yjjpp53Nxo",
      "expanded_url" : "http:\/\/ota.ox.ac.uk\/desc\/0159",
      "display_url" : "ota.ox.ac.uk\/desc\/0159"
    } ]
  },
  "in_reply_to_status_id_str" : "692707690561298432",
  "geo" : { },
  "id_str" : "692723205371490304",
  "in_reply_to_user_id" : 254378772,
  "text" : "@violawiegand hi u can email this guy to get micusp https:\/\/t.co\/HacAUI3ZUJ there is this new corpus https:\/\/t.co\/yjjpp53Nxo",
  "id" : 692723205371490304,
  "in_reply_to_status_id" : 692707690561298432,
  "created_at" : "2016-01-28 14:57:36 +0000",
  "in_reply_to_screen_name" : "violawiegand",
  "in_reply_to_user_id_str" : "254378772",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((David Traynier)))",
      "screen_name" : "DTraynier",
      "indices" : [ 3, 13 ],
      "id_str" : "317716198",
      "id" : 317716198
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/94YVdOT8HU",
      "expanded_url" : "https:\/\/twitter.com\/ConHome\/status\/692413478657773568",
      "display_url" : "twitter.com\/ConHome\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "692414630233313282",
  "text" : "RT @DTraynier: Because that's what you do to migrants and refugees. You stand up to them.  https:\/\/t.co\/94YVdOT8HU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/94YVdOT8HU",
        "expanded_url" : "https:\/\/twitter.com\/ConHome\/status\/692413478657773568",
        "display_url" : "twitter.com\/ConHome\/status\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "692413868522496001",
    "text" : "Because that's what you do to migrants and refugees. You stand up to them.  https:\/\/t.co\/94YVdOT8HU",
    "id" : 692413868522496001,
    "created_at" : "2016-01-27 18:28:25 +0000",
    "user" : {
      "name" : "(((David Traynier)))",
      "screen_name" : "DTraynier",
      "protected" : false,
      "id_str" : "317716198",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727929911877480451\/fLuwL370_normal.jpg",
      "id" : 317716198,
      "verified" : false
    }
  },
  "id" : 692414630233313282,
  "created_at" : "2016-01-27 18:31:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/1GJSbJyVLv",
      "expanded_url" : "http:\/\/www.counterpunch.org\/2016\/01\/27\/the-flint-water-disaster-a-perfect-storm-of-downplaying-denial-and-deceit\/",
      "display_url" : "counterpunch.org\/2016\/01\/27\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "692398869800443906",
  "text" : "The Flint Water Disaster: a Perfect Storm of Downplaying, Denial and Deceit: https:\/\/t.co\/1GJSbJyVLv",
  "id" : 692398869800443906,
  "created_at" : "2016-01-27 17:28:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexandria Hall",
      "screen_name" : "alxndghall",
      "indices" : [ 0, 11 ],
      "id_str" : "1656929592",
      "id" : 1656929592
    }, {
      "name" : "CNN",
      "screen_name" : "CNN",
      "indices" : [ 12, 16 ],
      "id_str" : "759251",
      "id" : 759251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "692394292434845696",
  "geo" : { },
  "id_str" : "692396353322926080",
  "in_reply_to_user_id" : 1656929592,
  "text" : "@alxndghall @CNN um if as reported it's called making guests feel at home?",
  "id" : 692396353322926080,
  "in_reply_to_status_id" : 692394292434845696,
  "created_at" : "2016-01-27 17:18:49 +0000",
  "in_reply_to_screen_name" : "alxndghall",
  "in_reply_to_user_id_str" : "1656929592",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PMQs",
      "indices" : [ 123, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/hA44NWxllL",
      "expanded_url" : "http:\/\/www.politics.co.uk\/blogs\/2016\/01\/27\/pmqs-verdict-cameron-shames-himself-with-bunch-of-migrants-c",
      "display_url" : "politics.co.uk\/blogs\/2016\/01\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "692351998453223424",
  "text" : "RT @pchallinor: You can take the prick out of the pig, but you can't take the pig out of the prick https:\/\/t.co\/hA44NWxllL #PMQs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PMQs",
        "indices" : [ 107, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/hA44NWxllL",
        "expanded_url" : "http:\/\/www.politics.co.uk\/blogs\/2016\/01\/27\/pmqs-verdict-cameron-shames-himself-with-bunch-of-migrants-c",
        "display_url" : "politics.co.uk\/blogs\/2016\/01\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "692345510531829760",
    "text" : "You can take the prick out of the pig, but you can't take the pig out of the prick https:\/\/t.co\/hA44NWxllL #PMQs",
    "id" : 692345510531829760,
    "created_at" : "2016-01-27 13:56:47 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 692351998453223424,
  "created_at" : "2016-01-27 14:22:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    }, {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 22, 32 ],
      "id_str" : "6531902",
      "id" : 6531902
    }, {
      "name" : "Owen Jones",
      "screen_name" : "OwenJones84",
      "indices" : [ 103, 115 ],
      "id_str" : "65045121",
      "id" : 65045121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/iuvU6v964A",
      "expanded_url" : "http:\/\/www.medialens.org\/index.php\/alerts\/alert-archive\/2016\/811-obama-the-art-of-ruin.html",
      "display_url" : "medialens.org\/index.php\/aler\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "692335185359142913",
  "text" : "RT @johnwhilley: Fine @medialens on tempered liberal criticisms of Obama and savaging of Putin, citing @OwenJones84 as key example https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Media Lens",
        "screen_name" : "medialens",
        "indices" : [ 5, 15 ],
        "id_str" : "6531902",
        "id" : 6531902
      }, {
        "name" : "Owen Jones",
        "screen_name" : "OwenJones84",
        "indices" : [ 86, 98 ],
        "id_str" : "65045121",
        "id" : 65045121
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/iuvU6v964A",
        "expanded_url" : "http:\/\/www.medialens.org\/index.php\/alerts\/alert-archive\/2016\/811-obama-the-art-of-ruin.html",
        "display_url" : "medialens.org\/index.php\/aler\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "692326059296079872",
    "text" : "Fine @medialens on tempered liberal criticisms of Obama and savaging of Putin, citing @OwenJones84 as key example https:\/\/t.co\/iuvU6v964A",
    "id" : 692326059296079872,
    "created_at" : "2016-01-27 12:39:29 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 692335185359142913,
  "created_at" : "2016-01-27 13:15:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Huw Jarvis",
      "screen_name" : "TESOLacademic",
      "indices" : [ 0, 14 ],
      "id_str" : "43409552",
      "id" : 43409552
    }, {
      "name" : "Angelos Bollas",
      "screen_name" : "angelos_bollas",
      "indices" : [ 15, 30 ],
      "id_str" : "309578964",
      "id" : 309578964
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "692297658401214464",
  "geo" : { },
  "id_str" : "692328317169565697",
  "in_reply_to_user_id" : 43409552,
  "text" : "@TESOLacademic @angelos_bollas true though it is a very good proxy",
  "id" : 692328317169565697,
  "in_reply_to_status_id" : 692297658401214464,
  "created_at" : "2016-01-27 12:48:28 +0000",
  "in_reply_to_screen_name" : "TESOLacademic",
  "in_reply_to_user_id_str" : "43409552",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Moore",
      "screen_name" : "lexicojules",
      "indices" : [ 3, 15 ],
      "id_str" : "424320799",
      "id" : 424320799
    }, {
      "name" : "New Scientist",
      "screen_name" : "newscientist",
      "indices" : [ 70, 83 ],
      "id_str" : "19658826",
      "id" : 19658826
    }, {
      "name" : "Alison George",
      "screen_name" : "alisonge",
      "indices" : [ 91, 100 ],
      "id_str" : "21769809",
      "id" : 21769809
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EAP",
      "indices" : [ 49, 53 ]
    }, {
      "text" : "tleap",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 126, 140 ],
      "url" : "https:\/\/t.co\/ndiaJOXWkj",
      "expanded_url" : "http:\/\/ow.ly\/XA1Hc",
      "display_url" : "ow.ly\/XA1Hc"
    } ]
  },
  "geo" : { },
  "id_str" : "692270599335469056",
  "text" : "RT @lexicojules: Are magazine articles useful in #EAP? Interview with @newscientist editor @alisonge to learn about the genre https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "New Scientist",
        "screen_name" : "newscientist",
        "indices" : [ 53, 66 ],
        "id_str" : "19658826",
        "id" : 19658826
      }, {
        "name" : "Alison George",
        "screen_name" : "alisonge",
        "indices" : [ 74, 83 ],
        "id_str" : "21769809",
        "id" : 21769809
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EAP",
        "indices" : [ 32, 36 ]
      }, {
        "text" : "tleap",
        "indices" : [ 133, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/ndiaJOXWkj",
        "expanded_url" : "http:\/\/ow.ly\/XA1Hc",
        "display_url" : "ow.ly\/XA1Hc"
      } ]
    },
    "geo" : { },
    "id_str" : "692269417552596992",
    "text" : "Are magazine articles useful in #EAP? Interview with @newscientist editor @alisonge to learn about the genre https:\/\/t.co\/ndiaJOXWkj #tleap",
    "id" : 692269417552596992,
    "created_at" : "2016-01-27 08:54:25 +0000",
    "user" : {
      "name" : "Julie Moore",
      "screen_name" : "lexicojules",
      "protected" : false,
      "id_str" : "424320799",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/478823971870109696\/AzIax4m3_normal.jpeg",
      "id" : 424320799,
      "verified" : false
    }
  },
  "id" : 692270599335469056,
  "created_at" : "2016-01-27 08:59:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Cameron",
      "screen_name" : "mikercameron",
      "indices" : [ 45, 58 ],
      "id_str" : "14138494",
      "id" : 14138494
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/elDj7OURg8",
      "expanded_url" : "http:\/\/wp.me\/pwh7n-rL",
      "display_url" : "wp.me\/pwh7n-rL"
    } ]
  },
  "geo" : { },
  "id_str" : "691991239957282816",
  "text" : "Lifting the veil https:\/\/t.co\/elDj7OURg8 via @mikercameron",
  "id" : 691991239957282816,
  "created_at" : "2016-01-26 14:29:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "691964963309531137",
  "geo" : { },
  "id_str" : "691966847747543040",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish hehe :)",
  "id" : 691966847747543040,
  "in_reply_to_status_id" : 691964963309531137,
  "created_at" : "2016-01-26 12:52:07 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/rsRkhsQ6OS",
      "expanded_url" : "http:\/\/www.politics.co.uk\/blogs\/2016\/01\/26\/arrested-humiliated-detained-how-britain-treats-foreign-stud",
      "display_url" : "politics.co.uk\/blogs\/2016\/01\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "691956507609530368",
  "text" : "RT @pchallinor: Mad Tessie May doesn't want no brightest and best around here, thank you https:\/\/t.co\/rsRkhsQ6OS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/rsRkhsQ6OS",
        "expanded_url" : "http:\/\/www.politics.co.uk\/blogs\/2016\/01\/26\/arrested-humiliated-detained-how-britain-treats-foreign-stud",
        "display_url" : "politics.co.uk\/blogs\/2016\/01\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "691954923894882304",
    "text" : "Mad Tessie May doesn't want no brightest and best around here, thank you https:\/\/t.co\/rsRkhsQ6OS",
    "id" : 691954923894882304,
    "created_at" : "2016-01-26 12:04:44 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 691956507609530368,
  "created_at" : "2016-01-26 12:11:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AllThingsLinguistic",
      "screen_name" : "AllThingsLing",
      "indices" : [ 3, 17 ],
      "id_str" : "857291268",
      "id" : 857291268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 130, 148 ],
      "url" : "https:\/\/t.co\/lRO9msmF3Q",
      "expanded_url" : "http:\/\/tmblr.co\/ZuWOEv20aMc-e",
      "display_url" : "tmblr.co\/ZuWOEv20aMc-e"
    } ]
  },
  "geo" : { },
  "id_str" : "691953214581805058",
  "text" : "RT @AllThingsLing: The difference between epistemic &amp; deontic, necessity &amp; possibility, in a helpful overlapping diagram. https:\/\/t.co\/lRO9\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/lRO9msmF3Q",
        "expanded_url" : "http:\/\/tmblr.co\/ZuWOEv20aMc-e",
        "display_url" : "tmblr.co\/ZuWOEv20aMc-e"
      } ]
    },
    "geo" : { },
    "id_str" : "691765091142877184",
    "text" : "The difference between epistemic &amp; deontic, necessity &amp; possibility, in a helpful overlapping diagram. https:\/\/t.co\/lRO9msmF3Q",
    "id" : 691765091142877184,
    "created_at" : "2016-01-25 23:30:24 +0000",
    "user" : {
      "name" : "AllThingsLinguistic",
      "screen_name" : "AllThingsLing",
      "protected" : false,
      "id_str" : "857291268",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750400997206454273\/N0DmrmFi_normal.jpg",
      "id" : 857291268,
      "verified" : false
    }
  },
  "id" : 691953214581805058,
  "created_at" : "2016-01-26 11:57:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Bowman",
      "screen_name" : "sleepinyourhat",
      "indices" : [ 3, 18 ],
      "id_str" : "338526004",
      "id" : 338526004
    }, {
      "name" : "Stanford NLP Group",
      "screen_name" : "stanfordnlp",
      "indices" : [ 24, 36 ],
      "id_str" : "118263124",
      "id" : 118263124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/5g8kPAuLMx",
      "expanded_url" : "http:\/\/nlp.stanford.edu\/blog\/",
      "display_url" : "nlp.stanford.edu\/blog\/"
    } ]
  },
  "geo" : { },
  "id_str" : "691951874409365504",
  "text" : "RT @sleepinyourhat: The @stanfordnlp blog is now up! The first post has some new details on our SNLI corpus! https:\/\/t.co\/5g8kPAuLMx (Click\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stanford NLP Group",
        "screen_name" : "stanfordnlp",
        "indices" : [ 4, 16 ],
        "id_str" : "118263124",
        "id" : 118263124
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/5g8kPAuLMx",
        "expanded_url" : "http:\/\/nlp.stanford.edu\/blog\/",
        "display_url" : "nlp.stanford.edu\/blog\/"
      } ]
    },
    "geo" : { },
    "id_str" : "691757183139254274",
    "text" : "The @stanfordnlp blog is now up! The first post has some new details on our SNLI corpus! https:\/\/t.co\/5g8kPAuLMx (Click the title.)",
    "id" : 691757183139254274,
    "created_at" : "2016-01-25 22:58:59 +0000",
    "user" : {
      "name" : "Sam Bowman",
      "screen_name" : "sleepinyourhat",
      "protected" : false,
      "id_str" : "338526004",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/661660345820286976\/YFtLIXNN_normal.jpg",
      "id" : 338526004,
      "verified" : false
    }
  },
  "id" : 691951874409365504,
  "created_at" : "2016-01-26 11:52:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/N8RXP1AJwE",
      "expanded_url" : "http:\/\/nyti.ms\/23peeLv",
      "display_url" : "nyti.ms\/23peeLv"
    } ]
  },
  "geo" : { },
  "id_str" : "691946383356645379",
  "text" : "Marvin Minsky, Pioneer in Artificial Intelligence, Dies at 88 https:\/\/t.co\/N8RXP1AJwE",
  "id" : 691946383356645379,
  "created_at" : "2016-01-26 11:30:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chuck sandy",
      "screen_name" : "chucksandy",
      "indices" : [ 3, 14 ],
      "id_str" : "18880320",
      "id" : 18880320
    }, {
      "name" : "Scott Thornbury",
      "screen_name" : "thornburyscott",
      "indices" : [ 16, 31 ],
      "id_str" : "23090474",
      "id" : 23090474
    }, {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 36, 52 ],
      "id_str" : "394053348",
      "id" : 394053348
    }, {
      "name" : "ExcitELT",
      "screen_name" : "excitELT",
      "indices" : [ 128, 137 ],
      "id_str" : "4190768473",
      "id" : 4190768473
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 110, 114 ]
    }, {
      "text" : "recommended",
      "indices" : [ 115, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/mFqXbIHVDv",
      "expanded_url" : "http:\/\/www.excitelt.com\/blog\/",
      "display_url" : "excitelt.com\/blog\/"
    } ]
  },
  "geo" : { },
  "id_str" : "691916073172652032",
  "text" : "RT @chucksandy: @thornburyscott  on @michaelegriffin  and the other way around too.   https:\/\/t.co\/mFqXbIHVDv #elt #recommended @excitELT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Scott Thornbury",
        "screen_name" : "thornburyscott",
        "indices" : [ 0, 15 ],
        "id_str" : "23090474",
        "id" : 23090474
      }, {
        "name" : "Michael Griffin",
        "screen_name" : "michaelegriffin",
        "indices" : [ 20, 36 ],
        "id_str" : "394053348",
        "id" : 394053348
      }, {
        "name" : "ExcitELT",
        "screen_name" : "excitELT",
        "indices" : [ 112, 121 ],
        "id_str" : "4190768473",
        "id" : 4190768473
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "elt",
        "indices" : [ 94, 98 ]
      }, {
        "text" : "recommended",
        "indices" : [ 99, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 70, 93 ],
        "url" : "https:\/\/t.co\/mFqXbIHVDv",
        "expanded_url" : "http:\/\/www.excitelt.com\/blog\/",
        "display_url" : "excitelt.com\/blog\/"
      } ]
    },
    "geo" : { },
    "id_str" : "691908507810013184",
    "in_reply_to_user_id" : 23090474,
    "text" : "@thornburyscott  on @michaelegriffin  and the other way around too.   https:\/\/t.co\/mFqXbIHVDv #elt #recommended @excitELT",
    "id" : 691908507810013184,
    "created_at" : "2016-01-26 09:00:17 +0000",
    "in_reply_to_screen_name" : "thornburyscott",
    "in_reply_to_user_id_str" : "23090474",
    "user" : {
      "name" : "chuck sandy",
      "screen_name" : "chucksandy",
      "protected" : false,
      "id_str" : "18880320",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/620217802465513472\/poN-d2nR_normal.jpg",
      "id" : 18880320,
      "verified" : false
    }
  },
  "id" : 691916073172652032,
  "created_at" : "2016-01-26 09:30:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "unfortunate",
      "indices" : [ 12, 24 ]
    }, {
      "text" : "domainnames",
      "indices" : [ 25, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "691915948874416128",
  "text" : "Englishsite #unfortunate #domainnames",
  "id" : 691915948874416128,
  "created_at" : "2016-01-26 09:29:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "691374319222530050",
  "geo" : { },
  "id_str" : "691400882878050304",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan hey cool thx, are blogrolls making a comeback? :)",
  "id" : 691400882878050304,
  "in_reply_to_status_id" : 691374319222530050,
  "created_at" : "2016-01-24 23:23:10 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Walton",
      "screen_name" : "Tom_IHBCN",
      "indices" : [ 3, 13 ],
      "id_str" : "1534536726",
      "id" : 1534536726
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELT",
      "indices" : [ 100, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/aq70yytKNr",
      "expanded_url" : "http:\/\/bit.ly\/1ZKr56l",
      "display_url" : "bit.ly\/1ZKr56l"
    } ]
  },
  "geo" : { },
  "id_str" : "691238087909859328",
  "text" : "RT @Tom_IHBCN: Free app to practise grammar &amp; vocab thru football https:\/\/t.co\/aq70yytKNr B2-C1 #ELT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELT",
        "indices" : [ 85, 89 ]
      } ],
      "urls" : [ {
        "indices" : [ 55, 78 ],
        "url" : "https:\/\/t.co\/aq70yytKNr",
        "expanded_url" : "http:\/\/bit.ly\/1ZKr56l",
        "display_url" : "bit.ly\/1ZKr56l"
      } ]
    },
    "geo" : { },
    "id_str" : "691192568059695104",
    "text" : "Free app to practise grammar &amp; vocab thru football https:\/\/t.co\/aq70yytKNr B2-C1 #ELT",
    "id" : 691192568059695104,
    "created_at" : "2016-01-24 09:35:24 +0000",
    "user" : {
      "name" : "Tom Walton",
      "screen_name" : "Tom_IHBCN",
      "protected" : false,
      "id_str" : "1534536726",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461169753810145280\/YEtBocRM_normal.png",
      "id" : 1534536726,
      "verified" : false
    }
  },
  "id" : 691238087909859328,
  "created_at" : "2016-01-24 12:36:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vedrana Vojkovi\u0107",
      "screen_name" : "Ven_VVE",
      "indices" : [ 0, 8 ],
      "id_str" : "270839603",
      "id" : 270839603
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "691207950887690240",
  "geo" : { },
  "id_str" : "691208350080581633",
  "in_reply_to_user_id" : 270839603,
  "text" : "@Ven_VVE i agree maybe to do with fact they are Canadian sounds?",
  "id" : 691208350080581633,
  "in_reply_to_status_id" : 691207950887690240,
  "created_at" : "2016-01-24 10:38:07 +0000",
  "in_reply_to_screen_name" : "Ven_VVE",
  "in_reply_to_user_id_str" : "270839603",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vedrana Vojkovi\u0107",
      "screen_name" : "Ven_VVE",
      "indices" : [ 0, 8 ],
      "id_str" : "270839603",
      "id" : 270839603
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "691205245364469760",
  "in_reply_to_user_id" : 270839603,
  "text" : "@Ven_VVE hi Vedrana glad you liked &amp; shared HVPT post : )",
  "id" : 691205245364469760,
  "created_at" : "2016-01-24 10:25:47 +0000",
  "in_reply_to_screen_name" : "Ven_VVE",
  "in_reply_to_user_id_str" : "270839603",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 3, 13 ],
      "id_str" : "525274103",
      "id" : 525274103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/EKOveyZiFK",
      "expanded_url" : "https:\/\/pedagogablog.wordpress.com\/2016\/01\/24\/edtech-as-fetishismthe-edtech-commodity-chain",
      "display_url" : "pedagogablog.wordpress.com\/2016\/01\/24\/edt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "691204798172024832",
  "text" : "RT @ElkySmith: \u2018EdTech\u2019 as fetishism\/The \u2018EdTech\u2019 commodity\u00A0chain https:\/\/t.co\/EKOveyZiFK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 74 ],
        "url" : "https:\/\/t.co\/EKOveyZiFK",
        "expanded_url" : "https:\/\/pedagogablog.wordpress.com\/2016\/01\/24\/edtech-as-fetishismthe-edtech-commodity-chain",
        "display_url" : "pedagogablog.wordpress.com\/2016\/01\/24\/edt\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "691173594492080129",
    "text" : "\u2018EdTech\u2019 as fetishism\/The \u2018EdTech\u2019 commodity\u00A0chain https:\/\/t.co\/EKOveyZiFK",
    "id" : 691173594492080129,
    "created_at" : "2016-01-24 08:20:00 +0000",
    "user" : {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "protected" : false,
      "id_str" : "525274103",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/690658566370263041\/qggTYEb3_normal.jpg",
      "id" : 525274103,
      "verified" : false
    }
  },
  "id" : 691204798172024832,
  "created_at" : "2016-01-24 10:24:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tleap",
      "indices" : [ 73, 79 ]
    }, {
      "text" : "eap",
      "indices" : [ 80, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/1gSRFcHvdu",
      "expanded_url" : "https:\/\/eflnotes.wordpress.com\/wordlists\/",
      "display_url" : "eflnotes.wordpress.com\/wordlists\/"
    } ]
  },
  "geo" : { },
  "id_str" : "690925302374100992",
  "text" : "added Darmstadt Scientific Text Corpus wordlists https:\/\/t.co\/1gSRFcHvdu #tleap #eap",
  "id" : 690925302374100992,
  "created_at" : "2016-01-23 15:53:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 3, 18 ],
      "id_str" : "285614027",
      "id" : 285614027
    }, {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 105, 120 ],
      "id_str" : "285614027",
      "id" : 285614027
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ResearchBites",
      "indices" : [ 20, 34 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/rYsl3YlL20",
      "expanded_url" : "http:\/\/www.anthonyteacher.com\/blog\/researchbites\/research-bites-coursebooks-and-eap-part-3",
      "display_url" : "anthonyteacher.com\/blog\/researchb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "690924697819725824",
  "text" : "RT @AnthonyTeacher: #ResearchBites: Coursebooks and EAP, part 3 (discussion) https:\/\/t.co\/rYsl3YlL20 via @AnthonyTeacher",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "AnthonyTeacher",
        "screen_name" : "AnthonyTeacher",
        "indices" : [ 85, 100 ],
        "id_str" : "285614027",
        "id" : 285614027
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ResearchBites",
        "indices" : [ 0, 14 ]
      } ],
      "urls" : [ {
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/rYsl3YlL20",
        "expanded_url" : "http:\/\/www.anthonyteacher.com\/blog\/researchbites\/research-bites-coursebooks-and-eap-part-3",
        "display_url" : "anthonyteacher.com\/blog\/researchb\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "690909735772655617",
    "text" : "#ResearchBites: Coursebooks and EAP, part 3 (discussion) https:\/\/t.co\/rYsl3YlL20 via @AnthonyTeacher",
    "id" : 690909735772655617,
    "created_at" : "2016-01-23 14:51:32 +0000",
    "user" : {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "protected" : false,
      "id_str" : "285614027",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/412336845658132481\/Om5kKuMQ_normal.jpeg",
      "id" : 285614027,
      "verified" : false
    }
  },
  "id" : 690924697819725824,
  "created_at" : "2016-01-23 15:50:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/DuonDvZawH",
      "expanded_url" : "http:\/\/www.theguardian.com\/uk-news\/2016\/jan\/23\/unions-condemn-giving-spain-490m-uk-train-contract-as-a-kick-in-the-teeth",
      "display_url" : "theguardian.com\/uk-news\/2016\/j\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "690856759955722240",
  "text" : "RT @pchallinor: How the Conservatives are supporting British industry https:\/\/t.co\/DuonDvZawH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 77 ],
        "url" : "https:\/\/t.co\/DuonDvZawH",
        "expanded_url" : "http:\/\/www.theguardian.com\/uk-news\/2016\/jan\/23\/unions-condemn-giving-spain-490m-uk-train-contract-as-a-kick-in-the-teeth",
        "display_url" : "theguardian.com\/uk-news\/2016\/j\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "690855742929240066",
    "text" : "How the Conservatives are supporting British industry https:\/\/t.co\/DuonDvZawH",
    "id" : 690855742929240066,
    "created_at" : "2016-01-23 11:16:59 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 690856759955722240,
  "created_at" : "2016-01-23 11:21:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 3, 19 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/A9Jcxvh1HH",
      "expanded_url" : "https:\/\/twitter.com\/geoffreyjordan\/status\/690678648366456832",
      "display_url" : "twitter.com\/geoffreyjordan\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "690854968425848832",
  "text" : "RT @getgreatenglish: Forget the 'He said this' nonsense. Deep question: Can learners 'graduate' the EFL system or are they locked in? https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/A9Jcxvh1HH",
        "expanded_url" : "https:\/\/twitter.com\/geoffreyjordan\/status\/690678648366456832",
        "display_url" : "twitter.com\/geoffreyjordan\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "690815453749346304",
    "text" : "Forget the 'He said this' nonsense. Deep question: Can learners 'graduate' the EFL system or are they locked in? https:\/\/t.co\/A9Jcxvh1HH",
    "id" : 690815453749346304,
    "created_at" : "2016-01-23 08:36:53 +0000",
    "user" : {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "protected" : false,
      "id_str" : "2273617656",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724115932742721537\/LWTpFJX2_normal.jpg",
      "id" : 2273617656,
      "verified" : false
    }
  },
  "id" : 690854968425848832,
  "created_at" : "2016-01-23 11:13:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Ensor",
      "screen_name" : "sensor63",
      "indices" : [ 3, 12 ],
      "id_str" : "84562932",
      "id" : 84562932
    }, {
      "name" : "Terry Elliott",
      "screen_name" : "telliowkuwp",
      "indices" : [ 14, 26 ],
      "id_str" : "326772515",
      "id" : 326772515
    }, {
      "name" : "Daniel Bassill",
      "screen_name" : "tutormentorteam",
      "indices" : [ 27, 43 ],
      "id_str" : "45338918",
      "id" : 45338918
    }, {
      "name" : "\u2133\u0105h\u0105 B\u0105\u2113i \u0645\u0647\u0627 \u0628\u0627\u0644\u064A",
      "screen_name" : "Bali_Maha",
      "indices" : [ 44, 54 ],
      "id_str" : "1535273520",
      "id" : 1535273520
    }, {
      "name" : "Sandra Sinfield",
      "screen_name" : "Danceswithcloud",
      "indices" : [ 55, 71 ],
      "id_str" : "236802458",
      "id" : 236802458
    }, {
      "name" : "KevinHodgson",
      "screen_name" : "dogtrax",
      "indices" : [ 72, 80 ],
      "id_str" : "13307352",
      "id" : 13307352
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ccourses",
      "indices" : [ 132, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/2AkE6GmD57",
      "expanded_url" : "http:\/\/tachesdesens.blogspot.fr\/2016\/01\/open-doors-are-not-enough.html",
      "display_url" : "tachesdesens.blogspot.fr\/2016\/01\/open-d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "690605400182362113",
  "text" : "RT @sensor63: @telliowkuwp @tutormentorteam @Bali_Maha @Danceswithcloud @dogtrax Open doors are not enough.\nhttps:\/\/t.co\/2AkE6GmD57 #ccours\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Terry Elliott",
        "screen_name" : "telliowkuwp",
        "indices" : [ 0, 12 ],
        "id_str" : "326772515",
        "id" : 326772515
      }, {
        "name" : "Daniel Bassill",
        "screen_name" : "tutormentorteam",
        "indices" : [ 13, 29 ],
        "id_str" : "45338918",
        "id" : 45338918
      }, {
        "name" : "\u2133\u0105h\u0105 B\u0105\u2113i \u0645\u0647\u0627 \u0628\u0627\u0644\u064A",
        "screen_name" : "Bali_Maha",
        "indices" : [ 30, 40 ],
        "id_str" : "1535273520",
        "id" : 1535273520
      }, {
        "name" : "Sandra Sinfield",
        "screen_name" : "Danceswithcloud",
        "indices" : [ 41, 57 ],
        "id_str" : "236802458",
        "id" : 236802458
      }, {
        "name" : "KevinHodgson",
        "screen_name" : "dogtrax",
        "indices" : [ 58, 66 ],
        "id_str" : "13307352",
        "id" : 13307352
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ccourses",
        "indices" : [ 118, 127 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/2AkE6GmD57",
        "expanded_url" : "http:\/\/tachesdesens.blogspot.fr\/2016\/01\/open-doors-are-not-enough.html",
        "display_url" : "tachesdesens.blogspot.fr\/2016\/01\/open-d\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "690591875812687872",
    "in_reply_to_user_id" : 326772515,
    "text" : "@telliowkuwp @tutormentorteam @Bali_Maha @Danceswithcloud @dogtrax Open doors are not enough.\nhttps:\/\/t.co\/2AkE6GmD57 #ccourses",
    "id" : 690591875812687872,
    "created_at" : "2016-01-22 17:48:28 +0000",
    "in_reply_to_screen_name" : "telliowkuwp",
    "in_reply_to_user_id_str" : "326772515",
    "user" : {
      "name" : "Simon Ensor",
      "screen_name" : "sensor63",
      "protected" : false,
      "id_str" : "84562932",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/764067062952161284\/J4_MGkND_normal.jpg",
      "id" : 84562932,
      "verified" : false
    }
  },
  "id" : 690605400182362113,
  "created_at" : "2016-01-22 18:42:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maria Pia Montoro",
      "screen_name" : "WordLo",
      "indices" : [ 3, 10 ],
      "id_str" : "190569306",
      "id" : 190569306
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/gBvEAJk20p",
      "expanded_url" : "http:\/\/wtfsigte.com\/",
      "display_url" : "wtfsigte.com"
    } ]
  },
  "geo" : { },
  "id_str" : "690575387324186624",
  "text" : "RT @WordLo: Where the fuck should i go to eat? https:\/\/t.co\/gBvEAJk20p",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 58 ],
        "url" : "https:\/\/t.co\/gBvEAJk20p",
        "expanded_url" : "http:\/\/wtfsigte.com\/",
        "display_url" : "wtfsigte.com"
      } ]
    },
    "geo" : { },
    "id_str" : "690574470419980288",
    "text" : "Where the fuck should i go to eat? https:\/\/t.co\/gBvEAJk20p",
    "id" : 690574470419980288,
    "created_at" : "2016-01-22 16:39:18 +0000",
    "user" : {
      "name" : "Maria Pia Montoro",
      "screen_name" : "WordLo",
      "protected" : false,
      "id_str" : "190569306",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/660652749881782272\/BB1P3zUR_normal.jpg",
      "id" : 190569306,
      "verified" : false
    }
  },
  "id" : 690575387324186624,
  "created_at" : "2016-01-22 16:42:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jayne Whistance",
      "screen_name" : "JayneWhistance",
      "indices" : [ 0, 15 ],
      "id_str" : "539398225",
      "id" : 539398225
    }, {
      "name" : "John X Williams",
      "screen_name" : "lexicoj0hn",
      "indices" : [ 16, 27 ],
      "id_str" : "4008981801",
      "id" : 4008981801
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/apj2ahjEyQ",
      "expanded_url" : "https:\/\/adaptivelearninginelt.wordpress.com\/2015\/12\/17\/vocabulary-apps-a-wish-list\/",
      "display_url" : "adaptivelearninginelt.wordpress.com\/2015\/12\/17\/voc\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "690539455636213760",
  "geo" : { },
  "id_str" : "690567858494005248",
  "in_reply_to_user_id" : 539398225,
  "text" : "@JayneWhistance @lexicoj0hn wonder how it stacks up against Kerr's wishlist? https:\/\/t.co\/apj2ahjEyQ",
  "id" : 690567858494005248,
  "in_reply_to_status_id" : 690539455636213760,
  "created_at" : "2016-01-22 16:13:02 +0000",
  "in_reply_to_screen_name" : "JayneWhistance",
  "in_reply_to_user_id_str" : "539398225",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 0, 9 ],
      "id_str" : "121063600",
      "id" : 121063600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "690540497933312000",
  "geo" : { },
  "id_str" : "690566738656772096",
  "in_reply_to_user_id" : 121063600,
  "text" : "@whyshona thanks for sharing!",
  "id" : 690566738656772096,
  "in_reply_to_status_id" : 690540497933312000,
  "created_at" : "2016-01-22 16:08:35 +0000",
  "in_reply_to_screen_name" : "whyshona",
  "in_reply_to_user_id_str" : "121063600",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TEFLAnneOKeeffe",
      "screen_name" : "TEFLclass",
      "indices" : [ 0, 10 ],
      "id_str" : "469244585",
      "id" : 469244585
    }, {
      "name" : "Andrew Caines",
      "screen_name" : "cainesap",
      "indices" : [ 11, 20 ],
      "id_str" : "578898729",
      "id" : 578898729
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "690541437771988994",
  "geo" : { },
  "id_str" : "690566683199684608",
  "in_reply_to_user_id" : 469244585,
  "text" : "@TEFLclass @cainesap nice, hope u r having fun :)",
  "id" : 690566683199684608,
  "in_reply_to_status_id" : 690541437771988994,
  "created_at" : "2016-01-22 16:08:22 +0000",
  "in_reply_to_screen_name" : "TEFLclass",
  "in_reply_to_user_id_str" : "469244585",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "690220202009739264",
  "geo" : { },
  "id_str" : "690566468547796993",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava looks like you need to pay for crossover :\/",
  "id" : 690566468547796993,
  "in_reply_to_status_id" : 690220202009739264,
  "created_at" : "2016-01-22 16:07:30 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TEFLAnneOKeeffe",
      "screen_name" : "TEFLclass",
      "indices" : [ 8, 18 ],
      "id_str" : "469244585",
      "id" : 469244585
    }, {
      "name" : "Andrew Caines",
      "screen_name" : "cainesap",
      "indices" : [ 52, 61 ],
      "id_str" : "578898729",
      "id" : 578898729
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/xxU8ZHKJll",
      "expanded_url" : "https:\/\/plus.google.com\/+MuraNava\/posts\/DxDES4kd3x3",
      "display_url" : "plus.google.com\/+MuraNava\/post\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "610414908237303808",
  "geo" : { },
  "id_str" : "690514106605006849",
  "in_reply_to_user_id" : 578898729,
  "text" : "hi Anne @TEFLclass there's an interview with Andrew @cainesap about the project you may like to read https:\/\/t.co\/xxU8ZHKJll",
  "id" : 690514106605006849,
  "in_reply_to_status_id" : 610414908237303808,
  "created_at" : "2016-01-22 12:39:26 +0000",
  "in_reply_to_screen_name" : "cainesap",
  "in_reply_to_user_id_str" : "578898729",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicola Prentis",
      "screen_name" : "NicolaPrentis",
      "indices" : [ 41, 55 ],
      "id_str" : "810667033",
      "id" : 810667033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/8TipuDxnvN",
      "expanded_url" : "http:\/\/wp.me\/p1RJaO-lvr",
      "display_url" : "wp.me\/p1RJaO-lvr"
    } ]
  },
  "geo" : { },
  "id_str" : "690511371889479680",
  "text" : "Queen Arthur https:\/\/t.co\/8TipuDxnvN via @NicolaPrentis",
  "id" : 690511371889479680,
  "created_at" : "2016-01-22 12:28:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tekhnologic",
      "screen_name" : "tekhnologicblog",
      "indices" : [ 0, 16 ],
      "id_str" : "1486688384",
      "id" : 1486688384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "690464873025773568",
  "geo" : { },
  "id_str" : "690508435494965248",
  "in_reply_to_user_id" : 1486688384,
  "text" : "@tekhnologicblog thanks for reading post and sharing :)",
  "id" : 690508435494965248,
  "in_reply_to_status_id" : 690464873025773568,
  "created_at" : "2016-01-22 12:16:54 +0000",
  "in_reply_to_screen_name" : "tekhnologicblog",
  "in_reply_to_user_id_str" : "1486688384",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Vitullo-Martin",
      "screen_name" : "JuliaManhattan",
      "indices" : [ 0, 15 ],
      "id_str" : "73929597",
      "id" : 73929597
    }, {
      "name" : "Angus B Grieve-Smith",
      "screen_name" : "grvsmth",
      "indices" : [ 16, 24 ],
      "id_str" : "22381639",
      "id" : 22381639
    }, {
      "name" : "Sarah Kershaw",
      "screen_name" : "Sarah_S_Kershaw",
      "indices" : [ 25, 41 ],
      "id_str" : "2295548778",
      "id" : 2295548778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "690319815970525184",
  "geo" : { },
  "id_str" : "690455664272019457",
  "in_reply_to_user_id" : 73929597,
  "text" : "@JuliaManhattan @grvsmth @Sarah_S_Kershaw  I wonder if the grant application required moderate &amp; tolerant as criteria for ancient texts? :\/",
  "id" : 690455664272019457,
  "in_reply_to_status_id" : 690319815970525184,
  "created_at" : "2016-01-22 08:47:13 +0000",
  "in_reply_to_screen_name" : "JuliaManhattan",
  "in_reply_to_user_id_str" : "73929597",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tekhnologic",
      "screen_name" : "tekhnologicblog",
      "indices" : [ 0, 16 ],
      "id_str" : "1486688384",
      "id" : 1486688384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/effJF5gqcc",
      "expanded_url" : "https:\/\/eflnotes.wordpress.com\/2016\/01\/20\/hvpt-or-minimal-pairs-on-steroids\/",
      "display_url" : "eflnotes.wordpress.com\/2016\/01\/20\/hvp\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "690448715992051712",
  "geo" : { },
  "id_str" : "690452227249541120",
  "in_reply_to_user_id" : 1486688384,
  "text" : "@tekhnologicblog hi lk fwd to yr new post, here's one on an overlooked technique for pron https:\/\/t.co\/effJF5gqcc",
  "id" : 690452227249541120,
  "in_reply_to_status_id" : 690448715992051712,
  "created_at" : "2016-01-22 08:33:33 +0000",
  "in_reply_to_screen_name" : "tekhnologicblog",
  "in_reply_to_user_id_str" : "1486688384",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sheikh Spear",
      "screen_name" : "FailedRckstr",
      "indices" : [ 3, 16 ],
      "id_str" : "771682987",
      "id" : 771682987
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/FailedRckstr\/status\/690093195762520064\/video\/1",
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/Bx5LATTxio",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/690091589495033858\/pu\/img\/-4nleysYQHFYuc2d.jpg",
      "id_str" : "690091589495033858",
      "id" : 690091589495033858,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/690091589495033858\/pu\/img\/-4nleysYQHFYuc2d.jpg",
      "sizes" : [ {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/Bx5LATTxio"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "690405655933513728",
  "text" : "RT @FailedRckstr: This is the coolest video you will see today. https:\/\/t.co\/Bx5LATTxio",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/FailedRckstr\/status\/690093195762520064\/video\/1",
        "indices" : [ 46, 69 ],
        "url" : "https:\/\/t.co\/Bx5LATTxio",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/690091589495033858\/pu\/img\/-4nleysYQHFYuc2d.jpg",
        "id_str" : "690091589495033858",
        "id" : 690091589495033858,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/690091589495033858\/pu\/img\/-4nleysYQHFYuc2d.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/Bx5LATTxio"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "690093195762520064",
    "text" : "This is the coolest video you will see today. https:\/\/t.co\/Bx5LATTxio",
    "id" : 690093195762520064,
    "created_at" : "2016-01-21 08:46:53 +0000",
    "user" : {
      "name" : "Sheikh Spear",
      "screen_name" : "FailedRckstr",
      "protected" : false,
      "id_str" : "771682987",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765505042640166913\/WA3Zt8DM_normal.jpg",
      "id" : 771682987,
      "verified" : false
    }
  },
  "id" : 690405655933513728,
  "created_at" : "2016-01-22 05:28:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Caulfield",
      "screen_name" : "holden",
      "indices" : [ 75, 82 ],
      "id_str" : "1912681",
      "id" : 1912681
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/690399565598593029\/photo\/1",
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/18Kw9FBoig",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CZTKvvoWYAEZi57.png",
      "id_str" : "690399564482895873",
      "id" : 690399564482895873,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZTKvvoWYAEZi57.png",
      "sizes" : [ {
        "h" : 339,
        "resize" : "fit",
        "w" : 1011
      }, {
        "h" : 339,
        "resize" : "fit",
        "w" : 1011
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 114,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 201,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/18Kw9FBoig"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/lA9iXnADci",
      "expanded_url" : "https:\/\/github.com\/brave\/browser-laptop",
      "display_url" : "github.com\/brave\/browser-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "690399565598593029",
  "text" : "trying out Brave browser desktop version https:\/\/t.co\/lA9iXnADci neato h\/t @holden https:\/\/t.co\/18Kw9FBoig",
  "id" : 690399565598593029,
  "created_at" : "2016-01-22 05:04:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamie Kilstein",
      "screen_name" : "jamiekilstein",
      "indices" : [ 3, 17 ],
      "id_str" : "16960279",
      "id" : 16960279
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/2xS8Y8AVnC",
      "expanded_url" : "https:\/\/twitter.com\/danmericaCNN\/status\/690312430556065793",
      "display_url" : "twitter.com\/danmericaCNN\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "690323913956532225",
  "text" : "RT @jamiekilstein: Booooo? https:\/\/t.co\/2xS8Y8AVnC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 8, 31 ],
        "url" : "https:\/\/t.co\/2xS8Y8AVnC",
        "expanded_url" : "https:\/\/twitter.com\/danmericaCNN\/status\/690312430556065793",
        "display_url" : "twitter.com\/danmericaCNN\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "690322004214419457",
    "text" : "Booooo? https:\/\/t.co\/2xS8Y8AVnC",
    "id" : 690322004214419457,
    "created_at" : "2016-01-21 23:56:06 +0000",
    "user" : {
      "name" : "Jamie Kilstein",
      "screen_name" : "jamiekilstein",
      "protected" : false,
      "id_str" : "16960279",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684033944182890496\/QyxzdDKr_normal.png",
      "id" : 16960279,
      "verified" : false
    }
  },
  "id" : 690323913956532225,
  "created_at" : "2016-01-22 00:03:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Prior",
      "screen_name" : "ConceptCzech",
      "indices" : [ 0, 13 ],
      "id_str" : "256015802",
      "id" : 256015802
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "690312012916736001",
  "geo" : { },
  "id_str" : "690314173474041857",
  "in_reply_to_user_id" : 256015802,
  "text" : "@ConceptCzech shifting numbers is most annoying for me :\/",
  "id" : 690314173474041857,
  "in_reply_to_status_id" : 690312012916736001,
  "created_at" : "2016-01-21 23:24:59 +0000",
  "in_reply_to_screen_name" : "ConceptCzech",
  "in_reply_to_user_id_str" : "256015802",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 3, 12 ],
      "id_str" : "121063600",
      "id" : 121063600
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 55, 64 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "C Wigham",
      "screen_name" : "Loopy63",
      "indices" : [ 65, 73 ],
      "id_str" : "55195789",
      "id" : 55195789
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edtech",
      "indices" : [ 98, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/W9rDecgomH",
      "expanded_url" : "http:\/\/sco.lt\/4v5IJd",
      "display_url" : "sco.lt\/4v5IJd"
    } ]
  },
  "geo" : { },
  "id_str" : "690312111323508736",
  "text" : "RT @whyshona: Virtual Special Issue on TELL and CALL | @muranava @loopy63 https:\/\/t.co\/W9rDecgomH #edtech",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.scoop.it\" rel=\"nofollow\"\u003EScoop.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mura Nava",
        "screen_name" : "muranava",
        "indices" : [ 41, 50 ],
        "id_str" : "18602422",
        "id" : 18602422
      }, {
        "name" : "C Wigham",
        "screen_name" : "Loopy63",
        "indices" : [ 51, 59 ],
        "id_str" : "55195789",
        "id" : 55195789
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "edtech",
        "indices" : [ 84, 91 ]
      } ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/W9rDecgomH",
        "expanded_url" : "http:\/\/sco.lt\/4v5IJd",
        "display_url" : "sco.lt\/4v5IJd"
      } ]
    },
    "geo" : { },
    "id_str" : "690228386267004932",
    "text" : "Virtual Special Issue on TELL and CALL | @muranava @loopy63 https:\/\/t.co\/W9rDecgomH #edtech",
    "id" : 690228386267004932,
    "created_at" : "2016-01-21 17:44:05 +0000",
    "user" : {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "protected" : false,
      "id_str" : "121063600",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459074158974889984\/nMzMr6_1_normal.jpeg",
      "id" : 121063600,
      "verified" : false
    }
  },
  "id" : 690312111323508736,
  "created_at" : "2016-01-21 23:16:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 3, 12 ],
      "id_str" : "134211317",
      "id" : 134211317
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/josipa74\/status\/690265789346242561\/photo\/1",
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/uGz1lwhmHw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CZRRE8UXEAAk-n9.jpg",
      "id_str" : "690265788247379968",
      "id" : 690265788247379968,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZRRE8UXEAAk-n9.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/uGz1lwhmHw"
    } ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 70, 74 ]
    }, {
      "text" : "esl",
      "indices" : [ 75, 79 ]
    }, {
      "text" : "tefl",
      "indices" : [ 80, 85 ]
    }, {
      "text" : "besig",
      "indices" : [ 86, 92 ]
    }, {
      "text" : "efl",
      "indices" : [ 93, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/deZQt53SuA",
      "expanded_url" : "http:\/\/goo.gl\/eE6iNu",
      "display_url" : "goo.gl\/eE6iNu"
    } ]
  },
  "geo" : { },
  "id_str" : "690303720341553153",
  "text" : "RT @josipa74: 'At Work' with Convivial Tools. https:\/\/t.co\/deZQt53SuA #elt #esl #tefl #besig #efl https:\/\/t.co\/uGz1lwhmHw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/josipa74\/status\/690265789346242561\/photo\/1",
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/uGz1lwhmHw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZRRE8UXEAAk-n9.jpg",
        "id_str" : "690265788247379968",
        "id" : 690265788247379968,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZRRE8UXEAAk-n9.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/uGz1lwhmHw"
      } ],
      "hashtags" : [ {
        "text" : "elt",
        "indices" : [ 56, 60 ]
      }, {
        "text" : "esl",
        "indices" : [ 61, 65 ]
      }, {
        "text" : "tefl",
        "indices" : [ 66, 71 ]
      }, {
        "text" : "besig",
        "indices" : [ 72, 78 ]
      }, {
        "text" : "efl",
        "indices" : [ 79, 83 ]
      } ],
      "urls" : [ {
        "indices" : [ 32, 55 ],
        "url" : "https:\/\/t.co\/deZQt53SuA",
        "expanded_url" : "http:\/\/goo.gl\/eE6iNu",
        "display_url" : "goo.gl\/eE6iNu"
      } ]
    },
    "geo" : { },
    "id_str" : "690265789346242561",
    "text" : "'At Work' with Convivial Tools. https:\/\/t.co\/deZQt53SuA #elt #esl #tefl #besig #efl https:\/\/t.co\/uGz1lwhmHw",
    "id" : 690265789346242561,
    "created_at" : "2016-01-21 20:12:43 +0000",
    "user" : {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "protected" : false,
      "id_str" : "134211317",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/526853654377021441\/MtEFhYIs_normal.jpeg",
      "id" : 134211317,
      "verified" : false
    }
  },
  "id" : 690303720341553153,
  "created_at" : "2016-01-21 22:43:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greg Ashman",
      "screen_name" : "greg_ashman",
      "indices" : [ 52, 64 ],
      "id_str" : "614246029",
      "id" : 614246029
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/JZLFG1sBuk",
      "expanded_url" : "http:\/\/wp.me\/p3A026-2F",
      "display_url" : "wp.me\/p3A026-2F"
    } ]
  },
  "geo" : { },
  "id_str" : "690262791001915394",
  "text" : "The skill of competence https:\/\/t.co\/JZLFG1sBuk via @greg_ashman",
  "id" : 690262791001915394,
  "created_at" : "2016-01-21 20:00:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Kriss",
      "screen_name" : "sam_kriss",
      "indices" : [ 74, 84 ],
      "id_str" : "588771213",
      "id" : 588771213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/Pl2BtpYpeP",
      "expanded_url" : "http:\/\/wp.me\/p1PBvi-Af",
      "display_url" : "wp.me\/p1PBvi-Af"
    } ]
  },
  "geo" : { },
  "id_str" : "690260278529921025",
  "text" : "American aphanisis: in search of Donald Trump https:\/\/t.co\/Pl2BtpYpeP via @sam_kriss",
  "id" : 690260278529921025,
  "created_at" : "2016-01-21 19:50:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 0, 9 ],
      "id_str" : "121063600",
      "id" : 121063600
    }, {
      "name" : "C Wigham",
      "screen_name" : "Loopy63",
      "indices" : [ 10, 18 ],
      "id_str" : "55195789",
      "id" : 55195789
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "690228386267004932",
  "geo" : { },
  "id_str" : "690250679756156929",
  "in_reply_to_user_id" : 121063600,
  "text" : "@whyshona @Loopy63 thx :)",
  "id" : 690250679756156929,
  "in_reply_to_status_id" : 690228386267004932,
  "created_at" : "2016-01-21 19:12:40 +0000",
  "in_reply_to_screen_name" : "whyshona",
  "in_reply_to_user_id_str" : "121063600",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will McCulloch",
      "screen_name" : "EnglishHamburg",
      "indices" : [ 0, 15 ],
      "id_str" : "387245091",
      "id" : 387245091
    }, {
      "name" : "TEFLology Podcast",
      "screen_name" : "TEFLology",
      "indices" : [ 16, 26 ],
      "id_str" : "2882870444",
      "id" : 2882870444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "690234390094422017",
  "geo" : { },
  "id_str" : "690250648043032576",
  "in_reply_to_user_id" : 387245091,
  "text" : "@EnglishHamburg @TEFLology ah right \n:)",
  "id" : 690250648043032576,
  "in_reply_to_status_id" : 690234390094422017,
  "created_at" : "2016-01-21 19:12:33 +0000",
  "in_reply_to_screen_name" : "EnglishHamburg",
  "in_reply_to_user_id_str" : "387245091",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will McCulloch",
      "screen_name" : "EnglishHamburg",
      "indices" : [ 0, 15 ],
      "id_str" : "387245091",
      "id" : 387245091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "690161263788302337",
  "geo" : { },
  "id_str" : "690224780377718784",
  "in_reply_to_user_id" : 387245091,
  "text" : "@EnglishHamburg I don't think I tweeted this",
  "id" : 690224780377718784,
  "in_reply_to_status_id" : 690161263788302337,
  "created_at" : "2016-01-21 17:29:46 +0000",
  "in_reply_to_screen_name" : "EnglishHamburg",
  "in_reply_to_user_id_str" : "387245091",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusresources",
      "indices" : [ 0, 16 ]
    }, {
      "text" : "corpuslinguistics",
      "indices" : [ 17, 35 ]
    } ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/0f6XvCiEgL",
      "expanded_url" : "https:\/\/twitter.com\/notesJOR\/status\/689415764999217153",
      "display_url" : "twitter.com\/notesJOR\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "690220202009739264",
  "text" : "#corpusresources #corpuslinguistics  https:\/\/t.co\/0f6XvCiEgL",
  "id" : 690220202009739264,
  "created_at" : "2016-01-21 17:11:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TechnicallyRon",
      "screen_name" : "TechnicallyRon",
      "indices" : [ 3, 18 ],
      "id_str" : "108140114",
      "id" : 108140114
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/TechnicallyRon\/status\/690175736225882112\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/DyspovLr3t",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CZP_LCCWcAI2H17.jpg",
      "id_str" : "690175732908191746",
      "id" : 690175732908191746,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZP_LCCWcAI2H17.jpg",
      "sizes" : [ {
        "h" : 825,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1100,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 1100,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 468,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/DyspovLr3t"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "690219155547627520",
  "text" : "RT @TechnicallyRon: I used Google autocomplete to write a dating profile and it may be the best dating profile ever https:\/\/t.co\/DyspovLr3t",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/TechnicallyRon\/status\/690175736225882112\/photo\/1",
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/DyspovLr3t",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZP_LCCWcAI2H17.jpg",
        "id_str" : "690175732908191746",
        "id" : 690175732908191746,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZP_LCCWcAI2H17.jpg",
        "sizes" : [ {
          "h" : 825,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1100,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 1100,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 468,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/DyspovLr3t"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "690175736225882112",
    "text" : "I used Google autocomplete to write a dating profile and it may be the best dating profile ever https:\/\/t.co\/DyspovLr3t",
    "id" : 690175736225882112,
    "created_at" : "2016-01-21 14:14:53 +0000",
    "user" : {
      "name" : "TechnicallyRon",
      "screen_name" : "TechnicallyRon",
      "protected" : false,
      "id_str" : "108140114",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/683972064781463552\/94h64ztN_normal.jpg",
      "id" : 108140114,
      "verified" : true
    }
  },
  "id" : 690219155547627520,
  "created_at" : "2016-01-21 17:07:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 3, 12 ],
      "id_str" : "134211317",
      "id" : 134211317
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/josipa74\/status\/690148556263546880\/photo\/1",
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/Zb4xVC1d34",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CZPmdFjWcAAO69r.jpg",
      "id_str" : "690148555298861056",
      "id" : 690148555298861056,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZPmdFjWcAAO69r.jpg",
      "sizes" : [ {
        "h" : 354,
        "resize" : "fit",
        "w" : 250
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 354,
        "resize" : "fit",
        "w" : 250
      }, {
        "h" : 354,
        "resize" : "fit",
        "w" : 250
      }, {
        "h" : 354,
        "resize" : "fit",
        "w" : 250
      } ],
      "display_url" : "pic.twitter.com\/Zb4xVC1d34"
    } ],
    "hashtags" : [ {
      "text" : "besig",
      "indices" : [ 93, 99 ]
    }, {
      "text" : "elt",
      "indices" : [ 100, 104 ]
    }, {
      "text" : "tefl",
      "indices" : [ 105, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/JcpSnOIL3q",
      "expanded_url" : "http:\/\/goo.gl\/7nn3qL",
      "display_url" : "goo.gl\/7nn3qL"
    } ]
  },
  "geo" : { },
  "id_str" : "690152562738237440",
  "text" : "RT @josipa74: 'At Work' - my new ebook with The Round available now! https:\/\/t.co\/JcpSnOIL3q #besig #elt #tefl https:\/\/t.co\/Zb4xVC1d34",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/josipa74\/status\/690148556263546880\/photo\/1",
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/Zb4xVC1d34",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZPmdFjWcAAO69r.jpg",
        "id_str" : "690148555298861056",
        "id" : 690148555298861056,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZPmdFjWcAAO69r.jpg",
        "sizes" : [ {
          "h" : 354,
          "resize" : "fit",
          "w" : 250
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 354,
          "resize" : "fit",
          "w" : 250
        }, {
          "h" : 354,
          "resize" : "fit",
          "w" : 250
        }, {
          "h" : 354,
          "resize" : "fit",
          "w" : 250
        } ],
        "display_url" : "pic.twitter.com\/Zb4xVC1d34"
      } ],
      "hashtags" : [ {
        "text" : "besig",
        "indices" : [ 79, 85 ]
      }, {
        "text" : "elt",
        "indices" : [ 86, 90 ]
      }, {
        "text" : "tefl",
        "indices" : [ 91, 96 ]
      } ],
      "urls" : [ {
        "indices" : [ 55, 78 ],
        "url" : "https:\/\/t.co\/JcpSnOIL3q",
        "expanded_url" : "http:\/\/goo.gl\/7nn3qL",
        "display_url" : "goo.gl\/7nn3qL"
      } ]
    },
    "geo" : { },
    "id_str" : "690148556263546880",
    "text" : "'At Work' - my new ebook with The Round available now! https:\/\/t.co\/JcpSnOIL3q #besig #elt #tefl https:\/\/t.co\/Zb4xVC1d34",
    "id" : 690148556263546880,
    "created_at" : "2016-01-21 12:26:52 +0000",
    "user" : {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "protected" : false,
      "id_str" : "134211317",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/526853654377021441\/MtEFhYIs_normal.jpeg",
      "id" : 134211317,
      "verified" : false
    }
  },
  "id" : 690152562738237440,
  "created_at" : "2016-01-21 12:42:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 67, 83 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/5tyUptC71p",
      "expanded_url" : "http:\/\/wp.me\/p75ue9-i",
      "display_url" : "wp.me\/p75ue9-i"
    } ]
  },
  "geo" : { },
  "id_str" : "690119595395551233",
  "text" : "3. Don't Shoot the Dog! by Karen Pryor https:\/\/t.co\/5tyUptC71p via @wordpressdotcom",
  "id" : 690119595395551233,
  "created_at" : "2016-01-21 10:31:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Molinari",
      "screen_name" : "serenissimaj",
      "indices" : [ 87, 100 ],
      "id_str" : "1119966463",
      "id" : 1119966463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/IU1Jzzmr5I",
      "expanded_url" : "http:\/\/wp.me\/p4EZQ7-s8",
      "display_url" : "wp.me\/p4EZQ7-s8"
    } ]
  },
  "geo" : { },
  "id_str" : "690116594018684928",
  "text" : "Review of \"Teaching and Researching Writing\" (Hyland 2016) https:\/\/t.co\/IU1Jzzmr5I via @serenissimaj",
  "id" : 690116594018684928,
  "created_at" : "2016-01-21 10:19:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EnglishGrammarClub\u2122",
      "screen_name" : "TheEnglishVerb",
      "indices" : [ 0, 15 ],
      "id_str" : "783208711",
      "id" : 783208711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "690056934863450112",
  "geo" : { },
  "id_str" : "690108827572789248",
  "in_reply_to_user_id" : 783208711,
  "text" : "@TheEnglishVerb thanks for sharing HVPT post : )",
  "id" : 690108827572789248,
  "in_reply_to_status_id" : 690056934863450112,
  "created_at" : "2016-01-21 09:49:00 +0000",
  "in_reply_to_screen_name" : "TheEnglishVerb",
  "in_reply_to_user_id_str" : "783208711",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Taylor",
      "screen_name" : "theteacherjames",
      "indices" : [ 53, 69 ],
      "id_str" : "71746265",
      "id" : 71746265
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/VtpyGQo7zy",
      "expanded_url" : "http:\/\/wp.me\/p2gBMI-iy",
      "display_url" : "wp.me\/p2gBMI-iy"
    } ]
  },
  "geo" : { },
  "id_str" : "690107288904941568",
  "text" : "Flipped Teacher Training https:\/\/t.co\/VtpyGQo7zy via @theteacherjames",
  "id" : 690107288904941568,
  "created_at" : "2016-01-21 09:42:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 3, 19 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELT",
      "indices" : [ 69, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/G9z6Rqn1ky",
      "expanded_url" : "http:\/\/goo.gl\/forms\/n4h10NwTMr",
      "display_url" : "goo.gl\/forms\/n4h10NwT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "690103271290179584",
  "text" : "RT @michaelegriffin: If you could complete this (easy?) survey about #ELT conferences I would really appreciate it. \nhttps:\/\/t.co\/G9z6Rqn1k\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELT",
        "indices" : [ 48, 52 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/G9z6Rqn1ky",
        "expanded_url" : "http:\/\/goo.gl\/forms\/n4h10NwTMr",
        "display_url" : "goo.gl\/forms\/n4h10NwT\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "690022292492062720",
    "text" : "If you could complete this (easy?) survey about #ELT conferences I would really appreciate it. \nhttps:\/\/t.co\/G9z6Rqn1ky\n(RTs are great)",
    "id" : 690022292492062720,
    "created_at" : "2016-01-21 04:05:09 +0000",
    "user" : {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "protected" : false,
      "id_str" : "394053348",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766911330645315584\/il5gKyOJ_normal.jpg",
      "id" : 394053348,
      "verified" : false
    }
  },
  "id" : 690103271290179584,
  "created_at" : "2016-01-21 09:26:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Carr",
      "screen_name" : "MattCarr55",
      "indices" : [ 79, 90 ],
      "id_str" : "288409122",
      "id" : 288409122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/ACNVfDLSZg",
      "expanded_url" : "http:\/\/infernalmachine.co.uk\/learn-english-the-vicious-idiocy-of-david-cameron\/",
      "display_url" : "infernalmachine.co.uk\/learn-english-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "690102717126217728",
  "text" : "Learn English! The Vicious Idiocy of David Cameron https:\/\/t.co\/ACNVfDLSZg via @MattCarr55",
  "id" : 690102717126217728,
  "created_at" : "2016-01-21 09:24:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 0, 15 ],
      "id_str" : "285614027",
      "id" : 285614027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "689964658405539846",
  "geo" : { },
  "id_str" : "690091727873511424",
  "in_reply_to_user_id" : 285614027,
  "text" : "@AnthonyTeacher were these policies explicitly acknowledging slavery though?",
  "id" : 690091727873511424,
  "in_reply_to_status_id" : 689964658405539846,
  "created_at" : "2016-01-21 08:41:03 +0000",
  "in_reply_to_screen_name" : "AnthonyTeacher",
  "in_reply_to_user_id_str" : "285614027",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yolanda B. Schell",
      "screen_name" : "mattellman",
      "indices" : [ 0, 11 ],
      "id_str" : "725597315860434945",
      "id" : 725597315860434945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "689968983135686656",
  "geo" : { },
  "id_str" : "690090137439576064",
  "in_reply_to_user_id" : 394987109,
  "text" : "@MattEllman wonder what other gems are hidden or being ignored? thanks for sharing : )",
  "id" : 690090137439576064,
  "in_reply_to_status_id" : 689968983135686656,
  "created_at" : "2016-01-21 08:34:44 +0000",
  "in_reply_to_screen_name" : "MatthewEllman",
  "in_reply_to_user_id_str" : "394987109",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The-Round ELT",
      "screen_name" : "wetheround",
      "indices" : [ 3, 14 ],
      "id_str" : "281918842",
      "id" : 281918842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "https:\/\/t.co\/ZZ4fBVRHSF",
      "expanded_url" : "http:\/\/www.the-round.com",
      "display_url" : "the-round.com"
    } ]
  },
  "geo" : { },
  "id_str" : "690089414282866688",
  "text" : "RT @wetheround: The round begins 2016 with a bang! Four new books, all part of the round minis series. 99 cents each! https:\/\/t.co\/ZZ4fBVRH\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/ZZ4fBVRHSF",
        "expanded_url" : "http:\/\/www.the-round.com",
        "display_url" : "the-round.com"
      } ]
    },
    "geo" : { },
    "id_str" : "690083210022252545",
    "text" : "The round begins 2016 with a bang! Four new books, all part of the round minis series. 99 cents each! https:\/\/t.co\/ZZ4fBVRHSF",
    "id" : 690083210022252545,
    "created_at" : "2016-01-21 08:07:13 +0000",
    "user" : {
      "name" : "The-Round ELT",
      "screen_name" : "wetheround",
      "protected" : false,
      "id_str" : "281918842",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1545068295\/twitter-avatar_normal.jpg",
      "id" : 281918842,
      "verified" : false
    }
  },
  "id" : 690089414282866688,
  "created_at" : "2016-01-21 08:31:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 0, 15 ],
      "id_str" : "285614027",
      "id" : 285614027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "689955016757616640",
  "geo" : { },
  "id_str" : "689963364014002176",
  "in_reply_to_user_id" : 285614027,
  "text" : "@AnthonyTeacher is the symbolic nature of reparations being missed in McWhorter's argument?",
  "id" : 689963364014002176,
  "in_reply_to_status_id" : 689955016757616640,
  "created_at" : "2016-01-21 00:10:59 +0000",
  "in_reply_to_screen_name" : "AnthonyTeacher",
  "in_reply_to_user_id_str" : "285614027",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenys Hanson",
      "screen_name" : "GlenysHanson",
      "indices" : [ 0, 13 ],
      "id_str" : "527238447",
      "id" : 527238447
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "689959492172304384",
  "in_reply_to_user_id" : 527238447,
  "text" : "@GlenysHanson thanks for sharing and voting ; )",
  "id" : 689959492172304384,
  "created_at" : "2016-01-20 23:55:36 +0000",
  "in_reply_to_screen_name" : "GlenysHanson",
  "in_reply_to_user_id_str" : "527238447",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mr. Driscoll",
      "screen_name" : "e_d_driscoll",
      "indices" : [ 0, 13 ],
      "id_str" : "381086898",
      "id" : 381086898
    }, {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 14, 29 ],
      "id_str" : "285614027",
      "id" : 285614027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "689959426732728322",
  "in_reply_to_user_id" : 381086898,
  "text" : "@e_d_driscoll @AnthonyTeacher thks for sharing wordlist :)",
  "id" : 689959426732728322,
  "created_at" : "2016-01-20 23:55:20 +0000",
  "in_reply_to_screen_name" : "e_d_driscoll",
  "in_reply_to_user_id_str" : "381086898",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 3, 18 ],
      "id_str" : "285614027",
      "id" : 285614027
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 20, 29 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "The Atlantic",
      "screen_name" : "TheAtlantic",
      "indices" : [ 30, 42 ],
      "id_str" : "35773039",
      "id" : 35773039
    }, {
      "name" : "John McWhorter",
      "screen_name" : "JohnHMcWhorter",
      "indices" : [ 43, 58 ],
      "id_str" : "1306199515",
      "id" : 1306199515
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/mpKxPTduNa",
      "expanded_url" : "http:\/\/www.cnn.com\/2016\/01\/20\/opinions\/ta-nehisi-coates-attack-on-bernie-sanders-mcwhorter\/index.html",
      "display_url" : "cnn.com\/2016\/01\/20\/opi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "689958621262798850",
  "text" : "RT @AnthonyTeacher: @muranava @TheAtlantic @JohnHMcWhorter explains: https:\/\/t.co\/mpKxPTduNa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mura Nava",
        "screen_name" : "muranava",
        "indices" : [ 0, 9 ],
        "id_str" : "18602422",
        "id" : 18602422
      }, {
        "name" : "The Atlantic",
        "screen_name" : "TheAtlantic",
        "indices" : [ 10, 22 ],
        "id_str" : "35773039",
        "id" : 35773039
      }, {
        "name" : "John McWhorter",
        "screen_name" : "JohnHMcWhorter",
        "indices" : [ 23, 38 ],
        "id_str" : "1306199515",
        "id" : 1306199515
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 72 ],
        "url" : "https:\/\/t.co\/mpKxPTduNa",
        "expanded_url" : "http:\/\/www.cnn.com\/2016\/01\/20\/opinions\/ta-nehisi-coates-attack-on-bernie-sanders-mcwhorter\/index.html",
        "display_url" : "cnn.com\/2016\/01\/20\/opi\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "689951295306887168",
    "geo" : { },
    "id_str" : "689955016757616640",
    "in_reply_to_user_id" : 18602422,
    "text" : "@muranava @TheAtlantic @JohnHMcWhorter explains: https:\/\/t.co\/mpKxPTduNa",
    "id" : 689955016757616640,
    "in_reply_to_status_id" : 689951295306887168,
    "created_at" : "2016-01-20 23:37:49 +0000",
    "in_reply_to_screen_name" : "muranava",
    "in_reply_to_user_id_str" : "18602422",
    "user" : {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "protected" : false,
      "id_str" : "285614027",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/412336845658132481\/Om5kKuMQ_normal.jpeg",
      "id" : 285614027,
      "verified" : false
    }
  },
  "id" : 689958621262798850,
  "created_at" : "2016-01-20 23:52:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "689951621606936576",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish thks for sharing Marc :)",
  "id" : 689951621606936576,
  "created_at" : "2016-01-20 23:24:19 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/iYIq1mYtEB",
      "expanded_url" : "http:\/\/www.theatlantic.com\/politics\/archive\/2016\/01\/bernie-sanders-reparations\/424602\/",
      "display_url" : "theatlantic.com\/politics\/archi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "689951295306887168",
  "text" : "Why is Bernie Sanders\u2019s political imagination so active against plutocracy, but so limited against white supremacy? https:\/\/t.co\/iYIq1mYtEB",
  "id" : 689951295306887168,
  "created_at" : "2016-01-20 23:23:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tleap",
      "indices" : [ 101, 107 ]
    }, {
      "text" : "EAP",
      "indices" : [ 108, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/1gSRFcHvdu",
      "expanded_url" : "https:\/\/eflnotes.wordpress.com\/wordlists\/",
      "display_url" : "eflnotes.wordpress.com\/wordlists\/"
    } ]
  },
  "geo" : { },
  "id_str" : "689937149978918912",
  "text" : "Academic Formulas List, Pearson Academic Collocation List added to Wordlists https:\/\/t.co\/1gSRFcHvdu #tleap #EAP",
  "id" : 689937149978918912,
  "created_at" : "2016-01-20 22:26:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "goieltsdotnet",
      "screen_name" : "goieltsdotnet",
      "indices" : [ 0, 14 ],
      "id_str" : "3052238274",
      "id" : 3052238274
    }, {
      "name" : "MarisaConstantinides",
      "screen_name" : "Marisa_C",
      "indices" : [ 15, 24 ],
      "id_str" : "18272500",
      "id" : 18272500
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "689909681939206145",
  "geo" : { },
  "id_str" : "689935717510815744",
  "in_reply_to_user_id" : 3052238274,
  "text" : "@goieltsdotnet @Marisa_C grateful for the share folks :)",
  "id" : 689935717510815744,
  "in_reply_to_status_id" : 689909681939206145,
  "created_at" : "2016-01-20 22:21:08 +0000",
  "in_reply_to_screen_name" : "goieltsdotnet",
  "in_reply_to_user_id_str" : "3052238274",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 34, 42 ]
    }, {
      "text" : "tleap",
      "indices" : [ 43, 49 ]
    }, {
      "text" : "eltchinwag",
      "indices" : [ 50, 61 ]
    }, {
      "text" : "tefl",
      "indices" : [ 62, 67 ]
    }, {
      "text" : "efl",
      "indices" : [ 68, 72 ]
    }, {
      "text" : "esl",
      "indices" : [ 73, 77 ]
    }, {
      "text" : "auselt",
      "indices" : [ 78, 85 ]
    }, {
      "text" : "keltchat",
      "indices" : [ 86, 95 ]
    }, {
      "text" : "elt",
      "indices" : [ 96, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/effJF4YONC",
      "expanded_url" : "https:\/\/eflnotes.wordpress.com\/2016\/01\/20\/hvpt-or-minimal-pairs-on-steroids\/",
      "display_url" : "eflnotes.wordpress.com\/2016\/01\/20\/hvp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "689909017536167937",
  "text" : "HVPT or minimal pairs on steroids #eltchat #tleap #eltchinwag #tefl #efl #esl #auselt #keltchat #elt https:\/\/t.co\/effJF4YONC",
  "id" : 689909017536167937,
  "created_at" : "2016-01-20 20:35:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donald Clark",
      "screen_name" : "DonaldClark",
      "indices" : [ 0, 12 ],
      "id_str" : "1632891",
      "id" : 1632891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/ijqQFdCFsU",
      "expanded_url" : "https:\/\/twitter.com\/muranava\/status\/668577829588705281",
      "display_url" : "twitter.com\/muranava\/statu\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "689883834146504704",
  "geo" : { },
  "id_str" : "689903919686930432",
  "in_reply_to_user_id" : 1632891,
  "text" : "@DonaldClark any interesting words like exobiological? https:\/\/t.co\/ijqQFdCFsU",
  "id" : 689903919686930432,
  "in_reply_to_status_id" : 689883834146504704,
  "created_at" : "2016-01-20 20:14:46 +0000",
  "in_reply_to_screen_name" : "DonaldClark",
  "in_reply_to_user_id_str" : "1632891",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 52, 68 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/khZZRiEo1T",
      "expanded_url" : "http:\/\/wp.me\/p5jLUa-4z",
      "display_url" : "wp.me\/p5jLUa-4z"
    } ]
  },
  "geo" : { },
  "id_str" : "689892866894749697",
  "text" : "Cottage Industry as CPD https:\/\/t.co\/khZZRiEo1T via @getgreatenglish",
  "id" : 689892866894749697,
  "created_at" : "2016-01-20 19:30:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 13, 22 ],
      "id_str" : "18602422",
      "id" : 18602422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "689745984113475584",
  "geo" : { },
  "id_str" : "689880716822364160",
  "in_reply_to_user_id" : 18602422,
  "text" : "poll alert ^ @muranava",
  "id" : 689880716822364160,
  "in_reply_to_status_id" : 689745984113475584,
  "created_at" : "2016-01-20 18:42:34 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Chesnut",
      "screen_name" : "MichaelChesnut2",
      "indices" : [ 0, 16 ],
      "id_str" : "820940430",
      "id" : 820940430
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "689785924406898689",
  "in_reply_to_user_id" : 820940430,
  "text" : "@MichaelChesnut2 thx for RTing poll!",
  "id" : 689785924406898689,
  "created_at" : "2016-01-20 12:25:54 +0000",
  "in_reply_to_screen_name" : "MichaelChesnut2",
  "in_reply_to_user_id_str" : "820940430",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eily Murphy",
      "screen_name" : "eilymurphy",
      "indices" : [ 0, 11 ],
      "id_str" : "111091623",
      "id" : 111091623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "689775506980474881",
  "in_reply_to_user_id" : 111091623,
  "text" : "@eilymurphy thks for sharing the poll :)",
  "id" : 689775506980474881,
  "created_at" : "2016-01-20 11:44:30 +0000",
  "in_reply_to_screen_name" : "eilymurphy",
  "in_reply_to_user_id_str" : "111091623",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "goieltsdotnet",
      "screen_name" : "goieltsdotnet",
      "indices" : [ 0, 14 ],
      "id_str" : "3052238274",
      "id" : 3052238274
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "689751298003091456",
  "geo" : { },
  "id_str" : "689760944277307392",
  "in_reply_to_user_id" : 3052238274,
  "text" : "@goieltsdotnet thx for sharing poll :)",
  "id" : 689760944277307392,
  "in_reply_to_status_id" : 689751298003091456,
  "created_at" : "2016-01-20 10:46:38 +0000",
  "in_reply_to_screen_name" : "goieltsdotnet",
  "in_reply_to_user_id_str" : "3052238274",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 10, 18 ]
    }, {
      "text" : "eltchinwag",
      "indices" : [ 19, 30 ]
    }, {
      "text" : "keltchat",
      "indices" : [ 31, 40 ]
    }, {
      "text" : "auschat",
      "indices" : [ 41, 49 ]
    }, {
      "text" : "tefl",
      "indices" : [ 50, 55 ]
    }, {
      "text" : "efl",
      "indices" : [ 56, 60 ]
    }, {
      "text" : "elt",
      "indices" : [ 61, 65 ]
    }, {
      "text" : "esl",
      "indices" : [ 66, 70 ]
    }, {
      "text" : "esol",
      "indices" : [ 71, 76 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "689745984113475584",
  "geo" : { },
  "id_str" : "689749947898531840",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava #eltchat #eltchinwag #keltchat #auschat #tefl #efl #elt #esl #esol",
  "id" : 689749947898531840,
  "in_reply_to_status_id" : 689745984113475584,
  "created_at" : "2016-01-20 10:02:57 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "689749411694526464",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish thx for RT Marc even after 8k tweets keep forgetting hastags doh!",
  "id" : 689749411694526464,
  "created_at" : "2016-01-20 10:00:49 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "689745984113475584",
  "text" : "Language teachers. Do you know what HVPT means? (no googling!)",
  "id" : 689745984113475584,
  "created_at" : "2016-01-20 09:47:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "P\u00E9rez-Paredes",
      "screen_name" : "perezparedes",
      "indices" : [ 0, 13 ],
      "id_str" : "28528850",
      "id" : 28528850
    }, {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 14, 23 ],
      "id_str" : "121063600",
      "id" : 121063600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "689728260700278784",
  "geo" : { },
  "id_str" : "689728814189023232",
  "in_reply_to_user_id" : 28528850,
  "text" : "@perezparedes @whyshona is it worth the pixels it is written on? e.g. no information on what counts as a second language re. Irish case",
  "id" : 689728814189023232,
  "in_reply_to_status_id" : 689728260700278784,
  "created_at" : "2016-01-20 08:38:58 +0000",
  "in_reply_to_screen_name" : "perezparedes",
  "in_reply_to_user_id_str" : "28528850",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oliver Mason",
      "screen_name" : "ojmason",
      "indices" : [ 0, 8 ],
      "id_str" : "19781877",
      "id" : 19781877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "689716572257140736",
  "geo" : { },
  "id_str" : "689727749171367936",
  "in_reply_to_user_id" : 19781877,
  "text" : "@ojmason working as designed i.e. create fear, mistrust, confusion etc etc",
  "id" : 689727749171367936,
  "in_reply_to_status_id" : 689716572257140736,
  "created_at" : "2016-01-20 08:34:44 +0000",
  "in_reply_to_screen_name" : "ojmason",
  "in_reply_to_user_id_str" : "19781877",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "689581514305069062",
  "geo" : { },
  "id_str" : "689583881146736641",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish going back to your question seems they are wedded to the data for the data god and theory be damned?",
  "id" : 689583881146736641,
  "in_reply_to_status_id" : 689581514305069062,
  "created_at" : "2016-01-19 23:03:03 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/H5ZjBdWOvd",
      "expanded_url" : "http:\/\/eer.sagepub.com\/content\/15\/1\/34.full.pdf+html",
      "display_url" : "eer.sagepub.com\/content\/15\/1\/3\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "689578780126380032",
  "geo" : { },
  "id_str" : "689581129981169664",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish there is more info about Pearson approach from linked article https:\/\/t.co\/H5ZjBdWOvd in midst of reading it",
  "id" : 689581129981169664,
  "in_reply_to_status_id" : 689578780126380032,
  "created_at" : "2016-01-19 22:52:07 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 96, 112 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/U9PSZQXaIz",
      "expanded_url" : "http:\/\/wp.me\/p3VIfJ-83",
      "display_url" : "wp.me\/p3VIfJ-83"
    } ]
  },
  "geo" : { },
  "id_str" : "689572782766735361",
  "text" : "Who owns educational theory? Pearson, big data and the 'theory gap' https:\/\/t.co\/U9PSZQXaIz via @wordpressdotcom",
  "id" : 689572782766735361,
  "created_at" : "2016-01-19 22:18:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Shepherd",
      "screen_name" : "samshep",
      "indices" : [ 3, 11 ],
      "id_str" : "20146035",
      "id" : 20146035
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/mDNjNHNf3H",
      "expanded_url" : "https:\/\/samuelshep.wordpress.com\/2016\/01\/18\/except-or-why-20-million-is-an-insult",
      "display_url" : "samuelshep.wordpress.com\/2016\/01\/18\/exc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "689142711136432128",
  "text" : "RT @samshep: Except. Or \u201Cwhy \u00A320 million is an insult.\u201D https:\/\/t.co\/mDNjNHNf3H",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 66 ],
        "url" : "https:\/\/t.co\/mDNjNHNf3H",
        "expanded_url" : "https:\/\/samuelshep.wordpress.com\/2016\/01\/18\/except-or-why-20-million-is-an-insult",
        "display_url" : "samuelshep.wordpress.com\/2016\/01\/18\/exc\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "689132388492824576",
    "text" : "Except. Or \u201Cwhy \u00A320 million is an insult.\u201D https:\/\/t.co\/mDNjNHNf3H",
    "id" : 689132388492824576,
    "created_at" : "2016-01-18 17:08:59 +0000",
    "user" : {
      "name" : "Sam Shepherd",
      "screen_name" : "samshep",
      "protected" : false,
      "id_str" : "20146035",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/740863245880197120\/_BaMJ5Hf_normal.jpg",
      "id" : 20146035,
      "verified" : false
    }
  },
  "id" : 689142711136432128,
  "created_at" : "2016-01-18 17:50:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/nmayWyGsml",
      "expanded_url" : "https:\/\/twitter.com\/BadAstronomer\/status\/689124819837689857",
      "display_url" : "twitter.com\/BadAstronomer\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "689128275482906624",
  "text" : "RT @pchallinor: It's a bunch of cats playing mind games. Clue's in the name. https:\/\/t.co\/nmayWyGsml",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/nmayWyGsml",
        "expanded_url" : "https:\/\/twitter.com\/BadAstronomer\/status\/689124819837689857",
        "display_url" : "twitter.com\/BadAstronomer\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "689126126166372352",
    "text" : "It's a bunch of cats playing mind games. Clue's in the name. https:\/\/t.co\/nmayWyGsml",
    "id" : 689126126166372352,
    "created_at" : "2016-01-18 16:44:06 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 689128275482906624,
  "created_at" : "2016-01-18 16:52:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 61, 76 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/NYjKjGPda3",
      "expanded_url" : "http:\/\/abcdelt.com\/exploit-emerging-language\/",
      "display_url" : "abcdelt.com\/exploit-emergi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "689125896377241601",
  "text" : "How to exploit emerging language https:\/\/t.co\/NYjKjGPda3 via @MrChrisJWilson",
  "id" : 689125896377241601,
  "created_at" : "2016-01-18 16:43:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/XXS2Txc1BT",
      "expanded_url" : "https:\/\/twitter.com\/DanHannanMEP\/status\/689013659293626368",
      "display_url" : "twitter.com\/DanHannanMEP\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "689042495733411840",
  "text" : "RT @pchallinor: Good point. No doubt Dan will be asking those posturing Etonians how much new funding for ESOL is in the pipeline. https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/XXS2Txc1BT",
        "expanded_url" : "https:\/\/twitter.com\/DanHannanMEP\/status\/689013659293626368",
        "display_url" : "twitter.com\/DanHannanMEP\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "689039551269105664",
    "text" : "Good point. No doubt Dan will be asking those posturing Etonians how much new funding for ESOL is in the pipeline. https:\/\/t.co\/XXS2Txc1BT",
    "id" : 689039551269105664,
    "created_at" : "2016-01-18 11:00:05 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 689042495733411840,
  "created_at" : "2016-01-18 11:11:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donald Clark",
      "screen_name" : "DonaldClark",
      "indices" : [ 3, 15 ],
      "id_str" : "1632891",
      "id" : 1632891
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/DonaldClark\/status\/688682690552418304\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/DwCmiaBs3m",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CY6xQePWMAAtXT3.jpg",
      "id_str" : "688682689587720192",
      "id" : 688682689587720192,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CY6xQePWMAAtXT3.jpg",
      "sizes" : [ {
        "h" : 425,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 241,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 725,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 969,
        "resize" : "fit",
        "w" : 1368
      } ],
      "display_url" : "pic.twitter.com\/DwCmiaBs3m"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/9S5oi30JnO",
      "expanded_url" : "http:\/\/bit.ly\/1naZfV3",
      "display_url" : "bit.ly\/1naZfV3"
    } ]
  },
  "geo" : { },
  "id_str" : "688848644452302849",
  "text" : "RT @DonaldClark: 10 solid Corbyn education policies. Why are most in education ignoring all but student fees? https:\/\/t.co\/9S5oi30JnO https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/DonaldClark\/status\/688682690552418304\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/DwCmiaBs3m",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CY6xQePWMAAtXT3.jpg",
        "id_str" : "688682689587720192",
        "id" : 688682689587720192,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CY6xQePWMAAtXT3.jpg",
        "sizes" : [ {
          "h" : 425,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 241,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 725,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 969,
          "resize" : "fit",
          "w" : 1368
        } ],
        "display_url" : "pic.twitter.com\/DwCmiaBs3m"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/9S5oi30JnO",
        "expanded_url" : "http:\/\/bit.ly\/1naZfV3",
        "display_url" : "bit.ly\/1naZfV3"
      } ]
    },
    "geo" : { },
    "id_str" : "688682690552418304",
    "text" : "10 solid Corbyn education policies. Why are most in education ignoring all but student fees? https:\/\/t.co\/9S5oi30JnO https:\/\/t.co\/DwCmiaBs3m",
    "id" : 688682690552418304,
    "created_at" : "2016-01-17 11:22:03 +0000",
    "user" : {
      "name" : "Donald Clark",
      "screen_name" : "DonaldClark",
      "protected" : false,
      "id_str" : "1632891",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/513085530695663616\/BfWK4n6u_normal.jpeg",
      "id" : 1632891,
      "verified" : false
    }
  },
  "id" : 688848644452302849,
  "created_at" : "2016-01-17 22:21:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noame",
      "screen_name" : "2noame",
      "indices" : [ 0, 7 ],
      "id_str" : "763407955471499264",
      "id" : 763407955471499264
    }, {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 8, 18 ],
      "id_str" : "525274103",
      "id" : 525274103
    }, {
      "name" : "Yves Smith",
      "screen_name" : "yvessmith",
      "indices" : [ 19, 29 ],
      "id_str" : "47387039",
      "id" : 47387039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "688778333627129856",
  "geo" : { },
  "id_str" : "688782492627812354",
  "in_reply_to_user_id" : 14297863,
  "text" : "@2noame @ElkySmith @yvessmith thanks for info :)",
  "id" : 688782492627812354,
  "in_reply_to_status_id" : 688778333627129856,
  "created_at" : "2016-01-17 17:58:37 +0000",
  "in_reply_to_screen_name" : "scottsantens",
  "in_reply_to_user_id_str" : "14297863",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 0, 10 ],
      "id_str" : "525274103",
      "id" : 525274103
    }, {
      "name" : "Yves Smith",
      "screen_name" : "yvessmith",
      "indices" : [ 11, 21 ],
      "id_str" : "47387039",
      "id" : 47387039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "688658032440389632",
  "geo" : { },
  "id_str" : "688770889828143104",
  "in_reply_to_user_id" : 525274103,
  "text" : "@ElkySmith @yvessmith thanks :)",
  "id" : 688770889828143104,
  "in_reply_to_status_id" : 688658032440389632,
  "created_at" : "2016-01-17 17:12:31 +0000",
  "in_reply_to_screen_name" : "ElkySmith",
  "in_reply_to_user_id_str" : "525274103",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sandy Millin",
      "screen_name" : "sandymillin",
      "indices" : [ 0, 12 ],
      "id_str" : "144236944",
      "id" : 144236944
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "688661896451493889",
  "geo" : { },
  "id_str" : "688770650991890432",
  "in_reply_to_user_id" : 144236944,
  "text" : "@sandymillin thanks Sandy, not actually used this yet as end of term when video appeared!",
  "id" : 688770650991890432,
  "in_reply_to_status_id" : 688661896451493889,
  "created_at" : "2016-01-17 17:11:34 +0000",
  "in_reply_to_screen_name" : "sandymillin",
  "in_reply_to_user_id_str" : "144236944",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 0, 10 ],
      "id_str" : "525274103",
      "id" : 525274103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/tA5RiMx3xX",
      "expanded_url" : "http:\/\/loopthetube.com\/#Ky4uYnsF3kc&start=190.43099999999998&end=197.513",
      "display_url" : "loopthetube.com\/#Ky4uYnsF3kc&s\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "688600449461563394",
  "geo" : { },
  "id_str" : "688610027553296384",
  "in_reply_to_user_id" : 525274103,
  "text" : "@ElkySmith a 90s basic income bro https:\/\/t.co\/tA5RiMx3xX bros or not a good idea",
  "id" : 688610027553296384,
  "in_reply_to_status_id" : 688600449461563394,
  "created_at" : "2016-01-17 06:33:18 +0000",
  "in_reply_to_screen_name" : "ElkySmith",
  "in_reply_to_user_id_str" : "525274103",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/DNSqcJGjo8",
      "expanded_url" : "https:\/\/electronicintifada.net\/blogs\/abraham-greenhouse\/alan-rickmans-gaza-play-censored-theater-staging-david-bowies-lazarus",
      "display_url" : "electronicintifada.net\/blogs\/abraham-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "688469777455681536",
  "text" : "Alan Rickman's Gaza play censored by theater staging David Bowie's \"Lazarus\" https:\/\/t.co\/DNSqcJGjo8",
  "id" : 688469777455681536,
  "created_at" : "2016-01-16 21:16:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 0, 15 ],
      "id_str" : "285614027",
      "id" : 285614027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "688466602489163776",
  "geo" : { },
  "id_str" : "688467227310424065",
  "in_reply_to_user_id" : 285614027,
  "text" : "@AnthonyTeacher lk fwd to reading it",
  "id" : 688467227310424065,
  "in_reply_to_status_id" : 688466602489163776,
  "created_at" : "2016-01-16 21:05:52 +0000",
  "in_reply_to_screen_name" : "AnthonyTeacher",
  "in_reply_to_user_id_str" : "285614027",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 0, 15 ],
      "id_str" : "285614027",
      "id" : 285614027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "688462116022538241",
  "geo" : { },
  "id_str" : "688466219347894272",
  "in_reply_to_user_id" : 285614027,
  "text" : "@AnthonyTeacher have u read Corpora and coursebooks: destined to be strangers forever? small survey study but basically biz as usual",
  "id" : 688466219347894272,
  "in_reply_to_status_id" : 688462116022538241,
  "created_at" : "2016-01-16 21:01:52 +0000",
  "in_reply_to_screen_name" : "AnthonyTeacher",
  "in_reply_to_user_id_str" : "285614027",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 3, 18 ],
      "id_str" : "285614027",
      "id" : 285614027
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ResearchBites",
      "indices" : [ 20, 34 ]
    }, {
      "text" : "EAP",
      "indices" : [ 69, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/nkknduuBf9",
      "expanded_url" : "http:\/\/www.anthonyteacher.com\/blog\/researchbites\/research-bites-coursebooks-and-eap-part-1",
      "display_url" : "anthonyteacher.com\/blog\/researchb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "688464459774455808",
  "text" : "RT @AnthonyTeacher: #ResearchBites: What do corpus studies say about #EAP coursebooks? (hint: nothing good)\n\nhttps:\/\/t.co\/nkknduuBf9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ResearchBites",
        "indices" : [ 0, 14 ]
      }, {
        "text" : "EAP",
        "indices" : [ 49, 53 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/nkknduuBf9",
        "expanded_url" : "http:\/\/www.anthonyteacher.com\/blog\/researchbites\/research-bites-coursebooks-and-eap-part-1",
        "display_url" : "anthonyteacher.com\/blog\/researchb\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "688462116022538241",
    "text" : "#ResearchBites: What do corpus studies say about #EAP coursebooks? (hint: nothing good)\n\nhttps:\/\/t.co\/nkknduuBf9",
    "id" : 688462116022538241,
    "created_at" : "2016-01-16 20:45:34 +0000",
    "user" : {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "protected" : false,
      "id_str" : "285614027",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/412336845658132481\/Om5kKuMQ_normal.jpeg",
      "id" : 285614027,
      "verified" : false
    }
  },
  "id" : 688464459774455808,
  "created_at" : "2016-01-16 20:54:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Moore",
      "screen_name" : "lexicojules",
      "indices" : [ 0, 12 ],
      "id_str" : "424320799",
      "id" : 424320799
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "688405821303173121",
  "geo" : { },
  "id_str" : "688462608064770049",
  "in_reply_to_user_id" : 424320799,
  "text" : "@lexicojules thx for the inspiration, listed an academic collocations list to list : )",
  "id" : 688462608064770049,
  "in_reply_to_status_id" : 688405821303173121,
  "created_at" : "2016-01-16 20:47:31 +0000",
  "in_reply_to_screen_name" : "lexicojules",
  "in_reply_to_user_id_str" : "424320799",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kamila Linkov\u00E1",
      "screen_name" : "kamilaofprague",
      "indices" : [ 0, 15 ],
      "id_str" : "3439998148",
      "id" : 3439998148
    }, {
      "name" : "Monika Sobejko",
      "screen_name" : "SobejM",
      "indices" : [ 16, 23 ],
      "id_str" : "380504775",
      "id" : 380504775
    }, {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 24, 40 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    }, {
      "name" : "Chris Jones",
      "screen_name" : "ELTResearch",
      "indices" : [ 41, 53 ],
      "id_str" : "3308043417",
      "id" : 3308043417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "688343593216532480",
  "in_reply_to_user_id" : 3439998148,
  "text" : "@kamilaofprague @SobejM @getgreatenglish @ELTResearch many thx for wordlist share",
  "id" : 688343593216532480,
  "created_at" : "2016-01-16 12:54:36 +0000",
  "in_reply_to_screen_name" : "kamilaofprague",
  "in_reply_to_user_id_str" : "3439998148",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "goieltsdotnet",
      "screen_name" : "goieltsdotnet",
      "indices" : [ 0, 14 ],
      "id_str" : "3052238274",
      "id" : 3052238274
    }, {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "indices" : [ 15, 25 ],
      "id_str" : "577931950",
      "id" : 577931950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "688286976907317248",
  "geo" : { },
  "id_str" : "688292304268820480",
  "in_reply_to_user_id" : 3052238274,
  "text" : "@goieltsdotnet @RudyLoock thanks for sharing! : )",
  "id" : 688292304268820480,
  "in_reply_to_status_id" : 688286976907317248,
  "created_at" : "2016-01-16 09:30:47 +0000",
  "in_reply_to_screen_name" : "goieltsdotnet",
  "in_reply_to_user_id_str" : "3052238274",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marion Nao",
      "screen_name" : "LinguaNao",
      "indices" : [ 3, 13 ],
      "id_str" : "2844937438",
      "id" : 2844937438
    }, {
      "name" : "Phys.org",
      "screen_name" : "physorg_com",
      "indices" : [ 120, 132 ],
      "id_str" : "17248121",
      "id" : 17248121
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sociolinguistics",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/EYPuI8umvm",
      "expanded_url" : "http:\/\/phy.so\/372001648",
      "display_url" : "phy.so\/372001648"
    } ]
  },
  "geo" : { },
  "id_str" : "688292018838200320",
  "text" : "RT @LinguaNao: Teenagers' role in language change is overstated, linguistics research finds https:\/\/t.co\/EYPuI8umvm via @physorg_com #socio\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Phys.org",
        "screen_name" : "physorg_com",
        "indices" : [ 105, 117 ],
        "id_str" : "17248121",
        "id" : 17248121
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "sociolinguistics",
        "indices" : [ 118, 135 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/EYPuI8umvm",
        "expanded_url" : "http:\/\/phy.so\/372001648",
        "display_url" : "phy.so\/372001648"
      } ]
    },
    "geo" : { },
    "id_str" : "688285327455203329",
    "text" : "Teenagers' role in language change is overstated, linguistics research finds https:\/\/t.co\/EYPuI8umvm via @physorg_com #sociolinguistics",
    "id" : 688285327455203329,
    "created_at" : "2016-01-16 09:03:04 +0000",
    "user" : {
      "name" : "Marion Nao",
      "screen_name" : "LinguaNao",
      "protected" : false,
      "id_str" : "2844937438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/526302660282957826\/nfzhauD7_normal.jpeg",
      "id" : 2844937438,
      "verified" : false
    }
  },
  "id" : 688292018838200320,
  "created_at" : "2016-01-16 09:29:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 75, 83 ]
    }, {
      "text" : "esl",
      "indices" : [ 84, 88 ]
    }, {
      "text" : "tefl",
      "indices" : [ 89, 94 ]
    }, {
      "text" : "eltchinwag",
      "indices" : [ 95, 106 ]
    }, {
      "text" : "auselt",
      "indices" : [ 107, 114 ]
    }, {
      "text" : "keltchat",
      "indices" : [ 115, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/OZoEuYqJyF",
      "expanded_url" : "http:\/\/wp.me\/PgHyE-113",
      "display_url" : "wp.me\/PgHyE-113"
    } ]
  },
  "geo" : { },
  "id_str" : "688283357700947968",
  "text" : "English General &amp; Subject-specific Wordlists https:\/\/t.co\/OZoEuYqJyF v #eltchat #esl #tefl #eltchinwag #auselt #keltchat",
  "id" : 688283357700947968,
  "created_at" : "2016-01-16 08:55:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 73, 89 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/ce7Sp6XHhO",
      "expanded_url" : "http:\/\/wp.me\/p3c4te-4v",
      "display_url" : "wp.me\/p3c4te-4v"
    } ]
  },
  "geo" : { },
  "id_str" : "688160945953095682",
  "text" : "Review: 'Why Only Us' by Berwick and Chomsky https:\/\/t.co\/ce7Sp6XHhO via @wordpressdotcom",
  "id" : 688160945953095682,
  "created_at" : "2016-01-16 00:48:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 0, 11 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/6RmPcT5EzS",
      "expanded_url" : "http:\/\/infomotions.com\/sandbox\/great-books\/great-books.htm",
      "display_url" : "infomotions.com\/sandbox\/great-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "687975723005526017",
  "geo" : { },
  "id_str" : "687977331332378624",
  "in_reply_to_user_id" : 87902543,
  "text" : "@tornhalves An updated great books curriculum perhaps? https:\/\/t.co\/6RmPcT5EzS",
  "id" : 687977331332378624,
  "in_reply_to_status_id" : 687975723005526017,
  "created_at" : "2016-01-15 12:39:12 +0000",
  "in_reply_to_screen_name" : "tornhalves",
  "in_reply_to_user_id_str" : "87902543",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 0, 11 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "687971469071138817",
  "geo" : { },
  "id_str" : "687973584795512833",
  "in_reply_to_user_id" : 87902543,
  "text" : "@tornhalves : ) what are the chances the most teacherly teachers will teach Bowie?",
  "id" : 687973584795512833,
  "in_reply_to_status_id" : 687971469071138817,
  "created_at" : "2016-01-15 12:24:19 +0000",
  "in_reply_to_screen_name" : "tornhalves",
  "in_reply_to_user_id_str" : "87902543",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 0, 11 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "687956747777085440",
  "geo" : { },
  "id_str" : "687960116910489600",
  "in_reply_to_user_id" : 87902543,
  "text" : "@tornhalves is it  \"The worst of the teacherly teachers...\"  or best? maybe the worst get effigys thrown on bonfire : )",
  "id" : 687960116910489600,
  "in_reply_to_status_id" : 687956747777085440,
  "created_at" : "2016-01-15 11:30:48 +0000",
  "in_reply_to_screen_name" : "tornhalves",
  "in_reply_to_user_id_str" : "87902543",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 3, 14 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pedagogy",
      "indices" : [ 91, 100 ]
    }, {
      "text" : "education",
      "indices" : [ 105, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/kVqkWYifxV",
      "expanded_url" : "http:\/\/bit.ly\/1RSUDxV",
      "display_url" : "bit.ly\/1RSUDxV"
    } ]
  },
  "geo" : { },
  "id_str" : "687959755764150272",
  "text" : "RT @tornhalves: If the sages have to get down from their stages, why not the gods of rock? #pedagogy and #education after Bowie https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "pedagogy",
        "indices" : [ 75, 84 ]
      }, {
        "text" : "education",
        "indices" : [ 89, 99 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/kVqkWYifxV",
        "expanded_url" : "http:\/\/bit.ly\/1RSUDxV",
        "display_url" : "bit.ly\/1RSUDxV"
      } ]
    },
    "geo" : { },
    "id_str" : "687956747777085440",
    "text" : "If the sages have to get down from their stages, why not the gods of rock? #pedagogy and #education after Bowie https:\/\/t.co\/kVqkWYifxV",
    "id" : 687956747777085440,
    "created_at" : "2016-01-15 11:17:24 +0000",
    "user" : {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "protected" : false,
      "id_str" : "87902543",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3059742703\/1d3c7a2052db17d29644fa0a49af6480_normal.jpeg",
      "id" : 87902543,
      "verified" : false
    }
  },
  "id" : 687959755764150272,
  "created_at" : "2016-01-15 11:29:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Sinclair",
      "screen_name" : "IanJSinclair",
      "indices" : [ 3, 16 ],
      "id_str" : "270100506",
      "id" : 270100506
    }, {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 18, 30 ],
      "id_str" : "223771625",
      "id" : 223771625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/hqOULnq6ex",
      "expanded_url" : "https:\/\/www.opendemocracy.net\/uk\/ian-sinclair\/countering-peter-tatchell-s-pro-war-anti-war-arguments-on-syria",
      "display_url" : "opendemocracy.net\/uk\/ian-sinclai\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "687948196954386432",
  "text" : "RT @IanJSinclair: @johnwhilley My new article 'Countering Peter Tatchell\u2019s pro-war anti-war arguments on Syria' may be of interest https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Hilley",
        "screen_name" : "johnwhilley",
        "indices" : [ 0, 12 ],
        "id_str" : "223771625",
        "id" : 223771625
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/hqOULnq6ex",
        "expanded_url" : "https:\/\/www.opendemocracy.net\/uk\/ian-sinclair\/countering-peter-tatchell-s-pro-war-anti-war-arguments-on-syria",
        "display_url" : "opendemocracy.net\/uk\/ian-sinclai\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "687937981030756354",
    "in_reply_to_user_id" : 223771625,
    "text" : "@johnwhilley My new article 'Countering Peter Tatchell\u2019s pro-war anti-war arguments on Syria' may be of interest https:\/\/t.co\/hqOULnq6ex",
    "id" : 687937981030756354,
    "created_at" : "2016-01-15 10:02:50 +0000",
    "in_reply_to_screen_name" : "johnwhilley",
    "in_reply_to_user_id_str" : "223771625",
    "user" : {
      "name" : "Ian Sinclair",
      "screen_name" : "IanJSinclair",
      "protected" : false,
      "id_str" : "270100506",
      "profile_image_url_https" : "https:\/\/abs.twimg.com\/sticky\/default_profile_images\/default_profile_4_normal.png",
      "id" : 270100506,
      "verified" : false
    }
  },
  "id" : 687948196954386432,
  "created_at" : "2016-01-15 10:43:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 0, 9 ],
      "id_str" : "121063600",
      "id" : 121063600
    }, {
      "name" : "Acedle",
      "screen_name" : "acedle",
      "indices" : [ 10, 17 ],
      "id_str" : "2999329659",
      "id" : 2999329659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/Dg105h61uv",
      "expanded_url" : "http:\/\/xa.yimg.com\/kq\/groups\/13328543\/539599815\/name\/Teoria%20da%20complexidade%20questionada.pdf",
      "display_url" : "xa.yimg.com\/kq\/groups\/1332\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "687943395986280449",
  "geo" : { },
  "id_str" : "687946487465140228",
  "in_reply_to_user_id" : 121063600,
  "text" : "@whyshona @acedle that Gregg review article is available here https:\/\/t.co\/Dg105h61uv",
  "id" : 687946487465140228,
  "in_reply_to_status_id" : 687943395986280449,
  "created_at" : "2016-01-15 10:36:38 +0000",
  "in_reply_to_screen_name" : "whyshona",
  "in_reply_to_user_id_str" : "121063600",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELT Teacher 2 Writer",
      "screen_name" : "ELT_T2W",
      "indices" : [ 3, 11 ],
      "id_str" : "427697599",
      "id" : 427697599
    }, {
      "name" : "MaWSIG",
      "screen_name" : "MaWSIG",
      "indices" : [ 16, 23 ],
      "id_str" : "1096618700",
      "id" : 1096618700
    }, {
      "name" : "Julie Moore",
      "screen_name" : "lexicojules",
      "indices" : [ 44, 56 ],
      "id_str" : "424320799",
      "id" : 424320799
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELT",
      "indices" : [ 106, 110 ]
    }, {
      "text" : "EFL",
      "indices" : [ 111, 115 ]
    }, {
      "text" : "ESL",
      "indices" : [ 116, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/UQemmzMdAq",
      "expanded_url" : "http:\/\/mawsig.iatefl.org\/?p=2153",
      "display_url" : "mawsig.iatefl.org\/?p=2153"
    } ]
  },
  "geo" : { },
  "id_str" : "687927196212662272",
  "text" : "RT @ELT_T2W: RT @MaWSIG: New blog post from @lexicojules thinking about wordlists https:\/\/t.co\/UQemmzMdAq #ELT #EFL #ESL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "MaWSIG",
        "screen_name" : "MaWSIG",
        "indices" : [ 3, 10 ],
        "id_str" : "1096618700",
        "id" : 1096618700
      }, {
        "name" : "Julie Moore",
        "screen_name" : "lexicojules",
        "indices" : [ 31, 43 ],
        "id_str" : "424320799",
        "id" : 424320799
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELT",
        "indices" : [ 93, 97 ]
      }, {
        "text" : "EFL",
        "indices" : [ 98, 102 ]
      }, {
        "text" : "ESL",
        "indices" : [ 103, 107 ]
      } ],
      "urls" : [ {
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/UQemmzMdAq",
        "expanded_url" : "http:\/\/mawsig.iatefl.org\/?p=2153",
        "display_url" : "mawsig.iatefl.org\/?p=2153"
      } ]
    },
    "geo" : { },
    "id_str" : "687924381792735236",
    "text" : "RT @MaWSIG: New blog post from @lexicojules thinking about wordlists https:\/\/t.co\/UQemmzMdAq #ELT #EFL #ESL",
    "id" : 687924381792735236,
    "created_at" : "2016-01-15 09:08:48 +0000",
    "user" : {
      "name" : "ELT Teacher 2 Writer",
      "screen_name" : "ELT_T2W",
      "protected" : false,
      "id_str" : "427697599",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1675434441\/T2W_logo_normal.jpg",
      "id" : 427697599,
      "verified" : false
    }
  },
  "id" : 687927196212662272,
  "created_at" : "2016-01-15 09:19:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John X Williams",
      "screen_name" : "lexicoj0hn",
      "indices" : [ 0, 11 ],
      "id_str" : "4008981801",
      "id" : 4008981801
    }, {
      "name" : "English SE",
      "screen_name" : "StackEnglish",
      "indices" : [ 12, 25 ],
      "id_str" : "235339197",
      "id" : 235339197
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "687782883646390275",
  "geo" : { },
  "id_str" : "687799177611448320",
  "in_reply_to_user_id" : 4008981801,
  "text" : "@lexicoj0hn @StackEnglish yes true that and how explain its use in measurements?",
  "id" : 687799177611448320,
  "in_reply_to_status_id" : 687782883646390275,
  "created_at" : "2016-01-15 00:51:17 +0000",
  "in_reply_to_screen_name" : "lexicoj0hn",
  "in_reply_to_user_id_str" : "4008981801",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/GL6w5dTyxH",
      "expanded_url" : "http:\/\/goo.gl\/9NMoZa",
      "display_url" : "goo.gl\/9NMoZa"
    } ]
  },
  "geo" : { },
  "id_str" : "687716001488744454",
  "text" : "Accepting Your Error Rate\n https:\/\/t.co\/GL6w5dTyxH",
  "id" : 687716001488744454,
  "created_at" : "2016-01-14 19:20:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John X Williams",
      "screen_name" : "lexicoj0hn",
      "indices" : [ 0, 11 ],
      "id_str" : "4008981801",
      "id" : 4008981801
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/RgHaNLl8b7",
      "expanded_url" : "http:\/\/english.stackexchange.com\/questions\/38293\/why-is-zero-plural#",
      "display_url" : "english.stackexchange.com\/questions\/3829\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "687404219037544448",
  "geo" : { },
  "id_str" : "687405321002835968",
  "in_reply_to_user_id" : 18602422,
  "text" : "@lexicoj0hn https:\/\/t.co\/RgHaNLl8b7",
  "id" : 687405321002835968,
  "in_reply_to_status_id" : 687404219037544448,
  "created_at" : "2016-01-13 22:46:14 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John X Williams",
      "screen_name" : "lexicoj0hn",
      "indices" : [ 0, 11 ],
      "id_str" : "4008981801",
      "id" : 4008981801
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "687313533927862272",
  "geo" : { },
  "id_str" : "687404219037544448",
  "in_reply_to_user_id" : 4008981801,
  "text" : "@lexicoj0hn no thanks for noticing :) though more u think about that more befuddled one gets :\/",
  "id" : 687404219037544448,
  "in_reply_to_status_id" : 687313533927862272,
  "created_at" : "2016-01-13 22:41:51 +0000",
  "in_reply_to_screen_name" : "lexicoj0hn",
  "in_reply_to_user_id_str" : "4008981801",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Igor Brigadir",
      "screen_name" : "IgorBrigadir",
      "indices" : [ 0, 13 ],
      "id_str" : "495430242",
      "id" : 495430242
    }, {
      "name" : "Pascal J\u00FCrgens",
      "screen_name" : "pascal",
      "indices" : [ 14, 21 ],
      "id_str" : "653773",
      "id" : 653773
    }, {
      "name" : "Andreas Jungherr",
      "screen_name" : "ajungherr",
      "indices" : [ 22, 32 ],
      "id_str" : "8314742",
      "id" : 8314742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "687308575757189120",
  "geo" : { },
  "id_str" : "687311415976325121",
  "in_reply_to_user_id" : 495430242,
  "text" : "@IgorBrigadir @pascal @ajungherr very nice thanks :)",
  "id" : 687311415976325121,
  "in_reply_to_status_id" : 687308575757189120,
  "created_at" : "2016-01-13 16:33:05 +0000",
  "in_reply_to_screen_name" : "IgorBrigadir",
  "in_reply_to_user_id_str" : "495430242",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan A Howard",
      "screen_name" : "FriendlyDemon",
      "indices" : [ 3, 17 ],
      "id_str" : "88001214",
      "id" : 88001214
    }, {
      "name" : "BBC News (UK)",
      "screen_name" : "BBCNews",
      "indices" : [ 44, 52 ],
      "id_str" : "612473",
      "id" : 612473
    }, {
      "name" : "Laura Kuenssberg",
      "screen_name" : "bbclaurak",
      "indices" : [ 57, 67 ],
      "id_str" : "61183568",
      "id" : 61183568
    }, {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 92, 102 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 140 ],
      "url" : "https:\/\/t.co\/EJQj9BdzRZ",
      "expanded_url" : "http:\/\/bit.ly\/1UOFQn3",
      "display_url" : "bit.ly\/1UOFQn3"
    } ]
  },
  "geo" : { },
  "id_str" : "687309768390750208",
  "text" : "RT @FriendlyDemon: The biased journalism of @BBCNews and @bbclaurak exposed and analysed by @medialens Essential reading https:\/\/t.co\/EJQj9\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BBC News (UK)",
        "screen_name" : "BBCNews",
        "indices" : [ 25, 33 ],
        "id_str" : "612473",
        "id" : 612473
      }, {
        "name" : "Laura Kuenssberg",
        "screen_name" : "bbclaurak",
        "indices" : [ 38, 48 ],
        "id_str" : "61183568",
        "id" : 61183568
      }, {
        "name" : "Media Lens",
        "screen_name" : "medialens",
        "indices" : [ 73, 83 ],
        "id_str" : "6531902",
        "id" : 6531902
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/EJQj9BdzRZ",
        "expanded_url" : "http:\/\/bit.ly\/1UOFQn3",
        "display_url" : "bit.ly\/1UOFQn3"
      } ]
    },
    "geo" : { },
    "id_str" : "687279509603758081",
    "text" : "The biased journalism of @BBCNews and @bbclaurak exposed and analysed by @medialens Essential reading https:\/\/t.co\/EJQj9BdzRZ",
    "id" : 687279509603758081,
    "created_at" : "2016-01-13 14:26:18 +0000",
    "user" : {
      "name" : "Jonathan A Howard",
      "screen_name" : "FriendlyDemon",
      "protected" : false,
      "id_str" : "88001214",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746984700955156480\/Zg-UE3vF_normal.jpg",
      "id" : 88001214,
      "verified" : false
    }
  },
  "id" : 687309768390750208,
  "created_at" : "2016-01-13 16:26:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angus B Grieve-Smith",
      "screen_name" : "grvsmth",
      "indices" : [ 0, 8 ],
      "id_str" : "22381639",
      "id" : 22381639
    }, {
      "name" : "Costas Gabrielatos",
      "screen_name" : "congabonga",
      "indices" : [ 9, 20 ],
      "id_str" : "187484412",
      "id" : 187484412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "686966302183940096",
  "geo" : { },
  "id_str" : "686984864646737920",
  "in_reply_to_user_id" : 22381639,
  "text" : "@grvsmth @congabonga was this their only data collection method for the project?",
  "id" : 686984864646737920,
  "in_reply_to_status_id" : 686966302183940096,
  "created_at" : "2016-01-12 18:55:29 +0000",
  "in_reply_to_screen_name" : "grvsmth",
  "in_reply_to_user_id_str" : "22381639",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusresources",
      "indices" : [ 56, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/OwV7rebBY7",
      "expanded_url" : "http:\/\/pelcra.clarin-pl.eu\/SpokesBNC\/#home",
      "display_url" : "pelcra.clarin-pl.eu\/SpokesBNC\/#home"
    } ]
  },
  "geo" : { },
  "id_str" : "686954825242783744",
  "text" : "Spokes for the BNC (spoekn BNC) https:\/\/t.co\/OwV7rebBY7 #corpusresources",
  "id" : 686954825242783744,
  "created_at" : "2016-01-12 16:56:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/686950274343243776\/photo\/1",
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/JiY0VmwSfy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CYiJolgWYAAzUjA.png",
      "id_str" : "686950273529569280",
      "id" : 686950273529569280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYiJolgWYAAzUjA.png",
      "sizes" : [ {
        "h" : 250,
        "resize" : "fit",
        "w" : 1136
      }, {
        "h" : 132,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 75,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/JiY0VmwSfy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "686950274343243776",
  "text" : "really liking SlopeQ search syntax (Bowie &lt;pos=j.*&gt;)~2 https:\/\/t.co\/JiY0VmwSfy",
  "id" : 686950274343243776,
  "created_at" : "2016-01-12 16:38:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusresources",
      "indices" : [ 39, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/qAZ3lOirH2",
      "expanded_url" : "http:\/\/pelcra.clarin-pl.eu\/SlopeqBNC\/#home",
      "display_url" : "pelcra.clarin-pl.eu\/SlopeqBNC\/#home"
    }, {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/65tB1k5EhU",
      "expanded_url" : "http:\/\/corpus4u.org",
      "display_url" : "corpus4u.org"
    } ]
  },
  "geo" : { },
  "id_str" : "686941960742039552",
  "text" : "SlopeQ for BNC https:\/\/t.co\/qAZ3lOirH2 #corpusresources h\/t\/ https:\/\/t.co\/65tB1k5EhU",
  "id" : 686941960742039552,
  "created_at" : "2016-01-12 16:05:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Costas Gabrielatos",
      "screen_name" : "congabonga",
      "indices" : [ 0, 11 ],
      "id_str" : "187484412",
      "id" : 187484412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "686924301472272384",
  "geo" : { },
  "id_str" : "686927368146030592",
  "in_reply_to_user_id" : 187484412,
  "text" : "@congabonga i guess it's only one way they are looking for new content? have u tried the app? it is pretty good",
  "id" : 686927368146030592,
  "in_reply_to_status_id" : 686924301472272384,
  "created_at" : "2016-01-12 15:07:01 +0000",
  "in_reply_to_screen_name" : "congabonga",
  "in_reply_to_user_id_str" : "187484412",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Costas Gabrielatos",
      "screen_name" : "congabonga",
      "indices" : [ 0, 11 ],
      "id_str" : "187484412",
      "id" : 187484412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "686890638072246272",
  "geo" : { },
  "id_str" : "686909800488288257",
  "in_reply_to_user_id" : 187484412,
  "text" : "@congabonga sorry don't understand analogy?",
  "id" : 686909800488288257,
  "in_reply_to_status_id" : 686890638072246272,
  "created_at" : "2016-01-12 13:57:13 +0000",
  "in_reply_to_screen_name" : "congabonga",
  "in_reply_to_user_id_str" : "187484412",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Costas Gabrielatos",
      "screen_name" : "congabonga",
      "indices" : [ 0, 11 ],
      "id_str" : "187484412",
      "id" : 187484412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "686872518989352960",
  "geo" : { },
  "id_str" : "686877413423316992",
  "in_reply_to_user_id" : 187484412,
  "text" : "@congabonga app itself has interesting info. guess they have more traditional sampling as well as crowdsourced sampling?",
  "id" : 686877413423316992,
  "in_reply_to_status_id" : 686872518989352960,
  "created_at" : "2016-01-12 11:48:31 +0000",
  "in_reply_to_screen_name" : "congabonga",
  "in_reply_to_user_id_str" : "187484412",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "indices" : [ 0, 12 ],
      "id_str" : "192437743",
      "id" : 192437743
    }, {
      "name" : "feedly",
      "screen_name" : "feedly",
      "indices" : [ 13, 20 ],
      "id_str" : "14485018",
      "id" : 14485018
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "686693994160508928",
  "geo" : { },
  "id_str" : "686695408979017729",
  "in_reply_to_user_id" : 192437743,
  "text" : "@nathanghall @feedly wah?! hehe : ) something to do with alphabetical order of twitter handles?",
  "id" : 686695408979017729,
  "in_reply_to_status_id" : 686693994160508928,
  "created_at" : "2016-01-11 23:45:18 +0000",
  "in_reply_to_screen_name" : "nathanghall",
  "in_reply_to_user_id_str" : "192437743",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Bowie",
      "indices" : [ 0, 6 ]
    } ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/gr5Qqs3eYu",
      "expanded_url" : "http:\/\/ncase.me\/simulating\/model\/?remote=-K7mtBFiJnQcSE81dOTi",
      "display_url" : "ncase.me\/simulating\/mod\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "686682596022063107",
  "text" : "#Bowie lovers and haters neighbourhood https:\/\/t.co\/gr5Qqs3eYu : )",
  "id" : 686682596022063107,
  "created_at" : "2016-01-11 22:54:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bella Caledonia",
      "screen_name" : "bellacaledonia",
      "indices" : [ 48, 63 ],
      "id_str" : "103554348",
      "id" : 103554348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/tWhs2iGXhs",
      "expanded_url" : "http:\/\/bellacaledonia.org.uk\/2016\/01\/11\/high-land-hard-rain\/",
      "display_url" : "bellacaledonia.org.uk\/2016\/01\/11\/hig\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "686646849487433729",
  "text" : "High Land Hard Rain https:\/\/t.co\/tWhs2iGXhs via @bellacaledonia",
  "id" : 686646849487433729,
  "created_at" : "2016-01-11 20:32:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 3, 18 ],
      "id_str" : "285614027",
      "id" : 285614027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/61vGkJireK",
      "expanded_url" : "http:\/\/ift.tt\/1TQ74te",
      "display_url" : "ift.tt\/1TQ74te"
    } ]
  },
  "geo" : { },
  "id_str" : "686634226406559746",
  "text" : "RT @AnthonyTeacher: Guest Post: \u201CSpoken Syntax\u201D and Corrective Feedback https:\/\/t.co\/61vGkJireK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 75 ],
        "url" : "https:\/\/t.co\/61vGkJireK",
        "expanded_url" : "http:\/\/ift.tt\/1TQ74te",
        "display_url" : "ift.tt\/1TQ74te"
      } ]
    },
    "geo" : { },
    "id_str" : "686630560370921472",
    "text" : "Guest Post: \u201CSpoken Syntax\u201D and Corrective Feedback https:\/\/t.co\/61vGkJireK",
    "id" : 686630560370921472,
    "created_at" : "2016-01-11 19:27:37 +0000",
    "user" : {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "protected" : false,
      "id_str" : "285614027",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/412336845658132481\/Om5kKuMQ_normal.jpeg",
      "id" : 285614027,
      "verified" : false
    }
  },
  "id" : 686634226406559746,
  "created_at" : "2016-01-11 19:42:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoff Lindsey",
      "screen_name" : "GeoffLindsey",
      "indices" : [ 78, 91 ],
      "id_str" : "381534458",
      "id" : 381534458
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusresources",
      "indices" : [ 92, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/DbasQP8f0Q",
      "expanded_url" : "http:\/\/seas3.elte.hu\/cube\/",
      "display_url" : "seas3.elte.hu\/cube\/"
    } ]
  },
  "geo" : { },
  "id_str" : "686620048635592705",
  "text" : "Current British English searchable transcriptions https:\/\/t.co\/DbasQP8f0Q via @GeoffLindsey #corpusresources",
  "id" : 686620048635592705,
  "created_at" : "2016-01-11 18:45:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/Nd5TppJRN3",
      "expanded_url" : "http:\/\/metashare.metanet4u.eu\/",
      "display_url" : "metashare.metanet4u.eu"
    }, {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/c5XS34piOg",
      "expanded_url" : "http:\/\/digitalmobilelanguagelearning.org\/2016\/01\/language-datasets-and-you-a-primer\/",
      "display_url" : "digitalmobilelanguagelearning.org\/2016\/01\/langua\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "686559929335939072",
  "text" : "Metashare https:\/\/t.co\/Nd5TppJRN3 also read about some more language datasets - https:\/\/t.co\/c5XS34piOg",
  "id" : 686559929335939072,
  "created_at" : "2016-01-11 14:46:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "686552375209914368",
  "geo" : { },
  "id_str" : "686555632753848320",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco the slop factor and order option pretty neat",
  "id" : 686555632753848320,
  "in_reply_to_status_id" : 686552375209914368,
  "created_at" : "2016-01-11 14:29:53 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 3, 14 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/39uNWARWSV",
      "expanded_url" : "http:\/\/monitorcorpus.com\/",
      "display_url" : "monitorcorpus.com"
    } ]
  },
  "geo" : { },
  "id_str" : "686541363643551744",
  "text" : "RT @lexicoloco: Monco - Really interesting + useful monitor corpus (in Beta) - almost realtime corpus. Great for studying new words. https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/39uNWARWSV",
        "expanded_url" : "http:\/\/monitorcorpus.com\/",
        "display_url" : "monitorcorpus.com"
      } ]
    },
    "geo" : { },
    "id_str" : "686499605484290048",
    "text" : "Monco - Really interesting + useful monitor corpus (in Beta) - almost realtime corpus. Great for studying new words. https:\/\/t.co\/39uNWARWSV",
    "id" : 686499605484290048,
    "created_at" : "2016-01-11 10:47:15 +0000",
    "user" : {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "protected" : false,
      "id_str" : "300734173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2403500097\/3nmx3kjaycyoc7irwe6s_normal.jpeg",
      "id" : 300734173,
      "verified" : false
    }
  },
  "id" : 686541363643551744,
  "created_at" : "2016-01-11 13:33:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oxford Academic",
      "screen_name" : "OUPAcademic",
      "indices" : [ 0, 12 ],
      "id_str" : "6580122",
      "id" : 6580122
    }, {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "indices" : [ 13, 23 ],
      "id_str" : "577931950",
      "id" : 577931950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "686250613156478978",
  "geo" : { },
  "id_str" : "686280688279130113",
  "in_reply_to_user_id" : 6580122,
  "text" : "@OUPAcademic @RudyLoock yeah it asks for u\/n and p\/w?",
  "id" : 686280688279130113,
  "in_reply_to_status_id" : 686250613156478978,
  "created_at" : "2016-01-10 20:17:21 +0000",
  "in_reply_to_screen_name" : "OUPAcademic",
  "in_reply_to_user_id_str" : "6580122",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "indices" : [ 0, 10 ],
      "id_str" : "577931950",
      "id" : 577931950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "686182928645226496",
  "geo" : { },
  "id_str" : "686186567820525570",
  "in_reply_to_user_id" : 577931950,
  "text" : "@RudyLoock great",
  "id" : 686186567820525570,
  "in_reply_to_status_id" : 686182928645226496,
  "created_at" : "2016-01-10 14:03:21 +0000",
  "in_reply_to_screen_name" : "RudyLoock",
  "in_reply_to_user_id_str" : "577931950",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "indices" : [ 0, 10 ],
      "id_str" : "577931950",
      "id" : 577931950
    }, {
      "name" : "Oxford Academic",
      "screen_name" : "OUPAcademic",
      "indices" : [ 11, 23 ],
      "id_str" : "6580122",
      "id" : 6580122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "686180721812221957",
  "in_reply_to_user_id" : 577931950,
  "text" : "@RudyLoock @OUPAcademic neat any chance of seeing accompanying website?",
  "id" : 686180721812221957,
  "created_at" : "2016-01-10 13:40:07 +0000",
  "in_reply_to_screen_name" : "RudyLoock",
  "in_reply_to_user_id_str" : "577931950",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/S6GIOE3Wyk",
      "expanded_url" : "http:\/\/www.theguardian.com\/commentisfree\/2016\/jan\/10\/keep-britain-tidy-what-the-queen-would-want",
      "display_url" : "theguardian.com\/commentisfree\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "686180354353397764",
  "text" : "RT @pchallinor: \"of all the characteristics that define Britain, none is so dependably on view as sycophancy\" https:\/\/t.co\/S6GIOE3Wyk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/S6GIOE3Wyk",
        "expanded_url" : "http:\/\/www.theguardian.com\/commentisfree\/2016\/jan\/10\/keep-britain-tidy-what-the-queen-would-want",
        "display_url" : "theguardian.com\/commentisfree\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "686178401309319169",
    "text" : "\"of all the characteristics that define Britain, none is so dependably on view as sycophancy\" https:\/\/t.co\/S6GIOE3Wyk",
    "id" : 686178401309319169,
    "created_at" : "2016-01-10 13:30:54 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 686180354353397764,
  "created_at" : "2016-01-10 13:38:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Visconti",
      "screen_name" : "Literature_Geek",
      "indices" : [ 3, 19 ],
      "id_str" : "89312744",
      "id" : 89312744
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CodexHack",
      "indices" : [ 105, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/eUpXzsi0xl",
      "expanded_url" : "https:\/\/macmillanpublishers.github.io\/bookmaker\/",
      "display_url" : "macmillanpublishers.github.io\/bookmaker\/"
    } ]
  },
  "geo" : { },
  "id_str" : "685855798984052737",
  "text" : "RT @Literature_Geek: \"The open-source bookmaking tool from Macmillan Publishers\u201D https:\/\/t.co\/eUpXzsi0xl #CodexHack",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CodexHack",
        "indices" : [ 84, 94 ]
      } ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/eUpXzsi0xl",
        "expanded_url" : "https:\/\/macmillanpublishers.github.io\/bookmaker\/",
        "display_url" : "macmillanpublishers.github.io\/bookmaker\/"
      } ]
    },
    "geo" : { },
    "id_str" : "685848020349521920",
    "text" : "\"The open-source bookmaking tool from Macmillan Publishers\u201D https:\/\/t.co\/eUpXzsi0xl #CodexHack",
    "id" : 685848020349521920,
    "created_at" : "2016-01-09 15:38:05 +0000",
    "user" : {
      "name" : "Amanda Visconti",
      "screen_name" : "Literature_Geek",
      "protected" : false,
      "id_str" : "89312744",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1641666770\/tracedavatar_normal.jpg",
      "id" : 89312744,
      "verified" : false
    }
  },
  "id" : 685855798984052737,
  "created_at" : "2016-01-09 16:08:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenn Greenwald",
      "screen_name" : "ggreenwald",
      "indices" : [ 127, 138 ],
      "id_str" : "16076032",
      "id" : 16076032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/UM2LynN9iJ",
      "expanded_url" : "http:\/\/interc.pt\/1kSkusF",
      "display_url" : "interc.pt\/1kSkusF"
    } ]
  },
  "geo" : { },
  "id_str" : "685792211691270144",
  "text" : "Where were the post-Hebdo free speech crusaders as France spent the last year crushing free speech? https:\/\/t.co\/UM2LynN9iJ by @ggreenwald",
  "id" : 685792211691270144,
  "created_at" : "2016-01-09 11:56:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 36, 52 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 31 ],
      "url" : "https:\/\/t.co\/DbEUqzVCW0",
      "expanded_url" : "http:\/\/wp.me\/p40HiS-bk",
      "display_url" : "wp.me\/p40HiS-bk"
    } ]
  },
  "geo" : { },
  "id_str" : "685779197533515776",
  "text" : "Oh dear https:\/\/t.co\/DbEUqzVCW0 via @wordpressdotcom",
  "id" : 685779197533515776,
  "created_at" : "2016-01-09 11:04:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Caines",
      "screen_name" : "cainesap",
      "indices" : [ 0, 9 ],
      "id_str" : "578898729",
      "id" : 578898729
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "685744090324037632",
  "geo" : { },
  "id_str" : "685759394190065664",
  "in_reply_to_user_id" : 578898729,
  "text" : "@cainesap : ) r u not jumping the gun blurbs rarely written by authors no?",
  "id" : 685759394190065664,
  "in_reply_to_status_id" : 685744090324037632,
  "created_at" : "2016-01-09 09:45:55 +0000",
  "in_reply_to_screen_name" : "cainesap",
  "in_reply_to_user_id_str" : "578898729",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Rosenfelder",
      "screen_name" : "zompist",
      "indices" : [ 3, 11 ],
      "id_str" : "358006618",
      "id" : 358006618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/L59bZuWdRM",
      "expanded_url" : "https:\/\/zompist.wordpress.com\/2016\/01\/08\/why-nlp-is-so-hard\/",
      "display_url" : "zompist.wordpress.com\/2016\/01\/08\/why\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "685596917255041024",
  "text" : "RT @zompist: Why NLP is so hard: https:\/\/t.co\/L59bZuWdRM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 20, 43 ],
        "url" : "https:\/\/t.co\/L59bZuWdRM",
        "expanded_url" : "https:\/\/zompist.wordpress.com\/2016\/01\/08\/why-nlp-is-so-hard\/",
        "display_url" : "zompist.wordpress.com\/2016\/01\/08\/why\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "685570466715688961",
    "text" : "Why NLP is so hard: https:\/\/t.co\/L59bZuWdRM",
    "id" : 685570466715688961,
    "created_at" : "2016-01-08 21:15:11 +0000",
    "user" : {
      "name" : "Mark Rosenfelder",
      "screen_name" : "zompist",
      "protected" : false,
      "id_str" : "358006618",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1503071360\/Portal2-Fuschia_normal.jpg",
      "id" : 358006618,
      "verified" : false
    }
  },
  "id" : 685596917255041024,
  "created_at" : "2016-01-08 23:00:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy for Labour",
      "screen_name" : "jeremyforlabour",
      "indices" : [ 3, 19 ],
      "id_str" : "755182225424060416",
      "id" : 755182225424060416
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "https:\/\/t.co\/5fevb0fNcs",
      "expanded_url" : "http:\/\/www.bbc.co.uk\/complaints\/",
      "display_url" : "bbc.co.uk\/complaints\/"
    } ]
  },
  "geo" : { },
  "id_str" : "685448896785563648",
  "text" : "RT @jeremyforlabour: If you wish to lodge a complaint with the BBC over Laura Kuenssberg's conduct, you may do so here: https:\/\/t.co\/5fevb0\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/5fevb0fNcs",
        "expanded_url" : "http:\/\/www.bbc.co.uk\/complaints\/",
        "display_url" : "bbc.co.uk\/complaints\/"
      } ]
    },
    "in_reply_to_status_id_str" : "685390700825948160",
    "geo" : { },
    "id_str" : "685405819521859584",
    "in_reply_to_user_id" : 3327849574,
    "text" : "If you wish to lodge a complaint with the BBC over Laura Kuenssberg's conduct, you may do so here: https:\/\/t.co\/5fevb0fNcs",
    "id" : 685405819521859584,
    "in_reply_to_status_id" : 685390700825948160,
    "created_at" : "2016-01-08 10:20:56 +0000",
    "in_reply_to_screen_name" : "jeremyforlab",
    "in_reply_to_user_id_str" : "3327849574",
    "user" : {
      "name" : "Jeremy for PM",
      "screen_name" : "jeremyforlab",
      "protected" : false,
      "id_str" : "3327849574",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/610533394888413184\/23psG-qd_normal.jpg",
      "id" : 3327849574,
      "verified" : false
    }
  },
  "id" : 685448896785563648,
  "created_at" : "2016-01-08 13:12:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Owen Jones",
      "screen_name" : "OwenJones84",
      "indices" : [ 3, 15 ],
      "id_str" : "65045121",
      "id" : 65045121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/uKDWMJV05q",
      "expanded_url" : "https:\/\/alittleecon.wordpress.com\/2016\/01\/07\/the-bbc-admits-it-co-ordinated-in-advance-the-on-air-resignation-of-stephen-doughty\/",
      "display_url" : "alittleecon.wordpress.com\/2016\/01\/07\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "685230363338260480",
  "text" : "RT @OwenJones84: The BBC admits it co-ordinated in advance the on-air resignation of Stephen Doughty. What are your thoughts on this? https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/uKDWMJV05q",
        "expanded_url" : "https:\/\/alittleecon.wordpress.com\/2016\/01\/07\/the-bbc-admits-it-co-ordinated-in-advance-the-on-air-resignation-of-stephen-doughty\/",
        "display_url" : "alittleecon.wordpress.com\/2016\/01\/07\/the\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "685227460892471296",
    "text" : "The BBC admits it co-ordinated in advance the on-air resignation of Stephen Doughty. What are your thoughts on this? https:\/\/t.co\/uKDWMJV05q",
    "id" : 685227460892471296,
    "created_at" : "2016-01-07 22:32:12 +0000",
    "user" : {
      "name" : "Owen Jones",
      "screen_name" : "OwenJones84",
      "protected" : false,
      "id_str" : "65045121",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/681493332678291457\/swHdHJNr_normal.jpg",
      "id" : 65045121,
      "verified" : true
    }
  },
  "id" : 685230363338260480,
  "created_at" : "2016-01-07 22:43:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Sketch Engine",
      "screen_name" : "SketchEngine",
      "indices" : [ 3, 16 ],
      "id_str" : "841197134",
      "id" : 841197134
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/SketchEngine\/status\/685002678838116352\/photo\/1",
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/YG8Nknp3eO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CYGeTl-UAAAlEX3.png",
      "id_str" : "685002677785198592",
      "id" : 685002677785198592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYGeTl-UAAAlEX3.png",
      "sizes" : [ {
        "h" : 567,
        "resize" : "fit",
        "w" : 899
      }, {
        "h" : 567,
        "resize" : "fit",
        "w" : 899
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 378,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 214,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/YG8Nknp3eO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "685134979463032832",
  "text" : "RT @SketchEngine: We wish you a ... https:\/\/t.co\/YG8Nknp3eO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/SketchEngine\/status\/685002678838116352\/photo\/1",
        "indices" : [ 18, 41 ],
        "url" : "https:\/\/t.co\/YG8Nknp3eO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CYGeTl-UAAAlEX3.png",
        "id_str" : "685002677785198592",
        "id" : 685002677785198592,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYGeTl-UAAAlEX3.png",
        "sizes" : [ {
          "h" : 567,
          "resize" : "fit",
          "w" : 899
        }, {
          "h" : 567,
          "resize" : "fit",
          "w" : 899
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 378,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 214,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/YG8Nknp3eO"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "685002678838116352",
    "text" : "We wish you a ... https:\/\/t.co\/YG8Nknp3eO",
    "id" : 685002678838116352,
    "created_at" : "2016-01-07 07:39:00 +0000",
    "user" : {
      "name" : "Sketch Engine",
      "screen_name" : "SketchEngine",
      "protected" : false,
      "id_str" : "841197134",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/763331747538997248\/ua_lo7Zd_normal.jpg",
      "id" : 841197134,
      "verified" : false
    }
  },
  "id" : 685134979463032832,
  "created_at" : "2016-01-07 16:24:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenys Hanson",
      "screen_name" : "GlenysHanson",
      "indices" : [ 0, 13 ],
      "id_str" : "527238447",
      "id" : 527238447
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "684880455066337280",
  "geo" : { },
  "id_str" : "684882970449149954",
  "in_reply_to_user_id" : 527238447,
  "text" : "@GlenysHanson a pleasure a great article will surely use it",
  "id" : 684882970449149954,
  "in_reply_to_status_id" : 684880455066337280,
  "created_at" : "2016-01-06 23:43:19 +0000",
  "in_reply_to_screen_name" : "GlenysHanson",
  "in_reply_to_user_id_str" : "527238447",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/awB4WmUByR",
      "expanded_url" : "http:\/\/www.glenys-hanson.info\/determiners-a-an-or-the\/#.Vo2jQW8ZryA.twitter",
      "display_url" : "glenys-hanson.info\/determiners-a-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "684879446248165377",
  "text" : "Using the determiners a\/an or the https:\/\/t.co\/awB4WmUByR",
  "id" : 684879446248165377,
  "created_at" : "2016-01-06 23:29:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenn Greenwald",
      "screen_name" : "ggreenwald",
      "indices" : [ 3, 14 ],
      "id_str" : "16076032",
      "id" : 16076032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/HANfFm2fpH",
      "expanded_url" : "https:\/\/theintercept.com\/2016\/01\/06\/the-deceptive-debate-over-what-causes-terrorism-against-the-west\/",
      "display_url" : "theintercept.com\/2016\/01\/06\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "684838537909432320",
  "text" : "RT @ggreenwald: How shocking that Jeremy Corbyn would rather not have shadow ministers who publicly smear him as an ISIS apologist https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/HANfFm2fpH",
        "expanded_url" : "https:\/\/theintercept.com\/2016\/01\/06\/the-deceptive-debate-over-what-causes-terrorism-against-the-west\/",
        "display_url" : "theintercept.com\/2016\/01\/06\/the\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "684814556015816704",
    "text" : "How shocking that Jeremy Corbyn would rather not have shadow ministers who publicly smear him as an ISIS apologist https:\/\/t.co\/HANfFm2fpH",
    "id" : 684814556015816704,
    "created_at" : "2016-01-06 19:11:28 +0000",
    "user" : {
      "name" : "Glenn Greenwald",
      "screen_name" : "ggreenwald",
      "protected" : false,
      "id_str" : "16076032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/659383028771364869\/G9HHnjiI_normal.jpg",
      "id" : 16076032,
      "verified" : true
    }
  },
  "id" : 684838537909432320,
  "created_at" : "2016-01-06 20:46:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 0, 9 ],
      "id_str" : "121063600",
      "id" : 121063600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "684691419924180992",
  "geo" : { },
  "id_str" : "684789803464962048",
  "in_reply_to_user_id" : 121063600,
  "text" : "@whyshona if i can wangle some time! u?",
  "id" : 684789803464962048,
  "in_reply_to_status_id" : 684691419924180992,
  "created_at" : "2016-01-06 17:33:06 +0000",
  "in_reply_to_screen_name" : "whyshona",
  "in_reply_to_user_id_str" : "121063600",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donald Clark",
      "screen_name" : "DonaldClark",
      "indices" : [ 0, 12 ],
      "id_str" : "1632891",
      "id" : 1632891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/j6Gs24WZPF",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=eFpThn8E3W4",
      "display_url" : "youtube.com\/watch?v=eFpThn\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "684507477715599361",
  "geo" : { },
  "id_str" : "684509782691196933",
  "in_reply_to_user_id" : 1632891,
  "text" : "@DonaldClark that last commenter in article is wisely skeptical imo https:\/\/t.co\/j6Gs24WZPF",
  "id" : 684509782691196933,
  "in_reply_to_status_id" : 684507477715599361,
  "created_at" : "2016-01-05 23:00:24 +0000",
  "in_reply_to_screen_name" : "DonaldClark",
  "in_reply_to_user_id_str" : "1632891",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Texas",
      "indices" : [ 81, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/j5Aak7fc6S",
      "expanded_url" : "http:\/\/johnhilley.blogspot.co.uk\/2016\/01\/american-gun-law-and-real-wild-west.html",
      "display_url" : "johnhilley.blogspot.co.uk\/2016\/01\/americ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "684503280131637248",
  "text" : "RT @johnwhilley: American gun law and the real Wild West https:\/\/t.co\/j5Aak7fc6S #Texas",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Texas",
        "indices" : [ 64, 70 ]
      } ],
      "urls" : [ {
        "indices" : [ 40, 63 ],
        "url" : "https:\/\/t.co\/j5Aak7fc6S",
        "expanded_url" : "http:\/\/johnhilley.blogspot.co.uk\/2016\/01\/american-gun-law-and-real-wild-west.html",
        "display_url" : "johnhilley.blogspot.co.uk\/2016\/01\/americ\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "683699928770691074",
    "text" : "American gun law and the real Wild West https:\/\/t.co\/j5Aak7fc6S #Texas",
    "id" : 683699928770691074,
    "created_at" : "2016-01-03 17:22:20 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 684503280131637248,
  "created_at" : "2016-01-05 22:34:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alistair Baron",
      "screen_name" : "al586",
      "indices" : [ 0, 6 ],
      "id_str" : "50316421",
      "id" : 50316421
    }, {
      "name" : "Steve Kleinedler",
      "screen_name" : "SKleinedler",
      "indices" : [ 7, 19 ],
      "id_str" : "3112104673",
      "id" : 3112104673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "684411163459883012",
  "geo" : { },
  "id_str" : "684467657257558016",
  "in_reply_to_user_id" : 50316421,
  "text" : "@al586 @SKleinedler there is videogrep",
  "id" : 684467657257558016,
  "in_reply_to_status_id" : 684411163459883012,
  "created_at" : "2016-01-05 20:13:00 +0000",
  "in_reply_to_screen_name" : "al586",
  "in_reply_to_user_id_str" : "50316421",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sophia Khan",
      "screen_name" : "SophiaKhan4",
      "indices" : [ 0, 12 ],
      "id_str" : "351390617",
      "id" : 351390617
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "684328548669075457",
  "geo" : { },
  "id_str" : "684358946916843520",
  "in_reply_to_user_id" : 351390617,
  "text" : "@SophiaKhan4 yr welcome Sophia, hope they continue to make more",
  "id" : 684358946916843520,
  "in_reply_to_status_id" : 684328548669075457,
  "created_at" : "2016-01-05 13:01:02 +0000",
  "in_reply_to_screen_name" : "SophiaKhan4",
  "in_reply_to_user_id_str" : "351390617",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 99, 115 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/se0zdZrgz7",
      "expanded_url" : "http:\/\/wp.me\/p26azg-3q",
      "display_url" : "wp.me\/p26azg-3q"
    } ]
  },
  "geo" : { },
  "id_str" : "684151269603307520",
  "text" : "hu\u00B7bris\u02C8(h)yo\u035Eobr\u0259s\/noun: hubris 1.excessive pride or self-confidence. https:\/\/t.co\/se0zdZrgz7 via @wordpressdotcom",
  "id" : 684151269603307520,
  "created_at" : "2016-01-04 23:15:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Poole",
      "screen_name" : "RobertEPoole",
      "indices" : [ 3, 16 ],
      "id_str" : "18526186",
      "id" : 18526186
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/nTX1cbKhvc",
      "expanded_url" : "http:\/\/Money.com",
      "display_url" : "Money.com"
    }, {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/qvBxdYaqAb",
      "expanded_url" : "http:\/\/time.com\/money\/4163467\/words-companies-failures\/",
      "display_url" : "time.com\/money\/4163467\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "684125545928519680",
  "text" : "RT @RobertEPoole: https:\/\/t.co\/nTX1cbKhvc with a write-up on my article on business writing in Int'l Journal of Business Communication http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/nTX1cbKhvc",
        "expanded_url" : "http:\/\/Money.com",
        "display_url" : "Money.com"
      }, {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/qvBxdYaqAb",
        "expanded_url" : "http:\/\/time.com\/money\/4163467\/words-companies-failures\/",
        "display_url" : "time.com\/money\/4163467\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "684111046911504384",
    "text" : "https:\/\/t.co\/nTX1cbKhvc with a write-up on my article on business writing in Int'l Journal of Business Communication https:\/\/t.co\/qvBxdYaqAb",
    "id" : 684111046911504384,
    "created_at" : "2016-01-04 20:35:58 +0000",
    "user" : {
      "name" : "Robert Poole",
      "screen_name" : "RobertEPoole",
      "protected" : false,
      "id_str" : "18526186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/586985086073069568\/UbAcX_I3_normal.jpg",
      "id" : 18526186,
      "verified" : false
    }
  },
  "id" : 684125545928519680,
  "created_at" : "2016-01-04 21:33:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyler Schnoebelen",
      "screen_name" : "TSchnoebelen",
      "indices" : [ 3, 16 ],
      "id_str" : "14969147",
      "id" : 14969147
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/938MZV85bh",
      "expanded_url" : "https:\/\/vimeo.com\/150423718",
      "display_url" : "vimeo.com\/150423718"
    } ]
  },
  "geo" : { },
  "id_str" : "684067278095257602",
  "text" : "RT @TSchnoebelen: \u201CHow\u2019d you spend your holidays?\u201D \u201COh, you know, alphabetizing The Wizard of Oz\u201D https:\/\/t.co\/938MZV85bh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/938MZV85bh",
        "expanded_url" : "https:\/\/vimeo.com\/150423718",
        "display_url" : "vimeo.com\/150423718"
      } ]
    },
    "geo" : { },
    "id_str" : "684055575324405760",
    "text" : "\u201CHow\u2019d you spend your holidays?\u201D \u201COh, you know, alphabetizing The Wizard of Oz\u201D https:\/\/t.co\/938MZV85bh",
    "id" : 684055575324405760,
    "created_at" : "2016-01-04 16:55:32 +0000",
    "user" : {
      "name" : "Tyler Schnoebelen",
      "screen_name" : "TSchnoebelen",
      "protected" : false,
      "id_str" : "14969147",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/604427674203779072\/Y4t_NODB_normal.jpg",
      "id" : 14969147,
      "verified" : false
    }
  },
  "id" : 684067278095257602,
  "created_at" : "2016-01-04 17:42:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Ash FRSA",
      "screen_name" : "Ashowski",
      "indices" : [ 0, 9 ],
      "id_str" : "316596356",
      "id" : 316596356
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "683975347654799362",
  "geo" : { },
  "id_str" : "684041437525184513",
  "in_reply_to_user_id" : 316596356,
  "text" : "@Ashowski hey Anthony thx for the hat tip :)",
  "id" : 684041437525184513,
  "in_reply_to_status_id" : 683975347654799362,
  "created_at" : "2016-01-04 15:59:22 +0000",
  "in_reply_to_screen_name" : "Ashowski",
  "in_reply_to_user_id_str" : "316596356",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 92, 100 ]
    }, {
      "text" : "eltchinwag",
      "indices" : [ 101, 112 ]
    }, {
      "text" : "keltchat",
      "indices" : [ 113, 122 ]
    }, {
      "text" : "auselt",
      "indices" : [ 123, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/FoI8Rx4hJy",
      "expanded_url" : "https:\/\/www.youtube.com\/channel\/UCqkSvImcT0Q-L6MZNi48aBQ",
      "display_url" : "youtube.com\/channel\/UCqkSv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "684041064869687296",
  "text" : "BlackBox some neat videos aimed at SLA topics for language teachers https:\/\/t.co\/FoI8Rx4hJy #eltchat #eltchinwag #keltchat #auselt",
  "id" : 684041064869687296,
  "created_at" : "2016-01-04 15:57:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donald Clark",
      "screen_name" : "DonaldClark",
      "indices" : [ 0, 12 ],
      "id_str" : "1632891",
      "id" : 1632891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "684036058196127744",
  "geo" : { },
  "id_str" : "684039802648457216",
  "in_reply_to_user_id" : 1632891,
  "text" : "@DonaldClark he's got stiff competition like that Segway guy who  built a helicopter garage at his place :)",
  "id" : 684039802648457216,
  "in_reply_to_status_id" : 684036058196127744,
  "created_at" : "2016-01-04 15:52:52 +0000",
  "in_reply_to_screen_name" : "DonaldClark",
  "in_reply_to_user_id_str" : "1632891",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "indices" : [ 3, 15 ],
      "id_str" : "849729062",
      "id" : 849729062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/YDptEFhhVo",
      "expanded_url" : "http:\/\/cass.lancs.ac.uk\/?p=1849",
      "display_url" : "cass.lancs.ac.uk\/?p=1849"
    } ]
  },
  "geo" : { },
  "id_str" : "684037860597587971",
  "text" : "RT @TonyMcEnery: Remembering my good friend and collaborator Richard Xiao, 1966-2016: https:\/\/t.co\/YDptEFhhVo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/YDptEFhhVo",
        "expanded_url" : "http:\/\/cass.lancs.ac.uk\/?p=1849",
        "display_url" : "cass.lancs.ac.uk\/?p=1849"
      } ]
    },
    "geo" : { },
    "id_str" : "683974173920727040",
    "text" : "Remembering my good friend and collaborator Richard Xiao, 1966-2016: https:\/\/t.co\/YDptEFhhVo",
    "id" : 683974173920727040,
    "created_at" : "2016-01-04 11:32:05 +0000",
    "user" : {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "protected" : false,
      "id_str" : "849729062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2676020930\/a4a1f40d56b447c9dfca1d7b9be4f4b4_normal.jpeg",
      "id" : 849729062,
      "verified" : false
    }
  },
  "id" : 684037860597587971,
  "created_at" : "2016-01-04 15:45:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annabelle Lukin",
      "screen_name" : "annabellelukin",
      "indices" : [ 3, 18 ],
      "id_str" : "86030794",
      "id" : 86030794
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpuslinguistics",
      "indices" : [ 25, 43 ]
    }, {
      "text" : "linguistics",
      "indices" : [ 100, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/OBgEuVMM4n",
      "expanded_url" : "https:\/\/theconversation.com\/we-swear-by-it-but-were-hardly-world-leaders-in-getting-to-grips-with-the-f-word-49676",
      "display_url" : "theconversation.com\/we-swear-by-it\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "683826189497155585",
  "text" : "RT @annabellelukin: What #corpuslinguistics can tell us about real language https:\/\/t.co\/OBgEuVMM4n #linguistics",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpuslinguistics",
        "indices" : [ 5, 23 ]
      }, {
        "text" : "linguistics",
        "indices" : [ 80, 92 ]
      } ],
      "urls" : [ {
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/OBgEuVMM4n",
        "expanded_url" : "https:\/\/theconversation.com\/we-swear-by-it-but-were-hardly-world-leaders-in-getting-to-grips-with-the-f-word-49676",
        "display_url" : "theconversation.com\/we-swear-by-it\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "683816609849278464",
    "text" : "What #corpuslinguistics can tell us about real language https:\/\/t.co\/OBgEuVMM4n #linguistics",
    "id" : 683816609849278464,
    "created_at" : "2016-01-04 01:05:59 +0000",
    "user" : {
      "name" : "Annabelle Lukin",
      "screen_name" : "annabellelukin",
      "protected" : false,
      "id_str" : "86030794",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/468614248264773632\/SxVE4QWx_normal.jpeg",
      "id" : 86030794,
      "verified" : false
    }
  },
  "id" : 683826189497155585,
  "created_at" : "2016-01-04 01:44:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "indices" : [ 0, 10 ],
      "id_str" : "577931950",
      "id" : 577931950
    }, {
      "name" : "Bert Cappelle",
      "screen_name" : "BertCappelle",
      "indices" : [ 11, 24 ],
      "id_str" : "435804356",
      "id" : 435804356
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "683583431297613824",
  "geo" : { },
  "id_str" : "683625220733833216",
  "in_reply_to_user_id" : 577931950,
  "text" : "@RudyLoock @BertCappelle : )",
  "id" : 683625220733833216,
  "in_reply_to_status_id" : 683583431297613824,
  "created_at" : "2016-01-03 12:25:28 +0000",
  "in_reply_to_screen_name" : "RudyLoock",
  "in_reply_to_user_id_str" : "577931950",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "indices" : [ 0, 10 ],
      "id_str" : "577931950",
      "id" : 577931950
    }, {
      "name" : "Bert Cappelle",
      "screen_name" : "BertCappelle",
      "indices" : [ 11, 24 ],
      "id_str" : "435804356",
      "id" : 435804356
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "683334436428079104",
  "geo" : { },
  "id_str" : "683447039829618689",
  "in_reply_to_user_id" : 577931950,
  "text" : "@RudyLoock @BertCappelle a great idea anyone implemented in class yet?",
  "id" : 683447039829618689,
  "in_reply_to_status_id" : 683334436428079104,
  "created_at" : "2016-01-03 00:37:26 +0000",
  "in_reply_to_screen_name" : "RudyLoock",
  "in_reply_to_user_id_str" : "577931950",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 0, 9 ],
      "id_str" : "121063600",
      "id" : 121063600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "682911743279022080",
  "geo" : { },
  "id_str" : "682954785394442244",
  "in_reply_to_user_id" : 121063600,
  "text" : "@whyshona thx for sharing Happy New Year :) do you know of any interesting datasets?",
  "id" : 682954785394442244,
  "in_reply_to_status_id" : 682911743279022080,
  "created_at" : "2016-01-01 16:01:24 +0000",
  "in_reply_to_screen_name" : "whyshona",
  "in_reply_to_user_id_str" : "121063600",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 0, 15 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/2Vy9mYBxDS",
      "expanded_url" : "http:\/\/getguesstimate.com\/models\/748",
      "display_url" : "getguesstimate.com\/models\/748"
    } ]
  },
  "geo" : { },
  "id_str" : "682950588322181122",
  "in_reply_to_user_id" : 334332424,
  "text" : "@GeoffreyJordan Hi Geoff i have a dodgy model for my marking excuses https:\/\/t.co\/2Vy9mYBxDS",
  "id" : 682950588322181122,
  "created_at" : "2016-01-01 15:44:43 +0000",
  "in_reply_to_screen_name" : "GeoffreyJordan",
  "in_reply_to_user_id_str" : "334332424",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/eUwaJ93a2y",
      "expanded_url" : "http:\/\/nsnbc.me\/2015\/12\/31\/russia-vindicated-by-terrorist-surrenders-in-syria\/",
      "display_url" : "nsnbc.me\/2015\/12\/31\/rus\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "682941797702733825",
  "text" : "Russia Vindicated by Terrorist Surrenders in Syria https:\/\/t.co\/eUwaJ93a2y via @httpstwittercomnsnbc",
  "id" : 682941797702733825,
  "created_at" : "2016-01-01 15:09:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hana Tich\u00E1",
      "screen_name" : "HanaTicha",
      "indices" : [ 3, 13 ],
      "id_str" : "512296705",
      "id" : 512296705
    }, {
      "name" : "Shareaholic",
      "screen_name" : "Shareaholic",
      "indices" : [ 87, 99 ],
      "id_str" : "791635",
      "id" : 791635
    }, {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 112, 120 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/UJrtVccVRP",
      "expanded_url" : "http:\/\/go.shr.lc\/1Sq4YC3",
      "display_url" : "go.shr.lc\/1Sq4YC3"
    } ]
  },
  "geo" : { },
  "id_str" : "682925823217807360",
  "text" : "RT @HanaTicha: Unconventional: Publishing With The Round - https:\/\/t.co\/UJrtVccVRP via @Shareaholic Congrats to @seburnt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Shareaholic",
        "screen_name" : "Shareaholic",
        "indices" : [ 72, 84 ],
        "id_str" : "791635",
        "id" : 791635
      }, {
        "name" : "Tyson Seburn",
        "screen_name" : "seburnt",
        "indices" : [ 97, 105 ],
        "id_str" : "20650366",
        "id" : 20650366
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 67 ],
        "url" : "https:\/\/t.co\/UJrtVccVRP",
        "expanded_url" : "http:\/\/go.shr.lc\/1Sq4YC3",
        "display_url" : "go.shr.lc\/1Sq4YC3"
      } ]
    },
    "geo" : { },
    "id_str" : "682913559588814848",
    "text" : "Unconventional: Publishing With The Round - https:\/\/t.co\/UJrtVccVRP via @Shareaholic Congrats to @seburnt",
    "id" : 682913559588814848,
    "created_at" : "2016-01-01 13:17:35 +0000",
    "user" : {
      "name" : "Hana Tich\u00E1",
      "screen_name" : "HanaTicha",
      "protected" : false,
      "id_str" : "512296705",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/699528253598494721\/HL9Np6Gu_normal.jpg",
      "id" : 512296705,
      "verified" : false
    }
  },
  "id" : 682925823217807360,
  "created_at" : "2016-01-01 14:06:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bret Victor",
      "screen_name" : "worrydream",
      "indices" : [ 3, 14 ],
      "id_str" : "255617445",
      "id" : 255617445
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/worrydream\/status\/682632406411657216\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/klMtVGQZek",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CXkyjmeUoAAvbNy.png",
      "id_str" : "682632405727879168",
      "id" : 682632405727879168,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXkyjmeUoAAvbNy.png",
      "sizes" : [ {
        "h" : 315,
        "resize" : "fit",
        "w" : 829
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 315,
        "resize" : "fit",
        "w" : 829
      }, {
        "h" : 228,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 129,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/klMtVGQZek"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/s5M9ktiOfG",
      "expanded_url" : "https:\/\/medium.com\/guesstimate-blog\/introducing-guesstimate-a-spreadsheet-for-things-that-aren-t-certain-2fa54aa9340",
      "display_url" : "medium.com\/guesstimate-bl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "682925323210616832",
  "text" : "RT @worrydream: Oh my god. A calculator for distribution arithmetic. I've been dreaming about this forever.\nhttps:\/\/t.co\/s5M9ktiOfG https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/worrydream\/status\/682632406411657216\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/klMtVGQZek",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CXkyjmeUoAAvbNy.png",
        "id_str" : "682632405727879168",
        "id" : 682632405727879168,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXkyjmeUoAAvbNy.png",
        "sizes" : [ {
          "h" : 315,
          "resize" : "fit",
          "w" : 829
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 315,
          "resize" : "fit",
          "w" : 829
        }, {
          "h" : 228,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 129,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/klMtVGQZek"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/s5M9ktiOfG",
        "expanded_url" : "https:\/\/medium.com\/guesstimate-blog\/introducing-guesstimate-a-spreadsheet-for-things-that-aren-t-certain-2fa54aa9340",
        "display_url" : "medium.com\/guesstimate-bl\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "682632406411657216",
    "text" : "Oh my god. A calculator for distribution arithmetic. I've been dreaming about this forever.\nhttps:\/\/t.co\/s5M9ktiOfG https:\/\/t.co\/klMtVGQZek",
    "id" : 682632406411657216,
    "created_at" : "2015-12-31 18:40:23 +0000",
    "user" : {
      "name" : "Bret Victor",
      "screen_name" : "worrydream",
      "protected" : false,
      "id_str" : "255617445",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/767981637623685120\/7WgbPNE9_normal.jpg",
      "id" : 255617445,
      "verified" : false
    }
  },
  "id" : 682925323210616832,
  "created_at" : "2016-01-01 14:04:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DMLL",
      "screen_name" : "DiMLL",
      "indices" : [ 3, 9 ],
      "id_str" : "1114312832",
      "id" : 1114312832
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 74, 83 ],
      "id_str" : "18602422",
      "id" : 18602422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 124, 140 ],
      "url" : "https:\/\/t.co\/ms27DXeeeY",
      "expanded_url" : "http:\/\/digitalmobilelanguagelearning.org\/2016\/01\/language-datasets-and-you-a-primer\/",
      "display_url" : "digitalmobilelanguagelearning.org\/2016\/01\/langua\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "682887208366391296",
  "text" : "RT @DiMLL: Happy New Year! \n\nWe start 2016 at DMLL with a guest post from @muranava, a language teacher in Paris, France. \n\nhttps:\/\/t.co\/ms\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mura Nava",
        "screen_name" : "muranava",
        "indices" : [ 63, 72 ],
        "id_str" : "18602422",
        "id" : 18602422
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/ms27DXeeeY",
        "expanded_url" : "http:\/\/digitalmobilelanguagelearning.org\/2016\/01\/language-datasets-and-you-a-primer\/",
        "display_url" : "digitalmobilelanguagelearning.org\/2016\/01\/langua\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "682731429994729472",
    "text" : "Happy New Year! \n\nWe start 2016 at DMLL with a guest post from @muranava, a language teacher in Paris, France. \n\nhttps:\/\/t.co\/ms27DXeeeY",
    "id" : 682731429994729472,
    "created_at" : "2016-01-01 01:13:52 +0000",
    "user" : {
      "name" : "DMLL",
      "screen_name" : "DiMLL",
      "protected" : false,
      "id_str" : "1114312832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/675557516583919620\/LTTt0aXN_normal.jpg",
      "id" : 1114312832,
      "verified" : false
    }
  },
  "id" : 682887208366391296,
  "created_at" : "2016-01-01 11:32:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
} ]