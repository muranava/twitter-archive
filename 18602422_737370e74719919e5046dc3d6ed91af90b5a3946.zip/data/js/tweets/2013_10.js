Grailbird.data.tweets_2013_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/tjT8TSXNiQ",
      "expanded_url" : "http:\/\/tinyurl.com\/pa6bfkd",
      "display_url" : "tinyurl.com\/pa6bfkd"
    } ]
  },
  "geo" : { },
  "id_str" : "396027952670195713",
  "text" : "RT @medialens: Libya: 'Zliten had 17 schools before the revolution. Now it has four.. NATO bombed the rest' http:\/\/t.co\/tjT8TSXNiQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/tjT8TSXNiQ",
        "expanded_url" : "http:\/\/tinyurl.com\/pa6bfkd",
        "display_url" : "tinyurl.com\/pa6bfkd"
      } ]
    },
    "geo" : { },
    "id_str" : "395974113547665408",
    "text" : "Libya: 'Zliten had 17 schools before the revolution. Now it has four.. NATO bombed the rest' http:\/\/t.co\/tjT8TSXNiQ",
    "id" : 395974113547665408,
    "created_at" : "2013-10-31 18:02:40 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 396027952670195713,
  "created_at" : "2013-10-31 21:36:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott McLeod",
      "screen_name" : "mcleod",
      "indices" : [ 3, 10 ],
      "id_str" : "4132841",
      "id" : 4132841
    }, {
      "name" : "Dean Shareski",
      "screen_name" : "shareski",
      "indices" : [ 130, 139 ],
      "id_str" : "739743",
      "id" : 739743
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edtech",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/hVJ1uyeyTx",
      "expanded_url" : "http:\/\/bit.ly\/1aWATQY",
      "display_url" : "bit.ly\/1aWATQY"
    } ]
  },
  "geo" : { },
  "id_str" : "396017503023161344",
  "text" : "RT @mcleod: \"If I asked your students, 'How does your teacher learn?', what would they say?\" http:\/\/t.co\/hVJ1uyeyTx Great post by @shareski\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dean Shareski",
        "screen_name" : "shareski",
        "indices" : [ 118, 127 ],
        "id_str" : "739743",
        "id" : 739743
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "edtech",
        "indices" : [ 128, 135 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/hVJ1uyeyTx",
        "expanded_url" : "http:\/\/bit.ly\/1aWATQY",
        "display_url" : "bit.ly\/1aWATQY"
      } ]
    },
    "geo" : { },
    "id_str" : "395966234929684480",
    "text" : "\"If I asked your students, 'How does your teacher learn?', what would they say?\" http:\/\/t.co\/hVJ1uyeyTx Great post by @shareski #edtech",
    "id" : 395966234929684480,
    "created_at" : "2013-10-31 17:31:21 +0000",
    "user" : {
      "name" : "Scott McLeod",
      "screen_name" : "mcleod",
      "protected" : false,
      "id_str" : "4132841",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528513398003077123\/U0fv_0fy_normal.jpeg",
      "id" : 4132841,
      "verified" : false
    }
  },
  "id" : 396017503023161344,
  "created_at" : "2013-10-31 20:55:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DeepDict",
      "indices" : [ 104, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395986294058131456",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler thanks for sharing and giving me another chance to indulge my schoolboy mind by mentioning #DeepDict :)",
  "id" : 395986294058131456,
  "created_at" : "2013-10-31 18:51:04 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russell Stannard",
      "screen_name" : "russell1955",
      "indices" : [ 3, 15 ],
      "id_str" : "14796284",
      "id" : 14796284
    }, {
      "name" : "Shelly Sanchez",
      "screen_name" : "ShellTerrell",
      "indices" : [ 20, 33 ],
      "id_str" : "29655018",
      "id" : 29655018
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MOOC",
      "indices" : [ 109, 114 ]
    }, {
      "text" : "ELTChat",
      "indices" : [ 115, 123 ]
    }, {
      "text" : "ESL",
      "indices" : [ 124, 128 ]
    }, {
      "text" : "ELLChat",
      "indices" : [ 129, 137 ]
    }, {
      "text" : "TEFL",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "IATEFL",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/gvFcBXqR6m",
      "expanded_url" : "http:\/\/www.wiziq.com\/course\/35898-elt-techniques-listening-and-pronunciation",
      "display_url" : "wiziq.com\/course\/35898-e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395982905148964864",
  "text" : "RT @russell1955: RT @ShellTerrell: ELT Techniques Free Online Course starts Nov. 18th http:\/\/t.co\/gvFcBXqR6m #MOOC #ELTChat #ESL #ELLChat #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Shelly Sanchez",
        "screen_name" : "ShellTerrell",
        "indices" : [ 3, 16 ],
        "id_str" : "29655018",
        "id" : 29655018
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MOOC",
        "indices" : [ 92, 97 ]
      }, {
        "text" : "ELTChat",
        "indices" : [ 98, 106 ]
      }, {
        "text" : "ESL",
        "indices" : [ 107, 111 ]
      }, {
        "text" : "ELLChat",
        "indices" : [ 112, 120 ]
      }, {
        "text" : "TEFL",
        "indices" : [ 121, 126 ]
      }, {
        "text" : "IATEFL",
        "indices" : [ 127, 134 ]
      } ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/gvFcBXqR6m",
        "expanded_url" : "http:\/\/www.wiziq.com\/course\/35898-elt-techniques-listening-and-pronunciation",
        "display_url" : "wiziq.com\/course\/35898-e\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "395971504543772673",
    "text" : "RT @ShellTerrell: ELT Techniques Free Online Course starts Nov. 18th http:\/\/t.co\/gvFcBXqR6m #MOOC #ELTChat #ESL #ELLChat #TEFL #IATEFL",
    "id" : 395971504543772673,
    "created_at" : "2013-10-31 17:52:18 +0000",
    "user" : {
      "name" : "Russell Stannard",
      "screen_name" : "russell1955",
      "protected" : false,
      "id_str" : "14796284",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/740709795\/RussellELTons_normal.jpg",
      "id" : 14796284,
      "verified" : false
    }
  },
  "id" : 395982905148964864,
  "created_at" : "2013-10-31 18:37:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpus",
      "indices" : [ 55, 62 ]
    }, {
      "text" : "corpuslinguistics",
      "indices" : [ 92, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/GOsAbLQIp7",
      "expanded_url" : "https:\/\/plus.google.com\/104940199413423400545\/posts\/U7hRBF4m7QQ",
      "display_url" : "plus.google.com\/10494019941342\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395942009652801536",
  "text" : "DeepDict Lexifier - no not a porn name but interesting #corpus tool https:\/\/t.co\/GOsAbLQIp7 #corpuslinguistics",
  "id" : 395942009652801536,
  "created_at" : "2013-10-31 15:55:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "evanfrendo",
      "screen_name" : "evanfrendo",
      "indices" : [ 0, 11 ],
      "id_str" : "17589664",
      "id" : 17589664
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395860247677386752",
  "geo" : { },
  "id_str" : "395883671234048000",
  "in_reply_to_user_id" : 17589664,
  "text" : "@evanfrendo wow that's cool :) any recommended tutorials for doing that?",
  "id" : 395883671234048000,
  "in_reply_to_status_id" : 395860247677386752,
  "created_at" : "2013-10-31 12:03:17 +0000",
  "in_reply_to_screen_name" : "evanfrendo",
  "in_reply_to_user_id_str" : "17589664",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395809214615941121",
  "geo" : { },
  "id_str" : "395838296016060416",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin 100 not out! (a cricketing term) congrats :)",
  "id" : 395838296016060416,
  "in_reply_to_status_id" : 395809214615941121,
  "created_at" : "2013-10-31 09:02:58 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "evanfrendo",
      "screen_name" : "evanfrendo",
      "indices" : [ 0, 11 ],
      "id_str" : "17589664",
      "id" : 17589664
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395812406703570945",
  "geo" : { },
  "id_str" : "395827026021457920",
  "in_reply_to_user_id" : 17589664,
  "text" : "@evanfrendo nice vid, did u commission the drawings?",
  "id" : 395827026021457920,
  "in_reply_to_status_id" : 395812406703570945,
  "created_at" : "2013-10-31 08:18:11 +0000",
  "in_reply_to_screen_name" : "evanfrendo",
  "in_reply_to_user_id_str" : "17589664",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristopher Boulton",
      "screen_name" : "Kris_Boulton",
      "indices" : [ 82, 95 ],
      "id_str" : "174736204",
      "id" : 174736204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/xwdSj6sutf",
      "expanded_url" : "http:\/\/wp.me\/p3sTtE-45",
      "display_url" : "wp.me\/p3sTtE-45"
    } ]
  },
  "geo" : { },
  "id_str" : "395587359917342720",
  "text" : "Does memorisation get in the way of learning? \u2013 Part 3 http:\/\/t.co\/xwdSj6sutf via @Kris_Boulton",
  "id" : 395587359917342720,
  "created_at" : "2013-10-30 16:25:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 12, 20 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395555005312561152",
  "geo" : { },
  "id_str" : "395555765525573632",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan @twitter no, if u want to see images go use facebook, instagram etc :), twitter needs to keep its lexical focus :)",
  "id" : 395555765525573632,
  "in_reply_to_status_id" : 395555005312561152,
  "created_at" : "2013-10-30 14:20:18 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 1, 9 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395551866697678848",
  "text" : ".@twitter please include image preview settings in desktop version",
  "id" : 395551866697678848,
  "created_at" : "2013-10-30 14:04:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/JUYhhLAeTz",
      "expanded_url" : "http:\/\/www.commondreams.org\/headline\/2013\/10\/29-3",
      "display_url" : "commondreams.org\/headline\/2013\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395548182697897985",
  "text" : "\"I no longer love blue skies. In fact, I now prefer grey skies. Drones don't fly when sky is grey,\" http:\/\/t.co\/JUYhhLAeTz",
  "id" : 395548182697897985,
  "created_at" : "2013-10-30 13:50:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Hawksey",
      "screen_name" : "mhawksey",
      "indices" : [ 3, 12 ],
      "id_str" : "13046992",
      "id" : 13046992
    }, {
      "name" : "Uldis Bojars",
      "screen_name" : "CaptSolo",
      "indices" : [ 73, 82 ],
      "id_str" : "1111871",
      "id" : 1111871
    }, {
      "name" : "Tim McCormick",
      "screen_name" : "tmccormick",
      "indices" : [ 109, 120 ],
      "id_str" : "21759817",
      "id" : 21759817
    }, {
      "name" : "Ernesto Priego",
      "screen_name" : "ernestopriego",
      "indices" : [ 121, 135 ],
      "id_str" : "18059285",
      "id" : 18059285
    }, {
      "name" : "Mark Sample",
      "screen_name" : "samplereality",
      "indices" : [ 136, 140 ],
      "id_str" : "8497292",
      "id" : 8497292
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/aKvsGLV2Vf",
      "expanded_url" : "http:\/\/mashe.hawksey.info\/2013\/02\/twitter-archive-tagsv5\/",
      "display_url" : "mashe.hawksey.info\/2013\/02\/twitte\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395510451658039296",
  "text" : "RT @mhawksey: Spread the word TAGS v5.1 is out to fix bug highlighted by @CaptSolo http:\/\/t.co\/aKvsGLV2Vf cc @tmccormick @ernestopriego @sa\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Uldis Bojars",
        "screen_name" : "CaptSolo",
        "indices" : [ 59, 68 ],
        "id_str" : "1111871",
        "id" : 1111871
      }, {
        "name" : "Tim McCormick",
        "screen_name" : "tmccormick",
        "indices" : [ 95, 106 ],
        "id_str" : "21759817",
        "id" : 21759817
      }, {
        "name" : "Ernesto Priego",
        "screen_name" : "ernestopriego",
        "indices" : [ 107, 121 ],
        "id_str" : "18059285",
        "id" : 18059285
      }, {
        "name" : "Mark Sample",
        "screen_name" : "samplereality",
        "indices" : [ 122, 136 ],
        "id_str" : "8497292",
        "id" : 8497292
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/aKvsGLV2Vf",
        "expanded_url" : "http:\/\/mashe.hawksey.info\/2013\/02\/twitter-archive-tagsv5\/",
        "display_url" : "mashe.hawksey.info\/2013\/02\/twitte\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "395502877399330816",
    "text" : "Spread the word TAGS v5.1 is out to fix bug highlighted by @CaptSolo http:\/\/t.co\/aKvsGLV2Vf cc @tmccormick @ernestopriego @samplereality",
    "id" : 395502877399330816,
    "created_at" : "2013-10-30 10:50:08 +0000",
    "user" : {
      "name" : "Martin Hawksey",
      "screen_name" : "mhawksey",
      "protected" : false,
      "id_str" : "13046992",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2390851993\/xu6aptqy6a8rb2h2w5by_normal.jpeg",
      "id" : 13046992,
      "verified" : false
    }
  },
  "id" : 395510451658039296,
  "created_at" : "2013-10-30 11:20:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 140 ],
      "url" : "http:\/\/t.co\/vhYseUMQ4q",
      "expanded_url" : "http:\/\/www.informationisbeautifulawards.com\/2013-shortlist\/data-visualization\/",
      "display_url" : "informationisbeautifulawards.com\/2013-shortlist\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395494238722752512",
  "text" : "RT @johnwhilley: Please consider voting for Melanie Patrick's brilliant and important infographic, Gross Miscalculation. http:\/\/t.co\/vhYseU\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/vhYseUMQ4q",
        "expanded_url" : "http:\/\/www.informationisbeautifulawards.com\/2013-shortlist\/data-visualization\/",
        "display_url" : "informationisbeautifulawards.com\/2013-shortlist\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "395484457399894017",
    "text" : "Please consider voting for Melanie Patrick's brilliant and important infographic, Gross Miscalculation. http:\/\/t.co\/vhYseUMQ4q",
    "id" : 395484457399894017,
    "created_at" : "2013-10-30 09:36:57 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 395494238722752512,
  "created_at" : "2013-10-30 10:15:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 3, 17 ],
      "id_str" : "25388528",
      "id" : 25388528
    }, {
      "name" : "Roberto Greco",
      "screen_name" : "rogre",
      "indices" : [ 112, 118 ],
      "id_str" : "31337253",
      "id" : 31337253
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/YwDFnK4BA1",
      "expanded_url" : "http:\/\/bat-bean-beam.blogspot.com\/2013\/10\/sixteen-tales-of-information-technology.html",
      "display_url" : "bat-bean-beam.blogspot.com\/2013\/10\/sixtee\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395320222280081408",
  "text" : "RT @audreywatters: Sixteen tales of information technology in education, 1991-2013  http:\/\/t.co\/YwDFnK4BA1 (h\/t @rogre)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Roberto Greco",
        "screen_name" : "rogre",
        "indices" : [ 93, 99 ],
        "id_str" : "31337253",
        "id" : 31337253
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/YwDFnK4BA1",
        "expanded_url" : "http:\/\/bat-bean-beam.blogspot.com\/2013\/10\/sixteen-tales-of-information-technology.html",
        "display_url" : "bat-bean-beam.blogspot.com\/2013\/10\/sixtee\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "395311311145275392",
    "text" : "Sixteen tales of information technology in education, 1991-2013  http:\/\/t.co\/YwDFnK4BA1 (h\/t @rogre)",
    "id" : 395311311145275392,
    "created_at" : "2013-10-29 22:08:55 +0000",
    "user" : {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "protected" : false,
      "id_str" : "25388528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711668009723498496\/pauFZsdv_normal.jpg",
      "id" : 25388528,
      "verified" : false
    }
  },
  "id" : 395320222280081408,
  "created_at" : "2013-10-29 22:44:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/M85JCo76pm",
      "expanded_url" : "http:\/\/tinyurl.com\/ogvxc3e",
      "display_url" : "tinyurl.com\/ogvxc3e"
    } ]
  },
  "geo" : { },
  "id_str" : "395267668221378560",
  "text" : "RT @medialens: Naomi Klein: 'How science is telling us all to revolt' http:\/\/t.co\/M85JCo76pm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/M85JCo76pm",
        "expanded_url" : "http:\/\/tinyurl.com\/ogvxc3e",
        "display_url" : "tinyurl.com\/ogvxc3e"
      } ]
    },
    "geo" : { },
    "id_str" : "395175651671433216",
    "text" : "Naomi Klein: 'How science is telling us all to revolt' http:\/\/t.co\/M85JCo76pm",
    "id" : 395175651671433216,
    "created_at" : "2013-10-29 13:09:52 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 395267668221378560,
  "created_at" : "2013-10-29 19:15:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angus B Grieve-Smith",
      "screen_name" : "grvsmth",
      "indices" : [ 0, 8 ],
      "id_str" : "22381639",
      "id" : 22381639
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395019565941272580",
  "geo" : { },
  "id_str" : "395196604908445696",
  "in_reply_to_user_id" : 22381639,
  "text" : "@grvsmth the post or teaching and learning english in general?",
  "id" : 395196604908445696,
  "in_reply_to_status_id" : 395019565941272580,
  "created_at" : "2013-10-29 14:33:07 +0000",
  "in_reply_to_screen_name" : "grvsmth",
  "in_reply_to_user_id_str" : "22381639",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/B10CIxjNmg",
      "expanded_url" : "http:\/\/linguafrankly.blogspot.com\/2013\/10\/the-word-is-not-basic-unit-of-language.html?spref=tw",
      "display_url" : "linguafrankly.blogspot.com\/2013\/10\/the-wo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394956225701351424",
  "text" : "Lingua Frankly: The word is not the basic unit of language. http:\/\/t.co\/B10CIxjNmg",
  "id" : 394956225701351424,
  "created_at" : "2013-10-28 22:37:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/ENzlUd9PfV",
      "expanded_url" : "http:\/\/engineeringasaforeignlanguage.blogspot.com\/2013\/10\/history-of-information.html?spref=tw",
      "display_url" : "\u2026eeringasaforeignlanguage.blogspot.com\/2013\/10\/histor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394954261278105601",
  "text" : "Teaching English to Engineers: History of information http:\/\/t.co\/ENzlUd9PfV",
  "id" : 394954261278105601,
  "created_at" : "2013-10-28 22:30:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Billington",
      "screen_name" : "firstshowing",
      "indices" : [ 93, 106 ],
      "id_str" : "7581972",
      "id" : 7581972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/GEch66nCJa",
      "expanded_url" : "http:\/\/www.firstshowing.net\/2013\/watch-first-trailer-for-michel-gondrys-noam-chomsky-documentary\/",
      "display_url" : "firstshowing.net\/2013\/watch-fir\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394942321600393216",
  "text" : "Watch: First Trailer for Michel Gondry's Noam Chomsky Documentary http:\/\/t.co\/GEch66nCJa via @firstshowing",
  "id" : 394942321600393216,
  "created_at" : "2013-10-28 21:42:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darius Kazemi",
      "screen_name" : "tinysubversions",
      "indices" : [ 68, 84 ],
      "id_str" : "14475298",
      "id" : 14475298
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/2mh7IBUSCK",
      "expanded_url" : "http:\/\/tinysubversions.com\/least\/",
      "display_url" : "tinysubversions.com\/least\/"
    } ]
  },
  "geo" : { },
  "id_str" : "394887383700606976",
  "text" : "The three least powerful women in gaming http:\/\/t.co\/2mh7IBUSCK via @tinysubversions",
  "id" : 394887383700606976,
  "created_at" : "2013-10-28 18:04:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "4TUNE Teller App",
      "screen_name" : "4tunetellernet",
      "indices" : [ 0, 15 ],
      "id_str" : "467634146",
      "id" : 467634146
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cassermescouilles",
      "indices" : [ 16, 34 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394855528943214592",
  "geo" : { },
  "id_str" : "394858124294627329",
  "in_reply_to_user_id" : 467634146,
  "text" : "@4tunetellernet #cassermescouilles may often co-occur with said loud noise :)",
  "id" : 394858124294627329,
  "in_reply_to_status_id" : 394855528943214592,
  "created_at" : "2013-10-28 16:08:07 +0000",
  "in_reply_to_screen_name" : "4tunetellernet",
  "in_reply_to_user_id_str" : "467634146",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Forbes",
      "screen_name" : "GenkiSarah",
      "indices" : [ 3, 14 ],
      "id_str" : "586340658",
      "id" : 586340658
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/c12INsfSyH",
      "expanded_url" : "http:\/\/sarahatktc.weebly.com\/1\/post\/2013\/10\/jalt-2013-learning-is-a-lifelong-voyage-in-kobe.html",
      "display_url" : "sarahatktc.weebly.com\/1\/post\/2013\/10\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394758249507205120",
  "text" : "RT @GenkiSarah: JALT 2013 \"Learning is a Lifelong Voyage\" in Kobe http:\/\/t.co\/c12INsfSyH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.weebly.com\/\" rel=\"nofollow\"\u003EWeebly App\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 72 ],
        "url" : "http:\/\/t.co\/c12INsfSyH",
        "expanded_url" : "http:\/\/sarahatktc.weebly.com\/1\/post\/2013\/10\/jalt-2013-learning-is-a-lifelong-voyage-in-kobe.html",
        "display_url" : "sarahatktc.weebly.com\/1\/post\/2013\/10\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "394757391935229952",
    "text" : "JALT 2013 \"Learning is a Lifelong Voyage\" in Kobe http:\/\/t.co\/c12INsfSyH",
    "id" : 394757391935229952,
    "created_at" : "2013-10-28 09:27:51 +0000",
    "user" : {
      "name" : "Sarah Forbes",
      "screen_name" : "GenkiSarah",
      "protected" : false,
      "id_str" : "586340658",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2237023794\/DSCF5375_normal.JPG",
      "id" : 586340658,
      "verified" : false
    }
  },
  "id" : 394758249507205120,
  "created_at" : "2013-10-28 09:31:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike S. Boyle",
      "screen_name" : "heyboyle",
      "indices" : [ 0, 9 ],
      "id_str" : "612840231",
      "id" : 612840231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394599993257910272",
  "geo" : { },
  "id_str" : "394757870685679616",
  "in_reply_to_user_id" : 612840231,
  "text" : "@heyboyle great :)",
  "id" : 394757870685679616,
  "in_reply_to_status_id" : 394599993257910272,
  "created_at" : "2013-10-28 09:29:45 +0000",
  "in_reply_to_screen_name" : "heyboyle",
  "in_reply_to_user_id_str" : "612840231",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adi Rajan",
      "screen_name" : "adi_rajan",
      "indices" : [ 0, 10 ],
      "id_str" : "1011323449",
      "id" : 1011323449
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/gnEFqIwmh8",
      "expanded_url" : "https:\/\/plus.google.com\/u\/0\/communities\/101266284417587206243",
      "display_url" : "plus.google.com\/u\/0\/communitie\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394757821020917760",
  "in_reply_to_user_id" : 1011323449,
  "text" : "@adi_rajan hi for more corpus stuff why not join g+ comm https:\/\/t.co\/gnEFqIwmh8 :)",
  "id" : 394757821020917760,
  "created_at" : "2013-10-28 09:29:33 +0000",
  "in_reply_to_screen_name" : "adi_rajan",
  "in_reply_to_user_id_str" : "1011323449",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Brown",
      "screen_name" : "sbrowntweets",
      "indices" : [ 3, 16 ],
      "id_str" : "885343459",
      "id" : 885343459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/rLSCrllzUs",
      "expanded_url" : "http:\/\/stevebrown70.wordpress.com\/2013\/10\/27\/best-praxis\/",
      "display_url" : "stevebrown70.wordpress.com\/2013\/10\/27\/bes\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394598347551809537",
  "text" : "RT @sbrowntweets: New post, on something we don't value in our profession but should: http:\/\/t.co\/rLSCrllzUs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/rLSCrllzUs",
        "expanded_url" : "http:\/\/stevebrown70.wordpress.com\/2013\/10\/27\/best-praxis\/",
        "display_url" : "stevebrown70.wordpress.com\/2013\/10\/27\/bes\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "394581150619815936",
    "text" : "New post, on something we don't value in our profession but should: http:\/\/t.co\/rLSCrllzUs",
    "id" : 394581150619815936,
    "created_at" : "2013-10-27 21:47:31 +0000",
    "user" : {
      "name" : "Steve Brown",
      "screen_name" : "sbrowntweets",
      "protected" : false,
      "id_str" : "885343459",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746292888405934080\/tp1_ccBF_normal.jpg",
      "id" : 885343459,
      "verified" : false
    }
  },
  "id" : 394598347551809537,
  "created_at" : "2013-10-27 22:55:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stevemuir",
      "screen_name" : "steve_muir",
      "indices" : [ 3, 14 ],
      "id_str" : "18537988",
      "id" : 18537988
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "foodissuesmonth",
      "indices" : [ 107, 123 ]
    }, {
      "text" : "GISIG",
      "indices" : [ 124, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/FOmQgzO2WH",
      "expanded_url" : "http:\/\/bit.ly\/HnGUz6",
      "display_url" : "bit.ly\/HnGUz6"
    } ]
  },
  "geo" : { },
  "id_str" : "394597419939549184",
  "text" : "RT @steve_muir: Hong Kong Honey: a lesson about Hong Kong's 1st urban beekeeper http:\/\/t.co\/FOmQgzO2WH\nfor #foodissuesmonth #GISIG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "foodissuesmonth",
        "indices" : [ 91, 107 ]
      }, {
        "text" : "GISIG",
        "indices" : [ 108, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/FOmQgzO2WH",
        "expanded_url" : "http:\/\/bit.ly\/HnGUz6",
        "display_url" : "bit.ly\/HnGUz6"
      } ]
    },
    "geo" : { },
    "id_str" : "394594201117024257",
    "text" : "Hong Kong Honey: a lesson about Hong Kong's 1st urban beekeeper http:\/\/t.co\/FOmQgzO2WH\nfor #foodissuesmonth #GISIG",
    "id" : 394594201117024257,
    "created_at" : "2013-10-27 22:39:23 +0000",
    "user" : {
      "name" : "stevemuir",
      "screen_name" : "steve_muir",
      "protected" : false,
      "id_str" : "18537988",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/553249343197949952\/dlZ2X6EP_normal.jpeg",
      "id" : 18537988,
      "verified" : false
    }
  },
  "id" : 394597419939549184,
  "created_at" : "2013-10-27 22:52:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Motherboard",
      "screen_name" : "motherboard",
      "indices" : [ 3, 15 ],
      "id_str" : "56510427",
      "id" : 56510427
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WoundsOfWaziristan",
      "indices" : [ 23, 42 ]
    } ],
    "urls" : [ {
      "indices" : [ 122, 140 ],
      "url" : "http:\/\/t.co\/MGS99OvZiX",
      "expanded_url" : "http:\/\/goo.gl\/UtiI1B",
      "display_url" : "goo.gl\/UtiI1B"
    } ]
  },
  "geo" : { },
  "id_str" : "394501246499176448",
  "text" : "RT @motherboard: Watch #WoundsOfWaziristan, a new short film about drones from the POV of the people who live under them: http:\/\/t.co\/MGS99\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WoundsOfWaziristan",
        "indices" : [ 6, 25 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/MGS99OvZiX",
        "expanded_url" : "http:\/\/goo.gl\/UtiI1B",
        "display_url" : "goo.gl\/UtiI1B"
      } ]
    },
    "geo" : { },
    "id_str" : "393777226908311552",
    "text" : "Watch #WoundsOfWaziristan, a new short film about drones from the POV of the people who live under them: http:\/\/t.co\/MGS99OvZiX",
    "id" : 393777226908311552,
    "created_at" : "2013-10-25 16:33:01 +0000",
    "user" : {
      "name" : "Motherboard",
      "screen_name" : "motherboard",
      "protected" : false,
      "id_str" : "56510427",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/671996520372166659\/K4kfOJw-_normal.jpg",
      "id" : 56510427,
      "verified" : true
    }
  },
  "id" : 394501246499176448,
  "created_at" : "2013-10-27 16:30:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darius Kazemi",
      "screen_name" : "tinysubversions",
      "indices" : [ 3, 19 ],
      "id_str" : "14475298",
      "id" : 14475298
    }, {
      "name" : "AutoVids",
      "screen_name" : "AutoVids",
      "indices" : [ 122, 131 ],
      "id_str" : "2157584160",
      "id" : 2157584160
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cat",
      "indices" : [ 133, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/ZdDVCuGR3Q",
      "expanded_url" : "http:\/\/bit.ly\/16D2uW6",
      "display_url" : "bit.ly\/16D2uW6"
    } ]
  },
  "geo" : { },
  "id_str" : "394496706093805568",
  "text" : "RT @tinysubversions: I just built a bot that makes music videos from Vine and CCMixter, then posts to Twitter\/YouTube. RT @AutoVids: #cat: \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "AutoVids",
        "screen_name" : "AutoVids",
        "indices" : [ 101, 110 ],
        "id_str" : "2157584160",
        "id" : 2157584160
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "cat",
        "indices" : [ 112, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/ZdDVCuGR3Q",
        "expanded_url" : "http:\/\/bit.ly\/16D2uW6",
        "display_url" : "bit.ly\/16D2uW6"
      } ]
    },
    "geo" : { },
    "id_str" : "394221692475953152",
    "text" : "I just built a bot that makes music videos from Vine and CCMixter, then posts to Twitter\/YouTube. RT @AutoVids: #cat: http:\/\/t.co\/ZdDVCuGR3Q",
    "id" : 394221692475953152,
    "created_at" : "2013-10-26 21:59:10 +0000",
    "user" : {
      "name" : "Darius Kazemi",
      "screen_name" : "tinysubversions",
      "protected" : false,
      "id_str" : "14475298",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723889712772059136\/4T8a46Sp_normal.jpg",
      "id" : 14475298,
      "verified" : false
    }
  },
  "id" : 394496706093805568,
  "created_at" : "2013-10-27 16:11:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oliver Mason",
      "screen_name" : "ojmason",
      "indices" : [ 3, 11 ],
      "id_str" : "19781877",
      "id" : 19781877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/Hgp6kHfMAJ",
      "expanded_url" : "http:\/\/youtu.be\/lIaXSBSQ0W0",
      "display_url" : "youtu.be\/lIaXSBSQ0W0"
    } ]
  },
  "geo" : { },
  "id_str" : "394459536876376064",
  "text" : "RT @ojmason: Funniest for techies. \"My Blackberry is not working\" http:\/\/t.co\/Hgp6kHfMAJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 75 ],
        "url" : "http:\/\/t.co\/Hgp6kHfMAJ",
        "expanded_url" : "http:\/\/youtu.be\/lIaXSBSQ0W0",
        "display_url" : "youtu.be\/lIaXSBSQ0W0"
      } ]
    },
    "geo" : { },
    "id_str" : "394429932212092929",
    "text" : "Funniest for techies. \"My Blackberry is not working\" http:\/\/t.co\/Hgp6kHfMAJ",
    "id" : 394429932212092929,
    "created_at" : "2013-10-27 11:46:38 +0000",
    "user" : {
      "name" : "Oliver Mason",
      "screen_name" : "ojmason",
      "protected" : false,
      "id_str" : "19781877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/74227368\/Photo_30_normal.jpg",
      "id" : 19781877,
      "verified" : false
    }
  },
  "id" : 394459536876376064,
  "created_at" : "2013-10-27 13:44:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394444578930950144",
  "geo" : { },
  "id_str" : "394445355510554624",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan try firefox, not sure why not working in chrome?",
  "id" : 394445355510554624,
  "in_reply_to_status_id" : 394444578930950144,
  "created_at" : "2013-10-27 12:47:55 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394444234956083200",
  "geo" : { },
  "id_str" : "394444392674504704",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan what browser r u using?",
  "id" : 394444392674504704,
  "in_reply_to_status_id" : 394444234956083200,
  "created_at" : "2013-10-27 12:44:06 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 7, 18 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "Peter Kittle",
      "screen_name" : "pkittle",
      "indices" : [ 66, 74 ],
      "id_str" : "11322822",
      "id" : 11322822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/FQW9hZkVaj",
      "expanded_url" : "https:\/\/elt.makes.org\/thimble\/dave-willis-",
      "display_url" : "elt.makes.org\/thimble\/dave-w\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "394443033627746304",
  "geo" : { },
  "id_str" : "394443297034235904",
  "in_reply_to_user_id" : 408365496,
  "text" : "hi leo @leoselivan you might like this https:\/\/t.co\/FQW9hZkVaj ht @pkittle",
  "id" : 394443297034235904,
  "in_reply_to_status_id" : 394443033627746304,
  "created_at" : "2013-10-27 12:39:45 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaunwilden",
      "screen_name" : "Shaunwilden",
      "indices" : [ 3, 15 ],
      "id_str" : "15350512",
      "id" : 15350512
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 42, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/YJObzNKPKr",
      "expanded_url" : "http:\/\/bit.ly\/HmXU8F",
      "display_url" : "bit.ly\/HmXU8F"
    } ]
  },
  "geo" : { },
  "id_str" : "394407655600836608",
  "text" : "RT @Shaunwilden: Join us on Wednesday for #eltchat on  Task Based Learning, Lexical Syllabuses, the Lexical Approach  http:\/\/t.co\/YJObzNKPKr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "eltchat",
        "indices" : [ 25, 33 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/YJObzNKPKr",
        "expanded_url" : "http:\/\/bit.ly\/HmXU8F",
        "display_url" : "bit.ly\/HmXU8F"
      } ]
    },
    "geo" : { },
    "id_str" : "394402991182057473",
    "text" : "Join us on Wednesday for #eltchat on  Task Based Learning, Lexical Syllabuses, the Lexical Approach  http:\/\/t.co\/YJObzNKPKr",
    "id" : 394402991182057473,
    "created_at" : "2013-10-27 09:59:35 +0000",
    "user" : {
      "name" : "Shaunwilden",
      "screen_name" : "Shaunwilden",
      "protected" : false,
      "id_str" : "15350512",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/443867028005212160\/pvFEA7Px_normal.jpeg",
      "id" : 15350512,
      "verified" : false
    }
  },
  "id" : 394407655600836608,
  "created_at" : "2013-10-27 10:18:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/lyaVrc8hDv",
      "expanded_url" : "http:\/\/www.mundolingua.org\/",
      "display_url" : "mundolingua.org"
    } ]
  },
  "in_reply_to_status_id_str" : "394401524001951744",
  "geo" : { },
  "id_str" : "394406269722697728",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan for @tesolfr 2013 sure :) also new linguistics museum to check when u visit - http:\/\/t.co\/lyaVrc8hDv not been yet myself",
  "id" : 394406269722697728,
  "in_reply_to_status_id" : 394401524001951744,
  "created_at" : "2013-10-27 10:12:37 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394167830498652160",
  "geo" : { },
  "id_str" : "394368023600967680",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan v nice tribute post leo",
  "id" : 394368023600967680,
  "in_reply_to_status_id" : 394167830498652160,
  "created_at" : "2013-10-27 07:40:38 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sophia Khan",
      "screen_name" : "SophiaKhan4",
      "indices" : [ 0, 12 ],
      "id_str" : "351390617",
      "id" : 351390617
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394212597290913792",
  "geo" : { },
  "id_str" : "394364604538576896",
  "in_reply_to_user_id" : 351390617,
  "text" : "@SophiaKhan4 that's right :); though saying is originally  from UK politician George Gallowa; was the debate any good?",
  "id" : 394364604538576896,
  "in_reply_to_status_id" : 394212597290913792,
  "created_at" : "2013-10-27 07:27:03 +0000",
  "in_reply_to_screen_name" : "SophiaKhan4",
  "in_reply_to_user_id_str" : "351390617",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 3, 14 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 69, 73 ]
    }, {
      "text" : "tefl",
      "indices" : [ 74, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/5m0hwXeUyf",
      "expanded_url" : "http:\/\/leoxicon.blogspot.com\/2013\/10\/dave-willis-lexical-syllabus_4913.html",
      "display_url" : "leoxicon.blogspot.com\/2013\/10\/dave-w\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394142034979983360",
  "text" : "RT @leoselivan: In honour of Dave Willis RIP http:\/\/t.co\/5m0hwXeUyf  #elt #tefl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "elt",
        "indices" : [ 53, 57 ]
      }, {
        "text" : "tefl",
        "indices" : [ 58, 63 ]
      } ],
      "urls" : [ {
        "indices" : [ 29, 51 ],
        "url" : "http:\/\/t.co\/5m0hwXeUyf",
        "expanded_url" : "http:\/\/leoxicon.blogspot.com\/2013\/10\/dave-willis-lexical-syllabus_4913.html",
        "display_url" : "leoxicon.blogspot.com\/2013\/10\/dave-w\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "394139285135179777",
    "text" : "In honour of Dave Willis RIP http:\/\/t.co\/5m0hwXeUyf  #elt #tefl",
    "id" : 394139285135179777,
    "created_at" : "2013-10-26 16:31:42 +0000",
    "user" : {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "protected" : false,
      "id_str" : "408365496",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/460546508601819136\/12ivDBb__normal.jpeg",
      "id" : 408365496,
      "verified" : false
    }
  },
  "id" : 394142034979983360,
  "created_at" : "2013-10-26 16:42:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike S. Boyle",
      "screen_name" : "heyboyle",
      "indices" : [ 0, 9 ],
      "id_str" : "612840231",
      "id" : 612840231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/gnEFqIwmh8",
      "expanded_url" : "https:\/\/plus.google.com\/u\/0\/communities\/101266284417587206243",
      "display_url" : "plus.google.com\/u\/0\/communitie\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394127158487953408",
  "in_reply_to_user_id" : 612840231,
  "text" : "@heyboyle hi for more corpus stuff why not join g+ community https:\/\/t.co\/gnEFqIwmh8 :)",
  "id" : 394127158487953408,
  "created_at" : "2013-10-26 15:43:31 +0000",
  "in_reply_to_screen_name" : "heyboyle",
  "in_reply_to_user_id_str" : "612840231",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sophia Khan",
      "screen_name" : "SophiaKhan4",
      "indices" : [ 0, 12 ],
      "id_str" : "351390617",
      "id" : 351390617
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "393719509472645120",
  "geo" : { },
  "id_str" : "394125917737320448",
  "in_reply_to_user_id" : 351390617,
  "text" : "@SophiaKhan4 yikes talk about two cheeks of the same bum :)",
  "id" : 394125917737320448,
  "in_reply_to_status_id" : 393719509472645120,
  "created_at" : "2013-10-26 15:38:35 +0000",
  "in_reply_to_screen_name" : "SophiaKhan4",
  "in_reply_to_user_id_str" : "351390617",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iwona",
      "screen_name" : "yvetteinmb",
      "indices" : [ 0, 11 ],
      "id_str" : "90695737",
      "id" : 90695737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/gnEFqIwmh8",
      "expanded_url" : "https:\/\/plus.google.com\/u\/0\/communities\/101266284417587206243",
      "display_url" : "plus.google.com\/u\/0\/communitie\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "394039011037036545",
  "geo" : { },
  "id_str" : "394056494011797504",
  "in_reply_to_user_id" : 90695737,
  "text" : "@yvetteinmb hi for more corpus stuff why not join g+ comm - https:\/\/t.co\/gnEFqIwmh8 :)",
  "id" : 394056494011797504,
  "in_reply_to_status_id" : 394039011037036545,
  "created_at" : "2013-10-26 11:02:44 +0000",
  "in_reply_to_screen_name" : "yvetteinmb",
  "in_reply_to_user_id_str" : "90695737",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Natallia Novikava",
      "screen_name" : "Natashetta",
      "indices" : [ 0, 11 ],
      "id_str" : "56308635",
      "id" : 56308635
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394029000202256384",
  "geo" : { },
  "id_str" : "394031860742770688",
  "in_reply_to_user_id" : 56308635,
  "text" : "@Natashetta great :)",
  "id" : 394031860742770688,
  "in_reply_to_status_id" : 394029000202256384,
  "created_at" : "2013-10-26 09:24:51 +0000",
  "in_reply_to_screen_name" : "Natashetta",
  "in_reply_to_user_id_str" : "56308635",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394028946712719360",
  "geo" : { },
  "id_str" : "394030190940024833",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco thanks; have u used openinsight, ep visualiser?",
  "id" : 394030190940024833,
  "in_reply_to_status_id" : 394028946712719360,
  "created_at" : "2013-10-26 09:18:12 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394026018937520128",
  "geo" : { },
  "id_str" : "394026658128080896",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco hi, yes very nice; do you know any concordancers for xml apart from xaira? (for mac?)",
  "id" : 394026658128080896,
  "in_reply_to_status_id" : 394026018937520128,
  "created_at" : "2013-10-26 09:04:10 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Natallia Novikava",
      "screen_name" : "Natashetta",
      "indices" : [ 0, 11 ],
      "id_str" : "56308635",
      "id" : 56308635
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/gnEFqIwmh8",
      "expanded_url" : "https:\/\/plus.google.com\/u\/0\/communities\/101266284417587206243",
      "display_url" : "plus.google.com\/u\/0\/communitie\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394025289224708096",
  "in_reply_to_user_id" : 56308635,
  "text" : "@Natashetta hi natallia for more corpus stuff why not join g+ comm https:\/\/t.co\/gnEFqIwmh8 :)",
  "id" : 394025289224708096,
  "created_at" : "2013-10-26 08:58:44 +0000",
  "in_reply_to_screen_name" : "Natashetta",
  "in_reply_to_user_id_str" : "56308635",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpuslinguistics",
      "indices" : [ 61, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/4ZyYgbqgO3",
      "expanded_url" : "http:\/\/ilexir.co.uk\/applications\/clc-fce-dataset\/",
      "display_url" : "ilexir.co.uk\/applications\/c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394022232428535808",
  "text" : "Free learner corpus dataset - CLC FCE http:\/\/t.co\/4ZyYgbqgO3 #corpuslinguistics",
  "id" : 394022232428535808,
  "created_at" : "2013-10-26 08:46:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barrie England",
      "screen_name" : "Baralbion",
      "indices" : [ 52, 62 ],
      "id_str" : "793527",
      "id" : 793527
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/Mc6mKDLDdC",
      "expanded_url" : "http:\/\/wp.me\/p3eMQN-VB",
      "display_url" : "wp.me\/p3eMQN-VB"
    } ]
  },
  "geo" : { },
  "id_str" : "393822627317293056",
  "text" : "Good Old World War One   http:\/\/t.co\/Mc6mKDLDdC via @Baralbion",
  "id" : 393822627317293056,
  "created_at" : "2013-10-25 19:33:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike S. Boyle",
      "screen_name" : "heyboyle",
      "indices" : [ 0, 9 ],
      "id_str" : "612840231",
      "id" : 612840231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "393773520892592128",
  "geo" : { },
  "id_str" : "393787878813077504",
  "in_reply_to_user_id" : 612840231,
  "text" : "@heyboyle thxs for great talk :)",
  "id" : 393787878813077504,
  "in_reply_to_status_id" : 393773520892592128,
  "created_at" : "2013-10-25 17:15:21 +0000",
  "in_reply_to_screen_name" : "heyboyle",
  "in_reply_to_user_id_str" : "612840231",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 0, 13 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "393785734760366082",
  "geo" : { },
  "id_str" : "393786954589798400",
  "in_reply_to_user_id" : 88655243,
  "text" : "@rosemerebard amazing post Rose :) lucky student!",
  "id" : 393786954589798400,
  "in_reply_to_status_id" : 393785734760366082,
  "created_at" : "2013-10-25 17:11:40 +0000",
  "in_reply_to_screen_name" : "rosemerebard",
  "in_reply_to_user_id_str" : "88655243",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 3, 16 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/Xzc77KgT8R",
      "expanded_url" : "http:\/\/wp.me\/pKFOt-kH",
      "display_url" : "wp.me\/pKFOt-kH"
    } ]
  },
  "geo" : { },
  "id_str" : "393786709965832192",
  "text" : "RT @rosemerebard: I had to write! A new blogpost. Opportunity and alternatives - What an experience I had! http:\/\/t.co\/Xzc77KgT8R",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/Xzc77KgT8R",
        "expanded_url" : "http:\/\/wp.me\/pKFOt-kH",
        "display_url" : "wp.me\/pKFOt-kH"
      } ]
    },
    "geo" : { },
    "id_str" : "393785734760366082",
    "text" : "I had to write! A new blogpost. Opportunity and alternatives - What an experience I had! http:\/\/t.co\/Xzc77KgT8R",
    "id" : 393785734760366082,
    "created_at" : "2013-10-25 17:06:50 +0000",
    "user" : {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "protected" : false,
      "id_str" : "88655243",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/706508144160145410\/pKzknb5H_normal.jpg",
      "id" : 88655243,
      "verified" : false
    }
  },
  "id" : 393786709965832192,
  "created_at" : "2013-10-25 17:10:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike S. Boyle",
      "screen_name" : "heyboyle",
      "indices" : [ 0, 9 ],
      "id_str" : "612840231",
      "id" : 612840231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "393751159170531328",
  "geo" : { },
  "id_str" : "393754749209571328",
  "in_reply_to_user_id" : 612840231,
  "text" : "@heyboyle wow 147 people and counting!",
  "id" : 393754749209571328,
  "in_reply_to_status_id" : 393751159170531328,
  "created_at" : "2013-10-25 15:03:42 +0000",
  "in_reply_to_screen_name" : "heyboyle",
  "in_reply_to_user_id_str" : "612840231",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pitchfork",
      "screen_name" : "pitchforkmedia",
      "indices" : [ 3, 18 ],
      "id_str" : "2707054218",
      "id" : 2707054218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/x4n3ojNBww",
      "expanded_url" : "http:\/\/p4k.in\/1eNTMtt",
      "display_url" : "p4k.in\/1eNTMtt"
    } ]
  },
  "geo" : { },
  "id_str" : "393705002201780224",
  "text" : "RT @pitchforkmedia: Stream Arcade Fire's new album Reflektor, via the world's longest lyric video http:\/\/t.co\/x4n3ojNBww",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/x4n3ojNBww",
        "expanded_url" : "http:\/\/p4k.in\/1eNTMtt",
        "display_url" : "p4k.in\/1eNTMtt"
      } ]
    },
    "geo" : { },
    "id_str" : "393468890392449024",
    "text" : "Stream Arcade Fire's new album Reflektor, via the world's longest lyric video http:\/\/t.co\/x4n3ojNBww",
    "id" : 393468890392449024,
    "created_at" : "2013-10-24 20:07:48 +0000",
    "user" : {
      "name" : "Pitchfork",
      "screen_name" : "pitchfork",
      "protected" : false,
      "id_str" : "14089195",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615703473678585856\/6DxJO5o0_normal.jpg",
      "id" : 14089195,
      "verified" : true
    }
  },
  "id" : 393705002201780224,
  "created_at" : "2013-10-25 11:46:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 76, 84 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/wxrtlcn0Hh",
      "expanded_url" : "http:\/\/youtu.be\/JKVyrSv5GwI",
      "display_url" : "youtu.be\/JKVyrSv5GwI"
    } ]
  },
  "geo" : { },
  "id_str" : "393501547054653440",
  "text" : "Noam Chomsky on \"Sandwiches and Twitter\" (2013): http:\/\/t.co\/wxrtlcn0Hh via @youtube",
  "id" : 393501547054653440,
  "created_at" : "2013-10-24 22:17:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/QeThFxNTyC",
      "expanded_url" : "http:\/\/wordandphrase.info",
      "display_url" : "wordandphrase.info"
    } ]
  },
  "in_reply_to_status_id_str" : "393466450427392000",
  "geo" : { },
  "id_str" : "393472351355944960",
  "in_reply_to_user_id" : 857732892,
  "text" : "http:\/\/t.co\/QeThFxNTyC showed me that core collocates with apple as a verb and not as a noun; counterintuitive ! @CELTtraining",
  "id" : 393472351355944960,
  "in_reply_to_status_id" : 393466450427392000,
  "created_at" : "2013-10-24 20:21:33 +0000",
  "in_reply_to_screen_name" : "LexicalLab",
  "in_reply_to_user_id_str" : "857732892",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "frequent",
      "indices" : [ 91, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/uSerK5Absq",
      "expanded_url" : "http:\/\/blog.westminster.ac.uk\/celt\/2013\/10\/23\/core\/",
      "display_url" : "blog.westminster.ac.uk\/celt\/2013\/10\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393469865945993216",
  "text" : "RT @CELTtraining: Core: blog post with links, discussion and video. http:\/\/t.co\/uSerK5Absq #frequent words",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "frequent",
        "indices" : [ 73, 82 ]
      } ],
      "urls" : [ {
        "indices" : [ 50, 72 ],
        "url" : "http:\/\/t.co\/uSerK5Absq",
        "expanded_url" : "http:\/\/blog.westminster.ac.uk\/celt\/2013\/10\/23\/core\/",
        "display_url" : "blog.westminster.ac.uk\/celt\/2013\/10\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "393466450427392000",
    "text" : "Core: blog post with links, discussion and video. http:\/\/t.co\/uSerK5Absq #frequent words",
    "id" : 393466450427392000,
    "created_at" : "2013-10-24 19:58:06 +0000",
    "user" : {
      "name" : "Lexical Lab",
      "screen_name" : "LexicalLab",
      "protected" : false,
      "id_str" : "857732892",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/559654844831506432\/F4HWliCf_normal.jpeg",
      "id" : 857732892,
      "verified" : false
    }
  },
  "id" : 393469865945993216,
  "created_at" : "2013-10-24 20:11:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 103, 119 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/vX1PNGq7Fx",
      "expanded_url" : "http:\/\/wp.me\/pjaNC-130",
      "display_url" : "wp.me\/pjaNC-130"
    } ]
  },
  "geo" : { },
  "id_str" : "393460414635208705",
  "text" : "Student Stumper 40: Does the verb BE always link a subject to a complement? http:\/\/t.co\/vX1PNGq7Fx via @wordpressdotcom",
  "id" : 393460414635208705,
  "created_at" : "2013-10-24 19:34:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Krashen",
      "screen_name" : "skrashen",
      "indices" : [ 3, 12 ],
      "id_str" : "25624708",
      "id" : 25624708
    }, {
      "name" : "Truthdig",
      "screen_name" : "Truthdig",
      "indices" : [ 115, 124 ],
      "id_str" : "15950681",
      "id" : 15950681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/ACXTp8fZeY",
      "expanded_url" : "http:\/\/www.truthdig.com\/report\/item\/lets_get_this_class_war_started_20131020\/#.UmVp0JK1BT4.twitter",
      "display_url" : "truthdig.com\/report\/item\/le\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393459378453774337",
  "text" : "RT @skrashen: Chris Hedges: Let\u2019s Get This Class War Started - Chris Hedges - Truthdig: http:\/\/t.co\/ACXTp8fZeY via @truthdig",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Truthdig",
        "screen_name" : "Truthdig",
        "indices" : [ 101, 110 ],
        "id_str" : "15950681",
        "id" : 15950681
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/ACXTp8fZeY",
        "expanded_url" : "http:\/\/www.truthdig.com\/report\/item\/lets_get_this_class_war_started_20131020\/#.UmVp0JK1BT4.twitter",
        "display_url" : "truthdig.com\/report\/item\/le\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "392347887964655616",
    "text" : "Chris Hedges: Let\u2019s Get This Class War Started - Chris Hedges - Truthdig: http:\/\/t.co\/ACXTp8fZeY via @truthdig",
    "id" : 392347887964655616,
    "created_at" : "2013-10-21 17:53:20 +0000",
    "user" : {
      "name" : "Stephen Krashen",
      "screen_name" : "skrashen",
      "protected" : false,
      "id_str" : "25624708",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/557399841769132032\/Ktp-bmWA_normal.jpeg",
      "id" : 25624708,
      "verified" : false
    }
  },
  "id" : 393459378453774337,
  "created_at" : "2013-10-24 19:30:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShareThis",
      "screen_name" : "ShareThis",
      "indices" : [ 72, 82 ],
      "id_str" : "14116807",
      "id" : 14116807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/PqfhcV5mpY",
      "expanded_url" : "http:\/\/shar.es\/I0SVj",
      "display_url" : "shar.es\/I0SVj"
    } ]
  },
  "geo" : { },
  "id_str" : "393335013392916480",
  "text" : "Media gatekeepers ruffled by Brand and co    http:\/\/t.co\/PqfhcV5mpY via @sharethis",
  "id" : 393335013392916480,
  "created_at" : "2013-10-24 11:15:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 71, 87 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/KVGCFmTCfO",
      "expanded_url" : "http:\/\/wp.me\/p2IyBp-iZ",
      "display_url" : "wp.me\/p2IyBp-iZ"
    } ]
  },
  "geo" : { },
  "id_str" : "393331318072688640",
  "text" : "(Dis)agreement scales and listening scripts http:\/\/t.co\/KVGCFmTCfO via @wordpressdotcom",
  "id" : 393331318072688640,
  "created_at" : "2013-10-24 11:01:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 3, 14 ],
      "id_str" : "282659955",
      "id" : 282659955
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 85, 93 ]
    }, {
      "text" : "iatefl",
      "indices" : [ 94, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/79rGCUB83M",
      "expanded_url" : "http:\/\/wp.me\/p2e2Wf-eR",
      "display_url" : "wp.me\/p2e2Wf-eR"
    } ]
  },
  "geo" : { },
  "id_str" : "393330436585578496",
  "text" : "RT @teflerinha: Food waste: a free downloadable lesson (for GISIG Food Issues month) #eltchat #iatefl http:\/\/t.co\/79rGCUB83M",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "eltchat",
        "indices" : [ 69, 77 ]
      }, {
        "text" : "iatefl",
        "indices" : [ 78, 85 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/79rGCUB83M",
        "expanded_url" : "http:\/\/wp.me\/p2e2Wf-eR",
        "display_url" : "wp.me\/p2e2Wf-eR"
      } ]
    },
    "geo" : { },
    "id_str" : "393324326902304768",
    "text" : "Food waste: a free downloadable lesson (for GISIG Food Issues month) #eltchat #iatefl http:\/\/t.co\/79rGCUB83M",
    "id" : 393324326902304768,
    "created_at" : "2013-10-24 10:33:21 +0000",
    "user" : {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "protected" : false,
      "id_str" : "282659955",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2149898907\/Rachael_Roberts_headshot_square_normal.jpg",
      "id" : 282659955,
      "verified" : false
    }
  },
  "id" : 393330436585578496,
  "created_at" : "2013-10-24 10:57:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Seymour",
      "screen_name" : "leninology",
      "indices" : [ 3, 14 ],
      "id_str" : "15557246",
      "id" : 15557246
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/bMAm7OaQW6",
      "expanded_url" : "http:\/\/www.buzzfeed.com\/tomphillips\/the-29-stages-of-a-twitterstorm",
      "display_url" : "buzzfeed.com\/tomphillips\/th\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393079058671878144",
  "text" : "RT @leninology: 29 stages of a Twitterstorm. http:\/\/t.co\/bMAm7OaQW6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 29, 51 ],
        "url" : "http:\/\/t.co\/bMAm7OaQW6",
        "expanded_url" : "http:\/\/www.buzzfeed.com\/tomphillips\/the-29-stages-of-a-twitterstorm",
        "display_url" : "buzzfeed.com\/tomphillips\/th\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "392972212770439168",
    "text" : "29 stages of a Twitterstorm. http:\/\/t.co\/bMAm7OaQW6",
    "id" : 392972212770439168,
    "created_at" : "2013-10-23 11:14:11 +0000",
    "user" : {
      "name" : "Richard Seymour",
      "screen_name" : "leninology",
      "protected" : false,
      "id_str" : "15557246",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762344914583781377\/UDn8tMrp_normal.jpg",
      "id" : 15557246,
      "verified" : false
    }
  },
  "id" : 393079058671878144,
  "created_at" : "2013-10-23 18:18:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/I6A1DoxvGb",
      "expanded_url" : "http:\/\/eflnotes.wordpress.com\/my-english-language-teacher\/",
      "display_url" : "eflnotes.wordpress.com\/my-english-lan\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392728310301483008",
  "text" : "La seule phrase que je comprends quand ma prof d'anglais parle c'est : L2 is not L1 !http:\/\/t.co\/I6A1DoxvGb",
  "id" : 392728310301483008,
  "created_at" : "2013-10-22 19:05:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anne Hodgson",
      "screen_name" : "annehodg",
      "indices" : [ 0, 9 ],
      "id_str" : "17589213",
      "id" : 17589213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "392712314865979392",
  "geo" : { },
  "id_str" : "392715888563978240",
  "in_reply_to_user_id" : 17589213,
  "text" : "@annehodg food",
  "id" : 392715888563978240,
  "in_reply_to_status_id" : 392712314865979392,
  "created_at" : "2013-10-22 18:15:38 +0000",
  "in_reply_to_screen_name" : "annehodg",
  "in_reply_to_user_id_str" : "17589213",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darius Kazemi",
      "screen_name" : "tinysubversions",
      "indices" : [ 3, 19 ],
      "id_str" : "14475298",
      "id" : 14475298
    }, {
      "name" : "Two Headlines",
      "screen_name" : "TwoHeadlines",
      "indices" : [ 42, 55 ],
      "id_str" : "1705052335",
      "id" : 1705052335
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/3asjEBFPSr",
      "expanded_url" : "http:\/\/bit.ly\/1ibwH3E",
      "display_url" : "bit.ly\/1ibwH3E"
    } ]
  },
  "geo" : { },
  "id_str" : "392699824883380224",
  "text" : "RT @tinysubversions: I wrote about my bot @twoheadlines and why its algorithm tends toward near-future dystopian fiction instead of jokes: \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Two Headlines",
        "screen_name" : "TwoHeadlines",
        "indices" : [ 21, 34 ],
        "id_str" : "1705052335",
        "id" : 1705052335
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/3asjEBFPSr",
        "expanded_url" : "http:\/\/bit.ly\/1ibwH3E",
        "display_url" : "bit.ly\/1ibwH3E"
      } ]
    },
    "geo" : { },
    "id_str" : "392686896155226112",
    "text" : "I wrote about my bot @twoheadlines and why its algorithm tends toward near-future dystopian fiction instead of jokes: http:\/\/t.co\/3asjEBFPSr",
    "id" : 392686896155226112,
    "created_at" : "2013-10-22 16:20:26 +0000",
    "user" : {
      "name" : "Darius Kazemi",
      "screen_name" : "tinysubversions",
      "protected" : false,
      "id_str" : "14475298",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723889712772059136\/4T8a46Sp_normal.jpg",
      "id" : 14475298,
      "verified" : false
    }
  },
  "id" : 392699824883380224,
  "created_at" : "2013-10-22 17:11:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Graham Jones",
      "screen_name" : "10Sentences",
      "indices" : [ 95, 107 ],
      "id_str" : "1520318594",
      "id" : 1520318594
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/PGscDZLvIr",
      "expanded_url" : "http:\/\/wp.me\/p2roaS-WE",
      "display_url" : "wp.me\/p2roaS-WE"
    } ]
  },
  "geo" : { },
  "id_str" : "392677352519372801",
  "text" : "Four key principles of small talk, from the movie \u201COcean\u2019s Eleven\u201D: http:\/\/t.co\/PGscDZLvIr via @10Sentences",
  "id" : 392677352519372801,
  "created_at" : "2013-10-22 15:42:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naomi Epstein",
      "screen_name" : "naomishema",
      "indices" : [ 22, 33 ],
      "id_str" : "228469472",
      "id" : 228469472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "392665950656278528",
  "geo" : { },
  "id_str" : "392676073881620481",
  "in_reply_to_user_id" : 228469472,
  "text" : "interesting reactions @naomishema i liked the 'wasting battery' response :)",
  "id" : 392676073881620481,
  "in_reply_to_status_id" : 392665950656278528,
  "created_at" : "2013-10-22 15:37:26 +0000",
  "in_reply_to_screen_name" : "naomishema",
  "in_reply_to_user_id_str" : "228469472",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "indices" : [ 0, 12 ],
      "id_str" : "849729062",
      "id" : 849729062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "392623935776624640",
  "geo" : { },
  "id_str" : "392675324216868865",
  "in_reply_to_user_id" : 849729062,
  "text" : "@TonyMcEnery nice intro, fyi video is not loading under firefox 24",
  "id" : 392675324216868865,
  "in_reply_to_status_id" : 392623935776624640,
  "created_at" : "2013-10-22 15:34:27 +0000",
  "in_reply_to_screen_name" : "TonyMcEnery",
  "in_reply_to_user_id_str" : "849729062",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "justtheword",
      "indices" : [ 36, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392531058941362176",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco thanks for phil edmonds #justtheword post RT; if u have used tool comments welcome :)",
  "id" : 392531058941362176,
  "created_at" : "2013-10-22 06:01:11 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "indices" : [ 0, 12 ],
      "id_str" : "192437743",
      "id" : 192437743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "392314596230717440",
  "geo" : { },
  "id_str" : "392348675650756608",
  "in_reply_to_user_id" : 192437743,
  "text" : "@nathanghall thanks for considering! phil happens to be canadian as well :)",
  "id" : 392348675650756608,
  "in_reply_to_status_id" : 392314596230717440,
  "created_at" : "2013-10-21 17:56:28 +0000",
  "in_reply_to_screen_name" : "nathanghall",
  "in_reply_to_user_id_str" : "192437743",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David John Bradshaw",
      "screen_name" : "djb667",
      "indices" : [ 0, 7 ],
      "id_str" : "35684587",
      "id" : 35684587
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "392318358495846400",
  "geo" : { },
  "id_str" : "392336041278849024",
  "in_reply_to_user_id" : 35684587,
  "text" : "@djb667 happy blogiversary :) 20k views in a year is no small change!",
  "id" : 392336041278849024,
  "in_reply_to_status_id" : 392318358495846400,
  "created_at" : "2013-10-21 17:06:16 +0000",
  "in_reply_to_screen_name" : "djb667",
  "in_reply_to_user_id_str" : "35684587",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 66, 82 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/M9WHOM4bp0",
      "expanded_url" : "http:\/\/wp.me\/pBm7c-1Xs",
      "display_url" : "wp.me\/pBm7c-1Xs"
    } ]
  },
  "geo" : { },
  "id_str" : "392314137671266304",
  "text" : "Best Practices and Bad Habits (Part 2) http:\/\/t.co\/M9WHOM4bp0 via @wordpressdotcom",
  "id" : 392314137671266304,
  "created_at" : "2013-10-21 15:39:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thisiswhateternityfeelslike",
      "indices" : [ 91, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392308209874001921",
  "text" : "hmm antconc (mac) lags with a 13mill word corpus, went and foolishly clicked 2-gram search #thisiswhateternityfeelslike",
  "id" : 392308209874001921,
  "created_at" : "2013-10-21 15:15:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpuslinguistics",
      "indices" : [ 89, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/l6yMhSGfzl",
      "expanded_url" : "https:\/\/plus.google.com\/110591153397060907977\/posts\/JAHCPfrS1e9",
      "display_url" : "plus.google.com\/11059115339706\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392284102247727104",
  "text" : "nice tool which can automatically POS tag and search a .txt file https:\/\/t.co\/l6yMhSGfzl #corpuslinguistics",
  "id" : 392284102247727104,
  "created_at" : "2013-10-21 13:39:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulmaglione",
      "screen_name" : "paulmaglione",
      "indices" : [ 3, 16 ],
      "id_str" : "14094921",
      "id" : 14094921
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "efl",
      "indices" : [ 92, 96 ]
    }, {
      "text" : "esl",
      "indices" : [ 97, 101 ]
    }, {
      "text" : "elt",
      "indices" : [ 102, 106 ]
    }, {
      "text" : "pronunciation",
      "indices" : [ 107, 121 ]
    }, {
      "text" : "prosody",
      "indices" : [ 122, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/ZEgUjriWAy",
      "expanded_url" : "http:\/\/blog.english-attack.com\/",
      "display_url" : "blog.english-attack.com"
    } ]
  },
  "geo" : { },
  "id_str" : "392277795084468225",
  "text" : "RT @paulmaglione: My first blog post in a while: \"You Said That To Her? Prosody As Meaning\" #efl #esl #elt #pronunciation #prosody http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "efl",
        "indices" : [ 74, 78 ]
      }, {
        "text" : "esl",
        "indices" : [ 79, 83 ]
      }, {
        "text" : "elt",
        "indices" : [ 84, 88 ]
      }, {
        "text" : "pronunciation",
        "indices" : [ 89, 103 ]
      }, {
        "text" : "prosody",
        "indices" : [ 104, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/ZEgUjriWAy",
        "expanded_url" : "http:\/\/blog.english-attack.com\/",
        "display_url" : "blog.english-attack.com"
      } ]
    },
    "geo" : { },
    "id_str" : "392274139983384576",
    "text" : "My first blog post in a while: \"You Said That To Her? Prosody As Meaning\" #efl #esl #elt #pronunciation #prosody http:\/\/t.co\/ZEgUjriWAy",
    "id" : 392274139983384576,
    "created_at" : "2013-10-21 13:00:17 +0000",
    "user" : {
      "name" : "paulmaglione",
      "screen_name" : "paulmaglione",
      "protected" : false,
      "id_str" : "14094921",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/206852089\/twitterpic1_normal.jpg",
      "id" : 14094921,
      "verified" : false
    }
  },
  "id" : 392277795084468225,
  "created_at" : "2013-10-21 13:14:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenn Greenwald",
      "screen_name" : "ggreenwald",
      "indices" : [ 3, 14 ],
      "id_str" : "16076032",
      "id" : 16076032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 124, 140 ],
      "url" : "http:\/\/t.co\/UntsUmOuFg",
      "expanded_url" : "http:\/\/talkingpointsmemo.com\/news\/report-nsa-spied-on-millions-of-french-phone-records-over-30-day-period",
      "display_url" : "talkingpointsmemo.com\/news\/report-ns\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392275831609118721",
  "text" : "RT @ggreenwald: The initial fall-out from the 1st of our Le Monde articles on NSA bulk collection of French communications  http:\/\/t.co\/Unt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/UntsUmOuFg",
        "expanded_url" : "http:\/\/talkingpointsmemo.com\/news\/report-nsa-spied-on-millions-of-french-phone-records-over-30-day-period",
        "display_url" : "talkingpointsmemo.com\/news\/report-ns\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "392266866032259073",
    "text" : "The initial fall-out from the 1st of our Le Monde articles on NSA bulk collection of French communications  http:\/\/t.co\/UntsUmOuFg",
    "id" : 392266866032259073,
    "created_at" : "2013-10-21 12:31:23 +0000",
    "user" : {
      "name" : "Glenn Greenwald",
      "screen_name" : "ggreenwald",
      "protected" : false,
      "id_str" : "16076032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/659383028771364869\/G9HHnjiI_normal.jpg",
      "id" : 16076032,
      "verified" : true
    }
  },
  "id" : 392275831609118721,
  "created_at" : "2013-10-21 13:07:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josette LeBlanc",
      "screen_name" : "JosetteLB",
      "indices" : [ 16, 26 ],
      "id_str" : "33503694",
      "id" : 33503694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "392232013488324609",
  "geo" : { },
  "id_str" : "392274942722469888",
  "in_reply_to_user_id" : 33503694,
  "text" : "avec plaisir :) @JosetteLB",
  "id" : 392274942722469888,
  "in_reply_to_status_id" : 392232013488324609,
  "created_at" : "2013-10-21 13:03:29 +0000",
  "in_reply_to_screen_name" : "JosetteLB",
  "in_reply_to_user_id_str" : "33503694",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monika Sobejko",
      "screen_name" : "SobejM",
      "indices" : [ 10, 17 ],
      "id_str" : "380504775",
      "id" : 380504775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392274511275364352",
  "text" : "hi monika @SobejM thanks for RT for post; Phil is welcoming any and all suggestions\/questions for future version of tool",
  "id" : 392274511275364352,
  "created_at" : "2013-10-21 13:01:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "indices" : [ 24, 36 ],
      "id_str" : "192437743",
      "id" : 192437743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "392262265769971712",
  "geo" : { },
  "id_str" : "392274192294354944",
  "in_reply_to_user_id" : 192437743,
  "text" : "thanks for share nathan @nathanghall ; if u have used tool why not suggest feature to phil?",
  "id" : 392274192294354944,
  "in_reply_to_status_id" : 392262265769971712,
  "created_at" : "2013-10-21 13:00:30 +0000",
  "in_reply_to_screen_name" : "nathanghall",
  "in_reply_to_user_id_str" : "192437743",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/Ybzol0SRnV",
      "expanded_url" : "http:\/\/members5.boardhost.com\/medialens\/msg\/1382355694.html",
      "display_url" : "members5.boardhost.com\/medialens\/msg\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392273876475842561",
  "text" : "Iraq infographic longlisted for award http:\/\/t.co\/Ybzol0SRnV",
  "id" : 392273876475842561,
  "created_at" : "2013-10-21 12:59:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chuck sandy",
      "screen_name" : "chucksandy",
      "indices" : [ 0, 11 ],
      "id_str" : "18880320",
      "id" : 18880320
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "justheword",
      "indices" : [ 62, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392202700361715712",
  "in_reply_to_user_id" : 18880320,
  "text" : "@chucksandy thanks for sharing Phil Edmonds post; have u used #justheword? please comment if u have\/thinking about using it :)",
  "id" : 392202700361715712,
  "created_at" : "2013-10-21 08:16:25 +0000",
  "in_reply_to_screen_name" : "chucksandy",
  "in_reply_to_user_id_str" : "18880320",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josette LeBlanc",
      "screen_name" : "JosetteLB",
      "indices" : [ 0, 10 ],
      "id_str" : "33503694",
      "id" : 33503694
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KIETT13",
      "indices" : [ 49, 57 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "392140768892043264",
  "geo" : { },
  "id_str" : "392201840051228672",
  "in_reply_to_user_id" : 33503694,
  "text" : "@JosetteLB hello josette's twitees from paris :) #KIETT13",
  "id" : 392201840051228672,
  "in_reply_to_status_id" : 392140768892043264,
  "created_at" : "2013-10-21 08:13:00 +0000",
  "in_reply_to_screen_name" : "JosetteLB",
  "in_reply_to_user_id_str" : "33503694",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "justtheword",
      "indices" : [ 33, 45 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 69, 77 ]
    }, {
      "text" : "edtech",
      "indices" : [ 78, 85 ]
    }, {
      "text" : "efl",
      "indices" : [ 86, 90 ]
    }, {
      "text" : "edtechchat",
      "indices" : [ 91, 102 ]
    }, {
      "text" : "tefl",
      "indices" : [ 103, 108 ]
    }, {
      "text" : "tesol",
      "indices" : [ 109, 115 ]
    }, {
      "text" : "elt",
      "indices" : [ 116, 120 ]
    }, {
      "text" : "corpuslinguistics",
      "indices" : [ 121, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/oU6j9dYpNm",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-J0",
      "display_url" : "wp.me\/pgHyE-J0"
    } ]
  },
  "geo" : { },
  "id_str" : "392200083669659648",
  "text" : "Interview with Phil Edmonds from #justtheword http:\/\/t.co\/oU6j9dYpNm #eltchat #edtech #efl #edtechchat #tefl #tesol #elt #corpuslinguistics",
  "id" : 392200083669659648,
  "created_at" : "2013-10-21 08:06:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Willingham",
      "screen_name" : "DTWillingham",
      "indices" : [ 3, 16 ],
      "id_str" : "84619537",
      "id" : 84619537
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edchat",
      "indices" : [ 121, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/eOqcZqzaea",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?feature=player_embedded&v=ZyAde4nIIm8",
      "display_url" : "youtube.com\/watch?feature=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392040925780013056",
  "text" : "RT @DTWillingham: Best 58 seconds a parent could spend today: Carol Dweck on the power of \"yet.\" https:\/\/t.co\/eOqcZqzaea #edchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "edchat",
        "indices" : [ 103, 110 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/eOqcZqzaea",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?feature=player_embedded&v=ZyAde4nIIm8",
        "display_url" : "youtube.com\/watch?feature=\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "391868949425422336",
    "text" : "Best 58 seconds a parent could spend today: Carol Dweck on the power of \"yet.\" https:\/\/t.co\/eOqcZqzaea #edchat",
    "id" : 391868949425422336,
    "created_at" : "2013-10-20 10:10:12 +0000",
    "user" : {
      "name" : "Daniel Willingham",
      "screen_name" : "DTWillingham",
      "protected" : false,
      "id_str" : "84619537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1815678310\/Daniel_Willingham_Color_lowres_normal.JPG",
      "id" : 84619537,
      "verified" : false
    }
  },
  "id" : 392040925780013056,
  "created_at" : "2013-10-20 21:33:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/11nYou8YRI",
      "expanded_url" : "http:\/\/36viewsofelt.blogspot.com\/2013\/10\/reading-to-think-teaching-reading-and.html?spref=tw",
      "display_url" : "36viewsofelt.blogspot.com\/2013\/10\/readin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391981297037348864",
  "text" : "36 views of  ELT: reading, writing and thinking: Reading to think, teaching reading and Banksy http:\/\/t.co\/11nYou8YRI",
  "id" : 391981297037348864,
  "created_at" : "2013-10-20 17:36:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bethany Cagnol",
      "screen_name" : "bethcagnol",
      "indices" : [ 0, 11 ],
      "id_str" : "27641720",
      "id" : 27641720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "391905331200421888",
  "geo" : { },
  "id_str" : "391965080742420480",
  "in_reply_to_user_id" : 27641720,
  "text" : "@bethcagnol the perils of fixed phrases! an interesting one a st used to include a lot - by dint of",
  "id" : 391965080742420480,
  "in_reply_to_status_id" : 391905331200421888,
  "created_at" : "2013-10-20 16:32:12 +0000",
  "in_reply_to_screen_name" : "bethcagnol",
  "in_reply_to_user_id_str" : "27641720",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "indices" : [ 3, 15 ],
      "id_str" : "192437743",
      "id" : 192437743
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELT",
      "indices" : [ 54, 58 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 110, 118 ]
    }, {
      "text" : "ellchat",
      "indices" : [ 119, 127 ]
    }, {
      "text" : "esl",
      "indices" : [ 128, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/wVf9ygGLpP",
      "expanded_url" : "http:\/\/bit.ly\/19irZze",
      "display_url" : "bit.ly\/19irZze"
    } ]
  },
  "geo" : { },
  "id_str" : "391858613645762560",
  "text" : "RT @nathanghall: Latest post on setting time goals in #ELT | Timing | ELT Reflections http:\/\/t.co\/wVf9ygGLpP  #eltchat #ellchat #esl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELT",
        "indices" : [ 37, 41 ]
      }, {
        "text" : "eltchat",
        "indices" : [ 93, 101 ]
      }, {
        "text" : "ellchat",
        "indices" : [ 102, 110 ]
      }, {
        "text" : "esl",
        "indices" : [ 111, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/wVf9ygGLpP",
        "expanded_url" : "http:\/\/bit.ly\/19irZze",
        "display_url" : "bit.ly\/19irZze"
      } ]
    },
    "geo" : { },
    "id_str" : "391847528465170432",
    "text" : "Latest post on setting time goals in #ELT | Timing | ELT Reflections http:\/\/t.co\/wVf9ygGLpP  #eltchat #ellchat #esl",
    "id" : 391847528465170432,
    "created_at" : "2013-10-20 08:45:05 +0000",
    "user" : {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "protected" : false,
      "id_str" : "192437743",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/715691315158061056\/_00s_D48_normal.jpg",
      "id" : 192437743,
      "verified" : false
    }
  },
  "id" : 391858613645762560,
  "created_at" : "2013-10-20 09:29:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "391851360746237952",
  "text" : "RT @medialens: Chomsky: 'NASA offered new ways to milk the public for private gain.. until people tired of spacemen stumbling about the moo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "391626000112443392",
    "text" : "Chomsky: 'NASA offered new ways to milk the public for private gain.. until people tired of spacemen stumbling about the moon to no purpose'",
    "id" : 391626000112443392,
    "created_at" : "2013-10-19 18:04:49 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 391851360746237952,
  "created_at" : "2013-10-20 09:00:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Thornbury",
      "screen_name" : "thornburyscott",
      "indices" : [ 0, 15 ],
      "id_str" : "23090474",
      "id" : 23090474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "391505367940595712",
  "geo" : { },
  "id_str" : "391844341741674497",
  "in_reply_to_user_id" : 23090474,
  "text" : "@thornburyscott nice tool lextutor has many hidden gems!",
  "id" : 391844341741674497,
  "in_reply_to_status_id" : 391505367940595712,
  "created_at" : "2013-10-20 08:32:25 +0000",
  "in_reply_to_screen_name" : "thornburyscott",
  "in_reply_to_user_id_str" : "23090474",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Thornbury",
      "screen_name" : "thornburyscott",
      "indices" : [ 3, 18 ],
      "id_str" : "23090474",
      "id" : 23090474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/kGHqAyOdab",
      "expanded_url" : "http:\/\/scottthornburyblog.com\/2013\/10\/13\/expensive-reading\/#comment-694",
      "display_url" : "scottthornburyblog.com\/2013\/10\/13\/exp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391841658964561920",
  "text" : "RT @thornburyscott: Thanks to Tom Cobb of Compleat Lexical Tutor for re-configuring his Conco tool for me! http:\/\/t.co\/kGHqAyOdab",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/kGHqAyOdab",
        "expanded_url" : "http:\/\/scottthornburyblog.com\/2013\/10\/13\/expensive-reading\/#comment-694",
        "display_url" : "scottthornburyblog.com\/2013\/10\/13\/exp\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "391505367940595712",
    "text" : "Thanks to Tom Cobb of Compleat Lexical Tutor for re-configuring his Conco tool for me! http:\/\/t.co\/kGHqAyOdab",
    "id" : 391505367940595712,
    "created_at" : "2013-10-19 10:05:28 +0000",
    "user" : {
      "name" : "Scott Thornbury",
      "screen_name" : "thornburyscott",
      "protected" : false,
      "id_str" : "23090474",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892392697\/twitter03_normal.jpg",
      "id" : 23090474,
      "verified" : false
    }
  },
  "id" : 391841658964561920,
  "created_at" : "2013-10-20 08:21:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Natallia Novikava",
      "screen_name" : "Natashetta",
      "indices" : [ 3, 14 ],
      "id_str" : "56308635",
      "id" : 56308635
    }, {
      "name" : "Lizzie Pinard",
      "screen_name" : "LizziePinard",
      "indices" : [ 88, 101 ],
      "id_str" : "287093748",
      "id" : 287093748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/VD7pb4LwNO",
      "expanded_url" : "http:\/\/wp.me\/p1wSAy-id",
      "display_url" : "wp.me\/p1wSAy-id"
    } ]
  },
  "geo" : { },
  "id_str" : "391841328763785216",
  "text" : "RT @Natashetta: \"Itchy Feet!\" (Some *more* new materials...) http:\/\/t.co\/VD7pb4LwNO via @lizziepinard",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lizzie Pinard",
        "screen_name" : "LizziePinard",
        "indices" : [ 72, 85 ],
        "id_str" : "287093748",
        "id" : 287093748
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 67 ],
        "url" : "http:\/\/t.co\/VD7pb4LwNO",
        "expanded_url" : "http:\/\/wp.me\/p1wSAy-id",
        "display_url" : "wp.me\/p1wSAy-id"
      } ]
    },
    "geo" : { },
    "id_str" : "391838441089949696",
    "text" : "\"Itchy Feet!\" (Some *more* new materials...) http:\/\/t.co\/VD7pb4LwNO via @lizziepinard",
    "id" : 391838441089949696,
    "created_at" : "2013-10-20 08:08:59 +0000",
    "user" : {
      "name" : "Natallia Novikava",
      "screen_name" : "Natashetta",
      "protected" : false,
      "id_str" : "56308635",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2877370292\/d6370dfafaa5506c53671f1bd1da0cdc_normal.jpeg",
      "id" : 56308635,
      "verified" : false
    }
  },
  "id" : 391841328763785216,
  "created_at" : "2013-10-20 08:20:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Teacher ROAR",
      "screen_name" : "TeacherROAR",
      "indices" : [ 3, 15 ],
      "id_str" : "1558774417",
      "id" : 1558774417
    }, {
      "name" : "Company Three",
      "screen_name" : "ictheatre",
      "indices" : [ 60, 70 ],
      "id_str" : "720950931718828035",
      "id" : 720950931718828035
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "youthROAR",
      "indices" : [ 118, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/b7ZBPYbiEJ",
      "expanded_url" : "http:\/\/vimeo.com\/77188015",
      "display_url" : "vimeo.com\/77188015"
    } ]
  },
  "geo" : { },
  "id_str" : "391528136305045505",
  "text" : "RT @TeacherROAR: Attention! Look what the young people from @ictheatre put together about our stike yesterday. It's a #youthROAR http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Company Three",
        "screen_name" : "ictheatre",
        "indices" : [ 43, 53 ],
        "id_str" : "720950931718828035",
        "id" : 720950931718828035
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "youthROAR",
        "indices" : [ 101, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/b7ZBPYbiEJ",
        "expanded_url" : "http:\/\/vimeo.com\/77188015",
        "display_url" : "vimeo.com\/77188015"
      } ]
    },
    "geo" : { },
    "id_str" : "391136847365410816",
    "text" : "Attention! Look what the young people from @ictheatre put together about our stike yesterday. It's a #youthROAR http:\/\/t.co\/b7ZBPYbiEJ",
    "id" : 391136847365410816,
    "created_at" : "2013-10-18 09:41:06 +0000",
    "user" : {
      "name" : "Teacher ROAR",
      "screen_name" : "TeacherROAR",
      "protected" : false,
      "id_str" : "1558774417",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/489000703038205952\/iY7K4OxP_normal.jpeg",
      "id" : 1558774417,
      "verified" : false
    }
  },
  "id" : 391528136305045505,
  "created_at" : "2013-10-19 11:35:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 66, 82 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/VzLuBnZLJr",
      "expanded_url" : "http:\/\/wp.me\/p31zUY-cT",
      "display_url" : "wp.me\/p31zUY-cT"
    } ]
  },
  "geo" : { },
  "id_str" : "391503967990988800",
  "text" : "Which cognitive traps do we fall into? http:\/\/t.co\/VzLuBnZLJr via @wordpressdotcom",
  "id" : 391503967990988800,
  "created_at" : "2013-10-19 09:59:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pete Warden",
      "screen_name" : "petewarden",
      "indices" : [ 95, 106 ],
      "id_str" : "14642896",
      "id" : 14642896
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "besig",
      "indices" : [ 107, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/8joaqIAO2P",
      "expanded_url" : "http:\/\/blog.rjmetrics.com\/2013\/10\/09\/our-logo-looks-like-underpants-a-case-study-in-internationalization\/#.UmIsKiTt6XD",
      "display_url" : "blog.rjmetrics.com\/2013\/10\/09\/our\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391462358733684736",
  "text" : "Our Logo Looks Like Underpants: A Case Study in Internationalization http:\/\/t.co\/8joaqIAO2P ht @petewarden #besig",
  "id" : 391462358733684736,
  "created_at" : "2013-10-19 07:14:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "justtheword",
      "indices" : [ 13, 25 ]
    }, {
      "text" : "corpus",
      "indices" : [ 26, 33 ]
    }, {
      "text" : "jtwQs",
      "indices" : [ 98, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "391329150776000512",
  "text" : "developer of #justtheword #corpus tool looking to hear from users; tweet questions\/suggestions to #jtwQs thanks!",
  "id" : 391329150776000512,
  "created_at" : "2013-10-18 22:25:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "indices" : [ 3, 14 ],
      "id_str" : "152051625",
      "id" : 152051625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/vZtVYE3xyz",
      "expanded_url" : "http:\/\/bit.ly\/19WAAKF",
      "display_url" : "bit.ly\/19WAAKF"
    } ]
  },
  "geo" : { },
  "id_str" : "391315639732039681",
  "text" : "RT @heatherfro: \"Yes I know what a gigabyte is\": Let's talk about sexism in the tech industry http:\/\/t.co\/vZtVYE3xyz where \"tech\" = \"digita\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/vZtVYE3xyz",
        "expanded_url" : "http:\/\/bit.ly\/19WAAKF",
        "display_url" : "bit.ly\/19WAAKF"
      } ]
    },
    "geo" : { },
    "id_str" : "391236460365361152",
    "text" : "\"Yes I know what a gigabyte is\": Let's talk about sexism in the tech industry http:\/\/t.co\/vZtVYE3xyz where \"tech\" = \"digital anything\"",
    "id" : 391236460365361152,
    "created_at" : "2013-10-18 16:16:55 +0000",
    "user" : {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "protected" : false,
      "id_str" : "152051625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/688767277022494720\/KMrzOBc1_normal.jpg",
      "id" : 152051625,
      "verified" : false
    }
  },
  "id" : 391315639732039681,
  "created_at" : "2013-10-18 21:31:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike S. Boyle",
      "screen_name" : "heyboyle",
      "indices" : [ 21, 30 ],
      "id_str" : "612840231",
      "id" : 612840231
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GIFtionary",
      "indices" : [ 97, 108 ]
    }, {
      "text" : "6SecondED",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/C20FCCuYX0",
      "expanded_url" : "http:\/\/bit.ly\/18txUSx",
      "display_url" : "bit.ly\/18txUSx"
    } ]
  },
  "geo" : { },
  "id_str" : "391312207486926848",
  "text" : "RT @ProjectEDtweets: @heyboyle Thanks for the reblog! Check out one of our GIFs as a part of the #GIFtionary! http:\/\/t.co\/C20FCCuYX0 #6Seco\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mike S. Boyle",
        "screen_name" : "heyboyle",
        "indices" : [ 0, 9 ],
        "id_str" : "612840231",
        "id" : 612840231
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GIFtionary",
        "indices" : [ 76, 87 ]
      }, {
        "text" : "6SecondED",
        "indices" : [ 112, 122 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/C20FCCuYX0",
        "expanded_url" : "http:\/\/bit.ly\/18txUSx",
        "display_url" : "bit.ly\/18txUSx"
      } ]
    },
    "in_reply_to_status_id_str" : "391261394688950272",
    "geo" : { },
    "id_str" : "391280669042556928",
    "in_reply_to_user_id" : 612840231,
    "text" : "@heyboyle Thanks for the reblog! Check out one of our GIFs as a part of the #GIFtionary! http:\/\/t.co\/C20FCCuYX0 #6SecondED",
    "id" : 391280669042556928,
    "in_reply_to_status_id" : 391261394688950272,
    "created_at" : "2013-10-18 19:12:35 +0000",
    "in_reply_to_screen_name" : "heyboyle",
    "in_reply_to_user_id_str" : "612840231",
    "user" : {
      "name" : "Project Ed",
      "screen_name" : "ProjectEdVideos",
      "protected" : false,
      "id_str" : "1268043979",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/448479152564211712\/WN7J0PRq_normal.png",
      "id" : 1268043979,
      "verified" : false
    }
  },
  "id" : 391312207486926848,
  "created_at" : "2013-10-18 21:17:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heike Philp",
      "screen_name" : "heikephilp",
      "indices" : [ 3, 14 ],
      "id_str" : "14387055",
      "id" : 14387055
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ted",
      "indices" : [ 29, 33 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/dLI0WuXqjO",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=d6wG_sAdP0U",
      "display_url" : "youtube.com\/watch?v=d6wG_s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391308842988240896",
  "text" : "RT @heikephilp: What a funny #ted talk on 'how to hack online dating' http:\/\/t.co\/dLI0WuXqjO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ted",
        "indices" : [ 13, 17 ]
      } ],
      "urls" : [ {
        "indices" : [ 54, 76 ],
        "url" : "http:\/\/t.co\/dLI0WuXqjO",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=d6wG_sAdP0U",
        "display_url" : "youtube.com\/watch?v=d6wG_s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "391283303900143617",
    "text" : "What a funny #ted talk on 'how to hack online dating' http:\/\/t.co\/dLI0WuXqjO",
    "id" : 391283303900143617,
    "created_at" : "2013-10-18 19:23:04 +0000",
    "user" : {
      "name" : "Heike Philp",
      "screen_name" : "heikephilp",
      "protected" : false,
      "id_str" : "14387055",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1901113888\/GwenandHeikeorig_normal.png",
      "id" : 14387055,
      "verified" : false
    }
  },
  "id" : 391308842988240896,
  "created_at" : "2013-10-18 21:04:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KevinHodgson",
      "screen_name" : "dogtrax",
      "indices" : [ 3, 11 ],
      "id_str" : "13307352",
      "id" : 13307352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/p4E1NqK0Uw",
      "expanded_url" : "http:\/\/dogtrax.edublogs.org\/2013\/10\/18\/hacking-education-week-connected-educator-month-satire\/",
      "display_url" : "dogtrax.edublogs.org\/2013\/10\/18\/hac\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391307214654550016",
  "text" : "RT @dogtrax: Hacking Education Week: Connected Educator Month Satire http:\/\/t.co\/p4E1NqK0Uw Kevin's Meandering Mind",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/mr.-reader\/id412874834?mt=8&uo=4\" rel=\"nofollow\"\u003EMr. Reader on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/p4E1NqK0Uw",
        "expanded_url" : "http:\/\/dogtrax.edublogs.org\/2013\/10\/18\/hacking-education-week-connected-educator-month-satire\/",
        "display_url" : "dogtrax.edublogs.org\/2013\/10\/18\/hac\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "391299254545031168",
    "text" : "Hacking Education Week: Connected Educator Month Satire http:\/\/t.co\/p4E1NqK0Uw Kevin's Meandering Mind",
    "id" : 391299254545031168,
    "created_at" : "2013-10-18 20:26:26 +0000",
    "user" : {
      "name" : "KevinHodgson",
      "screen_name" : "dogtrax",
      "protected" : false,
      "id_str" : "13307352",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629952065809334272\/BKXrDkoi_normal.png",
      "id" : 13307352,
      "verified" : false
    }
  },
  "id" : 391307214654550016,
  "created_at" : "2013-10-18 20:58:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "natiserhost197",
      "screen_name" : "esl_robert",
      "indices" : [ 0, 11 ],
      "id_str" : "2982357761",
      "id" : 2982357761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/F4Mnk3H1Xd",
      "expanded_url" : "http:\/\/corpus.byu.edu\/coca\/?c=coca&q=25884143",
      "display_url" : "corpus.byu.edu\/coca\/?c=coca&q\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "391223749803929600",
  "geo" : { },
  "id_str" : "391274365498568705",
  "in_reply_to_user_id" : 18526186,
  "text" : "@esl_robert similar for man also; comparing woman &amp; man interesting e.g. what is hoda woman!? http:\/\/t.co\/F4Mnk3H1Xd",
  "id" : 391274365498568705,
  "in_reply_to_status_id" : 391223749803929600,
  "created_at" : "2013-10-18 18:47:32 +0000",
  "in_reply_to_screen_name" : "RobertEPoole",
  "in_reply_to_user_id_str" : "18526186",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyler Schnoebelen",
      "screen_name" : "TSchnoebelen",
      "indices" : [ 3, 16 ],
      "id_str" : "14969147",
      "id" : 14969147
    }, {
      "name" : "Anne Charity Hudley",
      "screen_name" : "ACharityHudley",
      "indices" : [ 21, 36 ],
      "id_str" : "136828692",
      "id" : 136828692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/3LZ5nPYtxR",
      "expanded_url" : "http:\/\/bit.ly\/18sjan2",
      "display_url" : "bit.ly\/18sjan2"
    } ]
  },
  "geo" : { },
  "id_str" : "391262725168717824",
  "text" : "RT @TSchnoebelen: MT @ACharityHudley: A new Klingon translation of Rick Astley\u2019s \u201CNever Gonna Give You Up\u201D http:\/\/t.co\/3LZ5nPYtxR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anne Charity Hudley",
        "screen_name" : "ACharityHudley",
        "indices" : [ 3, 18 ],
        "id_str" : "136828692",
        "id" : 136828692
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/3LZ5nPYtxR",
        "expanded_url" : "http:\/\/bit.ly\/18sjan2",
        "display_url" : "bit.ly\/18sjan2"
      } ]
    },
    "in_reply_to_status_id_str" : "391185226933600256",
    "geo" : { },
    "id_str" : "391258868082548736",
    "in_reply_to_user_id" : 136828692,
    "text" : "MT @ACharityHudley: A new Klingon translation of Rick Astley\u2019s \u201CNever Gonna Give You Up\u201D http:\/\/t.co\/3LZ5nPYtxR",
    "id" : 391258868082548736,
    "in_reply_to_status_id" : 391185226933600256,
    "created_at" : "2013-10-18 17:45:58 +0000",
    "in_reply_to_screen_name" : "ACharityHudley",
    "in_reply_to_user_id_str" : "136828692",
    "user" : {
      "name" : "Tyler Schnoebelen",
      "screen_name" : "TSchnoebelen",
      "protected" : false,
      "id_str" : "14969147",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/604427674203779072\/Y4t_NODB_normal.jpg",
      "id" : 14969147,
      "verified" : false
    }
  },
  "id" : 391262725168717824,
  "created_at" : "2013-10-18 18:01:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Sample",
      "screen_name" : "samplereality",
      "indices" : [ 3, 17 ],
      "id_str" : "8497292",
      "id" : 8497292
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "391153213808058368",
  "text" : "RT @samplereality: Be the pocket change you want to see under the seat cushions of the world.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.metrotwit.com\/\" rel=\"nofollow\"\u003EMetroTwit\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "391003551214108672",
    "text" : "Be the pocket change you want to see under the seat cushions of the world.",
    "id" : 391003551214108672,
    "created_at" : "2013-10-18 00:51:25 +0000",
    "user" : {
      "name" : "Mark Sample",
      "screen_name" : "samplereality",
      "protected" : false,
      "id_str" : "8497292",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000707852410\/a86167716ecb748acc89638ad165a162_normal.jpeg",
      "id" : 8497292,
      "verified" : false
    }
  },
  "id" : 391153213808058368,
  "created_at" : "2013-10-18 10:46:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "4TUNE Teller App",
      "screen_name" : "4tunetellernet",
      "indices" : [ 0, 15 ],
      "id_str" : "467634146",
      "id" : 467634146
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390967241056854016",
  "geo" : { },
  "id_str" : "390967870575755264",
  "in_reply_to_user_id" : 467634146,
  "text" : "@4tunetellernet a pleasure, hope some more can be raised before gogo finishes :)",
  "id" : 390967870575755264,
  "in_reply_to_status_id" : 390967241056854016,
  "created_at" : "2013-10-17 22:29:38 +0000",
  "in_reply_to_screen_name" : "4tunetellernet",
  "in_reply_to_user_id_str" : "467634146",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "4TUNE Teller App",
      "screen_name" : "4tunetellernet",
      "indices" : [ 0, 15 ],
      "id_str" : "467634146",
      "id" : 467634146
    }, {
      "name" : "Indiegogo",
      "screen_name" : "Indiegogo",
      "indices" : [ 16, 26 ],
      "id_str" : "34732474",
      "id" : 34732474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390962312057610240",
  "geo" : { },
  "id_str" : "390965823453425664",
  "in_reply_to_user_id" : 467634146,
  "text" : "@4tunetellernet @Indiegogo damn that angle makes me look like my hair is going :\/",
  "id" : 390965823453425664,
  "in_reply_to_status_id" : 390962312057610240,
  "created_at" : "2013-10-17 22:21:30 +0000",
  "in_reply_to_screen_name" : "4tunetellernet",
  "in_reply_to_user_id_str" : "467634146",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Siva Vaidhyanathan",
      "screen_name" : "sivavaid",
      "indices" : [ 3, 12 ],
      "id_str" : "20406724",
      "id" : 20406724
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "17thcenturyGladwell",
      "indices" : [ 118, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390939835181318144",
  "text" : "RT @sivavaid: We assume when 2 objects dropped the heavier falls faster. But a recent study shows unexpected results. #17thcenturyGladwell",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "17thcenturyGladwell",
        "indices" : [ 104, 124 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "390886870110203904",
    "text" : "We assume when 2 objects dropped the heavier falls faster. But a recent study shows unexpected results. #17thcenturyGladwell",
    "id" : 390886870110203904,
    "created_at" : "2013-10-17 17:07:46 +0000",
    "user" : {
      "name" : "Siva Vaidhyanathan",
      "screen_name" : "sivavaid",
      "protected" : false,
      "id_str" : "20406724",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/767792599050649600\/aaiFpS9e_normal.jpg",
      "id" : 20406724,
      "verified" : false
    }
  },
  "id" : 390939835181318144,
  "created_at" : "2013-10-17 20:38:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Howard",
      "screen_name" : "skattyadz",
      "indices" : [ 3, 13 ],
      "id_str" : "4675238256",
      "id" : 4675238256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 127, 140 ],
      "url" : "http:\/\/t.co\/8SK1oI56Ss",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=5Krz-dyD-UQ&sns=tw",
      "display_url" : "youtube.com\/watch?v=5Krz-d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390935666080907264",
  "text" : "RT @skattyadz: This is beyond belief. An amazing trailer for a comedy built from game of thrones episodes being badly lip-read http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/8SK1oI56Ss",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=5Krz-dyD-UQ&sns=tw",
        "display_url" : "youtube.com\/watch?v=5Krz-d\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "390913435342733312",
    "text" : "This is beyond belief. An amazing trailer for a comedy built from game of thrones episodes being badly lip-read http:\/\/t.co\/8SK1oI56Ss",
    "id" : 390913435342733312,
    "created_at" : "2013-10-17 18:53:20 +0000",
    "user" : {
      "name" : "Adam Howard",
      "screen_name" : "codeincontext",
      "protected" : false,
      "id_str" : "22433482",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/592818482770751489\/h6WQ90X-_normal.jpg",
      "id" : 22433482,
      "verified" : false
    }
  },
  "id" : 390935666080907264,
  "created_at" : "2013-10-17 20:21:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "indices" : [ 3, 14 ],
      "id_str" : "152051625",
      "id" : 152051625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 140 ],
      "url" : "http:\/\/t.co\/utCs6XzB0d",
      "expanded_url" : "http:\/\/bit.ly\/19MGHNT",
      "display_url" : "bit.ly\/19MGHNT"
    } ]
  },
  "geo" : { },
  "id_str" : "390878210743083008",
  "text" : "RT @heatherfro: Googlebooks Ngrams Viewer: Slowly actually becoming a *real corpus tool* with the inclusion of wildcards http:\/\/t.co\/utCs6X\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/utCs6XzB0d",
        "expanded_url" : "http:\/\/bit.ly\/19MGHNT",
        "display_url" : "bit.ly\/19MGHNT"
      } ]
    },
    "geo" : { },
    "id_str" : "390875388093534209",
    "text" : "Googlebooks Ngrams Viewer: Slowly actually becoming a *real corpus tool* with the inclusion of wildcards http:\/\/t.co\/utCs6XzB0d",
    "id" : 390875388093534209,
    "created_at" : "2013-10-17 16:22:09 +0000",
    "user" : {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "protected" : false,
      "id_str" : "152051625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/688767277022494720\/KMrzOBc1_normal.jpg",
      "id" : 152051625,
      "verified" : false
    }
  },
  "id" : 390878210743083008,
  "created_at" : "2013-10-17 16:33:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "indices" : [ 3, 14 ],
      "id_str" : "152051625",
      "id" : 152051625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/KGcigqFLN0",
      "expanded_url" : "http:\/\/bit.ly\/H2bvlN",
      "display_url" : "bit.ly\/H2bvlN"
    } ]
  },
  "geo" : { },
  "id_str" : "390791309893849088",
  "text" : "RT @heatherfro: computing power used to be measured in 'kilo-girls'; computing time in 'girl hours', power x time = 'kilo-girl-hours' http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/KGcigqFLN0",
        "expanded_url" : "http:\/\/bit.ly\/H2bvlN",
        "display_url" : "bit.ly\/H2bvlN"
      } ]
    },
    "geo" : { },
    "id_str" : "390768617882542080",
    "text" : "computing power used to be measured in 'kilo-girls'; computing time in 'girl hours', power x time = 'kilo-girl-hours' http:\/\/t.co\/KGcigqFLN0",
    "id" : 390768617882542080,
    "created_at" : "2013-10-17 09:17:53 +0000",
    "user" : {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "protected" : false,
      "id_str" : "152051625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/688767277022494720\/KMrzOBc1_normal.jpg",
      "id" : 152051625,
      "verified" : false
    }
  },
  "id" : 390791309893849088,
  "created_at" : "2013-10-17 10:48:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/erased4838853.com\" rel=\"nofollow\"\u003Eerased4838853\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 21, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390584105022554112",
  "text" : "thanks muchly all :) #eltchat",
  "id" : 390584105022554112,
  "created_at" : "2013-10-16 21:04:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/erased4838853.com\" rel=\"nofollow\"\u003Eerased4838853\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MarisaConstantinides",
      "screen_name" : "Marisa_C",
      "indices" : [ 3, 12 ],
      "id_str" : "18272500",
      "id" : 18272500
    }, {
      "name" : "Jo Sayers",
      "screen_name" : "jo_sayers",
      "indices" : [ 13, 23 ],
      "id_str" : "87176766",
      "id" : 87176766
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 122, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390578391646478336",
  "text" : "MT @Marisa_C @jo_sayers explrtion context and careful CCQs are really important earlier stages - roles genre register etc #eltchat",
  "id" : 390578391646478336,
  "created_at" : "2013-10-16 20:41:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Taylor",
      "screen_name" : "theteacherjames",
      "indices" : [ 114, 130 ],
      "id_str" : "71746265",
      "id" : 71746265
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 131, 139 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390573401859186689",
  "geo" : { },
  "id_str" : "390577229500936192",
  "in_reply_to_user_id" : 71746265,
  "text" : "thats important - flu and acc, thgh im more interested in just getting them to accept their use of english if u c?@theteacherjames #eltchat",
  "id" : 390577229500936192,
  "in_reply_to_status_id" : 390573401859186689,
  "created_at" : "2013-10-16 20:37:22 +0000",
  "in_reply_to_screen_name" : "theteacherjames",
  "in_reply_to_user_id_str" : "71746265",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaunwilden",
      "screen_name" : "Shaunwilden",
      "indices" : [ 0, 12 ],
      "id_str" : "15350512",
      "id" : 15350512
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 126, 134 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390573919649808384",
  "geo" : { },
  "id_str" : "390575108290396160",
  "in_reply_to_user_id" : 15350512,
  "text" : "@Shaunwilden depending on sts i either look at trancript for accuracy or ask them what they noticed when transcribing or both #eltchat",
  "id" : 390575108290396160,
  "in_reply_to_status_id" : 390573919649808384,
  "created_at" : "2013-10-16 20:28:57 +0000",
  "in_reply_to_screen_name" : "Shaunwilden",
  "in_reply_to_user_id_str" : "15350512",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jo Sayers",
      "screen_name" : "jo_sayers",
      "indices" : [ 0, 10 ],
      "id_str" : "87176766",
      "id" : 87176766
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 130, 138 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390573103475994624",
  "geo" : { },
  "id_str" : "390574407220862976",
  "in_reply_to_user_id" : 87176766,
  "text" : "@jo_sayers difficult to say, myself i am more interested in getting them metathinking but sts focus on accuracy and pronunciation #eltchat",
  "id" : 390574407220862976,
  "in_reply_to_status_id" : 390573103475994624,
  "created_at" : "2013-10-16 20:26:09 +0000",
  "in_reply_to_screen_name" : "jo_sayers",
  "in_reply_to_user_id_str" : "87176766",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/erased4838853.com\" rel=\"nofollow\"\u003Eerased4838853\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaunwilden",
      "screen_name" : "Shaunwilden",
      "indices" : [ 0, 12 ],
      "id_str" : "15350512",
      "id" : 15350512
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 97, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390573614460067840",
  "in_reply_to_user_id" : 15350512,
  "text" : "@Shaunwilden usually get them to have ready for next class so clssrm time is not really affected #eltchat",
  "id" : 390573614460067840,
  "created_at" : "2013-10-16 20:23:00 +0000",
  "in_reply_to_screen_name" : "Shaunwilden",
  "in_reply_to_user_id_str" : "15350512",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/erased4838853.com\" rel=\"nofollow\"\u003Eerased4838853\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaunwilden",
      "screen_name" : "Shaunwilden",
      "indices" : [ 0, 12 ],
      "id_str" : "15350512",
      "id" : 15350512
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 65, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390573057703952384",
  "in_reply_to_user_id" : 15350512,
  "text" : "@Shaunwilden yes otherwise they don't really listen and notice!  #eltchat",
  "id" : 390573057703952384,
  "created_at" : "2013-10-16 20:20:48 +0000",
  "in_reply_to_screen_name" : "Shaunwilden",
  "in_reply_to_user_id_str" : "15350512",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/erased4838853.com\" rel=\"nofollow\"\u003Eerased4838853\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 124, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390572729881350144",
  "text" : "am getting sts to record their freepractice and then transcribe a part of recording as a way to raise awarenese of lang use #eltchat",
  "id" : 390572729881350144,
  "created_at" : "2013-10-16 20:19:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 0, 8 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390569962718253056",
  "text" : "#eltchat hi all but lurking :\/",
  "id" : 390569962718253056,
  "created_at" : "2013-10-16 20:08:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Adele Soracco",
      "screen_name" : "LauraSoracco",
      "indices" : [ 0, 13 ],
      "id_str" : "15663328",
      "id" : 15663328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390558464042205184",
  "geo" : { },
  "id_str" : "390558990418989056",
  "in_reply_to_user_id" : 15663328,
  "text" : "@LauraSoracco yeah good Q i dont think it has been implemented at all so hopefully in next version :)",
  "id" : 390558990418989056,
  "in_reply_to_status_id" : 390558464042205184,
  "created_at" : "2013-10-16 19:24:54 +0000",
  "in_reply_to_screen_name" : "LauraSoracco",
  "in_reply_to_user_id_str" : "15663328",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Adele Soracco",
      "screen_name" : "LauraSoracco",
      "indices" : [ 0, 13 ],
      "id_str" : "15663328",
      "id" : 15663328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390556150812250112",
  "geo" : { },
  "id_str" : "390557931214606336",
  "in_reply_to_user_id" : 15663328,
  "text" : "@LauraSoracco wow what brought u there?",
  "id" : 390557931214606336,
  "in_reply_to_status_id" : 390556150812250112,
  "created_at" : "2013-10-16 19:20:41 +0000",
  "in_reply_to_screen_name" : "LauraSoracco",
  "in_reply_to_user_id_str" : "15663328",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "justtheword",
      "indices" : [ 11, 23 ]
    }, {
      "text" : "jtwQs",
      "indices" : [ 99, 105 ]
    }, {
      "text" : "elchat",
      "indices" : [ 106, 113 ]
    }, {
      "text" : "tesol",
      "indices" : [ 114, 120 ]
    }, {
      "text" : "tefl",
      "indices" : [ 121, 126 ]
    }, {
      "text" : "lingchat",
      "indices" : [ 127, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390556561833066496",
  "text" : "do you use #justtheword? if so get in on chance to decide future version by tweeting suggestion to #jtwQs #elchat #tesol #tefl #lingchat",
  "id" : 390556561833066496,
  "created_at" : "2013-10-16 19:15:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Adele Soracco",
      "screen_name" : "LauraSoracco",
      "indices" : [ 0, 13 ],
      "id_str" : "15663328",
      "id" : 15663328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390555405429899264",
  "geo" : { },
  "id_str" : "390555813506342912",
  "in_reply_to_user_id" : 15663328,
  "text" : "@LauraSoracco another 45mins i think",
  "id" : 390555813506342912,
  "in_reply_to_status_id" : 390555405429899264,
  "created_at" : "2013-10-16 19:12:16 +0000",
  "in_reply_to_screen_name" : "LauraSoracco",
  "in_reply_to_user_id_str" : "15663328",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Natallia Novikava",
      "screen_name" : "Natashetta",
      "indices" : [ 0, 11 ],
      "id_str" : "56308635",
      "id" : 56308635
    }, {
      "name" : "Nataliya Sirkiya",
      "screen_name" : "NSirkiya",
      "indices" : [ 12, 21 ],
      "id_str" : "1044775135",
      "id" : 1044775135
    }, {
      "name" : "Monika Sobejko",
      "screen_name" : "SobejM",
      "indices" : [ 46, 53 ],
      "id_str" : "380504775",
      "id" : 380504775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390554098346369025",
  "in_reply_to_user_id" : 56308635,
  "text" : "@Natashetta @NSirkiya thanks a lot for fav of @SobejM post :)",
  "id" : 390554098346369025,
  "created_at" : "2013-10-16 19:05:27 +0000",
  "in_reply_to_screen_name" : "Natashetta",
  "in_reply_to_user_id_str" : "56308635",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Miracel Juanta",
      "screen_name" : "msjuanta",
      "indices" : [ 0, 9 ],
      "id_str" : "23180284",
      "id" : 23180284
    }, {
      "name" : "tkkz",
      "screen_name" : "kumamo10kuma3",
      "indices" : [ 10, 24 ],
      "id_str" : "262937387",
      "id" : 262937387
    }, {
      "name" : "Geoffrey Miller",
      "screen_name" : "GeoffMillerNZ",
      "indices" : [ 25, 39 ],
      "id_str" : "36365357",
      "id" : 36365357
    }, {
      "name" : "Monika Sobejko",
      "screen_name" : "SobejM",
      "indices" : [ 57, 64 ],
      "id_str" : "380504775",
      "id" : 380504775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390553889642016768",
  "in_reply_to_user_id" : 23180284,
  "text" : "@msjuanta @kumamo10kuma3 @GeoffMillerNZ appreciate RT of @SobejM post :)",
  "id" : 390553889642016768,
  "created_at" : "2013-10-16 19:04:38 +0000",
  "in_reply_to_screen_name" : "msjuanta",
  "in_reply_to_user_id_str" : "23180284",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "Monika Sobejko",
      "screen_name" : "SobejM",
      "indices" : [ 12, 19 ],
      "id_str" : "380504775",
      "id" : 380504775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390493835132149760",
  "geo" : { },
  "id_str" : "390552896707645440",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan @SobejM sweet thks for sharing monika's post leo :)",
  "id" : 390552896707645440,
  "in_reply_to_status_id" : 390493835132149760,
  "created_at" : "2013-10-16 19:00:41 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hannah Fry",
      "screen_name" : "FryRsquared",
      "indices" : [ 3, 15 ],
      "id_str" : "273375532",
      "id" : 273375532
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/mYjBBWMUEQ",
      "expanded_url" : "http:\/\/m.youtube.com\/watch?v=t2sozrof3HY&desktop_uri=%2Fwatch%3Fv%3Dt2sozrof3HY",
      "display_url" : "m.youtube.com\/watch?v=t2sozr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390430941870845952",
  "text" : "RT @FryRsquared: Start your day with a lovely little paper aeroplane flying forever in a homemade thermal: http:\/\/t.co\/mYjBBWMUEQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/mYjBBWMUEQ",
        "expanded_url" : "http:\/\/m.youtube.com\/watch?v=t2sozrof3HY&desktop_uri=%2Fwatch%3Fv%3Dt2sozrof3HY",
        "display_url" : "m.youtube.com\/watch?v=t2sozr\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "390380221268242432",
    "text" : "Start your day with a lovely little paper aeroplane flying forever in a homemade thermal: http:\/\/t.co\/mYjBBWMUEQ",
    "id" : 390380221268242432,
    "created_at" : "2013-10-16 07:34:32 +0000",
    "user" : {
      "name" : "Hannah Fry",
      "screen_name" : "FryRsquared",
      "protected" : false,
      "id_str" : "273375532",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/549666331805483009\/vYR8d3e0_normal.jpeg",
      "id" : 273375532,
      "verified" : false
    }
  },
  "id" : 390430941870845952,
  "created_at" : "2013-10-16 10:56:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/NUTOpaw1lm",
      "expanded_url" : "http:\/\/abcnews.go.com\/blogs\/politics\/2013\/10\/julian-assange-surveillance-apparatus-a-threat-to-u-s-democracy\/",
      "display_url" : "abcnews.go.com\/blogs\/politics\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390219516749176832",
  "text" : "not often found together - \"notorious transparency activist\" http:\/\/t.co\/NUTOpaw1lm",
  "id" : 390219516749176832,
  "created_at" : "2013-10-15 20:55:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/IDUyYrrwTX",
      "expanded_url" : "http:\/\/36viewsofelt.blogspot.com\/2013\/10\/36-views.html?spref=tw",
      "display_url" : "36viewsofelt.blogspot.com\/2013\/10\/36-vie\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390210822288318464",
  "text" : "new blog on block - 36 views of  ELT: reading, writing and thinking: 36 views: http:\/\/t.co\/IDUyYrrwTX",
  "id" : 390210822288318464,
  "created_at" : "2013-10-15 20:21:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "justtheword",
      "indices" : [ 4, 16 ]
    }, {
      "text" : "jtwQs",
      "indices" : [ 77, 83 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 104, 112 ]
    }, {
      "text" : "tesol",
      "indices" : [ 113, 119 ]
    }, {
      "text" : "edtech",
      "indices" : [ 120, 127 ]
    }, {
      "text" : "efl",
      "indices" : [ 128, 132 ]
    }, {
      "text" : "tefl",
      "indices" : [ 133, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390202810681159680",
  "text" : "the #justtheword developer is looking for feedback for future versions tweet #jtwQs to help out, thanks #eltchat #tesol #edtech #efl #tefl",
  "id" : 390202810681159680,
  "created_at" : "2013-10-15 19:49:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TESOL France",
      "screen_name" : "TESOLFrance",
      "indices" : [ 3, 15 ],
      "id_str" : "70341872",
      "id" : 70341872
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TESOLFR",
      "indices" : [ 45, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/pPI99TxwUa",
      "expanded_url" : "http:\/\/www.tesol-france.org\/Colloquium13.php",
      "display_url" : "tesol-france.org\/Colloquium13.p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390197527460732928",
  "text" : "RT @TESOLFrance: Online registration for our #TESOLFR Conference (22-24 November 2013) can be found here: http:\/\/t.co\/pPI99TxwUa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TESOLFR",
        "indices" : [ 28, 36 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/pPI99TxwUa",
        "expanded_url" : "http:\/\/www.tesol-france.org\/Colloquium13.php",
        "display_url" : "tesol-france.org\/Colloquium13.p\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "390164901726916608",
    "text" : "Online registration for our #TESOLFR Conference (22-24 November 2013) can be found here: http:\/\/t.co\/pPI99TxwUa",
    "id" : 390164901726916608,
    "created_at" : "2013-10-15 17:18:56 +0000",
    "user" : {
      "name" : "TESOL France",
      "screen_name" : "TESOLFrance",
      "protected" : false,
      "id_str" : "70341872",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1789787647\/TESOL_France_logo_normal.jpg",
      "id" : 70341872,
      "verified" : false
    }
  },
  "id" : 390197527460732928,
  "created_at" : "2013-10-15 19:28:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShareThis",
      "screen_name" : "ShareThis",
      "indices" : [ 79, 89 ],
      "id_str" : "14116807",
      "id" : 14116807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/f2da9AAqeZ",
      "expanded_url" : "http:\/\/shar.es\/EJL3d",
      "display_url" : "shar.es\/EJL3d"
    } ]
  },
  "geo" : { },
  "id_str" : "390195364889755648",
  "text" : "Celebrating Ada Lovelace: Our Favorite Hacker Slang http:\/\/t.co\/f2da9AAqeZ via @sharethis",
  "id" : 390195364889755648,
  "created_at" : "2013-10-15 19:19:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "justheword",
      "indices" : [ 42, 53 ]
    }, {
      "text" : "jtwQs",
      "indices" : [ 60, 66 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 97, 105 ]
    }, {
      "text" : "tesol",
      "indices" : [ 106, 112 ]
    }, {
      "text" : "efl",
      "indices" : [ 113, 117 ]
    }, {
      "text" : "tefl",
      "indices" : [ 118, 123 ]
    }, {
      "text" : "edchat",
      "indices" : [ 124, 131 ]
    }, {
      "text" : "edtech",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390140651506913280",
  "text" : "if you have questions for Phil Edmonds of #justheword tweet #jtwQs; will collate and send thanks #eltchat #tesol #efl #tefl #edchat #edtech",
  "id" : 390140651506913280,
  "created_at" : "2013-10-15 15:42:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BabelNet",
      "indices" : [ 12, 21 ]
    }, {
      "text" : "corporadigest",
      "indices" : [ 49, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/Ir2Vw1lUvG",
      "expanded_url" : "http:\/\/babelnet.org\/stats.jsp",
      "display_url" : "babelnet.org\/stats.jsp"
    } ]
  },
  "geo" : { },
  "id_str" : "390136095783927808",
  "text" : "new version #BabelNet http:\/\/t.co\/Ir2Vw1lUvG h\/t #corporadigest",
  "id" : 390136095783927808,
  "created_at" : "2013-10-15 15:24:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "frenchcomputing",
      "indices" : [ 66, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390047729847902208",
  "text" : "amazing, found out a stdnt today was one of the earliest women in #frenchcomputing",
  "id" : 390047729847902208,
  "created_at" : "2013-10-15 09:33:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "itdi.pro",
      "screen_name" : "iTDipro",
      "indices" : [ 0, 8 ],
      "id_str" : "374391424",
      "id" : 374391424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "389894119713042432",
  "in_reply_to_user_id" : 374391424,
  "text" : "@iTDipro hi be useful to add link to patron page in badge code :)",
  "id" : 389894119713042432,
  "created_at" : "2013-10-14 23:22:56 +0000",
  "in_reply_to_screen_name" : "iTDipro",
  "in_reply_to_user_id_str" : "374391424",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Sakamoto ",
      "screen_name" : "barbsaka",
      "indices" : [ 3, 12 ],
      "id_str" : "2970224781",
      "id" : 2970224781
    }, {
      "name" : "itdi.pro",
      "screen_name" : "iTDipro",
      "indices" : [ 17, 25 ],
      "id_str" : "374391424",
      "id" : 374391424
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iTDi",
      "indices" : [ 136, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/hxE0ql43cF",
      "expanded_url" : "http:\/\/itdi.pro\/itdihome\/patron.php",
      "display_url" : "itdi.pro\/itdihome\/patro\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389891216076468224",
  "text" : "RT @barbsaka: RT @iTDipro: Help us help more teachers.Become an iTDi Patron for as little as $1.Spread the word. http:\/\/t.co\/hxE0ql43cF #iT\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "itdi.pro",
        "screen_name" : "iTDipro",
        "indices" : [ 3, 11 ],
        "id_str" : "374391424",
        "id" : 374391424
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "iTDi",
        "indices" : [ 122, 127 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/hxE0ql43cF",
        "expanded_url" : "http:\/\/itdi.pro\/itdihome\/patron.php",
        "display_url" : "itdi.pro\/itdihome\/patro\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "389890126543073280",
    "text" : "RT @iTDipro: Help us help more teachers.Become an iTDi Patron for as little as $1.Spread the word. http:\/\/t.co\/hxE0ql43cF #iTDi By...",
    "id" : 389890126543073280,
    "created_at" : "2013-10-14 23:07:04 +0000",
    "user" : {
      "name" : "Teaching Village",
      "screen_name" : "TeachingVillage",
      "protected" : false,
      "id_str" : "19234804",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/253051119\/Barb_thumbnail_normal.jpg",
      "id" : 19234804,
      "verified" : false
    }
  },
  "id" : 389891216076468224,
  "created_at" : "2013-10-14 23:11:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Patsko",
      "screen_name" : "lauraahaha",
      "indices" : [ 0, 11 ],
      "id_str" : "97957137",
      "id" : 97957137
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "389857255048622081",
  "geo" : { },
  "id_str" : "389885907609726976",
  "in_reply_to_user_id" : 97957137,
  "text" : "@lauraahaha ah yeah problematic degree namings - bachelor, master; oh, and congrats!",
  "id" : 389885907609726976,
  "in_reply_to_status_id" : 389857255048622081,
  "created_at" : "2013-10-14 22:50:18 +0000",
  "in_reply_to_screen_name" : "lauraahaha",
  "in_reply_to_user_id_str" : "97957137",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ellensclass",
      "screen_name" : "ellensclass",
      "indices" : [ 3, 15 ],
      "id_str" : "451058137",
      "id" : 451058137
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/3nBWF4lWLh",
      "expanded_url" : "http:\/\/wp.me\/p3KAlG-dk",
      "display_url" : "wp.me\/p3KAlG-dk"
    } ]
  },
  "geo" : { },
  "id_str" : "389885430831017984",
  "text" : "RT @ellensclass: What We Watch http:\/\/t.co\/3nBWF4lWLh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 14, 36 ],
        "url" : "http:\/\/t.co\/3nBWF4lWLh",
        "expanded_url" : "http:\/\/wp.me\/p3KAlG-dk",
        "display_url" : "wp.me\/p3KAlG-dk"
      } ]
    },
    "geo" : { },
    "id_str" : "389878869710626816",
    "text" : "What We Watch http:\/\/t.co\/3nBWF4lWLh",
    "id" : 389878869710626816,
    "created_at" : "2013-10-14 22:22:20 +0000",
    "user" : {
      "name" : "ellensclass",
      "screen_name" : "ellensclass",
      "protected" : false,
      "id_str" : "451058137",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1724689649\/NYThatWay_normal.jpg",
      "id" : 451058137,
      "verified" : false
    }
  },
  "id" : 389885430831017984,
  "created_at" : "2013-10-14 22:48:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S Haque",
      "screen_name" : "shahzamanhaque",
      "indices" : [ 0, 15 ],
      "id_str" : "57303632",
      "id" : 57303632
    }, {
      "name" : "TESOL France",
      "screen_name" : "TESOLFrance",
      "indices" : [ 16, 28 ],
      "id_str" : "70341872",
      "id" : 70341872
    }, {
      "name" : "BELTA Belgium",
      "screen_name" : "BELTABelgium",
      "indices" : [ 29, 42 ],
      "id_str" : "884934438",
      "id" : 884934438
    }, {
      "name" : "Bethany Cagnol",
      "screen_name" : "bethcagnol",
      "indices" : [ 43, 54 ],
      "id_str" : "27641720",
      "id" : 27641720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "389878633893855232",
  "geo" : { },
  "id_str" : "389882008601513984",
  "in_reply_to_user_id" : 57303632,
  "text" : "@shahzamanhaque @TESOLFrance @BELTABelgium @bethcagnol nice, merci bien :)",
  "id" : 389882008601513984,
  "in_reply_to_status_id" : 389878633893855232,
  "created_at" : "2013-10-14 22:34:49 +0000",
  "in_reply_to_screen_name" : "shahzamanhaque",
  "in_reply_to_user_id_str" : "57303632",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BELTA Belgium",
      "screen_name" : "BELTABelgium",
      "indices" : [ 3, 16 ],
      "id_str" : "884934438",
      "id" : 884934438
    }, {
      "name" : "Claire Hart",
      "screen_name" : "claire_hart",
      "indices" : [ 59, 71 ],
      "id_str" : "96138105",
      "id" : 96138105
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "besig",
      "indices" : [ 116, 122 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 123, 131 ]
    }, {
      "text" : "esp",
      "indices" : [ 132, 136 ]
    }, {
      "text" : "elt",
      "indices" : [ 137, 140 ]
    }, {
      "text" : "esl",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "iatefl",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/oJidAVv4tO",
      "expanded_url" : "http:\/\/ow.ly\/pOdMi",
      "display_url" : "ow.ly\/pOdMi"
    } ]
  },
  "geo" : { },
  "id_str" : "389832906270859265",
  "text" : "RT @BELTABelgium: Announcing our next webinar on 3\/11 with @claire_hart. For more info, see: http:\/\/t.co\/oJidAVv4tO #besig #eltchat #esp #e\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Claire Hart",
        "screen_name" : "claire_hart",
        "indices" : [ 41, 53 ],
        "id_str" : "96138105",
        "id" : 96138105
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "besig",
        "indices" : [ 98, 104 ]
      }, {
        "text" : "eltchat",
        "indices" : [ 105, 113 ]
      }, {
        "text" : "esp",
        "indices" : [ 114, 118 ]
      }, {
        "text" : "elt",
        "indices" : [ 119, 123 ]
      }, {
        "text" : "esl",
        "indices" : [ 124, 128 ]
      }, {
        "text" : "iatefl",
        "indices" : [ 129, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/oJidAVv4tO",
        "expanded_url" : "http:\/\/ow.ly\/pOdMi",
        "display_url" : "ow.ly\/pOdMi"
      } ]
    },
    "geo" : { },
    "id_str" : "389831874774061057",
    "text" : "Announcing our next webinar on 3\/11 with @claire_hart. For more info, see: http:\/\/t.co\/oJidAVv4tO #besig #eltchat #esp #elt #esl #iatefl",
    "id" : 389831874774061057,
    "created_at" : "2013-10-14 19:15:36 +0000",
    "user" : {
      "name" : "BELTA Belgium",
      "screen_name" : "BELTABelgium",
      "protected" : false,
      "id_str" : "884934438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3130800745\/d36391a9857692e6c2aab76d0033ade0_normal.png",
      "id" : 884934438,
      "verified" : false
    }
  },
  "id" : 389832906270859265,
  "created_at" : "2013-10-14 19:19:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/kZ2Kc6ZCNl",
      "expanded_url" : "http:\/\/tinyurl.com\/pfw2mpb",
      "display_url" : "tinyurl.com\/pfw2mpb"
    } ]
  },
  "geo" : { },
  "id_str" : "389830246549450752",
  "text" : "RT @medialens: 2500+ killed by drones in Pakistan, about half identified victims thus far are civilians and children http:\/\/t.co\/kZ2Kc6ZCNl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/kZ2Kc6ZCNl",
        "expanded_url" : "http:\/\/tinyurl.com\/pfw2mpb",
        "display_url" : "tinyurl.com\/pfw2mpb"
      } ]
    },
    "geo" : { },
    "id_str" : "389824326909710336",
    "text" : "2500+ killed by drones in Pakistan, about half identified victims thus far are civilians and children http:\/\/t.co\/kZ2Kc6ZCNl",
    "id" : 389824326909710336,
    "created_at" : "2013-10-14 18:45:36 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 389830246549450752,
  "created_at" : "2013-10-14 19:09:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 73, 89 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/bzOJ2sQqAx",
      "expanded_url" : "http:\/\/wp.me\/pvfz7-fR",
      "display_url" : "wp.me\/pvfz7-fR"
    } ]
  },
  "geo" : { },
  "id_str" : "389818171990867968",
  "text" : "German culture - explained in 4 short videos  http:\/\/t.co\/bzOJ2sQqAx via @wordpressdotcom",
  "id" : 389818171990867968,
  "created_at" : "2013-10-14 18:21:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Phipps",
      "screen_name" : "lousylinguist",
      "indices" : [ 3, 17 ],
      "id_str" : "48459936",
      "id" : 48459936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/PdcV1V1Kud",
      "expanded_url" : "https:\/\/docs.google.com\/forms\/d\/1ym0eVz9x0Lb1roA2YEsGO7rUksmI_VpbT87BbRybzgA\/viewform#",
      "display_url" : "docs.google.com\/forms\/d\/1ym0eV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389811649634652160",
  "text" : "RT @lousylinguist: quick survey on past participle variations of \"to text\" https:\/\/t.co\/PdcV1V1Kud!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/PdcV1V1Kud",
        "expanded_url" : "https:\/\/docs.google.com\/forms\/d\/1ym0eVz9x0Lb1roA2YEsGO7rUksmI_VpbT87BbRybzgA\/viewform#",
        "display_url" : "docs.google.com\/forms\/d\/1ym0eV\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "389756681606807552",
    "text" : "quick survey on past participle variations of \"to text\" https:\/\/t.co\/PdcV1V1Kud!",
    "id" : 389756681606807552,
    "created_at" : "2013-10-14 14:16:48 +0000",
    "user" : {
      "name" : "Christopher Phipps",
      "screen_name" : "lousylinguist",
      "protected" : false,
      "id_str" : "48459936",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750789987113660416\/2IPugaM9_normal.jpg",
      "id" : 48459936,
      "verified" : false
    }
  },
  "id" : 389811649634652160,
  "created_at" : "2013-10-14 17:55:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pearson ELT USA",
      "screen_name" : "PearsonELTUSA",
      "indices" : [ 0, 14 ],
      "id_str" : "28831191",
      "id" : 28831191
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "389764373008646144",
  "geo" : { },
  "id_str" : "389783163766972416",
  "in_reply_to_user_id" : 28831191,
  "text" : "@PearsonELTUSA thanks for sharing latest post :)",
  "id" : 389783163766972416,
  "in_reply_to_status_id" : 389764373008646144,
  "created_at" : "2013-10-14 16:02:02 +0000",
  "in_reply_to_screen_name" : "PearsonELTUSA",
  "in_reply_to_user_id_str" : "28831191",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Guardian",
      "screen_name" : "guardian",
      "indices" : [ 112, 121 ],
      "id_str" : "87818409",
      "id" : 87818409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/fDy493U2FT",
      "expanded_url" : "http:\/\/gu.com\/p\/3jg9x\/tw",
      "display_url" : "gu.com\/p\/3jg9x\/tw"
    } ]
  },
  "geo" : { },
  "id_str" : "389688161867030528",
  "text" : "How the World Health Organisation covered up Iraq's nuclear nightmare | Nafeez Ahmed http:\/\/t.co\/fDy493U2FT via @guardian",
  "id" : 389688161867030528,
  "created_at" : "2013-10-14 09:44:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesus Romero-Trillo",
      "screen_name" : "jromerotrillo",
      "indices" : [ 0, 14 ],
      "id_str" : "124584132",
      "id" : 124584132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "389686370253287424",
  "in_reply_to_user_id" : 124584132,
  "text" : "@jromerotrillo yikes think you need to adjust your ifttt settings :\/",
  "id" : 389686370253287424,
  "created_at" : "2013-10-14 09:37:25 +0000",
  "in_reply_to_screen_name" : "jromerotrillo",
  "in_reply_to_user_id_str" : "124584132",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monika Sobejko",
      "screen_name" : "SobejM",
      "indices" : [ 0, 7 ],
      "id_str" : "380504775",
      "id" : 380504775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/KFCkYqkBbD",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-HO",
      "display_url" : "wp.me\/pgHyE-HO"
    } ]
  },
  "geo" : { },
  "id_str" : "389683043629158400",
  "in_reply_to_user_id" : 380504775,
  "text" : "@SobejM hi u have a comment on your post http:\/\/t.co\/KFCkYqkBbD",
  "id" : 389683043629158400,
  "created_at" : "2013-10-14 09:24:12 +0000",
  "in_reply_to_screen_name" : "SobejM",
  "in_reply_to_user_id_str" : "380504775",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 57, 65 ]
    }, {
      "text" : "tefl",
      "indices" : [ 66, 71 ]
    }, {
      "text" : "efl",
      "indices" : [ 72, 76 ]
    }, {
      "text" : "esl",
      "indices" : [ 77, 81 ]
    }, {
      "text" : "tesol",
      "indices" : [ 82, 88 ]
    }, {
      "text" : "elt",
      "indices" : [ 89, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/iOOdpbrcS1",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-IF",
      "display_url" : "wp.me\/pgHyE-IF"
    } ]
  },
  "geo" : { },
  "id_str" : "389661212050341888",
  "text" : "Quick cup of COCA - lemma and POS http:\/\/t.co\/iOOdpbrcS1 #eltchat #tefl #efl #esl #tesol #elt",
  "id" : 389661212050341888,
  "created_at" : "2013-10-14 07:57:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Stults",
      "screen_name" : "JustinStults",
      "indices" : [ 0, 13 ],
      "id_str" : "294217312",
      "id" : 294217312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "389487881246756864",
  "geo" : { },
  "id_str" : "389493767067021313",
  "in_reply_to_user_id" : 294217312,
  "text" : "@JustinStults you need to put them in a barrel, leave for sometime in a dark cellar for best results i hear :)",
  "id" : 389493767067021313,
  "in_reply_to_status_id" : 389487881246756864,
  "created_at" : "2013-10-13 20:52:05 +0000",
  "in_reply_to_screen_name" : "JustinStults",
  "in_reply_to_user_id_str" : "294217312",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tDoK3",
      "screen_name" : "bondskew",
      "indices" : [ 3, 12 ],
      "id_str" : "856257518",
      "id" : 856257518
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/4Md4h5bk6P",
      "expanded_url" : "http:\/\/youtu.be\/hK6DDC4CV0s",
      "display_url" : "youtu.be\/hK6DDC4CV0s"
    } ]
  },
  "geo" : { },
  "id_str" : "389460334240866304",
  "text" : "RT @bondskew: must be watched by all - Mediastan (2013): http:\/\/t.co\/4Md4h5bk6P \/\/ will be posted several times over the following week",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 65 ],
        "url" : "http:\/\/t.co\/4Md4h5bk6P",
        "expanded_url" : "http:\/\/youtu.be\/hK6DDC4CV0s",
        "display_url" : "youtu.be\/hK6DDC4CV0s"
      } ]
    },
    "geo" : { },
    "id_str" : "389421647943716864",
    "text" : "must be watched by all - Mediastan (2013): http:\/\/t.co\/4Md4h5bk6P \/\/ will be posted several times over the following week",
    "id" : 389421647943716864,
    "created_at" : "2013-10-13 16:05:30 +0000",
    "user" : {
      "name" : "tDoK3",
      "screen_name" : "bondskew",
      "protected" : false,
      "id_str" : "856257518",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/740658441522384896\/fEjtoYp6_normal.jpg",
      "id" : 856257518,
      "verified" : false
    }
  },
  "id" : 389460334240866304,
  "created_at" : "2013-10-13 18:39:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Freeman",
      "screen_name" : "SnoozeInBrief",
      "indices" : [ 48, 62 ],
      "id_str" : "82947233",
      "id" : 82947233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/I2rp0JdJHC",
      "expanded_url" : "http:\/\/wp.me\/p1l5Kr-4E",
      "display_url" : "wp.me\/p1l5Kr-4E"
    } ]
  },
  "geo" : { },
  "id_str" : "389449194781433856",
  "text" : "Pedantry is flagging http:\/\/t.co\/I2rp0JdJHC via @SnoozeInBrief",
  "id" : 389449194781433856,
  "created_at" : "2013-10-13 17:54:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Adele Soracco",
      "screen_name" : "LauraSoracco",
      "indices" : [ 0, 13 ],
      "id_str" : "15663328",
      "id" : 15663328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "389408275382284288",
  "geo" : { },
  "id_str" : "389414107977228288",
  "in_reply_to_user_id" : 15663328,
  "text" : "@LauraSoracco agreed; be good to have the learner errors function working; time to donate i guess!",
  "id" : 389414107977228288,
  "in_reply_to_status_id" : 389408275382284288,
  "created_at" : "2013-10-13 15:35:32 +0000",
  "in_reply_to_screen_name" : "LauraSoracco",
  "in_reply_to_user_id_str" : "15663328",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angus B Grieve-Smith",
      "screen_name" : "grvsmth",
      "indices" : [ 0, 8 ],
      "id_str" : "22381639",
      "id" : 22381639
    }, {
      "name" : "Yuichiro Kobayashi",
      "screen_name" : "langstat",
      "indices" : [ 9, 18 ],
      "id_str" : "108896452",
      "id" : 108896452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "389401609752424448",
  "geo" : { },
  "id_str" : "389405403739455488",
  "in_reply_to_user_id" : 22381639,
  "text" : "@grvsmth @langstat be interested tp c how it was compiled e.g. odd words like bear in shopping category?! i like the synonyms linking though",
  "id" : 389405403739455488,
  "in_reply_to_status_id" : 389401609752424448,
  "created_at" : "2013-10-13 15:00:57 +0000",
  "in_reply_to_screen_name" : "grvsmth",
  "in_reply_to_user_id_str" : "22381639",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yuichiro Kobayashi",
      "screen_name" : "langstat",
      "indices" : [ 3, 12 ],
      "id_str" : "108896452",
      "id" : 108896452
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "toeic",
      "indices" : [ 122, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/0mBCdnT10f",
      "expanded_url" : "http:\/\/www.help2say.com\/questions\/1149\/the-first-600-most-common-words-in-english-for-international-communication",
      "display_url" : "help2say.com\/questions\/1149\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389396783949811713",
  "text" : "MT @langstat The first 600 most common words in English for International Communication - Help2Say http:\/\/t.co\/0mBCdnT10f #toeic",
  "id" : 389396783949811713,
  "created_at" : "2013-10-13 14:26:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mari Yamauchi",
      "screen_name" : "m_yam",
      "indices" : [ 3, 9 ],
      "id_str" : "21755807",
      "id" : 21755807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/ySh1CLEG0t",
      "expanded_url" : "http:\/\/Research-publishing.net",
      "display_url" : "Research-publishing.net"
    }, {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/tK3lvAOj3y",
      "expanded_url" : "http:\/\/ow.ly\/pLrF3",
      "display_url" : "ow.ly\/pLrF3"
    } ]
  },
  "geo" : { },
  "id_str" : "389299624449961984",
  "text" : "RT @m_yam: 2013 Case Studies of Openness in the Language Classroom | http:\/\/t.co\/ySh1CLEG0t http:\/\/t.co\/tK3lvAOj3y",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/ySh1CLEG0t",
        "expanded_url" : "http:\/\/Research-publishing.net",
        "display_url" : "Research-publishing.net"
      }, {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/tK3lvAOj3y",
        "expanded_url" : "http:\/\/ow.ly\/pLrF3",
        "display_url" : "ow.ly\/pLrF3"
      } ]
    },
    "geo" : { },
    "id_str" : "389253443095105536",
    "text" : "2013 Case Studies of Openness in the Language Classroom | http:\/\/t.co\/ySh1CLEG0t http:\/\/t.co\/tK3lvAOj3y",
    "id" : 389253443095105536,
    "created_at" : "2013-10-13 04:57:07 +0000",
    "user" : {
      "name" : "Mari Yamauchi",
      "screen_name" : "m_yam",
      "protected" : false,
      "id_str" : "21755807",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/473333586330796032\/Z5XanZeq_normal.jpeg",
      "id" : 21755807,
      "verified" : false
    }
  },
  "id" : 389299624449961984,
  "created_at" : "2013-10-13 08:00:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Pride",
      "screen_name" : "ThomasPride",
      "indices" : [ 98, 110 ],
      "id_str" : "385867551",
      "id" : 385867551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/53pCVNNJ1g",
      "expanded_url" : "http:\/\/wp.me\/p1U04a-5iE",
      "display_url" : "wp.me\/p1U04a-5iE"
    } ]
  },
  "geo" : { },
  "id_str" : "389160695700283392",
  "text" : "Never mind - British kids are just naturally thicker than Finnish kids http:\/\/t.co\/53pCVNNJ1g via @ThomasPride",
  "id" : 389160695700283392,
  "created_at" : "2013-10-12 22:48:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MrLingo",
      "screen_name" : "SportsLingo",
      "indices" : [ 3, 15 ],
      "id_str" : "1398265280",
      "id" : 1398265280
    }, {
      "name" : "Ben Zimmer",
      "screen_name" : "bgzimmer",
      "indices" : [ 109, 118 ],
      "id_str" : "15104164",
      "id" : 15104164
    }, {
      "name" : "Angus B Grieve-Smith",
      "screen_name" : "grvsmth",
      "indices" : [ 119, 127 ],
      "id_str" : "22381639",
      "id" : 22381639
    }, {
      "name" : "Steven Pinker",
      "screen_name" : "sapinker",
      "indices" : [ 128, 137 ],
      "id_str" : "107225267",
      "id" : 107225267
    }, {
      "name" : "LINGUIST List",
      "screen_name" : "linguistlist",
      "indices" : [ 139, 140 ],
      "id_str" : "104943598",
      "id" : 104943598
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "linguistics",
      "indices" : [ 95, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/FZYpAfy4Qh",
      "expanded_url" : "http:\/\/www.mundolingua.org",
      "display_url" : "mundolingua.org"
    } ]
  },
  "geo" : { },
  "id_str" : "389150979742269440",
  "text" : "RT @SportsLingo: As of October 12th, Paris has a museum of linguistics: http:\/\/t.co\/FZYpAfy4Qh #linguistics  @bgzimmer @grvsmth @sapinker @\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ben Zimmer",
        "screen_name" : "bgzimmer",
        "indices" : [ 92, 101 ],
        "id_str" : "15104164",
        "id" : 15104164
      }, {
        "name" : "Angus B Grieve-Smith",
        "screen_name" : "grvsmth",
        "indices" : [ 102, 110 ],
        "id_str" : "22381639",
        "id" : 22381639
      }, {
        "name" : "Steven Pinker",
        "screen_name" : "sapinker",
        "indices" : [ 111, 120 ],
        "id_str" : "107225267",
        "id" : 107225267
      }, {
        "name" : "LINGUIST List",
        "screen_name" : "linguistlist",
        "indices" : [ 121, 134 ],
        "id_str" : "104943598",
        "id" : 104943598
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "linguistics",
        "indices" : [ 78, 90 ]
      } ],
      "urls" : [ {
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/FZYpAfy4Qh",
        "expanded_url" : "http:\/\/www.mundolingua.org",
        "display_url" : "mundolingua.org"
      } ]
    },
    "geo" : { },
    "id_str" : "389125484535353344",
    "text" : "As of October 12th, Paris has a museum of linguistics: http:\/\/t.co\/FZYpAfy4Qh #linguistics  @bgzimmer @grvsmth @sapinker @linguistlist",
    "id" : 389125484535353344,
    "created_at" : "2013-10-12 20:28:39 +0000",
    "user" : {
      "name" : "MrLingo",
      "screen_name" : "SportsLingo",
      "protected" : false,
      "id_str" : "1398265280",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3604926018\/323b5676862e0a95ec1bbde0cd0fc016_normal.png",
      "id" : 1398265280,
      "verified" : false
    }
  },
  "id" : 389150979742269440,
  "created_at" : "2013-10-12 22:09:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 3, 16 ],
      "id_str" : "88655243",
      "id" : 88655243
    }, {
      "name" : "Gemma Lunn",
      "screen_name" : "GemL1",
      "indices" : [ 52, 58 ],
      "id_str" : "486146568",
      "id" : 486146568
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RSCON4",
      "indices" : [ 18, 25 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/VQYoNRs8lZ",
      "expanded_url" : "https:\/\/sas.elluminate.com\/d.jnlp?sid=2008350&password=RSCON4Part150",
      "display_url" : "sas.elluminate.com\/d.jnlp?sid=200\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389010319928205312",
  "text" : "RT @rosemerebard: #RSCON4 Presenting in 4h 30m with @GemL1 SESSION LINK - https:\/\/t.co\/VQYoNRs8lZ - Virtual Exchange Projects - Motivating \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gemma Lunn",
        "screen_name" : "GemL1",
        "indices" : [ 34, 40 ],
        "id_str" : "486146568",
        "id" : 486146568
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RSCON4",
        "indices" : [ 0, 7 ]
      } ],
      "urls" : [ {
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/VQYoNRs8lZ",
        "expanded_url" : "https:\/\/sas.elluminate.com\/d.jnlp?sid=2008350&password=RSCON4Part150",
        "display_url" : "sas.elluminate.com\/d.jnlp?sid=200\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "389005160124387328",
    "text" : "#RSCON4 Presenting in 4h 30m with @GemL1 SESSION LINK - https:\/\/t.co\/VQYoNRs8lZ - Virtual Exchange Projects - Motivating Teens 2 communicate",
    "id" : 389005160124387328,
    "created_at" : "2013-10-12 12:30:32 +0000",
    "user" : {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "protected" : false,
      "id_str" : "88655243",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/706508144160145410\/pKzknb5H_normal.jpg",
      "id" : 88655243,
      "verified" : false
    }
  },
  "id" : 389010319928205312,
  "created_at" : "2013-10-12 12:51:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RSCON4",
      "indices" : [ 101, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/DGYkIxJl8W",
      "expanded_url" : "https:\/\/sas.elluminate.com\/d.jnlp?sid=2008350&password=RSCON4Part135",
      "display_url" : "sas.elluminate.com\/d.jnlp?sid=200\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389009059413647361",
  "text" : "in 15 mins - Using Skype to connect ... in Malaysia, Anita Adnan Sat, 12 October, 15:00 \u2013 16:00(CET) #RSCON4 https:\/\/t.co\/DGYkIxJl8W",
  "id" : 389009059413647361,
  "created_at" : "2013-10-12 12:46:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388716315436797952",
  "geo" : { },
  "id_str" : "389003084971515905",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco i should have added that for a free program it's great :)",
  "id" : 389003084971515905,
  "in_reply_to_status_id" : 388716315436797952,
  "created_at" : "2013-10-12 12:22:17 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 50, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/oN1vsttRGB",
      "expanded_url" : "http:\/\/giaklamata.blogspot.fr\/2013\/10\/sometimes-i-sits-thinks.html",
      "display_url" : "giaklamata.blogspot.fr\/2013\/10\/someti\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389002328801431552",
  "text" : "Sometimes I sits an thinks http:\/\/t.co\/oN1vsttRGB #eapchat",
  "id" : 389002328801431552,
  "created_at" : "2013-10-12 12:19:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 50, 66 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/GkgdLHB2NN",
      "expanded_url" : "http:\/\/wp.me\/p31zUY-cw",
      "display_url" : "wp.me\/p31zUY-cw"
    } ]
  },
  "geo" : { },
  "id_str" : "388998546927538176",
  "text" : "What Sir Ken Got Wrong http:\/\/t.co\/GkgdLHB2NN via @wordpressdotcom",
  "id" : 388998546927538176,
  "created_at" : "2013-10-12 12:04:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/doCeMw6Q5b",
      "expanded_url" : "http:\/\/johnhilley.blogspot.co.uk\/2013\/10\/relaying-commonwealth-baton-queen-and.html",
      "display_url" : "johnhilley.blogspot.co.uk\/2013\/10\/relayi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "388973334467469312",
  "text" : "RT @johnwhilley: Relaying the Commonwealth baton - Queen and media on-message http:\/\/t.co\/doCeMw6Q5b",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 83 ],
        "url" : "http:\/\/t.co\/doCeMw6Q5b",
        "expanded_url" : "http:\/\/johnhilley.blogspot.co.uk\/2013\/10\/relaying-commonwealth-baton-queen-and.html",
        "display_url" : "johnhilley.blogspot.co.uk\/2013\/10\/relayi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "388633945283121152",
    "text" : "Relaying the Commonwealth baton - Queen and media on-message http:\/\/t.co\/doCeMw6Q5b",
    "id" : 388633945283121152,
    "created_at" : "2013-10-11 11:55:27 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 388973334467469312,
  "created_at" : "2013-10-12 10:24:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 0, 11 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388779317972328448",
  "geo" : { },
  "id_str" : "388786782713573376",
  "in_reply_to_user_id" : 88202140,
  "text" : "@hughdellar cheers; for sure toby young is too much too young :\/",
  "id" : 388786782713573376,
  "in_reply_to_status_id" : 388779317972328448,
  "created_at" : "2013-10-11 22:02:46 +0000",
  "in_reply_to_screen_name" : "hughdellar",
  "in_reply_to_user_id_str" : "88202140",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 0, 11 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388773372210860032",
  "geo" : { },
  "id_str" : "388773589144461312",
  "in_reply_to_user_id" : 88202140,
  "text" : "@hughdellar righto, images are overrated imo :)",
  "id" : 388773589144461312,
  "in_reply_to_status_id" : 388773372210860032,
  "created_at" : "2013-10-11 21:10:21 +0000",
  "in_reply_to_screen_name" : "hughdellar",
  "in_reply_to_user_id_str" : "88202140",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 0, 11 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388772248602951680",
  "geo" : { },
  "id_str" : "388772869926162433",
  "in_reply_to_user_id" : 88202140,
  "text" : "@hughdellar hi video not playing",
  "id" : 388772869926162433,
  "in_reply_to_status_id" : 388772248602951680,
  "created_at" : "2013-10-11 21:07:29 +0000",
  "in_reply_to_screen_name" : "hughdellar",
  "in_reply_to_user_id_str" : "88202140",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lewis Lansford",
      "screen_name" : "LewisLansford",
      "indices" : [ 3, 17 ],
      "id_str" : "135942990",
      "id" : 135942990
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 140 ],
      "url" : "http:\/\/t.co\/HQJ98mfjYl",
      "expanded_url" : "http:\/\/lnkd.in\/bxAUTsR",
      "display_url" : "lnkd.in\/bxAUTsR"
    } ]
  },
  "geo" : { },
  "id_str" : "388647943404023808",
  "text" : "RT @LewisLansford: Webinar: The Bridge to Nowhere and Other Materials Development Follies to Avoid\n22 Oct, 1830-1930 CET\nhttp:\/\/t.co\/HQJ98m\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.linkedin.com\/\" rel=\"nofollow\"\u003ELinkedIn\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/HQJ98mfjYl",
        "expanded_url" : "http:\/\/lnkd.in\/bxAUTsR",
        "display_url" : "lnkd.in\/bxAUTsR"
      } ]
    },
    "geo" : { },
    "id_str" : "388645442537267200",
    "text" : "Webinar: The Bridge to Nowhere and Other Materials Development Follies to Avoid\n22 Oct, 1830-1930 CET\nhttp:\/\/t.co\/HQJ98mfjYl",
    "id" : 388645442537267200,
    "created_at" : "2013-10-11 12:41:08 +0000",
    "user" : {
      "name" : "Lewis Lansford",
      "screen_name" : "LewisLansford",
      "protected" : false,
      "id_str" : "135942990",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614500196148510720\/X8QTQwqP_normal.jpg",
      "id" : 135942990,
      "verified" : false
    }
  },
  "id" : 388647943404023808,
  "created_at" : "2013-10-11 12:51:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388612999541313536",
  "geo" : { },
  "id_str" : "388641961906679809",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco d\/l seems gd for teachers like me to brush up :) not sure about learners as it is basically an ebook with some quizzes",
  "id" : 388641961906679809,
  "in_reply_to_status_id" : 388612999541313536,
  "created_at" : "2013-10-11 12:27:19 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Parise",
      "screen_name" : "peterrenshu",
      "indices" : [ 0, 12 ],
      "id_str" : "631949549",
      "id" : 631949549
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388516079456104448",
  "geo" : { },
  "id_str" : "388517339601199104",
  "in_reply_to_user_id" : 631949549,
  "text" : "@peterrenshu nice to discover cool teaching features on lextutor wasn't aware of, though the UI does need to be change or is it just me?!",
  "id" : 388517339601199104,
  "in_reply_to_status_id" : 388516079456104448,
  "created_at" : "2013-10-11 04:12:06 +0000",
  "in_reply_to_screen_name" : "peterrenshu",
  "in_reply_to_user_id_str" : "631949549",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Parise",
      "screen_name" : "peterrenshu",
      "indices" : [ 56, 68 ],
      "id_str" : "631949549",
      "id" : 631949549
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/D8XKv9kI6A",
      "expanded_url" : "http:\/\/wp.me\/PfNDY-bA",
      "display_url" : "wp.me\/PfNDY-bA"
    } ]
  },
  "geo" : { },
  "id_str" : "388514647612997632",
  "text" : "A Lextutor video by Tom Cobb http:\/\/t.co\/D8XKv9kI6A via @peterrenshu",
  "id" : 388514647612997632,
  "created_at" : "2013-10-11 04:01:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "makerculture",
      "indices" : [ 7, 20 ]
    }, {
      "text" : "hackspaces",
      "indices" : [ 27, 38 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/FRena9cNVE",
      "expanded_url" : "http:\/\/www.francetvinfo.fr\/image\/74vqltt01-b608\/908\/510\/1746031.jpg",
      "display_url" : "francetvinfo.fr\/image\/74vqltt0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "388431565040017408",
  "text" : "uncool #makerculture &amp; #hackspaces not welcome in France http:\/\/t.co\/FRena9cNVE",
  "id" : 388431565040017408,
  "created_at" : "2013-10-10 22:31:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpuslinguistics",
      "indices" : [ 19, 37 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/V9KRdWlM5x",
      "expanded_url" : "http:\/\/acorn.aston.ac.uk\/Sym_Speakers09.html",
      "display_url" : "acorn.aston.ac.uk\/Sym_Speakers09\u2026"
    }, {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/Jhqvs0ssjI",
      "expanded_url" : "http:\/\/acorn.aston.ac.uk\/Symposium08\/sym_speakers.html",
      "display_url" : "acorn.aston.ac.uk\/Symposium08\/sy\u2026"
    }, {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/oNk6fsRo1I",
      "expanded_url" : "http:\/\/acorn.aston.ac.uk\/symposium\/multimedia.html",
      "display_url" : "acorn.aston.ac.uk\/symposium\/mult\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "388399462185308160",
  "text" : "very int Aston Uni #corpuslinguistics talks; 09 http:\/\/t.co\/V9KRdWlM5x; 08 http:\/\/t.co\/Jhqvs0ssjI; 07 http:\/\/t.co\/oNk6fsRo1I h\/t Facebook CL",
  "id" : 388399462185308160,
  "created_at" : "2013-10-10 20:23:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Guardian",
      "screen_name" : "guardian",
      "indices" : [ 113, 122 ],
      "id_str" : "87818409",
      "id" : 87818409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/gsm8pcLHm1",
      "expanded_url" : "http:\/\/gu.com\/p\/3jdn5\/tw",
      "display_url" : "gu.com\/p\/3jdn5\/tw"
    } ]
  },
  "geo" : { },
  "id_str" : "388269739690033152",
  "text" : "More than jihadism or Iran, China's role in Africa is Obama's obsession | John Pilger http:\/\/t.co\/gsm8pcLHm1 via @guardian",
  "id" : 388269739690033152,
  "created_at" : "2013-10-10 11:48:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/vHNHrbief4",
      "expanded_url" : "http:\/\/leoxicon.blogspot.com\/2013\/10\/collocations-insights-research.html?spref=tw",
      "display_url" : "leoxicon.blogspot.com\/2013\/10\/colloc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "388032902765613056",
  "text" : "Leoxicon: Learners' use of collocations: insights from resea... http:\/\/t.co\/vHNHrbief4",
  "id" : 388032902765613056,
  "created_at" : "2013-10-09 20:07:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike S. Boyle",
      "screen_name" : "heyboyle",
      "indices" : [ 0, 9 ],
      "id_str" : "612840231",
      "id" : 612840231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388028367397597184",
  "geo" : { },
  "id_str" : "388031289065865216",
  "in_reply_to_user_id" : 612840231,
  "text" : "@heyboyle spod similar to nerd\/geek etc, not heard that for a while though :)",
  "id" : 388031289065865216,
  "in_reply_to_status_id" : 388028367397597184,
  "created_at" : "2013-10-09 20:00:43 +0000",
  "in_reply_to_screen_name" : "heyboyle",
  "in_reply_to_user_id_str" : "612840231",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Mayeux",
      "screen_name" : "ESLhiphop",
      "indices" : [ 0, 10 ],
      "id_str" : "1360915363",
      "id" : 1360915363
    }, {
      "name" : "Mike S. Boyle",
      "screen_name" : "heyboyle",
      "indices" : [ 11, 20 ],
      "id_str" : "612840231",
      "id" : 612840231
    }, {
      "name" : "Michael Chesnut",
      "screen_name" : "MichaelChesnut2",
      "indices" : [ 21, 37 ],
      "id_str" : "820940430",
      "id" : 820940430
    }, {
      "name" : "Elise Hu (\uC77C\uB9AC\uC2A4 \uD6C4)",
      "screen_name" : "elisewho",
      "indices" : [ 38, 47 ],
      "id_str" : "16001350",
      "id" : 16001350
    }, {
      "name" : "Rap Genius",
      "screen_name" : "RapGenius",
      "indices" : [ 48, 58 ],
      "id_str" : "735773",
      "id" : 735773
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387962198053498880",
  "geo" : { },
  "id_str" : "387980383884541952",
  "in_reply_to_user_id" : 1360915363,
  "text" : "@ESLhiphop @heyboyle @MichaelChesnut2 @elisewho @RapGenius  though hiphop word count not yet released tool?",
  "id" : 387980383884541952,
  "in_reply_to_status_id" : 387962198053498880,
  "created_at" : "2013-10-09 16:38:26 +0000",
  "in_reply_to_screen_name" : "ESLhiphop",
  "in_reply_to_user_id_str" : "1360915363",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387731592027717632",
  "geo" : { },
  "id_str" : "387794578192879617",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler yr welcome anne :)",
  "id" : 387794578192879617,
  "in_reply_to_status_id" : 387731592027717632,
  "created_at" : "2013-10-09 04:20:06 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ellensclass",
      "screen_name" : "ellensclass",
      "indices" : [ 36, 48 ],
      "id_str" : "451058137",
      "id" : 451058137
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5Icq9WBVke",
      "expanded_url" : "http:\/\/www.languageguide.org\/",
      "display_url" : "languageguide.org"
    } ]
  },
  "geo" : { },
  "id_str" : "387792523185233920",
  "text" : "http:\/\/t.co\/5Icq9WBVke nice sire ht @ellensclass",
  "id" : 387792523185233920,
  "created_at" : "2013-10-09 04:11:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Blond",
      "screen_name" : "BillsEnglish",
      "indices" : [ 3, 16 ],
      "id_str" : "1225932950",
      "id" : 1225932950
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELT",
      "indices" : [ 28, 32 ]
    }, {
      "text" : "ESL",
      "indices" : [ 112, 116 ]
    }, {
      "text" : "grammar",
      "indices" : [ 117, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/wFXGZdVpuw",
      "expanded_url" : "http:\/\/www.billsenglish.com\/1\/post\/2013\/10\/we-fear-change.html",
      "display_url" : "billsenglish.com\/1\/post\/2013\/10\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387791010916749313",
  "text" : "RT @BillsEnglish: To all my #ELT peeps,\nNew blog post on pedagogical theory preferences: http:\/\/t.co\/wFXGZdVpuw\n#ESL #grammar",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELT",
        "indices" : [ 10, 14 ]
      }, {
        "text" : "ESL",
        "indices" : [ 94, 98 ]
      }, {
        "text" : "grammar",
        "indices" : [ 99, 107 ]
      } ],
      "urls" : [ {
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/wFXGZdVpuw",
        "expanded_url" : "http:\/\/www.billsenglish.com\/1\/post\/2013\/10\/we-fear-change.html",
        "display_url" : "billsenglish.com\/1\/post\/2013\/10\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "387746926461845504",
    "text" : "To all my #ELT peeps,\nNew blog post on pedagogical theory preferences: http:\/\/t.co\/wFXGZdVpuw\n#ESL #grammar",
    "id" : 387746926461845504,
    "created_at" : "2013-10-09 01:10:45 +0000",
    "user" : {
      "name" : "Bill Blond",
      "screen_name" : "BillsEnglish",
      "protected" : false,
      "id_str" : "1225932950",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000178985604\/38c86f0ad86b16b49ddd21f7e3d0e4dd_normal.jpeg",
      "id" : 1225932950,
      "verified" : false
    }
  },
  "id" : 387791010916749313,
  "created_at" : "2013-10-09 04:05:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387667295558189056",
  "geo" : { },
  "id_str" : "387673360357810176",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson i sit u not :)",
  "id" : 387673360357810176,
  "in_reply_to_status_id" : 387667295558189056,
  "created_at" : "2013-10-08 20:18:26 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387656174809915392",
  "geo" : { },
  "id_str" : "387658513872220160",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson ha yeah a cousin of mine is opposite thing when he swears he says sit :)",
  "id" : 387658513872220160,
  "in_reply_to_status_id" : 387656174809915392,
  "created_at" : "2013-10-08 19:19:26 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Grevett",
      "screen_name" : "breathyvowel",
      "indices" : [ 0, 13 ],
      "id_str" : "237547177",
      "id" : 237547177
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/uWMLYegF49",
      "expanded_url" : "http:\/\/seriouspony.com\/blog\/2013\/10\/4\/presentation-skills-considered-harmful",
      "display_url" : "seriouspony.com\/blog\/2013\/10\/4\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "387557496908689408",
  "geo" : { },
  "id_str" : "387559980674473984",
  "in_reply_to_user_id" : 237547177,
  "text" : "@breathyvowel http:\/\/t.co\/uWMLYegF49 seriously useful analogy &gt; presenter as UI",
  "id" : 387559980674473984,
  "in_reply_to_status_id" : 387557496908689408,
  "created_at" : "2013-10-08 12:47:54 +0000",
  "in_reply_to_screen_name" : "breathyvowel",
  "in_reply_to_user_id_str" : "237547177",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 48, 56 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bansky",
      "indices" : [ 57, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/8fTVyUTc7k",
      "expanded_url" : "http:\/\/youtu.be\/FsF3HspQY6A",
      "display_url" : "youtu.be\/FsF3HspQY6A"
    } ]
  },
  "geo" : { },
  "id_str" : "387552384278220800",
  "text" : "Rebel rocket attack: http:\/\/t.co\/8fTVyUTc7k via @youtube #bansky",
  "id" : 387552384278220800,
  "created_at" : "2013-10-08 12:17:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 3, 14 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/OsYLqpVCVA",
      "expanded_url" : "http:\/\/www.kilgarriff.co.uk\/Publications\/2009-K-ETA-Taiwan-scaring.doc",
      "display_url" : "kilgarriff.co.uk\/Publications\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387544474861064192",
  "text" : "RT @lexicoloco: 'Corpora in the classroom without scaring the students.' Adam Kilgarriff http:\/\/t.co\/OsYLqpVCVA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/OsYLqpVCVA",
        "expanded_url" : "http:\/\/www.kilgarriff.co.uk\/Publications\/2009-K-ETA-Taiwan-scaring.doc",
        "display_url" : "kilgarriff.co.uk\/Publications\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "387488456060174336",
    "text" : "'Corpora in the classroom without scaring the students.' Adam Kilgarriff http:\/\/t.co\/OsYLqpVCVA",
    "id" : 387488456060174336,
    "created_at" : "2013-10-08 08:03:41 +0000",
    "user" : {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "protected" : false,
      "id_str" : "300734173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2403500097\/3nmx3kjaycyoc7irwe6s_normal.jpeg",
      "id" : 300734173,
      "verified" : false
    }
  },
  "id" : 387544474861064192,
  "created_at" : "2013-10-08 11:46:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valentina Morgana",
      "screen_name" : "vmorgana",
      "indices" : [ 0, 9 ],
      "id_str" : "62479177",
      "id" : 62479177
    }, {
      "name" : "Monika Sobejko",
      "screen_name" : "SobejM",
      "indices" : [ 43, 50 ],
      "id_str" : "380504775",
      "id" : 380504775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387315005491671040",
  "geo" : { },
  "id_str" : "387328277297119232",
  "in_reply_to_user_id" : 62479177,
  "text" : "@vmorgana thanks for share valentina :) cc @SobejM",
  "id" : 387328277297119232,
  "in_reply_to_status_id" : 387315005491671040,
  "created_at" : "2013-10-07 21:27:12 +0000",
  "in_reply_to_screen_name" : "vmorgana",
  "in_reply_to_user_id_str" : "62479177",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 89, 105 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/qlWWj5MBkI",
      "expanded_url" : "http:\/\/wp.me\/p2CPYN-7l",
      "display_url" : "wp.me\/p2CPYN-7l"
    } ]
  },
  "geo" : { },
  "id_str" : "387271030990843904",
  "text" : "Today is the 12th anniversary of the invasion of Afghanistan. http:\/\/t.co\/qlWWj5MBkI via @wordpressdotcom",
  "id" : 387271030990843904,
  "created_at" : "2013-10-07 17:39:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/nhiT8uf6Li",
      "expanded_url" : "http:\/\/www.informationclearinghouse.info\/article36439.htm",
      "display_url" : "informationclearinghouse.info\/article36439.h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387220859804336128",
  "text" : "David Cameron and George Osborne are essentially fossilised spivs...http:\/\/t.co\/nhiT8uf6Li Pilger on grt form, as usual",
  "id" : 387220859804336128,
  "created_at" : "2013-10-07 14:20:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 0, 13 ],
      "id_str" : "88655243",
      "id" : 88655243
    }, {
      "name" : "Gemma Lunn",
      "screen_name" : "GemL1",
      "indices" : [ 14, 20 ],
      "id_str" : "486146568",
      "id" : 486146568
    }, {
      "name" : "Mari Yamauchi",
      "screen_name" : "m_yam",
      "indices" : [ 85, 91 ],
      "id_str" : "21755807",
      "id" : 21755807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/6hZ4VSkgxG",
      "expanded_url" : "https:\/\/docs.google.com\/file\/d\/0B28jqCIsUYQgTUpDdEhvaS1NbU0\/edit?usp=drive_web",
      "display_url" : "docs.google.com\/file\/d\/0B28jqC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387215635698036736",
  "in_reply_to_user_id" : 88655243,
  "text" : "@rosemerebard @GemL1 hi you may be find this interesting https:\/\/t.co\/6hZ4VSkgxG via @m_yam",
  "id" : 387215635698036736,
  "created_at" : "2013-10-07 13:59:36 +0000",
  "in_reply_to_screen_name" : "rosemerebard",
  "in_reply_to_user_id_str" : "88655243",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angus B Grieve-Smith",
      "screen_name" : "grvsmth",
      "indices" : [ 3, 11 ],
      "id_str" : "22381639",
      "id" : 22381639
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/xJJGPHWdXR",
      "expanded_url" : "http:\/\/grieve-smith.com\/blog\/2013\/10\/the-reduction-effect\/",
      "display_url" : "grieve-smith.com\/blog\/2013\/10\/t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387203520102813696",
  "text" : "RT @grvsmth: New post \"What is more natural than making things easier whenever frequency provides the strongest impulse for this?\" http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/xJJGPHWdXR",
        "expanded_url" : "http:\/\/grieve-smith.com\/blog\/2013\/10\/the-reduction-effect\/",
        "display_url" : "grieve-smith.com\/blog\/2013\/10\/t\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "387202528976601088",
    "text" : "New post \"What is more natural than making things easier whenever frequency provides the strongest impulse for this?\" http:\/\/t.co\/xJJGPHWdXR",
    "id" : 387202528976601088,
    "created_at" : "2013-10-07 13:07:31 +0000",
    "user" : {
      "name" : "Angus B Grieve-Smith",
      "screen_name" : "grvsmth",
      "protected" : false,
      "id_str" : "22381639",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/94827231\/portrait_normal.png",
      "id" : 22381639,
      "verified" : false
    }
  },
  "id" : 387203520102813696,
  "created_at" : "2013-10-07 13:11:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Damien Munchip",
      "screen_name" : "chimponobo",
      "indices" : [ 3, 14 ],
      "id_str" : "327186537",
      "id" : 327186537
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "auselt",
      "indices" : [ 88, 95 ]
    }, {
      "text" : "esl",
      "indices" : [ 96, 100 ]
    }, {
      "text" : "edtech",
      "indices" : [ 101, 108 ]
    }, {
      "text" : "tefl",
      "indices" : [ 109, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/dx5CV6ImLD",
      "expanded_url" : "http:\/\/www.tecsquared.com",
      "display_url" : "tecsquared.com"
    } ]
  },
  "geo" : { },
  "id_str" : "387139958839861248",
  "text" : "RT @chimponobo: It's alive! Our new technology English community http:\/\/t.co\/dx5CV6ImLD #auselt #esl #edtech #tefl see you there!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for Windows\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "auselt",
        "indices" : [ 72, 79 ]
      }, {
        "text" : "esl",
        "indices" : [ 80, 84 ]
      }, {
        "text" : "edtech",
        "indices" : [ 85, 92 ]
      }, {
        "text" : "tefl",
        "indices" : [ 93, 98 ]
      } ],
      "urls" : [ {
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/dx5CV6ImLD",
        "expanded_url" : "http:\/\/www.tecsquared.com",
        "display_url" : "tecsquared.com"
      } ]
    },
    "geo" : { },
    "id_str" : "386846507762061313",
    "text" : "It's alive! Our new technology English community http:\/\/t.co\/dx5CV6ImLD #auselt #esl #edtech #tefl see you there!",
    "id" : 386846507762061313,
    "created_at" : "2013-10-06 13:32:49 +0000",
    "user" : {
      "name" : "Damien Munchip",
      "screen_name" : "chimponobo",
      "protected" : false,
      "id_str" : "327186537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703504370713780224\/Ffd779uj_normal.jpg",
      "id" : 327186537,
      "verified" : false
    }
  },
  "id" : 387139958839861248,
  "created_at" : "2013-10-07 08:58:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 108, 116 ],
      "id_str" : "10228272",
      "id" : 10228272
    }, {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 120, 130 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/hqr7Dxh5Az",
      "expanded_url" : "http:\/\/youtu.be\/02ljBDNr100",
      "display_url" : "youtu.be\/02ljBDNr100"
    } ]
  },
  "geo" : { },
  "id_str" : "387131065006968832",
  "text" : "GAP Client &amp; NSA whistleblower Thomas Drake Testifies before EU Parliame...: http:\/\/t.co\/hqr7Dxh5Az via @youtube ht @medialens board",
  "id" : 387131065006968832,
  "created_at" : "2013-10-07 08:23:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Taylor",
      "screen_name" : "theteacherjames",
      "indices" : [ 0, 16 ],
      "id_str" : "71746265",
      "id" : 71746265
    }, {
      "name" : "Jo Sayers",
      "screen_name" : "jo_sayers",
      "indices" : [ 17, 27 ],
      "id_str" : "87176766",
      "id" : 87176766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387071513507020801",
  "geo" : { },
  "id_str" : "387106391409692672",
  "in_reply_to_user_id" : 71746265,
  "text" : "@theteacherjames @jo_sayers you'll be there in spirit, we'll be there in spirits :) \/stop groaning at the back\/",
  "id" : 387106391409692672,
  "in_reply_to_status_id" : 387071513507020801,
  "created_at" : "2013-10-07 06:45:30 +0000",
  "in_reply_to_screen_name" : "theteacherjames",
  "in_reply_to_user_id_str" : "71746265",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387048616545636353",
  "geo" : { },
  "id_str" : "387103858704400385",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler cheers for sharing :)",
  "id" : 387103858704400385,
  "in_reply_to_status_id" : 387048616545636353,
  "created_at" : "2013-10-07 06:35:26 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    }, {
      "name" : "Alex Grevett",
      "screen_name" : "breathyvowel",
      "indices" : [ 13, 26 ],
      "id_str" : "237547177",
      "id" : 237547177
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387051872223117312",
  "geo" : { },
  "id_str" : "387103787782901760",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler @breathyvowel agree elfaproject is one of the best corpora blogs about at the moment",
  "id" : 387103787782901760,
  "in_reply_to_status_id" : 387051872223117312,
  "created_at" : "2013-10-07 06:35:09 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    }, {
      "name" : "Monika Sobejko",
      "screen_name" : "SobejM",
      "indices" : [ 13, 20 ],
      "id_str" : "380504775",
      "id" : 380504775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387048007952125952",
  "geo" : { },
  "id_str" : "387103526012194816",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler @SobejM thanks anne; monika if you want to pass any comments onto anne DM me",
  "id" : 387103526012194816,
  "in_reply_to_status_id" : 387048007952125952,
  "created_at" : "2013-10-07 06:34:07 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sketch Engine",
      "screen_name" : "SketchEngine",
      "indices" : [ 37, 50 ],
      "id_str" : "841197134",
      "id" : 841197134
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 89, 97 ]
    }, {
      "text" : "tesol",
      "indices" : [ 98, 104 ]
    }, {
      "text" : "efl",
      "indices" : [ 105, 109 ]
    }, {
      "text" : "tefl",
      "indices" : [ 110, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/7XVnUptjZF",
      "expanded_url" : "https:\/\/plus.google.com\/104940199413423400545\/posts\/cpesvZv5q1s",
      "display_url" : "plus.google.com\/10494019941342\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386983809985425408",
  "text" : "did u know there was an open part of @SketchEngine? read on -&gt;https:\/\/t.co\/7XVnUptjZF #eltchat #tesol #efl #tefl",
  "id" : 386983809985425408,
  "created_at" : "2013-10-06 22:38:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jersus Colmenares L.",
      "screen_name" : "jjcolmenaresl",
      "indices" : [ 0, 14 ],
      "id_str" : "195735983",
      "id" : 195735983
    }, {
      "name" : "Anne O'Keeffe",
      "screen_name" : "Anne0Keeffe",
      "indices" : [ 15, 27 ],
      "id_str" : "310322075",
      "id" : 310322075
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386965749987700736",
  "geo" : { },
  "id_str" : "386977290548031488",
  "in_reply_to_user_id" : 195735983,
  "text" : "@jjcolmenaresl @Anne0Keeffe unfortunately anne explained that her employers have restrictions on content :(",
  "id" : 386977290548031488,
  "in_reply_to_status_id" : 386965749987700736,
  "created_at" : "2013-10-06 22:12:30 +0000",
  "in_reply_to_screen_name" : "jjcolmenaresl",
  "in_reply_to_user_id_str" : "195735983",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELT Blog Carnival",
      "screen_name" : "ELTBlogCarnival",
      "indices" : [ 98, 114 ],
      "id_str" : "1107133490",
      "id" : 1107133490
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 71, 79 ]
    }, {
      "text" : "tefl",
      "indices" : [ 80, 85 ]
    }, {
      "text" : "esl",
      "indices" : [ 86, 90 ]
    }, {
      "text" : "tesol",
      "indices" : [ 91, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/ujwuXaBIlP",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-Ia",
      "display_url" : "wp.me\/pgHyE-Ia"
    } ]
  },
  "geo" : { },
  "id_str" : "386942076652240896",
  "text" : "The Tinkerer \u2013 a corpus informed video activity http:\/\/t.co\/ujwuXaBIlP #eltchat #tefl #esl #tesol @ELTBlogCarnival",
  "id" : 386942076652240896,
  "created_at" : "2013-10-06 19:52:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anne O'Keeffe",
      "screen_name" : "Anne0Keeffe",
      "indices" : [ 0, 12 ],
      "id_str" : "310322075",
      "id" : 310322075
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386934966866948098",
  "geo" : { },
  "id_str" : "386935313672593409",
  "in_reply_to_user_id" : 310322075,
  "text" : "@Anne0Keeffe they are a great resource many teachers will find them useful; vids may well lead them on to buy your book :)",
  "id" : 386935313672593409,
  "in_reply_to_status_id" : 386934966866948098,
  "created_at" : "2013-10-06 19:25:42 +0000",
  "in_reply_to_screen_name" : "Anne0Keeffe",
  "in_reply_to_user_id_str" : "310322075",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anne O'Keeffe",
      "screen_name" : "Anne0Keeffe",
      "indices" : [ 0, 12 ],
      "id_str" : "310322075",
      "id" : 310322075
    }, {
      "name" : "TEFLAnneOKeeffe",
      "screen_name" : "TEFLclass",
      "indices" : [ 13, 23 ],
      "id_str" : "469244585",
      "id" : 469244585
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386930327606009856",
  "geo" : { },
  "id_str" : "386934216522346496",
  "in_reply_to_user_id" : 310322075,
  "text" : "@Anne0Keeffe @TEFLclass oh noes you've put them on private :( was watching one on adverbs",
  "id" : 386934216522346496,
  "in_reply_to_status_id" : 386930327606009856,
  "created_at" : "2013-10-06 19:21:20 +0000",
  "in_reply_to_screen_name" : "Anne0Keeffe",
  "in_reply_to_user_id_str" : "310322075",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anne O'Keeffe",
      "screen_name" : "Anne0Keeffe",
      "indices" : [ 0, 12 ],
      "id_str" : "310322075",
      "id" : 310322075
    }, {
      "name" : "Jersus Colmenares L.",
      "screen_name" : "jjcolmenaresl",
      "indices" : [ 78, 92 ],
      "id_str" : "195735983",
      "id" : 195735983
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 93, 101 ]
    }, {
      "text" : "tesol",
      "indices" : [ 102, 108 ]
    }, {
      "text" : "efl",
      "indices" : [ 109, 113 ]
    }, {
      "text" : "esl",
      "indices" : [ 114, 118 ]
    }, {
      "text" : "tefl",
      "indices" : [ 119, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/zyCkSn8zSR",
      "expanded_url" : "http:\/\/www.youtube.com\/channel\/UCqx6ndAmAxDImSQWR-6-OXw\/videos",
      "display_url" : "youtube.com\/channel\/UCqx6n\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386923054376288256",
  "in_reply_to_user_id" : 310322075,
  "text" : "@Anne0Keeffe youtube channel has some neat videos http:\/\/t.co\/zyCkSn8zSR \u2026 HT @jjcolmenaresl #eltchat #tesol #efl #esl #tefl",
  "id" : 386923054376288256,
  "created_at" : "2013-10-06 18:36:59 +0000",
  "in_reply_to_screen_name" : "Anne0Keeffe",
  "in_reply_to_user_id_str" : "310322075",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Szab\u00F3",
      "screen_name" : "RobertASzabo",
      "indices" : [ 15, 28 ],
      "id_str" : "145285777",
      "id" : 145285777
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "386868024390594560",
  "text" : "@MattHalsdorff @RobertASzabo based on authentic emails i think matt :)",
  "id" : 386868024390594560,
  "created_at" : "2013-10-06 14:58:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IATEFL BESIG",
      "screen_name" : "iatefl_besig",
      "indices" : [ 3, 16 ],
      "id_str" : "146913655",
      "id" : 146913655
    }, {
      "name" : "Rob Szab\u00F3",
      "screen_name" : "RobertASzabo",
      "indices" : [ 69, 82 ],
      "id_str" : "145285777",
      "id" : 145285777
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Words",
      "indices" : [ 18, 24 ]
    }, {
      "text" : "elt",
      "indices" : [ 128, 132 ]
    }, {
      "text" : "tefl",
      "indices" : [ 133, 138 ]
    }, {
      "text" : "tesol",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/hchXV9PlDZ",
      "expanded_url" : "http:\/\/www.besig.org\/events\/online\/workshops\/Workshop_31.aspx",
      "display_url" : "besig.org\/events\/online\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386851545209241600",
  "text" : "RT @iatefl_besig: #Words misunderstood - BESIG Weekend Workshop with @RobertASzabo starting in 10 mins http:\/\/t.co\/hchXV9PlDZ \u2026 #elt #tefl \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rob Szab\u00F3",
        "screen_name" : "RobertASzabo",
        "indices" : [ 51, 64 ],
        "id_str" : "145285777",
        "id" : 145285777
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Words",
        "indices" : [ 0, 6 ]
      }, {
        "text" : "elt",
        "indices" : [ 110, 114 ]
      }, {
        "text" : "tefl",
        "indices" : [ 115, 120 ]
      }, {
        "text" : "tesol",
        "indices" : [ 121, 127 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/hchXV9PlDZ",
        "expanded_url" : "http:\/\/www.besig.org\/events\/online\/workshops\/Workshop_31.aspx",
        "display_url" : "besig.org\/events\/online\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "386851249011695616",
    "text" : "#Words misunderstood - BESIG Weekend Workshop with @RobertASzabo starting in 10 mins http:\/\/t.co\/hchXV9PlDZ \u2026 #elt #tefl #tesol",
    "id" : 386851249011695616,
    "created_at" : "2013-10-06 13:51:39 +0000",
    "user" : {
      "name" : "IATEFL BESIG",
      "screen_name" : "iatefl_besig",
      "protected" : false,
      "id_str" : "146913655",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/921734243\/BesigLogoSmall_normal.jpg",
      "id" : 146913655,
      "verified" : false
    }
  },
  "id" : 386851545209241600,
  "created_at" : "2013-10-06 13:52:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShareThis",
      "screen_name" : "ShareThis",
      "indices" : [ 64, 74 ],
      "id_str" : "14116807",
      "id" : 14116807
    }, {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 78, 88 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/8OvDrNfkbi",
      "expanded_url" : "http:\/\/shar.es\/KN2dr",
      "display_url" : "shar.es\/KN2dr"
    } ]
  },
  "geo" : { },
  "id_str" : "386850690074566656",
  "text" : "Why you shouldn't trust journalists  http:\/\/t.co\/8OvDrNfkbi via @sharethis ht @medialens",
  "id" : 386850690074566656,
  "created_at" : "2013-10-06 13:49:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0411\u0430\u043B\u0438\u043D\u0433",
      "screen_name" : "websofsubstance",
      "indices" : [ 75, 91 ],
      "id_str" : "235176479",
      "id" : 235176479
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/eFHbUcfzjN",
      "expanded_url" : "http:\/\/wp.me\/p3hsrD-fA",
      "display_url" : "wp.me\/p3hsrD-fA"
    } ]
  },
  "geo" : { },
  "id_str" : "386822641354407937",
  "text" : "Do you remember that advert about the trousers? http:\/\/t.co\/eFHbUcfzjN via @websofsubstance",
  "id" : 386822641354407937,
  "created_at" : "2013-10-06 11:57:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Levine",
      "screen_name" : "cogdog",
      "indices" : [ 3, 10 ],
      "id_str" : "740343",
      "id" : 740343
    }, {
      "name" : "Serious Pony",
      "screen_name" : "seriouspony",
      "indices" : [ 69, 81 ],
      "id_str" : "122932694",
      "id" : 122932694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/cQkVjoSAax",
      "expanded_url" : "http:\/\/seriouspony.com\/blog\/2013\/10\/4\/presentation-skills-considered-harmful",
      "display_url" : "seriouspony.com\/blog\/2013\/10\/4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386596738951172097",
  "text" : "RT @cogdog: \u201CPresentation Skills Considered Harmful\u201D presenter as UI @seriouspony turns convention inside out.  http:\/\/t.co\/cQkVjoSAax",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Serious Pony",
        "screen_name" : "seriouspony",
        "indices" : [ 57, 69 ],
        "id_str" : "122932694",
        "id" : 122932694
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/cQkVjoSAax",
        "expanded_url" : "http:\/\/seriouspony.com\/blog\/2013\/10\/4\/presentation-skills-considered-harmful",
        "display_url" : "seriouspony.com\/blog\/2013\/10\/4\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "386393807366782977",
    "text" : "\u201CPresentation Skills Considered Harmful\u201D presenter as UI @seriouspony turns convention inside out.  http:\/\/t.co\/cQkVjoSAax",
    "id" : 386393807366782977,
    "created_at" : "2013-10-05 07:33:57 +0000",
    "user" : {
      "name" : "Alan Levine",
      "screen_name" : "cogdog",
      "protected" : false,
      "id_str" : "740343",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/740063389527859201\/BN9buLB9_normal.jpg",
      "id" : 740343,
      "verified" : false
    }
  },
  "id" : 386596738951172097,
  "created_at" : "2013-10-05 21:00:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Brown",
      "screen_name" : "sbrowntweets",
      "indices" : [ 0, 13 ],
      "id_str" : "885343459",
      "id" : 885343459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386535603917316096",
  "geo" : { },
  "id_str" : "386547639564513280",
  "in_reply_to_user_id" : 885343459,
  "text" : "@sbrowntweets fine reflective thinking, look fwd to more :)",
  "id" : 386547639564513280,
  "in_reply_to_status_id" : 386535603917316096,
  "created_at" : "2013-10-05 17:45:13 +0000",
  "in_reply_to_screen_name" : "sbrowntweets",
  "in_reply_to_user_id_str" : "885343459",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 62, 72 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/Hs38IBNJ6P",
      "expanded_url" : "http:\/\/members5.boardhost.com\/medialens\/msg\/1380970233.html",
      "display_url" : "members5.boardhost.com\/medialens\/msg\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386472166004236290",
  "text" : "The light at the end of the tunnel http:\/\/t.co\/Hs38IBNJ6P via @medialens board",
  "id" : 386472166004236290,
  "created_at" : "2013-10-05 12:45:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Moore",
      "screen_name" : "lexicojules",
      "indices" : [ 3, 15 ],
      "id_str" : "424320799",
      "id" : 424320799
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EAPchat",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 124, 140 ],
      "url" : "http:\/\/t.co\/nyMO1fncqZ",
      "expanded_url" : "http:\/\/ow.ly\/puprx",
      "display_url" : "ow.ly\/puprx"
    } ]
  },
  "geo" : { },
  "id_str" : "386453040607150080",
  "text" : "RT @lexicojules: What is EAP vocabulary? Find out what answers I got when I asked some teachers on a recent trip to Munich: http:\/\/t.co\/nyM\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EAPchat",
        "indices" : [ 130, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/nyMO1fncqZ",
        "expanded_url" : "http:\/\/ow.ly\/puprx",
        "display_url" : "ow.ly\/puprx"
      } ]
    },
    "geo" : { },
    "id_str" : "386063506178846720",
    "text" : "What is EAP vocabulary? Find out what answers I got when I asked some teachers on a recent trip to Munich: http:\/\/t.co\/nyMO1fncqZ #EAPchat",
    "id" : 386063506178846720,
    "created_at" : "2013-10-04 09:41:27 +0000",
    "user" : {
      "name" : "Julie Moore",
      "screen_name" : "lexicojules",
      "protected" : false,
      "id_str" : "424320799",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/478823971870109696\/AzIax4m3_normal.jpeg",
      "id" : 424320799,
      "verified" : false
    }
  },
  "id" : 386453040607150080,
  "created_at" : "2013-10-05 11:29:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Brown",
      "screen_name" : "sbrowntweets",
      "indices" : [ 3, 16 ],
      "id_str" : "885343459",
      "id" : 885343459
    }, {
      "name" : "Steve Brown",
      "screen_name" : "sbrowntweets",
      "indices" : [ 125, 138 ],
      "id_str" : "885343459",
      "id" : 885343459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/UosA3BxBfS",
      "expanded_url" : "http:\/\/wp.me\/p2OPTn-mS",
      "display_url" : "wp.me\/p2OPTn-mS"
    } ]
  },
  "geo" : { },
  "id_str" : "386413993763409920",
  "text" : "RT @sbrowntweets: New post, in which I reflect on my inability to reflect: It's hard to be humble http:\/\/t.co\/UosA3BxBfS via @sbrowntweets",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Steve Brown",
        "screen_name" : "sbrowntweets",
        "indices" : [ 107, 120 ],
        "id_str" : "885343459",
        "id" : 885343459
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/UosA3BxBfS",
        "expanded_url" : "http:\/\/wp.me\/p2OPTn-mS",
        "display_url" : "wp.me\/p2OPTn-mS"
      } ]
    },
    "geo" : { },
    "id_str" : "386406411749445632",
    "text" : "New post, in which I reflect on my inability to reflect: It's hard to be humble http:\/\/t.co\/UosA3BxBfS via @sbrowntweets",
    "id" : 386406411749445632,
    "created_at" : "2013-10-05 08:24:02 +0000",
    "user" : {
      "name" : "Steve Brown",
      "screen_name" : "sbrowntweets",
      "protected" : false,
      "id_str" : "885343459",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746292888405934080\/tp1_ccBF_normal.jpg",
      "id" : 885343459,
      "verified" : false
    }
  },
  "id" : 386413993763409920,
  "created_at" : "2013-10-05 08:54:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 3, 14 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELT",
      "indices" : [ 55, 59 ]
    }, {
      "text" : "tefl",
      "indices" : [ 125, 130 ]
    }, {
      "text" : "esol",
      "indices" : [ 131, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/OC3xeunVtf",
      "expanded_url" : "http:\/\/bit.ly\/1bD5fuJ",
      "display_url" : "bit.ly\/1bD5fuJ"
    } ]
  },
  "geo" : { },
  "id_str" : "386372180474224640",
  "text" : "RT @leoselivan: Linguistic corpus and its relevance to #ELT | What corpora HAVE done for us -Leoxicon http:\/\/t.co\/OC3xeunVtf #tefl #esol",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELT",
        "indices" : [ 39, 43 ]
      }, {
        "text" : "tefl",
        "indices" : [ 109, 114 ]
      }, {
        "text" : "esol",
        "indices" : [ 115, 120 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/OC3xeunVtf",
        "expanded_url" : "http:\/\/bit.ly\/1bD5fuJ",
        "display_url" : "bit.ly\/1bD5fuJ"
      } ]
    },
    "geo" : { },
    "id_str" : "386188483079200768",
    "text" : "Linguistic corpus and its relevance to #ELT | What corpora HAVE done for us -Leoxicon http:\/\/t.co\/OC3xeunVtf #tefl #esol",
    "id" : 386188483079200768,
    "created_at" : "2013-10-04 17:58:04 +0000",
    "user" : {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "protected" : false,
      "id_str" : "408365496",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/460546508601819136\/12ivDBb__normal.jpeg",
      "id" : 408365496,
      "verified" : false
    }
  },
  "id" : 386372180474224640,
  "created_at" : "2013-10-05 06:08:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Simpson",
      "screen_name" : "yearinthelifeof",
      "indices" : [ 0, 16 ],
      "id_str" : "78543378",
      "id" : 78543378
    }, {
      "name" : "Sharon Turner",
      "screen_name" : "Sharonzspace",
      "indices" : [ 25, 38 ],
      "id_str" : "235194378",
      "id" : 235194378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386358948468510720",
  "geo" : { },
  "id_str" : "386362376431218688",
  "in_reply_to_user_id" : 78543378,
  "text" : "@yearinthelifeof hi, has @Sharonzspace left twitter?",
  "id" : 386362376431218688,
  "in_reply_to_status_id" : 386358948468510720,
  "created_at" : "2013-10-05 05:29:03 +0000",
  "in_reply_to_screen_name" : "yearinthelifeof",
  "in_reply_to_user_id_str" : "78543378",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "natiserhost197",
      "screen_name" : "esl_robert",
      "indices" : [ 0, 11 ],
      "id_str" : "2982357761",
      "id" : 2982357761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/vWHi5GuTv7",
      "expanded_url" : "http:\/\/lope.linguistics.ntu.edu.tw\/courses\/corpusling\/slides\/week4\/?full#Cover",
      "display_url" : "lope.linguistics.ntu.edu.tw\/courses\/corpus\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "386265767118790656",
  "geo" : { },
  "id_str" : "386268782110326784",
  "in_reply_to_user_id" : 18526186,
  "text" : "@esl_robert nice! fnd a recent corpus ling presentation as it linked to my blog, pretty neat slidify presentation http:\/\/t.co\/vWHi5GuTv7",
  "id" : 386268782110326784,
  "in_reply_to_status_id" : 386265767118790656,
  "created_at" : "2013-10-04 23:17:08 +0000",
  "in_reply_to_screen_name" : "RobertEPoole",
  "in_reply_to_user_id_str" : "18526186",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShareThis",
      "screen_name" : "ShareThis",
      "indices" : [ 70, 80 ],
      "id_str" : "14116807",
      "id" : 14116807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/flEd0czjZG",
      "expanded_url" : "http:\/\/shar.es\/KT0Aw",
      "display_url" : "shar.es\/KT0Aw"
    } ]
  },
  "geo" : { },
  "id_str" : "386265771698966529",
  "text" : "The most embarrassing news interview ever  http:\/\/t.co\/flEd0czjZG via @sharethis",
  "id" : 386265771698966529,
  "created_at" : "2013-10-04 23:05:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 3, 14 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/gBbDfkfKXw",
      "expanded_url" : "http:\/\/learnercorpus.blogspot.com\/?spref=tw",
      "display_url" : "learnercorpus.blogspot.com\/?spref=tw"
    } ]
  },
  "geo" : { },
  "id_str" : "386208672491110400",
  "text" : "RT @lexicoloco: On my new blog: Learner Corpora and Corpus Studies http:\/\/t.co\/gBbDfkfKXw A short review of Learner Corpus Research confere\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 73 ],
        "url" : "http:\/\/t.co\/gBbDfkfKXw",
        "expanded_url" : "http:\/\/learnercorpus.blogspot.com\/?spref=tw",
        "display_url" : "learnercorpus.blogspot.com\/?spref=tw"
      } ]
    },
    "geo" : { },
    "id_str" : "386138299850444800",
    "text" : "On my new blog: Learner Corpora and Corpus Studies http:\/\/t.co\/gBbDfkfKXw A short review of Learner Corpus Research conference 2013 + links.",
    "id" : 386138299850444800,
    "created_at" : "2013-10-04 14:38:39 +0000",
    "user" : {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "protected" : false,
      "id_str" : "300734173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2403500097\/3nmx3kjaycyoc7irwe6s_normal.jpeg",
      "id" : 300734173,
      "verified" : false
    }
  },
  "id" : 386208672491110400,
  "created_at" : "2013-10-04 19:18:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jo Sayers",
      "screen_name" : "jo_sayers",
      "indices" : [ 0, 10 ],
      "id_str" : "87176766",
      "id" : 87176766
    }, {
      "name" : "James Taylor",
      "screen_name" : "theteacherjames",
      "indices" : [ 11, 27 ],
      "id_str" : "71746265",
      "id" : 71746265
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386157512996581377",
  "geo" : { },
  "id_str" : "386205222873223168",
  "in_reply_to_user_id" : 87176766,
  "text" : "@jo_sayers @theteacherjames nice :)",
  "id" : 386205222873223168,
  "in_reply_to_status_id" : 386157512996581377,
  "created_at" : "2013-10-04 19:04:35 +0000",
  "in_reply_to_screen_name" : "jo_sayers",
  "in_reply_to_user_id_str" : "87176766",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "P\u00E9rez-Paredes",
      "screen_name" : "perezparedes",
      "indices" : [ 0, 13 ],
      "id_str" : "28528850",
      "id" : 28528850
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "385867866916274176",
  "geo" : { },
  "id_str" : "386099765802323969",
  "in_reply_to_user_id" : 28528850,
  "text" : "@perezparedes gracias por una scoop pascual :)",
  "id" : 386099765802323969,
  "in_reply_to_status_id" : 385867866916274176,
  "created_at" : "2013-10-04 12:05:32 +0000",
  "in_reply_to_screen_name" : "perezparedes",
  "in_reply_to_user_id_str" : "28528850",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Simpson",
      "screen_name" : "yearinthelifeof",
      "indices" : [ 3, 19 ],
      "id_str" : "78543378",
      "id" : 78543378
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELT",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "ELTchat",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "ESL",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/AcPF6xwlEn",
      "expanded_url" : "http:\/\/bit.ly\/17vI2tC",
      "display_url" : "bit.ly\/17vI2tC"
    } ]
  },
  "geo" : { },
  "id_str" : "385701589685510145",
  "text" : "RT @yearinthelifeof: How I prepare to give a workshop to teachers: TweetAs I mentioned a few days ago, I\u2019ll be a... http:\/\/t.co\/AcPF6xwlEn \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELT",
        "indices" : [ 118, 122 ]
      }, {
        "text" : "ELTchat",
        "indices" : [ 123, 131 ]
      }, {
        "text" : "ESL",
        "indices" : [ 132, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/AcPF6xwlEn",
        "expanded_url" : "http:\/\/bit.ly\/17vI2tC",
        "display_url" : "bit.ly\/17vI2tC"
      } ]
    },
    "geo" : { },
    "id_str" : "385697237252055040",
    "text" : "How I prepare to give a workshop to teachers: TweetAs I mentioned a few days ago, I\u2019ll be a... http:\/\/t.co\/AcPF6xwlEn #ELT #ELTchat #ESL",
    "id" : 385697237252055040,
    "created_at" : "2013-10-03 09:26:01 +0000",
    "user" : {
      "name" : "Adam Simpson",
      "screen_name" : "yearinthelifeof",
      "protected" : false,
      "id_str" : "78543378",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3631509371\/58d02c1bbadd12516d17de635652eb05_normal.jpeg",
      "id" : 78543378,
      "verified" : false
    }
  },
  "id" : 385701589685510145,
  "created_at" : "2013-10-03 09:43:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pete Warden",
      "screen_name" : "petewarden",
      "indices" : [ 82, 93 ],
      "id_str" : "14642896",
      "id" : 14642896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/sgg5DAYomh",
      "expanded_url" : "http:\/\/norvig.com\/chomsky.html",
      "display_url" : "norvig.com\/chomsky.html"
    } ]
  },
  "geo" : { },
  "id_str" : "385696034434736129",
  "text" : "On Chomsky and the Two Cultures of Statistical Learning http:\/\/t.co\/sgg5DAYomh ht @petewarden",
  "id" : 385696034434736129,
  "created_at" : "2013-10-03 09:21:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yolanda B. Schell",
      "screen_name" : "mattellman",
      "indices" : [ 0, 11 ],
      "id_str" : "725597315860434945",
      "id" : 725597315860434945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "385689617422635008",
  "geo" : { },
  "id_str" : "385692355367411713",
  "in_reply_to_user_id" : 394987109,
  "text" : "@mattellman nice happy packing :)",
  "id" : 385692355367411713,
  "in_reply_to_status_id" : 385689617422635008,
  "created_at" : "2013-10-03 09:06:37 +0000",
  "in_reply_to_screen_name" : "MatthewEllman",
  "in_reply_to_user_id_str" : "394987109",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yolanda B. Schell",
      "screen_name" : "mattellman",
      "indices" : [ 0, 11 ],
      "id_str" : "725597315860434945",
      "id" : 725597315860434945
    }, {
      "name" : "Monika Sobejko",
      "screen_name" : "SobejM",
      "indices" : [ 12, 19 ],
      "id_str" : "380504775",
      "id" : 380504775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "385686678461247488",
  "geo" : { },
  "id_str" : "385687364388933632",
  "in_reply_to_user_id" : 394987109,
  "text" : "@mattellman @SobejM thanks for share Matt; if u are up for a post let me know :)",
  "id" : 385687364388933632,
  "in_reply_to_status_id" : 385686678461247488,
  "created_at" : "2013-10-03 08:46:48 +0000",
  "in_reply_to_screen_name" : "MatthewEllman",
  "in_reply_to_user_id_str" : "394987109",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "natiserhost197",
      "screen_name" : "esl_robert",
      "indices" : [ 0, 11 ],
      "id_str" : "2982357761",
      "id" : 2982357761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "385628859741134848",
  "geo" : { },
  "id_str" : "385686883197394944",
  "in_reply_to_user_id" : 18526186,
  "text" : "@esl_robert sweet :)",
  "id" : 385686883197394944,
  "in_reply_to_status_id" : 385628859741134848,
  "created_at" : "2013-10-03 08:44:53 +0000",
  "in_reply_to_screen_name" : "RobertEPoole",
  "in_reply_to_user_id_str" : "18526186",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jersus Colmenares L.",
      "screen_name" : "jjcolmenaresl",
      "indices" : [ 0, 14 ],
      "id_str" : "195735983",
      "id" : 195735983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/gnEFqIwmh8",
      "expanded_url" : "https:\/\/plus.google.com\/u\/0\/communities\/101266284417587206243",
      "display_url" : "plus.google.com\/u\/0\/communitie\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "385666919350960128",
  "geo" : { },
  "id_str" : "385680584799825920",
  "in_reply_to_user_id" : 195735983,
  "text" : "@jjcolmenaresl thanks for the scoop :) please consider joining the google+ corpus ling and lang teach\/learn group https:\/\/t.co\/gnEFqIwmh8",
  "id" : 385680584799825920,
  "in_reply_to_status_id" : 385666919350960128,
  "created_at" : "2013-10-03 08:19:51 +0000",
  "in_reply_to_screen_name" : "jjcolmenaresl",
  "in_reply_to_user_id_str" : "195735983",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShareThis",
      "screen_name" : "ShareThis",
      "indices" : [ 40, 50 ],
      "id_str" : "14116807",
      "id" : 14116807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/b5aEZIkS49",
      "expanded_url" : "http:\/\/shar.es\/KDMcJ",
      "display_url" : "shar.es\/KDMcJ"
    } ]
  },
  "geo" : { },
  "id_str" : "385678414327209984",
  "text" : "Wearing Thin http:\/\/t.co\/b5aEZIkS49 via @sharethis",
  "id" : 385678414327209984,
  "created_at" : "2013-10-03 08:11:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "natiserhost197",
      "screen_name" : "esl_robert",
      "indices" : [ 0, 11 ],
      "id_str" : "2982357761",
      "id" : 2982357761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385527985089949696",
  "in_reply_to_user_id" : 18526186,
  "text" : "@esl_robert thanks for RT, would u be up for a post? :)",
  "id" : 385527985089949696,
  "created_at" : "2013-10-02 22:13:29 +0000",
  "in_reply_to_screen_name" : "RobertEPoole",
  "in_reply_to_user_id_str" : "18526186",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 63, 79 ],
      "id_str" : "823905",
      "id" : 823905
    }, {
      "name" : "Hannah Fry",
      "screen_name" : "FryRsquared",
      "indices" : [ 84, 96 ],
      "id_str" : "273375532",
      "id" : 273375532
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/eYOhET6lKC",
      "expanded_url" : "http:\/\/wp.me\/pt9Wa-ul",
      "display_url" : "wp.me\/pt9Wa-ul"
    } ]
  },
  "geo" : { },
  "id_str" : "385527712204324864",
  "text" : "The hotness-IQ tradeoff in academia http:\/\/t.co\/eYOhET6lKC via @wordpressdotcom h\/t @FryRsquared",
  "id" : 385527712204324864,
  "created_at" : "2013-10-02 22:12:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monika Sobejko",
      "screen_name" : "SobejM",
      "indices" : [ 66, 73 ],
      "id_str" : "380504775",
      "id" : 380504775
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elchat",
      "indices" : [ 97, 104 ]
    }, {
      "text" : "efl",
      "indices" : [ 105, 109 ]
    }, {
      "text" : "tesol",
      "indices" : [ 110, 116 ]
    }, {
      "text" : "esl",
      "indices" : [ 117, 121 ]
    }, {
      "text" : "tefl",
      "indices" : [ 122, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/KFCkYqkBbD",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-HO",
      "display_url" : "wp.me\/pgHyE-HO"
    } ]
  },
  "geo" : { },
  "id_str" : "385511528130027520",
  "text" : "Teaching writing with the aid of COCA \u2013 guest post Monika Sobejko @SobejM http:\/\/t.co\/KFCkYqkBbD #elchat #efl #tesol #esl #tefl",
  "id" : 385511528130027520,
  "created_at" : "2013-10-02 21:08:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jo Sayers",
      "screen_name" : "jo_sayers",
      "indices" : [ 0, 10 ],
      "id_str" : "87176766",
      "id" : 87176766
    }, {
      "name" : "James Taylor",
      "screen_name" : "theteacherjames",
      "indices" : [ 61, 77 ],
      "id_str" : "71746265",
      "id" : 71746265
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "385446867808436224",
  "geo" : { },
  "id_str" : "385448944605474816",
  "in_reply_to_user_id" : 87176766,
  "text" : "@jo_sayers great hope u sort it, will be there :) i remember @theteacherjames remarked once best conf he's ever been to!",
  "id" : 385448944605474816,
  "in_reply_to_status_id" : 385446867808436224,
  "created_at" : "2013-10-02 16:59:24 +0000",
  "in_reply_to_screen_name" : "jo_sayers",
  "in_reply_to_user_id_str" : "87176766",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jo Sayers",
      "screen_name" : "jo_sayers",
      "indices" : [ 0, 10 ],
      "id_str" : "87176766",
      "id" : 87176766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/A949b2PV2y",
      "expanded_url" : "http:\/\/xkcd.com\/1256\/",
      "display_url" : "xkcd.com\/1256\/"
    } ]
  },
  "in_reply_to_status_id_str" : "385424381276471297",
  "geo" : { },
  "id_str" : "385444683465248768",
  "in_reply_to_user_id" : 87176766,
  "text" : "@jo_sayers eh up, ya it's xkcd http:\/\/t.co\/A949b2PV2y",
  "id" : 385444683465248768,
  "in_reply_to_status_id" : 385424381276471297,
  "created_at" : "2013-10-02 16:42:28 +0000",
  "in_reply_to_screen_name" : "jo_sayers",
  "in_reply_to_user_id_str" : "87176766",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((David Traynier)))",
      "screen_name" : "DTraynier",
      "indices" : [ 3, 13 ],
      "id_str" : "317716198",
      "id" : 317716198
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dailymail",
      "indices" : [ 28, 38 ]
    }, {
      "text" : "newsnight",
      "indices" : [ 119, 129 ]
    }, {
      "text" : "campbell",
      "indices" : [ 130, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385174231727628288",
  "text" : "RT @DTraynier: God help the #dailymail: the moral highground they're being lectured from is a mountain of dead Iraqis. #newsnight #campbell",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/seesmic.com\/\" rel=\"nofollow\"\u003ESeesmic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "dailymail",
        "indices" : [ 13, 23 ]
      }, {
        "text" : "newsnight",
        "indices" : [ 104, 114 ]
      }, {
        "text" : "campbell",
        "indices" : [ 115, 124 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "385162503338360832",
    "text" : "God help the #dailymail: the moral highground they're being lectured from is a mountain of dead Iraqis. #newsnight #campbell",
    "id" : 385162503338360832,
    "created_at" : "2013-10-01 22:01:11 +0000",
    "user" : {
      "name" : "(((David Traynier)))",
      "screen_name" : "DTraynier",
      "protected" : false,
      "id_str" : "317716198",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727929911877480451\/fLuwL370_normal.jpg",
      "id" : 317716198,
      "verified" : false
    }
  },
  "id" : 385174231727628288,
  "created_at" : "2013-10-01 22:47:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
} ]