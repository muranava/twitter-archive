Grailbird.data.tweets_2012_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 87, 98 ],
      "id_str" : "282659955",
      "id" : 282659955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http:\/\/t.co\/kfDpiRHE",
      "expanded_url" : "http:\/\/myweb.tiscali.co.uk\/wordscape\/wordlist\/index.html",
      "display_url" : "myweb.tiscali.co.uk\/wordscape\/word\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "263633856647806977",
  "text" : "another grt find min pairs list http:\/\/t.co\/kfDpiRHE from comment by John Higgins on a @teflerinha post",
  "id" : 263633856647806977,
  "created_at" : "2012-10-31 13:29:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Patterson",
      "screen_name" : "Brad5Patterson",
      "indices" : [ 0, 15 ],
      "id_str" : "944237276",
      "id" : 944237276
    }, {
      "name" : "Learning with Texts",
      "screen_name" : "LWT_Project",
      "indices" : [ 16, 28 ],
      "id_str" : "325666179",
      "id" : 325666179
    }, {
      "name" : "Wiktorkompe",
      "screen_name" : "wiktor_k",
      "indices" : [ 29, 38 ],
      "id_str" : "733704413383168000",
      "id" : 733704413383168000
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "263602182211903488",
  "geo" : { },
  "id_str" : "263632098907271169",
  "in_reply_to_user_id" : 236921161,
  "text" : "@brad5patterson @LWT_Project @Wiktor_K thanks to you for initial link brad, :)",
  "id" : 263632098907271169,
  "in_reply_to_status_id" : 263602182211903488,
  "created_at" : "2012-10-31 13:22:45 +0000",
  "in_reply_to_screen_name" : "wordtov",
  "in_reply_to_user_id_str" : "236921161",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 0, 11 ],
      "id_str" : "282659955",
      "id" : 282659955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "263626218581139456",
  "geo" : { },
  "id_str" : "263630196228366336",
  "in_reply_to_user_id" : 282659955,
  "text" : "@teflerinha hehe yeah shame only limited time for discussion",
  "id" : 263630196228366336,
  "in_reply_to_status_id" : 263626218581139456,
  "created_at" : "2012-10-31 13:15:11 +0000",
  "in_reply_to_screen_name" : "teflerinha",
  "in_reply_to_user_id_str" : "282659955",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Petrie",
      "screen_name" : "teflgeek",
      "indices" : [ 0, 9 ],
      "id_str" : "305260555",
      "id" : 305260555
    }, {
      "name" : "Julian L'Enfant",
      "screen_name" : "Julian_LEnfant",
      "indices" : [ 10, 25 ],
      "id_str" : "467911010",
      "id" : 467911010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "263628376336646144",
  "geo" : { },
  "id_str" : "263629710813179905",
  "in_reply_to_user_id" : 305260555,
  "text" : "@teflgeek @Julian_LEnfant for sure a good chat topic :)",
  "id" : 263629710813179905,
  "in_reply_to_status_id" : 263628376336646144,
  "created_at" : "2012-10-31 13:13:15 +0000",
  "in_reply_to_screen_name" : "teflgeek",
  "in_reply_to_user_id_str" : "305260555",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Observer",
      "screen_name" : "Uncomformity",
      "indices" : [ 0, 13 ],
      "id_str" : "595362503",
      "id" : 595362503
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 22, 30 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "263627793240297472",
  "geo" : { },
  "id_str" : "263629006706974720",
  "in_reply_to_user_id" : 595362503,
  "text" : "@Uncomformity agreed! #eltchat",
  "id" : 263629006706974720,
  "in_reply_to_status_id" : 263627793240297472,
  "created_at" : "2012-10-31 13:10:27 +0000",
  "in_reply_to_screen_name" : "Uncomformity",
  "in_reply_to_user_id_str" : "595362503",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 16, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "263628271718105088",
  "text" : "many thanks all #eltchat",
  "id" : 263628271718105088,
  "created_at" : "2012-10-31 13:07:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Petrie",
      "screen_name" : "teflgeek",
      "indices" : [ 15, 24 ],
      "id_str" : "305260555",
      "id" : 305260555
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 70, 78 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 79, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "263628172464095232",
  "text" : "Julian_LEnfant @teflgeek an interesting other discussion for sure :0  #eltchat #eltchat",
  "id" : 263628172464095232,
  "created_at" : "2012-10-31 13:07:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 104, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "263626106857463809",
  "text" : "similar to authentic txt vs coursebook txt discussions, is there a 'real' teacher vs 'classrm' teacher? #eltchat",
  "id" : 263626106857463809,
  "created_at" : "2012-10-31 12:58:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 45, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "263622932314587136",
  "text" : "what would make up a performance skill set?\n #eltchat",
  "id" : 263622932314587136,
  "created_at" : "2012-10-31 12:46:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 97, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "263619380489895936",
  "text" : "as long as keep learning objective in mind \"performance\", \"being a gd laugh\" tweaks\/hacks useful #eltchat",
  "id" : 263619380489895936,
  "created_at" : "2012-10-31 12:32:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Learning with Texts",
      "screen_name" : "LWT_Project",
      "indices" : [ 53, 65 ],
      "id_str" : "325666179",
      "id" : 325666179
    }, {
      "name" : "Wiktorkompe",
      "screen_name" : "wiktor_k",
      "indices" : [ 101, 110 ],
      "id_str" : "733704413383168000",
      "id" : 733704413383168000
    }, {
      "name" : "Brad Patterson",
      "screen_name" : "Brad5Patterson",
      "indices" : [ 115, 130 ],
      "id_str" : "944237276",
      "id" : 944237276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/8t3lxfZ6",
      "expanded_url" : "http:\/\/lwt.sourceforge.net\/#learn",
      "display_url" : "lwt.sourceforge.net\/#learn"
    } ]
  },
  "geo" : { },
  "id_str" : "263587001876504576",
  "text" : "reminder of power of hypertext, new tool to explore: @LWT_Project http:\/\/t.co\/8t3lxfZ6\u00A0 via Joel via @Wiktor_K via @brad5patterson",
  "id" : 263587001876504576,
  "created_at" : "2012-10-31 10:23:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Huw Jarvis",
      "screen_name" : "TESOLacademic",
      "indices" : [ 3, 17 ],
      "id_str" : "43409552",
      "id" : 43409552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/3JcspuFN",
      "expanded_url" : "http:\/\/bit.ly\/I9YC65",
      "display_url" : "bit.ly\/I9YC65"
    } ]
  },
  "geo" : { },
  "id_str" : "263407678372581376",
  "text" : "RT @TESOLacademic\nEnglish belongs to everyone? http:\/\/t.co\/3JcspuFN &lt;--sensible corrective for elt world!",
  "id" : 263407678372581376,
  "created_at" : "2012-10-30 22:30:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http:\/\/t.co\/XnNaNCFq",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=O9C7yYomVuo",
      "display_url" : "youtube.com\/watch?v=O9C7yY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "263372227523796992",
  "text" : "James Bond Death Match http:\/\/t.co\/XnNaNCFq HT@boingboing&lt;--crisp editing!",
  "id" : 263372227523796992,
  "created_at" : "2012-10-30 20:10:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valentina Morgana",
      "screen_name" : "vmorgana",
      "indices" : [ 0, 9 ],
      "id_str" : "62479177",
      "id" : 62479177
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "263016690588200961",
  "geo" : { },
  "id_str" : "263209044762849281",
  "in_reply_to_user_id" : 62479177,
  "text" : "@vmorgana great do let me know how it went :)",
  "id" : 263209044762849281,
  "in_reply_to_status_id" : 263016690588200961,
  "created_at" : "2012-10-30 09:21:41 +0000",
  "in_reply_to_screen_name" : "vmorgana",
  "in_reply_to_user_id_str" : "62479177",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol Goodey",
      "screen_name" : "cgoodey",
      "indices" : [ 0, 8 ],
      "id_str" : "26606833",
      "id" : 26606833
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/90dIaUzY",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=jp2ehUOV9cQ&feature=player_embedded",
      "display_url" : "youtube.com\/watch?v=jp2ehU\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "262889700262555648",
  "geo" : { },
  "id_str" : "262978229797781504",
  "in_reply_to_user_id" : 26606833,
  "text" : "@cgoodey available for nonUK http:\/\/t.co\/90dIaUzY; great docu. curious it was shown on beeb at same time as trump announcement re obama? :\/",
  "id" : 262978229797781504,
  "in_reply_to_status_id" : 262889700262555648,
  "created_at" : "2012-10-29 18:04:30 +0000",
  "in_reply_to_screen_name" : "cgoodey",
  "in_reply_to_user_id_str" : "26606833",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valentina Morgana",
      "screen_name" : "vmorgana",
      "indices" : [ 0, 9 ],
      "id_str" : "62479177",
      "id" : 62479177
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262963837408514048",
  "in_reply_to_user_id" : 62479177,
  "text" : "@vmorgana thanks for the like on my last blog post valentina, hope u r well.",
  "id" : 262963837408514048,
  "created_at" : "2012-10-29 17:07:19 +0000",
  "in_reply_to_screen_name" : "vmorgana",
  "in_reply_to_user_id_str" : "62479177",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 0, 14 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "262670216654364673",
  "geo" : { },
  "id_str" : "262698760256229376",
  "in_reply_to_user_id" : 25388528,
  "text" : "@audreywatters hmm suppose a zombie apocalypse will balance out the rise of the terminator drone machines in pakistan and afghanistan? :\/",
  "id" : 262698760256229376,
  "in_reply_to_status_id" : 262670216654364673,
  "created_at" : "2012-10-28 23:33:59 +0000",
  "in_reply_to_screen_name" : "audreywatters",
  "in_reply_to_user_id_str" : "25388528",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 82, 90 ]
    }, {
      "text" : "elt",
      "indices" : [ 91, 95 ]
    }, {
      "text" : "engchat",
      "indices" : [ 96, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/hAa4YGmf",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-ad",
      "display_url" : "wp.me\/pgHyE-ad"
    } ]
  },
  "geo" : { },
  "id_str" : "262694602979565568",
  "text" : "video to help with giving directions language, new blog post http:\/\/t.co\/hAa4YGmf #eltchat #elt #engchat",
  "id" : 262694602979565568,
  "created_at" : "2012-10-28 23:17:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/OSx8d0yx",
      "expanded_url" : "http:\/\/blog.westminster.ac.uk\/celt\/",
      "display_url" : "blog.westminster.ac.uk\/celt\/"
    } ]
  },
  "geo" : { },
  "id_str" : "262161355497406464",
  "text" : "RT @CELTtraining What's good, better and best in teaching? Anything beyond best?! New blog post. http:\/\/t.co\/OSx8d0yx &lt;-nice challenge",
  "id" : 262161355497406464,
  "created_at" : "2012-10-27 11:58:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 0, 11 ],
      "id_str" : "282659955",
      "id" : 282659955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261830975330320384",
  "in_reply_to_user_id" : 282659955,
  "text" : "@teflerinha thxs for RT and mention, hope ur friday has been good.",
  "id" : 261830975330320384,
  "created_at" : "2012-10-26 14:05:43 +0000",
  "in_reply_to_screen_name" : "teflerinha",
  "in_reply_to_user_id_str" : "282659955",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 68, 79 ],
      "id_str" : "282659955",
      "id" : 282659955
    }, {
      "name" : "Hancock McDonald ELT",
      "screen_name" : "HancockMcDonald",
      "indices" : [ 95, 111 ],
      "id_str" : "552929354",
      "id" : 552929354
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/Wkb9Y0mL",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-9S",
      "display_url" : "wp.me\/pgHyE-9S"
    } ]
  },
  "geo" : { },
  "id_str" : "261610453363462144",
  "text" : "update 3 on my accents post (http:\/\/t.co\/Wkb9Y0mL ) referencing via @teflerinha Mark Hancock's @HancockMcDonald vulnerable phonemes guide",
  "id" : 261610453363462144,
  "created_at" : "2012-10-25 23:29:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Phelps",
      "screen_name" : "pterolaur",
      "indices" : [ 0, 10 ],
      "id_str" : "90093887",
      "id" : 90093887
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mayusethatinaclass",
      "indices" : [ 16, 35 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261555050034388992",
  "geo" : { },
  "id_str" : "261555688214511617",
  "in_reply_to_user_id" : 90093887,
  "text" : "@pterolaur hehe #mayusethatinaclass",
  "id" : 261555688214511617,
  "in_reply_to_status_id" : 261555050034388992,
  "created_at" : "2012-10-25 19:51:50 +0000",
  "in_reply_to_screen_name" : "pterolaur",
  "in_reply_to_user_id_str" : "90093887",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261528413670604800",
  "geo" : { },
  "id_str" : "261552934968508416",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt hey hope is not too late to say Happy Birthday! hope you have\/had a good one :)",
  "id" : 261552934968508416,
  "in_reply_to_status_id" : 261528413670604800,
  "created_at" : "2012-10-25 19:40:53 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 0, 11 ],
      "id_str" : "282659955",
      "id" : 282659955
    }, {
      "name" : "Vicky Loras",
      "screen_name" : "vickyloras",
      "indices" : [ 12, 23 ],
      "id_str" : "95957241",
      "id" : 95957241
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchatpodcasts",
      "indices" : [ 24, 40 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "260830197358661633",
  "geo" : { },
  "id_str" : "260831670113021954",
  "in_reply_to_user_id" : 282659955,
  "text" : "@teflerinha @vickyloras #eltchatpodcasts definitely one of the finer elt things on the net :) can't wait.",
  "id" : 260831670113021954,
  "in_reply_to_status_id" : 260830197358661633,
  "created_at" : "2012-10-23 19:54:50 +0000",
  "in_reply_to_screen_name" : "teflerinha",
  "in_reply_to_user_id_str" : "282659955",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 3, 17 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "260800240339275776",
  "geo" : { },
  "id_str" : "260828367333498880",
  "in_reply_to_user_id" : 25388528,
  "text" : "MT @audreywatters Apple touts the rapid turnout of new iPads. I'd hope schools see this as a warning sign about their hardware investments",
  "id" : 260828367333498880,
  "in_reply_to_status_id" : 260800240339275776,
  "created_at" : "2012-10-23 19:41:43 +0000",
  "in_reply_to_screen_name" : "audreywatters",
  "in_reply_to_user_id_str" : "25388528",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 45, 55 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/YMWclkeh",
      "expanded_url" : "http:\/\/www.medialens.org\/index.php?option=com_content&view=article&id=702:bad-pharma-bad-journalism&catid=25:alerts-2012&Itemid=69",
      "display_url" : "medialens.org\/index.php?opti\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "260744332032737281",
  "text" : "great new post Bad Pharma, Bad Journalism by @medialens http:\/\/t.co\/YMWclkeh",
  "id" : 260744332032737281,
  "created_at" : "2012-10-23 14:07:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 26, 38 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "260737475788541953",
  "text" : "thanks to livinglearning (@AnneHendler?)  for like of my lqst blog post :)",
  "id" : 260737475788541953,
  "created_at" : "2012-10-23 13:40:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/90dIaUzY",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=jp2ehUOV9cQ&feature=player_embedded",
      "display_url" : "youtube.com\/watch?v=jp2ehU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "260688900517941248",
  "text" : "watching fascinating doc You've been Trumped http:\/\/t.co\/90dIaUzY",
  "id" : 260688900517941248,
  "created_at" : "2012-10-23 10:27:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "phil wade",
      "screen_name" : "phil3wade",
      "indices" : [ 0, 10 ],
      "id_str" : "248864761",
      "id" : 248864761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "260432964767318016",
  "geo" : { },
  "id_str" : "260435742541639680",
  "in_reply_to_user_id" : 248864761,
  "text" : "@phil3wade how do you get recommendations for movies apart from friends? mags like telerama i find useful. imdb ratings are a no go :)",
  "id" : 260435742541639680,
  "in_reply_to_status_id" : 260432964767318016,
  "created_at" : "2012-10-22 17:41:34 +0000",
  "in_reply_to_screen_name" : "phil3wade",
  "in_reply_to_user_id_str" : "248864761",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/HTz2Kf4K",
      "expanded_url" : "http:\/\/blog.mysciencework.com\/2012\/10\/02\/open-access-week-2012-deux-evenements-a-paris.html",
      "display_url" : "blog.mysciencework.com\/2012\/10\/02\/ope\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "260434714517716993",
  "text" : "Two Open Access events in Paris this week http:\/\/t.co\/HTz2Kf4K",
  "id" : 260434714517716993,
  "created_at" : "2012-10-22 17:37:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Phelps",
      "screen_name" : "pterolaur",
      "indices" : [ 0, 10 ],
      "id_str" : "90093887",
      "id" : 90093887
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "260414298441003009",
  "geo" : { },
  "id_str" : "260431699333230593",
  "in_reply_to_user_id" : 90093887,
  "text" : "@pterolaur i know that feeling! differences btw teacher perception and sts does vary a lot.",
  "id" : 260431699333230593,
  "in_reply_to_status_id" : 260414298441003009,
  "created_at" : "2012-10-22 17:25:30 +0000",
  "in_reply_to_screen_name" : "pterolaur",
  "in_reply_to_user_id_str" : "90093887",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "phil wade",
      "screen_name" : "phil3wade",
      "indices" : [ 0, 10 ],
      "id_str" : "248864761",
      "id" : 248864761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "260398281522311168",
  "geo" : { },
  "id_str" : "260428268031840257",
  "in_reply_to_user_id" : 248864761,
  "text" : "@phil3wade not really,  age old question of popular vs quality, will taken2 even been remembered in a few years time? :0",
  "id" : 260428268031840257,
  "in_reply_to_status_id" : 260398281522311168,
  "created_at" : "2012-10-22 17:11:52 +0000",
  "in_reply_to_screen_name" : "phil3wade",
  "in_reply_to_user_id_str" : "248864761",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "phil wade",
      "screen_name" : "phil3wade",
      "indices" : [ 0, 10 ],
      "id_str" : "248864761",
      "id" : 248864761
    }, {
      "name" : "Bethany Cagnol",
      "screen_name" : "bethcagnol",
      "indices" : [ 11, 22 ],
      "id_str" : "27641720",
      "id" : 27641720
    }, {
      "name" : "C Rebuffet-Broadus",
      "screen_name" : "RebuffetBroadus",
      "indices" : [ 23, 39 ],
      "id_str" : "22635290",
      "id" : 22635290
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "259332212997095424",
  "geo" : { },
  "id_str" : "259334864552214528",
  "in_reply_to_user_id" : 248864761,
  "text" : "@phil3wade @bethcagnol @RebuffetBroadus there are 3 inc me!",
  "id" : 259334864552214528,
  "in_reply_to_status_id" : 259332212997095424,
  "created_at" : "2012-10-19 16:47:04 +0000",
  "in_reply_to_screen_name" : "phil3wade",
  "in_reply_to_user_id_str" : "248864761",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TESOL France",
      "screen_name" : "TESOLFrance",
      "indices" : [ 3, 15 ],
      "id_str" : "70341872",
      "id" : 70341872
    }, {
      "name" : "C Rebuffet-Broadus",
      "screen_name" : "RebuffetBroadus",
      "indices" : [ 47, 63 ],
      "id_str" : "22635290",
      "id" : 22635290
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 139 ],
      "url" : "https:\/\/t.co\/iinO1aYK",
      "expanded_url" : "https:\/\/meet38122280.adobeconnect.com\/_a1084276364\/christina",
      "display_url" : "meet38122280.adobeconnect.com\/_a1084276364\/c\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "259313360603058178",
  "geo" : { },
  "id_str" : "259326040030187520",
  "in_reply_to_user_id" : 70341872,
  "text" : "MT @TESOLFrance at 18:30 CET FREE webinar with @RebuffetBroadus Dogme in the Classroom. Log on w\/your name as a guest:https:\/\/t.co\/iinO1aYK",
  "id" : 259326040030187520,
  "in_reply_to_status_id" : 259313360603058178,
  "created_at" : "2012-10-19 16:12:00 +0000",
  "in_reply_to_screen_name" : "TESOLFrance",
  "in_reply_to_user_id_str" : "70341872",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    }, {
      "name" : "James Taylor",
      "screen_name" : "theteacherjames",
      "indices" : [ 16, 32 ],
      "id_str" : "71746265",
      "id" : 71746265
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 56, 64 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "259286225393963009",
  "geo" : { },
  "id_str" : "259322664194285569",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson @theteacherjames looking forward to it, #eltchat podcasts RULE :)",
  "id" : 259322664194285569,
  "in_reply_to_status_id" : 259286225393963009,
  "created_at" : "2012-10-19 15:58:35 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Colleen Brown",
      "screen_name" : "c_brune",
      "indices" : [ 50, 58 ],
      "id_str" : "34247658",
      "id" : 34247658
    }, {
      "name" : "TESOL France",
      "screen_name" : "TESOLFrance",
      "indices" : [ 80, 92 ],
      "id_str" : "70341872",
      "id" : 70341872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/wwz7172z",
      "expanded_url" : "http:\/\/www.tesol-france.org\/sustainableteaching.php?PHPSESSID=39651fca08e1b109be1abb90b0cc39ea",
      "display_url" : "tesol-france.org\/sustainabletea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "259319470542168064",
  "text" : "Paris teachers on Sat 20 Oct be sure to check out @c_brune Sustainable Teaching @TESOLFrance wrkshop http:\/\/t.co\/wwz7172z",
  "id" : 259319470542168064,
  "created_at" : "2012-10-19 15:45:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    }, {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 12, 23 ],
      "id_str" : "282659955",
      "id" : 282659955
    }, {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 24, 35 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ff",
      "indices" : [ 56, 59 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "259058257988042752",
  "geo" : { },
  "id_str" : "259233650170810368",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow @teflerinha @leoselivan dang no need to say #ff these peeps for people in the know, if u'r not then get the know!",
  "id" : 259233650170810368,
  "in_reply_to_status_id" : 259058257988042752,
  "created_at" : "2012-10-19 10:04:53 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "259021847650263041",
  "geo" : { },
  "id_str" : "259233258510893056",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan great be happy to get any comments :)",
  "id" : 259233258510893056,
  "in_reply_to_status_id" : 259021847650263041,
  "created_at" : "2012-10-19 10:03:19 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "259019954001702912",
  "geo" : { },
  "id_str" : "259021470469074945",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan yes though that lexical cards post does not seem to be linked there?",
  "id" : 259021470469074945,
  "in_reply_to_status_id" : 259019954001702912,
  "created_at" : "2012-10-18 20:01:45 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeachingEnglish",
      "indices" : [ 83, 99 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "259017254304366594",
  "geo" : { },
  "id_str" : "259018222651711489",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan yep that was the one, do you have a section linking frm yr blog to the #TeachingEnglish articles you've done?",
  "id" : 259018222651711489,
  "in_reply_to_status_id" : 259017254304366594,
  "created_at" : "2012-10-18 19:48:51 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "259013653502779392",
  "geo" : { },
  "id_str" : "259015108469067777",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan speaking of great blogs, hi leo! wanted to say thx for ref to JALT Lang teacher issue on Vocab frm yr fab post on lexical cards.",
  "id" : 259015108469067777,
  "in_reply_to_status_id" : 259013653502779392,
  "created_at" : "2012-10-18 19:36:28 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 0, 11 ],
      "id_str" : "282659955",
      "id" : 282659955
    }, {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 12, 23 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "258947363480158211",
  "geo" : { },
  "id_str" : "259011021937717248",
  "in_reply_to_user_id" : 282659955,
  "text" : "@teflerinha @kevchanwow am lucky to be able to read both of your great blogs, keeps me going in the classroom :)",
  "id" : 259011021937717248,
  "in_reply_to_status_id" : 258947363480158211,
  "created_at" : "2012-10-18 19:20:14 +0000",
  "in_reply_to_screen_name" : "teflerinha",
  "in_reply_to_user_id_str" : "282659955",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 0, 11 ],
      "id_str" : "282659955",
      "id" : 282659955
    }, {
      "name" : "TESOL Intl Assn",
      "screen_name" : "TESOL_Assn",
      "indices" : [ 12, 23 ],
      "id_str" : "21091012",
      "id" : 21091012
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "258947222480232448",
  "geo" : { },
  "id_str" : "259010576414556160",
  "in_reply_to_user_id" : 282659955,
  "text" : "@teflerinha @TESOL_Assn my pleasure :)",
  "id" : 259010576414556160,
  "in_reply_to_status_id" : 258947222480232448,
  "created_at" : "2012-10-18 19:18:28 +0000",
  "in_reply_to_screen_name" : "teflerinha",
  "in_reply_to_user_id_str" : "282659955",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    }, {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 13, 24 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "258961973755125762",
  "geo" : { },
  "id_str" : "259010174877044736",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler @kevchanwow glad u both liked the post! :)",
  "id" : 259010174877044736,
  "in_reply_to_status_id" : 258961973755125762,
  "created_at" : "2012-10-18 19:16:52 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 54, 65 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/Wkb9Y0mL",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-9S",
      "display_url" : "wp.me\/pgHyE-9S"
    } ]
  },
  "geo" : { },
  "id_str" : "258933959021457408",
  "text" : "another small update http:\/\/t.co\/Wkb9Y0mL, linking to @kevchanwow most recent post on listening",
  "id" : 258933959021457408,
  "created_at" : "2012-10-18 14:14:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "258714769572372480",
  "text" : "slowly getting used to an old mac after pc laptop screen packed in; but need to rely on 3rd party tools to see web videos and the like!",
  "id" : 258714769572372480,
  "created_at" : "2012-10-17 23:43:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TESOL Intl Assn",
      "screen_name" : "TESOL_Assn",
      "indices" : [ 83, 94 ],
      "id_str" : "21091012",
      "id" : 21091012
    }, {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 100, 111 ],
      "id_str" : "282659955",
      "id" : 282659955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/Wkb9Y0mL",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-9S",
      "display_url" : "wp.me\/pgHyE-9S"
    } ]
  },
  "geo" : { },
  "id_str" : "258691057087291392",
  "text" : "short update on post http:\/\/t.co\/Wkb9Y0mL re accents and comprehensibility with HT @TESOL_Assn also @teflerinha is linked in original post",
  "id" : 258691057087291392,
  "created_at" : "2012-10-17 22:08:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Levine",
      "screen_name" : "cogdog",
      "indices" : [ 0, 7 ],
      "id_str" : "740343",
      "id" : 740343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/sksT4P5I",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-9q",
      "display_url" : "wp.me\/pgHyE-9q"
    } ]
  },
  "in_reply_to_status_id_str" : "258670968954839041",
  "geo" : { },
  "id_str" : "258677848078942208",
  "in_reply_to_user_id" : 740343,
  "text" : "@cogdog i describe a little here  http:\/\/t.co\/sksT4P5I about it",
  "id" : 258677848078942208,
  "in_reply_to_status_id" : 258670968954839041,
  "created_at" : "2012-10-17 21:16:19 +0000",
  "in_reply_to_screen_name" : "cogdog",
  "in_reply_to_user_id_str" : "740343",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/6zZOdSl4",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=DkGMY63FF3Q&feature=player_embedded",
      "display_url" : "youtube.com\/watch?v=DkGMY6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "258675959631314944",
  "text" : "http:\/\/t.co\/6zZOdSl4 &lt;--Onion Talks new source of short presentation delivery models and funny to boot :0",
  "id" : 258675959631314944,
  "created_at" : "2012-10-17 21:08:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 8, 16 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "258675095155916800",
  "text" : "thx all #eltchat",
  "id" : 258675095155916800,
  "created_at" : "2012-10-17 21:05:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 71, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "258664591335247872",
  "text" : "any refs to recent review of research evidence about error correction? #eltchat",
  "id" : 258664591335247872,
  "created_at" : "2012-10-17 20:23:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Levine",
      "screen_name" : "cogdog",
      "indices" : [ 3, 10 ],
      "id_str" : "740343",
      "id" : 740343
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opened12",
      "indices" : [ 45, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/jroZM3Qt",
      "expanded_url" : "http:\/\/bit.ly\/S3UZCN",
      "display_url" : "bit.ly\/S3UZCN"
    } ]
  },
  "in_reply_to_status_id_str" : "258638091709972480",
  "geo" : { },
  "id_str" : "258645005680402432",
  "in_reply_to_user_id" : 740343,
  "text" : "MT @cogdog And today's TreasureBox Prompt at #opened12 http:\/\/t.co\/jroZM3Qt &lt;fab ed conf idea, i have used piratebox in class to share files",
  "id" : 258645005680402432,
  "in_reply_to_status_id" : 258638091709972480,
  "created_at" : "2012-10-17 19:05:49 +0000",
  "in_reply_to_screen_name" : "cogdog",
  "in_reply_to_user_id_str" : "740343",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/Wkb9Y0mL",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-9S",
      "display_url" : "wp.me\/pgHyE-9S"
    } ]
  },
  "geo" : { },
  "id_str" : "258615519836504065",
  "text" : "Using the IDEA accent archive in one-to-one classes http:\/\/t.co\/Wkb9Y0mL &lt;--looking for some listening tips",
  "id" : 258615519836504065,
  "created_at" : "2012-10-17 17:08:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/X0LkTdyw",
      "expanded_url" : "http:\/\/www.wired.com\/gadgetlab\/2012\/10\/1-annoying-technologies-as-chosen-by-the-wired-commenters\/",
      "display_url" : "wired.com\/gadgetlab\/2012\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "258575426174189568",
  "text" : "12 Annoying Technologies as Chosen by the Wired Commenters http:\/\/t.co\/X0LkTdyw &lt;--potential scan\/skim reading exercise",
  "id" : 258575426174189568,
  "created_at" : "2012-10-17 14:29:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Stults",
      "screen_name" : "JustinStults",
      "indices" : [ 0, 13 ],
      "id_str" : "294217312",
      "id" : 294217312
    }, {
      "name" : "ISCOM",
      "screen_name" : "iscom",
      "indices" : [ 14, 20 ],
      "id_str" : "11930312",
      "id" : 11930312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "258502045538058240",
  "geo" : { },
  "id_str" : "258503914469593088",
  "in_reply_to_user_id" : 294217312,
  "text" : "@JustinStults @iscom will future time-travel paradox stories replace well known German politician with well known billionaire geek?  :\/",
  "id" : 258503914469593088,
  "in_reply_to_status_id" : 258502045538058240,
  "created_at" : "2012-10-17 09:45:10 +0000",
  "in_reply_to_screen_name" : "JustinStults",
  "in_reply_to_user_id_str" : "294217312",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "funwithnumbers",
      "indices" : [ 85, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "258501988545859584",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow getting them to calculate and then say their age in seconds is great fun #funwithnumbers",
  "id" : 258501988545859584,
  "created_at" : "2012-10-17 09:37:31 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/U9qJRyM9",
      "expanded_url" : "http:\/\/theotherthingsmatter.blogspot.com\/2012\/04\/measurements-short-story-for-ells.html",
      "display_url" : "theotherthingsmatter.blogspot.com\/2012\/04\/measur\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "258499746132545536",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow measurements story went down well again with engineering sts http:\/\/t.co\/U9qJRyM9",
  "id" : 258499746132545536,
  "created_at" : "2012-10-17 09:28:36 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "258259306137411585",
  "geo" : { },
  "id_str" : "258287187655794688",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson thanks for sharing :)",
  "id" : 258287187655794688,
  "in_reply_to_status_id" : 258259306137411585,
  "created_at" : "2012-10-16 19:23:58 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 51, 55 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 56, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/Wkb9Y0mL",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-9S",
      "display_url" : "wp.me\/pgHyE-9S"
    } ]
  },
  "geo" : { },
  "id_str" : "258143176961970177",
  "text" : "Using the IDEA accent archive http:\/\/t.co\/Wkb9Y0mL #elt #eltchat &gt; how do you use it?",
  "id" : 258143176961970177,
  "created_at" : "2012-10-16 09:51:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "257134300451966976",
  "geo" : { },
  "id_str" : "257192221252677633",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt was thinking of 500-600 words; was looking at just using DL, Sum and Highlighter roles as most of the texts are web tech news",
  "id" : 257192221252677633,
  "in_reply_to_status_id" : 257134300451966976,
  "created_at" : "2012-10-13 18:52:58 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "Stephanie McIntosh",
      "screen_name" : "purple_steph",
      "indices" : [ 12, 25 ],
      "id_str" : "18678010",
      "id" : 18678010
    }, {
      "name" : "Sandy Millin",
      "screen_name" : "sandymillin",
      "indices" : [ 26, 38 ],
      "id_str" : "144236944",
      "id" : 144236944
    }, {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 39, 50 ],
      "id_str" : "282659955",
      "id" : 282659955
    }, {
      "name" : "Carol Goodey",
      "screen_name" : "cgoodey",
      "indices" : [ 51, 59 ],
      "id_str" : "26606833",
      "id" : 26606833
    }, {
      "name" : "Thomas Lloyd",
      "screen_name" : "teacherthom",
      "indices" : [ 60, 72 ],
      "id_str" : "346448868",
      "id" : 346448868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256834326619095040",
  "geo" : { },
  "id_str" : "257083727363059713",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan @purple_steph @sandymillin @teflerinha @cgoodey @teacherthom cheers leo, maybe c u in paris!",
  "id" : 257083727363059713,
  "in_reply_to_status_id" : 256834326619095040,
  "created_at" : "2012-10-13 11:41:51 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "257083546546618368",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt hi, re ARC, has anyone adapted it for short blog like articles?",
  "id" : 257083546546618368,
  "created_at" : "2012-10-13 11:41:08 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 19, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256137378991833088",
  "text" : "many thanks all :) #eltchat",
  "id" : 256137378991833088,
  "created_at" : "2012-10-10 21:01:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 125, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256134604552024065",
  "text" : "from my understanding mindfulness as concept is simple the practice is hard, so i don't think there is danger of reducing it #eltchat",
  "id" : 256134604552024065,
  "created_at" : "2012-10-10 20:50:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 73, 83 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 84, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256131643469864963",
  "text" : "for further reading i would recommend the cogitation series of essays by @medialens #eltchat",
  "id" : 256131643469864963,
  "created_at" : "2012-10-10 20:38:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Lloyd",
      "screen_name" : "teacherthom",
      "indices" : [ 0, 12 ],
      "id_str" : "346448868",
      "id" : 346448868
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 72, 80 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256128837119770624",
  "geo" : { },
  "id_str" : "256129218226823168",
  "in_reply_to_user_id" : 346448868,
  "text" : "@teacherthom yes often that \"mental noise\" is deliberately generated... #eltchat",
  "id" : 256129218226823168,
  "in_reply_to_status_id" : 256128837119770624,
  "created_at" : "2012-10-10 20:28:58 +0000",
  "in_reply_to_screen_name" : "teacherthom",
  "in_reply_to_user_id_str" : "346448868",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 109, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256128463151431681",
  "text" : "maybe we can look at what aspects of a class hinders \"mindfulness\" like the way everyday life situations do? #eltchat",
  "id" : 256128463151431681,
  "created_at" : "2012-10-10 20:25:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    }, {
      "name" : "Boing Boing",
      "screen_name" : "BoingBoing",
      "indices" : [ 16, 27 ],
      "id_str" : "5971922",
      "id" : 5971922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255628508775211009",
  "geo" : { },
  "id_str" : "255631415343988737",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson @BoingBoing  yes and it looks very successful",
  "id" : 255631415343988737,
  "in_reply_to_status_id" : 255628508775211009,
  "created_at" : "2012-10-09 11:30:53 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boing Boing",
      "screen_name" : "BoingBoing",
      "indices" : [ 42, 53 ],
      "id_str" : "5971922",
      "id" : 5971922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http:\/\/t.co\/mtXB5lN7",
      "expanded_url" : "http:\/\/imgur.com\/a\/lUWTG#Jl086",
      "display_url" : "imgur.com\/a\/lUWTG#Jl086"
    } ]
  },
  "geo" : { },
  "id_str" : "255630636423991296",
  "text" : "prank tube signs http:\/\/t.co\/mtXB5lN7 via @boingboing",
  "id" : 255630636423991296,
  "created_at" : "2012-10-09 11:27:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boing Boing",
      "screen_name" : "BoingBoing",
      "indices" : [ 68, 79 ],
      "id_str" : "5971922",
      "id" : 5971922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/7Xfie1JN",
      "expanded_url" : "http:\/\/www.kickstarter.com\/projects\/teachrdan\/how-to-teach-adults-a-free-beautiful-e-book",
      "display_url" : "kickstarter.com\/projects\/teach\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "255627681956245506",
  "text" : "using kickstarter to fund a teaching book: http:\/\/t.co\/7Xfie1JN via @boingboing",
  "id" : 255627681956245506,
  "created_at" : "2012-10-09 11:16:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sophia Khan",
      "screen_name" : "SophiaKhan4",
      "indices" : [ 0, 12 ],
      "id_str" : "351390617",
      "id" : 351390617
    }, {
      "name" : "Stephanie McIntosh",
      "screen_name" : "purple_steph",
      "indices" : [ 13, 26 ],
      "id_str" : "18678010",
      "id" : 18678010
    }, {
      "name" : "Alex Grevett",
      "screen_name" : "breathyvowel",
      "indices" : [ 27, 40 ],
      "id_str" : "237547177",
      "id" : 237547177
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "theoldonesrthebest",
      "indices" : [ 111, 130 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255316518521405442",
  "geo" : { },
  "id_str" : "255342368356720640",
  "in_reply_to_user_id" : 351390617,
  "text" : "@SophiaKhan4 @purple_steph @breathyvowel \/The bowler's Holding the batsmen's Willy\/ sorry could not resist! :) #theoldonesrthebest",
  "id" : 255342368356720640,
  "in_reply_to_status_id" : 255316518521405442,
  "created_at" : "2012-10-08 16:22:19 +0000",
  "in_reply_to_screen_name" : "SophiaKhan4",
  "in_reply_to_user_id_str" : "351390617",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Taylor",
      "screen_name" : "theteacherjames",
      "indices" : [ 0, 16 ],
      "id_str" : "71746265",
      "id" : 71746265
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253925637356675072",
  "geo" : { },
  "id_str" : "253931765905911808",
  "in_reply_to_user_id" : 71746265,
  "text" : "@theteacherjames the think blog sounds interesting, but am getting a 404?",
  "id" : 253931765905911808,
  "in_reply_to_status_id" : 253925637356675072,
  "created_at" : "2012-10-04 18:57:05 +0000",
  "in_reply_to_screen_name" : "theteacherjames",
  "in_reply_to_user_id_str" : "71746265",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moira Hunter",
      "screen_name" : "MoiraH",
      "indices" : [ 0, 7 ],
      "id_str" : "6206432",
      "id" : 6206432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253559899722772480",
  "in_reply_to_user_id" : 6206432,
  "text" : "@MoiraH hi moira can't DM u seems u got knocked off following?",
  "id" : 253559899722772480,
  "created_at" : "2012-10-03 18:19:25 +0000",
  "in_reply_to_screen_name" : "MoiraH",
  "in_reply_to_user_id_str" : "6206432",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 0, 11 ],
      "id_str" : "282659955",
      "id" : 282659955
    }, {
      "name" : "TEFL.net",
      "screen_name" : "TEFL",
      "indices" : [ 12, 17 ],
      "id_str" : "19223632",
      "id" : 19223632
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "blowyourtrumpetwhenucan",
      "indices" : [ 64, 88 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253157210853605376",
  "geo" : { },
  "id_str" : "253225273691095040",
  "in_reply_to_user_id" : 282659955,
  "text" : "@teflerinha @TEFL nice one rachael well deserved recognition :) #blowyourtrumpetwhenucan",
  "id" : 253225273691095040,
  "in_reply_to_status_id" : 253157210853605376,
  "created_at" : "2012-10-02 20:09:44 +0000",
  "in_reply_to_screen_name" : "teflerinha",
  "in_reply_to_user_id_str" : "282659955",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
} ]