Grailbird.data.tweets_2015_09 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "email",
      "indices" : [ 13, 19 ]
    }, {
      "text" : "ELTchat",
      "indices" : [ 90, 98 ]
    }, {
      "text" : "besig",
      "indices" : [ 99, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/jEEuQW2Y6c",
      "expanded_url" : "http:\/\/clinton-palin.englishup.me\/",
      "display_url" : "clinton-palin.englishup.me"
    } ]
  },
  "geo" : { },
  "id_str" : "649342896521519104",
  "text" : "explore some #email language with hilary clinton &amp; sarah palin http:\/\/t.co\/jEEuQW2Y6c #ELTchat #besig",
  "id" : 649342896521519104,
  "created_at" : "2015-09-30 21:59:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 0, 8 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "649327574141784064",
  "text" : "#eltchat lurking all :)",
  "id" : 649327574141784064,
  "created_at" : "2015-09-30 20:58:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Sketch Engine",
      "screen_name" : "SketchEngine",
      "indices" : [ 3, 16 ],
      "id_str" : "841197134",
      "id" : 841197134
    }, {
      "name" : "The Sketch Engine",
      "screen_name" : "SketchEngine",
      "indices" : [ 60, 73 ],
      "id_str" : "841197134",
      "id" : 841197134
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/SketchEngine\/status\/649131246447140864\/photo\/1",
      "indices" : [ 127, 140 ],
      "url" : "http:\/\/t.co\/OUaZTyHgDJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQItbbtWsAAzWoj.png",
      "id_str" : "649131245612478464",
      "id" : 649131245612478464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQItbbtWsAAzWoj.png",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/OUaZTyHgDJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/i7rhnKEroF",
      "expanded_url" : "http:\/\/bit.ly\/1jvVEPe",
      "display_url" : "bit.ly\/1jvVEPe"
    } ]
  },
  "geo" : { },
  "id_str" : "649219586492100608",
  "text" : "RT @SketchEngine: Extract terms from teaching material with @SketchEngine, see Simon Smith's SlideShare http:\/\/t.co\/i7rhnKEroF http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Sketch Engine",
        "screen_name" : "SketchEngine",
        "indices" : [ 42, 55 ],
        "id_str" : "841197134",
        "id" : 841197134
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/SketchEngine\/status\/649131246447140864\/photo\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/OUaZTyHgDJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQItbbtWsAAzWoj.png",
        "id_str" : "649131245612478464",
        "id" : 649131245612478464,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQItbbtWsAAzWoj.png",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/OUaZTyHgDJ"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/i7rhnKEroF",
        "expanded_url" : "http:\/\/bit.ly\/1jvVEPe",
        "display_url" : "bit.ly\/1jvVEPe"
      } ]
    },
    "geo" : { },
    "id_str" : "649131246447140864",
    "text" : "Extract terms from teaching material with @SketchEngine, see Simon Smith's SlideShare http:\/\/t.co\/i7rhnKEroF http:\/\/t.co\/OUaZTyHgDJ",
    "id" : 649131246447140864,
    "created_at" : "2015-09-30 07:58:44 +0000",
    "user" : {
      "name" : "Sketch Engine",
      "screen_name" : "SketchEngine",
      "protected" : false,
      "id_str" : "841197134",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/763331747538997248\/ua_lo7Zd_normal.jpg",
      "id" : 841197134,
      "verified" : false
    }
  },
  "id" : 649219586492100608,
  "created_at" : "2015-09-30 13:49:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 3, 13 ],
      "id_str" : "525274103",
      "id" : 525274103
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/ElkySmith\/status\/649206130237804544\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/se02GoQ3B0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQJxiOeVEAEz80U.jpg",
      "id_str" : "649206129109569537",
      "id" : 649206129109569537,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQJxiOeVEAEz80U.jpg",
      "sizes" : [ {
        "h" : 656,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 384,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 656,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 218,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/se02GoQ3B0"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/ZjBKD1eJjI",
      "expanded_url" : "https:\/\/pedagogablog.wordpress.com\/2015\/09\/30\/changing-our-default-settings-part-3-the-student-data-blueprint",
      "display_url" : "pedagogablog.wordpress.com\/2015\/09\/30\/cha\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "649209872848973824",
  "text" : "RT @ElkySmith: Changing our default settings \u2013 part 3: The Student Data Blueprint https:\/\/t.co\/ZjBKD1eJjI http:\/\/t.co\/se02GoQ3B0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ElkySmith\/status\/649206130237804544\/photo\/1",
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/se02GoQ3B0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQJxiOeVEAEz80U.jpg",
        "id_str" : "649206129109569537",
        "id" : 649206129109569537,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQJxiOeVEAEz80U.jpg",
        "sizes" : [ {
          "h" : 656,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 384,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 656,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 218,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/se02GoQ3B0"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/ZjBKD1eJjI",
        "expanded_url" : "https:\/\/pedagogablog.wordpress.com\/2015\/09\/30\/changing-our-default-settings-part-3-the-student-data-blueprint",
        "display_url" : "pedagogablog.wordpress.com\/2015\/09\/30\/cha\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "649206130237804544",
    "text" : "Changing our default settings \u2013 part 3: The Student Data Blueprint https:\/\/t.co\/ZjBKD1eJjI http:\/\/t.co\/se02GoQ3B0",
    "id" : 649206130237804544,
    "created_at" : "2015-09-30 12:56:17 +0000",
    "user" : {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "protected" : false,
      "id_str" : "525274103",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/690658566370263041\/qggTYEb3_normal.jpg",
      "id" : 525274103,
      "verified" : false
    }
  },
  "id" : 649209872848973824,
  "created_at" : "2015-09-30 13:11:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 0, 9 ],
      "id_str" : "134211317",
      "id" : 134211317
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "649192169392222208",
  "geo" : { },
  "id_str" : "649192787896856576",
  "in_reply_to_user_id" : 134211317,
  "text" : "@josipa74 a pleasure Paul :)",
  "id" : 649192787896856576,
  "in_reply_to_status_id" : 649192169392222208,
  "created_at" : "2015-09-30 12:03:16 +0000",
  "in_reply_to_screen_name" : "josipa74",
  "in_reply_to_user_id_str" : "134211317",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 3, 12 ],
      "id_str" : "134211317",
      "id" : 134211317
    }, {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 14, 29 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/josipa74\/status\/649190560352366592\/photo\/1",
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/A5OpiRcYAK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQJjX7XWcAAilsy.jpg",
      "id_str" : "649190559018545152",
      "id" : 649190559018545152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQJjX7XWcAAilsy.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/A5OpiRcYAK"
    } ],
    "hashtags" : [ {
      "text" : "Dinosaurs",
      "indices" : [ 37, 47 ]
    }, {
      "text" : "TEFL",
      "indices" : [ 51, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/Jq1h6ftikt",
      "expanded_url" : "http:\/\/traffic.libsyn.com\/teflology\/Geoff_Jordan_Interview.m4a",
      "display_url" : "traffic.libsyn.com\/teflology\/Geof\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "649192015658356736",
  "text" : "RT @josipa74: @GeoffreyJordan on the #Dinosaurs in #TEFL! http:\/\/t.co\/Jq1h6ftikt http:\/\/t.co\/A5OpiRcYAK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Geoffrey Jordan",
        "screen_name" : "GeoffreyJordan",
        "indices" : [ 0, 15 ],
        "id_str" : "334332424",
        "id" : 334332424
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/josipa74\/status\/649190560352366592\/photo\/1",
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/A5OpiRcYAK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQJjX7XWcAAilsy.jpg",
        "id_str" : "649190559018545152",
        "id" : 649190559018545152,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQJjX7XWcAAilsy.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/A5OpiRcYAK"
      } ],
      "hashtags" : [ {
        "text" : "Dinosaurs",
        "indices" : [ 23, 33 ]
      }, {
        "text" : "TEFL",
        "indices" : [ 37, 42 ]
      } ],
      "urls" : [ {
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/Jq1h6ftikt",
        "expanded_url" : "http:\/\/traffic.libsyn.com\/teflology\/Geoff_Jordan_Interview.m4a",
        "display_url" : "traffic.libsyn.com\/teflology\/Geof\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "649190560352366592",
    "in_reply_to_user_id" : 334332424,
    "text" : "@GeoffreyJordan on the #Dinosaurs in #TEFL! http:\/\/t.co\/Jq1h6ftikt http:\/\/t.co\/A5OpiRcYAK",
    "id" : 649190560352366592,
    "created_at" : "2015-09-30 11:54:25 +0000",
    "in_reply_to_screen_name" : "GeoffreyJordan",
    "in_reply_to_user_id_str" : "334332424",
    "user" : {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "protected" : false,
      "id_str" : "134211317",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/526853654377021441\/MtEFhYIs_normal.jpeg",
      "id" : 134211317,
      "verified" : false
    }
  },
  "id" : 649192015658356736,
  "created_at" : "2015-09-30 12:00:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "649180319912996864",
  "geo" : { },
  "id_str" : "649188929837658112",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl sure it isn't uber catching up to language schools ;)",
  "id" : 649188929837658112,
  "in_reply_to_status_id" : 649180319912996864,
  "created_at" : "2015-09-30 11:47:56 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 0, 10 ],
      "id_str" : "525274103",
      "id" : 525274103
    }, {
      "name" : "Donald Clark",
      "screen_name" : "DonaldClark",
      "indices" : [ 11, 23 ],
      "id_str" : "1632891",
      "id" : 1632891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "649062821288775680",
  "geo" : { },
  "id_str" : "649069606842290176",
  "in_reply_to_user_id" : 525274103,
  "text" : "@ElkySmith @DonaldClark does \"lecture\" necessarily mean no interaction with audience?",
  "id" : 649069606842290176,
  "in_reply_to_status_id" : 649062821288775680,
  "created_at" : "2015-09-30 03:53:48 +0000",
  "in_reply_to_screen_name" : "ElkySmith",
  "in_reply_to_user_id_str" : "525274103",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Daw",
      "screen_name" : "racheldaw18",
      "indices" : [ 0, 12 ],
      "id_str" : "289983899",
      "id" : 289983899
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "648956893726175232",
  "geo" : { },
  "id_str" : "648971603167080448",
  "in_reply_to_user_id" : 289983899,
  "text" : "@racheldaw18  :0",
  "id" : 648971603167080448,
  "in_reply_to_status_id" : 648956893726175232,
  "created_at" : "2015-09-29 21:24:22 +0000",
  "in_reply_to_screen_name" : "racheldaw18",
  "in_reply_to_user_id_str" : "289983899",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Speech Dudes",
      "screen_name" : "SpeechDudes",
      "indices" : [ 3, 15 ],
      "id_str" : "310919399",
      "id" : 310919399
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "slpbloggers",
      "indices" : [ 100, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/S2e2dPGDig",
      "expanded_url" : "http:\/\/ow.ly\/SOdWh",
      "display_url" : "ow.ly\/SOdWh"
    } ]
  },
  "geo" : { },
  "id_str" : "648922409387606017",
  "text" : "RT @SpeechDudes: New Dudes post: \"My Hovercraft is Full of Eels and My AAC Device Full of N-grams.\" #slpbloggers http:\/\/t.co\/S2e2dPGDig",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "slpbloggers",
        "indices" : [ 83, 95 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/S2e2dPGDig",
        "expanded_url" : "http:\/\/ow.ly\/SOdWh",
        "display_url" : "ow.ly\/SOdWh"
      } ]
    },
    "geo" : { },
    "id_str" : "648920203645059073",
    "text" : "New Dudes post: \"My Hovercraft is Full of Eels and My AAC Device Full of N-grams.\" #slpbloggers http:\/\/t.co\/S2e2dPGDig",
    "id" : 648920203645059073,
    "created_at" : "2015-09-29 18:00:07 +0000",
    "user" : {
      "name" : "Speech Dudes",
      "screen_name" : "SpeechDudes",
      "protected" : false,
      "id_str" : "310919399",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2630404839\/ded339c018067c3300f6e855e18b897b_normal.png",
      "id" : 310919399,
      "verified" : false
    }
  },
  "id" : 648922409387606017,
  "created_at" : "2015-09-29 18:08:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ljiljana Havran",
      "screen_name" : "LjiljanaHavran",
      "indices" : [ 0, 15 ],
      "id_str" : "1395825290",
      "id" : 1395825290
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "648757726089248768",
  "geo" : { },
  "id_str" : "648778157450002432",
  "in_reply_to_user_id" : 1395825290,
  "text" : "@LjiljanaHavran glad it caused a smile :) there a number of probabilities in ELT one could do",
  "id" : 648778157450002432,
  "in_reply_to_status_id" : 648757726089248768,
  "created_at" : "2015-09-29 08:35:41 +0000",
  "in_reply_to_screen_name" : "LjiljanaHavran",
  "in_reply_to_user_id_str" : "1395825290",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 3, 13 ],
      "id_str" : "525274103",
      "id" : 525274103
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EAConf15",
      "indices" : [ 25, 34 ]
    }, {
      "text" : "AusELT",
      "indices" : [ 122, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/MTi77rp3XL",
      "expanded_url" : "https:\/\/pedagogablog.wordpress.com\/2015\/09\/28\/changing-our-default-settings-attitudes-to-educational-technology\/",
      "display_url" : "pedagogablog.wordpress.com\/2015\/09\/28\/cha\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "648630943679422465",
  "text" : "RT @ElkySmith: Pt1 of my #EAConf15 talk, Changing our default settings, includes results from my recent survey on ed tech #AusELT https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EAConf15",
        "indices" : [ 10, 19 ]
      }, {
        "text" : "AusELT",
        "indices" : [ 107, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/MTi77rp3XL",
        "expanded_url" : "https:\/\/pedagogablog.wordpress.com\/2015\/09\/28\/changing-our-default-settings-attitudes-to-educational-technology\/",
        "display_url" : "pedagogablog.wordpress.com\/2015\/09\/28\/cha\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "648442553604313089",
    "text" : "Pt1 of my #EAConf15 talk, Changing our default settings, includes results from my recent survey on ed tech #AusELT https:\/\/t.co\/MTi77rp3XL",
    "id" : 648442553604313089,
    "created_at" : "2015-09-28 10:22:06 +0000",
    "user" : {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "protected" : false,
      "id_str" : "525274103",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/690658566370263041\/qggTYEb3_normal.jpg",
      "id" : 525274103,
      "verified" : false
    }
  },
  "id" : 648630943679422465,
  "created_at" : "2015-09-28 22:50:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ljiljana Havran",
      "screen_name" : "LjiljanaHavran",
      "indices" : [ 59, 74 ],
      "id_str" : "1395825290",
      "id" : 1395825290
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/648628822653407233\/photo\/1",
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/z0NvTJcf6Q",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQBkeggWgAQLELl.png",
      "id_str" : "648628821625831428",
      "id" : 648628821625831428,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQBkeggWgAQLELl.png",
      "sizes" : [ {
        "h" : 360,
        "resize" : "fit",
        "w" : 504
      }, {
        "h" : 243,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 504
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 504
      } ],
      "display_url" : "pic.twitter.com\/z0NvTJcf6Q"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "648619147216224257",
  "geo" : { },
  "id_str" : "648628822653407233",
  "in_reply_to_user_id" : 18602422,
  "text" : "for ELT Teachers &amp; probability of using coursebooks :) @LjiljanaHavran http:\/\/t.co\/z0NvTJcf6Q",
  "id" : 648628822653407233,
  "in_reply_to_status_id" : 648619147216224257,
  "created_at" : "2015-09-28 22:42:16 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Orlin",
      "screen_name" : "benorlin",
      "indices" : [ 74, 83 ],
      "id_str" : "123096209",
      "id" : 123096209
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/G4BuUgOBuv",
      "expanded_url" : "http:\/\/wp.me\/p3gt4l-WT",
      "display_url" : "wp.me\/p3gt4l-WT"
    } ]
  },
  "geo" : { },
  "id_str" : "648619147216224257",
  "text" : "What Does Probability Mean in Your Profession? http:\/\/t.co\/G4BuUgOBuv via @benorlin",
  "id" : 648619147216224257,
  "created_at" : "2015-09-28 22:03:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eily Murphy",
      "screen_name" : "eilymurphy",
      "indices" : [ 3, 14 ],
      "id_str" : "111091623",
      "id" : 111091623
    }, {
      "name" : "Sharon Hartle",
      "screen_name" : "hartle",
      "indices" : [ 67, 74 ],
      "id_str" : "20324125",
      "id" : 20324125
    }, {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 75, 86 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/MmbJ4VbpyM",
      "expanded_url" : "https:\/\/twitter.com\/hartle\/status\/648527498951573504",
      "display_url" : "twitter.com\/hartle\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "648616430594867200",
  "text" : "RT @eilymurphy: Hugh Dellar\u2019s Webinar summary if you missed it via @hartle @hughdellar  https:\/\/t.co\/MmbJ4VbpyM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sharon Hartle",
        "screen_name" : "hartle",
        "indices" : [ 51, 58 ],
        "id_str" : "20324125",
        "id" : 20324125
      }, {
        "name" : "hugh dellar",
        "screen_name" : "hughdellar",
        "indices" : [ 59, 70 ],
        "id_str" : "88202140",
        "id" : 88202140
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/MmbJ4VbpyM",
        "expanded_url" : "https:\/\/twitter.com\/hartle\/status\/648527498951573504",
        "display_url" : "twitter.com\/hartle\/status\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "648568413447692289",
    "text" : "Hugh Dellar\u2019s Webinar summary if you missed it via @hartle @hughdellar  https:\/\/t.co\/MmbJ4VbpyM",
    "id" : 648568413447692289,
    "created_at" : "2015-09-28 18:42:14 +0000",
    "user" : {
      "name" : "Eily Murphy",
      "screen_name" : "eilymurphy",
      "protected" : false,
      "id_str" : "111091623",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746422529405894656\/gSFQlPqA_normal.jpg",
      "id" : 111091623,
      "verified" : false
    }
  },
  "id" : 648616430594867200,
  "created_at" : "2015-09-28 21:53:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eily Murphy",
      "screen_name" : "eilymurphy",
      "indices" : [ 0, 11 ],
      "id_str" : "111091623",
      "id" : 111091623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "648598149808922624",
  "geo" : { },
  "id_str" : "648599733670412288",
  "in_reply_to_user_id" : 111091623,
  "text" : "@eilymurphy consider blogposts linked in the G+ comm from prev rounds cld help for text u can't read in full?",
  "id" : 648599733670412288,
  "in_reply_to_status_id" : 648598149808922624,
  "created_at" : "2015-09-28 20:46:41 +0000",
  "in_reply_to_screen_name" : "eilymurphy",
  "in_reply_to_user_id_str" : "111091623",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchinwag",
      "indices" : [ 116, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/CQWhy7KUAq",
      "expanded_url" : "http:\/\/www.34914.com\/xsq\/jokes.htm",
      "display_url" : "34914.com\/xsq\/jokes.htm"
    }, {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/rhDvwlUAwf",
      "expanded_url" : "http:\/\/saundz.com\/knock-knock-jokes-for-pronunciation\/",
      "display_url" : "saundz.com\/knock-knock-jo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "648596384057266177",
  "text" : "hey all was looking for some \"fun\" pron things and found these two - http:\/\/t.co\/CQWhy7KUAq, http:\/\/t.co\/rhDvwlUAwf #eltchinwag",
  "id" : 648596384057266177,
  "created_at" : "2015-09-28 20:33:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Daw",
      "screen_name" : "racheldaw18",
      "indices" : [ 0, 12 ],
      "id_str" : "289983899",
      "id" : 289983899
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "648561676577546240",
  "geo" : { },
  "id_str" : "648562800537812994",
  "in_reply_to_user_id" : 289983899,
  "text" : "@racheldaw18 yep though i guess you can control some settings in paper.li?",
  "id" : 648562800537812994,
  "in_reply_to_status_id" : 648561676577546240,
  "created_at" : "2015-09-28 18:19:56 +0000",
  "in_reply_to_screen_name" : "racheldaw18",
  "in_reply_to_user_id_str" : "289983899",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Daw",
      "screen_name" : "racheldaw18",
      "indices" : [ 0, 12 ],
      "id_str" : "289983899",
      "id" : 289983899
    }, {
      "name" : "Alan Levine",
      "screen_name" : "cogdog",
      "indices" : [ 21, 28 ],
      "id_str" : "740343",
      "id" : 740343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/VTT7kezdvM",
      "expanded_url" : "https:\/\/twitter.com\/cogdog\/status\/558359619173486593",
      "display_url" : "twitter.com\/cogdog\/status\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "648559939342991360",
  "geo" : { },
  "id_str" : "648561163488378880",
  "in_reply_to_user_id" : 289983899,
  "text" : "@racheldaw18 i think @cogdog best expressed this https:\/\/t.co\/VTT7kezdvM",
  "id" : 648561163488378880,
  "in_reply_to_status_id" : 648559939342991360,
  "created_at" : "2015-09-28 18:13:25 +0000",
  "in_reply_to_screen_name" : "racheldaw18",
  "in_reply_to_user_id_str" : "289983899",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/b8rJtk3EDf",
      "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2015\/09\/the-wog-you-save-may-be-your-own.html",
      "display_url" : "thecurmudgeonly.blogspot.co.uk\/2015\/09\/the-wo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "648560552520908802",
  "text" : "RT @pchallinor: New mudgeonry: The wog you save may be your own http:\/\/t.co\/b8rJtk3EDf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 70 ],
        "url" : "http:\/\/t.co\/b8rJtk3EDf",
        "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2015\/09\/the-wog-you-save-may-be-your-own.html",
        "display_url" : "thecurmudgeonly.blogspot.co.uk\/2015\/09\/the-wo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "648555491585622016",
    "text" : "New mudgeonry: The wog you save may be your own http:\/\/t.co\/b8rJtk3EDf",
    "id" : 648555491585622016,
    "created_at" : "2015-09-28 17:50:53 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 648560552520908802,
  "created_at" : "2015-09-28 18:11:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hancock McDonald ELT",
      "screen_name" : "HancockMcDonald",
      "indices" : [ 3, 19 ],
      "id_str" : "552929354",
      "id" : 552929354
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/HancockMcDonald\/status\/648474001140899840\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/5w3LOI49h8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CP_Xqt4WUAA0D8w.jpg",
      "id_str" : "648474000235057152",
      "id" : 648474000235057152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CP_Xqt4WUAA0D8w.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 583,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1714,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 1714,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 1028,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/5w3LOI49h8"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/LzP17fn0XZ",
      "expanded_url" : "http:\/\/hancockmcdonald.com\/materials\/american-sound-chart",
      "display_url" : "hancockmcdonald.com\/materials\/amer\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "648475245507149824",
  "text" : "RT @HancockMcDonald: Here's an American version of my pronpack sound chart. Feedback welcome! http:\/\/t.co\/LzP17fn0XZ http:\/\/t.co\/5w3LOI49h8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/HancockMcDonald\/status\/648474001140899840\/photo\/1",
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/5w3LOI49h8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CP_Xqt4WUAA0D8w.jpg",
        "id_str" : "648474000235057152",
        "id" : 648474000235057152,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CP_Xqt4WUAA0D8w.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 583,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1714,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 1714,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 1028,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/5w3LOI49h8"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/LzP17fn0XZ",
        "expanded_url" : "http:\/\/hancockmcdonald.com\/materials\/american-sound-chart",
        "display_url" : "hancockmcdonald.com\/materials\/amer\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "648474001140899840",
    "text" : "Here's an American version of my pronpack sound chart. Feedback welcome! http:\/\/t.co\/LzP17fn0XZ http:\/\/t.co\/5w3LOI49h8",
    "id" : 648474001140899840,
    "created_at" : "2015-09-28 12:27:04 +0000",
    "user" : {
      "name" : "Hancock McDonald ELT",
      "screen_name" : "HancockMcDonald",
      "protected" : false,
      "id_str" : "552929354",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2158919436\/HM_portrait_normal.jpg",
      "id" : 552929354,
      "verified" : false
    }
  },
  "id" : 648475245507149824,
  "created_at" : "2015-09-28 12:32:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KBarrs",
      "screen_name" : "corpusloanword",
      "indices" : [ 3, 18 ],
      "id_str" : "95419070",
      "id" : 95419070
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusMOOC",
      "indices" : [ 39, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 123, 140 ],
      "url" : "http:\/\/t.co\/ZWOmww6CcN",
      "expanded_url" : "http:\/\/www.euppublishing.com\/doi\/abs\/10.3366\/cor.2015.0069",
      "display_url" : "euppublishing.com\/doi\/abs\/10.336\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "648162574232588288",
  "text" : "RT @corpusloanword: Thinking of taking #corpusMOOC starting tmrrw? I wrote an open access review of the 2nd run last year: http:\/\/t.co\/ZWOm\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpusMOOC",
        "indices" : [ 19, 30 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/ZWOmww6CcN",
        "expanded_url" : "http:\/\/www.euppublishing.com\/doi\/abs\/10.3366\/cor.2015.0069",
        "display_url" : "euppublishing.com\/doi\/abs\/10.336\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "648129338030751744",
    "text" : "Thinking of taking #corpusMOOC starting tmrrw? I wrote an open access review of the 2nd run last year: http:\/\/t.co\/ZWOmww6CcN",
    "id" : 648129338030751744,
    "created_at" : "2015-09-27 13:37:30 +0000",
    "user" : {
      "name" : "KBarrs",
      "screen_name" : "corpusloanword",
      "protected" : false,
      "id_str" : "95419070",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3194937799\/f5a7b3c729837992c82ce94d0db82774_normal.jpeg",
      "id" : 95419070,
      "verified" : false
    }
  },
  "id" : 648162574232588288,
  "created_at" : "2015-09-27 15:49:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/tq3lJ1yYEo",
      "expanded_url" : "https:\/\/www.craigmurray.org.uk\/archives\/2015\/09\/more-truth-about-british-torture\/",
      "display_url" : "craigmurray.org.uk\/archives\/2015\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "647865279725355008",
  "text" : "RT @pchallinor: \"...because he was tortured with MI6 personnel directly in the room, as opposed to waiting outside\" https:\/\/t.co\/tq3lJ1yYEo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/tq3lJ1yYEo",
        "expanded_url" : "https:\/\/www.craigmurray.org.uk\/archives\/2015\/09\/more-truth-about-british-torture\/",
        "display_url" : "craigmurray.org.uk\/archives\/2015\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "647863904161394688",
    "text" : "\"...because he was tortured with MI6 personnel directly in the room, as opposed to waiting outside\" https:\/\/t.co\/tq3lJ1yYEo",
    "id" : 647863904161394688,
    "created_at" : "2015-09-26 20:02:46 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 647865279725355008,
  "created_at" : "2015-09-26 20:08:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 58, 74 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/Eon2tE4GDI",
      "expanded_url" : "http:\/\/wp.me\/ptlTk-rJ",
      "display_url" : "wp.me\/ptlTk-rJ"
    } ]
  },
  "geo" : { },
  "id_str" : "647841245524545536",
  "text" : "Top 10 ELT books never written http:\/\/t.co\/Eon2tE4GDI via @wordpressdotcom",
  "id" : 647841245524545536,
  "created_at" : "2015-09-26 18:32:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 3, 14 ],
      "id_str" : "88202140",
      "id" : 88202140
    }, {
      "name" : "IATEFL Online",
      "screen_name" : "iateflonline",
      "indices" : [ 32, 45 ],
      "id_str" : "17447359",
      "id" : 17447359
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/fRjJoEYZ3L",
      "expanded_url" : "http:\/\/www.iatefl.org\/join\/webinars",
      "display_url" : "iatefl.org\/join\/webinars"
    } ]
  },
  "geo" : { },
  "id_str" : "647451304420319232",
  "text" : "RT @hughdellar: Am doing a free @iateflonline webinar this Saturday on how understanding colligation helps you teach grammar better: http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "IATEFL Online",
        "screen_name" : "iateflonline",
        "indices" : [ 16, 29 ],
        "id_str" : "17447359",
        "id" : 17447359
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/fRjJoEYZ3L",
        "expanded_url" : "http:\/\/www.iatefl.org\/join\/webinars",
        "display_url" : "iatefl.org\/join\/webinars"
      } ]
    },
    "geo" : { },
    "id_str" : "647421268845821952",
    "text" : "Am doing a free @iateflonline webinar this Saturday on how understanding colligation helps you teach grammar better: http:\/\/t.co\/fRjJoEYZ3L",
    "id" : 647421268845821952,
    "created_at" : "2015-09-25 14:43:53 +0000",
    "user" : {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "protected" : false,
      "id_str" : "88202140",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2040881292\/Hugh_Dellar_photo_normal.jpg",
      "id" : 88202140,
      "verified" : false
    }
  },
  "id" : 647451304420319232,
  "created_at" : "2015-09-25 16:43:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 3, 14 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edtech",
      "indices" : [ 20, 27 ]
    }, {
      "text" : "education",
      "indices" : [ 48, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 140 ],
      "url" : "http:\/\/t.co\/i7hQohIh0x",
      "expanded_url" : "http:\/\/bit.ly\/1OyavFG",
      "display_url" : "bit.ly\/1OyavFG"
    } ]
  },
  "geo" : { },
  "id_str" : "647449613482467328",
  "text" : "RT @tornhalves: How #edtech learner autonomy in #education turned into a perfect training for the prevailing heteronomy: http:\/\/t.co\/i7hQoh\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "edtech",
        "indices" : [ 4, 11 ]
      }, {
        "text" : "education",
        "indices" : [ 32, 42 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/i7hQohIh0x",
        "expanded_url" : "http:\/\/bit.ly\/1OyavFG",
        "display_url" : "bit.ly\/1OyavFG"
      } ]
    },
    "geo" : { },
    "id_str" : "647389190687191040",
    "text" : "How #edtech learner autonomy in #education turned into a perfect training for the prevailing heteronomy: http:\/\/t.co\/i7hQohIh0x",
    "id" : 647389190687191040,
    "created_at" : "2015-09-25 12:36:25 +0000",
    "user" : {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "protected" : false,
      "id_str" : "87902543",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3059742703\/1d3c7a2052db17d29644fa0a49af6480_normal.jpeg",
      "id" : 87902543,
      "verified" : false
    }
  },
  "id" : 647449613482467328,
  "created_at" : "2015-09-25 16:36:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 0, 10 ],
      "id_str" : "525274103",
      "id" : 525274103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "647362366288474112",
  "geo" : { },
  "id_str" : "647363575858753536",
  "in_reply_to_user_id" : 525274103,
  "text" : "@ElkySmith great will look fwd to checking that",
  "id" : 647363575858753536,
  "in_reply_to_status_id" : 647362366288474112,
  "created_at" : "2015-09-25 10:54:38 +0000",
  "in_reply_to_screen_name" : "ElkySmith",
  "in_reply_to_user_id_str" : "525274103",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 0, 10 ],
      "id_str" : "525274103",
      "id" : 525274103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "647355068270772224",
  "geo" : { },
  "id_str" : "647362181638524928",
  "in_reply_to_user_id" : 525274103,
  "text" : "@ElkySmith what happened to that survey u did a while back?",
  "id" : 647362181638524928,
  "in_reply_to_status_id" : 647355068270772224,
  "created_at" : "2015-09-25 10:49:06 +0000",
  "in_reply_to_screen_name" : "ElkySmith",
  "in_reply_to_user_id_str" : "525274103",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 73, 88 ],
      "id_str" : "285614027",
      "id" : 285614027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/yUbshCaDiG",
      "expanded_url" : "http:\/\/www.anthonyteacher.com\/more\/audio-diaries-for-improved-spoken-proficiency",
      "display_url" : "anthonyteacher.com\/more\/audio-dia\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "647259385186635776",
  "text" : "Audio Diaries for Improved Spoken Proficiency http:\/\/t.co\/yUbshCaDiG via @AnthonyTeacher",
  "id" : 647259385186635776,
  "created_at" : "2015-09-25 04:00:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Dawkins",
      "screen_name" : "RichardDawkins",
      "indices" : [ 46, 61 ],
      "id_str" : "15143478",
      "id" : 15143478
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "647021762933313536",
  "text" : "Why would the blind watchmaker take a meme to @RichardDawkins take the works out and put it in a soapbox?",
  "id" : 647021762933313536,
  "created_at" : "2015-09-24 12:16:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Taylor",
      "screen_name" : "theteacherjames",
      "indices" : [ 0, 16 ],
      "id_str" : "71746265",
      "id" : 71746265
    }, {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 17, 32 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "646752009140498432",
  "geo" : { },
  "id_str" : "646755684256718848",
  "in_reply_to_user_id" : 71746265,
  "text" : "@theteacherjames @MrChrisJWilson uh oh this dichotic thinking does not go far :)",
  "id" : 646755684256718848,
  "in_reply_to_status_id" : 646752009140498432,
  "created_at" : "2015-09-23 18:39:05 +0000",
  "in_reply_to_screen_name" : "theteacherjames",
  "in_reply_to_user_id_str" : "71746265",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    }, {
      "name" : "James Taylor",
      "screen_name" : "theteacherjames",
      "indices" : [ 16, 32 ],
      "id_str" : "71746265",
      "id" : 71746265
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "646749748087685120",
  "geo" : { },
  "id_str" : "646751368657637377",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson @theteacherjames someone tweeted the glass is always refillable and someone else commented a third kind of person :)",
  "id" : 646751368657637377,
  "in_reply_to_status_id" : 646749748087685120,
  "created_at" : "2015-09-23 18:21:57 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol Goodey",
      "screen_name" : "carol_goodey",
      "indices" : [ 0, 13 ],
      "id_str" : "2814555865",
      "id" : 2814555865
    }, {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 50, 61 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "646687243357265920",
  "geo" : { },
  "id_str" : "646728265097445378",
  "in_reply_to_user_id" : 2814555865,
  "text" : "@carol_goodey sorry for your day be sure to check @pchallinor for more laughs :)",
  "id" : 646728265097445378,
  "in_reply_to_status_id" : 646687243357265920,
  "created_at" : "2015-09-23 16:50:08 +0000",
  "in_reply_to_screen_name" : "carol_goodey",
  "in_reply_to_user_id_str" : "2814555865",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/sD0CCjBK1s",
      "expanded_url" : "http:\/\/www.theguardian.com\/books\/2015\/sep\/23\/scots-thesaurus-reveals-421-words-for-snow",
      "display_url" : "theguardian.com\/books\/2015\/sep\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "646684480695074817",
  "text" : "RT @pchallinor: Thanks to machinations of the fiend Salmond and his minions, Scots have more than their fair share of words for snow http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/sD0CCjBK1s",
        "expanded_url" : "http:\/\/www.theguardian.com\/books\/2015\/sep\/23\/scots-thesaurus-reveals-421-words-for-snow",
        "display_url" : "theguardian.com\/books\/2015\/sep\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "646684023444664320",
    "text" : "Thanks to machinations of the fiend Salmond and his minions, Scots have more than their fair share of words for snow http:\/\/t.co\/sD0CCjBK1s",
    "id" : 646684023444664320,
    "created_at" : "2015-09-23 13:54:20 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 646684480695074817,
  "created_at" : "2015-09-23 13:56:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHL Express UK",
      "screen_name" : "dhlexpressuk",
      "indices" : [ 0, 13 ],
      "id_str" : "128563448",
      "id" : 128563448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "646681434762145792",
  "geo" : { },
  "id_str" : "646682111903141889",
  "in_reply_to_user_id" : 128563448,
  "text" : "@dhlexpressuk hi following u need to follow me as well to DM i think",
  "id" : 646682111903141889,
  "in_reply_to_status_id" : 646681434762145792,
  "created_at" : "2015-09-23 13:46:44 +0000",
  "in_reply_to_screen_name" : "dhlexpressuk",
  "in_reply_to_user_id_str" : "128563448",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHL Express UK",
      "screen_name" : "dhlexpressuk",
      "indices" : [ 0, 13 ],
      "id_str" : "128563448",
      "id" : 128563448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "646646860757762048",
  "in_reply_to_user_id" : 128563448,
  "text" : "@dhlexpressuk seems dhlfrance is a joke, third drop-off point refused wtf?!",
  "id" : 646646860757762048,
  "created_at" : "2015-09-23 11:26:40 +0000",
  "in_reply_to_screen_name" : "dhlexpressuk",
  "in_reply_to_user_id_str" : "128563448",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Thomas",
      "screen_name" : "versatilepub",
      "indices" : [ 100, 113 ],
      "id_str" : "3243120760",
      "id" : 3243120760
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 10, 21 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/sEwbklpuZz",
      "expanded_url" : "https:\/\/plus.google.com\/+MuraNava\/posts\/AmEcrQGE1Ji",
      "display_url" : "plus.google.com\/+MuraNava\/post\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "646424314439450624",
  "text" : "if u r on #corpusmooc u may want to try yr hand at winning Discovering English with SketchEngine by @versatilepub https:\/\/t.co\/sEwbklpuZz",
  "id" : 646424314439450624,
  "created_at" : "2015-09-22 20:42:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHL Express UK",
      "screen_name" : "dhlexpressuk",
      "indices" : [ 0, 13 ],
      "id_str" : "128563448",
      "id" : 128563448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "646347111471185920",
  "in_reply_to_user_id" : 128563448,
  "text" : "@dhlexpressuk no high mountains no wide river just plain old roads yet still waiting over a week after 7 calls :\/",
  "id" : 646347111471185920,
  "created_at" : "2015-09-22 15:35:34 +0000",
  "in_reply_to_screen_name" : "dhlexpressuk",
  "in_reply_to_user_id_str" : "128563448",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Glenn Hadikin",
      "screen_name" : "Glenn_Hadikin",
      "indices" : [ 3, 17 ],
      "id_str" : "24455799",
      "id" : 24455799
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusresources",
      "indices" : [ 37, 53 ]
    }, {
      "text" : "corpora",
      "indices" : [ 70, 78 ]
    }, {
      "text" : "corpuslinguistics",
      "indices" : [ 83, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "646267827540914176",
  "text" : "RT @Glenn_Hadikin: We should all use #corpusresources to collect good #corpora and #corpuslinguistics resource pages. It'll be great in a f\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpusresources",
        "indices" : [ 18, 34 ]
      }, {
        "text" : "corpora",
        "indices" : [ 51, 59 ]
      }, {
        "text" : "corpuslinguistics",
        "indices" : [ 64, 82 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "644600091135844352",
    "text" : "We should all use #corpusresources to collect good #corpora and #corpuslinguistics resource pages. It'll be great in a few months if all in",
    "id" : 644600091135844352,
    "created_at" : "2015-09-17 19:53:32 +0000",
    "user" : {
      "name" : "Dr Glenn Hadikin",
      "screen_name" : "Glenn_Hadikin",
      "protected" : false,
      "id_str" : "24455799",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451444841910530052\/M3o_yNR1_normal.jpeg",
      "id" : 24455799,
      "verified" : false
    }
  },
  "id" : 646267827540914176,
  "created_at" : "2015-09-22 10:20:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Paskale",
      "screen_name" : "speak2all",
      "indices" : [ 3, 13 ],
      "id_str" : "20900313",
      "id" : 20900313
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DirtyRhetoric",
      "indices" : [ 19, 33 ]
    }, {
      "text" : "CarlyFiorina",
      "indices" : [ 48, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/D1Bkf8eQub",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=lkBI_mhDrNs&feature=youtu.be",
      "display_url" : "youtube.com\/watch?v=lkBI_m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "646044388452397056",
  "text" : "RT @speak2all: The #DirtyRhetoric secret behind #CarlyFiorina debate performance &amp; why you can't beat a good analogy https:\/\/t.co\/D1Bkf8eQub",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DirtyRhetoric",
        "indices" : [ 4, 18 ]
      }, {
        "text" : "CarlyFiorina",
        "indices" : [ 33, 46 ]
      } ],
      "urls" : [ {
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/D1Bkf8eQub",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=lkBI_mhDrNs&feature=youtu.be",
        "display_url" : "youtube.com\/watch?v=lkBI_m\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "646039742484717568",
    "text" : "The #DirtyRhetoric secret behind #CarlyFiorina debate performance &amp; why you can't beat a good analogy https:\/\/t.co\/D1Bkf8eQub",
    "id" : 646039742484717568,
    "created_at" : "2015-09-21 19:14:12 +0000",
    "user" : {
      "name" : "Peter Paskale",
      "screen_name" : "speak2all",
      "protected" : false,
      "id_str" : "20900313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/555413218571468800\/oXbEP2Zs_normal.jpeg",
      "id" : 20900313,
      "verified" : false
    }
  },
  "id" : 646044388452397056,
  "created_at" : "2015-09-21 19:32:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dreamreader",
      "screen_name" : "dreamreadernet",
      "indices" : [ 0, 15 ],
      "id_str" : "570887893",
      "id" : 570887893
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "645914807426678786",
  "geo" : { },
  "id_str" : "645921922518253568",
  "in_reply_to_user_id" : 570887893,
  "text" : "@dreamreadernet delighted :)",
  "id" : 645921922518253568,
  "in_reply_to_status_id" : 645914807426678786,
  "created_at" : "2015-09-21 11:26:01 +0000",
  "in_reply_to_screen_name" : "dreamreadernet",
  "in_reply_to_user_id_str" : "570887893",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dreamreader",
      "screen_name" : "dreamreadernet",
      "indices" : [ 0, 15 ],
      "id_str" : "570887893",
      "id" : 570887893
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/NdZELMp5bV",
      "expanded_url" : "https:\/\/eflnotes.wordpress.com\/category\/grassroots-language-technology\/",
      "display_url" : "eflnotes.wordpress.com\/category\/grass\u2026"
    }, {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/XmME9pEG7z",
      "expanded_url" : "https:\/\/eflnotes.files.wordpress.com\/2015\/09\/tdsig-article.pdf",
      "display_url" : "eflnotes.files.wordpress.com\/2015\/09\/tdsig-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "645896123454885890",
  "geo" : { },
  "id_str" : "645911661166075904",
  "in_reply_to_user_id" : 570887893,
  "text" : "@dreamreadernet hi some tchrs exp here https:\/\/t.co\/NdZELMp5bV &amp; my own here https:\/\/t.co\/XmME9pEG7z [pdf]",
  "id" : 645911661166075904,
  "in_reply_to_status_id" : 645896123454885890,
  "created_at" : "2015-09-21 10:45:15 +0000",
  "in_reply_to_screen_name" : "dreamreadernet",
  "in_reply_to_user_id_str" : "570887893",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/o0AoOlPujp",
      "expanded_url" : "http:\/\/www.independent.co.uk\/news\/uk\/home-news\/depressed-man-killed-himself-as-a-direct-result-of-dwps-fit-to-work-ruling-coroner-finds-10510305.html",
      "display_url" : "independent.co.uk\/news\/uk\/home-n\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "645885989622280192",
  "text" : "RT @pchallinor: Come on, IDS, give us a fist-pump http:\/\/t.co\/o0AoOlPujp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 34, 56 ],
        "url" : "http:\/\/t.co\/o0AoOlPujp",
        "expanded_url" : "http:\/\/www.independent.co.uk\/news\/uk\/home-news\/depressed-man-killed-himself-as-a-direct-result-of-dwps-fit-to-work-ruling-coroner-finds-10510305.html",
        "display_url" : "independent.co.uk\/news\/uk\/home-n\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "645884992229347328",
    "text" : "Come on, IDS, give us a fist-pump http:\/\/t.co\/o0AoOlPujp",
    "id" : 645884992229347328,
    "created_at" : "2015-09-21 08:59:16 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 645885989622280192,
  "created_at" : "2015-09-21 09:03:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Cook",
      "screen_name" : "Jonathan_K_Cook",
      "indices" : [ 3, 19 ],
      "id_str" : "2459644405",
      "id" : 2459644405
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "https:\/\/t.co\/Pk8pXfYIhM",
      "expanded_url" : "https:\/\/shar.es\/17tfv2",
      "display_url" : "shar.es\/17tfv2"
    } ]
  },
  "geo" : { },
  "id_str" : "645691357558796289",
  "text" : "RT @Jonathan_K_Cook: My latest: Corbyn's win has unmasked the Guardian as more wedded to neoliberalism than real change https:\/\/t.co\/Pk8pXf\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/Pk8pXfYIhM",
        "expanded_url" : "https:\/\/shar.es\/17tfv2",
        "display_url" : "shar.es\/17tfv2"
      } ]
    },
    "geo" : { },
    "id_str" : "645650238875680768",
    "text" : "My latest: Corbyn's win has unmasked the Guardian as more wedded to neoliberalism than real change https:\/\/t.co\/Pk8pXfYIhM",
    "id" : 645650238875680768,
    "created_at" : "2015-09-20 17:26:27 +0000",
    "user" : {
      "name" : "Jonathan Cook",
      "screen_name" : "Jonathan_K_Cook",
      "protected" : false,
      "id_str" : "2459644405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458948119749619713\/8ed1EDoY_normal.jpeg",
      "id" : 2459644405,
      "verified" : false
    }
  },
  "id" : 645691357558796289,
  "created_at" : "2015-09-20 20:09:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 61, 74 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/ylAknt9P02",
      "expanded_url" : "http:\/\/wp.me\/pKFOt-Dm",
      "display_url" : "wp.me\/pKFOt-Dm"
    } ]
  },
  "geo" : { },
  "id_str" : "645550401748643840",
  "text" : "A Card Game: The Nouns and Verbs: http:\/\/t.co\/ylAknt9P02 via @rosemerebard",
  "id" : 645550401748643840,
  "created_at" : "2015-09-20 10:49:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/eGbKd8rjGX",
      "expanded_url" : "http:\/\/www.leninology.co.uk\/2015\/09\/our-feral-lying-good-for-nothing-media.html",
      "display_url" : "leninology.co.uk\/2015\/09\/our-fe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "645301490559549440",
  "text" : "RT @pchallinor: \"The ferocity of the British media...has nothing whatever to do with Corbyn's media strategy, spin or lack thereof\" http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/eGbKd8rjGX",
        "expanded_url" : "http:\/\/www.leninology.co.uk\/2015\/09\/our-feral-lying-good-for-nothing-media.html",
        "display_url" : "leninology.co.uk\/2015\/09\/our-fe\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "645268223588474881",
    "text" : "\"The ferocity of the British media...has nothing whatever to do with Corbyn's media strategy, spin or lack thereof\" http:\/\/t.co\/eGbKd8rjGX",
    "id" : 645268223588474881,
    "created_at" : "2015-09-19 16:08:27 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 645301490559549440,
  "created_at" : "2015-09-19 18:20:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "645153699656941568",
  "geo" : { },
  "id_str" : "645156972531175424",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish sure, it was a good rant :)",
  "id" : 645156972531175424,
  "in_reply_to_status_id" : 645153699656941568,
  "created_at" : "2015-09-19 08:46:23 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 3, 19 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/MEaGo5pwkW",
      "expanded_url" : "https:\/\/freelanceteacherselfdevelopment.wordpress.com\/2015\/09\/18\/on-that-annoying-benjamin-franklin-quote\/",
      "display_url" : "\u2026eteacherselfdevelopment.wordpress.com\/2015\/09\/18\/on-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "645153125247111168",
  "text" : "RT @getgreatenglish: I wrote a post this morning about a viral quote that annoys me so much. https:\/\/t.co\/MEaGo5pwkW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/MEaGo5pwkW",
        "expanded_url" : "https:\/\/freelanceteacherselfdevelopment.wordpress.com\/2015\/09\/18\/on-that-annoying-benjamin-franklin-quote\/",
        "display_url" : "\u2026eteacherselfdevelopment.wordpress.com\/2015\/09\/18\/on-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "645138854823923712",
    "text" : "I wrote a post this morning about a viral quote that annoys me so much. https:\/\/t.co\/MEaGo5pwkW",
    "id" : 645138854823923712,
    "created_at" : "2015-09-19 07:34:23 +0000",
    "user" : {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "protected" : false,
      "id_str" : "2273617656",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724115932742721537\/LWTpFJX2_normal.jpg",
      "id" : 2273617656,
      "verified" : false
    }
  },
  "id" : 645153125247111168,
  "created_at" : "2015-09-19 08:31:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "indices" : [ 3, 18 ],
      "id_str" : "152194866",
      "id" : 152194866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/HC8SEA1R6J",
      "expanded_url" : "http:\/\/tm.durusau.net\/?p=64567",
      "display_url" : "tm.durusau.net\/?p=64567"
    } ]
  },
  "geo" : { },
  "id_str" : "645152950768300032",
  "text" : "RT @patrickDurusau: Tor relay turned back on after unanimous library vote http:\/\/t.co\/HC8SEA1R6J",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 76 ],
        "url" : "http:\/\/t.co\/HC8SEA1R6J",
        "expanded_url" : "http:\/\/tm.durusau.net\/?p=64567",
        "display_url" : "tm.durusau.net\/?p=64567"
      } ]
    },
    "geo" : { },
    "id_str" : "644884650784071680",
    "text" : "Tor relay turned back on after unanimous library vote http:\/\/t.co\/HC8SEA1R6J",
    "id" : 644884650784071680,
    "created_at" : "2015-09-18 14:44:16 +0000",
    "user" : {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "protected" : false,
      "id_str" : "152194866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/961579480\/patrick_normal.jpeg",
      "id" : 152194866,
      "verified" : false
    }
  },
  "id" : 645152950768300032,
  "created_at" : "2015-09-19 08:30:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoff Jordan",
      "screen_name" : "GeoffJordan",
      "indices" : [ 59, 71 ],
      "id_str" : "29510765",
      "id" : 29510765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/rHFPWG22vf",
      "expanded_url" : "http:\/\/wp.me\/p3qkCB-1ng",
      "display_url" : "wp.me\/p3qkCB-1ng"
    } ]
  },
  "geo" : { },
  "id_str" : "645140031980576768",
  "text" : "Thornbury and The Learning Body http:\/\/t.co\/rHFPWG22vf via @GeoffJordan",
  "id" : 645140031980576768,
  "created_at" : "2015-09-19 07:39:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 92, 107 ],
      "id_str" : "285614027",
      "id" : 285614027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/FmYN9hAIZ6",
      "expanded_url" : "http:\/\/www.anthonyteacher.com\/blog\/researchbites\/research-bites-wtf-what-the-font-typography-and-elt-part-3",
      "display_url" : "anthonyteacher.com\/blog\/researchb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "645139866280460289",
  "text" : "Research Bites: WTF: What The Font? - Typography and ELT, part 3 http:\/\/t.co\/FmYN9hAIZ6 via @AnthonyTeacher",
  "id" : 645139866280460289,
  "created_at" : "2015-09-19 07:38:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Cantarutti",
      "screen_name" : "pronbites",
      "indices" : [ 0, 10 ],
      "id_str" : "2451770871",
      "id" : 2451770871
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "644964994342342657",
  "geo" : { },
  "id_str" : "644966699050123264",
  "in_reply_to_user_id" : 2451770871,
  "text" : "@pronbites :( hope yr w\/e is better",
  "id" : 644966699050123264,
  "in_reply_to_status_id" : 644964994342342657,
  "created_at" : "2015-09-18 20:10:18 +0000",
  "in_reply_to_screen_name" : "pronbites",
  "in_reply_to_user_id_str" : "2451770871",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Cantarutti",
      "screen_name" : "pronbites",
      "indices" : [ 0, 10 ],
      "id_str" : "2451770871",
      "id" : 2451770871
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "644961843509874688",
  "geo" : { },
  "id_str" : "644963846487191557",
  "in_reply_to_user_id" : 2451770871,
  "text" : "@pronbites :\/ are u laughing or crying?",
  "id" : 644963846487191557,
  "in_reply_to_status_id" : 644961843509874688,
  "created_at" : "2015-09-18 19:58:58 +0000",
  "in_reply_to_screen_name" : "pronbites",
  "in_reply_to_user_id_str" : "2451770871",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Cook",
      "screen_name" : "idc74",
      "indices" : [ 0, 6 ],
      "id_str" : "290521216",
      "id" : 290521216
    }, {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 7, 18 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "644934212437544960",
  "geo" : { },
  "id_str" : "644959894538448896",
  "in_reply_to_user_id" : 290521216,
  "text" : "@idc74 @hughdellar hehe",
  "id" : 644959894538448896,
  "in_reply_to_status_id" : 644934212437544960,
  "created_at" : "2015-09-18 19:43:16 +0000",
  "in_reply_to_screen_name" : "idc74",
  "in_reply_to_user_id_str" : "290521216",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frankie Boyle",
      "screen_name" : "frankieboyle",
      "indices" : [ 32, 45 ],
      "id_str" : "17336372",
      "id" : 17336372
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/644959306497060867\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/5vbw5eOpPW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CPNbEg6WcAA7e98.png",
      "id_str" : "644959304756391936",
      "id" : 644959304756391936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPNbEg6WcAA7e98.png",
      "sizes" : [ {
        "h" : 119,
        "resize" : "crop",
        "w" : 119
      }, {
        "h" : 119,
        "resize" : "fit",
        "w" : 627
      }, {
        "h" : 65,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 114,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 119,
        "resize" : "fit",
        "w" : 627
      } ],
      "display_url" : "pic.twitter.com\/5vbw5eOpPW"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/5TZmWuusCw",
      "expanded_url" : "http:\/\/gu.com\/p\/4cckq\/stw",
      "display_url" : "gu.com\/p\/4cckq\/stw"
    } ]
  },
  "geo" : { },
  "id_str" : "644959306497060867",
  "text" : "damn son some powerful rhetoric @frankieboyle...like there\u2019s a humanitarian offside rule http:\/\/t.co\/5TZmWuusCw http:\/\/t.co\/5vbw5eOpPW",
  "id" : 644959306497060867,
  "created_at" : "2015-09-18 19:40:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 0, 11 ],
      "id_str" : "88202140",
      "id" : 88202140
    }, {
      "name" : "Ian Cook",
      "screen_name" : "idc74",
      "indices" : [ 12, 18 ],
      "id_str" : "290521216",
      "id" : 290521216
    }, {
      "name" : "macmillanelt",
      "screen_name" : "MacmillanELT",
      "indices" : [ 38, 51 ],
      "id_str" : "16294897",
      "id" : 16294897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/pv8pTYT8dh",
      "expanded_url" : "http:\/\/www.macmillanenglish.com\/life-skills\/",
      "display_url" : "macmillanenglish.com\/life-skills\/"
    } ]
  },
  "in_reply_to_status_id_str" : "644913313902628864",
  "geo" : { },
  "id_str" : "644923358849695744",
  "in_reply_to_user_id" : 88202140,
  "text" : "@hughdellar @idc74 is it sponsered by @MacmillanELT? to wit http:\/\/t.co\/pv8pTYT8dh :\/",
  "id" : 644923358849695744,
  "in_reply_to_status_id" : 644913313902628864,
  "created_at" : "2015-09-18 17:18:05 +0000",
  "in_reply_to_screen_name" : "hughdellar",
  "in_reply_to_user_id_str" : "88202140",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2133\u0105h\u0105 B\u0105\u2113i \u0645\u0647\u0627 \u0628\u0627\u0644\u064A",
      "screen_name" : "Bali_Maha",
      "indices" : [ 0, 10 ],
      "id_str" : "1535273520",
      "id" : 1535273520
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "644590192272216064",
  "geo" : { },
  "id_str" : "644591906761146370",
  "in_reply_to_user_id" : 1535273520,
  "text" : "@Bali_Maha is that your age?!! :) hope you had a good one",
  "id" : 644591906761146370,
  "in_reply_to_status_id" : 644590192272216064,
  "created_at" : "2015-09-17 19:21:01 +0000",
  "in_reply_to_screen_name" : "Bali_Maha",
  "in_reply_to_user_id_str" : "1535273520",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/ZBrhaceVen",
      "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2015\/09\/its-texas-hole-so-keep-on-diggin.html",
      "display_url" : "thecurmudgeonly.blogspot.co.uk\/2015\/09\/its-te\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "644582477865033728",
  "text" : "RT @pchallinor: New mudgeonry: It's a Texas hole http:\/\/t.co\/ZBrhaceVen",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 55 ],
        "url" : "http:\/\/t.co\/ZBrhaceVen",
        "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2015\/09\/its-texas-hole-so-keep-on-diggin.html",
        "display_url" : "thecurmudgeonly.blogspot.co.uk\/2015\/09\/its-te\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "644574993498669056",
    "text" : "New mudgeonry: It's a Texas hole http:\/\/t.co\/ZBrhaceVen",
    "id" : 644574993498669056,
    "created_at" : "2015-09-17 18:13:48 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 644582477865033728,
  "created_at" : "2015-09-17 18:43:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Glenn Hadikin",
      "screen_name" : "Glenn_Hadikin",
      "indices" : [ 3, 17 ],
      "id_str" : "24455799",
      "id" : 24455799
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "spoken",
      "indices" : [ 60, 67 ]
    }, {
      "text" : "corpuslinguistics",
      "indices" : [ 68, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/EMCBe4YTOH",
      "expanded_url" : "http:\/\/ivortimmis.wix.com\/theboltoncorpus",
      "display_url" : "ivortimmis.wix.com\/theboltoncorpus"
    } ]
  },
  "geo" : { },
  "id_str" : "644575540440100864",
  "text" : "RT @Glenn_Hadikin: The Bolton corpus http:\/\/t.co\/EMCBe4YTOH #spoken #corpuslinguistics",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "spoken",
        "indices" : [ 41, 48 ]
      }, {
        "text" : "corpuslinguistics",
        "indices" : [ 49, 67 ]
      } ],
      "urls" : [ {
        "indices" : [ 18, 40 ],
        "url" : "http:\/\/t.co\/EMCBe4YTOH",
        "expanded_url" : "http:\/\/ivortimmis.wix.com\/theboltoncorpus",
        "display_url" : "ivortimmis.wix.com\/theboltoncorpus"
      } ]
    },
    "geo" : { },
    "id_str" : "644555397462917120",
    "text" : "The Bolton corpus http:\/\/t.co\/EMCBe4YTOH #spoken #corpuslinguistics",
    "id" : 644555397462917120,
    "created_at" : "2015-09-17 16:55:56 +0000",
    "user" : {
      "name" : "Dr Glenn Hadikin",
      "screen_name" : "Glenn_Hadikin",
      "protected" : false,
      "id_str" : "24455799",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451444841910530052\/M3o_yNR1_normal.jpeg",
      "id" : 24455799,
      "verified" : false
    }
  },
  "id" : 644575540440100864,
  "created_at" : "2015-09-17 18:15:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Paskale",
      "screen_name" : "speak2all",
      "indices" : [ 0, 10 ],
      "id_str" : "20900313",
      "id" : 20900313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/Z976BFniPd",
      "expanded_url" : "https:\/\/github.com\/alvations\/Quotables",
      "display_url" : "github.com\/alvations\/Quot\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "644520863602241536",
  "geo" : { },
  "id_str" : "644523632149069825",
  "in_reply_to_user_id" : 20900313,
  "text" : "@speak2all oh btw u may be interested in this collection of quotes https:\/\/t.co\/Z976BFniPd",
  "id" : 644523632149069825,
  "in_reply_to_status_id" : 644520863602241536,
  "created_at" : "2015-09-17 14:49:43 +0000",
  "in_reply_to_screen_name" : "speak2all",
  "in_reply_to_user_id_str" : "20900313",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Paskale",
      "screen_name" : "speak2all",
      "indices" : [ 0, 10 ],
      "id_str" : "20900313",
      "id" : 20900313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "644520863602241536",
  "geo" : { },
  "id_str" : "644522448721956864",
  "in_reply_to_user_id" : 20900313,
  "text" : "@speak2all sure look fwd to the cards :)",
  "id" : 644522448721956864,
  "in_reply_to_status_id" : 644520863602241536,
  "created_at" : "2015-09-17 14:45:01 +0000",
  "in_reply_to_screen_name" : "speak2all",
  "in_reply_to_user_id_str" : "20900313",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kickstarter",
      "screen_name" : "kickstarter",
      "indices" : [ 13, 25 ],
      "id_str" : "16186995",
      "id" : 16186995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/YqPLKB8Dmw",
      "expanded_url" : "http:\/\/kck.st\/1UVl7gF",
      "display_url" : "kck.st\/1UVl7gF"
    } ]
  },
  "geo" : { },
  "id_str" : "644518176626241536",
  "text" : "Brand new on @Kickstarter: Dirty Rhetoric by fassforward http:\/\/t.co\/YqPLKB8Dmw",
  "id" : 644518176626241536,
  "created_at" : "2015-09-17 14:28:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/7XYSUiaDsg",
      "expanded_url" : "https:\/\/stebax.wordpress.com\/2015\/09\/17\/with-a-heavy-heart\/",
      "display_url" : "stebax.wordpress.com\/2015\/09\/17\/wit\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "644493759988826112",
  "text" : "RT @pchallinor: With a heavy heart https:\/\/t.co\/7XYSUiaDsg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 19, 42 ],
        "url" : "https:\/\/t.co\/7XYSUiaDsg",
        "expanded_url" : "https:\/\/stebax.wordpress.com\/2015\/09\/17\/with-a-heavy-heart\/",
        "display_url" : "stebax.wordpress.com\/2015\/09\/17\/wit\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "644488880503279616",
    "text" : "With a heavy heart https:\/\/t.co\/7XYSUiaDsg",
    "id" : 644488880503279616,
    "created_at" : "2015-09-17 12:31:37 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 644493759988826112,
  "created_at" : "2015-09-17 12:51:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenys Hanson",
      "screen_name" : "GlenysHanson",
      "indices" : [ 0, 13 ],
      "id_str" : "527238447",
      "id" : 527238447
    }, {
      "name" : "Douglas Carnall",
      "screen_name" : "JuliuzBeezer",
      "indices" : [ 14, 27 ],
      "id_str" : "25936824",
      "id" : 25936824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "644283948814741504",
  "geo" : { },
  "id_str" : "644435549764354048",
  "in_reply_to_user_id" : 527238447,
  "text" : "@GlenysHanson @JuliuzBeezer new word for me conchie :) thx",
  "id" : 644435549764354048,
  "in_reply_to_status_id" : 644283948814741504,
  "created_at" : "2015-09-17 08:59:42 +0000",
  "in_reply_to_screen_name" : "GlenysHanson",
  "in_reply_to_user_id_str" : "527238447",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Douglas Carnall",
      "screen_name" : "JuliuzBeezer",
      "indices" : [ 3, 16 ],
      "id_str" : "25936824",
      "id" : 25936824
    }, {
      "name" : "Jeremy Corbyn MP",
      "screen_name" : "jeremycorbyn",
      "indices" : [ 43, 56 ],
      "id_str" : "117777690",
      "id" : 117777690
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/JuliuzBeezer\/status\/644262304972824576\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/qUWHaz2Ill",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CPDhJuPWoAEO3-Q.png",
      "id_str" : "644262303861481473",
      "id" : 644262303861481473,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPDhJuPWoAEO3-Q.png",
      "sizes" : [ {
        "h" : 645,
        "resize" : "fit",
        "w" : 1277
      }, {
        "h" : 172,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 517,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 303,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/qUWHaz2Ill"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "644274756003459072",
  "text" : "RT @JuliuzBeezer: My gran would've enjoyed @jeremycorbyn's recent refusal to sing the national anthem, as my father's memoir recounts http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jeremy Corbyn MP",
        "screen_name" : "jeremycorbyn",
        "indices" : [ 25, 38 ],
        "id_str" : "117777690",
        "id" : 117777690
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/JuliuzBeezer\/status\/644262304972824576\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/qUWHaz2Ill",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CPDhJuPWoAEO3-Q.png",
        "id_str" : "644262303861481473",
        "id" : 644262303861481473,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPDhJuPWoAEO3-Q.png",
        "sizes" : [ {
          "h" : 645,
          "resize" : "fit",
          "w" : 1277
        }, {
          "h" : 172,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 517,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 303,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/qUWHaz2Ill"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "644262304972824576",
    "text" : "My gran would've enjoyed @jeremycorbyn's recent refusal to sing the national anthem, as my father's memoir recounts http:\/\/t.co\/qUWHaz2Ill",
    "id" : 644262304972824576,
    "created_at" : "2015-09-16 21:31:17 +0000",
    "user" : {
      "name" : "Douglas Carnall",
      "screen_name" : "JuliuzBeezer",
      "protected" : false,
      "id_str" : "25936824",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/114211651\/robert_burns247x165_normal.jpg",
      "id" : 25936824,
      "verified" : false
    }
  },
  "id" : 644274756003459072,
  "created_at" : "2015-09-16 22:20:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PrivacyInternational",
      "screen_name" : "privacyint",
      "indices" : [ 3, 14 ],
      "id_str" : "20982910",
      "id" : 20982910
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/privacyint\/status\/644144191451365376\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/b5k8iD6Zbn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CPB1uoSWUAQQQ0P.png",
      "id_str" : "644144190662791172",
      "id" : 644144190662791172,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPB1uoSWUAQQQ0P.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 537,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 917,
        "resize" : "fit",
        "w" : 1750
      }, {
        "h" : 314,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 178,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/b5k8iD6Zbn"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/yHZPrWOmQ1",
      "expanded_url" : "https:\/\/privacyinternational.org\/illegalspying",
      "display_url" : "privacyinternational.org\/illegalspying"
    } ]
  },
  "geo" : { },
  "id_str" : "644174079453495297",
  "text" : "RT @privacyint: Ppl globally are asking GCHQ if their comms were illegally spied on. You can too. Here's how: https:\/\/t.co\/yHZPrWOmQ1 http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/privacyint\/status\/644144191451365376\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/b5k8iD6Zbn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CPB1uoSWUAQQQ0P.png",
        "id_str" : "644144190662791172",
        "id" : 644144190662791172,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPB1uoSWUAQQQ0P.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 537,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 917,
          "resize" : "fit",
          "w" : 1750
        }, {
          "h" : 314,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 178,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/b5k8iD6Zbn"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/yHZPrWOmQ1",
        "expanded_url" : "https:\/\/privacyinternational.org\/illegalspying",
        "display_url" : "privacyinternational.org\/illegalspying"
      } ]
    },
    "geo" : { },
    "id_str" : "644144191451365376",
    "text" : "Ppl globally are asking GCHQ if their comms were illegally spied on. You can too. Here's how: https:\/\/t.co\/yHZPrWOmQ1 http:\/\/t.co\/b5k8iD6Zbn",
    "id" : 644144191451365376,
    "created_at" : "2015-09-16 13:41:57 +0000",
    "user" : {
      "name" : "PrivacyInternational",
      "screen_name" : "privacyint",
      "protected" : false,
      "id_str" : "20982910",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/570916756202344448\/twbJTmZa_normal.png",
      "id" : 20982910,
      "verified" : false
    }
  },
  "id" : 644174079453495297,
  "created_at" : "2015-09-16 15:40:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenys Hanson",
      "screen_name" : "GlenysHanson",
      "indices" : [ 0, 13 ],
      "id_str" : "527238447",
      "id" : 527238447
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "643916125345071104",
  "geo" : { },
  "id_str" : "643918077147639808",
  "in_reply_to_user_id" : 527238447,
  "text" : "@GlenysHanson my pleasure, glad u enjoyed it :)",
  "id" : 643918077147639808,
  "in_reply_to_status_id" : 643916125345071104,
  "created_at" : "2015-09-15 22:43:27 +0000",
  "in_reply_to_screen_name" : "GlenysHanson",
  "in_reply_to_user_id_str" : "527238447",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Corbyn",
      "indices" : [ 27, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "643906236979769344",
  "text" : "RT @pchallinor: Apparently #Corbyn tends to behave like a republican even though he is one. What the devil kind of politics is this?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Corbyn",
        "indices" : [ 11, 18 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "643830789638070272",
    "text" : "Apparently #Corbyn tends to behave like a republican even though he is one. What the devil kind of politics is this?",
    "id" : 643830789638070272,
    "created_at" : "2015-09-15 16:56:36 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 643906236979769344,
  "created_at" : "2015-09-15 21:56:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/Zar5RBPSyp",
      "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2015\/09\/a-wedgie-for-wog-panderers.html",
      "display_url" : "thecurmudgeonly.blogspot.co.uk\/2015\/09\/a-wedg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "643906125356777472",
  "text" : "RT @pchallinor: New mudgeonry: A wedgie for the wog-panderers http:\/\/t.co\/Zar5RBPSyp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/Zar5RBPSyp",
        "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2015\/09\/a-wedgie-for-wog-panderers.html",
        "display_url" : "thecurmudgeonly.blogspot.co.uk\/2015\/09\/a-wedg\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "643845751177658368",
    "text" : "New mudgeonry: A wedgie for the wog-panderers http:\/\/t.co\/Zar5RBPSyp",
    "id" : 643845751177658368,
    "created_at" : "2015-09-15 17:56:03 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 643906125356777472,
  "created_at" : "2015-09-15 21:55:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#ELTchat",
      "screen_name" : "ELTchat",
      "indices" : [ 3, 11 ],
      "id_str" : "189578708",
      "id" : 189578708
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/ELTchat\/status\/643808768443047936\/photo\/1",
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/FYpFW8nzvs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CO9Eqa_UkAACczx.jpg",
      "id_str" : "643808767327375360",
      "id" : 643808767327375360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CO9Eqa_UkAACczx.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 300
      } ],
      "display_url" : "pic.twitter.com\/FYpFW8nzvs"
    } ],
    "hashtags" : [ {
      "text" : "ELTchat",
      "indices" : [ 35, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/RaS363a97E",
      "expanded_url" : "http:\/\/eltchat.org\/wordpress\/summary\/happy-5th-anniversary-eltchat\/",
      "display_url" : "eltchat.org\/wordpress\/summ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "643904894718582784",
  "text" : "RT @ELTchat: Happy 5th Anniversary\u00A0#ELTchat! http:\/\/t.co\/RaS363a97E http:\/\/t.co\/FYpFW8nzvs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ELTchat\/status\/643808768443047936\/photo\/1",
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/FYpFW8nzvs",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CO9Eqa_UkAACczx.jpg",
        "id_str" : "643808767327375360",
        "id" : 643808767327375360,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CO9Eqa_UkAACczx.jpg",
        "sizes" : [ {
          "h" : 300,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 300
        } ],
        "display_url" : "pic.twitter.com\/FYpFW8nzvs"
      } ],
      "hashtags" : [ {
        "text" : "ELTchat",
        "indices" : [ 22, 30 ]
      } ],
      "urls" : [ {
        "indices" : [ 32, 54 ],
        "url" : "http:\/\/t.co\/RaS363a97E",
        "expanded_url" : "http:\/\/eltchat.org\/wordpress\/summary\/happy-5th-anniversary-eltchat\/",
        "display_url" : "eltchat.org\/wordpress\/summ\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "643808768443047936",
    "text" : "Happy 5th Anniversary\u00A0#ELTchat! http:\/\/t.co\/RaS363a97E http:\/\/t.co\/FYpFW8nzvs",
    "id" : 643808768443047936,
    "created_at" : "2015-09-15 15:29:06 +0000",
    "user" : {
      "name" : "#ELTchat",
      "screen_name" : "ELTchat",
      "protected" : false,
      "id_str" : "189578708",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1277101025\/eltchat1_normal.jpg",
      "id" : 189578708,
      "verified" : false
    }
  },
  "id" : 643904894718582784,
  "created_at" : "2015-09-15 21:51:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 0, 11 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "643366556710404096",
  "geo" : { },
  "id_str" : "643904212531851264",
  "in_reply_to_user_id" : 87902543,
  "text" : "@tornhalves hmmm indeed",
  "id" : 643904212531851264,
  "in_reply_to_status_id" : 643366556710404096,
  "created_at" : "2015-09-15 21:48:22 +0000",
  "in_reply_to_screen_name" : "tornhalves",
  "in_reply_to_user_id_str" : "87902543",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    }, {
      "name" : "Richard Seymour",
      "screen_name" : "leninology",
      "indices" : [ 37, 48 ],
      "id_str" : "15557246",
      "id" : 15557246
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Corbyn",
      "indices" : [ 112, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/hq4PZKRI0X",
      "expanded_url" : "http:\/\/www.leninology.co.uk\/2015\/09\/the-unsinkable-blairite-rubber-ducks.html",
      "display_url" : "leninology.co.uk\/2015\/09\/the-un\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "643902688908963840",
  "text" : "RT @medialens: Really excellent from @leninology: 'The unsinkable Blairite rubber ducks' http:\/\/t.co\/hq4PZKRI0X #Corbyn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Richard Seymour",
        "screen_name" : "leninology",
        "indices" : [ 22, 33 ],
        "id_str" : "15557246",
        "id" : 15557246
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Corbyn",
        "indices" : [ 97, 104 ]
      } ],
      "urls" : [ {
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/hq4PZKRI0X",
        "expanded_url" : "http:\/\/www.leninology.co.uk\/2015\/09\/the-unsinkable-blairite-rubber-ducks.html",
        "display_url" : "leninology.co.uk\/2015\/09\/the-un\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "643759837684322304",
    "text" : "Really excellent from @leninology: 'The unsinkable Blairite rubber ducks' http:\/\/t.co\/hq4PZKRI0X #Corbyn",
    "id" : 643759837684322304,
    "created_at" : "2015-09-15 12:14:40 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 643902688908963840,
  "created_at" : "2015-09-15 21:42:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Kern\u24C4h\u24B6n",
      "screen_name" : "dkernohan",
      "indices" : [ 3, 13 ],
      "id_str" : "12219232",
      "id" : 12219232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/ezPRrP5y7M",
      "expanded_url" : "http:\/\/curmudgucation.blogspot.co.uk\/2015\/09\/implementationism-and-barber.html?m=1",
      "display_url" : "curmudgucation.blogspot.co.uk\/2015\/09\/implem\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "643876806278443008",
  "text" : "RT @dkernohan: One for people who enjoy sarcasm and reviews of Michael Barber books. (a significant portion of my twitter followers) http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/ezPRrP5y7M",
        "expanded_url" : "http:\/\/curmudgucation.blogspot.co.uk\/2015\/09\/implementationism-and-barber.html?m=1",
        "display_url" : "curmudgucation.blogspot.co.uk\/2015\/09\/implem\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "643786957424861185",
    "text" : "One for people who enjoy sarcasm and reviews of Michael Barber books. (a significant portion of my twitter followers) http:\/\/t.co\/ezPRrP5y7M",
    "id" : 643786957424861185,
    "created_at" : "2015-09-15 14:02:26 +0000",
    "user" : {
      "name" : "David Kern\u24C4h\u24B6n",
      "screen_name" : "dkernohan",
      "protected" : false,
      "id_str" : "12219232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/757702202437804032\/4Xrm7IIe_normal.jpg",
      "id" : 12219232,
      "verified" : false
    }
  },
  "id" : 643876806278443008,
  "created_at" : "2015-09-15 19:59:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Speech Dudes",
      "screen_name" : "SpeechDudes",
      "indices" : [ 3, 15 ],
      "id_str" : "310919399",
      "id" : 310919399
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "slpeeps",
      "indices" : [ 95, 103 ]
    }, {
      "text" : "slpbloggers",
      "indices" : [ 105, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/N6of5G35BJ",
      "expanded_url" : "http:\/\/ow.ly\/Sa5zj",
      "display_url" : "ow.ly\/Sa5zj"
    } ]
  },
  "geo" : { },
  "id_str" : "643548841388703744",
  "text" : "RT @SpeechDudes: In case you missed it: New Dudes' post: \"Language on the Move: Flat Adverbs.\" #slpeeps, #slpbloggers http:\/\/t.co\/N6of5G35BJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "slpeeps",
        "indices" : [ 78, 86 ]
      }, {
        "text" : "slpbloggers",
        "indices" : [ 88, 100 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/N6of5G35BJ",
        "expanded_url" : "http:\/\/ow.ly\/Sa5zj",
        "display_url" : "ow.ly\/Sa5zj"
      } ]
    },
    "geo" : { },
    "id_str" : "643545296065155075",
    "text" : "In case you missed it: New Dudes' post: \"Language on the Move: Flat Adverbs.\" #slpeeps, #slpbloggers http:\/\/t.co\/N6of5G35BJ",
    "id" : 643545296065155075,
    "created_at" : "2015-09-14 22:02:09 +0000",
    "user" : {
      "name" : "Speech Dudes",
      "screen_name" : "SpeechDudes",
      "protected" : false,
      "id_str" : "310919399",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2630404839\/ded339c018067c3300f6e855e18b897b_normal.png",
      "id" : 310919399,
      "verified" : false
    }
  },
  "id" : 643548841388703744,
  "created_at" : "2015-09-14 22:16:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tekhnologic",
      "screen_name" : "tekhnologicblog",
      "indices" : [ 0, 16 ],
      "id_str" : "1486688384",
      "id" : 1486688384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "643400162186948608",
  "geo" : { },
  "id_str" : "643486663805698048",
  "in_reply_to_user_id" : 1486688384,
  "text" : "@tekhnologicblog thank you neat game :)",
  "id" : 643486663805698048,
  "in_reply_to_status_id" : 643400162186948608,
  "created_at" : "2015-09-14 18:09:10 +0000",
  "in_reply_to_screen_name" : "tekhnologicblog",
  "in_reply_to_user_id_str" : "1486688384",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Corbyn",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/0OlkeQQHX8",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=7eL8_wtS-0I",
      "display_url" : "youtube.com\/watch?v=7eL8_w\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "643388546125066240",
  "text" : "#Corbyn speaking Spanish https:\/\/t.co\/0OlkeQQHX8",
  "id" : 643388546125066240,
  "created_at" : "2015-09-14 11:39:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELTjam",
      "screen_name" : "eltjam",
      "indices" : [ 3, 10 ],
      "id_str" : "1356363686",
      "id" : 1356363686
    }, {
      "name" : "Alannah Fitzgerald",
      "screen_name" : "AlannahFitz",
      "indices" : [ 88, 100 ],
      "id_str" : "223613160",
      "id" : 223613160
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELT",
      "indices" : [ 49, 53 ]
    }, {
      "text" : "materials",
      "indices" : [ 54, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 127, 140 ],
      "url" : "http:\/\/t.co\/HIlMp5DXJh",
      "expanded_url" : "http:\/\/ow.ly\/Sat6h",
      "display_url" : "ow.ly\/Sat6h"
    } ]
  },
  "geo" : { },
  "id_str" : "643357276309450752",
  "text" : "RT @eltjam: Want to get involved in a MOOC about #ELT #materials writing and copyright? @AlannahFitz tells ELTjam all about it http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Alannah Fitzgerald",
        "screen_name" : "AlannahFitz",
        "indices" : [ 76, 88 ],
        "id_str" : "223613160",
        "id" : 223613160
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELT",
        "indices" : [ 37, 41 ]
      }, {
        "text" : "materials",
        "indices" : [ 42, 52 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/HIlMp5DXJh",
        "expanded_url" : "http:\/\/ow.ly\/Sat6h",
        "display_url" : "ow.ly\/Sat6h"
      } ]
    },
    "geo" : { },
    "id_str" : "643354021286256640",
    "text" : "Want to get involved in a MOOC about #ELT #materials writing and copyright? @AlannahFitz tells ELTjam all about it http:\/\/t.co\/HIlMp5DXJh",
    "id" : 643354021286256640,
    "created_at" : "2015-09-14 09:22:06 +0000",
    "user" : {
      "name" : "ELTjam",
      "screen_name" : "eltjam",
      "protected" : false,
      "id_str" : "1356363686",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700706017441554432\/vqyiSHTx_normal.png",
      "id" : 1356363686,
      "verified" : false
    }
  },
  "id" : 643357276309450752,
  "created_at" : "2015-09-14 09:35:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 0, 11 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/62j1ShMuVH",
      "expanded_url" : "http:\/\/i.imgur.com\/7AeYcfK.jpg",
      "display_url" : "i.imgur.com\/7AeYcfK.jpg"
    } ]
  },
  "in_reply_to_status_id_str" : "643334623146188801",
  "geo" : { },
  "id_str" : "643351814688112640",
  "in_reply_to_user_id" : 87902543,
  "text" : "@tornhalves interesting thought maybe there is an equivalent for ta of this? http:\/\/t.co\/62j1ShMuVH",
  "id" : 643351814688112640,
  "in_reply_to_status_id" : 643334623146188801,
  "created_at" : "2015-09-14 09:13:20 +0000",
  "in_reply_to_screen_name" : "tornhalves",
  "in_reply_to_user_id_str" : "87902543",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tekhnologic",
      "screen_name" : "tekhnologicblog",
      "indices" : [ 45, 61 ],
      "id_str" : "1486688384",
      "id" : 1486688384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/tfuDW9VfBU",
      "expanded_url" : "http:\/\/wp.me\/p577Go-oR",
      "display_url" : "wp.me\/p577Go-oR"
    } ]
  },
  "geo" : { },
  "id_str" : "643343788266627072",
  "text" : "The Football Game http:\/\/t.co\/tfuDW9VfBU via @tekhnologicblog",
  "id" : 643343788266627072,
  "created_at" : "2015-09-14 08:41:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 3, 14 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "criticalthinking",
      "indices" : [ 21, 38 ]
    }, {
      "text" : "education",
      "indices" : [ 42, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/bnD7FCh6tj",
      "expanded_url" : "http:\/\/bit.ly\/1JUBrLy",
      "display_url" : "bit.ly\/1JUBrLy"
    } ]
  },
  "geo" : { },
  "id_str" : "643014833940533253",
  "text" : "RT @tornhalves: When #criticalthinking in #education becomes another prop for business as usual: http:\/\/t.co\/bnD7FCh6tj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "criticalthinking",
        "indices" : [ 5, 22 ]
      }, {
        "text" : "education",
        "indices" : [ 26, 36 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/bnD7FCh6tj",
        "expanded_url" : "http:\/\/bit.ly\/1JUBrLy",
        "display_url" : "bit.ly\/1JUBrLy"
      } ]
    },
    "geo" : { },
    "id_str" : "642999185978040320",
    "text" : "When #criticalthinking in #education becomes another prop for business as usual: http:\/\/t.co\/bnD7FCh6tj",
    "id" : 642999185978040320,
    "created_at" : "2015-09-13 09:52:06 +0000",
    "user" : {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "protected" : false,
      "id_str" : "87902543",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3059742703\/1d3c7a2052db17d29644fa0a49af6480_normal.jpeg",
      "id" : 87902543,
      "verified" : false
    }
  },
  "id" : 643014833940533253,
  "created_at" : "2015-09-13 10:54:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Douglas Carnall",
      "screen_name" : "JuliuzBeezer",
      "indices" : [ 3, 16 ],
      "id_str" : "25936824",
      "id" : 25936824
    }, {
      "name" : "#JezWeCan",
      "screen_name" : "Corbyn4Leader",
      "indices" : [ 51, 65 ],
      "id_str" : "3642549741",
      "id" : 3642549741
    }, {
      "name" : "Ian Murray",
      "screen_name" : "ianmurray",
      "indices" : [ 123, 133 ],
      "id_str" : "14461089",
      "id" : 14461089
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/JuliuzBeezer\/status\/642835250146508800\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/jKVjJhhEo0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/COvPQMWWUAAJITb.jpg",
      "id_str" : "642835248930246656",
      "id" : 642835248930246656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COvPQMWWUAAJITb.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 790
      }, {
        "h" : 778,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 790
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 441,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/jKVjJhhEo0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "642836513819127813",
  "text" : "RT @JuliuzBeezer: My dad would've been celebrating @Corbyn4Leader win. Evidence: this letter, to Scotland's last Labour MP @IanMurray http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "#JezWeCan",
        "screen_name" : "Corbyn4Leader",
        "indices" : [ 33, 47 ],
        "id_str" : "3642549741",
        "id" : 3642549741
      }, {
        "name" : "Ian Murray",
        "screen_name" : "ianmurray",
        "indices" : [ 105, 115 ],
        "id_str" : "14461089",
        "id" : 14461089
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/JuliuzBeezer\/status\/642835250146508800\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/jKVjJhhEo0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/COvPQMWWUAAJITb.jpg",
        "id_str" : "642835248930246656",
        "id" : 642835248930246656,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COvPQMWWUAAJITb.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 790
        }, {
          "h" : 778,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 790
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 441,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/jKVjJhhEo0"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "642835250146508800",
    "text" : "My dad would've been celebrating @Corbyn4Leader win. Evidence: this letter, to Scotland's last Labour MP @IanMurray http:\/\/t.co\/jKVjJhhEo0",
    "id" : 642835250146508800,
    "created_at" : "2015-09-12 23:00:41 +0000",
    "user" : {
      "name" : "Douglas Carnall",
      "screen_name" : "JuliuzBeezer",
      "protected" : false,
      "id_str" : "25936824",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/114211651\/robert_burns247x165_normal.jpg",
      "id" : 25936824,
      "verified" : false
    }
  },
  "id" : 642836513819127813,
  "created_at" : "2015-09-12 23:05:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IBTimes UK",
      "screen_name" : "IBTimesUK",
      "indices" : [ 103, 113 ],
      "id_str" : "47916714",
      "id" : 47916714
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WikiLeaks",
      "indices" : [ 114, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/deGxZj7kFc",
      "expanded_url" : "http:\/\/ibt.uk\/A006NCm",
      "display_url" : "ibt.uk\/A006NCm"
    } ]
  },
  "geo" : { },
  "id_str" : "642785386121572352",
  "text" : "PhD student forced to remove all WikiLeaks references from her dissertation http:\/\/t.co\/deGxZj7kFc via @IBTimesUK #WikiLeaks",
  "id" : 642785386121572352,
  "created_at" : "2015-09-12 19:42:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer MacDonald",
      "screen_name" : "JenMac_ESL",
      "indices" : [ 0, 11 ],
      "id_str" : "608800026",
      "id" : 608800026
    }, {
      "name" : "Patrick Andrews",
      "screen_name" : "patrickelt",
      "indices" : [ 12, 23 ],
      "id_str" : "2292503990",
      "id" : 2292503990
    }, {
      "name" : "Hancock McDonald ELT",
      "screen_name" : "HancockMcDonald",
      "indices" : [ 32, 48 ],
      "id_str" : "552929354",
      "id" : 552929354
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/oIAgRY8lcx",
      "expanded_url" : "http:\/\/hancockmcdonald.com\/blog\/pronpack-sound-chart-explained",
      "display_url" : "hancockmcdonald.com\/blog\/pronpack-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "642749488579366912",
  "geo" : { },
  "id_str" : "642751441329913856",
  "in_reply_to_user_id" : 608800026,
  "text" : "@JenMac_ESL @patrickelt i think @HancockMcDonald latest chart version is good http:\/\/t.co\/oIAgRY8lcx",
  "id" : 642751441329913856,
  "in_reply_to_status_id" : 642749488579366912,
  "created_at" : "2015-09-12 17:27:40 +0000",
  "in_reply_to_screen_name" : "JenMac_ESL",
  "in_reply_to_user_id_str" : "608800026",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 0, 9 ],
      "id_str" : "121063600",
      "id" : 121063600
    }, {
      "name" : "Patrick Andrews",
      "screen_name" : "patrickelt",
      "indices" : [ 10, 21 ],
      "id_str" : "2292503990",
      "id" : 2292503990
    }, {
      "name" : "Russel Tarr",
      "screen_name" : "russeltarr",
      "indices" : [ 22, 33 ],
      "id_str" : "16912160",
      "id" : 16912160
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "642740157540626432",
  "geo" : { },
  "id_str" : "642750947349938177",
  "in_reply_to_user_id" : 121063600,
  "text" : "@whyshona @patrickelt @russeltarr wow great story",
  "id" : 642750947349938177,
  "in_reply_to_status_id" : 642740157540626432,
  "created_at" : "2015-09-12 17:25:42 +0000",
  "in_reply_to_screen_name" : "whyshona",
  "in_reply_to_user_id_str" : "121063600",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 57, 73 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/tTG7qzQ0a7",
      "expanded_url" : "http:\/\/wp.me\/p6cBF3-3q",
      "display_url" : "wp.me\/p6cBF3-3q"
    } ]
  },
  "geo" : { },
  "id_str" : "642749949453668352",
  "text" : "The fembots of Ashley Madison http:\/\/t.co\/tTG7qzQ0a7 via @wordpressdotcom",
  "id" : 642749949453668352,
  "created_at" : "2015-09-12 17:21:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Rayson",
      "screen_name" : "perayson",
      "indices" : [ 0, 9 ],
      "id_str" : "263108959",
      "id" : 263108959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "642733234510540800",
  "geo" : { },
  "id_str" : "642734998760595456",
  "in_reply_to_user_id" : 263108959,
  "text" : "@perayson :)",
  "id" : 642734998760595456,
  "in_reply_to_status_id" : 642733234510540800,
  "created_at" : "2015-09-12 16:22:19 +0000",
  "in_reply_to_screen_name" : "perayson",
  "in_reply_to_user_id_str" : "263108959",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/Th5ZlyvX7r",
      "expanded_url" : "https:\/\/docs.google.com\/spreadsheets\/d\/1f7wXi3CsHqwOFl6R5LaDnuxNn7h-A8u5iDZ3QZ7leA8\/edit",
      "display_url" : "docs.google.com\/spreadsheets\/d\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "642461509063475200",
  "geo" : { },
  "id_str" : "642732886504943620",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava updated count of phrasal verbs https:\/\/t.co\/Th5ZlyvX7r",
  "id" : 642732886504943620,
  "in_reply_to_status_id" : 642461509063475200,
  "created_at" : "2015-09-12 16:13:56 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Rayson",
      "screen_name" : "perayson",
      "indices" : [ 0, 9 ],
      "id_str" : "263108959",
      "id" : 263108959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "642729566730100736",
  "geo" : { },
  "id_str" : "642731102520639488",
  "in_reply_to_user_id" : 263108959,
  "text" : "@perayson grt thx for letting me know :)",
  "id" : 642731102520639488,
  "in_reply_to_status_id" : 642729566730100736,
  "created_at" : "2015-09-12 16:06:50 +0000",
  "in_reply_to_screen_name" : "perayson",
  "in_reply_to_user_id_str" : "263108959",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 0, 9 ],
      "id_str" : "121063600",
      "id" : 121063600
    }, {
      "name" : "Patrick Andrews",
      "screen_name" : "patrickelt",
      "indices" : [ 10, 21 ],
      "id_str" : "2292503990",
      "id" : 2292503990
    }, {
      "name" : "Russel Tarr",
      "screen_name" : "russeltarr",
      "indices" : [ 22, 33 ],
      "id_str" : "16912160",
      "id" : 16912160
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "642719918304161792",
  "geo" : { },
  "id_str" : "642724791007485952",
  "in_reply_to_user_id" : 121063600,
  "text" : "@whyshona @patrickelt @russeltarr oh great do u have a link?",
  "id" : 642724791007485952,
  "in_reply_to_status_id" : 642719918304161792,
  "created_at" : "2015-09-12 15:41:46 +0000",
  "in_reply_to_screen_name" : "whyshona",
  "in_reply_to_user_id_str" : "121063600",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/sZaiWRe7IN",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=KDE8ruratsc&feature=youtu.be&t=2h21m25s",
      "display_url" : "youtube.com\/watch?v=KDE8ru\u2026"
    }, {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/HvlRWoJodO",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=KDE8ruratsc&feature=youtu.be&t=2h12m46s",
      "display_url" : "youtube.com\/watch?v=KDE8ru\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "642724678474297344",
  "text" : "which meaning of the following \/go through\/ is found on the PHaVE list? https:\/\/t.co\/sZaiWRe7IN, https:\/\/t.co\/HvlRWoJodO",
  "id" : 642724678474297344,
  "created_at" : "2015-09-12 15:41:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chiew Pang",
      "screen_name" : "aClilToClimb",
      "indices" : [ 0, 13 ],
      "id_str" : "76160458",
      "id" : 76160458
    }, {
      "name" : "Memrise",
      "screen_name" : "memrise",
      "indices" : [ 14, 22 ],
      "id_str" : "24142010",
      "id" : 24142010
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "leadership",
      "indices" : [ 82, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/hbJ22H0gGa",
      "expanded_url" : "https:\/\/docs.google.com\/spreadsheets\/d\/1f7wXi3CsHqwOFl6R5LaDnuxNn7h-A8u5iDZ3QZ7leA8\/edit?usp=sharing",
      "display_url" : "docs.google.com\/spreadsheets\/d\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "642694263709564928",
  "geo" : { },
  "id_str" : "642701855605268482",
  "in_reply_to_user_id" : 76160458,
  "text" : "@aClilToClimb @memrise sts could explore some of the verbs used by Corbyn in last #leadership rally https:\/\/t.co\/hbJ22H0gGa :)",
  "id" : 642701855605268482,
  "in_reply_to_status_id" : 642694263709564928,
  "created_at" : "2015-09-12 14:10:37 +0000",
  "in_reply_to_screen_name" : "aClilToClimb",
  "in_reply_to_user_id_str" : "76160458",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/NIKLE2Mz3t",
      "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2015\/09\/wont-somebody-consolidate-children.html",
      "display_url" : "thecurmudgeonly.blogspot.co.uk\/2015\/09\/wont-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "642692546485972992",
  "text" : "RT @pchallinor: New mudgeonry: Won't somebody consolidate the children? http:\/\/t.co\/NIKLE2Mz3t",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/NIKLE2Mz3t",
        "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2015\/09\/wont-somebody-consolidate-children.html",
        "display_url" : "thecurmudgeonly.blogspot.co.uk\/2015\/09\/wont-s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "642320045683683328",
    "text" : "New mudgeonry: Won't somebody consolidate the children? http:\/\/t.co\/NIKLE2Mz3t",
    "id" : 642320045683683328,
    "created_at" : "2015-09-11 12:53:27 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 642692546485972992,
  "created_at" : "2015-09-12 13:33:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "642657555190284289",
  "text" : ": )",
  "id" : 642657555190284289,
  "created_at" : "2015-09-12 11:14:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    }, {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 123, 133 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/arZv107ct6",
      "expanded_url" : "http:\/\/www.medialens.org\/index.php\/alerts\/alert-archive\/2015\/801-invisible-war-crimes-the-corporate-media-on-yemen.html",
      "display_url" : "medialens.org\/index.php\/aler\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "642623378784944128",
  "text" : "RT @johnwhilley: Another dark crime passed over by service media: the West key role in Yemen's violence. Fine exposure via @medialens http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Media Lens",
        "screen_name" : "medialens",
        "indices" : [ 106, 116 ],
        "id_str" : "6531902",
        "id" : 6531902
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/arZv107ct6",
        "expanded_url" : "http:\/\/www.medialens.org\/index.php\/alerts\/alert-archive\/2015\/801-invisible-war-crimes-the-corporate-media-on-yemen.html",
        "display_url" : "medialens.org\/index.php\/aler\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "641906252885422080",
    "text" : "Another dark crime passed over by service media: the West key role in Yemen's violence. Fine exposure via @medialens http:\/\/t.co\/arZv107ct6",
    "id" : 641906252885422080,
    "created_at" : "2015-09-10 09:29:11 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 642623378784944128,
  "created_at" : "2015-09-12 08:58:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 53, 68 ],
      "id_str" : "285614027",
      "id" : 285614027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/ePLmH354B8",
      "expanded_url" : "http:\/\/www.anthonyteacher.com\/blog\/listening-journals-redux",
      "display_url" : "anthonyteacher.com\/blog\/listening\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "642596267760164864",
  "text" : "Listening Journals: Redux http:\/\/t.co\/ePLmH354B8 via @AnthonyTeacher",
  "id" : 642596267760164864,
  "created_at" : "2015-09-12 07:11:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Al Cook",
      "screen_name" : "brokenglasseye",
      "indices" : [ 3, 18 ],
      "id_str" : "22280913",
      "id" : 22280913
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/brokenglasseye\/status\/640988524754432001\/photo\/1",
      "indices" : [ 121, 140 ],
      "url" : "http:\/\/t.co\/pmudxJcuk7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/COU_mi8WcAAzcs3.jpg",
      "id_str" : "640988453417676800",
      "id" : 640988453417676800,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COU_mi8WcAAzcs3.jpg",
      "sizes" : [ {
        "h" : 431,
        "resize" : "fit",
        "w" : 615
      }, {
        "h" : 238,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 431,
        "resize" : "fit",
        "w" : 615
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 420,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/pmudxJcuk7"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "642464273894125568",
  "text" : "RT @brokenglasseye: Frankie Boyle is a really funny guy. But I think he's more important when he says stuff like this... http:\/\/t.co\/pmudxJ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/brokenglasseye\/status\/640988524754432001\/photo\/1",
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/pmudxJcuk7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/COU_mi8WcAAzcs3.jpg",
        "id_str" : "640988453417676800",
        "id" : 640988453417676800,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COU_mi8WcAAzcs3.jpg",
        "sizes" : [ {
          "h" : 431,
          "resize" : "fit",
          "w" : 615
        }, {
          "h" : 238,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 431,
          "resize" : "fit",
          "w" : 615
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 420,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/pmudxJcuk7"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "640988524754432001",
    "text" : "Frankie Boyle is a really funny guy. But I think he's more important when he says stuff like this... http:\/\/t.co\/pmudxJcuk7",
    "id" : 640988524754432001,
    "created_at" : "2015-09-07 20:42:27 +0000",
    "user" : {
      "name" : "Al Cook",
      "screen_name" : "brokenglasseye",
      "protected" : false,
      "id_str" : "22280913",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/601328428814565376\/3uEAPLHU_normal.jpg",
      "id" : 22280913,
      "verified" : false
    }
  },
  "id" : 642464273894125568,
  "created_at" : "2015-09-11 22:26:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "labourleadership",
      "indices" : [ 116, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/1BXSil5QAF",
      "expanded_url" : "http:\/\/phave-dictionary.englishup.me",
      "display_url" : "phave-dictionary.englishup.me"
    }, {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/iFrimE3PfR",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=KDE8ruratsc&feature=youtu.be&t=2h27m29s",
      "display_url" : "youtube.com\/watch?v=KDE8ru\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "642461509063475200",
  "text" : "more common man Corbyn 10\/17 phrasal verbs in http:\/\/t.co\/1BXSil5QAF stand up 8 tokens e.g. https:\/\/t.co\/iFrimE3PfR #labourleadership",
  "id" : 642461509063475200,
  "created_at" : "2015-09-11 22:15:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Andrews",
      "screen_name" : "patrickelt",
      "indices" : [ 0, 11 ],
      "id_str" : "2292503990",
      "id" : 2292503990
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/QHcV8p8O8o",
      "expanded_url" : "https:\/\/speak2all.wordpress.com\/2013\/07\/12\/analysis-of-malala-yousafzais-speech-to-the-un-general-assembly\/",
      "display_url" : "speak2all.wordpress.com\/2013\/07\/12\/ana\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "642354003288948736",
  "geo" : { },
  "id_str" : "642364272341815296",
  "in_reply_to_user_id" : 2292503990,
  "text" : "@patrickelt great nice example there, this is a good post on some rhetoric techniques in a speech https:\/\/t.co\/QHcV8p8O8o",
  "id" : 642364272341815296,
  "in_reply_to_status_id" : 642354003288948736,
  "created_at" : "2015-09-11 15:49:11 +0000",
  "in_reply_to_screen_name" : "patrickelt",
  "in_reply_to_user_id_str" : "2292503990",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/TCvPNNKsPP",
      "expanded_url" : "http:\/\/patrickdandrews.blogspot.com\/2015\/09\/persuasion-2.html",
      "display_url" : "patrickdandrews.blogspot.com\/2015\/09\/persua\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "642363864756158464",
  "text" : "Persuasion 2 http:\/\/t.co\/TCvPNNKsPP",
  "id" : 642363864756158464,
  "created_at" : "2015-09-11 15:47:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Rayson",
      "screen_name" : "perayson",
      "indices" : [ 0, 9 ],
      "id_str" : "263108959",
      "id" : 263108959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "642349893374361600",
  "geo" : { },
  "id_str" : "642350246186590208",
  "in_reply_to_user_id" : 263108959,
  "text" : "@perayson right thx think will hold off a bit more :)",
  "id" : 642350246186590208,
  "in_reply_to_status_id" : 642349893374361600,
  "created_at" : "2015-09-11 14:53:27 +0000",
  "in_reply_to_screen_name" : "perayson",
  "in_reply_to_user_id_str" : "263108959",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Andrews",
      "screen_name" : "patrickelt",
      "indices" : [ 0, 11 ],
      "id_str" : "2292503990",
      "id" : 2292503990
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "642347315936759809",
  "geo" : { },
  "id_str" : "642348805137002496",
  "in_reply_to_user_id" : 2292503990,
  "text" : "@patrickelt feel free to use them if u want :) if u do be great to get some feedback not yet tested them on my students!",
  "id" : 642348805137002496,
  "in_reply_to_status_id" : 642347315936759809,
  "created_at" : "2015-09-11 14:47:44 +0000",
  "in_reply_to_screen_name" : "patrickelt",
  "in_reply_to_user_id_str" : "2292503990",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Andrews",
      "screen_name" : "patrickelt",
      "indices" : [ 0, 11 ],
      "id_str" : "2292503990",
      "id" : 2292503990
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "642347475555250177",
  "geo" : { },
  "id_str" : "642348009041326080",
  "in_reply_to_user_id" : 2292503990,
  "text" : "@patrickelt definitely not always easy to put in practice though..",
  "id" : 642348009041326080,
  "in_reply_to_status_id" : 642347475555250177,
  "created_at" : "2015-09-11 14:44:34 +0000",
  "in_reply_to_screen_name" : "patrickelt",
  "in_reply_to_user_id_str" : "2292503990",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Rayson",
      "screen_name" : "perayson",
      "indices" : [ 0, 9 ],
      "id_str" : "263108959",
      "id" : 263108959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "642345135980871680",
  "geo" : { },
  "id_str" : "642346633217372160",
  "in_reply_to_user_id" : 263108959,
  "text" : "@perayson anything break? not yet brave enuff to take plunge!",
  "id" : 642346633217372160,
  "in_reply_to_status_id" : 642345135980871680,
  "created_at" : "2015-09-11 14:39:06 +0000",
  "in_reply_to_screen_name" : "perayson",
  "in_reply_to_user_id_str" : "263108959",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Andrews",
      "screen_name" : "patrickelt",
      "indices" : [ 0, 11 ],
      "id_str" : "2292503990",
      "id" : 2292503990
    }, {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 12, 21 ],
      "id_str" : "121063600",
      "id" : 121063600
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/642340101238996992\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/yt9HlSim1J",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/COoM6wZW8AAV0Ka.png",
      "id_str" : "642340100416925696",
      "id" : 642340100416925696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COoM6wZW8AAV0Ka.png",
      "sizes" : [ {
        "h" : 62,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 109,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 179,
        "resize" : "fit",
        "w" : 986
      }, {
        "h" : 179,
        "resize" : "fit",
        "w" : 986
      } ],
      "display_url" : "pic.twitter.com\/yt9HlSim1J"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "642271386107572224",
  "geo" : { },
  "id_str" : "642340101238996992",
  "in_reply_to_user_id" : 2292503990,
  "text" : "@patrickelt @whyshona hi Patrick source is yours truely attach +1 though think i may be flogging dead horse :) http:\/\/t.co\/yt9HlSim1J",
  "id" : 642340101238996992,
  "in_reply_to_status_id" : 642271386107572224,
  "created_at" : "2015-09-11 14:13:08 +0000",
  "in_reply_to_screen_name" : "patrickelt",
  "in_reply_to_user_id_str" : "2292503990",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arthur Charpentier",
      "screen_name" : "freakonometrics",
      "indices" : [ 3, 19 ],
      "id_str" : "105530526",
      "id" : 105530526
    }, {
      "name" : "Visions carto",
      "screen_name" : "visionscarto",
      "indices" : [ 69, 82 ],
      "id_str" : "63508984",
      "id" : 63508984
    }, {
      "name" : "Fil",
      "screen_name" : "recifs",
      "indices" : [ 125, 132 ],
      "id_str" : "201856958",
      "id" : 201856958
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/freakonometrics\/status\/641986579821629440\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/ACox94fGVN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/COjLZBKVAAAwrpa.png",
      "id_str" : "641986577569218560",
      "id" : 641986577569218560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COjLZBKVAAAwrpa.png",
      "sizes" : [ {
        "h" : 330,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 617,
        "resize" : "fit",
        "w" : 636
      }, {
        "h" : 582,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 617,
        "resize" : "fit",
        "w" : 636
      } ],
      "display_url" : "pic.twitter.com\/ACox94fGVN"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/U8irU7DJzn",
      "expanded_url" : "http:\/\/visionscarto.net\/cartes-minimalistes",
      "display_url" : "visionscarto.net\/cartes-minimal\u2026"
    }, {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/b11KnOIihE",
      "expanded_url" : "http:\/\/freakonometrics.hypotheses.org\/20263",
      "display_url" : "freakonometrics.hypotheses.org\/20263"
    } ]
  },
  "geo" : { },
  "id_str" : "642000822197465088",
  "text" : "RT @freakonometrics: Cartes Minimalistes http:\/\/t.co\/U8irU7DJzn chez @visionscarto, voir aussi http:\/\/t.co\/b11KnOIihE (merci @recifs) http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Visions carto",
        "screen_name" : "visionscarto",
        "indices" : [ 48, 61 ],
        "id_str" : "63508984",
        "id" : 63508984
      }, {
        "name" : "Fil",
        "screen_name" : "recifs",
        "indices" : [ 104, 111 ],
        "id_str" : "201856958",
        "id" : 201856958
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/freakonometrics\/status\/641986579821629440\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/ACox94fGVN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/COjLZBKVAAAwrpa.png",
        "id_str" : "641986577569218560",
        "id" : 641986577569218560,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COjLZBKVAAAwrpa.png",
        "sizes" : [ {
          "h" : 330,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 617,
          "resize" : "fit",
          "w" : 636
        }, {
          "h" : 582,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 617,
          "resize" : "fit",
          "w" : 636
        } ],
        "display_url" : "pic.twitter.com\/ACox94fGVN"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 20, 42 ],
        "url" : "http:\/\/t.co\/U8irU7DJzn",
        "expanded_url" : "http:\/\/visionscarto.net\/cartes-minimalistes",
        "display_url" : "visionscarto.net\/cartes-minimal\u2026"
      }, {
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/b11KnOIihE",
        "expanded_url" : "http:\/\/freakonometrics.hypotheses.org\/20263",
        "display_url" : "freakonometrics.hypotheses.org\/20263"
      } ]
    },
    "geo" : { },
    "id_str" : "641986579821629440",
    "text" : "Cartes Minimalistes http:\/\/t.co\/U8irU7DJzn chez @visionscarto, voir aussi http:\/\/t.co\/b11KnOIihE (merci @recifs) http:\/\/t.co\/ACox94fGVN",
    "id" : 641986579821629440,
    "created_at" : "2015-09-10 14:48:22 +0000",
    "user" : {
      "name" : "Arthur Charpentier",
      "screen_name" : "freakonometrics",
      "protected" : false,
      "id_str" : "105530526",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/753994578131357696\/6_ps0aEW_normal.jpg",
      "id" : 105530526,
      "verified" : true
    }
  },
  "id" : 642000822197465088,
  "created_at" : "2015-09-10 15:44:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 0, 9 ],
      "id_str" : "121063600",
      "id" : 121063600
    }, {
      "name" : "Patrick Andrews",
      "screen_name" : "patrickelt",
      "indices" : [ 71, 82 ],
      "id_str" : "2292503990",
      "id" : 2292503990
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/641995394122186752\/photo\/1",
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/Edgg2MEog5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/COjTaHPWEAAh5ji.png",
      "id_str" : "641995392473763840",
      "id" : 641995392473763840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COjTaHPWEAAh5ji.png",
      "sizes" : [ {
        "h" : 62,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 109,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 179,
        "resize" : "fit",
        "w" : 986
      }, {
        "h" : 179,
        "resize" : "fit",
        "w" : 986
      } ],
      "display_url" : "pic.twitter.com\/Edgg2MEog5"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "641915833908899840",
  "geo" : { },
  "id_str" : "641995394122186752",
  "in_reply_to_user_id" : 121063600,
  "text" : "@whyshona thx for mention, attaching minions do rhetoric graphic :) cc @patrickelt http:\/\/t.co\/Edgg2MEog5",
  "id" : 641995394122186752,
  "in_reply_to_status_id" : 641915833908899840,
  "created_at" : "2015-09-10 15:23:24 +0000",
  "in_reply_to_screen_name" : "whyshona",
  "in_reply_to_user_id_str" : "121063600",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oliver Huitson",
      "screen_name" : "OllyHuitson",
      "indices" : [ 3, 15 ],
      "id_str" : "229221523",
      "id" : 229221523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/j1b2IaZL07",
      "expanded_url" : "https:\/\/www.opendemocracy.net\/ourkingdom\/joe-guinan-thomas-m-hanna\/dont-believe-corbyn-bashers-economic-case-against-public-owners#.Ve_tFYV7Yr0.twitter",
      "display_url" : "opendemocracy.net\/ourkingdom\/joe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "641930578720346112",
  "text" : "RT @OllyHuitson: Required reading: Don't believe the Corbyn bashers - the economic case against public ownership is mostly fantasy https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/j1b2IaZL07",
        "expanded_url" : "https:\/\/www.opendemocracy.net\/ourkingdom\/joe-guinan-thomas-m-hanna\/dont-believe-corbyn-bashers-economic-case-against-public-owners#.Ve_tFYV7Yr0.twitter",
        "display_url" : "opendemocracy.net\/ourkingdom\/joe\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "641528176208924672",
    "text" : "Required reading: Don't believe the Corbyn bashers - the economic case against public ownership is mostly fantasy https:\/\/t.co\/j1b2IaZL07",
    "id" : 641528176208924672,
    "created_at" : "2015-09-09 08:26:50 +0000",
    "user" : {
      "name" : "Oliver Huitson",
      "screen_name" : "OllyHuitson",
      "protected" : false,
      "id_str" : "229221523",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1600897679\/IMG_3029_-_Copy_normal.JPG",
      "id" : 229221523,
      "verified" : false
    }
  },
  "id" : 641930578720346112,
  "created_at" : "2015-09-10 11:05:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 0, 9 ],
      "id_str" : "134211317",
      "id" : 134211317
    }, {
      "name" : "Oliver Huitson",
      "screen_name" : "OllyHuitson",
      "indices" : [ 10, 22 ],
      "id_str" : "229221523",
      "id" : 229221523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "641892538207600640",
  "geo" : { },
  "id_str" : "641893071416881152",
  "in_reply_to_user_id" : 134211317,
  "text" : "@josipa74 @OllyHuitson thx Paul, looking for other text speeches difficult to find!",
  "id" : 641893071416881152,
  "in_reply_to_status_id" : 641892538207600640,
  "created_at" : "2015-09-10 08:36:48 +0000",
  "in_reply_to_screen_name" : "josipa74",
  "in_reply_to_user_id_str" : "134211317",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oliver Huitson",
      "screen_name" : "OllyHuitson",
      "indices" : [ 0, 12 ],
      "id_str" : "229221523",
      "id" : 229221523
    }, {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 13, 22 ],
      "id_str" : "134211317",
      "id" : 134211317
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/641892089609998336\/photo\/1",
      "indices" : [ 120, 142 ],
      "url" : "http:\/\/t.co\/dyGerWX8KJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/COh1dCtWgAA61WV.png",
      "id_str" : "641892088704040960",
      "id" : 641892088704040960,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COh1dCtWgAA61WV.png",
      "sizes" : [ {
        "h" : 168,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 296,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 505,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 708,
        "resize" : "fit",
        "w" : 1437
      } ],
      "display_url" : "pic.twitter.com\/dyGerWX8KJ"
    } ],
    "hashtags" : [ {
      "text" : "labourleadership",
      "indices" : [ 79, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/6Iwy0ypf44",
      "expanded_url" : "http:\/\/lableader-speeches.englishup.me\/",
      "display_url" : "lableader-speeches.englishup.me"
    } ]
  },
  "in_reply_to_status_id_str" : "641528176208924672",
  "geo" : { },
  "id_str" : "641892089609998336",
  "in_reply_to_user_id" : 229221523,
  "text" : "@OllyHuitson @josipa74 grt essay, public +freq &amp; diff by Corbyn vs Burnham #labourleadership http:\/\/t.co\/6Iwy0ypf44 http:\/\/t.co\/dyGerWX8KJ",
  "id" : 641892089609998336,
  "in_reply_to_status_id" : 641528176208924672,
  "created_at" : "2015-09-10 08:32:54 +0000",
  "in_reply_to_screen_name" : "OllyHuitson",
  "in_reply_to_user_id_str" : "229221523",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Jones",
      "screen_name" : "djplaner",
      "indices" : [ 3, 12 ],
      "id_str" : "16282582",
      "id" : 16282582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/2jvD5tvRl8",
      "expanded_url" : "https:\/\/davidtjones.wordpress.com\/2015\/09\/10\/what-type-of-digital-knowledge-does-a-teacher-need\/",
      "display_url" : "davidtjones.wordpress.com\/2015\/09\/10\/wha\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "641876222876778496",
  "text" : "RT @djplaner: New post - https:\/\/t.co\/2jvD5tvRl8 - What type of \u201Cdigital knowledge\u201D does a teacher need. Exploring expansion of visitor\/res\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 11, 34 ],
        "url" : "https:\/\/t.co\/2jvD5tvRl8",
        "expanded_url" : "https:\/\/davidtjones.wordpress.com\/2015\/09\/10\/what-type-of-digital-knowledge-does-a-teacher-need\/",
        "display_url" : "davidtjones.wordpress.com\/2015\/09\/10\/wha\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "641815072566718464",
    "text" : "New post - https:\/\/t.co\/2jvD5tvRl8 - What type of \u201Cdigital knowledge\u201D does a teacher need. Exploring expansion of visitor\/resident",
    "id" : 641815072566718464,
    "created_at" : "2015-09-10 03:26:52 +0000",
    "user" : {
      "name" : "David Jones",
      "screen_name" : "djplaner",
      "protected" : false,
      "id_str" : "16282582",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3167763216\/c60c5bdbacfbd62fdeeb2809daf843b1_normal.jpeg",
      "id" : 16282582,
      "verified" : false
    }
  },
  "id" : 641876222876778496,
  "created_at" : "2015-09-10 07:29:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/q8fQXzpUdq",
      "expanded_url" : "http:\/\/patrickdandrews.blogspot.com\/2015\/09\/teaching-students-persuasive-techniques.html",
      "display_url" : "patrickdandrews.blogspot.com\/2015\/09\/teachi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "641869257425448960",
  "text" : "Teaching students persuasive techniques http:\/\/t.co\/q8fQXzpUdq",
  "id" : 641869257425448960,
  "created_at" : "2015-09-10 07:02:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cambridge Uni Press",
      "screen_name" : "CambridgeUP",
      "indices" : [ 3, 15 ],
      "id_str" : "319110295",
      "id" : 319110295
    }, {
      "name" : "Cambridge Uni Press",
      "screen_name" : "CambridgeUP",
      "indices" : [ 32, 44 ],
      "id_str" : "319110295",
      "id" : 319110295
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 125, 140 ],
      "url" : "http:\/\/t.co\/LjvC5donDC",
      "expanded_url" : "http:\/\/ow.ly\/RY3ud",
      "display_url" : "ow.ly\/RY3ud"
    } ]
  },
  "geo" : { },
  "id_str" : "641669221911535616",
  "text" : "RT @CambridgeUP: According to a @cambridgeup study, we talk about education nearly twice as much as we did twenty years ago. http:\/\/t.co\/Lj\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Cambridge Uni Press",
        "screen_name" : "CambridgeUP",
        "indices" : [ 15, 27 ],
        "id_str" : "319110295",
        "id" : 319110295
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/LjvC5donDC",
        "expanded_url" : "http:\/\/ow.ly\/RY3ud",
        "display_url" : "ow.ly\/RY3ud"
      } ]
    },
    "geo" : { },
    "id_str" : "641524843855376384",
    "text" : "According to a @cambridgeup study, we talk about education nearly twice as much as we did twenty years ago. http:\/\/t.co\/LjvC5donDC",
    "id" : 641524843855376384,
    "created_at" : "2015-09-09 08:13:36 +0000",
    "user" : {
      "name" : "Cambridge Uni Press",
      "screen_name" : "CambridgeUP",
      "protected" : false,
      "id_str" : "319110295",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/431787582209290240\/Op9gQts4_normal.png",
      "id" : 319110295,
      "verified" : false
    }
  },
  "id" : 641669221911535616,
  "created_at" : "2015-09-09 17:47:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "indices" : [ 3, 18 ],
      "id_str" : "27716419",
      "id" : 27716419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 140 ],
      "url" : "http:\/\/t.co\/lAkzA13JsS",
      "expanded_url" : "http:\/\/www.craigmurray.org.uk\/archives\/2015\/09\/exclusive-i-can-reveal-the-legal-advice-on-drone-strikes-and-how-the-establishment-works\/",
      "display_url" : "craigmurray.org.uk\/archives\/2015\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "641635812359176192",
  "text" : "RT @CraigMurrayOrg: New post: Exclusive: I Can Reveal the Legal Advice on Drone Strikes, and How the Establishment Works http:\/\/t.co\/lAkzA1\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.craigmurray.org.uk\" rel=\"nofollow\"\u003ECraig Murray posting plugin\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/lAkzA13JsS",
        "expanded_url" : "http:\/\/www.craigmurray.org.uk\/archives\/2015\/09\/exclusive-i-can-reveal-the-legal-advice-on-drone-strikes-and-how-the-establishment-works\/",
        "display_url" : "craigmurray.org.uk\/archives\/2015\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "641601231618723840",
    "text" : "New post: Exclusive: I Can Reveal the Legal Advice on Drone Strikes, and How the Establishment Works http:\/\/t.co\/lAkzA13JsS",
    "id" : 641601231618723840,
    "created_at" : "2015-09-09 13:17:08 +0000",
    "user" : {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "protected" : false,
      "id_str" : "27716419",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1388436826\/cm_normal.jpg",
      "id" : 27716419,
      "verified" : false
    }
  },
  "id" : 641635812359176192,
  "created_at" : "2015-09-09 15:34:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Federica Formato",
      "screen_name" : "federicalancs",
      "indices" : [ 3, 17 ],
      "id_str" : "39983021",
      "id" : 39983021
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CorpusMOOC",
      "indices" : [ 40, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/mAb5EjY8nq",
      "expanded_url" : "https:\/\/www.futurelearn.com\/courses\/corpus-linguistics",
      "display_url" : "futurelearn.com\/courses\/corpus\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "641588639982596096",
  "text" : "RT @federicalancs: Do you know that the #CorpusMOOC is starting in 19 days? (28th Sept). You can register here: https:\/\/t.co\/mAb5EjY8nq. HI\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CorpusMOOC",
        "indices" : [ 21, 32 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/mAb5EjY8nq",
        "expanded_url" : "https:\/\/www.futurelearn.com\/courses\/corpus-linguistics",
        "display_url" : "futurelearn.com\/courses\/corpus\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "641504839458009088",
    "text" : "Do you know that the #CorpusMOOC is starting in 19 days? (28th Sept). You can register here: https:\/\/t.co\/mAb5EjY8nq. HIGHLY RECOMMENDED!",
    "id" : 641504839458009088,
    "created_at" : "2015-09-09 06:54:06 +0000",
    "user" : {
      "name" : "Federica Formato",
      "screen_name" : "federicalancs",
      "protected" : false,
      "id_str" : "39983021",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/726421949161824256\/UbCtWzPQ_normal.jpg",
      "id" : 39983021,
      "verified" : false
    }
  },
  "id" : 641588639982596096,
  "created_at" : "2015-09-09 12:27:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Andrews",
      "screen_name" : "patrickelt",
      "indices" : [ 0, 11 ],
      "id_str" : "2292503990",
      "id" : 2292503990
    }, {
      "name" : "Jennifer MacDonald",
      "screen_name" : "JenMac_ESL",
      "indices" : [ 12, 23 ],
      "id_str" : "608800026",
      "id" : 608800026
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "641581342581489664",
  "geo" : { },
  "id_str" : "641583322045485056",
  "in_reply_to_user_id" : 2292503990,
  "text" : "@patrickelt @JenMac_ESL i guess if we assume knowing IPA chart is a proxy for knowing how to help students with pron?",
  "id" : 641583322045485056,
  "in_reply_to_status_id" : 641581342581489664,
  "created_at" : "2015-09-09 12:05:58 +0000",
  "in_reply_to_screen_name" : "patrickelt",
  "in_reply_to_user_id_str" : "2292503990",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/2SxM0OMCI8",
      "expanded_url" : "http:\/\/www.sodiumhaze.org\/2015\/09\/09\/a-child-drowns-who-can-we-bomb-customer-update-from-the-british-media\/",
      "display_url" : "sodiumhaze.org\/2015\/09\/09\/a-c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "641581957101559808",
  "text" : "A child drowns \u2013 who can we bomb? Customer update from the British Media http:\/\/t.co\/2SxM0OMCI8",
  "id" : 641581957101559808,
  "created_at" : "2015-09-09 12:00:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bella Caledonia",
      "screen_name" : "bellacaledonia",
      "indices" : [ 3, 18 ],
      "id_str" : "103554348",
      "id" : 103554348
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "syco",
      "indices" : [ 130, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "641575731051528192",
  "text" : "RT @bellacaledonia: Bella is offering a special prize for the best example of royalist sycophancy today. Nominations are now open #syco",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "syco",
        "indices" : [ 110, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "641542271696023552",
    "text" : "Bella is offering a special prize for the best example of royalist sycophancy today. Nominations are now open #syco",
    "id" : 641542271696023552,
    "created_at" : "2015-09-09 09:22:51 +0000",
    "user" : {
      "name" : "Bella Caledonia",
      "screen_name" : "bellacaledonia",
      "protected" : false,
      "id_str" : "103554348",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/732831340194897925\/WGVyJGiO_normal.jpg",
      "id" : 103554348,
      "verified" : false
    }
  },
  "id" : 641575731051528192,
  "created_at" : "2015-09-09 11:35:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monika Sobejko",
      "screen_name" : "SobejM",
      "indices" : [ 0, 7 ],
      "id_str" : "380504775",
      "id" : 380504775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "641562371555782656",
  "geo" : { },
  "id_str" : "641569033754673152",
  "in_reply_to_user_id" : 380504775,
  "text" : "@SobejM congrats :)",
  "id" : 641569033754673152,
  "in_reply_to_status_id" : 641562371555782656,
  "created_at" : "2015-09-09 11:09:12 +0000",
  "in_reply_to_screen_name" : "SobejM",
  "in_reply_to_user_id_str" : "380504775",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "indices" : [ 3, 18 ],
      "id_str" : "27716419",
      "id" : 27716419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/nDsGXL46MO",
      "expanded_url" : "http:\/\/www.craigmurray.org.uk\/archives\/2015\/09\/operation-flavius-and-the-killer-cameron\/",
      "display_url" : "craigmurray.org.uk\/archives\/2015\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "641357838653063168",
  "text" : "RT @CraigMurrayOrg: New post: Operation Flavius and the Killer Cameron http:\/\/t.co\/nDsGXL46MO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.craigmurray.org.uk\" rel=\"nofollow\"\u003ECraig Murray posting plugin\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 73 ],
        "url" : "http:\/\/t.co\/nDsGXL46MO",
        "expanded_url" : "http:\/\/www.craigmurray.org.uk\/archives\/2015\/09\/operation-flavius-and-the-killer-cameron\/",
        "display_url" : "craigmurray.org.uk\/archives\/2015\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "641154120200638464",
    "text" : "New post: Operation Flavius and the Killer Cameron http:\/\/t.co\/nDsGXL46MO",
    "id" : 641154120200638464,
    "created_at" : "2015-09-08 07:40:28 +0000",
    "user" : {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "protected" : false,
      "id_str" : "27716419",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1388436826\/cm_normal.jpg",
      "id" : 27716419,
      "verified" : false
    }
  },
  "id" : 641357838653063168,
  "created_at" : "2015-09-08 21:09:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Free",
      "screen_name" : "LALIGNEDEFREE",
      "indices" : [ 0, 14 ],
      "id_str" : "58920430",
      "id" : 58920430
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "641221927680520192",
  "in_reply_to_user_id" : 58920430,
  "text" : "@LALIGNEDEFREE Ma ligne mobile a ete piratee. Appel du 3666 pour 20 euros. N'arrive pas a joindre services techniques (satures). Que faire ?",
  "id" : 641221927680520192,
  "created_at" : "2015-09-08 12:09:55 +0000",
  "in_reply_to_screen_name" : "LALIGNEDEFREE",
  "in_reply_to_user_id_str" : "58920430",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/54gJmuPxDp",
      "expanded_url" : "http:\/\/www.macmillandictionaryblog.com\/welcome-to-real-vocabulary",
      "display_url" : "macmillandictionaryblog.com\/welcome-to-rea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "641218915377524736",
  "text" : "Following Real Grammar, welcome to Real Vocabulary http:\/\/t.co\/54gJmuPxDp",
  "id" : 641218915377524736,
  "created_at" : "2015-09-08 11:57:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greg Ashman",
      "screen_name" : "greg_ashman",
      "indices" : [ 93, 105 ],
      "id_str" : "614246029",
      "id" : 614246029
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/D2DDWHm4cm",
      "expanded_url" : "http:\/\/wp.me\/p3X3By-di",
      "display_url" : "wp.me\/p3X3By-di"
    } ]
  },
  "geo" : { },
  "id_str" : "641170252953468929",
  "text" : "Busting the number one myth of problem-based and inquiry learning http:\/\/t.co\/D2DDWHm4cm via @greg_ashman",
  "id" : 641170252953468929,
  "created_at" : "2015-09-08 08:44:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/jZz2w8KuYJ",
      "expanded_url" : "http:\/\/www.wsws.org\/en\/articles\/2015\/09\/08\/uksy-s08.html",
      "display_url" : "wsws.org\/en\/articles\/20\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "641165892177534976",
  "text" : "Prime Minister Cameron confirms Royal Air Force killed two British citizens in Syria - World Socialist Web Site: http:\/\/t.co\/jZz2w8KuYJ",
  "id" : 641165892177534976,
  "created_at" : "2015-09-08 08:27:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Mannion",
      "screen_name" : "pedagog_machine",
      "indices" : [ 100, 116 ],
      "id_str" : "367360404",
      "id" : 367360404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/n0lIpabxE1",
      "expanded_url" : "http:\/\/wp.me\/p3eEtK-aC",
      "display_url" : "wp.me\/p3eEtK-aC"
    } ]
  },
  "geo" : { },
  "id_str" : "640977615625523200",
  "text" : "Reflections on researchED, part 1: Prof Coe on what works, RCTs and 'me' http:\/\/t.co\/n0lIpabxE1 via @pedagog_machine",
  "id" : 640977615625523200,
  "created_at" : "2015-09-07 19:59:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    }, {
      "name" : "Owen Jones",
      "screen_name" : "OwenJones84",
      "indices" : [ 126, 138 ],
      "id_str" : "65045121",
      "id" : 65045121
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "refugeeswelcome",
      "indices" : [ 101, 117 ]
    }, {
      "text" : "Corbyn",
      "indices" : [ 118, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/1MQCk37c0q",
      "expanded_url" : "http:\/\/johnhilley.blogspot.co.uk\/2015\/09\/guardian-liberal-war-agenda-no-fly-zone.html",
      "display_url" : "johnhilley.blogspot.co.uk\/2015\/09\/guardi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "640898475371196416",
  "text" : "RT @johnwhilley: Guardian-liberal war agenda - a 'no-fly zone' for criticism  http:\/\/t.co\/1MQCk37c0q #refugeeswelcome #Corbyn @OwenJones84",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Owen Jones",
        "screen_name" : "OwenJones84",
        "indices" : [ 109, 121 ],
        "id_str" : "65045121",
        "id" : 65045121
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "refugeeswelcome",
        "indices" : [ 84, 100 ]
      }, {
        "text" : "Corbyn",
        "indices" : [ 101, 108 ]
      } ],
      "urls" : [ {
        "indices" : [ 61, 83 ],
        "url" : "http:\/\/t.co\/1MQCk37c0q",
        "expanded_url" : "http:\/\/johnhilley.blogspot.co.uk\/2015\/09\/guardian-liberal-war-agenda-no-fly-zone.html",
        "display_url" : "johnhilley.blogspot.co.uk\/2015\/09\/guardi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "640894393713606656",
    "text" : "Guardian-liberal war agenda - a 'no-fly zone' for criticism  http:\/\/t.co\/1MQCk37c0q #refugeeswelcome #Corbyn @OwenJones84",
    "id" : 640894393713606656,
    "created_at" : "2015-09-07 14:28:25 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 640898475371196416,
  "created_at" : "2015-09-07 14:44:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EAPsteve",
      "screen_name" : "EAPstephen",
      "indices" : [ 0, 11 ],
      "id_str" : "2717005711",
      "id" : 2717005711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "640864958037786624",
  "geo" : { },
  "id_str" : "640866293722259456",
  "in_reply_to_user_id" : 2717005711,
  "text" : "@EAPstephen not sure where they calculate the millions though?",
  "id" : 640866293722259456,
  "in_reply_to_status_id" : 640864958037786624,
  "created_at" : "2015-09-07 12:36:45 +0000",
  "in_reply_to_screen_name" : "EAPstephen",
  "in_reply_to_user_id_str" : "2717005711",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Thomson",
      "screen_name" : "cbthomson",
      "indices" : [ 3, 13 ],
      "id_str" : "246845785",
      "id" : 246845785
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 141 ],
      "url" : "http:\/\/t.co\/uoPM5az2UL",
      "expanded_url" : "http:\/\/gu.com\/p\/4c4ap?CMP=Share_iOSApp_Other",
      "display_url" : "gu.com\/p\/4c4ap?CMP=Sh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "640864452628365312",
  "text" : "RT @cbthomson: Imogen Heap: saviour of the music industry? &lt;- blockchains as the basis for a fairer music industry? http:\/\/t.co\/uoPM5az2UL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/uoPM5az2UL",
        "expanded_url" : "http:\/\/gu.com\/p\/4c4ap?CMP=Share_iOSApp_Other",
        "display_url" : "gu.com\/p\/4c4ap?CMP=Sh\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "640540350763925504",
    "text" : "Imogen Heap: saviour of the music industry? &lt;- blockchains as the basis for a fairer music industry? http:\/\/t.co\/uoPM5az2UL",
    "id" : 640540350763925504,
    "created_at" : "2015-09-06 15:01:34 +0000",
    "user" : {
      "name" : "Chris Thomson",
      "screen_name" : "cbthomson",
      "protected" : false,
      "id_str" : "246845785",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/522041892716834816\/-1uGL-3-_normal.jpeg",
      "id" : 246845785,
      "verified" : false
    }
  },
  "id" : 640864452628365312,
  "created_at" : "2015-09-07 12:29:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EAPsteve",
      "screen_name" : "EAPstephen",
      "indices" : [ 0, 11 ],
      "id_str" : "2717005711",
      "id" : 2717005711
    }, {
      "name" : "Scott Thornbury",
      "screen_name" : "thornburyscott",
      "indices" : [ 12, 27 ],
      "id_str" : "23090474",
      "id" : 23090474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "640863095733243904",
  "geo" : { },
  "id_str" : "640863621371817984",
  "in_reply_to_user_id" : 2717005711,
  "text" : "@EAPstephen @thornburyscott no idea but a diamond geezer by all accounts :)",
  "id" : 640863621371817984,
  "in_reply_to_status_id" : 640863095733243904,
  "created_at" : "2015-09-07 12:26:08 +0000",
  "in_reply_to_screen_name" : "EAPstephen",
  "in_reply_to_user_id_str" : "2717005711",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "indices" : [ 3, 13 ],
      "id_str" : "577931950",
      "id" : 577931950
    }, {
      "name" : "Universit\u00E9 Lille 3",
      "screen_name" : "Lille3",
      "indices" : [ 91, 98 ],
      "id_str" : "89969779",
      "id" : 89969779
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/RudyLoock\/status\/640837197990596608\/photo\/1",
      "indices" : [ 143, 144 ],
      "url" : "http:\/\/t.co\/h8q0lNHtLm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/COS2CQtWcAAjkeN.jpg",
      "id_str" : "640837196954628096",
      "id" : 640837196954628096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COS2CQtWcAAjkeN.jpg",
      "sizes" : [ {
        "h" : 71,
        "resize" : "fit",
        "w" : 282
      }, {
        "h" : 71,
        "resize" : "crop",
        "w" : 71
      }, {
        "h" : 71,
        "resize" : "fit",
        "w" : 282
      }, {
        "h" : 71,
        "resize" : "fit",
        "w" : 282
      }, {
        "h" : 71,
        "resize" : "fit",
        "w" : 282
      } ],
      "display_url" : "pic.twitter.com\/h8q0lNHtLm"
    } ],
    "hashtags" : [ {
      "text" : "Translation",
      "indices" : [ 35, 47 ]
    }, {
      "text" : "Quality",
      "indices" : [ 54, 62 ]
    }, {
      "text" : "corpus",
      "indices" : [ 67, 74 ]
    }, {
      "text" : "xl8",
      "indices" : [ 125, 129 ]
    }, {
      "text" : "t9n",
      "indices" : [ 130, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/xX6VRBDVT7",
      "expanded_url" : "http:\/\/traduction2016.sciencesconf.org\/",
      "display_url" : "traduction2016.sciencesconf.org"
    } ]
  },
  "geo" : { },
  "id_str" : "640839300066725888",
  "text" : "RT @RudyLoock: One-day conference \"#Translation &amp; #Quality\" on #corpus use 5 Feb. 2016 @lille3 : http:\/\/t.co\/xX6VRBDVT7  #xl8 #t9n http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Universit\u00E9 Lille 3",
        "screen_name" : "Lille3",
        "indices" : [ 76, 83 ],
        "id_str" : "89969779",
        "id" : 89969779
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/RudyLoock\/status\/640837197990596608\/photo\/1",
        "indices" : [ 120, 142 ],
        "url" : "http:\/\/t.co\/h8q0lNHtLm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/COS2CQtWcAAjkeN.jpg",
        "id_str" : "640837196954628096",
        "id" : 640837196954628096,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COS2CQtWcAAjkeN.jpg",
        "sizes" : [ {
          "h" : 71,
          "resize" : "fit",
          "w" : 282
        }, {
          "h" : 71,
          "resize" : "crop",
          "w" : 71
        }, {
          "h" : 71,
          "resize" : "fit",
          "w" : 282
        }, {
          "h" : 71,
          "resize" : "fit",
          "w" : 282
        }, {
          "h" : 71,
          "resize" : "fit",
          "w" : 282
        } ],
        "display_url" : "pic.twitter.com\/h8q0lNHtLm"
      } ],
      "hashtags" : [ {
        "text" : "Translation",
        "indices" : [ 20, 32 ]
      }, {
        "text" : "Quality",
        "indices" : [ 39, 47 ]
      }, {
        "text" : "corpus",
        "indices" : [ 52, 59 ]
      }, {
        "text" : "xl8",
        "indices" : [ 110, 114 ]
      }, {
        "text" : "t9n",
        "indices" : [ 115, 119 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/xX6VRBDVT7",
        "expanded_url" : "http:\/\/traduction2016.sciencesconf.org\/",
        "display_url" : "traduction2016.sciencesconf.org"
      } ]
    },
    "geo" : { },
    "id_str" : "640837197990596608",
    "text" : "One-day conference \"#Translation &amp; #Quality\" on #corpus use 5 Feb. 2016 @lille3 : http:\/\/t.co\/xX6VRBDVT7  #xl8 #t9n http:\/\/t.co\/h8q0lNHtLm",
    "id" : 640837197990596608,
    "created_at" : "2015-09-07 10:41:08 +0000",
    "user" : {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "protected" : false,
      "id_str" : "577931950",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2370874884\/qm10et5v1fyzwixh651s_normal.jpeg",
      "id" : 577931950,
      "verified" : false
    }
  },
  "id" : 640839300066725888,
  "created_at" : "2015-09-07 10:49:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/640838418906378240\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/E7NT0qMV7k",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/COS3JWCWoAALhTC.png",
      "id_str" : "640838418155610112",
      "id" : 640838418155610112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COS3JWCWoAALhTC.png",
      "sizes" : [ {
        "h" : 526,
        "resize" : "fit",
        "w" : 1438
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 124,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 219,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/E7NT0qMV7k"
    } ],
    "hashtags" : [ {
      "text" : "labourleadership",
      "indices" : [ 0, 17 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/6Iwy0ypf44",
      "expanded_url" : "http:\/\/lableader-speeches.englishup.me\/",
      "display_url" : "lableader-speeches.englishup.me"
    } ]
  },
  "geo" : { },
  "id_str" : "640838418906378240",
  "text" : "#labourleadership Burnham more about business Corbyn more about economy? have a play at http:\/\/t.co\/6Iwy0ypf44 http:\/\/t.co\/E7NT0qMV7k",
  "id" : 640838418906378240,
  "created_at" : "2015-09-07 10:45:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/OCRXXq5sOs",
      "expanded_url" : "http:\/\/fair.org\/home\/the-syrian-refugee-crisis-and-the-do-something-lie\/",
      "display_url" : "fair.org\/home\/the-syria\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "640812572359421952",
  "text" : "The Syrian Refugee Crisis and the \u2018Do Something\u2019 Lie http:\/\/t.co\/OCRXXq5sOs",
  "id" : 640812572359421952,
  "created_at" : "2015-09-07 09:03:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Free Mobile",
      "screen_name" : "freemobile",
      "indices" : [ 0, 11 ],
      "id_str" : "425725345",
      "id" : 425725345
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "640782866767609856",
  "in_reply_to_user_id" : 425725345,
  "text" : "@freemobile Ma ligne mobile a ete piratee. Appel du 3666 pour 20 euros. N'arrive pas a joindre services techniques (satures). Que faire ?",
  "id" : 640782866767609856,
  "created_at" : "2015-09-07 07:05:15 +0000",
  "in_reply_to_screen_name" : "freemobile",
  "in_reply_to_user_id_str" : "425725345",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Honnibal",
      "screen_name" : "honnibal",
      "indices" : [ 0, 9 ],
      "id_str" : "14699038",
      "id" : 14699038
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "640308495330492416",
  "geo" : { },
  "id_str" : "640638671448862720",
  "in_reply_to_user_id" : 14699038,
  "text" : "@honnibal lol ok will wait mooo\/baaaa",
  "id" : 640638671448862720,
  "in_reply_to_status_id" : 640308495330492416,
  "created_at" : "2015-09-06 21:32:16 +0000",
  "in_reply_to_screen_name" : "honnibal",
  "in_reply_to_user_id_str" : "14699038",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Theobald",
      "screen_name" : "JamesTheo",
      "indices" : [ 3, 13 ],
      "id_str" : "87903271",
      "id" : 87903271
    }, {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 79, 87 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/675iXAkZMm",
      "expanded_url" : "https:\/\/youtu.be\/QajyNRnyPMs",
      "display_url" : "youtu.be\/QajyNRnyPMs"
    } ]
  },
  "geo" : { },
  "id_str" : "640631628730105856",
  "text" : "RT @JamesTheo: This is very clever.\n\n\"HELL'S CLUB. https:\/\/t.co\/675iXAkZMm via @YouTube\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ 64, 72 ],
        "id_str" : "10228272",
        "id" : 10228272
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 36, 59 ],
        "url" : "https:\/\/t.co\/675iXAkZMm",
        "expanded_url" : "https:\/\/youtu.be\/QajyNRnyPMs",
        "display_url" : "youtu.be\/QajyNRnyPMs"
      } ]
    },
    "geo" : { },
    "id_str" : "640576888478539776",
    "text" : "This is very clever.\n\n\"HELL'S CLUB. https:\/\/t.co\/675iXAkZMm via @YouTube\"",
    "id" : 640576888478539776,
    "created_at" : "2015-09-06 17:26:46 +0000",
    "user" : {
      "name" : "James Theobald",
      "screen_name" : "JamesTheo",
      "protected" : false,
      "id_str" : "87903271",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724679297391276033\/Fy8vphs6_normal.jpg",
      "id" : 87903271,
      "verified" : false
    }
  },
  "id" : 640631628730105856,
  "created_at" : "2015-09-06 21:04:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HaveUread",
      "screen_name" : "thisbyanychance",
      "indices" : [ 1, 17 ],
      "id_str" : "3416415189",
      "id" : 3416415189
    }, {
      "name" : "Zrinka Maroja",
      "screen_name" : "zrinkav",
      "indices" : [ 23, 31 ],
      "id_str" : "413860997",
      "id" : 413860997
    }, {
      "name" : "Richard Branson",
      "screen_name" : "richardbranson",
      "indices" : [ 41, 56 ],
      "id_str" : "8161232",
      "id" : 8161232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "640495248272138241",
  "geo" : { },
  "id_str" : "640625730011967488",
  "in_reply_to_user_id" : 8161232,
  "text" : ".@thisbyanychance tell @zrinkav to tell  @richardbranson about Dale cone",
  "id" : 640625730011967488,
  "in_reply_to_status_id" : 640495248272138241,
  "created_at" : "2015-09-06 20:40:50 +0000",
  "in_reply_to_screen_name" : "richardbranson",
  "in_reply_to_user_id_str" : "8161232",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Honnibal",
      "screen_name" : "honnibal",
      "indices" : [ 0, 9 ],
      "id_str" : "14699038",
      "id" : 14699038
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "640295193493815296",
  "in_reply_to_user_id" : 14699038,
  "text" : "@honnibal hi you got an rss feed for your spacy blog?",
  "id" : 640295193493815296,
  "created_at" : "2015-09-05 22:47:24 +0000",
  "in_reply_to_screen_name" : "honnibal",
  "in_reply_to_user_id_str" : "14699038",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Moravec",
      "screen_name" : "ProfessMoravec",
      "indices" : [ 0, 15 ],
      "id_str" : "369529173",
      "id" : 369529173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "639917516710674432",
  "geo" : { },
  "id_str" : "639922749645922304",
  "in_reply_to_user_id" : 369529173,
  "text" : "@ProfessMoravec ha i hear ya! well have a good w\/e in any case :)",
  "id" : 639922749645922304,
  "in_reply_to_status_id" : 639917516710674432,
  "created_at" : "2015-09-04 22:07:27 +0000",
  "in_reply_to_screen_name" : "ProfessMoravec",
  "in_reply_to_user_id_str" : "369529173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Moravec",
      "screen_name" : "ProfessMoravec",
      "indices" : [ 0, 15 ],
      "id_str" : "369529173",
      "id" : 369529173
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "labourleadership",
      "indices" : [ 40, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "639908686719225856",
  "in_reply_to_user_id" : 369529173,
  "text" : "@ProfessMoravec hi Michelle thx, is the #labourleadership being followed much over the pond?",
  "id" : 639908686719225856,
  "created_at" : "2015-09-04 21:11:34 +0000",
  "in_reply_to_screen_name" : "ProfessMoravec",
  "in_reply_to_user_id_str" : "369529173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "labourleadership",
      "indices" : [ 19, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/6Iwy0ypf44",
      "expanded_url" : "http:\/\/lableader-speeches.englishup.me\/",
      "display_url" : "lableader-speeches.englishup.me"
    } ]
  },
  "geo" : { },
  "id_str" : "639898758512275456",
  "text" : "venncloud for some #labourleadership speeches http:\/\/t.co\/6Iwy0ypf44 (looking for more speeches)",
  "id" : 639898758512275456,
  "created_at" : "2015-09-04 20:32:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AskPaulEnglish",
      "screen_name" : "paulbaconRivera",
      "indices" : [ 0, 16 ],
      "id_str" : "70418088",
      "id" : 70418088
    }, {
      "name" : "Mark Venning",
      "screen_name" : "linkstoenglish",
      "indices" : [ 17, 32 ],
      "id_str" : "3083991707",
      "id" : 3083991707
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "639780388634669057",
  "geo" : { },
  "id_str" : "639785672950292480",
  "in_reply_to_user_id" : 70418088,
  "text" : "@paulbaconRivera @linkstoenglish maybe student was thinking of US shows like pimp my ride?",
  "id" : 639785672950292480,
  "in_reply_to_status_id" : 639780388634669057,
  "created_at" : "2015-09-04 13:02:45 +0000",
  "in_reply_to_screen_name" : "paulbaconRivera",
  "in_reply_to_user_id_str" : "70418088",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Douglas Carnall",
      "screen_name" : "JuliuzBeezer",
      "indices" : [ 0, 13 ],
      "id_str" : "25936824",
      "id" : 25936824
    }, {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 14, 24 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "639752818669301760",
  "geo" : { },
  "id_str" : "639781537085571074",
  "in_reply_to_user_id" : 25936824,
  "text" : "@JuliuzBeezer @medialens some cutting remarks by Greenwald ouch :)",
  "id" : 639781537085571074,
  "in_reply_to_status_id" : 639752818669301760,
  "created_at" : "2015-09-04 12:46:19 +0000",
  "in_reply_to_screen_name" : "JuliuzBeezer",
  "in_reply_to_user_id_str" : "25936824",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Douglas Carnall",
      "screen_name" : "JuliuzBeezer",
      "indices" : [ 3, 16 ],
      "id_str" : "25936824",
      "id" : 25936824
    }, {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 89, 99 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/SQwpJj4zYm",
      "expanded_url" : "http:\/\/www.medialens.org\/index.php\/alerts\/alert-archive\/2015\/800-corbyn-and-the-end-of-time-the-crisis-of-democracy.html",
      "display_url" : "medialens.org\/index.php\/aler\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "639781386627514368",
  "text" : "RT @JuliuzBeezer: Even 10yrs ago, it wasn't easy to disseminate critique by the likes of @medialens. Well it's easy enough now [posts] http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Media Lens",
        "screen_name" : "medialens",
        "indices" : [ 71, 81 ],
        "id_str" : "6531902",
        "id" : 6531902
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/SQwpJj4zYm",
        "expanded_url" : "http:\/\/www.medialens.org\/index.php\/alerts\/alert-archive\/2015\/800-corbyn-and-the-end-of-time-the-crisis-of-democracy.html",
        "display_url" : "medialens.org\/index.php\/aler\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "639752818669301760",
    "text" : "Even 10yrs ago, it wasn't easy to disseminate critique by the likes of @medialens. Well it's easy enough now [posts] http:\/\/t.co\/SQwpJj4zYm",
    "id" : 639752818669301760,
    "created_at" : "2015-09-04 10:52:12 +0000",
    "user" : {
      "name" : "Douglas Carnall",
      "screen_name" : "JuliuzBeezer",
      "protected" : false,
      "id_str" : "25936824",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/114211651\/robert_burns247x165_normal.jpg",
      "id" : 25936824,
      "verified" : false
    }
  },
  "id" : 639781386627514368,
  "created_at" : "2015-09-04 12:45:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Emersberger",
      "screen_name" : "rosendo_joe",
      "indices" : [ 3, 15 ],
      "id_str" : "3351345863",
      "id" : 3351345863
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/UVC0ZhTxXr",
      "expanded_url" : "http:\/\/members5.boardhost.com\/medialens\/msg\/1441309262.html",
      "display_url" : "members5.boardhost.com\/medialens\/msg\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "639699741895475200",
  "text" : "RT @rosendo_joe: Within the inch wide UK newspaper spectrum: Bombing is the solution to refugee crisis\n(Peter of Interventionswatch)\nhttp:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/UVC0ZhTxXr",
        "expanded_url" : "http:\/\/members5.boardhost.com\/medialens\/msg\/1441309262.html",
        "display_url" : "members5.boardhost.com\/medialens\/msg\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "639672839558311937",
    "text" : "Within the inch wide UK newspaper spectrum: Bombing is the solution to refugee crisis\n(Peter of Interventionswatch)\nhttp:\/\/t.co\/UVC0ZhTxXr",
    "id" : 639672839558311937,
    "created_at" : "2015-09-04 05:34:24 +0000",
    "user" : {
      "name" : "Joe Emersberger",
      "screen_name" : "rosendo_joe",
      "protected" : false,
      "id_str" : "3351345863",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/621112707522142209\/OGmLR1xt_normal.jpg",
      "id" : 3351345863,
      "verified" : false
    }
  },
  "id" : 639699741895475200,
  "created_at" : "2015-09-04 07:21:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EFL Magazine",
      "screen_name" : "eflmagazine",
      "indices" : [ 3, 15 ],
      "id_str" : "2879372766",
      "id" : 2879372766
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/eflmagazine\/status\/639689811993821184\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/gKNaYQXP8W",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/COCifnDVAAA0-rR.jpg",
      "id_str" : "639689811029196800",
      "id" : 639689811029196800,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COCifnDVAAA0-rR.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/gKNaYQXP8W"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/H3doBpv6PC",
      "expanded_url" : "http:\/\/eflmagazine.com\/will-five-ps\/",
      "display_url" : "eflmagazine.com\/will-five-ps\/"
    } ]
  },
  "geo" : { },
  "id_str" : "639692979851145216",
  "text" : "RT @eflmagazine: http:\/\/t.co\/H3doBpv6PC\nJeremy Day writing on future forms for EFL Magazine @jeremyday360 http:\/\/t.co\/gKNaYQXP8W",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/eflmagazine\/status\/639689811993821184\/photo\/1",
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/gKNaYQXP8W",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/COCifnDVAAA0-rR.jpg",
        "id_str" : "639689811029196800",
        "id" : 639689811029196800,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COCifnDVAAA0-rR.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/gKNaYQXP8W"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/H3doBpv6PC",
        "expanded_url" : "http:\/\/eflmagazine.com\/will-five-ps\/",
        "display_url" : "eflmagazine.com\/will-five-ps\/"
      } ]
    },
    "geo" : { },
    "id_str" : "639689811993821184",
    "text" : "http:\/\/t.co\/H3doBpv6PC\nJeremy Day writing on future forms for EFL Magazine @jeremyday360 http:\/\/t.co\/gKNaYQXP8W",
    "id" : 639689811993821184,
    "created_at" : "2015-09-04 06:41:50 +0000",
    "user" : {
      "name" : "EFL Magazine",
      "screen_name" : "eflmagazine",
      "protected" : false,
      "id_str" : "2879372766",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/566909861871366144\/YQt7EAWR_normal.jpeg",
      "id" : 2879372766,
      "verified" : false
    }
  },
  "id" : 639692979851145216,
  "created_at" : "2015-09-04 06:54:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "wrestlingneoliberals",
      "screen_name" : "neolib_takedown",
      "indices" : [ 3, 19 ],
      "id_str" : "3437858853",
      "id" : 3437858853
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/neolib_takedown\/status\/638844549792665600\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/CqLCX7Yuoe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CN2hu4OWgAAF3Px.png",
      "id_str" : "638844548895113216",
      "id" : 638844548895113216,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CN2hu4OWgAAF3Px.png",
      "sizes" : [ {
        "h" : 485,
        "resize" : "fit",
        "w" : 927
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 314,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 178,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 485,
        "resize" : "fit",
        "w" : 927
      } ],
      "display_url" : "pic.twitter.com\/CqLCX7Yuoe"
    } ],
    "hashtags" : [ {
      "text" : "Friedman",
      "indices" : [ 28, 37 ]
    }, {
      "text" : "ukpolitics",
      "indices" : [ 76, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/D37vTdmWW9",
      "expanded_url" : "http:\/\/wrestlingwithneoliberalism.com",
      "display_url" : "wrestlingwithneoliberalism.com"
    } ]
  },
  "geo" : { },
  "id_str" : "639546366486794240",
  "text" : "RT @neolib_takedown: Milton #Friedman speaks\u2014and he's dreaming the hardest. #ukpolitics http:\/\/t.co\/D37vTdmWW9 http:\/\/t.co\/CqLCX7Yuoe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/neolib_takedown\/status\/638844549792665600\/photo\/1",
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/CqLCX7Yuoe",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CN2hu4OWgAAF3Px.png",
        "id_str" : "638844548895113216",
        "id" : 638844548895113216,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CN2hu4OWgAAF3Px.png",
        "sizes" : [ {
          "h" : 485,
          "resize" : "fit",
          "w" : 927
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 314,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 178,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 485,
          "resize" : "fit",
          "w" : 927
        } ],
        "display_url" : "pic.twitter.com\/CqLCX7Yuoe"
      } ],
      "hashtags" : [ {
        "text" : "Friedman",
        "indices" : [ 7, 16 ]
      }, {
        "text" : "ukpolitics",
        "indices" : [ 55, 66 ]
      } ],
      "urls" : [ {
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/D37vTdmWW9",
        "expanded_url" : "http:\/\/wrestlingwithneoliberalism.com",
        "display_url" : "wrestlingwithneoliberalism.com"
      } ]
    },
    "geo" : { },
    "id_str" : "638844549792665600",
    "text" : "Milton #Friedman speaks\u2014and he's dreaming the hardest. #ukpolitics http:\/\/t.co\/D37vTdmWW9 http:\/\/t.co\/CqLCX7Yuoe",
    "id" : 638844549792665600,
    "created_at" : "2015-09-01 22:43:04 +0000",
    "user" : {
      "name" : "wrestlingneoliberals",
      "screen_name" : "neolib_takedown",
      "protected" : false,
      "id_str" : "3437858853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/635797071396798464\/rD8NlTWp_normal.png",
      "id" : 3437858853,
      "verified" : false
    }
  },
  "id" : 639546366486794240,
  "created_at" : "2015-09-03 21:11:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Caulfield",
      "screen_name" : "holden",
      "indices" : [ 3, 10 ],
      "id_str" : "1912681",
      "id" : 1912681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/xPTJMntwYs",
      "expanded_url" : "http:\/\/hapgood.us\/2015\/09\/03\/this-is-my-point-about-the-stream\/",
      "display_url" : "hapgood.us\/2015\/09\/03\/thi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "639468284065239040",
  "text" : "RT @holden: This Is My Point About the Stream http:\/\/t.co\/xPTJMntwYs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 34, 56 ],
        "url" : "http:\/\/t.co\/xPTJMntwYs",
        "expanded_url" : "http:\/\/hapgood.us\/2015\/09\/03\/this-is-my-point-about-the-stream\/",
        "display_url" : "hapgood.us\/2015\/09\/03\/thi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "639467369560039424",
    "text" : "This Is My Point About the Stream http:\/\/t.co\/xPTJMntwYs",
    "id" : 639467369560039424,
    "created_at" : "2015-09-03 15:57:56 +0000",
    "user" : {
      "name" : "Mike Caulfield",
      "screen_name" : "holden",
      "protected" : false,
      "id_str" : "1912681",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/752538301538545665\/mXNoIc4W_normal.jpg",
      "id" : 1912681,
      "verified" : false
    }
  },
  "id" : 639468284065239040,
  "created_at" : "2015-09-03 16:01:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Achilleas Kostoulas",
      "screen_name" : "AchilleasK",
      "indices" : [ 100, 111 ],
      "id_str" : "134191406",
      "id" : 134191406
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/AZXF6P5Duq",
      "expanded_url" : "http:\/\/wp.me\/p2aFDK-199",
      "display_url" : "wp.me\/p2aFDK-199"
    } ]
  },
  "geo" : { },
  "id_str" : "639467944280461312",
  "text" : "\"I honestly can't understand what's so bad with taking a language test!\" http:\/\/t.co\/AZXF6P5Duq via @AchilleasK",
  "id" : 639467944280461312,
  "created_at" : "2015-09-03 16:00:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Chrimes",
      "screen_name" : "ELTwriter",
      "indices" : [ 0, 10 ],
      "id_str" : "2464809235",
      "id" : 2464809235
    }, {
      "name" : "EL Gazette",
      "screen_name" : "ELGazette",
      "indices" : [ 11, 21 ],
      "id_str" : "614186998",
      "id" : 614186998
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "639447216814432256",
  "geo" : { },
  "id_str" : "639448354020302848",
  "in_reply_to_user_id" : 2464809235,
  "text" : "@ELTwriter @ELGazette plus it's more than one teacher :\/ what message do they want to send with such a stunt? instead titled free class?",
  "id" : 639448354020302848,
  "in_reply_to_status_id" : 639447216814432256,
  "created_at" : "2015-09-03 14:42:22 +0000",
  "in_reply_to_screen_name" : "ELTwriter",
  "in_reply_to_user_id_str" : "2464809235",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hancock McDonald ELT",
      "screen_name" : "HancockMcDonald",
      "indices" : [ 3, 19 ],
      "id_str" : "552929354",
      "id" : 552929354
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/HancockMcDonald\/status\/639085196361531392\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/0wduHh7tph",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CN58mWXWUAA2ziQ.jpg",
      "id_str" : "639085195413573632",
      "id" : 639085195413573632,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CN58mWXWUAA2ziQ.jpg",
      "sizes" : [ {
        "h" : 471,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 3323,
        "resize" : "fit",
        "w" : 2400
      }, {
        "h" : 831,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1418,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/0wduHh7tph"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/e3JIkUnQ17",
      "expanded_url" : "http:\/\/hancockmcdonald.com",
      "display_url" : "hancockmcdonald.com"
    } ]
  },
  "geo" : { },
  "id_str" : "639087922831097856",
  "text" : "RT @HancockMcDonald: Mark: Here's an infographic to explain the ultimate version of my new phonemic chart - see http:\/\/t.co\/e3JIkUnQ17 http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/HancockMcDonald\/status\/639085196361531392\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/0wduHh7tph",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CN58mWXWUAA2ziQ.jpg",
        "id_str" : "639085195413573632",
        "id" : 639085195413573632,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CN58mWXWUAA2ziQ.jpg",
        "sizes" : [ {
          "h" : 471,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 3323,
          "resize" : "fit",
          "w" : 2400
        }, {
          "h" : 831,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1418,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/0wduHh7tph"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/e3JIkUnQ17",
        "expanded_url" : "http:\/\/hancockmcdonald.com",
        "display_url" : "hancockmcdonald.com"
      } ]
    },
    "geo" : { },
    "id_str" : "639085196361531392",
    "text" : "Mark: Here's an infographic to explain the ultimate version of my new phonemic chart - see http:\/\/t.co\/e3JIkUnQ17 http:\/\/t.co\/0wduHh7tph",
    "id" : 639085196361531392,
    "created_at" : "2015-09-02 14:39:19 +0000",
    "user" : {
      "name" : "Hancock McDonald ELT",
      "screen_name" : "HancockMcDonald",
      "protected" : false,
      "id_str" : "552929354",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2158919436\/HM_portrait_normal.jpg",
      "id" : 552929354,
      "verified" : false
    }
  },
  "id" : 639087922831097856,
  "created_at" : "2015-09-02 14:50:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Akira Murakami",
      "screen_name" : "mrkm_a",
      "indices" : [ 0, 7 ],
      "id_str" : "116922669",
      "id" : 116922669
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sinclair15",
      "indices" : [ 81, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/p3oO380YgX",
      "expanded_url" : "http:\/\/writeaway.nlpweb.org\/",
      "display_url" : "writeaway.nlpweb.org"
    } ]
  },
  "in_reply_to_status_id_str" : "639003633653280768",
  "geo" : { },
  "id_str" : "639008171315625984",
  "in_reply_to_user_id" : 116922669,
  "text" : "@mrkm_a http:\/\/t.co\/p3oO380YgX is a nice implementation of grammar pattern ideas #sinclair15",
  "id" : 639008171315625984,
  "in_reply_to_status_id" : 639003633653280768,
  "created_at" : "2015-09-02 09:33:14 +0000",
  "in_reply_to_screen_name" : "mrkm_a",
  "in_reply_to_user_id_str" : "116922669",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robbie Love",
      "screen_name" : "lovermob",
      "indices" : [ 3, 12 ],
      "id_str" : "19469715",
      "id" : 19469715
    }, {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "indices" : [ 91, 107 ],
      "id_str" : "1326508478",
      "id" : 1326508478
    }, {
      "name" : "Cambridge Uni Press",
      "screen_name" : "CambridgeUP",
      "indices" : [ 108, 120 ],
      "id_str" : "319110295",
      "id" : 319110295
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BNC2014",
      "indices" : [ 57, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/ca5J3hoUj8",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?t=15&v=q1K2RhtOjAE",
      "display_url" : "youtube.com\/watch?t=15&v=q\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "638822024186499072",
  "text" : "RT @lovermob: 5 simple steps to contribute to the Spoken #BNC2014! https:\/\/t.co\/ca5J3hoUj8 @CorpusSocialSci @CambridgeUP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CASS",
        "screen_name" : "CorpusSocialSci",
        "indices" : [ 77, 93 ],
        "id_str" : "1326508478",
        "id" : 1326508478
      }, {
        "name" : "Cambridge Uni Press",
        "screen_name" : "CambridgeUP",
        "indices" : [ 94, 106 ],
        "id_str" : "319110295",
        "id" : 319110295
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BNC2014",
        "indices" : [ 43, 51 ]
      } ],
      "urls" : [ {
        "indices" : [ 53, 76 ],
        "url" : "https:\/\/t.co\/ca5J3hoUj8",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?t=15&v=q1K2RhtOjAE",
        "display_url" : "youtube.com\/watch?t=15&v=q\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "638690757545709568",
    "text" : "5 simple steps to contribute to the Spoken #BNC2014! https:\/\/t.co\/ca5J3hoUj8 @CorpusSocialSci @CambridgeUP",
    "id" : 638690757545709568,
    "created_at" : "2015-09-01 12:31:57 +0000",
    "user" : {
      "name" : "Robbie Love",
      "screen_name" : "lovermob",
      "protected" : false,
      "id_str" : "19469715",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733371018056716288\/4lRj6knU_normal.jpg",
      "id" : 19469715,
      "verified" : false
    }
  },
  "id" : 638822024186499072,
  "created_at" : "2015-09-01 21:13:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2133\u0105h\u0105 B\u0105\u2113i \u0645\u0647\u0627 \u0628\u0627\u0644\u064A",
      "screen_name" : "Bali_Maha",
      "indices" : [ 0, 10 ],
      "id_str" : "1535273520",
      "id" : 1535273520
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "638803430283341825",
  "geo" : { },
  "id_str" : "638803800300605441",
  "in_reply_to_user_id" : 1535273520,
  "text" : "@Bali_Maha oh dear :(",
  "id" : 638803800300605441,
  "in_reply_to_status_id" : 638803430283341825,
  "created_at" : "2015-09-01 20:01:09 +0000",
  "in_reply_to_screen_name" : "Bali_Maha",
  "in_reply_to_user_id_str" : "1535273520",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    }, {
      "name" : "The Guardian",
      "screen_name" : "guardian",
      "indices" : [ 78, 87 ],
      "id_str" : "87818409",
      "id" : 87818409
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Corbyn",
      "indices" : [ 107, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 124, 140 ],
      "url" : "http:\/\/t.co\/sn7NijE873",
      "expanded_url" : "http:\/\/johnhilley.blogspot.co.uk\/2015\/09\/guardian-and-jones-now-working-hard-to.html",
      "display_url" : "johnhilley.blogspot.co.uk\/2015\/09\/guardi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "638802928338358276",
  "text" : "RT @johnwhilley: The real storm is coming, as establishment, aided by liberal @guardian, get ready to tame #Corbyn movement http:\/\/t.co\/sn7\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Guardian",
        "screen_name" : "guardian",
        "indices" : [ 61, 70 ],
        "id_str" : "87818409",
        "id" : 87818409
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Corbyn",
        "indices" : [ 90, 97 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/sn7NijE873",
        "expanded_url" : "http:\/\/johnhilley.blogspot.co.uk\/2015\/09\/guardian-and-jones-now-working-hard-to.html",
        "display_url" : "johnhilley.blogspot.co.uk\/2015\/09\/guardi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "638759344427900928",
    "text" : "The real storm is coming, as establishment, aided by liberal @guardian, get ready to tame #Corbyn movement http:\/\/t.co\/sn7NijE873",
    "id" : 638759344427900928,
    "created_at" : "2015-09-01 17:04:29 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 638802928338358276,
  "created_at" : "2015-09-01 19:57:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "indices" : [ 3, 18 ],
      "id_str" : "27716419",
      "id" : 27716419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/Z9iWu82BKa",
      "expanded_url" : "http:\/\/www.craigmurray.org.uk\/archives\/2015\/09\/breaking-the-depleted-uranium-ceiling\/",
      "display_url" : "craigmurray.org.uk\/archives\/2015\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "638801591437524993",
  "text" : "RT @CraigMurrayOrg: New post: Breaking the Depleted Uranium Ceiling http:\/\/t.co\/Z9iWu82BKa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.craigmurray.org.uk\" rel=\"nofollow\"\u003ECraig Murray posting plugin\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 70 ],
        "url" : "http:\/\/t.co\/Z9iWu82BKa",
        "expanded_url" : "http:\/\/www.craigmurray.org.uk\/archives\/2015\/09\/breaking-the-depleted-uranium-ceiling\/",
        "display_url" : "craigmurray.org.uk\/archives\/2015\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "638634510805004288",
    "text" : "New post: Breaking the Depleted Uranium Ceiling http:\/\/t.co\/Z9iWu82BKa",
    "id" : 638634510805004288,
    "created_at" : "2015-09-01 08:48:27 +0000",
    "user" : {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "protected" : false,
      "id_str" : "27716419",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1388436826\/cm_normal.jpg",
      "id" : 27716419,
      "verified" : false
    }
  },
  "id" : 638801591437524993,
  "created_at" : "2015-09-01 19:52:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "indices" : [ 3, 18 ],
      "id_str" : "152194866",
      "id" : 152194866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/2ifyXykmaJ",
      "expanded_url" : "http:\/\/tm.durusau.net\/?p=64306",
      "display_url" : "tm.durusau.net\/?p=64306"
    } ]
  },
  "geo" : { },
  "id_str" : "638796087197872128",
  "text" : "RT @patrickDurusau: Self-Censorship and Terrorism (Hosting Taliban material) http:\/\/t.co\/2ifyXykmaJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/2ifyXykmaJ",
        "expanded_url" : "http:\/\/tm.durusau.net\/?p=64306",
        "display_url" : "tm.durusau.net\/?p=64306"
      } ]
    },
    "geo" : { },
    "id_str" : "638470254465798144",
    "text" : "Self-Censorship and Terrorism (Hosting Taliban material) http:\/\/t.co\/2ifyXykmaJ",
    "id" : 638470254465798144,
    "created_at" : "2015-08-31 21:55:45 +0000",
    "user" : {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "protected" : false,
      "id_str" : "152194866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/961579480\/patrick_normal.jpeg",
      "id" : 152194866,
      "verified" : false
    }
  },
  "id" : 638796087197872128,
  "created_at" : "2015-09-01 19:30:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Freeman",
      "screen_name" : "SnoozeInBrief",
      "indices" : [ 65, 79 ],
      "id_str" : "82947233",
      "id" : 82947233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/eGqVzS14Vx",
      "expanded_url" : "http:\/\/wp.me\/p1l5Kr-8y",
      "display_url" : "wp.me\/p1l5Kr-8y"
    } ]
  },
  "geo" : { },
  "id_str" : "638793982718398464",
  "text" : "Common words you\u2019re probably misusing http:\/\/t.co\/eGqVzS14Vx via @SnoozeInBrief",
  "id" : 638793982718398464,
  "created_at" : "2015-09-01 19:22:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Chrimes",
      "screen_name" : "ELTwriter",
      "indices" : [ 0, 10 ],
      "id_str" : "2464809235",
      "id" : 2464809235
    }, {
      "name" : "Genevieve White",
      "screen_name" : "ShetlandESOL",
      "indices" : [ 11, 24 ],
      "id_str" : "624508480",
      "id" : 624508480
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "638638639866626048",
  "geo" : { },
  "id_str" : "638641009744838656",
  "in_reply_to_user_id" : 2464809235,
  "text" : "@ELTwriter @ShetlandESOL great let me know how you get on :)",
  "id" : 638641009744838656,
  "in_reply_to_status_id" : 638638639866626048,
  "created_at" : "2015-09-01 09:14:16 +0000",
  "in_reply_to_screen_name" : "ELTwriter",
  "in_reply_to_user_id_str" : "2464809235",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Genevieve White",
      "screen_name" : "ShetlandESOL",
      "indices" : [ 0, 13 ],
      "id_str" : "624508480",
      "id" : 624508480
    }, {
      "name" : "John Chrimes",
      "screen_name" : "ELTwriter",
      "indices" : [ 14, 24 ],
      "id_str" : "2464809235",
      "id" : 2464809235
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/fsFZlCDoVC",
      "expanded_url" : "https:\/\/eflnotes.wordpress.com\/tag\/google-custom-search-engine\/",
      "display_url" : "eflnotes.wordpress.com\/tag\/google-cus\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "638631625719435264",
  "geo" : { },
  "id_str" : "638636959460687872",
  "in_reply_to_user_id" : 624508480,
  "text" : "@ShetlandESOL @ELTwriter hi you may find this of use https:\/\/t.co\/fsFZlCDoVC",
  "id" : 638636959460687872,
  "in_reply_to_status_id" : 638631625719435264,
  "created_at" : "2015-09-01 08:58:11 +0000",
  "in_reply_to_screen_name" : "ShetlandESOL",
  "in_reply_to_user_id_str" : "624508480",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KBarrs",
      "screen_name" : "corpusloanword",
      "indices" : [ 0, 15 ],
      "id_str" : "95419070",
      "id" : 95419070
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "638601249605070848",
  "geo" : { },
  "id_str" : "638617871694864384",
  "in_reply_to_user_id" : 95419070,
  "text" : "@corpusloanword hey no worries my pleasure :)",
  "id" : 638617871694864384,
  "in_reply_to_status_id" : 638601249605070848,
  "created_at" : "2015-09-01 07:42:20 +0000",
  "in_reply_to_screen_name" : "corpusloanword",
  "in_reply_to_user_id_str" : "95419070",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TESOL at ACE",
      "screen_name" : "TESOLatACE",
      "indices" : [ 0, 11 ],
      "id_str" : "592998930",
      "id" : 592998930
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "638519724452773889",
  "geo" : { },
  "id_str" : "638523260301365248",
  "in_reply_to_user_id" : 592998930,
  "text" : "@TESOLatACE hemispheres of the brain, multiple intelligence, suggestopedia, neuro-linguistic programming, learning styles wow BINGO :)",
  "id" : 638523260301365248,
  "in_reply_to_status_id" : 638519724452773889,
  "created_at" : "2015-09-01 01:26:23 +0000",
  "in_reply_to_screen_name" : "TESOLatACE",
  "in_reply_to_user_id_str" : "592998930",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
} ]