Grailbird.data.tweets_2013_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "indices" : [ 0, 13 ],
      "id_str" : "1685397408",
      "id" : 1685397408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/b9Kp9VF0",
      "expanded_url" : "http:\/\/2.bp.blogspot.com\/-hhOfebLaWtM\/T9hvHI0D14I\/AAAAAAAAAFo\/vCbn2L1zQKE\/s1600\/Sheldon-con-manos-de-Hulk.jpg",
      "display_url" : "2.bp.blogspot.com\/-hhOfebLaWtM\/T\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "297059575708938240",
  "text" : "@harrisonmike and with hulk hands u would never be able to unpop them :) http:\/\/t.co\/b9Kp9VF0",
  "id" : 297059575708938240,
  "created_at" : "2013-01-31 19:11:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Seymour",
      "screen_name" : "leninology",
      "indices" : [ 3, 14 ],
      "id_str" : "15557246",
      "id" : 15557246
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/X1AiY4UJ",
      "expanded_url" : "http:\/\/guardian.co.uk",
      "display_url" : "guardian.co.uk"
    }, {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/UN28NCVD",
      "expanded_url" : "http:\/\/s.shr.lc\/TgFsC3",
      "display_url" : "s.shr.lc\/TgFsC3"
    } ]
  },
  "geo" : { },
  "id_str" : "297058201864658944",
  "text" : "RT @leninology: Rebellious HMV tweets are in a fine tradition | Richard Seymour | Comment is free | http:\/\/t.co\/X1AiY4UJ - http:\/\/t.co\/U ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.shareaholic.com\" rel=\"nofollow\"\u003Eshareaholic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 104 ],
        "url" : "http:\/\/t.co\/X1AiY4UJ",
        "expanded_url" : "http:\/\/guardian.co.uk",
        "display_url" : "guardian.co.uk"
      }, {
        "indices" : [ 107, 127 ],
        "url" : "http:\/\/t.co\/UN28NCVD",
        "expanded_url" : "http:\/\/s.shr.lc\/TgFsC3",
        "display_url" : "s.shr.lc\/TgFsC3"
      } ]
    },
    "geo" : { },
    "id_str" : "297044812216037376",
    "text" : "Rebellious HMV tweets are in a fine tradition | Richard Seymour | Comment is free | http:\/\/t.co\/X1AiY4UJ - http:\/\/t.co\/UN28NCVD",
    "id" : 297044812216037376,
    "created_at" : "2013-01-31 18:12:56 +0000",
    "user" : {
      "name" : "Richard Seymour",
      "screen_name" : "leninology",
      "protected" : false,
      "id_str" : "15557246",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762344914583781377\/UDn8tMrp_normal.jpg",
      "id" : 15557246,
      "verified" : false
    }
  },
  "id" : 297058201864658944,
  "created_at" : "2013-01-31 19:06:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Huw Jarvis",
      "screen_name" : "TESOLacademic",
      "indices" : [ 28, 42 ],
      "id_str" : "43409552",
      "id" : 43409552
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 89, 93 ]
    }, {
      "text" : "tefl",
      "indices" : [ 95, 100 ]
    }, {
      "text" : "esl",
      "indices" : [ 102, 106 ]
    }, {
      "text" : "efl",
      "indices" : [ 108, 112 ]
    }, {
      "text" : "tesol",
      "indices" : [ 114, 120 ]
    }, {
      "text" : "esol",
      "indices" : [ 121, 126 ]
    }, {
      "text" : "ELTchat",
      "indices" : [ 128, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/0gTRLidv",
      "expanded_url" : "http:\/\/bit.ly\/WUAhWv",
      "display_url" : "bit.ly\/WUAhWv"
    } ]
  },
  "geo" : { },
  "id_str" : "297050800046362628",
  "text" : "backs up classrm exp&gt; MT @TESOLacademic http:\/\/t.co\/0gTRLidv  research into pair work #elt  #tefl  #esl  #efl  #tesol #esol  #ELTchat",
  "id" : 297050800046362628,
  "created_at" : "2013-01-31 18:36:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 0, 13 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297047018239569921",
  "in_reply_to_user_id" : 88655243,
  "text" : "@rosemerebard thanks for like on glittens post rose, how goes it?",
  "id" : 297047018239569921,
  "created_at" : "2013-01-31 18:21:42 +0000",
  "in_reply_to_screen_name" : "rosemerebard",
  "in_reply_to_user_id_str" : "88655243",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Gurr",
      "screen_name" : "tonygurr",
      "indices" : [ 6, 15 ],
      "id_str" : "257930941",
      "id" : 257930941
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297046358911754241",
  "text" : "yikes @tonygurr blog post styles are breeding and reproducing! :\/",
  "id" : 297046358911754241,
  "created_at" : "2013-01-31 18:19:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stevemuir",
      "screen_name" : "steve_muir",
      "indices" : [ 0, 11 ],
      "id_str" : "18537988",
      "id" : 18537988
    }, {
      "name" : "Ezekiel Brooks",
      "screen_name" : "ebfl",
      "indices" : [ 12, 17 ],
      "id_str" : "46239351",
      "id" : 46239351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296990056307113986",
  "geo" : { },
  "id_str" : "296991369870835712",
  "in_reply_to_user_id" : 18537988,
  "text" : "@steve_muir @ebfl shhhhhh! ;)",
  "id" : 296991369870835712,
  "in_reply_to_status_id" : 296990056307113986,
  "created_at" : "2013-01-31 14:40:35 +0000",
  "in_reply_to_screen_name" : "steve_muir",
  "in_reply_to_user_id_str" : "18537988",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/xSoXFgNh",
      "expanded_url" : "http:\/\/www.un.org\/apps\/news\/story.asp?NewsID=43989&Cr=protests&Cr1=#.UQp1eb-9S3w",
      "display_url" : "un.org\/apps\/news\/stor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "296989851801235457",
  "text" : "United Kingdom must review measures affecting right to peaceful assembly \u2013 UN expert http:\/\/t.co\/xSoXFgNh",
  "id" : 296989851801235457,
  "created_at" : "2013-01-31 14:34:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bren brennan",
      "screen_name" : "brenbrennan",
      "indices" : [ 0, 12 ],
      "id_str" : "39806371",
      "id" : 39806371
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296594036507160577",
  "geo" : { },
  "id_str" : "296977055034249216",
  "in_reply_to_user_id" : 39806371,
  "text" : "@brenbrennan yr welcome, lecture based conferences need to die asap :)",
  "id" : 296977055034249216,
  "in_reply_to_status_id" : 296594036507160577,
  "created_at" : "2013-01-31 13:43:42 +0000",
  "in_reply_to_screen_name" : "brenbrennan",
  "in_reply_to_user_id_str" : "39806371",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stevemuir",
      "screen_name" : "steve_muir",
      "indices" : [ 0, 11 ],
      "id_str" : "18537988",
      "id" : 18537988
    }, {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 50, 56 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296928114334904320",
  "geo" : { },
  "id_str" : "296976439956361216",
  "in_reply_to_user_id" : 18537988,
  "text" : "@steve_muir  many thx for RT steve but don't tell @EBEFL :)",
  "id" : 296976439956361216,
  "in_reply_to_status_id" : 296928114334904320,
  "created_at" : "2013-01-31 13:41:15 +0000",
  "in_reply_to_screen_name" : "steve_muir",
  "in_reply_to_user_id_str" : "18537988",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 32, 40 ],
      "id_str" : "20650366",
      "id" : 20650366
    }, {
      "name" : "Charles Rei",
      "screen_name" : "Charlesrei1",
      "indices" : [ 69, 81 ],
      "id_str" : "464454382",
      "id" : 464454382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/QTnI83Ht",
      "expanded_url" : "http:\/\/fourc.ca\/wikipedia1\/",
      "display_url" : "fourc.ca\/wikipedia1\/"
    }, {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/M6F7cLAd",
      "expanded_url" : "http:\/\/businessenglishideas.blogspot.de\/2013\/01\/five-groups-one-long-lesson.html",
      "display_url" : "businessenglishideas.blogspot.de\/2013\/01\/five-g\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "296975950338469890",
  "text" : "2 grt ex. of between class TBL? @seburnt's  http:\/\/t.co\/QTnI83Ht and @Charlesrei1's http:\/\/t.co\/M6F7cLAd",
  "id" : 296975950338469890,
  "created_at" : "2013-01-31 13:39:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    }, {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 16, 26 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296755747260350464",
  "geo" : { },
  "id_str" : "296756657298489345",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson @medialens the way he set that line up was class :)",
  "id" : 296756657298489345,
  "in_reply_to_status_id" : 296755747260350464,
  "created_at" : "2013-01-30 23:07:55 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 17, 27 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/PLfZMW3v",
      "expanded_url" : "http:\/\/tinyurl.com\/6a95s7r",
      "display_url" : "tinyurl.com\/6a95s7r"
    } ]
  },
  "geo" : { },
  "id_str" : "296755293797363712",
  "text" : "hehe fab &gt; RT @medialens What is Noam Chomsky's favourite tongue-twister? :o) http:\/\/t.co\/PLfZMW3v",
  "id" : 296755293797363712,
  "created_at" : "2013-01-30 23:02:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/TQLN4Pq4",
      "expanded_url" : "http:\/\/youtu.be\/WkzXTgslFNE",
      "display_url" : "youtu.be\/WkzXTgslFNE"
    } ]
  },
  "geo" : { },
  "id_str" : "296751369497489408",
  "text" : "nice to hear some home truths from a politician&gt;Belgian MP LAURENT LOUIS stands against war in Mali http:\/\/t.co\/TQLN4Pq4",
  "id" : 296751369497489408,
  "created_at" : "2013-01-30 22:46:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liliputing",
      "screen_name" : "liliputingnews",
      "indices" : [ 15, 30 ],
      "id_str" : "268929729",
      "id" : 268929729
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/CMWs90Fs",
      "expanded_url" : "http:\/\/dlvr.it\/2sqlZ9",
      "display_url" : "dlvr.it\/2sqlZ9"
    } ]
  },
  "geo" : { },
  "id_str" : "296740661632327682",
  "text" : "very neat &gt; @liliputingnews Turn subtitled videos into eBooks with StoryBoard http:\/\/t.co\/CMWs90Fs",
  "id" : 296740661632327682,
  "created_at" : "2013-01-30 22:04:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "webmonkey",
      "screen_name" : "webmonkey",
      "indices" : [ 3, 13 ],
      "id_str" : "14288386",
      "id" : 14288386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/bDWqTogN",
      "expanded_url" : "http:\/\/domainmasher.com\/",
      "display_url" : "domainmasher.com"
    } ]
  },
  "geo" : { },
  "id_str" : "296297523067383809",
  "text" : "RT @webmonkey: What happens when you cross a domain name checker with a thesaurus? An easy way to find a good domain: http:\/\/t.co\/bDWqTogN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 123 ],
        "url" : "http:\/\/t.co\/bDWqTogN",
        "expanded_url" : "http:\/\/domainmasher.com\/",
        "display_url" : "domainmasher.com"
      } ]
    },
    "geo" : { },
    "id_str" : "296295949096083456",
    "text" : "What happens when you cross a domain name checker with a thesaurus? An easy way to find a good domain: http:\/\/t.co\/bDWqTogN",
    "id" : 296295949096083456,
    "created_at" : "2013-01-29 16:37:13 +0000",
    "user" : {
      "name" : "webmonkey",
      "screen_name" : "webmonkey",
      "protected" : false,
      "id_str" : "14288386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/480877915324682240\/eu7F-z0M_normal.jpeg",
      "id" : 14288386,
      "verified" : false
    }
  },
  "id" : 296297523067383809,
  "created_at" : "2013-01-29 16:43:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    }, {
      "name" : "bren brennan",
      "screen_name" : "brenbrennan",
      "indices" : [ 17, 29 ],
      "id_str" : "39806371",
      "id" : 39806371
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296271433628274688",
  "geo" : { },
  "id_str" : "296292151296401408",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin @brenbrennan hmm r u sure it was that absolutely  brilliant ;)",
  "id" : 296292151296401408,
  "in_reply_to_status_id" : 296271433628274688,
  "created_at" : "2013-01-29 16:22:08 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenn Greenwald",
      "screen_name" : "ggreenwald",
      "indices" : [ 3, 14 ],
      "id_str" : "16076032",
      "id" : 16076032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/vTasvkzU",
      "expanded_url" : "http:\/\/news.antiwar.com\/2013\/01\/27\/12-civilians-slain-in-french-attack-on-mali-town-of-konna\/",
      "display_url" : "news.antiwar.com\/2013\/01\/27\/12-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "296015714853216256",
  "text" : "RT @ggreenwald: 12 civilians killed by French attack on Mali town  http:\/\/t.co\/vTasvkzU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 71 ],
        "url" : "http:\/\/t.co\/vTasvkzU",
        "expanded_url" : "http:\/\/news.antiwar.com\/2013\/01\/27\/12-civilians-slain-in-french-attack-on-mali-town-of-konna\/",
        "display_url" : "news.antiwar.com\/2013\/01\/27\/12-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "295959116311035904",
    "text" : "12 civilians killed by French attack on Mali town  http:\/\/t.co\/vTasvkzU",
    "id" : 295959116311035904,
    "created_at" : "2013-01-28 18:18:46 +0000",
    "user" : {
      "name" : "Glenn Greenwald",
      "screen_name" : "ggreenwald",
      "protected" : false,
      "id_str" : "16076032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/659383028771364869\/G9HHnjiI_normal.jpg",
      "id" : 16076032,
      "verified" : true
    }
  },
  "id" : 296015714853216256,
  "created_at" : "2013-01-28 22:03:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate Bowles",
      "screen_name" : "KateMfD",
      "indices" : [ 3, 11 ],
      "id_str" : "379065166",
      "id" : 379065166
    }, {
      "name" : "Tim McCormick",
      "screen_name" : "tmccormick",
      "indices" : [ 16, 27 ],
      "id_str" : "21759817",
      "id" : 21759817
    }, {
      "name" : "Kathleen Fitzpatrick",
      "screen_name" : "kfitz",
      "indices" : [ 118, 124 ],
      "id_str" : "14308843",
      "id" : 14308843
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/7auIw6rU",
      "expanded_url" : "http:\/\/bit.ly\/10YJcXH",
      "display_url" : "bit.ly\/10YJcXH"
    } ]
  },
  "geo" : { },
  "id_str" : "295843303558103040",
  "text" : "RT @KateMfD: RT @tmccormick: \u201CHeteroglossia and Nonhominem for a More Civil Twitter\u201D http:\/\/t.co\/7auIw6rU in reply to @kfitz &lt; vital  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tim McCormick",
        "screen_name" : "tmccormick",
        "indices" : [ 3, 14 ],
        "id_str" : "21759817",
        "id" : 21759817
      }, {
        "name" : "Kathleen Fitzpatrick",
        "screen_name" : "kfitz",
        "indices" : [ 105, 111 ],
        "id_str" : "14308843",
        "id" : 14308843
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 92 ],
        "url" : "http:\/\/t.co\/7auIw6rU",
        "expanded_url" : "http:\/\/bit.ly\/10YJcXH",
        "display_url" : "bit.ly\/10YJcXH"
      } ]
    },
    "geo" : { },
    "id_str" : "295823499421949952",
    "text" : "RT @tmccormick: \u201CHeteroglossia and Nonhominem for a More Civil Twitter\u201D http:\/\/t.co\/7auIw6rU in reply to @kfitz &lt; vital debate continued",
    "id" : 295823499421949952,
    "created_at" : "2013-01-28 09:19:53 +0000",
    "user" : {
      "name" : "Kate Bowles",
      "screen_name" : "KateMfD",
      "protected" : false,
      "id_str" : "379065166",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1557363696\/Screen_shot_2011-09-24_at_7.36.20_PM_normal.png",
      "id" : 379065166,
      "verified" : false
    }
  },
  "id" : 295843303558103040,
  "created_at" : "2013-01-28 10:38:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Thornbury",
      "screen_name" : "thornburyscott",
      "indices" : [ 89, 104 ],
      "id_str" : "23090474",
      "id" : 23090474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "295834022704189440",
  "text" : "@kevingiddens thk for mention kevin, very intriguing the ignorant schoomaster, ties with @thornburyscott latest on contrastive analysis?",
  "id" : 295834022704189440,
  "created_at" : "2013-01-28 10:01:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hancock McDonald ELT",
      "screen_name" : "HancockMcDonald",
      "indices" : [ 29, 45 ],
      "id_str" : "552929354",
      "id" : 552929354
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/fLCYdp0y",
      "expanded_url" : "http:\/\/tinyurl.com\/9ol8oyz",
      "display_url" : "tinyurl.com\/9ol8oyz"
    } ]
  },
  "geo" : { },
  "id_str" : "295594533570351104",
  "text" : "where be the treasure?&gt;MT @HancockMcDonald 'A Map of ELT'  More about it here: http:\/\/t.co\/fLCYdp0y",
  "id" : 295594533570351104,
  "created_at" : "2013-01-27 18:10:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 87, 98 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/ACZrB6bA",
      "expanded_url" : "http:\/\/leoxicon.blogspot.fr\/2013\/01\/start-teaching-lexically.html",
      "display_url" : "leoxicon.blogspot.fr\/2013\/01\/start-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "295544587609591808",
  "text" : "v. nice teaching tips &gt; Start teaching lexically in 2013 : http:\/\/t.co\/ACZrB6bA via @leoselivan",
  "id" : 295544587609591808,
  "created_at" : "2013-01-27 14:51:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Grevett",
      "screen_name" : "breathyvowel",
      "indices" : [ 3, 16 ],
      "id_str" : "237547177",
      "id" : 237547177
    }, {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 21, 37 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KELTchat",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/6IWMaIcE",
      "expanded_url" : "http:\/\/eltrantsreviewsreflections.wordpress.com\/2013\/01\/27\/the-dude-abides\/",
      "display_url" : "\u2026rantsreviewsreflections.wordpress.com\/2013\/01\/27\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "295542007789658112",
  "text" : "RT @breathyvowel: MT @michaelegriffin talks rules, beliefs and complications in Teaching wisdom from the Big Lebowski http:\/\/t.co\/6IWMaI ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Michael Griffin",
        "screen_name" : "michaelegriffin",
        "indices" : [ 3, 19 ],
        "id_str" : "394053348",
        "id" : 394053348
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "KELTchat",
        "indices" : [ 121, 130 ]
      } ],
      "urls" : [ {
        "indices" : [ 100, 120 ],
        "url" : "http:\/\/t.co\/6IWMaIcE",
        "expanded_url" : "http:\/\/eltrantsreviewsreflections.wordpress.com\/2013\/01\/27\/the-dude-abides\/",
        "display_url" : "\u2026rantsreviewsreflections.wordpress.com\/2013\/01\/27\/the\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "295525614755135489",
    "text" : "MT @michaelegriffin talks rules, beliefs and complications in Teaching wisdom from the Big Lebowski http:\/\/t.co\/6IWMaIcE #KELTchat",
    "id" : 295525614755135489,
    "created_at" : "2013-01-27 13:36:11 +0000",
    "user" : {
      "name" : "Alex Grevett",
      "screen_name" : "breathyvowel",
      "protected" : false,
      "id_str" : "237547177",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3101668289\/f2e27b108853582e71e99cb0a0ef6638_normal.jpeg",
      "id" : 237547177,
      "verified" : false
    }
  },
  "id" : 295542007789658112,
  "created_at" : "2013-01-27 14:41:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 0, 13 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "295539830996234240",
  "in_reply_to_user_id" : 88655243,
  "text" : "@rosemerebard obrigado rt rose :)",
  "id" : 295539830996234240,
  "created_at" : "2013-01-27 14:32:41 +0000",
  "in_reply_to_screen_name" : "rosemerebard",
  "in_reply_to_user_id_str" : "88655243",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alannah Fitzgerald",
      "screen_name" : "AlannahFitz",
      "indices" : [ 0, 12 ],
      "id_str" : "223613160",
      "id" : 223613160
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294883968837365760",
  "geo" : { },
  "id_str" : "295539394750869506",
  "in_reply_to_user_id" : 223613160,
  "text" : "@AlannahFitz pleasure, really like what u r doing re open resources :)",
  "id" : 295539394750869506,
  "in_reply_to_status_id" : 294883968837365760,
  "created_at" : "2013-01-27 14:30:57 +0000",
  "in_reply_to_screen_name" : "AlannahFitz",
  "in_reply_to_user_id_str" : "223613160",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 0, 11 ],
      "id_str" : "282659955",
      "id" : 282659955
    }, {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 12, 27 ],
      "id_str" : "20760283",
      "id" : 20760283
    }, {
      "name" : "Arizio Sweeting",
      "screen_name" : "ariziosweeting",
      "indices" : [ 28, 43 ],
      "id_str" : "75252733",
      "id" : 75252733
    }, {
      "name" : "c m kerr",
      "screen_name" : "KerrCarolyn",
      "indices" : [ 44, 56 ],
      "id_str" : "468676296",
      "id" : 468676296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294862670975361024",
  "geo" : { },
  "id_str" : "295539237602869249",
  "in_reply_to_user_id" : 282659955,
  "text" : "@teflerinha @MrChrisJWilson @ariziosweeting @KerrCarolyn thanks for share rachael hope u r having a good sunday",
  "id" : 295539237602869249,
  "in_reply_to_status_id" : 294862670975361024,
  "created_at" : "2013-01-27 14:30:19 +0000",
  "in_reply_to_screen_name" : "teflerinha",
  "in_reply_to_user_id_str" : "282659955",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephanie McIntosh",
      "screen_name" : "purple_steph",
      "indices" : [ 0, 13 ],
      "id_str" : "18678010",
      "id" : 18678010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294835691223912449",
  "geo" : { },
  "id_str" : "294842081044746240",
  "in_reply_to_user_id" : 18678010,
  "text" : "@purple_steph true students r surprised especially by the term gender neutral!",
  "id" : 294842081044746240,
  "in_reply_to_status_id" : 294835691223912449,
  "created_at" : "2013-01-25 16:20:04 +0000",
  "in_reply_to_screen_name" : "purple_steph",
  "in_reply_to_user_id_str" : "18678010",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Open access MFL",
      "screen_name" : "YazikOpen",
      "indices" : [ 65, 75 ],
      "id_str" : "411834669",
      "id" : 411834669
    }, {
      "name" : "Alannah Fitzgerald",
      "screen_name" : "AlannahFitz",
      "indices" : [ 89, 101 ],
      "id_str" : "223613160",
      "id" : 223613160
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/YczOVFFP",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-gu",
      "display_url" : "wp.me\/pgHyE-gu"
    } ]
  },
  "geo" : { },
  "id_str" : "294841875020537856",
  "text" : "updated feedback research post http:\/\/t.co\/YczOVFFP with link to @yazikopen directory HT @AlannahFitz",
  "id" : 294841875020537856,
  "created_at" : "2013-01-25 16:19:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bethany Nowviskie",
      "screen_name" : "nowviskie",
      "indices" : [ 3, 13 ],
      "id_str" : "14221013",
      "id" : 14221013
    }, {
      "name" : "Bess Sadler",
      "screen_name" : "eosadler",
      "indices" : [ 67, 76 ],
      "id_str" : "14068465",
      "id" : 14068465
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "aaronsw",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/xhinaFsX",
      "expanded_url" : "http:\/\/www.ibiblio.org\/bess\/?p=290",
      "display_url" : "ibiblio.org\/bess\/?p=290"
    } ]
  },
  "geo" : { },
  "id_str" : "294799779454676992",
  "text" : "RT @nowviskie: Brave, selfless, vulnerable, strong, &amp; true. RT @eosadler: This is the opposite of a suicide note. http:\/\/t.co\/xhinaF ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bess Sadler",
        "screen_name" : "eosadler",
        "indices" : [ 52, 61 ],
        "id_str" : "14068465",
        "id" : 14068465
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "aaronsw",
        "indices" : [ 124, 132 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 123 ],
        "url" : "http:\/\/t.co\/xhinaFsX",
        "expanded_url" : "http:\/\/www.ibiblio.org\/bess\/?p=290",
        "display_url" : "ibiblio.org\/bess\/?p=290"
      } ]
    },
    "geo" : { },
    "id_str" : "294594147254431744",
    "text" : "Brave, selfless, vulnerable, strong, &amp; true. RT @eosadler: This is the opposite of a suicide note. http:\/\/t.co\/xhinaFsX #aaronsw",
    "id" : 294594147254431744,
    "created_at" : "2013-01-24 23:54:52 +0000",
    "user" : {
      "name" : "Bethany Nowviskie",
      "screen_name" : "nowviskie",
      "protected" : false,
      "id_str" : "14221013",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751794036365594625\/xIEFm3Jp_normal.jpg",
      "id" : 14221013,
      "verified" : false
    }
  },
  "id" : 294799779454676992,
  "created_at" : "2013-01-25 13:31:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 0, 11 ],
      "id_str" : "282659955",
      "id" : 282659955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294774039556276225",
  "geo" : { },
  "id_str" : "294774724255424512",
  "in_reply_to_user_id" : 282659955,
  "text" : "@teflerinha no worries nice lesson :)",
  "id" : 294774724255424512,
  "in_reply_to_status_id" : 294774039556276225,
  "created_at" : "2013-01-25 11:52:25 +0000",
  "in_reply_to_screen_name" : "teflerinha",
  "in_reply_to_user_id_str" : "282659955",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 0, 11 ],
      "id_str" : "282659955",
      "id" : 282659955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294769155138285568",
  "geo" : { },
  "id_str" : "294773786052542464",
  "in_reply_to_user_id" : 282659955,
  "text" : "@teflerinha hi, there seems to be a typo on the answer key section: non-defining instead of defining",
  "id" : 294773786052542464,
  "in_reply_to_status_id" : 294769155138285568,
  "created_at" : "2013-01-25 11:48:41 +0000",
  "in_reply_to_screen_name" : "teflerinha",
  "in_reply_to_user_id_str" : "282659955",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sophia Khan",
      "screen_name" : "SophiaKhan4",
      "indices" : [ 0, 12 ],
      "id_str" : "351390617",
      "id" : 351390617
    }, {
      "name" : "Stephanie McIntosh",
      "screen_name" : "purple_steph",
      "indices" : [ 13, 26 ],
      "id_str" : "18678010",
      "id" : 18678010
    }, {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 27, 37 ],
      "id_str" : "525274103",
      "id" : 525274103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294760059550973953",
  "geo" : { },
  "id_str" : "294761931183624194",
  "in_reply_to_user_id" : 351390617,
  "text" : "@SophiaKhan4 @purple_steph @ElkySmith guess need to normalise diff data to compare, makes sense no hyphen for twitter re character count.",
  "id" : 294761931183624194,
  "in_reply_to_status_id" : 294760059550973953,
  "created_at" : "2013-01-25 11:01:35 +0000",
  "in_reply_to_screen_name" : "SophiaKhan4",
  "in_reply_to_user_id_str" : "351390617",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephanie McIntosh",
      "screen_name" : "purple_steph",
      "indices" : [ 0, 13 ],
      "id_str" : "18678010",
      "id" : 18678010
    }, {
      "name" : "Sophia Khan",
      "screen_name" : "SophiaKhan4",
      "indices" : [ 14, 26 ],
      "id_str" : "351390617",
      "id" : 351390617
    }, {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 27, 37 ],
      "id_str" : "525274103",
      "id" : 525274103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/0KYnwvht",
      "expanded_url" : "http:\/\/www.ark.cs.cmu.edu\/TweetNLP\/paths\/11110111001001.html",
      "display_url" : "ark.cs.cmu.edu\/TweetNLP\/paths\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "294754912070418432",
  "geo" : { },
  "id_str" : "294759458750472192",
  "in_reply_to_user_id" : 18678010,
  "text" : "@purple_steph @SophiaKhan4 @ElkySmith found this http:\/\/t.co\/0KYnwvht ebook more freq than e-book on twitter",
  "id" : 294759458750472192,
  "in_reply_to_status_id" : 294754912070418432,
  "created_at" : "2013-01-25 10:51:45 +0000",
  "in_reply_to_screen_name" : "purple_steph",
  "in_reply_to_user_id_str" : "18678010",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sophia Khan",
      "screen_name" : "SophiaKhan4",
      "indices" : [ 0, 12 ],
      "id_str" : "351390617",
      "id" : 351390617
    }, {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 13, 24 ],
      "id_str" : "144663117",
      "id" : 144663117
    }, {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 25, 41 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294751632904818690",
  "geo" : { },
  "id_str" : "294751980839133184",
  "in_reply_to_user_id" : 351390617,
  "text" : "@SophiaKhan4 @kevchanwow @michaelegriffin hehe though looks like i may be getting drawn to google+ now agh!",
  "id" : 294751980839133184,
  "in_reply_to_status_id" : 294751632904818690,
  "created_at" : "2013-01-25 10:22:03 +0000",
  "in_reply_to_screen_name" : "SophiaKhan4",
  "in_reply_to_user_id_str" : "351390617",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephanie McIntosh",
      "screen_name" : "purple_steph",
      "indices" : [ 0, 13 ],
      "id_str" : "18678010",
      "id" : 18678010
    }, {
      "name" : "Sophia Khan",
      "screen_name" : "SophiaKhan4",
      "indices" : [ 14, 26 ],
      "id_str" : "351390617",
      "id" : 351390617
    }, {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 27, 37 ],
      "id_str" : "525274103",
      "id" : 525274103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294748306721103872",
  "geo" : { },
  "id_str" : "294751577896525825",
  "in_reply_to_user_id" : 18678010,
  "text" : "@purple_steph @SophiaKhan4 @ElkySmith good point COCA does not. what do u mean by character  count?",
  "id" : 294751577896525825,
  "in_reply_to_status_id" : 294748306721103872,
  "created_at" : "2013-01-25 10:20:27 +0000",
  "in_reply_to_screen_name" : "purple_steph",
  "in_reply_to_user_id_str" : "18678010",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keri-Lee Beasley",
      "screen_name" : "klbeasley",
      "indices" : [ 0, 10 ],
      "id_str" : "14483067",
      "id" : 14483067
    }, {
      "name" : "Jabiz Raisdana",
      "screen_name" : "intrepidteacher",
      "indices" : [ 11, 27 ],
      "id_str" : "11976052",
      "id" : 11976052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294739029428162560",
  "geo" : { },
  "id_str" : "294743739325349888",
  "in_reply_to_user_id" : 14483067,
  "text" : "@klbeasley @intrepidteacher ok no worries, good luck ;)",
  "id" : 294743739325349888,
  "in_reply_to_status_id" : 294739029428162560,
  "created_at" : "2013-01-25 09:49:18 +0000",
  "in_reply_to_screen_name" : "klbeasley",
  "in_reply_to_user_id_str" : "14483067",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    }, {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 12, 28 ],
      "id_str" : "394053348",
      "id" : 394053348
    }, {
      "name" : "Sophia Khan",
      "screen_name" : "SophiaKhan4",
      "indices" : [ 29, 41 ],
      "id_str" : "351390617",
      "id" : 351390617
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294739350879612928",
  "geo" : { },
  "id_str" : "294741849187434496",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow @michaelegriffin @SophiaKhan4 bugger not on FB :(",
  "id" : 294741849187434496,
  "in_reply_to_status_id" : 294739350879612928,
  "created_at" : "2013-01-25 09:41:47 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    }, {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 12, 28 ],
      "id_str" : "394053348",
      "id" : 394053348
    }, {
      "name" : "Sophia Khan",
      "screen_name" : "SophiaKhan4",
      "indices" : [ 29, 41 ],
      "id_str" : "351390617",
      "id" : 351390617
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "weekendisnearlyhere",
      "indices" : [ 92, 112 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294736424257875968",
  "geo" : { },
  "id_str" : "294738018655412224",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow @michaelegriffin @SophiaKhan4 hey all, is that mini-review available somewhere? #weekendisnearlyhere",
  "id" : 294738018655412224,
  "in_reply_to_status_id" : 294736424257875968,
  "created_at" : "2013-01-25 09:26:34 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keri-Lee Beasley",
      "screen_name" : "klbeasley",
      "indices" : [ 0, 10 ],
      "id_str" : "14483067",
      "id" : 14483067
    }, {
      "name" : "Jabiz Raisdana",
      "screen_name" : "intrepidteacher",
      "indices" : [ 11, 27 ],
      "id_str" : "11976052",
      "id" : 11976052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294734611982983170",
  "geo" : { },
  "id_str" : "294737384912859136",
  "in_reply_to_user_id" : 14483067,
  "text" : "@klbeasley @intrepidteacher i don't have ithing so that's why i asked, epub?",
  "id" : 294737384912859136,
  "in_reply_to_status_id" : 294734611982983170,
  "created_at" : "2013-01-25 09:24:03 +0000",
  "in_reply_to_screen_name" : "klbeasley",
  "in_reply_to_user_id_str" : "14483067",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George Siemens",
      "screen_name" : "gsiemens",
      "indices" : [ 12, 21 ],
      "id_str" : "18613",
      "id" : 18613
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "privacy",
      "indices" : [ 108, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/dwVRmhYe",
      "expanded_url" : "http:\/\/actualfacebookgraphsearches.tumblr.com\/",
      "display_url" : "actualfacebookgraphsearches.tumblr.com"
    } ]
  },
  "geo" : { },
  "id_str" : "294736506600439809",
  "text" : "yowser&gt;RT@gsiemens                                 actual facebook graph searches: http:\/\/t.co\/dwVRmhYe  #privacy",
  "id" : 294736506600439809,
  "created_at" : "2013-01-25 09:20:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jabiz Raisdana",
      "screen_name" : "intrepidteacher",
      "indices" : [ 0, 16 ],
      "id_str" : "11976052",
      "id" : 11976052
    }, {
      "name" : "Keri-Lee Beasley",
      "screen_name" : "klbeasley",
      "indices" : [ 17, 27 ],
      "id_str" : "14483067",
      "id" : 14483067
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294668749645180928",
  "geo" : { },
  "id_str" : "294733396675002369",
  "in_reply_to_user_id" : 11976052,
  "text" : "@intrepidteacher @klbeasley any plans for other format?",
  "id" : 294733396675002369,
  "in_reply_to_status_id" : 294668749645180928,
  "created_at" : "2013-01-25 09:08:12 +0000",
  "in_reply_to_screen_name" : "intrepidteacher",
  "in_reply_to_user_id_str" : "11976052",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sophia Khan",
      "screen_name" : "SophiaKhan4",
      "indices" : [ 0, 12 ],
      "id_str" : "351390617",
      "id" : 351390617
    }, {
      "name" : "Stephanie McIntosh",
      "screen_name" : "purple_steph",
      "indices" : [ 13, 26 ],
      "id_str" : "18678010",
      "id" : 18678010
    }, {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 27, 37 ],
      "id_str" : "525274103",
      "id" : 525274103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294725804808601602",
  "geo" : { },
  "id_str" : "294728035905703936",
  "in_reply_to_user_id" : 351390617,
  "text" : "@SophiaKhan4 @purple_steph @ElkySmith seems b is lower case if hyphenated, upper case if not (from COCA). and hypenated forms dominate",
  "id" : 294728035905703936,
  "in_reply_to_status_id" : 294725804808601602,
  "created_at" : "2013-01-25 08:46:54 +0000",
  "in_reply_to_screen_name" : "SophiaKhan4",
  "in_reply_to_user_id_str" : "351390617",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate Bowles",
      "screen_name" : "KateMfD",
      "indices" : [ 85, 93 ],
      "id_str" : "379065166",
      "id" : 379065166
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edchat",
      "indices" : [ 94, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/TNJYlV3a",
      "expanded_url" : "http:\/\/wp.me\/p1tYEb-C9",
      "display_url" : "wp.me\/p1tYEb-C9"
    } ]
  },
  "geo" : { },
  "id_str" : "294600056118583297",
  "text" : "California uber alles?&gt;Visions always belong to someone http:\/\/t.co\/TNJYlV3a  via @KateMfD #edchat",
  "id" : 294600056118583297,
  "created_at" : "2013-01-25 00:18:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "294548605480628224",
  "text" : "what's the point of making infographics that you need to scroll to see? :\/",
  "id" : 294548605480628224,
  "created_at" : "2013-01-24 20:53:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 108, 116 ]
    }, {
      "text" : "edchat",
      "indices" : [ 117, 124 ]
    }, {
      "text" : "efl",
      "indices" : [ 125, 129 ]
    }, {
      "text" : "elt",
      "indices" : [ 130, 134 ]
    }, {
      "text" : "tefl",
      "indices" : [ 135, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/LYvOUJQu",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-h2",
      "display_url" : "wp.me\/pgHyE-h2"
    } ]
  },
  "geo" : { },
  "id_str" : "294541194850086912",
  "text" : "Bloggy - The thermodynamics of glittens, mini-narrow reading and collaborative writing http:\/\/t.co\/LYvOUJQu #eltchat #edchat #efl #elt #tefl",
  "id" : 294541194850086912,
  "created_at" : "2013-01-24 20:24:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "294434422193807360",
  "text" : "@EBEFL he's been at those smarties again, need AgentScrivener to set him right ;)",
  "id" : 294434422193807360,
  "created_at" : "2013-01-24 13:20:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chia Suan Chong",
      "screen_name" : "chiasuan",
      "indices" : [ 0, 9 ],
      "id_str" : "71588589",
      "id" : 71588589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294421807015018496",
  "geo" : { },
  "id_str" : "294424444825395202",
  "in_reply_to_user_id" : 71588589,
  "text" : "@chiasuan dang i won't complain next time i have a long commute to a job ;) good luck :)",
  "id" : 294424444825395202,
  "in_reply_to_status_id" : 294421807015018496,
  "created_at" : "2013-01-24 12:40:32 +0000",
  "in_reply_to_screen_name" : "chiasuan",
  "in_reply_to_user_id_str" : "71588589",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294407479834574848",
  "geo" : { },
  "id_str" : "294415144014991363",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson \/actual literal LOL\/ make sure you tape that next that happens :)",
  "id" : 294415144014991363,
  "in_reply_to_status_id" : 294407479834574848,
  "created_at" : "2013-01-24 12:03:34 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 0, 11 ],
      "id_str" : "282659955",
      "id" : 282659955
    }, {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 12, 27 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294413401529147392",
  "geo" : { },
  "id_str" : "294414322703167489",
  "in_reply_to_user_id" : 282659955,
  "text" : "@teflerinha @MrChrisJWilson Nice!",
  "id" : 294414322703167489,
  "in_reply_to_status_id" : 294413401529147392,
  "created_at" : "2013-01-24 12:00:19 +0000",
  "in_reply_to_screen_name" : "teflerinha",
  "in_reply_to_user_id_str" : "282659955",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/UHKRTW4m",
      "expanded_url" : "http:\/\/tinyurl.com\/b3e45nf",
      "display_url" : "tinyurl.com\/b3e45nf"
    } ]
  },
  "geo" : { },
  "id_str" : "294413150088986624",
  "text" : "RT @medialens: Media Alert: Eyes Like Blank Discs - The Guardian's Steven Poole On George Orwell's Politics And The English Language htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/UHKRTW4m",
        "expanded_url" : "http:\/\/tinyurl.com\/b3e45nf",
        "display_url" : "tinyurl.com\/b3e45nf"
      } ]
    },
    "geo" : { },
    "id_str" : "294405251031760897",
    "text" : "Media Alert: Eyes Like Blank Discs - The Guardian's Steven Poole On George Orwell's Politics And The English Language http:\/\/t.co\/UHKRTW4m",
    "id" : 294405251031760897,
    "created_at" : "2013-01-24 11:24:16 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 294413150088986624,
  "created_at" : "2013-01-24 11:55:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294392876396318720",
  "geo" : { },
  "id_str" : "294394560203853825",
  "in_reply_to_user_id" : 408492806,
  "text" : "@divyabrochier grt look fwd to it!",
  "id" : 294394560203853825,
  "in_reply_to_status_id" : 294392876396318720,
  "created_at" : "2013-01-24 10:41:47 +0000",
  "in_reply_to_screen_name" : "_divyamadhavan",
  "in_reply_to_user_id_str" : "408492806",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "294394147140403200",
  "text" : "i'm no mathematician but \"to take a life to save a life\" does not add up :\/, maybe one can indeed win bets playing Harry at pool.",
  "id" : 294394147140403200,
  "created_at" : "2013-01-24 10:40:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheLanguagePoint",
      "screen_name" : "Marie_Sanako",
      "indices" : [ 0, 13 ],
      "id_str" : "356176087",
      "id" : 356176087
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294376939307819008",
  "geo" : { },
  "id_str" : "294389932498227200",
  "in_reply_to_user_id" : 356176087,
  "text" : "@Marie_Sanako woohoo :)",
  "id" : 294389932498227200,
  "in_reply_to_status_id" : 294376939307819008,
  "created_at" : "2013-01-24 10:23:24 +0000",
  "in_reply_to_screen_name" : "Marie_Sanako",
  "in_reply_to_user_id_str" : "356176087",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294381819980308480",
  "geo" : { },
  "id_str" : "294389032056651777",
  "in_reply_to_user_id" : 408492806,
  "text" : "@divyabrochier yr welcome, have u written more about the student made coursebooks?",
  "id" : 294389032056651777,
  "in_reply_to_status_id" : 294381819980308480,
  "created_at" : "2013-01-24 10:19:49 +0000",
  "in_reply_to_screen_name" : "_divyamadhavan",
  "in_reply_to_user_id_str" : "408492806",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/294388086496976896\/photo\/1",
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/xdBS2SqY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BBXgZ6pCYAArxNz.jpg",
      "id_str" : "294388086505365504",
      "id" : 294388086505365504,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BBXgZ6pCYAArxNz.jpg",
      "sizes" : [ {
        "h" : 597,
        "resize" : "fit",
        "w" : 597
      }, {
        "h" : 597,
        "resize" : "fit",
        "w" : 597
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 597,
        "resize" : "fit",
        "w" : 597
      } ],
      "display_url" : "pic.twitter.com\/xdBS2SqY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294381825546145792",
  "geo" : { },
  "id_str" : "294388086496976896",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson got an few minutes to kill make a DH ELT meme? :) http:\/\/t.co\/xdBS2SqY",
  "id" : 294388086496976896,
  "in_reply_to_status_id" : 294381825546145792,
  "created_at" : "2013-01-24 10:16:04 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/vAgIXLHN",
      "expanded_url" : "http:\/\/bit.ly\/WoiUfu",
      "display_url" : "bit.ly\/WoiUfu"
    } ]
  },
  "geo" : { },
  "id_str" : "294364568006832128",
  "text" : "Some quotes from Orwell that the liberal media don't quote on Orwell day http:\/\/t.co\/vAgIXLHN",
  "id" : 294364568006832128,
  "created_at" : "2013-01-24 08:42:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/uWRQ96Hk",
      "expanded_url" : "http:\/\/brianhaw.tv\/index.php?option=com_content&view=category&layout=blog&id=34&Itemid=50",
      "display_url" : "brianhaw.tv\/index.php?opti\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "294360236049973248",
  "text" : "Barbara Tucker  HUNGER STRIKE DAY 28: \"ARREST\" 48 http:\/\/t.co\/uWRQ96Hk",
  "id" : 294360236049973248,
  "created_at" : "2013-01-24 08:25:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "indices" : [ 0, 13 ],
      "id_str" : "1685397408",
      "id" : 1685397408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "294357963479592960",
  "text" : "@harrisonmike true the authorities would rather send him to some memory hole, proper charges would mean they have some semblence of a case",
  "id" : 294357963479592960,
  "created_at" : "2013-01-24 08:16:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "indices" : [ 0, 13 ],
      "id_str" : "1685397408",
      "id" : 1685397408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "294352779940601856",
  "text" : "@harrisonmike what do you find tiresome about it mike?",
  "id" : 294352779940601856,
  "created_at" : "2013-01-24 07:55:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 0, 11 ],
      "id_str" : "282659955",
      "id" : 282659955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294312396992942081",
  "geo" : { },
  "id_str" : "294324751747383297",
  "in_reply_to_user_id" : 282659955,
  "text" : "@teflerinha many thanks for share Rachael, replied to yr comment.",
  "id" : 294324751747383297,
  "in_reply_to_status_id" : 294312396992942081,
  "created_at" : "2013-01-24 06:04:23 +0000",
  "in_reply_to_screen_name" : "teflerinha",
  "in_reply_to_user_id_str" : "282659955",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294282381949550593",
  "geo" : { },
  "id_str" : "294323012260474881",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt many thanks for spotting that Tyson, corrected.",
  "id" : 294323012260474881,
  "in_reply_to_status_id" : 294282381949550593,
  "created_at" : "2013-01-24 05:57:29 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George Chilton",
      "screen_name" : "designerlessons",
      "indices" : [ 0, 16 ],
      "id_str" : "432090149",
      "id" : 432090149
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294216611546681345",
  "geo" : { },
  "id_str" : "294219053877325824",
  "in_reply_to_user_id" : 432090149,
  "text" : "@designerlessons hehe maybe i shld try that with uni students ;)",
  "id" : 294219053877325824,
  "in_reply_to_status_id" : 294216611546681345,
  "created_at" : "2013-01-23 23:04:23 +0000",
  "in_reply_to_screen_name" : "designerlessons",
  "in_reply_to_user_id_str" : "432090149",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George Chilton",
      "screen_name" : "designerlessons",
      "indices" : [ 0, 16 ],
      "id_str" : "432090149",
      "id" : 432090149
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294211299431301120",
  "geo" : { },
  "id_str" : "294214985750556673",
  "in_reply_to_user_id" : 432090149,
  "text" : "@designerlessons maybe figuring out what to look for as evidence that they are learning what you wanted them to learn",
  "id" : 294214985750556673,
  "in_reply_to_status_id" : 294211299431301120,
  "created_at" : "2013-01-23 22:48:13 +0000",
  "in_reply_to_screen_name" : "designerlessons",
  "in_reply_to_user_id_str" : "432090149",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Hawksey",
      "screen_name" : "mhawksey",
      "indices" : [ 83, 92 ],
      "id_str" : "13046992",
      "id" : 13046992
    }, {
      "name" : "Scott Thornbury",
      "screen_name" : "thornburyscott",
      "indices" : [ 123, 138 ],
      "id_str" : "23090474",
      "id" : 23090474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 39 ],
      "url" : "https:\/\/t.co\/dnVoBlyq",
      "expanded_url" : "https:\/\/googledrive.com\/host\/0B7FW2BYaBgeiS1NiR0dwWlZBc2M\/",
      "display_url" : "googledrive.com\/host\/0B7FW2BYa\u2026"
    }, {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/9rfs0eZe",
      "expanded_url" : "http:\/\/bit.ly\/Vo0pJw",
      "display_url" : "bit.ly\/Vo0pJw"
    } ]
  },
  "geo" : { },
  "id_str" : "294205509043630080",
  "text" : "archive of Tweets https:\/\/t.co\/dnVoBlyq for thebored  thks http:\/\/t.co\/9rfs0eZe by @mhawksey; star ELT tweeters do same cc @thornburyscott",
  "id" : 294205509043630080,
  "created_at" : "2013-01-23 22:10:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 11, 19 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "294203254085132289",
  "text" : "thx all :) #eltchat",
  "id" : 294203254085132289,
  "created_at" : "2013-01-23 22:01:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 3, 18 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/8cQTZDKz",
      "expanded_url" : "http:\/\/www.amazon.co.uk\/habits-speed-blogging-today-ebook\/dp\/B00B48GKZG\/ref=sr_1_1?ie=UTF8&qid=1358965362&sr=8-1",
      "display_url" : "amazon.co.uk\/habits-speed-b\u2026"
    }, {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/TceVYzAT",
      "expanded_url" : "http:\/\/www.bloghabits.com",
      "display_url" : "bloghabits.com"
    } ]
  },
  "geo" : { },
  "id_str" : "294196756370051074",
  "text" : "RT @MrChrisJWilson: So I've self published a tiny report on blogging http:\/\/t.co\/8cQTZDKz that you can get for free at http:\/\/t.co\/TceVY ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 69 ],
        "url" : "http:\/\/t.co\/8cQTZDKz",
        "expanded_url" : "http:\/\/www.amazon.co.uk\/habits-speed-blogging-today-ebook\/dp\/B00B48GKZG\/ref=sr_1_1?ie=UTF8&qid=1358965362&sr=8-1",
        "display_url" : "amazon.co.uk\/habits-speed-b\u2026"
      }, {
        "indices" : [ 99, 119 ],
        "url" : "http:\/\/t.co\/TceVYzAT",
        "expanded_url" : "http:\/\/www.bloghabits.com",
        "display_url" : "bloghabits.com"
      } ]
    },
    "geo" : { },
    "id_str" : "294148985554341889",
    "text" : "So I've self published a tiny report on blogging http:\/\/t.co\/8cQTZDKz that you can get for free at http:\/\/t.co\/TceVYzAT :)",
    "id" : 294148985554341889,
    "created_at" : "2013-01-23 18:25:57 +0000",
    "user" : {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "protected" : false,
      "id_str" : "20760283",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744952885595758592\/H4bmsUn3_normal.jpg",
      "id" : 20760283,
      "verified" : false
    }
  },
  "id" : 294196756370051074,
  "created_at" : "2013-01-23 21:35:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Krashen",
      "screen_name" : "skrashen",
      "indices" : [ 3, 12 ],
      "id_str" : "25624708",
      "id" : 25624708
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/7rYZxNRF",
      "expanded_url" : "http:\/\/www.susanohanian.org\/core.php?id=399",
      "display_url" : "susanohanian.org\/core.php?id=399"
    } ]
  },
  "geo" : { },
  "id_str" : "294196146841206785",
  "text" : "RT @skrashen: Gates' data collection project, the pitch and the reality: http:\/\/t.co\/7rYZxNRF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 79 ],
        "url" : "http:\/\/t.co\/7rYZxNRF",
        "expanded_url" : "http:\/\/www.susanohanian.org\/core.php?id=399",
        "display_url" : "susanohanian.org\/core.php?id=399"
      } ]
    },
    "geo" : { },
    "id_str" : "294169786445860864",
    "text" : "Gates' data collection project, the pitch and the reality: http:\/\/t.co\/7rYZxNRF",
    "id" : 294169786445860864,
    "created_at" : "2013-01-23 19:48:37 +0000",
    "user" : {
      "name" : "Stephen Krashen",
      "screen_name" : "skrashen",
      "protected" : false,
      "id_str" : "25624708",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/557399841769132032\/Ktp-bmWA_normal.jpeg",
      "id" : 25624708,
      "verified" : false
    }
  },
  "id" : 294196146841206785,
  "created_at" : "2013-01-23 21:33:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/NeAUYdi6",
      "expanded_url" : "http:\/\/wp.me\/p1Ayq4-3j",
      "display_url" : "wp.me\/p1Ayq4-3j"
    } ]
  },
  "geo" : { },
  "id_str" : "294192504159485952",
  "text" : "intriguing especially student created eng coursebk &gt;Let's write our own? http:\/\/t.co\/NeAUYdi6 via @divyabrochier",
  "id" : 294192504159485952,
  "created_at" : "2013-01-23 21:18:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 45, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "294190412820795392",
  "text" : "why do teacher want to become tchr trainers? #eltchat",
  "id" : 294190412820795392,
  "created_at" : "2013-01-23 21:10:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 20, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "294188995942957056",
  "text" : "here but lurking :) #eltchat",
  "id" : 294188995942957056,
  "created_at" : "2013-01-23 21:04:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 124, 140 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/bXBuBelS",
      "expanded_url" : "http:\/\/wp.me\/pLaO9-1ux",
      "display_url" : "wp.me\/pLaO9-1ux"
    } ]
  },
  "geo" : { },
  "id_str" : "294187615312297984",
  "text" : "nice approach &gt; Shadowing: a useful technique for autonomous practice of listening and speaking http:\/\/t.co\/bXBuBelS via @wordpressdotcom",
  "id" : 294187615312297984,
  "created_at" : "2013-01-23 20:59:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 91, 102 ],
      "id_str" : "282659955",
      "id" : 282659955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/LYvOUJQu",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-h2",
      "display_url" : "wp.me\/pgHyE-h2"
    } ]
  },
  "geo" : { },
  "id_str" : "294185992842264576",
  "text" : "new blog post Glittens, mini-narrow reading, collaborative writing http:\/\/t.co\/LYvOUJQu cc @teflerinha",
  "id" : 294185992842264576,
  "created_at" : "2013-01-23 20:53:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Mearns",
      "screen_name" : "davidmearns",
      "indices" : [ 0, 12 ],
      "id_str" : "30931681",
      "id" : 30931681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "293937109318897665",
  "geo" : { },
  "id_str" : "294185153167761409",
  "in_reply_to_user_id" : 30931681,
  "text" : "@davidmearns no plans for that mainly looking for some song based lessons",
  "id" : 294185153167761409,
  "in_reply_to_status_id" : 293937109318897665,
  "created_at" : "2013-01-23 20:49:40 +0000",
  "in_reply_to_screen_name" : "davidmearns",
  "in_reply_to_user_id_str" : "30931681",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "293915831715377153",
  "geo" : { },
  "id_str" : "294185009441558530",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt wotcha tyson, many thanks, hope u r keeping warm up there :)",
  "id" : 294185009441558530,
  "in_reply_to_status_id" : 293915831715377153,
  "created_at" : "2013-01-23 20:49:06 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/Frlyi4UO",
      "expanded_url" : "http:\/\/www.salford.ac.uk\/home-page\/news\/2012\/study-proves-classroom-design-really-does-matter",
      "display_url" : "salford.ac.uk\/home-page\/news\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "293838912319782913",
  "text" : "interesting pilot study on classroom design and learning http:\/\/t.co\/Frlyi4UO",
  "id" : 293838912319782913,
  "created_at" : "2013-01-22 21:53:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Mearns",
      "screen_name" : "davidmearns",
      "indices" : [ 0, 12 ],
      "id_str" : "30931681",
      "id" : 30931681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "293819217071964160",
  "geo" : { },
  "id_str" : "293821453793648640",
  "in_reply_to_user_id" : 30931681,
  "text" : "@davidmearns thanks, i see, its parody song.",
  "id" : 293821453793648640,
  "in_reply_to_status_id" : 293819217071964160,
  "created_at" : "2013-01-22 20:44:28 +0000",
  "in_reply_to_screen_name" : "davidmearns",
  "in_reply_to_user_id_str" : "30931681",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Mearns",
      "screen_name" : "davidmearns",
      "indices" : [ 0, 12 ],
      "id_str" : "30931681",
      "id" : 30931681
    }, {
      "name" : "Adam Simpson",
      "screen_name" : "yearinthelifeof",
      "indices" : [ 13, 29 ],
      "id_str" : "78543378",
      "id" : 78543378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "293764667178893313",
  "geo" : { },
  "id_str" : "293812706161602560",
  "in_reply_to_user_id" : 30931681,
  "text" : "@davidmearns @yearinthelifeof agh must.resist.urge to get on soapbox about mr bill i-do-a-lot-of-work-for-charidee gates :\/",
  "id" : 293812706161602560,
  "in_reply_to_status_id" : 293764667178893313,
  "created_at" : "2013-01-22 20:09:42 +0000",
  "in_reply_to_screen_name" : "davidmearns",
  "in_reply_to_user_id_str" : "30931681",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Mearns",
      "screen_name" : "davidmearns",
      "indices" : [ 0, 12 ],
      "id_str" : "30931681",
      "id" : 30931681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "293759440367271936",
  "geo" : { },
  "id_str" : "293811624727429120",
  "in_reply_to_user_id" : 30931681,
  "text" : "@davidmearns do u have separate link for video?",
  "id" : 293811624727429120,
  "in_reply_to_status_id" : 293759440367271936,
  "created_at" : "2013-01-22 20:05:24 +0000",
  "in_reply_to_screen_name" : "davidmearns",
  "in_reply_to_user_id_str" : "30931681",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Mearns",
      "screen_name" : "davidmearns",
      "indices" : [ 0, 12 ],
      "id_str" : "30931681",
      "id" : 30931681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "293731193088774144",
  "geo" : { },
  "id_str" : "293738436962177025",
  "in_reply_to_user_id" : 30931681,
  "text" : "@davidmearns thx but still don't see what the song is for craig ferguson twitter ppt?",
  "id" : 293738436962177025,
  "in_reply_to_status_id" : 293731193088774144,
  "created_at" : "2013-01-22 15:14:35 +0000",
  "in_reply_to_screen_name" : "davidmearns",
  "in_reply_to_user_id_str" : "30931681",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Mearns",
      "screen_name" : "davidmearns",
      "indices" : [ 0, 12 ],
      "id_str" : "30931681",
      "id" : 30931681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "293679140165545985",
  "geo" : { },
  "id_str" : "293679998706020352",
  "in_reply_to_user_id" : 30931681,
  "text" : "@davidmearns also what music video is Read by Tweets by Craig Ferguson? :)",
  "id" : 293679998706020352,
  "in_reply_to_status_id" : 293679140165545985,
  "created_at" : "2013-01-22 11:22:22 +0000",
  "in_reply_to_screen_name" : "davidmearns",
  "in_reply_to_user_id_str" : "30931681",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Mearns",
      "screen_name" : "davidmearns",
      "indices" : [ 0, 12 ],
      "id_str" : "30931681",
      "id" : 30931681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293675065147551745",
  "in_reply_to_user_id" : 30931681,
  "text" : "@davidmearns hi you seem to have uploaded video of virtual insanity and not ppt?",
  "id" : 293675065147551745,
  "created_at" : "2013-01-22 11:02:46 +0000",
  "in_reply_to_screen_name" : "davidmearns",
  "in_reply_to_user_id_str" : "30931681",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shelly Sanchez",
      "screen_name" : "ShellTerrell",
      "indices" : [ 3, 16 ],
      "id_str" : "29655018",
      "id" : 29655018
    }, {
      "name" : "John T. Spencer",
      "screen_name" : "JohnTSpencer",
      "indices" : [ 22, 35 ],
      "id_str" : "2285706270",
      "id" : 2285706270
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edreform",
      "indices" : [ 96, 105 ]
    }, {
      "text" : "edchat",
      "indices" : [ 106, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/ky7kBgpc",
      "expanded_url" : "http:\/\/bit.ly\/Sr8AX2",
      "display_url" : "bit.ly\/Sr8AX2"
    } ]
  },
  "geo" : { },
  "id_str" : "293641955995418624",
  "text" : "RT @ShellTerrell: via @johntspencer We Turned Dr. King into Tony the Tiger http:\/\/t.co\/ky7kBgpc #edreform #edchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John T. Spencer",
        "screen_name" : "JohnTSpencer",
        "indices" : [ 4, 17 ],
        "id_str" : "2285706270",
        "id" : 2285706270
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "edreform",
        "indices" : [ 78, 87 ]
      }, {
        "text" : "edchat",
        "indices" : [ 88, 95 ]
      } ],
      "urls" : [ {
        "indices" : [ 57, 77 ],
        "url" : "http:\/\/t.co\/ky7kBgpc",
        "expanded_url" : "http:\/\/bit.ly\/Sr8AX2",
        "display_url" : "bit.ly\/Sr8AX2"
      } ]
    },
    "geo" : { },
    "id_str" : "293391663731179521",
    "text" : "via @johntspencer We Turned Dr. King into Tony the Tiger http:\/\/t.co\/ky7kBgpc #edreform #edchat",
    "id" : 293391663731179521,
    "created_at" : "2013-01-21 16:16:38 +0000",
    "user" : {
      "name" : "Shelly Sanchez",
      "screen_name" : "ShellTerrell",
      "protected" : false,
      "id_str" : "29655018",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662819148330733568\/OOb7ol4U_normal.jpg",
      "id" : 29655018,
      "verified" : false
    }
  },
  "id" : 293641955995418624,
  "created_at" : "2013-01-22 08:51:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/QlJrq1wZ",
      "expanded_url" : "http:\/\/www.indymedia.org.uk\/en\/2013\/01\/505730.html",
      "display_url" : "indymedia.org.uk\/en\/2013\/01\/505\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "293295121846386688",
  "text" : "Hunger Strike in Parliament Square - day 25\nhttp:\/\/t.co\/QlJrq1wZ",
  "id" : 293295121846386688,
  "created_at" : "2013-01-21 09:53:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 3, 11 ],
      "id_str" : "20650366",
      "id" : 20650366
    }, {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 74, 90 ],
      "id_str" : "394053348",
      "id" : 394053348
    }, {
      "name" : "Vicky Loras",
      "screen_name" : "vickyloras",
      "indices" : [ 117, 128 ],
      "id_str" : "95957241",
      "id" : 95957241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/UCUGzWkV",
      "expanded_url" : "http:\/\/wp.me\/pIrrb-sQ",
      "display_url" : "wp.me\/pIrrb-sQ"
    } ]
  },
  "geo" : { },
  "id_str" : "293113438312464384",
  "text" : "RT @seburnt: Mike Griffin: Reflecting and Reviewing, But Not Ranting : ) (@michaelegriffin) http:\/\/t.co\/UCUGzWkV via @vickyloras",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Michael Griffin",
        "screen_name" : "michaelegriffin",
        "indices" : [ 61, 77 ],
        "id_str" : "394053348",
        "id" : 394053348
      }, {
        "name" : "Vicky Loras",
        "screen_name" : "vickyloras",
        "indices" : [ 104, 115 ],
        "id_str" : "95957241",
        "id" : 95957241
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 99 ],
        "url" : "http:\/\/t.co\/UCUGzWkV",
        "expanded_url" : "http:\/\/wp.me\/pIrrb-sQ",
        "display_url" : "wp.me\/pIrrb-sQ"
      } ]
    },
    "geo" : { },
    "id_str" : "293067042549006337",
    "text" : "Mike Griffin: Reflecting and Reviewing, But Not Ranting : ) (@michaelegriffin) http:\/\/t.co\/UCUGzWkV via @vickyloras",
    "id" : 293067042549006337,
    "created_at" : "2013-01-20 18:46:42 +0000",
    "user" : {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "protected" : false,
      "id_str" : "20650366",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/743248377563971584\/9d9xlHlz_normal.jpg",
      "id" : 20650366,
      "verified" : false
    }
  },
  "id" : 293113438312464384,
  "created_at" : "2013-01-20 21:51:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 3, 18 ],
      "id_str" : "20760283",
      "id" : 20760283
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 139, 140 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Dale Coulter",
      "screen_name" : "dalecoulter",
      "indices" : [ 139, 140 ],
      "id_str" : "24046458",
      "id" : 24046458
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 126, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 125 ],
      "url" : "https:\/\/t.co\/dLrzANZr",
      "expanded_url" : "https:\/\/plus.google.com\/communities\/111886923879644647270",
      "display_url" : "plus.google.com\/communities\/11\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "292953713713217536",
  "text" : "RT @MrChrisJWilson: Reminder of the Google+ hangout on feedback and error correction tonight at 6pm GMT https:\/\/t.co\/dLrzANZr #eltchat @ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mura Nava",
        "screen_name" : "muranava",
        "indices" : [ 115, 124 ],
        "id_str" : "18602422",
        "id" : 18602422
      }, {
        "name" : "Dale Coulter",
        "screen_name" : "dalecoulter",
        "indices" : [ 125, 137 ],
        "id_str" : "24046458",
        "id" : 24046458
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "eltchat",
        "indices" : [ 106, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 105 ],
        "url" : "https:\/\/t.co\/dLrzANZr",
        "expanded_url" : "https:\/\/plus.google.com\/communities\/111886923879644647270",
        "display_url" : "plus.google.com\/communities\/11\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "292939909159870465",
    "text" : "Reminder of the Google+ hangout on feedback and error correction tonight at 6pm GMT https:\/\/t.co\/dLrzANZr #eltchat @muranava @dalecoulter",
    "id" : 292939909159870465,
    "created_at" : "2013-01-20 10:21:31 +0000",
    "user" : {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "protected" : false,
      "id_str" : "20760283",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744952885595758592\/H4bmsUn3_normal.jpg",
      "id" : 20760283,
      "verified" : false
    }
  },
  "id" : 292953713713217536,
  "created_at" : "2013-01-20 11:16:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "c m kerr",
      "screen_name" : "KerrCarolyn",
      "indices" : [ 3, 15 ],
      "id_str" : "468676296",
      "id" : 468676296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/2UvQOdAG",
      "expanded_url" : "http:\/\/wp.me\/p2VvHi-4J",
      "display_url" : "wp.me\/p2VvHi-4J"
    } ]
  },
  "geo" : { },
  "id_str" : "292951647582302208",
  "text" : "RT @KerrCarolyn: How can color affect how you read? Part 2 on reading and the brain http:\/\/t.co\/2UvQOdAG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 87 ],
        "url" : "http:\/\/t.co\/2UvQOdAG",
        "expanded_url" : "http:\/\/wp.me\/p2VvHi-4J",
        "display_url" : "wp.me\/p2VvHi-4J"
      } ]
    },
    "geo" : { },
    "id_str" : "292586960223088640",
    "text" : "How can color affect how you read? Part 2 on reading and the brain http:\/\/t.co\/2UvQOdAG",
    "id" : 292586960223088640,
    "created_at" : "2013-01-19 10:59:01 +0000",
    "user" : {
      "name" : "c m kerr",
      "screen_name" : "KerrCarolyn",
      "protected" : false,
      "id_str" : "468676296",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2152968032\/image_normal.jpg",
      "id" : 468676296,
      "verified" : false
    }
  },
  "id" : 292951647582302208,
  "created_at" : "2013-01-20 11:08:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 3, 14 ],
      "id_str" : "282659955",
      "id" : 282659955
    }, {
      "name" : "Hancock McDonald ELT",
      "screen_name" : "HancockMcDonald",
      "indices" : [ 78, 94 ],
      "id_str" : "552929354",
      "id" : 552929354
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/zFSMhZcG",
      "expanded_url" : "http:\/\/tinyurl.com\/b3x5n45",
      "display_url" : "tinyurl.com\/b3x5n45"
    } ]
  },
  "geo" : { },
  "id_str" : "292403559302053889",
  "text" : "RT @teflerinha: Using teacher feedback to drive learning http:\/\/t.co\/zFSMhZcG @hancockmcdonald",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hancock McDonald ELT",
        "screen_name" : "HancockMcDonald",
        "indices" : [ 62, 78 ],
        "id_str" : "552929354",
        "id" : 552929354
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 61 ],
        "url" : "http:\/\/t.co\/zFSMhZcG",
        "expanded_url" : "http:\/\/tinyurl.com\/b3x5n45",
        "display_url" : "tinyurl.com\/b3x5n45"
      } ]
    },
    "geo" : { },
    "id_str" : "292346684653047808",
    "text" : "Using teacher feedback to drive learning http:\/\/t.co\/zFSMhZcG @hancockmcdonald",
    "id" : 292346684653047808,
    "created_at" : "2013-01-18 19:04:15 +0000",
    "user" : {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "protected" : false,
      "id_str" : "282659955",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2149898907\/Rachael_Roberts_headshot_square_normal.jpg",
      "id" : 282659955,
      "verified" : false
    }
  },
  "id" : 292403559302053889,
  "created_at" : "2013-01-18 22:50:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/f6iJmw0V",
      "expanded_url" : "http:\/\/www.newint.org\/features\/2012\/12\/01\/us-terrorism-sahara\/",
      "display_url" : "newint.org\/features\/2012\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "292399499811377152",
  "text" : "How Washington helped foster the Islamist uprising in Mali\nhttp:\/\/t.co\/f6iJmw0V",
  "id" : 292399499811377152,
  "created_at" : "2013-01-18 22:34:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/MrRf0IL3",
      "expanded_url" : "http:\/\/www.xbmcandroid.com\/2013\/01\/17\/introducing-the-first-end-user-friendly-release-of-xbmc-for-android-must-have\/",
      "display_url" : "xbmcandroid.com\/2013\/01\/17\/int\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "292271578857734144",
  "text" : "latest XBMC build for andorid is neat http:\/\/t.co\/MrRf0IL3",
  "id" : 292271578857734144,
  "created_at" : "2013-01-18 14:05:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate Bowles",
      "screen_name" : "KateMfD",
      "indices" : [ 105, 113 ],
      "id_str" : "379065166",
      "id" : 379065166
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/sVKzJlTY",
      "expanded_url" : "http:\/\/wp.me\/p1tYEb-Bg",
      "display_url" : "wp.me\/p1tYEb-Bg"
    } ]
  },
  "geo" : { },
  "id_str" : "292256092715638785",
  "text" : "very nice and topical cycling metaphor for online courses &gt; In the grupetto http:\/\/t.co\/sVKzJlTY via @@KateMfD",
  "id" : 292256092715638785,
  "created_at" : "2013-01-18 13:04:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 3, 16 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "efl",
      "indices" : [ 77, 81 ]
    }, {
      "text" : "esl",
      "indices" : [ 82, 86 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 87, 95 ]
    }, {
      "text" : "edchat",
      "indices" : [ 96, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/c7AKVEt0",
      "expanded_url" : "http:\/\/wp.me\/pKFOt-aQ",
      "display_url" : "wp.me\/pKFOt-aQ"
    } ]
  },
  "geo" : { },
  "id_str" : "292250893452210176",
  "text" : "RT @rosemerebard: What I expect to happen in my classes http:\/\/t.co\/c7AKVEt0 #efl #esl #eltchat #edchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "efl",
        "indices" : [ 59, 63 ]
      }, {
        "text" : "esl",
        "indices" : [ 64, 68 ]
      }, {
        "text" : "eltchat",
        "indices" : [ 69, 77 ]
      }, {
        "text" : "edchat",
        "indices" : [ 78, 85 ]
      } ],
      "urls" : [ {
        "indices" : [ 38, 58 ],
        "url" : "http:\/\/t.co\/c7AKVEt0",
        "expanded_url" : "http:\/\/wp.me\/pKFOt-aQ",
        "display_url" : "wp.me\/pKFOt-aQ"
      } ]
    },
    "geo" : { },
    "id_str" : "291972299937161216",
    "text" : "What I expect to happen in my classes http:\/\/t.co\/c7AKVEt0 #efl #esl #eltchat #edchat",
    "id" : 291972299937161216,
    "created_at" : "2013-01-17 18:16:35 +0000",
    "user" : {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "protected" : false,
      "id_str" : "88655243",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/706508144160145410\/pKzknb5H_normal.jpg",
      "id" : 88655243,
      "verified" : false
    }
  },
  "id" : 292250893452210176,
  "created_at" : "2013-01-18 12:43:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/CH5AavKj",
      "expanded_url" : "http:\/\/tedxcaltech.com\/speakers",
      "display_url" : "tedxcaltech.com\/speakers"
    } ]
  },
  "geo" : { },
  "id_str" : "292249907866243073",
  "text" : "http:\/\/t.co\/CH5AavKj might be interesting...",
  "id" : 292249907866243073,
  "created_at" : "2013-01-18 12:39:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    }, {
      "name" : "Willy C. Cardoso",
      "screen_name" : "willycard",
      "indices" : [ 49, 59 ],
      "id_str" : "102353142",
      "id" : 102353142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/XbClWJp6",
      "expanded_url" : "http:\/\/keepitrealemma.wordpress.com\/2013\/01\/16\/praise-be-not-so-good",
      "display_url" : "keepitrealemma.wordpress.com\/2013\/01\/16\/pra\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "292237345598611456",
  "geo" : { },
  "id_str" : "292239507066064896",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson this one http:\/\/t.co\/XbClWJp6 HT @willycard",
  "id" : 292239507066064896,
  "in_reply_to_status_id" : 292237345598611456,
  "created_at" : "2013-01-18 11:58:22 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "royan lee",
      "screen_name" : "royanlee",
      "indices" : [ 3, 12 ],
      "id_str" : "30651485",
      "id" : 30651485
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/YFBUJWPn",
      "expanded_url" : "http:\/\/bit.ly\/Ycg1V7",
      "display_url" : "bit.ly\/Ycg1V7"
    } ]
  },
  "geo" : { },
  "id_str" : "292228916163276800",
  "text" : "RT @royanlee: minimalism is simple http:\/\/t.co\/YFBUJWPn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 21, 41 ],
        "url" : "http:\/\/t.co\/YFBUJWPn",
        "expanded_url" : "http:\/\/bit.ly\/Ycg1V7",
        "display_url" : "bit.ly\/Ycg1V7"
      } ]
    },
    "geo" : { },
    "id_str" : "292050791575998464",
    "text" : "minimalism is simple http:\/\/t.co\/YFBUJWPn",
    "id" : 292050791575998464,
    "created_at" : "2013-01-17 23:28:29 +0000",
    "user" : {
      "name" : "royan lee",
      "screen_name" : "royanlee",
      "protected" : false,
      "id_str" : "30651485",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/677974536827064320\/djEgh5IC_normal.jpg",
      "id" : 30651485,
      "verified" : false
    }
  },
  "id" : 292228916163276800,
  "created_at" : "2013-01-18 11:16:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "evanfrendo",
      "screen_name" : "evanfrendo",
      "indices" : [ 3, 14 ],
      "id_str" : "17589664",
      "id" : 17589664
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "besig",
      "indices" : [ 86, 92 ]
    }, {
      "text" : "tefl",
      "indices" : [ 93, 98 ]
    }, {
      "text" : "elt",
      "indices" : [ 99, 103 ]
    }, {
      "text" : "tesol",
      "indices" : [ 104, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/3jlIkVUs",
      "expanded_url" : "http:\/\/bit.ly\/Xhlmno",
      "display_url" : "bit.ly\/Xhlmno"
    } ]
  },
  "geo" : { },
  "id_str" : "292220725778063361",
  "text" : "RT @evanfrendo: Latest issue of Asian ESP Journal now online at  http:\/\/t.co\/3jlIkVUs #besig #tefl #elt #tesol",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "besig",
        "indices" : [ 70, 76 ]
      }, {
        "text" : "tefl",
        "indices" : [ 77, 82 ]
      }, {
        "text" : "elt",
        "indices" : [ 83, 87 ]
      }, {
        "text" : "tesol",
        "indices" : [ 88, 94 ]
      } ],
      "urls" : [ {
        "indices" : [ 49, 69 ],
        "url" : "http:\/\/t.co\/3jlIkVUs",
        "expanded_url" : "http:\/\/bit.ly\/Xhlmno",
        "display_url" : "bit.ly\/Xhlmno"
      } ]
    },
    "geo" : { },
    "id_str" : "292218260370366465",
    "text" : "Latest issue of Asian ESP Journal now online at  http:\/\/t.co\/3jlIkVUs #besig #tefl #elt #tesol",
    "id" : 292218260370366465,
    "created_at" : "2013-01-18 10:33:57 +0000",
    "user" : {
      "name" : "evanfrendo",
      "screen_name" : "evanfrendo",
      "protected" : false,
      "id_str" : "17589664",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1267172323\/Evan_Frendo_normal.jpg",
      "id" : 17589664,
      "verified" : false
    }
  },
  "id" : 292220725778063361,
  "created_at" : "2013-01-18 10:43:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth Anne",
      "screen_name" : "eannegrenoble",
      "indices" : [ 0, 14 ],
      "id_str" : "19869781",
      "id" : 19869781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "292205295856390144",
  "geo" : { },
  "id_str" : "292209706582306816",
  "in_reply_to_user_id" : 19869781,
  "text" : "@eannegrenoble glad u find it useful :)",
  "id" : 292209706582306816,
  "in_reply_to_status_id" : 292205295856390144,
  "created_at" : "2013-01-18 09:59:57 +0000",
  "in_reply_to_screen_name" : "eannegrenoble",
  "in_reply_to_user_id_str" : "19869781",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HappyBirthdayLP",
      "indices" : [ 44, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http:\/\/t.co\/akG1dwq3",
      "expanded_url" : "http:\/\/thelanguagepoint.com\/english_collections\/show\/Tips%2521_Simple_Classroom_Activities",
      "display_url" : "thelanguagepoint.com\/english_collec\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "292208391101755392",
  "text" : "Speaking activities&gt;http:\/\/t.co\/akG1dwq3 #HappyBirthdayLP",
  "id" : 292208391101755392,
  "created_at" : "2013-01-18 09:54:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth Anne",
      "screen_name" : "eannegrenoble",
      "indices" : [ 0, 14 ],
      "id_str" : "19869781",
      "id" : 19869781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/BU3u1zLK",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-7a",
      "display_url" : "wp.me\/pgHyE-7a"
    } ]
  },
  "in_reply_to_status_id_str" : "292191949383929856",
  "geo" : { },
  "id_str" : "292199121157234688",
  "in_reply_to_user_id" : 19869781,
  "text" : "@eannegrenoble glad u sorted it, wrote a post on some precautions u can take http:\/\/t.co\/BU3u1zLK",
  "id" : 292199121157234688,
  "in_reply_to_status_id" : 292191949383929856,
  "created_at" : "2013-01-18 09:17:53 +0000",
  "in_reply_to_screen_name" : "eannegrenoble",
  "in_reply_to_user_id_str" : "19869781",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 38 ],
      "url" : "http:\/\/t.co\/DsZYnpTJ",
      "expanded_url" : "http:\/\/ceasefiremagazine.co.uk\/blood-uranium-frances-mali-intervention-terrorism\/",
      "display_url" : "ceasefiremagazine.co.uk\/blood-uranium-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "292046590854705152",
  "text" : "Blood for Uranium http:\/\/t.co\/DsZYnpTJ",
  "id" : 292046590854705152,
  "created_at" : "2013-01-17 23:11:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Mearns",
      "screen_name" : "davidmearns",
      "indices" : [ 0, 12 ],
      "id_str" : "30931681",
      "id" : 30931681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "292017101332434946",
  "geo" : { },
  "id_str" : "292017747657900033",
  "in_reply_to_user_id" : 30931681,
  "text" : "@davidmearns will do.",
  "id" : 292017747657900033,
  "in_reply_to_status_id" : 292017101332434946,
  "created_at" : "2013-01-17 21:17:11 +0000",
  "in_reply_to_screen_name" : "davidmearns",
  "in_reply_to_user_id_str" : "30931681",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Mearns",
      "screen_name" : "davidmearns",
      "indices" : [ 0, 12 ],
      "id_str" : "30931681",
      "id" : 30931681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "292013696497119233",
  "geo" : { },
  "id_str" : "292015745523658752",
  "in_reply_to_user_id" : 30931681,
  "text" : "@davidmearns doh! thks",
  "id" : 292015745523658752,
  "in_reply_to_status_id" : 292013696497119233,
  "created_at" : "2013-01-17 21:09:13 +0000",
  "in_reply_to_screen_name" : "davidmearns",
  "in_reply_to_user_id_str" : "30931681",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Mearns",
      "screen_name" : "davidmearns",
      "indices" : [ 0, 12 ],
      "id_str" : "30931681",
      "id" : 30931681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "292012110643331072",
  "geo" : { },
  "id_str" : "292013011953143808",
  "in_reply_to_user_id" : 30931681,
  "text" : "@davidmearns 50 thats a good number, what kind of styles\/periods of songs does that include?",
  "id" : 292013011953143808,
  "in_reply_to_status_id" : 292012110643331072,
  "created_at" : "2013-01-17 20:58:22 +0000",
  "in_reply_to_screen_name" : "davidmearns",
  "in_reply_to_user_id_str" : "30931681",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Mearns",
      "screen_name" : "davidmearns",
      "indices" : [ 0, 12 ],
      "id_str" : "30931681",
      "id" : 30931681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291975042319917056",
  "geo" : { },
  "id_str" : "292011502838362112",
  "in_reply_to_user_id" : 30931681,
  "text" : "@davidmearns nice approach though finding a song that sts are into and nice theme is difficult",
  "id" : 292011502838362112,
  "in_reply_to_status_id" : 291975042319917056,
  "created_at" : "2013-01-17 20:52:22 +0000",
  "in_reply_to_screen_name" : "davidmearns",
  "in_reply_to_user_id_str" : "30931681",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Mearns",
      "screen_name" : "davidmearns",
      "indices" : [ 3, 15 ],
      "id_str" : "30931681",
      "id" : 30931681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/IbTuTWkg",
      "expanded_url" : "http:\/\/davidmearns.blogspot.com\/2013\/01\/watch-listen-and-tell-speaking-activity.html?spref=tw",
      "display_url" : "davidmearns.blogspot.com\/2013\/01\/watch-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "292011119613181952",
  "text" : "RT @davidmearns: BRENTSON RAMSEY'S NEW POST: Adopt and Adapt ICT- ELT: Watch, Listen and Tell: A Speaking Activity http:\/\/t.co\/IbTuTWkg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 118 ],
        "url" : "http:\/\/t.co\/IbTuTWkg",
        "expanded_url" : "http:\/\/davidmearns.blogspot.com\/2013\/01\/watch-listen-and-tell-speaking-activity.html?spref=tw",
        "display_url" : "davidmearns.blogspot.com\/2013\/01\/watch-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "291975152898547712",
    "text" : "BRENTSON RAMSEY'S NEW POST: Adopt and Adapt ICT- ELT: Watch, Listen and Tell: A Speaking Activity http:\/\/t.co\/IbTuTWkg",
    "id" : 291975152898547712,
    "created_at" : "2013-01-17 18:27:55 +0000",
    "user" : {
      "name" : "David Mearns",
      "screen_name" : "davidmearns",
      "protected" : true,
      "id_str" : "30931681",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703310502659751936\/MF_hJF-m_normal.jpg",
      "id" : 30931681,
      "verified" : false
    }
  },
  "id" : 292011119613181952,
  "created_at" : "2013-01-17 20:50:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Mearns",
      "screen_name" : "davidmearns",
      "indices" : [ 3, 15 ],
      "id_str" : "30931681",
      "id" : 30931681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/fiWJ08FY",
      "expanded_url" : "http:\/\/davidmearns.blogspot.com\/2013\/01\/music-videos-are-much-more-than-just.html?spref=tw",
      "display_url" : "davidmearns.blogspot.com\/2013\/01\/music-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "292010315204415489",
  "text" : "RT @davidmearns: DAVID MEARNS NEW POST: Adopt and Adapt ICT- ELT: Music-Videos are Much More Than Just the Lyrics http:\/\/t.co\/fiWJ08FY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 117 ],
        "url" : "http:\/\/t.co\/fiWJ08FY",
        "expanded_url" : "http:\/\/davidmearns.blogspot.com\/2013\/01\/music-videos-are-much-more-than-just.html?spref=tw",
        "display_url" : "davidmearns.blogspot.com\/2013\/01\/music-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "291975042319917056",
    "text" : "DAVID MEARNS NEW POST: Adopt and Adapt ICT- ELT: Music-Videos are Much More Than Just the Lyrics http:\/\/t.co\/fiWJ08FY",
    "id" : 291975042319917056,
    "created_at" : "2013-01-17 18:27:29 +0000",
    "user" : {
      "name" : "David Mearns",
      "screen_name" : "davidmearns",
      "protected" : true,
      "id_str" : "30931681",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703310502659751936\/MF_hJF-m_normal.jpg",
      "id" : 30931681,
      "verified" : false
    }
  },
  "id" : 292010315204415489,
  "created_at" : "2013-01-17 20:47:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 78, 93 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/Pz0HjrNR",
      "expanded_url" : "http:\/\/www.eltsquared.co.uk\/the-parable-of-the-rubik-cube\/",
      "display_url" : "eltsquared.co.uk\/the-parable-of\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "292007731806752768",
  "text" : "can you solve?&gt;The parable of the rubik's cube. http:\/\/t.co\/Pz0HjrNR \u2026 via @MrChrisJWilson",
  "id" : 292007731806752768,
  "created_at" : "2013-01-17 20:37:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Timothy Tate",
      "screen_name" : "Timothy_Tate",
      "indices" : [ 0, 13 ],
      "id_str" : "1084531170",
      "id" : 1084531170
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291923207785680896",
  "geo" : { },
  "id_str" : "291923832879607811",
  "in_reply_to_user_id" : 1084531170,
  "text" : "@Timothy_Tate hehe yeah 'quant of assoc joy' should be an added filter to BYU corpus :)",
  "id" : 291923832879607811,
  "in_reply_to_status_id" : 291923207785680896,
  "created_at" : "2013-01-17 15:04:00 +0000",
  "in_reply_to_screen_name" : "Timothy_Tate",
  "in_reply_to_user_id_str" : "1084531170",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Timothy Tate",
      "screen_name" : "Timothy_Tate",
      "indices" : [ 0, 13 ],
      "id_str" : "1084531170",
      "id" : 1084531170
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/nCX5kBlF",
      "expanded_url" : "http:\/\/corpus.byu.edu\/coca\/?c=coca&q=20510275",
      "display_url" : "corpus.byu.edu\/coca\/?c=coca&q\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "291922139341262848",
  "in_reply_to_user_id" : 1084531170,
  "text" : "@Timothy_Tate ample is a nice adj, and bosom does indeed rank higher than parking but not as much as evidence http:\/\/t.co\/nCX5kBlF",
  "id" : 291922139341262848,
  "created_at" : "2013-01-17 14:57:16 +0000",
  "in_reply_to_screen_name" : "Timothy_Tate",
  "in_reply_to_user_id_str" : "1084531170",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Timothy Tate",
      "screen_name" : "Timothy_Tate",
      "indices" : [ 0, 13 ],
      "id_str" : "1084531170",
      "id" : 1084531170
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291918950365790208",
  "geo" : { },
  "id_str" : "291920328156909568",
  "in_reply_to_user_id" : 1084531170,
  "text" : "@Timothy_Tate hmm wonder what disabled\/free\/limited\/no parking brings to mind :?",
  "id" : 291920328156909568,
  "in_reply_to_status_id" : 291918950365790208,
  "created_at" : "2013-01-17 14:50:04 +0000",
  "in_reply_to_screen_name" : "Timothy_Tate",
  "in_reply_to_user_id_str" : "1084531170",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gareth davies",
      "screen_name" : "reasons4",
      "indices" : [ 0, 9 ],
      "id_str" : "413454135",
      "id" : 413454135
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291912202619854848",
  "geo" : { },
  "id_str" : "291919651489869824",
  "in_reply_to_user_id" : 413454135,
  "text" : "@reasons4 good stuff enjoyed coldplay, lift story, top of the pops :)",
  "id" : 291919651489869824,
  "in_reply_to_status_id" : 291912202619854848,
  "created_at" : "2013-01-17 14:47:23 +0000",
  "in_reply_to_screen_name" : "reasons4",
  "in_reply_to_user_id_str" : "413454135",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gareth davies",
      "screen_name" : "reasons4",
      "indices" : [ 3, 12 ],
      "id_str" : "413454135",
      "id" : 413454135
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "shortstory",
      "indices" : [ 21, 32 ]
    }, {
      "text" : "fiction",
      "indices" : [ 115, 123 ]
    }, {
      "text" : "writing",
      "indices" : [ 124, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/6fMl5WoA",
      "expanded_url" : "http:\/\/garethsrorystorycubes.blogspot.co.uk\/",
      "display_url" : "garethsrorystorycubes.blogspot.co.uk"
    } ]
  },
  "geo" : { },
  "id_str" : "291919442550611968",
  "text" : "RT @reasons4: No new #shortstory today o a chance to catch up on stories you may have missed. http:\/\/t.co\/6fMl5WoA #fiction #writing",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "shortstory",
        "indices" : [ 7, 18 ]
      }, {
        "text" : "fiction",
        "indices" : [ 101, 109 ]
      }, {
        "text" : "writing",
        "indices" : [ 110, 118 ]
      } ],
      "urls" : [ {
        "indices" : [ 80, 100 ],
        "url" : "http:\/\/t.co\/6fMl5WoA",
        "expanded_url" : "http:\/\/garethsrorystorycubes.blogspot.co.uk\/",
        "display_url" : "garethsrorystorycubes.blogspot.co.uk"
      } ]
    },
    "geo" : { },
    "id_str" : "291912202619854848",
    "text" : "No new #shortstory today o a chance to catch up on stories you may have missed. http:\/\/t.co\/6fMl5WoA #fiction #writing",
    "id" : 291912202619854848,
    "created_at" : "2013-01-17 14:17:47 +0000",
    "user" : {
      "name" : "gareth davies",
      "screen_name" : "reasons4",
      "protected" : false,
      "id_str" : "413454135",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1640992210\/image_normal.jpg",
      "id" : 413454135,
      "verified" : false
    }
  },
  "id" : 291919442550611968,
  "created_at" : "2013-01-17 14:46:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "indices" : [ 0, 10 ],
      "id_str" : "19725644",
      "id" : 19725644
    }, {
      "name" : "Timothy Tate",
      "screen_name" : "Timothy_Tate",
      "indices" : [ 11, 24 ],
      "id_str" : "1084531170",
      "id" : 1084531170
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291562956657938434",
  "geo" : { },
  "id_str" : "291890129671438337",
  "in_reply_to_user_id" : 19725644,
  "text" : "@neiltyson @Timothy_Tate which is worse getting stuck in a lift or in a wormhole?",
  "id" : 291890129671438337,
  "in_reply_to_status_id" : 291562956657938434,
  "created_at" : "2013-01-17 12:50:04 +0000",
  "in_reply_to_screen_name" : "neiltyson",
  "in_reply_to_user_id_str" : "19725644",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0414\u0438\u0430\u043D\u043A\u0430 \u0428\u043A\u0443\u0440\u0441\u043A\u0430\u044F",
      "screen_name" : "TheSecretDoS",
      "indices" : [ 0, 13 ],
      "id_str" : "440292980",
      "id" : 440292980
    }, {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 14, 30 ],
      "id_str" : "394053348",
      "id" : 394053348
    }, {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 31, 37 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291882994178863104",
  "text" : "@TheSecretDoS @michaelegriffin @EBEFL if he's lucky",
  "id" : 291882994178863104,
  "created_at" : "2013-01-17 12:21:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    }, {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 7, 23 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291877871025262592",
  "text" : "@EBEFL @michaelegriffin indeed Demand-Why-so-serious posts :)",
  "id" : 291877871025262592,
  "created_at" : "2013-01-17 12:01:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 0, 13 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291674524414509056",
  "geo" : { },
  "id_str" : "291675112095248384",
  "in_reply_to_user_id" : 88655243,
  "text" : "@rosemerebard true, one can but hope to get on a virtuous cycle of thinking\/doing",
  "id" : 291675112095248384,
  "in_reply_to_status_id" : 291674524414509056,
  "created_at" : "2013-01-16 22:35:40 +0000",
  "in_reply_to_screen_name" : "rosemerebard",
  "in_reply_to_user_id_str" : "88655243",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 0, 13 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 45, 53 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291670329758195713",
  "geo" : { },
  "id_str" : "291673857864130561",
  "in_reply_to_user_id" : 88655243,
  "text" : "@rosemerebard the thinking it's neverending! #eltchat",
  "id" : 291673857864130561,
  "in_reply_to_status_id" : 291670329758195713,
  "created_at" : "2013-01-16 22:30:41 +0000",
  "in_reply_to_screen_name" : "rosemerebard",
  "in_reply_to_user_id_str" : "88655243",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheLanguagePoint",
      "screen_name" : "Marie_Sanako",
      "indices" : [ 3, 16 ],
      "id_str" : "356176087",
      "id" : 356176087
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HappyBirthdayLP",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/XiftqaNy",
      "expanded_url" : "http:\/\/bit.ly\/ZWTpU3",
      "display_url" : "bit.ly\/ZWTpU3"
    } ]
  },
  "geo" : { },
  "id_str" : "291673561767215104",
  "text" : "RT @Marie_Sanako: Celebrate our 1st b\/day with us &amp; win! Tweet link to your favourite LanguagePoint resource &amp; include #HappyBir ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HappyBirthdayLP",
        "indices" : [ 109, 125 ]
      } ],
      "urls" : [ {
        "indices" : [ 127, 147 ],
        "url" : "http:\/\/t.co\/XiftqaNy",
        "expanded_url" : "http:\/\/bit.ly\/ZWTpU3",
        "display_url" : "bit.ly\/ZWTpU3"
      } ]
    },
    "geo" : { },
    "id_str" : "291671172221923328",
    "text" : "Celebrate our 1st b\/day with us &amp; win! Tweet link to your favourite LanguagePoint resource &amp; include #HappyBirthdayLP! http:\/\/t.co\/XiftqaNy",
    "id" : 291671172221923328,
    "created_at" : "2013-01-16 22:20:01 +0000",
    "user" : {
      "name" : "TheLanguagePoint",
      "screen_name" : "Marie_Sanako",
      "protected" : false,
      "id_str" : "356176087",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1810381097\/lpcombined_normal.jpg",
      "id" : 356176087,
      "verified" : false
    }
  },
  "id" : 291673561767215104,
  "created_at" : "2013-01-16 22:29:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Batu",
      "screen_name" : "imadruid",
      "indices" : [ 0, 9 ],
      "id_str" : "766054177407660033",
      "id" : 766054177407660033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 84, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291666948385820672",
  "text" : "@Imadruid hehe being eclectic in music tastes is good maybe not so for teaching? :) #eltchat",
  "id" : 291666948385820672,
  "created_at" : "2013-01-16 22:03:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 41, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291666620127010816",
  "text" : "a lot to think about as usual folks, ta! #eltchat",
  "id" : 291666620127010816,
  "created_at" : "2013-01-16 22:01:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaunwilden",
      "screen_name" : "Shaunwilden",
      "indices" : [ 0, 12 ],
      "id_str" : "15350512",
      "id" : 15350512
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 82, 90 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291661767535362048",
  "geo" : { },
  "id_str" : "291662444923846657",
  "in_reply_to_user_id" : 15350512,
  "text" : "@Shaunwilden yes, was thinking of the monks, will DHT\/Dogme give us good beer? ;) #eltchat",
  "id" : 291662444923846657,
  "in_reply_to_status_id" : 291661767535362048,
  "created_at" : "2013-01-16 21:45:20 +0000",
  "in_reply_to_screen_name" : "Shaunwilden",
  "in_reply_to_user_id_str" : "15350512",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 62, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291661565923557376",
  "text" : "weren't earlier ways like grammar translation demand high? ;) #eltchat",
  "id" : 291661565923557376,
  "created_at" : "2013-01-16 21:41:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "c m kerr",
      "screen_name" : "KerrCarolyn",
      "indices" : [ 0, 12 ],
      "id_str" : "468676296",
      "id" : 468676296
    }, {
      "name" : "Steve Gallagher",
      "screen_name" : "stiiv",
      "indices" : [ 50, 56 ],
      "id_str" : "24408597",
      "id" : 24408597
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 78, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/0kFDqaPP",
      "expanded_url" : "http:\/\/theteapingpoint.wordpress.com\/2013\/01\/06\/demand-high-eap\/",
      "display_url" : "theteapingpoint.wordpress.com\/2013\/01\/06\/dem\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "291658483563126784",
  "geo" : { },
  "id_str" : "291659637734924288",
  "in_reply_to_user_id" : 468676296,
  "text" : "@KerrCarolyn reminder of importance of content by @stiiv http:\/\/t.co\/0kFDqaPP #eltchat",
  "id" : 291659637734924288,
  "in_reply_to_status_id" : 291658483563126784,
  "created_at" : "2013-01-16 21:34:11 +0000",
  "in_reply_to_screen_name" : "KerrCarolyn",
  "in_reply_to_user_id_str" : "468676296",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 73, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291656384238481408",
  "text" : "i wonder how many EAP or ESP lessons the demand high guys have observed? #eltchat",
  "id" : 291656384238481408,
  "created_at" : "2013-01-16 21:21:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheLanguagePoint",
      "screen_name" : "Marie_Sanako",
      "indices" : [ 0, 13 ],
      "id_str" : "356176087",
      "id" : 356176087
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291564820925390848",
  "geo" : { },
  "id_str" : "291567265705496576",
  "in_reply_to_user_id" : 356176087,
  "text" : "@Marie_Sanako i think my favourite is 'getting environmental problems in my territory' :)",
  "id" : 291567265705496576,
  "in_reply_to_status_id" : 291564820925390848,
  "created_at" : "2013-01-16 15:27:07 +0000",
  "in_reply_to_screen_name" : "Marie_Sanako",
  "in_reply_to_user_id_str" : "356176087",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheLanguagePoint",
      "screen_name" : "Marie_Sanako",
      "indices" : [ 3, 16 ],
      "id_str" : "356176087",
      "id" : 356176087
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/DKpP2f5j",
      "expanded_url" : "http:\/\/newsradio1310.com\/hear-the-fresh-prince-of-bel-air-theme-translated-into-multiple-languages\/",
      "display_url" : "newsradio1310.com\/hear-the-fresh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "291567086130577408",
  "text" : "RT @Marie_Sanako: \u2018Fresh Prince of Bel-Air\u2019 theme put through every language in Google Translate before translating it back to English h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/DKpP2f5j",
        "expanded_url" : "http:\/\/newsradio1310.com\/hear-the-fresh-prince-of-bel-air-theme-translated-into-multiple-languages\/",
        "display_url" : "newsradio1310.com\/hear-the-fresh\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "291564820925390848",
    "text" : "\u2018Fresh Prince of Bel-Air\u2019 theme put through every language in Google Translate before translating it back to English http:\/\/t.co\/DKpP2f5j",
    "id" : 291564820925390848,
    "created_at" : "2013-01-16 15:17:24 +0000",
    "user" : {
      "name" : "TheLanguagePoint",
      "screen_name" : "Marie_Sanako",
      "protected" : false,
      "id_str" : "356176087",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1810381097\/lpcombined_normal.jpg",
      "id" : 356176087,
      "verified" : false
    }
  },
  "id" : 291567086130577408,
  "created_at" : "2013-01-16 15:26:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 3, 14 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/WwpsniZ6",
      "expanded_url" : "http:\/\/theotherthingsmatter.blogspot.jp\/p\/short-fiction-for-ells-ii_16.html",
      "display_url" : "theotherthingsmatter.blogspot.jp\/p\/short-fictio\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "291565299579359233",
  "text" : "RT @kevchanwow: I got some great positive reinforcement so I put my last 4 stories for lang. learners together on one handy dandy page:  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/WwpsniZ6",
        "expanded_url" : "http:\/\/theotherthingsmatter.blogspot.jp\/p\/short-fiction-for-ells-ii_16.html",
        "display_url" : "theotherthingsmatter.blogspot.jp\/p\/short-fictio\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "291546381632548865",
    "text" : "I got some great positive reinforcement so I put my last 4 stories for lang. learners together on one handy dandy page: http:\/\/t.co\/WwpsniZ6",
    "id" : 291546381632548865,
    "created_at" : "2013-01-16 14:04:08 +0000",
    "user" : {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "protected" : false,
      "id_str" : "144663117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/559618421839507456\/nPF7dP47_normal.jpeg",
      "id" : 144663117,
      "verified" : false
    }
  },
  "id" : 291565299579359233,
  "created_at" : "2013-01-16 15:19:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/8gsL54Pv",
      "expanded_url" : "http:\/\/www.brianhaw.tv\/index.php\/blog\/1379-hunger-strike-day-21-366-days-without-shelter",
      "display_url" : "brianhaw.tv\/index.php\/blog\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "291488719146463234",
  "text" : "Barbara Tucker hunger strike in Parliament Square at 3 weeks http:\/\/t.co\/8gsL54Pv",
  "id" : 291488719146463234,
  "created_at" : "2013-01-16 10:15:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MarisaConstantinides",
      "screen_name" : "Marisa_C",
      "indices" : [ 3, 12 ],
      "id_str" : "18272500",
      "id" : 18272500
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELTchat",
      "indices" : [ 57, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/MdUYUfxP",
      "expanded_url" : "http:\/\/bit.ly\/UO7Urs",
      "display_url" : "bit.ly\/UO7Urs"
    } ]
  },
  "geo" : { },
  "id_str" : "291304862686277632",
  "text" : "RT @Marisa_C: There is still time to vote for tomorrow's #ELTchat topics. Pls vote and RT this http:\/\/t.co\/MdUYUfxP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELTchat",
        "indices" : [ 43, 51 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 101 ],
        "url" : "http:\/\/t.co\/MdUYUfxP",
        "expanded_url" : "http:\/\/bit.ly\/UO7Urs",
        "display_url" : "bit.ly\/UO7Urs"
      } ]
    },
    "geo" : { },
    "id_str" : "291276721221689344",
    "text" : "There is still time to vote for tomorrow's #ELTchat topics. Pls vote and RT this http:\/\/t.co\/MdUYUfxP",
    "id" : 291276721221689344,
    "created_at" : "2013-01-15 20:12:36 +0000",
    "user" : {
      "name" : "MarisaConstantinides",
      "screen_name" : "Marisa_C",
      "protected" : false,
      "id_str" : "18272500",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/551128180497457153\/DRrY3cNw_normal.jpeg",
      "id" : 18272500,
      "verified" : false
    }
  },
  "id" : 291304862686277632,
  "created_at" : "2013-01-15 22:04:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 3, 17 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/c5UU04K3",
      "expanded_url" : "http:\/\/m.guardian.co.uk\/education\/2013\/jan\/15\/teachers-pay-performance-michael-gove",
      "display_url" : "m.guardian.co.uk\/education\/2013\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "291292855333441536",
  "text" : "RT @audreywatters: UK will begin performance-related pay for teachers this fall http:\/\/t.co\/c5UU04K3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 81 ],
        "url" : "http:\/\/t.co\/c5UU04K3",
        "expanded_url" : "http:\/\/m.guardian.co.uk\/education\/2013\/jan\/15\/teachers-pay-performance-michael-gove",
        "display_url" : "m.guardian.co.uk\/education\/2013\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "291286906543681536",
    "text" : "UK will begin performance-related pay for teachers this fall http:\/\/t.co\/c5UU04K3",
    "id" : 291286906543681536,
    "created_at" : "2013-01-15 20:53:05 +0000",
    "user" : {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "protected" : false,
      "id_str" : "25388528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711668009723498496\/pauFZsdv_normal.jpg",
      "id" : 25388528,
      "verified" : false
    }
  },
  "id" : 291292855333441536,
  "created_at" : "2013-01-15 21:16:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dale Coulter",
      "screen_name" : "dalecoulter",
      "indices" : [ 3, 15 ],
      "id_str" : "24046458",
      "id" : 24046458
    }, {
      "name" : "Chiew Pang",
      "screen_name" : "aClilToClimb",
      "indices" : [ 17, 30 ],
      "id_str" : "76160458",
      "id" : 76160458
    }, {
      "name" : "Chris O\u017C\u00F3g",
      "screen_name" : "ChrisOzog",
      "indices" : [ 31, 41 ],
      "id_str" : "79192243",
      "id" : 79192243
    }, {
      "name" : "elton naicker",
      "screen_name" : "elt",
      "indices" : [ 139, 140 ],
      "id_str" : "131938942",
      "id" : 131938942
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/b7kW22HR",
      "expanded_url" : "http:\/\/languagemoments.wordpress.com\/2013\/01\/14\/correction-and-timing\/",
      "display_url" : "languagemoments.wordpress.com\/2013\/01\/14\/cor\u2026"
    }, {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/1XB9NLri",
      "expanded_url" : "http:\/\/dogmediaries.wordpress.com\/2013\/01\/14\/error-correction-part-2\/#comment-470",
      "display_url" : "dogmediaries.wordpress.com\/2013\/01\/14\/err\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "291286193243561986",
  "text" : "RT @dalecoulter: @aClilToClimb @ChrisOzog Come and watch the discussion grow on correction at http:\/\/t.co\/b7kW22HR and http:\/\/t.co\/1XB9N ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Chiew Pang",
        "screen_name" : "aClilToClimb",
        "indices" : [ 0, 13 ],
        "id_str" : "76160458",
        "id" : 76160458
      }, {
        "name" : "Chris O\u017C\u00F3g",
        "screen_name" : "ChrisOzog",
        "indices" : [ 14, 24 ],
        "id_str" : "79192243",
        "id" : 79192243
      }, {
        "name" : "elton naicker",
        "screen_name" : "elt",
        "indices" : [ 132, 136 ],
        "id_str" : "131938942",
        "id" : 131938942
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "eltchat",
        "indices" : [ 123, 131 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 97 ],
        "url" : "http:\/\/t.co\/b7kW22HR",
        "expanded_url" : "http:\/\/languagemoments.wordpress.com\/2013\/01\/14\/correction-and-timing\/",
        "display_url" : "languagemoments.wordpress.com\/2013\/01\/14\/cor\u2026"
      }, {
        "indices" : [ 102, 122 ],
        "url" : "http:\/\/t.co\/1XB9NLri",
        "expanded_url" : "http:\/\/dogmediaries.wordpress.com\/2013\/01\/14\/error-correction-part-2\/#comment-470",
        "display_url" : "dogmediaries.wordpress.com\/2013\/01\/14\/err\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "291282462829592576",
    "in_reply_to_user_id" : 76160458,
    "text" : "@aClilToClimb @ChrisOzog Come and watch the discussion grow on correction at http:\/\/t.co\/b7kW22HR and http:\/\/t.co\/1XB9NLri #eltchat @elt",
    "id" : 291282462829592576,
    "created_at" : "2013-01-15 20:35:25 +0000",
    "in_reply_to_screen_name" : "aClilToClimb",
    "in_reply_to_user_id_str" : "76160458",
    "user" : {
      "name" : "Dale Coulter",
      "screen_name" : "dalecoulter",
      "protected" : false,
      "id_str" : "24046458",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528209583752220673\/ZlqajEJk_normal.jpeg",
      "id" : 24046458,
      "verified" : false
    }
  },
  "id" : 291286193243561986,
  "created_at" : "2013-01-15 20:50:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 3, 14 ],
      "id_str" : "282659955",
      "id" : 282659955
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 89, 97 ]
    }, {
      "text" : "esol",
      "indices" : [ 98, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/ihNCzkDE",
      "expanded_url" : "http:\/\/wp.me\/p2e2Wf-9Z",
      "display_url" : "wp.me\/p2e2Wf-9Z"
    } ]
  },
  "geo" : { },
  "id_str" : "291285817584939009",
  "text" : "RT @teflerinha: Latest blog post: Collaborative writing activities http:\/\/t.co\/ihNCzkDE  #eltchat #esol",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "eltchat",
        "indices" : [ 73, 81 ]
      }, {
        "text" : "esol",
        "indices" : [ 82, 87 ]
      } ],
      "urls" : [ {
        "indices" : [ 51, 71 ],
        "url" : "http:\/\/t.co\/ihNCzkDE",
        "expanded_url" : "http:\/\/wp.me\/p2e2Wf-9Z",
        "display_url" : "wp.me\/p2e2Wf-9Z"
      } ]
    },
    "geo" : { },
    "id_str" : "291250399632031744",
    "text" : "Latest blog post: Collaborative writing activities http:\/\/t.co\/ihNCzkDE  #eltchat #esol",
    "id" : 291250399632031744,
    "created_at" : "2013-01-15 18:28:01 +0000",
    "user" : {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "protected" : false,
      "id_str" : "282659955",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2149898907\/Rachael_Roberts_headshot_square_normal.jpg",
      "id" : 282659955,
      "verified" : false
    }
  },
  "id" : 291285817584939009,
  "created_at" : "2013-01-15 20:48:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 58, 73 ],
      "id_str" : "20760283",
      "id" : 20760283
    }, {
      "name" : "Dale Coulter",
      "screen_name" : "dalecoulter",
      "indices" : [ 74, 86 ],
      "id_str" : "24046458",
      "id" : 24046458
    }, {
      "name" : "Chiew Pang",
      "screen_name" : "aClilToClimb",
      "indices" : [ 87, 100 ],
      "id_str" : "76160458",
      "id" : 76160458
    }, {
      "name" : "IATEFL BESIG",
      "screen_name" : "iatefl_besig",
      "indices" : [ 104, 117 ],
      "id_str" : "146913655",
      "id" : 146913655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/cn83aopj",
      "expanded_url" : "http:\/\/businessenglishresources.blogspot.de\/2013\/01\/rolo-reformulate-output-lightly-and.html",
      "display_url" : "businessenglishresources.blogspot.de\/2013\/01\/rolo-r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "291167669464477696",
  "text" : "nice slide on fb\/correction &gt; http:\/\/t.co\/cn83aopj  cc @MrChrisJWilson @dalecoulter @aClilToClimb HT @iatefl_besig",
  "id" : 291167669464477696,
  "created_at" : "2013-01-15 12:59:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Simpson",
      "screen_name" : "yearinthelifeof",
      "indices" : [ 0, 16 ],
      "id_str" : "78543378",
      "id" : 78543378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291163394659213312",
  "geo" : { },
  "id_str" : "291165614008066048",
  "in_reply_to_user_id" : 78543378,
  "text" : "@yearinthelifeof wonderwheel no longer exists? also a gmail address shows in those screenshots.",
  "id" : 291165614008066048,
  "in_reply_to_status_id" : 291163394659213312,
  "created_at" : "2013-01-15 12:51:06 +0000",
  "in_reply_to_screen_name" : "yearinthelifeof",
  "in_reply_to_user_id_str" : "78543378",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/AihIqO80",
      "expanded_url" : "http:\/\/www.theregister.co.uk\/2013\/01\/14\/computers_electronic_cocaine\/",
      "display_url" : "theregister.co.uk\/2013\/01\/14\/com\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "291142631994556417",
  "geo" : { },
  "id_str" : "291144319547617280",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson http:\/\/t.co\/AihIqO80 switching off is good :)",
  "id" : 291144319547617280,
  "in_reply_to_status_id" : 291142631994556417,
  "created_at" : "2013-01-15 11:26:29 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CDE",
      "screen_name" : "cdelondon",
      "indices" : [ 0, 10 ],
      "id_str" : "158683357",
      "id" : 158683357
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291141679602339841",
  "geo" : { },
  "id_str" : "291143491403251713",
  "in_reply_to_user_id" : 158683357,
  "text" : "@cdelondon it is still difficult for general public to access the stuff so import of statement is still valid unfortunately",
  "id" : 291143491403251713,
  "in_reply_to_status_id" : 291141679602339841,
  "created_at" : "2013-01-15 11:23:12 +0000",
  "in_reply_to_screen_name" : "cdelondon",
  "in_reply_to_user_id_str" : "158683357",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CDE",
      "screen_name" : "cdelondon",
      "indices" : [ 0, 10 ],
      "id_str" : "158683357",
      "id" : 158683357
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291127555728240640",
  "geo" : { },
  "id_str" : "291129260251418624",
  "in_reply_to_user_id" : 158683357,
  "text" : "@cdelondon lol looks like result of my poor search skills, just fnd ref, tgh it is on a japanese site probably not uploaded by journal!",
  "id" : 291129260251418624,
  "in_reply_to_status_id" : 291127555728240640,
  "created_at" : "2013-01-15 10:26:39 +0000",
  "in_reply_to_screen_name" : "cdelondon",
  "in_reply_to_user_id_str" : "158683357",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291118823510265856",
  "geo" : { },
  "id_str" : "291119364839727104",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson this friday lookng ok anytime",
  "id" : 291119364839727104,
  "in_reply_to_status_id" : 291118823510265856,
  "created_at" : "2013-01-15 09:47:19 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    }, {
      "name" : "Dale Coulter",
      "screen_name" : "dalecoulter",
      "indices" : [ 16, 28 ],
      "id_str" : "24046458",
      "id" : 24046458
    }, {
      "name" : "Chiew Pang",
      "screen_name" : "aClilToClimb",
      "indices" : [ 29, 42 ],
      "id_str" : "76160458",
      "id" : 76160458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291112990449754112",
  "geo" : { },
  "id_str" : "291117936599527424",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson @dalecoulter @aClilToClimb do it! will be in!",
  "id" : 291117936599527424,
  "in_reply_to_status_id" : 291112990449754112,
  "created_at" : "2013-01-15 09:41:39 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 0, 11 ],
      "id_str" : "282659955",
      "id" : 282659955
    }, {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 12, 28 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291112354081538050",
  "geo" : { },
  "id_str" : "291112790360469505",
  "in_reply_to_user_id" : 282659955,
  "text" : "@teflerinha @michaelegriffin those categories need work though :)",
  "id" : 291112790360469505,
  "in_reply_to_status_id" : 291112354081538050,
  "created_at" : "2013-01-15 09:21:12 +0000",
  "in_reply_to_screen_name" : "teflerinha",
  "in_reply_to_user_id_str" : "282659955",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    }, {
      "name" : "Dale Coulter",
      "screen_name" : "dalecoulter",
      "indices" : [ 16, 28 ],
      "id_str" : "24046458",
      "id" : 24046458
    }, {
      "name" : "Chiew Pang",
      "screen_name" : "aClilToClimb",
      "indices" : [ 72, 85 ],
      "id_str" : "76160458",
      "id" : 76160458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291100928784883712",
  "geo" : { },
  "id_str" : "291112262897369088",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson @dalecoulter yes grt video thgh read written preview on @aClilToClimb post",
  "id" : 291112262897369088,
  "in_reply_to_status_id" : 291100928784883712,
  "created_at" : "2013-01-15 09:19:06 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    }, {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 17, 28 ],
      "id_str" : "282659955",
      "id" : 282659955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/dkxulO1C",
      "expanded_url" : "http:\/\/tefltastic.wordpress.com\/2012\/06\/19\/top-trumps-for-teflers\/",
      "display_url" : "tefltastic.wordpress.com\/2012\/06\/19\/top\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "291108947627233280",
  "geo" : { },
  "id_str" : "291111957266825216",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin @teflerinha http:\/\/t.co\/dkxulO1C",
  "id" : 291111957266825216,
  "in_reply_to_status_id" : 291108947627233280,
  "created_at" : "2013-01-15 09:17:53 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 12, 27 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291072867456651265",
  "geo" : { },
  "id_str" : "291081543168954368",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan @MrChrisJWilson be interested to hear if\/how you use it :)",
  "id" : 291081543168954368,
  "in_reply_to_status_id" : 291072867456651265,
  "created_at" : "2013-01-15 07:17:02 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 3, 17 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http:\/\/t.co\/vNGRzSs6",
      "expanded_url" : "http:\/\/www.nytimes.com\/2013\/01\/15\/technology\/california-to-give-web-courses-a-big-trial.html",
      "display_url" : "nytimes.com\/2013\/01\/15\/tec\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "291080048268685312",
  "text" : "RT @audreywatters: Huge http:\/\/t.co\/vNGRzSs6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 5, 25 ],
        "url" : "http:\/\/t.co\/vNGRzSs6",
        "expanded_url" : "http:\/\/www.nytimes.com\/2013\/01\/15\/technology\/california-to-give-web-courses-a-big-trial.html",
        "display_url" : "nytimes.com\/2013\/01\/15\/tec\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "291057569492004864",
    "text" : "Huge http:\/\/t.co\/vNGRzSs6",
    "id" : 291057569492004864,
    "created_at" : "2013-01-15 05:41:46 +0000",
    "user" : {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "protected" : false,
      "id_str" : "25388528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711668009723498496\/pauFZsdv_normal.jpg",
      "id" : 25388528,
      "verified" : false
    }
  },
  "id" : 291080048268685312,
  "created_at" : "2013-01-15 07:11:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Register",
      "screen_name" : "TheRegister",
      "indices" : [ 3, 15 ],
      "id_str" : "78012548",
      "id" : 78012548
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/FI7fG5fz",
      "expanded_url" : "http:\/\/reg.cx\/1ZBv",
      "display_url" : "reg.cx\/1ZBv"
    } ]
  },
  "geo" : { },
  "id_str" : "291072500534747137",
  "text" : "RT @theregister: Swedish school puts Minecraft on the school curriculum: Those are some lucky students. Whereas most schoolchildren h\u2026 h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/theregister.co.uk\/\" rel=\"nofollow\"\u003EVulture Central\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/FI7fG5fz",
        "expanded_url" : "http:\/\/reg.cx\/1ZBv",
        "display_url" : "reg.cx\/1ZBv"
      } ]
    },
    "geo" : { },
    "id_str" : "291022781439696896",
    "text" : "Swedish school puts Minecraft on the school curriculum: Those are some lucky students. Whereas most schoolchildren h\u2026 http:\/\/t.co\/FI7fG5fz",
    "id" : 291022781439696896,
    "created_at" : "2013-01-15 03:23:32 +0000",
    "user" : {
      "name" : "RegVulture",
      "screen_name" : "regvulture",
      "protected" : false,
      "id_str" : "381940039",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000641211038\/baad5b63e1d218692d68b03ae7a1057f_normal.png",
      "id" : 381940039,
      "verified" : false
    }
  },
  "id" : 291072500534747137,
  "created_at" : "2013-01-15 06:41:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/vfjKG0uV",
      "expanded_url" : "http:\/\/www.guardian.co.uk\/commentisfree\/2013\/jan\/14\/mali-france-bombing-intervention-libya",
      "display_url" : "guardian.co.uk\/commentisfree\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "290958414077624320",
  "text" : "The bombing of Mali highlights all the lessons of western intervention http:\/\/t.co\/vfjKG0uV",
  "id" : 290958414077624320,
  "created_at" : "2013-01-14 23:07:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Weidenbaum",
      "screen_name" : "disquiet",
      "indices" : [ 3, 12 ],
      "id_str" : "6943192",
      "id" : 6943192
    }, {
      "name" : "Lessig",
      "screen_name" : "lessig",
      "indices" : [ 26, 33 ],
      "id_str" : "11388132",
      "id" : 11388132
    }, {
      "name" : "Aaron Swartz",
      "screen_name" : "aaronsw",
      "indices" : [ 49, 57 ],
      "id_str" : "2696831",
      "id" : 2696831
    }, {
      "name" : "Follow @Disquiet",
      "screen_name" : "djunto",
      "indices" : [ 139, 140 ],
      "id_str" : "586933515",
      "id" : 586933515
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/TirNSM2l",
      "expanded_url" : "http:\/\/lessig.tumblr.com\/post\/40347463044\/prosecutor-as-bully",
      "display_url" : "lessig.tumblr.com\/post\/403474630\u2026"
    }, {
      "indices" : [ 104, 125 ],
      "url" : "https:\/\/t.co\/8S35dnxg",
      "expanded_url" : "https:\/\/soundcloud.com\/happypuppyrecords\/lee-rosevere-prosecutor-as",
      "display_url" : "soundcloud.com\/happypuppyreco\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "290951829737570304",
  "text" : "RT @disquiet: A score for @lessig's obituary for @aaronsw. Text here: http:\/\/t.co\/TirNSM2l. Music here: https:\/\/t.co\/8S35dnxg. Part of t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lessig",
        "screen_name" : "lessig",
        "indices" : [ 12, 19 ],
        "id_str" : "11388132",
        "id" : 11388132
      }, {
        "name" : "Aaron Swartz",
        "screen_name" : "aaronsw",
        "indices" : [ 35, 43 ],
        "id_str" : "2696831",
        "id" : 2696831
      }, {
        "name" : "Follow @Disquiet",
        "screen_name" : "djunto",
        "indices" : [ 130, 137 ],
        "id_str" : "586933515",
        "id" : 586933515
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 76 ],
        "url" : "http:\/\/t.co\/TirNSM2l",
        "expanded_url" : "http:\/\/lessig.tumblr.com\/post\/40347463044\/prosecutor-as-bully",
        "display_url" : "lessig.tumblr.com\/post\/403474630\u2026"
      }, {
        "indices" : [ 90, 111 ],
        "url" : "https:\/\/t.co\/8S35dnxg",
        "expanded_url" : "https:\/\/soundcloud.com\/happypuppyrecords\/lee-rosevere-prosecutor-as",
        "display_url" : "soundcloud.com\/happypuppyreco\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "290317089628114944",
    "text" : "A score for @lessig's obituary for @aaronsw. Text here: http:\/\/t.co\/TirNSM2l. Music here: https:\/\/t.co\/8S35dnxg. Part of the 54th @djunto.",
    "id" : 290317089628114944,
    "created_at" : "2013-01-13 04:39:22 +0000",
    "user" : {
      "name" : "Marc Weidenbaum",
      "screen_name" : "disquiet",
      "protected" : false,
      "id_str" : "6943192",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/692147298017632256\/l5mu9mbn_normal.jpg",
      "id" : 6943192,
      "verified" : false
    }
  },
  "id" : 290951829737570304,
  "created_at" : "2013-01-14 22:41:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/zQiNZlgx",
      "expanded_url" : "http:\/\/www.hackagame.org",
      "display_url" : "hackagame.org"
    } ]
  },
  "geo" : { },
  "id_str" : "290941903304802304",
  "text" : "http:\/\/t.co\/zQiNZlgx very very cool!",
  "id" : 290941903304802304,
  "created_at" : "2013-01-14 22:02:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 0, 11 ],
      "id_str" : "282659955",
      "id" : 282659955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "290861439206436864",
  "geo" : { },
  "id_str" : "290890635542659073",
  "in_reply_to_user_id" : 282659955,
  "text" : "@teflerinha thx so much for RT and replied to yr comment",
  "id" : 290890635542659073,
  "in_reply_to_status_id" : 290861439206436864,
  "created_at" : "2013-01-14 18:38:26 +0000",
  "in_reply_to_screen_name" : "teflerinha",
  "in_reply_to_user_id_str" : "282659955",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Alexander",
      "screen_name" : "BryanAlexander",
      "indices" : [ 3, 18 ],
      "id_str" : "755991",
      "id" : 755991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/C0tw2CPC",
      "expanded_url" : "http:\/\/bit.ly\/13uETGS",
      "display_url" : "bit.ly\/13uETGS"
    } ]
  },
  "geo" : { },
  "id_str" : "290860897377857536",
  "text" : "RT @BryanAlexander: Internet Archive launches The Aaron Swartz Collection: http:\/\/t.co\/C0tw2CPC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 75 ],
        "url" : "http:\/\/t.co\/C0tw2CPC",
        "expanded_url" : "http:\/\/bit.ly\/13uETGS",
        "display_url" : "bit.ly\/13uETGS"
      } ]
    },
    "geo" : { },
    "id_str" : "290848510222405633",
    "text" : "Internet Archive launches The Aaron Swartz Collection: http:\/\/t.co\/C0tw2CPC",
    "id" : 290848510222405633,
    "created_at" : "2013-01-14 15:51:03 +0000",
    "user" : {
      "name" : "Bryan Alexander",
      "screen_name" : "BryanAlexander",
      "protected" : false,
      "id_str" : "755991",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/654391499686313986\/1Fx2eBCq_normal.jpg",
      "id" : 755991,
      "verified" : false
    }
  },
  "id" : 290860897377857536,
  "created_at" : "2013-01-14 16:40:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "phil wade",
      "screen_name" : "phil3wade",
      "indices" : [ 0, 10 ],
      "id_str" : "248864761",
      "id" : 248864761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "290727979246555136",
  "geo" : { },
  "id_str" : "290860751592226816",
  "in_reply_to_user_id" : 248864761,
  "text" : "@phil3wade heck! hope u r well and no serous injury!",
  "id" : 290860751592226816,
  "in_reply_to_status_id" : 290727979246555136,
  "created_at" : "2013-01-14 16:39:41 +0000",
  "in_reply_to_screen_name" : "phil3wade",
  "in_reply_to_user_id_str" : "248864761",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "290851208908914688",
  "geo" : { },
  "id_str" : "290859896839208960",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin thx, replied and added a wee comment to yr post.",
  "id" : 290859896839208960,
  "in_reply_to_status_id" : 290851208908914688,
  "created_at" : "2013-01-14 16:36:17 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mieke Kenis",
      "screen_name" : "mkofab",
      "indices" : [ 0, 7 ],
      "id_str" : "96527212",
      "id" : 96527212
    }, {
      "name" : "Ben Crystal",
      "screen_name" : "bencrystal",
      "indices" : [ 8, 19 ],
      "id_str" : "39458003",
      "id" : 39458003
    }, {
      "name" : "BELTA Belgium",
      "screen_name" : "BELTABelgium",
      "indices" : [ 41, 54 ],
      "id_str" : "884934438",
      "id" : 884934438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "290732997861322753",
  "geo" : { },
  "id_str" : "290854518038614016",
  "in_reply_to_user_id" : 96527212,
  "text" : "@mkofab @bencrystal good stuff! hope the @BELTABelgium launch went swell.",
  "id" : 290854518038614016,
  "in_reply_to_status_id" : 290732997861322753,
  "created_at" : "2013-01-14 16:14:55 +0000",
  "in_reply_to_screen_name" : "mkofab",
  "in_reply_to_user_id_str" : "96527212",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "290850702316687360",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin man thx for RT mike just abt to read yr latest.",
  "id" : 290850702316687360,
  "created_at" : "2013-01-14 15:59:45 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Prior",
      "screen_name" : "ConceptCzech",
      "indices" : [ 0, 13 ],
      "id_str" : "256015802",
      "id" : 256015802
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "290844859537977344",
  "geo" : { },
  "id_str" : "290850331158511616",
  "in_reply_to_user_id" : 256015802,
  "text" : "@ConceptCzech lol!  funny student! :)",
  "id" : 290850331158511616,
  "in_reply_to_status_id" : 290844859537977344,
  "created_at" : "2013-01-14 15:58:17 +0000",
  "in_reply_to_screen_name" : "ConceptCzech",
  "in_reply_to_user_id_str" : "256015802",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CDE",
      "screen_name" : "cdelondon",
      "indices" : [ 102, 112 ],
      "id_str" : "158683357",
      "id" : 158683357
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/YczOVFFP",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-gu",
      "display_url" : "wp.me\/pgHyE-gu"
    } ]
  },
  "geo" : { },
  "id_str" : "290843218935967745",
  "text" : "Update 2 on What research says post http:\/\/t.co\/YczOVFFP linking to a great UK uni search tool thx to @cdelondon",
  "id" : 290843218935967745,
  "created_at" : "2013-01-14 15:30:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CDE",
      "screen_name" : "cdelondon",
      "indices" : [ 3, 13 ],
      "id_str" : "158683357",
      "id" : 158683357
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/0KdFDbBU",
      "expanded_url" : "http:\/\/www.guardian.co.uk\/higher-education-network\/blog\/2013\/jan\/10\/research-communications-uk-university-websites?CMP=new_58&j=25357&e=tom.inkelaar",
      "display_url" : "guardian.co.uk\/higher-educati\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "290837499041955840",
  "text" : "RT @cdelondon: Interesting: http:\/\/t.co\/0KdFDbBU@london.ac.uk&amp;l=350_HTML&amp;u=1308535&amp;mid=1059027&amp;jb=4&amp;CMP=",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 13, 33 ],
        "url" : "http:\/\/t.co\/0KdFDbBU",
        "expanded_url" : "http:\/\/www.guardian.co.uk\/higher-education-network\/blog\/2013\/jan\/10\/research-communications-uk-university-websites?CMP=new_58&j=25357&e=tom.inkelaar",
        "display_url" : "guardian.co.uk\/higher-educati\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "290830343727095808",
    "text" : "Interesting: http:\/\/t.co\/0KdFDbBU@london.ac.uk&amp;l=350_HTML&amp;u=1308535&amp;mid=1059027&amp;jb=4&amp;CMP=",
    "id" : 290830343727095808,
    "created_at" : "2013-01-14 14:38:51 +0000",
    "user" : {
      "name" : "CDE",
      "screen_name" : "cdelondon",
      "protected" : false,
      "id_str" : "158683357",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3662440478\/0d4b919cda74d75e15216adb0458adc5_normal.png",
      "id" : 158683357,
      "verified" : false
    }
  },
  "id" : 290837499041955840,
  "created_at" : "2013-01-14 15:07:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CDE",
      "screen_name" : "cdelondon",
      "indices" : [ 0, 10 ],
      "id_str" : "158683357",
      "id" : 158683357
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "290830343727095808",
  "geo" : { },
  "id_str" : "290837452829126656",
  "in_reply_to_user_id" : 158683357,
  "text" : "@cdelondon i did a recent net search and could access a US reference but not a UK one  :\/",
  "id" : 290837452829126656,
  "in_reply_to_status_id" : 290830343727095808,
  "created_at" : "2013-01-14 15:07:06 +0000",
  "in_reply_to_screen_name" : "cdelondon",
  "in_reply_to_user_id_str" : "158683357",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Xanthe",
      "screen_name" : "xanlan",
      "indices" : [ 0, 7 ],
      "id_str" : "39527659",
      "id" : 39527659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "290705889046982656",
  "geo" : { },
  "id_str" : "290805691684384768",
  "in_reply_to_user_id" : 39527659,
  "text" : "@xanlan apart from p\/w change maybe notify twitter?",
  "id" : 290805691684384768,
  "in_reply_to_status_id" : 290705889046982656,
  "created_at" : "2013-01-14 13:00:54 +0000",
  "in_reply_to_screen_name" : "xanlan",
  "in_reply_to_user_id_str" : "39527659",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 12, 27 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/fwp1vbaW",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-bo",
      "display_url" : "wp.me\/pgHyE-bo"
    } ]
  },
  "in_reply_to_status_id_str" : "290717328113557504",
  "geo" : { },
  "id_str" : "290794980115632128",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan @MrChrisJWilson u could take my animated gif frm here http:\/\/t.co\/fwp1vbaW",
  "id" : 290794980115632128,
  "in_reply_to_status_id" : 290717328113557504,
  "created_at" : "2013-01-14 12:18:20 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mieke Kenis",
      "screen_name" : "mkofab",
      "indices" : [ 0, 7 ],
      "id_str" : "96527212",
      "id" : 96527212
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/290608762975313921\/photo\/1",
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/HrpbydvV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BAhzIVZCYAQor5j.png",
      "id_str" : "290608762983702532",
      "id" : 290608762983702532,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BAhzIVZCYAQor5j.png",
      "sizes" : [ {
        "h" : 169,
        "resize" : "fit",
        "w" : 938
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 108,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 169,
        "resize" : "fit",
        "w" : 938
      }, {
        "h" : 61,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/HrpbydvV"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http:\/\/t.co\/5fsQvdv7",
      "expanded_url" : "http:\/\/www.paulmeier.com\/OP.pdf",
      "display_url" : "paulmeier.com\/OP.pdf"
    } ]
  },
  "in_reply_to_status_id_str" : "290587125898960897",
  "geo" : { },
  "id_str" : "290608762975313921",
  "in_reply_to_user_id" : 96527212,
  "text" : "@mkofab fnd this http:\/\/t.co\/5fsQvdv7 -  \/au\/ was schwa and \/u\/ eng \"o\" which i guess gets closer to frnch nasal \"o\"? http:\/\/t.co\/HrpbydvV",
  "id" : 290608762975313921,
  "in_reply_to_status_id" : 290587125898960897,
  "created_at" : "2013-01-13 23:58:23 +0000",
  "in_reply_to_screen_name" : "mkofab",
  "in_reply_to_user_id_str" : "96527212",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mieke Kenis",
      "screen_name" : "mkofab",
      "indices" : [ 0, 7 ],
      "id_str" : "96527212",
      "id" : 96527212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "290587125898960897",
  "geo" : { },
  "id_str" : "290594003177582592",
  "in_reply_to_user_id" : 96527212,
  "text" : "@mkofab no idea! will need to look at a corpus of shakespeare english!",
  "id" : 290594003177582592,
  "in_reply_to_status_id" : 290587125898960897,
  "created_at" : "2013-01-13 22:59:43 +0000",
  "in_reply_to_screen_name" : "mkofab",
  "in_reply_to_user_id_str" : "96527212",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mieke Kenis",
      "screen_name" : "mkofab",
      "indices" : [ 0, 7 ],
      "id_str" : "96527212",
      "id" : 96527212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "290579904490258434",
  "geo" : { },
  "id_str" : "290582833158828032",
  "in_reply_to_user_id" : 96527212,
  "text" : "@mkofab ah yes! close \/k\/ and \/g\/ sounds; though i wonder wether r\/l french spkr wld confuse the eng \/au\/ sound for frnch nasal vowel?",
  "id" : 290582833158828032,
  "in_reply_to_status_id" : 290579904490258434,
  "created_at" : "2013-01-13 22:15:20 +0000",
  "in_reply_to_screen_name" : "mkofab",
  "in_reply_to_user_id_str" : "96527212",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mieke Kenis",
      "screen_name" : "mkofab",
      "indices" : [ 0, 7 ],
      "id_str" : "96527212",
      "id" : 96527212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "290576179579207680",
  "geo" : { },
  "id_str" : "290578717942624256",
  "in_reply_to_user_id" : 96527212,
  "text" : "@mkofab was thomsons's princess raised in quebec ;), utube comments explains the 'con' reference from 'la robe' via 'gown' aparently.",
  "id" : 290578717942624256,
  "in_reply_to_status_id" : 290576179579207680,
  "created_at" : "2013-01-13 21:58:59 +0000",
  "in_reply_to_screen_name" : "mkofab",
  "in_reply_to_user_id_str" : "96527212",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mieke Kenis",
      "screen_name" : "mkofab",
      "indices" : [ 0, 7 ],
      "id_str" : "96527212",
      "id" : 96527212
    }, {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 8, 19 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "290570581810745345",
  "geo" : { },
  "id_str" : "290574156188237824",
  "in_reply_to_user_id" : 96527212,
  "text" : "@mkofab @leoselivan rofl! :)",
  "id" : 290574156188237824,
  "in_reply_to_status_id" : 290570581810745345,
  "created_at" : "2013-01-13 21:40:52 +0000",
  "in_reply_to_screen_name" : "mkofab",
  "in_reply_to_user_id_str" : "96527212",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Oxenham",
      "screen_name" : "neurobonkers",
      "indices" : [ 3, 16 ],
      "id_str" : "134610558",
      "id" : 134610558
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PDFTribute",
      "indices" : [ 18, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/lF050ESc",
      "expanded_url" : "http:\/\/pdftribute.net\/",
      "display_url" : "pdftribute.net"
    } ]
  },
  "geo" : { },
  "id_str" : "290565988561350657",
  "text" : "RT @neurobonkers: #PDFTribute papers uploaded by academics in honour of Aaron Swartz are being scraped here: http:\/\/t.co\/lF050ESc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PDFTribute",
        "indices" : [ 0, 11 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 111 ],
        "url" : "http:\/\/t.co\/lF050ESc",
        "expanded_url" : "http:\/\/pdftribute.net\/",
        "display_url" : "pdftribute.net"
      } ]
    },
    "geo" : { },
    "id_str" : "290524172868796416",
    "text" : "#PDFTribute papers uploaded by academics in honour of Aaron Swartz are being scraped here: http:\/\/t.co\/lF050ESc",
    "id" : 290524172868796416,
    "created_at" : "2013-01-13 18:22:15 +0000",
    "user" : {
      "name" : "Simon Oxenham",
      "screen_name" : "neurobonkers",
      "protected" : false,
      "id_str" : "134610558",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1604981312\/bwlur_normal.png",
      "id" : 134610558,
      "verified" : false
    }
  },
  "id" : 290565988561350657,
  "created_at" : "2013-01-13 21:08:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    }, {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 16, 27 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "290562098138857472",
  "geo" : { },
  "id_str" : "290565191375138817",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson @leoselivan no comment! :\\",
  "id" : 290565191375138817,
  "in_reply_to_status_id" : 290562098138857472,
  "created_at" : "2013-01-13 21:05:14 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    }, {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 16, 27 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/290561809038073856\/photo\/1",
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/zNJ8xQwd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BAhIbQWCYAA8xD6.jpg",
      "id_str" : "290561809046462464",
      "id" : 290561809046462464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BAhIbQWCYAA8xD6.jpg",
      "sizes" : [ {
        "h" : 264,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 451,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 536,
        "resize" : "fit",
        "w" : 1218
      }, {
        "h" : 150,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/zNJ8xQwd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "290542327322271744",
  "geo" : { },
  "id_str" : "290561809038073856",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson @leoselivan can we say this is a lexical approach from film For a good time call? :) http:\/\/t.co\/zNJ8xQwd",
  "id" : 290561809038073856,
  "in_reply_to_status_id" : 290542327322271744,
  "created_at" : "2013-01-13 20:51:48 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/YczOVFFP",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-gu",
      "display_url" : "wp.me\/pgHyE-gu"
    } ]
  },
  "geo" : { },
  "id_str" : "290552128160821248",
  "text" : "updated Feedback research post http:\/\/t.co\/YczOVFFP with timing info and resources used for research info",
  "id" : 290552128160821248,
  "created_at" : "2013-01-13 20:13:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 0, 13 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mumitsbatman3",
      "indices" : [ 41, 55 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "290221264029765632",
  "geo" : { },
  "id_str" : "290249761972420608",
  "in_reply_to_user_id" : 88655243,
  "text" : "@rosemerebard grt, sure i heard cries of #mumitsbatman3! ;), my 8 month son is enjoying his recently found crawling abilities so a bit tired",
  "id" : 290249761972420608,
  "in_reply_to_status_id" : 290221264029765632,
  "created_at" : "2013-01-13 00:11:50 +0000",
  "in_reply_to_screen_name" : "rosemerebard",
  "in_reply_to_user_id_str" : "88655243",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chadsansing",
      "screen_name" : "chadsansing",
      "indices" : [ 0, 12 ],
      "id_str" : "76810409",
      "id" : 76810409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "290246291370418176",
  "geo" : { },
  "id_str" : "290246754060886016",
  "in_reply_to_user_id" : 76810409,
  "text" : "@chadsansing it's CC so be my guest ;)",
  "id" : 290246754060886016,
  "in_reply_to_status_id" : 290246291370418176,
  "created_at" : "2013-01-12 23:59:53 +0000",
  "in_reply_to_screen_name" : "chadsansing",
  "in_reply_to_user_id_str" : "76810409",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chadsansing",
      "screen_name" : "chadsansing",
      "indices" : [ 0, 12 ],
      "id_str" : "76810409",
      "id" : 76810409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "290244895346683904",
  "geo" : { },
  "id_str" : "290245960209137665",
  "in_reply_to_user_id" : 76810409,
  "text" : "@chadsansing your vision of teaching charges is horrifying but present ideo-logically  possible future!",
  "id" : 290245960209137665,
  "in_reply_to_status_id" : 290244895346683904,
  "created_at" : "2013-01-12 23:56:44 +0000",
  "in_reply_to_screen_name" : "chadsansing",
  "in_reply_to_user_id_str" : "76810409",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chadsansing",
      "screen_name" : "chadsansing",
      "indices" : [ 0, 12 ],
      "id_str" : "76810409",
      "id" : 76810409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "290240098983878656",
  "geo" : { },
  "id_str" : "290244024701444096",
  "in_reply_to_user_id" : 76810409,
  "text" : "@chadsansing just read chapter 1 and really enjoyed it!",
  "id" : 290244024701444096,
  "in_reply_to_status_id" : 290240098983878656,
  "created_at" : "2013-01-12 23:49:02 +0000",
  "in_reply_to_screen_name" : "chadsansing",
  "in_reply_to_user_id_str" : "76810409",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chadsansing",
      "screen_name" : "chadsansing",
      "indices" : [ 3, 15 ],
      "id_str" : "76810409",
      "id" : 76810409
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GatesReport",
      "indices" : [ 113, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/KwM1cwsA",
      "expanded_url" : "http:\/\/bit.ly\/SrqEkY",
      "display_url" : "bit.ly\/SrqEkY"
    } ]
  },
  "geo" : { },
  "id_str" : "290243693804400640",
  "text" : "RT @chadsansing: long-form sci-fi meditation re: future of teaching http:\/\/t.co\/KwM1cwsA released in response to #GatesReport, news re:  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GatesReport",
        "indices" : [ 96, 108 ]
      } ],
      "urls" : [ {
        "indices" : [ 51, 71 ],
        "url" : "http:\/\/t.co\/KwM1cwsA",
        "expanded_url" : "http:\/\/bit.ly\/SrqEkY",
        "display_url" : "bit.ly\/SrqEkY"
      } ]
    },
    "geo" : { },
    "id_str" : "290240098983878656",
    "text" : "long-form sci-fi meditation re: future of teaching http:\/\/t.co\/KwM1cwsA released in response to #GatesReport, news re: Aaron Swartz",
    "id" : 290240098983878656,
    "created_at" : "2013-01-12 23:33:26 +0000",
    "user" : {
      "name" : "chadsansing",
      "screen_name" : "chadsansing",
      "protected" : false,
      "id_str" : "76810409",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712740640111652869\/NvEwLRy__normal.jpg",
      "id" : 76810409,
      "verified" : false
    }
  },
  "id" : 290243693804400640,
  "created_at" : "2013-01-12 23:47:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 40 ],
      "url" : "http:\/\/t.co\/eSNrRPzj",
      "expanded_url" : "http:\/\/lessig.tumblr.com\/post\/40347463044\/prosecutor-as-bully",
      "display_url" : "lessig.tumblr.com\/post\/403474630\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "290197359567192065",
  "text" : "Prosecutor as bully http:\/\/t.co\/eSNrRPzj",
  "id" : 290197359567192065,
  "created_at" : "2013-01-12 20:43:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 0, 13 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "290138240093130752",
  "geo" : { },
  "id_str" : "290193375578161152",
  "in_reply_to_user_id" : 88655243,
  "text" : "@rosemerebard v grateful for the share Rose, hope yr w\/e is going well.",
  "id" : 290193375578161152,
  "in_reply_to_status_id" : 290138240093130752,
  "created_at" : "2013-01-12 20:27:46 +0000",
  "in_reply_to_screen_name" : "rosemerebard",
  "in_reply_to_user_id_str" : "88655243",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Smashing Magazine",
      "screen_name" : "smashingmag",
      "indices" : [ 3, 15 ],
      "id_str" : "15736190",
      "id" : 15736190
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "besig",
      "indices" : [ 116, 122 ]
    }, {
      "text" : "businessenglish",
      "indices" : [ 123, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/5E25lwKM",
      "expanded_url" : "http:\/\/bit.ly\/10hg2bF",
      "display_url" : "bit.ly\/10hg2bF"
    } ]
  },
  "geo" : { },
  "id_str" : "290138049994706944",
  "text" : "RT @smashingmag A collection of well-done product announcement videos, great for inspiration - http:\/\/t.co\/5E25lwKM #besig #businessenglish",
  "id" : 290138049994706944,
  "created_at" : "2013-01-12 16:47:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Smashing Magazine",
      "screen_name" : "smashingmag",
      "indices" : [ 14, 26 ],
      "id_str" : "15736190",
      "id" : 15736190
    }, {
      "name" : "jongmin kim",
      "screen_name" : "cmiscm",
      "indices" : [ 112, 119 ],
      "id_str" : "66087144",
      "id" : 66087144
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 142 ],
      "url" : "http:\/\/t.co\/ha1Cs0FV",
      "expanded_url" : "http:\/\/fff.cmiscm.com\/#!\/main",
      "display_url" : "fff.cmiscm.com\/#!\/main"
    } ]
  },
  "geo" : { },
  "id_str" : "290121608092344321",
  "text" : "whoah! &gt;RT @smashingmag A series of amazing Web experiments and interactive experiences, based with HTML5 by @cmiscm - http:\/\/t.co\/ha1Cs0FV",
  "id" : 290121608092344321,
  "created_at" : "2013-01-12 15:42:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lexicalzombie",
      "indices" : [ 36, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "290115328724320256",
  "text" : "\/humanitarian intervention\/ another #lexicalzombie seems u just can't kill a poor excuse",
  "id" : 290115328724320256,
  "created_at" : "2013-01-12 15:17:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/aLQwoSsZ",
      "expanded_url" : "http:\/\/johnhilley.blogspot.co.uk\/2013\/01\/gulp-friction-testy-tino-whacks-guru.html",
      "display_url" : "johnhilley.blogspot.co.uk\/2013\/01\/gulp-f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "290104198140403712",
  "text" : "Gulp, friction: testy Tino whacks the Guru http:\/\/t.co\/aLQwoSsZ",
  "id" : 290104198140403712,
  "created_at" : "2013-01-12 14:33:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "290074479630098433",
  "text" : "Mali, French diplomacy - bombing you is  helping you, mais bien s\u00FBr.",
  "id" : 290074479630098433,
  "created_at" : "2013-01-12 12:35:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "290052311290617856",
  "geo" : { },
  "id_str" : "290072373879787521",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow sleep well mate!",
  "id" : 290072373879787521,
  "in_reply_to_status_id" : 290052311290617856,
  "created_at" : "2013-01-12 12:26:57 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/wRmWYFuv",
      "expanded_url" : "http:\/\/www.craigmurray.org.uk\/archives\/2013\/01\/defend-stephen-sizer\/",
      "display_url" : "craigmurray.org.uk\/archives\/2013\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "290071658918735872",
  "text" : "when sharing links is being attacked &gt; Defend Stephen Sizer http:\/\/t.co\/wRmWYFuv",
  "id" : 290071658918735872,
  "created_at" : "2013-01-12 12:24:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Alexander",
      "screen_name" : "BryanAlexander",
      "indices" : [ 3, 18 ],
      "id_str" : "755991",
      "id" : 755991
    }, {
      "name" : "Estelle Metayer",
      "screen_name" : "Competia",
      "indices" : [ 23, 32 ],
      "id_str" : "16407746",
      "id" : 16407746
    }, {
      "name" : "Shashi Bellamkonda",
      "screen_name" : "shashib",
      "indices" : [ 113, 121 ],
      "id_str" : "1221471",
      "id" : 1221471
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/SAwSqU3r",
      "expanded_url" : "http:\/\/j.mp\/ZPzZFi",
      "display_url" : "j.mp\/ZPzZFi"
    } ]
  },
  "geo" : { },
  "id_str" : "289819492610088960",
  "text" : "RT @BryanAlexander: RT @Competia: Disruption: Amazon introduces iTunes rival \u2014 AutoRip   http:\/\/t.co\/SAwSqU3r RT @shashib &lt;I await th ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Estelle Metayer",
        "screen_name" : "Competia",
        "indices" : [ 3, 12 ],
        "id_str" : "16407746",
        "id" : 16407746
      }, {
        "name" : "Shashi Bellamkonda",
        "screen_name" : "shashib",
        "indices" : [ 93, 101 ],
        "id_str" : "1221471",
        "id" : 1221471
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 89 ],
        "url" : "http:\/\/t.co\/SAwSqU3r",
        "expanded_url" : "http:\/\/j.mp\/ZPzZFi",
        "display_url" : "j.mp\/ZPzZFi"
      } ]
    },
    "geo" : { },
    "id_str" : "289802697333407744",
    "text" : "RT @Competia: Disruption: Amazon introduces iTunes rival \u2014 AutoRip   http:\/\/t.co\/SAwSqU3r RT @shashib &lt;I await the ebook version",
    "id" : 289802697333407744,
    "created_at" : "2013-01-11 18:35:21 +0000",
    "user" : {
      "name" : "Bryan Alexander",
      "screen_name" : "BryanAlexander",
      "protected" : false,
      "id_str" : "755991",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/654391499686313986\/1Fx2eBCq_normal.jpg",
      "id" : 755991,
      "verified" : false
    }
  },
  "id" : 289819492610088960,
  "created_at" : "2013-01-11 19:42:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/wIBYC3A7",
      "expanded_url" : "http:\/\/electronicintifada.net\/content\/bbcs-cruel-excuses-ignoring-palestinian-hunger-strikes\/12072",
      "display_url" : "electronicintifada.net\/content\/bbcs-c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "289812120344875008",
  "text" : "BBC\u2019s cruel excuses for ignoring Palestinian hunger strikes http:\/\/t.co\/wIBYC3A7",
  "id" : 289812120344875008,
  "created_at" : "2013-01-11 19:12:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "Jim Scrivener",
      "screen_name" : "jimscriv",
      "indices" : [ 12, 21 ],
      "id_str" : "130149739",
      "id" : 130149739
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289782706026446848",
  "geo" : { },
  "id_str" : "289787105821982721",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan @jimscriv heard they run with the collocation monsters!",
  "id" : 289787105821982721,
  "in_reply_to_status_id" : 289782706026446848,
  "created_at" : "2013-01-11 17:33:24 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289778769839939585",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson minimum effective dossing sounds like my kind of thing :) thks v much for supporting presentation post",
  "id" : 289778769839939585,
  "created_at" : "2013-01-11 17:00:17 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "Jim Scrivener",
      "screen_name" : "jimscriv",
      "indices" : [ 12, 21 ],
      "id_str" : "130149739",
      "id" : 130149739
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289765127681622018",
  "geo" : { },
  "id_str" : "289766131219189760",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan @jimscriv zombies are never good :)",
  "id" : 289766131219189760,
  "in_reply_to_status_id" : 289765127681622018,
  "created_at" : "2013-01-11 16:10:03 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289764765771890688",
  "text" : "just realised why my cup of tea was gettting stronger, had left bag in it! bleurgh!",
  "id" : 289764765771890688,
  "created_at" : "2013-01-11 16:04:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Global English TEFL,",
      "screen_name" : "GlobalEnglishUK",
      "indices" : [ 0, 16 ],
      "id_str" : "130105161",
      "id" : 130105161
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289376329625919488",
  "geo" : { },
  "id_str" : "289764239671959552",
  "in_reply_to_user_id" : 130105161,
  "text" : "@GlobalEnglishUK great nice to connect online with you :)",
  "id" : 289764239671959552,
  "in_reply_to_status_id" : 289376329625919488,
  "created_at" : "2013-01-11 16:02:32 +0000",
  "in_reply_to_screen_name" : "GlobalEnglishUK",
  "in_reply_to_user_id_str" : "130105161",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 40, 55 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 68, 72 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 132, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/FRZWmKSY",
      "expanded_url" : "http:\/\/elt2.co.uk\/UUJulj",
      "display_url" : "elt2.co.uk\/UUJulj"
    } ]
  },
  "geo" : { },
  "id_str" : "289762603566260224",
  "text" : "allthe news that's fit for class &gt;MT @MrChrisJWilson round up of #elt this week. add any links I've missed http:\/\/t.co\/FRZWmKSY  #eltchat",
  "id" : 289762603566260224,
  "created_at" : "2013-01-11 15:56:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    }, {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 17, 28 ],
      "id_str" : "144663117",
      "id" : 144663117
    }, {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 29, 44 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289757385931751426",
  "geo" : { },
  "id_str" : "289758995374292992",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin @kevchanwow @MrChrisJWilson thanks Mike! have a grt w\/e!",
  "id" : 289758995374292992,
  "in_reply_to_status_id" : 289757385931751426,
  "created_at" : "2013-01-11 15:41:42 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289757302075039745",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson thx for comments on feedback post, just replied",
  "id" : 289757302075039745,
  "created_at" : "2013-01-11 15:34:58 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    }, {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 12, 27 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289741746152300544",
  "geo" : { },
  "id_str" : "289757107379654656",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow @MrChrisJWilson cheers kev! not yet got round to tweeting this so thanks for the share! here's to a good w\/e!",
  "id" : 289757107379654656,
  "in_reply_to_status_id" : 289741746152300544,
  "created_at" : "2013-01-11 15:34:12 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willy C. Cardoso",
      "screen_name" : "willycard",
      "indices" : [ 0, 10 ],
      "id_str" : "102353142",
      "id" : 102353142
    }, {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 34, 45 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289639566896414720",
  "geo" : { },
  "id_str" : "289643715285360641",
  "in_reply_to_user_id" : 102353142,
  "text" : "@willycard author is on twitter - @tornhalves but i think he rarely uses the \"forever-friends\" channel for chat :)",
  "id" : 289643715285360641,
  "in_reply_to_status_id" : 289639566896414720,
  "created_at" : "2013-01-11 08:03:37 +0000",
  "in_reply_to_screen_name" : "willycard",
  "in_reply_to_user_id_str" : "102353142",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289343165171920896",
  "geo" : { },
  "id_str" : "289343517543788544",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson no no link shared but no worries was not much of a comment!",
  "id" : 289343517543788544,
  "in_reply_to_status_id" : 289343165171920896,
  "created_at" : "2013-01-10 12:10:44 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289342514857648128",
  "geo" : { },
  "id_str" : "289342864016683008",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson so i can use my WP account and be notified when comments added. also am sure sent a new comment lost in ether?",
  "id" : 289342864016683008,
  "in_reply_to_status_id" : 289342514857648128,
  "created_at" : "2013-01-10 12:08:09 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289341513790537728",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson been meaning to ask could u add a wordpress comment feature to yr blog? ta",
  "id" : 289341513790537728,
  "created_at" : "2013-01-10 12:02:47 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Willingham",
      "screen_name" : "DTWillingham",
      "indices" : [ 3, 16 ],
      "id_str" : "84619537",
      "id" : 84619537
    }, {
      "name" : "Amy Woolard",
      "screen_name" : "awoo_",
      "indices" : [ 99, 105 ],
      "id_str" : "194245430",
      "id" : 194245430
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/lMfBZZQH",
      "expanded_url" : "http:\/\/www.insidehighered.com\/news\/2013\/01\/09\/jstor-offer-limited-free-access-content-1200-journals",
      "display_url" : "insidehighered.com\/news\/2013\/01\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "289324102999756800",
  "text" : "RT @DTWillingham: Nice! JSTOR (huge journal database) will allow free access: 3 articles\/2 wks. HT @awoo_ http:\/\/t.co\/lMfBZZQH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Amy Woolard",
        "screen_name" : "awoo_",
        "indices" : [ 81, 87 ],
        "id_str" : "194245430",
        "id" : 194245430
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 108 ],
        "url" : "http:\/\/t.co\/lMfBZZQH",
        "expanded_url" : "http:\/\/www.insidehighered.com\/news\/2013\/01\/09\/jstor-offer-limited-free-access-content-1200-journals",
        "display_url" : "insidehighered.com\/news\/2013\/01\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "289122680509198339",
    "text" : "Nice! JSTOR (huge journal database) will allow free access: 3 articles\/2 wks. HT @awoo_ http:\/\/t.co\/lMfBZZQH",
    "id" : 289122680509198339,
    "created_at" : "2013-01-09 21:33:13 +0000",
    "user" : {
      "name" : "Daniel Willingham",
      "screen_name" : "DTWillingham",
      "protected" : false,
      "id_str" : "84619537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1815678310\/Daniel_Willingham_Color_lowres_normal.JPG",
      "id" : 84619537,
      "verified" : false
    }
  },
  "id" : 289324102999756800,
  "created_at" : "2013-01-10 10:53:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289322294990483456",
  "geo" : { },
  "id_str" : "289323136313327617",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson too bad the second one but as i don't yet know when i will be free may hit u up for the link to the morning session",
  "id" : 289323136313327617,
  "in_reply_to_status_id" : 289322294990483456,
  "created_at" : "2013-01-10 10:49:45 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    }, {
      "name" : "Chiew Pang",
      "screen_name" : "aClilToClimb",
      "indices" : [ 16, 29 ],
      "id_str" : "76160458",
      "id" : 76160458
    }, {
      "name" : "John Hughes",
      "screen_name" : "johnhugheselt",
      "indices" : [ 30, 44 ],
      "id_str" : "20094894",
      "id" : 20094894
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 45, 54 ],
      "id_str" : "18602422",
      "id" : 18602422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289306457168560128",
  "geo" : { },
  "id_str" : "289320176250400768",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson @aClilToClimb @johnhugheselt @muranava ta signed up i am hoping to be free then :)",
  "id" : 289320176250400768,
  "in_reply_to_status_id" : 289306457168560128,
  "created_at" : "2013-01-10 10:37:59 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Brown",
      "screen_name" : "dBr_wn",
      "indices" : [ 0, 7 ],
      "id_str" : "704177088",
      "id" : 704177088
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289134277986230272",
  "geo" : { },
  "id_str" : "289320028623486978",
  "in_reply_to_user_id" : 704177088,
  "text" : "@dBr_wn pleasure, hoping to get some time to read your instructions more carefully :)",
  "id" : 289320028623486978,
  "in_reply_to_status_id" : 289134277986230272,
  "created_at" : "2013-01-10 10:37:24 +0000",
  "in_reply_to_screen_name" : "dBr_wn",
  "in_reply_to_user_id_str" : "704177088",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Naomi Epstein",
      "screen_name" : "naomishema",
      "indices" : [ 10, 21 ],
      "id_str" : "228469472",
      "id" : 228469472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289111578266177537",
  "geo" : { },
  "id_str" : "289113239940395009",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava @naomishema ugh i meant to say i can see why edmodo is popular :)",
  "id" : 289113239940395009,
  "in_reply_to_status_id" : 289111578266177537,
  "created_at" : "2013-01-09 20:55:42 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naomi Epstein",
      "screen_name" : "naomishema",
      "indices" : [ 0, 11 ],
      "id_str" : "228469472",
      "id" : 228469472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289111793358499840",
  "geo" : { },
  "id_str" : "289112651416604674",
  "in_reply_to_user_id" : 228469472,
  "text" : "@naomishema comm in the sense e.g. how transportable is content u upload, will future terms mean intrusive 3rd party vendors ?",
  "id" : 289112651416604674,
  "in_reply_to_status_id" : 289111793358499840,
  "created_at" : "2013-01-09 20:53:22 +0000",
  "in_reply_to_screen_name" : "naomishema",
  "in_reply_to_user_id_str" : "228469472",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naomi Epstein",
      "screen_name" : "naomishema",
      "indices" : [ 0, 11 ],
      "id_str" : "228469472",
      "id" : 228469472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289102872782708737",
  "geo" : { },
  "id_str" : "289111578266177537",
  "in_reply_to_user_id" : 228469472,
  "text" : "@naomishema pleasure, wary of commercial ed platforms when open  ones like moodle are available, thgh i can see why moodle is pop",
  "id" : 289111578266177537,
  "in_reply_to_status_id" : 289102872782708737,
  "created_at" : "2013-01-09 20:49:06 +0000",
  "in_reply_to_screen_name" : "naomishema",
  "in_reply_to_user_id_str" : "228469472",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blair Teacher",
      "screen_name" : "blairteacher",
      "indices" : [ 3, 16 ],
      "id_str" : "20932918",
      "id" : 20932918
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/afPdzAVH",
      "expanded_url" : "http:\/\/m.guardian.co.uk\/commentisfree\/2013\/jan\/09\/redundancy-life-wasted-threat",
      "display_url" : "m.guardian.co.uk\/commentisfree\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "289106797556539395",
  "text" : "RT @blairteacher: Redundancy is a life wasted. I am now nothing but a threat http:\/\/t.co\/afPdzAVH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 79 ],
        "url" : "http:\/\/t.co\/afPdzAVH",
        "expanded_url" : "http:\/\/m.guardian.co.uk\/commentisfree\/2013\/jan\/09\/redundancy-life-wasted-threat",
        "display_url" : "m.guardian.co.uk\/commentisfree\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "289092464332120064",
    "text" : "Redundancy is a life wasted. I am now nothing but a threat http:\/\/t.co\/afPdzAVH",
    "id" : 289092464332120064,
    "created_at" : "2013-01-09 19:33:09 +0000",
    "user" : {
      "name" : "Blair Teacher",
      "screen_name" : "blairteacher",
      "protected" : false,
      "id_str" : "20932918",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/473405104729493504\/mK908m7N_normal.jpeg",
      "id" : 20932918,
      "verified" : false
    }
  },
  "id" : 289106797556539395,
  "created_at" : "2013-01-09 20:30:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nagehan Tunar",
      "screen_name" : "stiiiv",
      "indices" : [ 0, 7 ],
      "id_str" : "799058600",
      "id" : 799058600
    }, {
      "name" : "Dan Ruelle",
      "screen_name" : "danrmitvn",
      "indices" : [ 8, 18 ],
      "id_str" : "125853393",
      "id" : 125853393
    }, {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 19, 30 ],
      "id_str" : "282659955",
      "id" : 282659955
    }, {
      "name" : "Michael Griffiths",
      "screen_name" : "trylingual",
      "indices" : [ 31, 42 ],
      "id_str" : "20420600",
      "id" : 20420600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288969072941596672",
  "geo" : { },
  "id_str" : "289091346684334080",
  "in_reply_to_user_id" : 69068757,
  "text" : "@stiiiv @danrmitvn @teflerinha @trylingual yr welcome :)",
  "id" : 289091346684334080,
  "in_reply_to_status_id" : 288969072941596672,
  "created_at" : "2013-01-09 19:28:42 +0000",
  "in_reply_to_screen_name" : "stiivkirk",
  "in_reply_to_user_id_str" : "69068757",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stevemuir",
      "screen_name" : "steve_muir",
      "indices" : [ 0, 11 ],
      "id_str" : "18537988",
      "id" : 18537988
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289086669775310849",
  "geo" : { },
  "id_str" : "289091087392456704",
  "in_reply_to_user_id" : 18537988,
  "text" : "@steve_muir a pleasure fr sure :)",
  "id" : 289091087392456704,
  "in_reply_to_status_id" : 289086669775310849,
  "created_at" : "2013-01-09 19:27:40 +0000",
  "in_reply_to_screen_name" : "steve_muir",
  "in_reply_to_user_id_str" : "18537988",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 3, 11 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/rVs8nOfR",
      "expanded_url" : "http:\/\/e.g.in",
      "display_url" : "e.g.in"
    }, {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/XiZsmktC",
      "expanded_url" : "https:\/\/docs.google.com\/document\/d\/1ugq-HiWcYk0V1WIfMLGybhTPh-c1Nh9LvPdF3v3yrAA\/edit",
      "display_url" : "docs.google.com\/document\/d\/1ug\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "289090819300917250",
  "text" : "RT @seburnt: What tired expressions do you hear still used (http:\/\/t.co\/rVs8nOfR essays, conversation, business, etc.)? https:\/\/t.co\/XiZ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 67 ],
        "url" : "http:\/\/t.co\/rVs8nOfR",
        "expanded_url" : "http:\/\/e.g.in",
        "display_url" : "e.g.in"
      }, {
        "indices" : [ 107, 128 ],
        "url" : "https:\/\/t.co\/XiZsmktC",
        "expanded_url" : "https:\/\/docs.google.com\/document\/d\/1ugq-HiWcYk0V1WIfMLGybhTPh-c1Nh9LvPdF3v3yrAA\/edit",
        "display_url" : "docs.google.com\/document\/d\/1ug\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "288867533459697664",
    "text" : "What tired expressions do you hear still used (http:\/\/t.co\/rVs8nOfR essays, conversation, business, etc.)? https:\/\/t.co\/XiZsmktC",
    "id" : 288867533459697664,
    "created_at" : "2013-01-09 04:39:21 +0000",
    "user" : {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "protected" : false,
      "id_str" : "20650366",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/743248377563971584\/9d9xlHlz_normal.jpg",
      "id" : 20650366,
      "verified" : false
    }
  },
  "id" : 289090819300917250,
  "created_at" : "2013-01-09 19:26:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Whitby",
      "screen_name" : "tomwhitby",
      "indices" : [ 0, 10 ],
      "id_str" : "17762060",
      "id" : 17762060
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289055237472395264",
  "geo" : { },
  "id_str" : "289079470936186880",
  "in_reply_to_user_id" : 17762060,
  "text" : "@tomwhitby anyone got a link to show for non-US peeps? ta",
  "id" : 289079470936186880,
  "in_reply_to_status_id" : 289055237472395264,
  "created_at" : "2013-01-09 18:41:31 +0000",
  "in_reply_to_screen_name" : "tomwhitby",
  "in_reply_to_user_id_str" : "17762060",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Global English TEFL,",
      "screen_name" : "GlobalEnglishUK",
      "indices" : [ 0, 16 ],
      "id_str" : "130105161",
      "id" : 130105161
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289060876600893440",
  "geo" : { },
  "id_str" : "289075793676603393",
  "in_reply_to_user_id" : 130105161,
  "text" : "@GlobalEnglishUK fab appreciate the share! r u all one person?",
  "id" : 289075793676603393,
  "in_reply_to_status_id" : 289060876600893440,
  "created_at" : "2013-01-09 18:26:54 +0000",
  "in_reply_to_screen_name" : "GlobalEnglishUK",
  "in_reply_to_user_id_str" : "130105161",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Louisa Walsh",
      "screen_name" : "PhoneEnglishUK",
      "indices" : [ 0, 15 ],
      "id_str" : "130121853",
      "id" : 130121853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289060874478575616",
  "geo" : { },
  "id_str" : "289075649811980289",
  "in_reply_to_user_id" : 130121853,
  "text" : "@PhoneEnglishUK thank you kindly for share!",
  "id" : 289075649811980289,
  "in_reply_to_status_id" : 289060874478575616,
  "created_at" : "2013-01-09 18:26:20 +0000",
  "in_reply_to_screen_name" : "PhoneEnglishUK",
  "in_reply_to_user_id_str" : "130121853",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TEFL4Christians",
      "screen_name" : "TEFL4Christians",
      "indices" : [ 0, 16 ],
      "id_str" : "862831646",
      "id" : 862831646
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289060872595312640",
  "geo" : { },
  "id_str" : "289075553355583488",
  "in_reply_to_user_id" : 862831646,
  "text" : "@TEFL4Christians many thanks for RT :)",
  "id" : 289075553355583488,
  "in_reply_to_status_id" : 289060872595312640,
  "created_at" : "2013-01-09 18:25:57 +0000",
  "in_reply_to_screen_name" : "TEFL4Christians",
  "in_reply_to_user_id_str" : "862831646",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Harmer",
      "screen_name" : "Harmerj",
      "indices" : [ 3, 11 ],
      "id_str" : "21094022",
      "id" : 21094022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289051616970145792",
  "text" : "on @Harmerj latest post there seems to be an interesting article on feedback but it is behind a paywall up the open edu resource movement!",
  "id" : 289051616970145792,
  "created_at" : "2013-01-09 16:50:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stevemuir",
      "screen_name" : "steve_muir",
      "indices" : [ 49, 60 ],
      "id_str" : "18537988",
      "id" : 18537988
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/378S1xlW",
      "expanded_url" : "http:\/\/allatc.wordpress.com\/2013\/01\/08\/dumb-ways-to-die\/",
      "display_url" : "allatc.wordpress.com\/2013\/01\/08\/dum\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "289045897134878720",
  "text" : "Allatc Dumb ways to die Another great lesson via @steve_muir http:\/\/t.co\/378S1xlW",
  "id" : 289045897134878720,
  "created_at" : "2013-01-09 16:28:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Wheeler",
      "screen_name" : "timbuckteeth",
      "indices" : [ 3, 16 ],
      "id_str" : "11435832",
      "id" : 11435832
    }, {
      "name" : "Leigh Graves Wolf",
      "screen_name" : "gravesle",
      "indices" : [ 21, 30 ],
      "id_str" : "11092692",
      "id" : 11092692
    }, {
      "name" : "Buffer",
      "screen_name" : "bufferapp",
      "indices" : [ 67, 77 ],
      "id_str" : "1510622484",
      "id" : 1510622484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289035580279504896",
  "text" : "RT @timbuckteeth: BT @gravesle: If you have lots of info to tweet, @bufferapp is a great way to spread it out and not overwhelm people",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Leigh Graves Wolf",
        "screen_name" : "gravesle",
        "indices" : [ 3, 12 ],
        "id_str" : "11092692",
        "id" : 11092692
      }, {
        "name" : "Buffer",
        "screen_name" : "bufferapp",
        "indices" : [ 49, 59 ],
        "id_str" : "1510622484",
        "id" : 1510622484
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "289034796582178816",
    "text" : "BT @gravesle: If you have lots of info to tweet, @bufferapp is a great way to spread it out and not overwhelm people",
    "id" : 289034796582178816,
    "created_at" : "2013-01-09 15:44:00 +0000",
    "user" : {
      "name" : "Steve Wheeler",
      "screen_name" : "timbuckteeth",
      "protected" : false,
      "id_str" : "11435832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/836350581\/timbo_normal.jpg",
      "id" : 11435832,
      "verified" : false
    }
  },
  "id" : 289035580279504896,
  "created_at" : "2013-01-09 15:47:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Brown",
      "screen_name" : "dBr_wn",
      "indices" : [ 86, 93 ],
      "id_str" : "704177088",
      "id" : 704177088
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/QIyGpa4K",
      "expanded_url" : "http:\/\/wp.me\/p24Rm0-8Z",
      "display_url" : "wp.me\/p24Rm0-8Z"
    } ]
  },
  "geo" : { },
  "id_str" : "289033335446052864",
  "text" : "good stuff &gt; Business English with Office World http:\/\/t.co\/QIyGpa4K via @CrSpkELT @dBr_wn",
  "id" : 289033335446052864,
  "created_at" : "2013-01-09 15:38:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Simpson",
      "screen_name" : "yearinthelifeof",
      "indices" : [ 0, 16 ],
      "id_str" : "78543378",
      "id" : 78543378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289029031716868096",
  "in_reply_to_user_id" : 78543378,
  "text" : "@yearinthelifeof thanks for RT Adam! enjoyed yr creative story lesson. is that a record time for using same lesson? ;)",
  "id" : 289029031716868096,
  "created_at" : "2013-01-09 15:21:05 +0000",
  "in_reply_to_screen_name" : "yearinthelifeof",
  "in_reply_to_user_id_str" : "78543378",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289027756900114434",
  "geo" : { },
  "id_str" : "289028353611153408",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson very nice idea! i'll nick that :)",
  "id" : 289028353611153408,
  "in_reply_to_status_id" : 289027756900114434,
  "created_at" : "2013-01-09 15:18:24 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289026290160377856",
  "geo" : { },
  "id_str" : "289027238299590656",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson thanks though ofc quite an obvious activity but simple is usually the best as my class clearly responded to it :)",
  "id" : 289027238299590656,
  "in_reply_to_status_id" : 289026290160377856,
  "created_at" : "2013-01-09 15:13:58 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 12, 27 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 106, 114 ]
    }, {
      "text" : "elt",
      "indices" : [ 115, 119 ]
    }, {
      "text" : "tefl",
      "indices" : [ 120, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/ASBVW5eT",
      "expanded_url" : "http:\/\/elt2.co.uk\/UKsJJD",
      "display_url" : "elt2.co.uk\/UKsJJD"
    } ]
  },
  "geo" : { },
  "id_str" : "289026631161491456",
  "text" : "NICE! :) RT @MrChrisJWilson The first ever ELTSquared podcast. Becoming a linchpin. http:\/\/t.co\/ASBVW5eT  #eltchat #elt #tefl",
  "id" : 289026631161491456,
  "created_at" : "2013-01-09 15:11:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 83, 91 ]
    }, {
      "text" : "efl",
      "indices" : [ 92, 96 ]
    }, {
      "text" : "tefl",
      "indices" : [ 97, 102 ]
    }, {
      "text" : "esl",
      "indices" : [ 103, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/NhtFgr37",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-fJ",
      "display_url" : "wp.me\/pgHyE-fJ"
    } ]
  },
  "geo" : { },
  "id_str" : "289025992817786880",
  "text" : "new blog post Runaround - 50 British inventions, scan reading http:\/\/t.co\/NhtFgr37 #eltchat #efl #tefl #esl",
  "id" : 289025992817786880,
  "created_at" : "2013-01-09 15:09:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jess Thirlway",
      "screen_name" : "Jess_Thirlway",
      "indices" : [ 0, 14 ],
      "id_str" : "151182674",
      "id" : 151182674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288762478895190016",
  "geo" : { },
  "id_str" : "288786577562415104",
  "in_reply_to_user_id" : 151182674,
  "text" : "@Jess_Thirlway is that like a how many X can you eat in Y minutes kind of competition? is it a new olympic sport? we must be told!",
  "id" : 288786577562415104,
  "in_reply_to_status_id" : 288762478895190016,
  "created_at" : "2013-01-08 23:17:40 +0000",
  "in_reply_to_screen_name" : "Jess_Thirlway",
  "in_reply_to_user_id_str" : "151182674",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luiz Otavio Barros",
      "screen_name" : "luizotavioELT",
      "indices" : [ 0, 14 ],
      "id_str" : "54798894",
      "id" : 54798894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288754429933518848",
  "geo" : { },
  "id_str" : "288755290499850240",
  "in_reply_to_user_id" : 54798894,
  "text" : "@luizotavioELT pleasure and thank you for a great activity!",
  "id" : 288755290499850240,
  "in_reply_to_status_id" : 288754429933518848,
  "created_at" : "2013-01-08 21:13:20 +0000",
  "in_reply_to_screen_name" : "luizotavioELT",
  "in_reply_to_user_id_str" : "54798894",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luiz Otavio Barros",
      "screen_name" : "luizotavioELT",
      "indices" : [ 0, 14 ],
      "id_str" : "54798894",
      "id" : 54798894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288753734685700096",
  "geo" : { },
  "id_str" : "288754699493056512",
  "in_reply_to_user_id" : 54798894,
  "text" : "@luizotavioELT one more Q, for the slowdown i assume you used an audio of the song and not the video? looking to slowdown a video simply!",
  "id" : 288754699493056512,
  "in_reply_to_status_id" : 288753734685700096,
  "created_at" : "2013-01-08 21:10:59 +0000",
  "in_reply_to_screen_name" : "luizotavioELT",
  "in_reply_to_user_id_str" : "54798894",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luiz Otavio Barros",
      "screen_name" : "luizotavioELT",
      "indices" : [ 0, 14 ],
      "id_str" : "54798894",
      "id" : 54798894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288753112666210304",
  "geo" : { },
  "id_str" : "288753556918513664",
  "in_reply_to_user_id" : 54798894,
  "text" : "@luizotavioELT ah okay sorry  i was gettign confused since i was counting the syllables i heard! really great activity! i may use it",
  "id" : 288753556918513664,
  "in_reply_to_status_id" : 288753112666210304,
  "created_at" : "2013-01-08 21:06:27 +0000",
  "in_reply_to_screen_name" : "luizotavioELT",
  "in_reply_to_user_id_str" : "54798894",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Luiz Otavio Barros",
      "screen_name" : "luizotavioELT",
      "indices" : [ 10, 24 ],
      "id_str" : "54798894",
      "id" : 54798894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288752689276399617",
  "geo" : { },
  "id_str" : "288753158858084352",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava @luizotavioELT sorry that should have read i see [a lle ye so nu s]",
  "id" : 288753158858084352,
  "in_reply_to_status_id" : 288752689276399617,
  "created_at" : "2013-01-08 21:04:52 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luiz Otavio Barros",
      "screen_name" : "luizotavioELT",
      "indices" : [ 0, 14 ],
      "id_str" : "54798894",
      "id" : 54798894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288749920897347584",
  "geo" : { },
  "id_str" : "288752689276399617",
  "in_reply_to_user_id" : 54798894,
  "text" : "@luizotavioELT so for song one looking at the pink rectangles - u have [a lle ye so nus] and not \n[a lleye son nus] ?",
  "id" : 288752689276399617,
  "in_reply_to_status_id" : 288749920897347584,
  "created_at" : "2013-01-08 21:03:00 +0000",
  "in_reply_to_screen_name" : "luizotavioELT",
  "in_reply_to_user_id_str" : "54798894",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luiz Otavio Barros",
      "screen_name" : "luizotavioELT",
      "indices" : [ 0, 14 ],
      "id_str" : "54798894",
      "id" : 54798894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288746322696212480",
  "geo" : { },
  "id_str" : "288749761350217729",
  "in_reply_to_user_id" : 54798894,
  "text" : "@luizotavioELT what r u using the pink rectangles to show?",
  "id" : 288749761350217729,
  "in_reply_to_status_id" : 288746322696212480,
  "created_at" : "2013-01-08 20:51:22 +0000",
  "in_reply_to_screen_name" : "luizotavioELT",
  "in_reply_to_user_id_str" : "54798894",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luiz Otavio Barros",
      "screen_name" : "luizotavioELT",
      "indices" : [ 0, 14 ],
      "id_str" : "54798894",
      "id" : 54798894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288731483701669888",
  "geo" : { },
  "id_str" : "288746187362811905",
  "in_reply_to_user_id" : 54798894,
  "text" : "@luizotavioELT hi grt activity got some questions but can't seem to login into WP to leave comment? can i ask it here?",
  "id" : 288746187362811905,
  "in_reply_to_status_id" : 288731483701669888,
  "created_at" : "2013-01-08 20:37:10 +0000",
  "in_reply_to_screen_name" : "luizotavioELT",
  "in_reply_to_user_id_str" : "54798894",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    }, {
      "name" : "TEFL.net",
      "screen_name" : "TEFL",
      "indices" : [ 17, 22 ],
      "id_str" : "19223632",
      "id" : 19223632
    }, {
      "name" : "Chia Suan Chong",
      "screen_name" : "chiasuan",
      "indices" : [ 23, 32 ],
      "id_str" : "71588589",
      "id" : 71588589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288691167728640000",
  "geo" : { },
  "id_str" : "288691871004372992",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin @TEFL @chiasuan she was definitely rockin blogland in 2012 :)",
  "id" : 288691871004372992,
  "in_reply_to_status_id" : 288691167728640000,
  "created_at" : "2013-01-08 17:01:20 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Register",
      "screen_name" : "TheRegister",
      "indices" : [ 3, 15 ],
      "id_str" : "78012548",
      "id" : 78012548
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/wJhkOLbW",
      "expanded_url" : "http:\/\/reg.cx\/1Zxm",
      "display_url" : "reg.cx\/1Zxm"
    } ]
  },
  "geo" : { },
  "id_str" : "288688481352433665",
  "text" : "RT @theregister: Oracle, Xerox, Dell, CSC, Symantec accused of swerving UK tax: MPs reel off more titans 'avoiding bills on industria\u2026 h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/theregister.co.uk\/\" rel=\"nofollow\"\u003EVulture Central\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/wJhkOLbW",
        "expanded_url" : "http:\/\/reg.cx\/1Zxm",
        "display_url" : "reg.cx\/1Zxm"
      } ]
    },
    "geo" : { },
    "id_str" : "288662319079251968",
    "text" : "Oracle, Xerox, Dell, CSC, Symantec accused of swerving UK tax: MPs reel off more titans 'avoiding bills on industria\u2026 http:\/\/t.co\/wJhkOLbW",
    "id" : 288662319079251968,
    "created_at" : "2013-01-08 15:03:54 +0000",
    "user" : {
      "name" : "RegVulture",
      "screen_name" : "regvulture",
      "protected" : false,
      "id_str" : "381940039",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000641211038\/baad5b63e1d218692d68b03ae7a1057f_normal.png",
      "id" : 381940039,
      "verified" : false
    }
  },
  "id" : 288688481352433665,
  "created_at" : "2013-01-08 16:47:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288682767091392512",
  "geo" : { },
  "id_str" : "288686781312942080",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson too kind chris! how much of the video did you understand? most of it went over my head :\/",
  "id" : 288686781312942080,
  "in_reply_to_status_id" : 288682767091392512,
  "created_at" : "2013-01-08 16:41:06 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valentina Morgana",
      "screen_name" : "vmorgana",
      "indices" : [ 0, 9 ],
      "id_str" : "62479177",
      "id" : 62479177
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288673881135403009",
  "geo" : { },
  "id_str" : "288686019010781184",
  "in_reply_to_user_id" : 62479177,
  "text" : "@vmorgana wow ELT related presentation? will u blog it? ;) good luck!",
  "id" : 288686019010781184,
  "in_reply_to_status_id" : 288673881135403009,
  "created_at" : "2013-01-08 16:38:05 +0000",
  "in_reply_to_screen_name" : "vmorgana",
  "in_reply_to_user_id_str" : "62479177",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "edulang",
      "screen_name" : "edulang",
      "indices" : [ 0, 8 ],
      "id_str" : "2877002950",
      "id" : 2877002950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "288663225325719552",
  "in_reply_to_user_id" : 236921161,
  "text" : "@Edulang is that a sheep with a mohawk? or one who had got into a strange pointed star mishap? or maybe ate a Galette des Rois recently?",
  "id" : 288663225325719552,
  "created_at" : "2013-01-08 15:07:30 +0000",
  "in_reply_to_screen_name" : "wordtov",
  "in_reply_to_user_id_str" : "236921161",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ann foreman",
      "screen_name" : "ann_f",
      "indices" : [ 3, 9 ],
      "id_str" : "7173032",
      "id" : 7173032
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeachingEnglish",
      "indices" : [ 40, 56 ]
    }, {
      "text" : "BritishCouncil",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "elt",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/eSdJfABB",
      "expanded_url" : "http:\/\/on.fb.me\/VMog4H",
      "display_url" : "on.fb.me\/VMog4H"
    } ]
  },
  "geo" : { },
  "id_str" : "288656341466218496",
  "text" : "RT @ann_f: Shortlisted for this month\u2019s #TeachingEnglish blog award: Gemma Lunn \u2013 Room 101: lesson plan http:\/\/t.co\/eSdJfABB #BritishCou ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TeachingEnglish",
        "indices" : [ 29, 45 ]
      }, {
        "text" : "BritishCouncil",
        "indices" : [ 114, 129 ]
      }, {
        "text" : "elt",
        "indices" : [ 130, 134 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 113 ],
        "url" : "http:\/\/t.co\/eSdJfABB",
        "expanded_url" : "http:\/\/on.fb.me\/VMog4H",
        "display_url" : "on.fb.me\/VMog4H"
      } ]
    },
    "geo" : { },
    "id_str" : "288649004131172352",
    "text" : "Shortlisted for this month\u2019s #TeachingEnglish blog award: Gemma Lunn \u2013 Room 101: lesson plan http:\/\/t.co\/eSdJfABB #BritishCouncil #elt",
    "id" : 288649004131172352,
    "created_at" : "2013-01-08 14:11:00 +0000",
    "user" : {
      "name" : "ann foreman",
      "screen_name" : "ann_f",
      "protected" : false,
      "id_str" : "7173032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/562888648161390592\/HQIMryO8_normal.jpeg",
      "id" : 7173032,
      "verified" : false
    }
  },
  "id" : 288656341466218496,
  "created_at" : "2013-01-08 14:40:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 0, 13 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288638593533104129",
  "geo" : { },
  "id_str" : "288655674454466561",
  "in_reply_to_user_id" : 88655243,
  "text" : "@rosemerebard for sure of course :)",
  "id" : 288655674454466561,
  "in_reply_to_status_id" : 288638593533104129,
  "created_at" : "2013-01-08 14:37:30 +0000",
  "in_reply_to_screen_name" : "rosemerebard",
  "in_reply_to_user_id_str" : "88655243",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    }, {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 9, 24 ],
      "id_str" : "20760283",
      "id" : 20760283
    }, {
      "name" : "Miguel Mendoza",
      "screen_name" : "mike08",
      "indices" : [ 25, 32 ],
      "id_str" : "9444972",
      "id" : 9444972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288640642433810432",
  "geo" : { },
  "id_str" : "288655402768408577",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt @MrChrisJWilson @mike08 not outdated for the power-pc die-hards :)",
  "id" : 288655402768408577,
  "in_reply_to_status_id" : 288640642433810432,
  "created_at" : "2013-01-08 14:36:25 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Ruelle",
      "screen_name" : "danrmitvn",
      "indices" : [ 0, 10 ],
      "id_str" : "125853393",
      "id" : 125853393
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288637198927020032",
  "geo" : { },
  "id_str" : "288654998005501952",
  "in_reply_to_user_id" : 125853393,
  "text" : "@danrmitvn what's vietnam like for piratebay blocking? ;)",
  "id" : 288654998005501952,
  "in_reply_to_status_id" : 288637198927020032,
  "created_at" : "2013-01-08 14:34:49 +0000",
  "in_reply_to_screen_name" : "danrmitvn",
  "in_reply_to_user_id_str" : "125853393",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 0, 13 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288629687800967168",
  "geo" : { },
  "id_str" : "288631085527601152",
  "in_reply_to_user_id" : 88655243,
  "text" : "@rosemerebard was saying that if u write about your experience of using a corpus let me know :) or maybe a r of yr use of Bilbrough mem bk?",
  "id" : 288631085527601152,
  "in_reply_to_status_id" : 288629687800967168,
  "created_at" : "2013-01-08 12:59:47 +0000",
  "in_reply_to_screen_name" : "rosemerebard",
  "in_reply_to_user_id_str" : "88655243",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 0, 13 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288623082397114368",
  "geo" : { },
  "id_str" : "288625682139971585",
  "in_reply_to_user_id" : 88655243,
  "text" : "@rosemerebard also be v int to read any exp u have of using a corpus",
  "id" : 288625682139971585,
  "in_reply_to_status_id" : 288623082397114368,
  "created_at" : "2013-01-08 12:38:19 +0000",
  "in_reply_to_screen_name" : "rosemerebard",
  "in_reply_to_user_id_str" : "88655243",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 10, 23 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288624376767717376",
  "geo" : { },
  "id_str" : "288624855107125250",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava @rosemerebard doh meant ofc 2013, thgh do need to check more of yr 2012 posts as well :)",
  "id" : 288624855107125250,
  "in_reply_to_status_id" : 288624376767717376,
  "created_at" : "2013-01-08 12:35:02 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 0, 13 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288623082397114368",
  "geo" : { },
  "id_str" : "288624376767717376",
  "in_reply_to_user_id" : 88655243,
  "text" : "@rosemerebard that's really kind rose :) i like your writing style, gives a great classroom view. must check more of your posts in 2012!",
  "id" : 288624376767717376,
  "in_reply_to_status_id" : 288623082397114368,
  "created_at" : "2013-01-08 12:33:08 +0000",
  "in_reply_to_screen_name" : "rosemerebard",
  "in_reply_to_user_id_str" : "88655243",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valentina Morgana",
      "screen_name" : "vmorgana",
      "indices" : [ 0, 9 ],
      "id_str" : "62479177",
      "id" : 62479177
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288397971098312704",
  "geo" : { },
  "id_str" : "288623776919339008",
  "in_reply_to_user_id" : 62479177,
  "text" : "@vmorgana delighted for the share !",
  "id" : 288623776919339008,
  "in_reply_to_status_id" : 288397971098312704,
  "created_at" : "2013-01-08 12:30:45 +0000",
  "in_reply_to_screen_name" : "vmorgana",
  "in_reply_to_user_id_str" : "62479177",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/lrBzBlyx",
      "expanded_url" : "http:\/\/www.radiotimes.com\/news\/2013-01-08\/the-50-greatest-british-inventions",
      "display_url" : "radiotimes.com\/news\/2013-01-0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "288617271960678401",
  "text" : "on an online poll worldwideweb at 30% is leading, voted for sewage system!&gt; http:\/\/t.co\/lrBzBlyx",
  "id" : 288617271960678401,
  "created_at" : "2013-01-08 12:04:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/lrBzBlyx",
      "expanded_url" : "http:\/\/www.radiotimes.com\/news\/2013-01-08\/the-50-greatest-british-inventions",
      "display_url" : "radiotimes.com\/news\/2013-01-0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "288614047497207808",
  "text" : "interesting list of British invention&gt;http:\/\/t.co\/lrBzBlyx",
  "id" : 288614047497207808,
  "created_at" : "2013-01-08 11:52:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RegVulture",
      "screen_name" : "regvulture",
      "indices" : [ 118, 129 ],
      "id_str" : "381940039",
      "id" : 381940039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/T8Qz6Q72",
      "expanded_url" : "http:\/\/www.theregister.co.uk\/2013\/01\/08\/james_dyson_silicon_roundabout\/",
      "display_url" : "theregister.co.uk\/2013\/01\/08\/jam\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "288608480171008000",
  "text" : "'media 2.0 websluts' haha&gt;Sir James Dyson slams gov's 'obsession' with Silicon Roundabout http:\/\/t.co\/T8Qz6Q72 via @regvulture",
  "id" : 288608480171008000,
  "created_at" : "2013-01-08 11:29:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Krashen",
      "screen_name" : "skrashen",
      "indices" : [ 3, 12 ],
      "id_str" : "25624708",
      "id" : 25624708
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/PiQ0dFX5",
      "expanded_url" : "http:\/\/gu.com\/p\/3cp22",
      "display_url" : "gu.com\/p\/3cp22"
    } ]
  },
  "geo" : { },
  "id_str" : "288606093981143040",
  "text" : "RT @skrashen: Michael Rosen understands everything about education. This is amazing.  http:\/\/t.co\/PiQ0dFX5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 92 ],
        "url" : "http:\/\/t.co\/PiQ0dFX5",
        "expanded_url" : "http:\/\/gu.com\/p\/3cp22",
        "display_url" : "gu.com\/p\/3cp22"
      } ]
    },
    "geo" : { },
    "id_str" : "288559765246840832",
    "text" : "Michael Rosen understands everything about education. This is amazing.  http:\/\/t.co\/PiQ0dFX5",
    "id" : 288559765246840832,
    "created_at" : "2013-01-08 08:16:23 +0000",
    "user" : {
      "name" : "Stephen Krashen",
      "screen_name" : "skrashen",
      "protected" : false,
      "id_str" : "25624708",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/557399841769132032\/Ktp-bmWA_normal.jpeg",
      "id" : 25624708,
      "verified" : false
    }
  },
  "id" : 288606093981143040,
  "created_at" : "2013-01-08 11:20:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WIRED",
      "screen_name" : "WIRED",
      "indices" : [ 46, 52 ],
      "id_str" : "1344951",
      "id" : 1344951
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/kUs8Lhst",
      "expanded_url" : "http:\/\/oak.ctx.ly\/r\/1sqr",
      "display_url" : "oak.ctx.ly\/r\/1sqr"
    } ]
  },
  "geo" : { },
  "id_str" : "288595354146975744",
  "text" : "what chance for voter hope in tax wars?  &gt; @wired In Apple\u2019s War on Taxes, Surrender Costs $28 Billion http:\/\/t.co\/kUs8Lhst",
  "id" : 288595354146975744,
  "created_at" : "2013-01-08 10:37:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemma Lunn",
      "screen_name" : "GemL1",
      "indices" : [ 0, 6 ],
      "id_str" : "486146568",
      "id" : 486146568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288577428702498817",
  "geo" : { },
  "id_str" : "288579137197731840",
  "in_reply_to_user_id" : 486146568,
  "text" : "@GemL1 thanks for share!",
  "id" : 288579137197731840,
  "in_reply_to_status_id" : 288577428702498817,
  "created_at" : "2013-01-08 09:33:22 +0000",
  "in_reply_to_screen_name" : "GemL1",
  "in_reply_to_user_id_str" : "486146568",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EL Gazette",
      "screen_name" : "ELGazette",
      "indices" : [ 0, 10 ],
      "id_str" : "614186998",
      "id" : 614186998
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288576276082606080",
  "geo" : { },
  "id_str" : "288578219689508864",
  "in_reply_to_user_id" : 614186998,
  "text" : "@ELGazette funny and like all good parody very true!",
  "id" : 288578219689508864,
  "in_reply_to_status_id" : 288576276082606080,
  "created_at" : "2013-01-08 09:29:43 +0000",
  "in_reply_to_screen_name" : "ELGazette",
  "in_reply_to_user_id_str" : "614186998",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Simpson",
      "screen_name" : "yearinthelifeof",
      "indices" : [ 16, 32 ],
      "id_str" : "78543378",
      "id" : 78543378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/cLrT3Ctb",
      "expanded_url" : "http:\/\/www.teachthemenglish.com\/2013\/01\/nominated-for-the-teaching-english-post-of-the-month\/",
      "display_url" : "teachthemenglish.com\/2013\/01\/nomina\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "288577444519227392",
  "text" : "nice one!&gt;MT @yearinthelifeof (somehow) nominated for the Teaching English post of the month http:\/\/t.co\/cLrT3Ctb \u2026",
  "id" : 288577444519227392,
  "created_at" : "2013-01-08 09:26:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemma Lunn",
      "screen_name" : "GemL1",
      "indices" : [ 0, 6 ],
      "id_str" : "486146568",
      "id" : 486146568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288565259113996288",
  "geo" : { },
  "id_str" : "288577064242651136",
  "in_reply_to_user_id" : 486146568,
  "text" : "@GemL1 pleasure, and will take plunge soonish!",
  "id" : 288577064242651136,
  "in_reply_to_status_id" : 288565259113996288,
  "created_at" : "2013-01-08 09:25:08 +0000",
  "in_reply_to_screen_name" : "GemL1",
  "in_reply_to_user_id_str" : "486146568",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DjangoUnchained",
      "indices" : [ 51, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "288576335557832705",
  "text" : "damn if there is one near 3hr film to see make it  #DjangoUnchained it's banging!",
  "id" : 288576335557832705,
  "created_at" : "2013-01-08 09:22:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gerald Von Bourdeau",
      "screen_name" : "gvbourdeau",
      "indices" : [ 17, 28 ],
      "id_str" : "1029718040",
      "id" : 1029718040
    }, {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 42, 55 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/9gz62oRt",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-dY",
      "display_url" : "wp.me\/pgHyE-dY"
    } ]
  },
  "geo" : { },
  "id_str" : "288575349669908480",
  "text" : "many many thx to @gvbourdeau for like and @rosemerebard for like and the RT on last post http:\/\/t.co\/9gz62oRt",
  "id" : 288575349669908480,
  "created_at" : "2013-01-08 09:18:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    }, {
      "name" : "Daniel Willingham",
      "screen_name" : "DTWillingham",
      "indices" : [ 33, 46 ],
      "id_str" : "84619537",
      "id" : 84619537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288417426964627457",
  "geo" : { },
  "id_str" : "288574419360690176",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson pleasure, i have @DTWillingham on one of my lists for ed and cog sci. also mny thx for commenting on last post, hv replied",
  "id" : 288574419360690176,
  "in_reply_to_status_id" : 288417426964627457,
  "created_at" : "2013-01-08 09:14:37 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Gurr",
      "screen_name" : "tonygurr",
      "indices" : [ 0, 9 ],
      "id_str" : "257930941",
      "id" : 257930941
    }, {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 10, 25 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288405352934940672",
  "geo" : { },
  "id_str" : "288570516938297346",
  "in_reply_to_user_id" : 257930941,
  "text" : "@tonygurr @MrChrisJWilson wld hv like to be a fly on wall in that class! i have been pretty unstrange in my classes. nd to chnge it up!",
  "id" : 288570516938297346,
  "in_reply_to_status_id" : 288405352934940672,
  "created_at" : "2013-01-08 08:59:07 +0000",
  "in_reply_to_screen_name" : "tonygurr",
  "in_reply_to_user_id_str" : "257930941",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 62, 70 ]
    }, {
      "text" : "efl",
      "indices" : [ 71, 75 ]
    }, {
      "text" : "tefl",
      "indices" : [ 76, 81 ]
    }, {
      "text" : "tesol",
      "indices" : [ 82, 88 ]
    }, {
      "text" : "esl",
      "indices" : [ 89, 93 ]
    }, {
      "text" : "29c3",
      "indices" : [ 94, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/9gz62oRt",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-dY",
      "display_url" : "wp.me\/pgHyE-dY"
    } ]
  },
  "geo" : { },
  "id_str" : "288382084429512704",
  "text" : "New post Making Presentations - Openings http:\/\/t.co\/9gz62oRt #eltchat #efl #tefl #tesol #esl #29c3",
  "id" : 288382084429512704,
  "created_at" : "2013-01-07 20:30:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    }, {
      "name" : "Tony Gurr",
      "screen_name" : "tonygurr",
      "indices" : [ 16, 25 ],
      "id_str" : "257930941",
      "id" : 257930941
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288352636103704577",
  "geo" : { },
  "id_str" : "288354514854109186",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson @tonygurr hehe novel addition to teachers bag - toilet roll :)",
  "id" : 288354514854109186,
  "in_reply_to_status_id" : 288352636103704577,
  "created_at" : "2013-01-07 18:40:48 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    }, {
      "name" : "David Dodgson",
      "screen_name" : "DaveDodgson",
      "indices" : [ 17, 29 ],
      "id_str" : "112962705",
      "id" : 112962705
    }, {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 30, 45 ],
      "id_str" : "20760283",
      "id" : 20760283
    }, {
      "name" : "Jim George",
      "screen_name" : "oyajimbo",
      "indices" : [ 93, 102 ],
      "id_str" : "96103979",
      "id" : 96103979
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288351239182352385",
  "geo" : { },
  "id_str" : "288352124436373504",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin @DaveDodgson @MrChrisJWilson indeed some great comments on exams as well by @oyajimbo",
  "id" : 288352124436373504,
  "in_reply_to_status_id" : 288351239182352385,
  "created_at" : "2013-01-07 18:31:18 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288026901321224193",
  "geo" : { },
  "id_str" : "288350451324317697",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt tools like scoopit r fine for individual curation but to share why not give direct link? down with lazy bod curation!",
  "id" : 288350451324317697,
  "in_reply_to_status_id" : 288026901321224193,
  "created_at" : "2013-01-07 18:24:39 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemma Lunn",
      "screen_name" : "GemL1",
      "indices" : [ 137, 143 ],
      "id_str" : "486146568",
      "id" : 486146568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/pjRgOxlP",
      "expanded_url" : "http:\/\/wp.me\/p2NUdz-2e",
      "display_url" : "wp.me\/p2NUdz-2e"
    } ]
  },
  "geo" : { },
  "id_str" : "288346829731545089",
  "text" : "aswers more questions i had, less + less xcuse to recrd myself!&gt;Self-Observation Part 2: editing your script http:\/\/t.co\/pjRgOxlP via @GemL1",
  "id" : 288346829731545089,
  "created_at" : "2013-01-07 18:10:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Ruelle",
      "screen_name" : "danrmitvn",
      "indices" : [ 0, 10 ],
      "id_str" : "125853393",
      "id" : 125853393
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288301680909500417",
  "geo" : { },
  "id_str" : "288344721955385344",
  "in_reply_to_user_id" : 125853393,
  "text" : "@danrmitvn cheers for MT, that site has oth3r good stuff wrkshops like on presentations",
  "id" : 288344721955385344,
  "in_reply_to_status_id" : 288301680909500417,
  "created_at" : "2013-01-07 18:01:53 +0000",
  "in_reply_to_screen_name" : "danrmitvn",
  "in_reply_to_user_id_str" : "125853393",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 0, 11 ],
      "id_str" : "282659955",
      "id" : 282659955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288343695730802688",
  "geo" : { },
  "id_str" : "288344472906002432",
  "in_reply_to_user_id" : 282659955,
  "text" : "@teflerinha nwordpress was there then. i guess that first post was about tech. the quality of yr blog seems like it's been there for ever!",
  "id" : 288344472906002432,
  "in_reply_to_status_id" : 288343695730802688,
  "created_at" : "2013-01-07 18:00:54 +0000",
  "in_reply_to_screen_name" : "teflerinha",
  "in_reply_to_user_id_str" : "282659955",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nagehan Tunar",
      "screen_name" : "stiiiv",
      "indices" : [ 128, 135 ],
      "id_str" : "799058600",
      "id" : 799058600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/kL4UnfAt",
      "expanded_url" : "http:\/\/wp.me\/p219lY-4e",
      "display_url" : "wp.me\/p219lY-4e"
    } ]
  },
  "geo" : { },
  "id_str" : "288343797396566016",
  "text" : "well argued case for promoting content as well as language practice in EAP contexts&gt;Demand High EAP http:\/\/t.co\/kL4UnfAt via @stiiiv",
  "id" : 288343797396566016,
  "created_at" : "2013-01-07 17:58:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 0, 11 ],
      "id_str" : "282659955",
      "id" : 282659955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "288341734126145536",
  "in_reply_to_user_id" : 282659955,
  "text" : "@teflerinha thx for mention, got my 1st year blog anniv in feb as well, though technically did my 1st post in june 2008!",
  "id" : 288341734126145536,
  "created_at" : "2013-01-07 17:50:01 +0000",
  "in_reply_to_screen_name" : "teflerinha",
  "in_reply_to_user_id_str" : "282659955",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 83, 94 ],
      "id_str" : "282659955",
      "id" : 282659955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/nghUCMZK",
      "expanded_url" : "http:\/\/wp.me\/p2e2Wf-9E",
      "display_url" : "wp.me\/p2e2Wf-9E"
    } ]
  },
  "geo" : { },
  "id_str" : "288341177625878529",
  "text" : "a right fine bunch! &gt;A bouquet of favourite blog posts http:\/\/t.co\/nghUCMZK via @teflerinha",
  "id" : 288341177625878529,
  "created_at" : "2013-01-07 17:47:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 80, 88 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "287987762731290624",
  "text" : "i just had to get to a link via a scoopit of a scoopit so 3 clicks in total! RT @seburnt I really dislike Scoop.it links.",
  "id" : 287987762731290624,
  "created_at" : "2013-01-06 18:23:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MarisaConstantinides",
      "screen_name" : "Marisa_C",
      "indices" : [ 0, 9 ],
      "id_str" : "18272500",
      "id" : 18272500
    }, {
      "name" : "Vicky Loras",
      "screen_name" : "vickyloras",
      "indices" : [ 10, 21 ],
      "id_str" : "95957241",
      "id" : 95957241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287913412325949441",
  "geo" : { },
  "id_str" : "287927809802924032",
  "in_reply_to_user_id" : 18272500,
  "text" : "@Marisa_C @vickyloras needs a name change to Play the Corporate News game :)",
  "id" : 287927809802924032,
  "in_reply_to_status_id" : 287913412325949441,
  "created_at" : "2013-01-06 14:25:13 +0000",
  "in_reply_to_screen_name" : "Marisa_C",
  "in_reply_to_user_id_str" : "18272500",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/T7j2GRfg",
      "expanded_url" : "http:\/\/boingboing.net\/2013\/01\/04\/office-hobbit-mashup.html",
      "display_url" : "boingboing.net\/2013\/01\/04\/off\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "287698117778894848",
  "text" : "nicely done :) &gt;The Office: An Unexpected Journey: http:\/\/t.co\/T7j2GRfg",
  "id" : 287698117778894848,
  "created_at" : "2013-01-05 23:12:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287682339855810561",
  "geo" : { },
  "id_str" : "287689349611548672",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt you've fixed it?",
  "id" : 287689349611548672,
  "in_reply_to_status_id" : 287682339855810561,
  "created_at" : "2013-01-05 22:37:40 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287637413138944000",
  "geo" : { },
  "id_str" : "287646132111294464",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt doh commenting on the post just noticed missed the t off yr name!",
  "id" : 287646132111294464,
  "in_reply_to_status_id" : 287637413138944000,
  "created_at" : "2013-01-05 19:45:56 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287637413138944000",
  "geo" : { },
  "id_str" : "287639230321131520",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt very well thanks tyson, same to you and yours :)",
  "id" : 287639230321131520,
  "in_reply_to_status_id" : 287637413138944000,
  "created_at" : "2013-01-05 19:18:31 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 14, 22 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 125, 145 ],
      "url" : "http:\/\/t.co\/TQs7fiQi",
      "expanded_url" : "http:\/\/fourc.ca\/copycat\/",
      "display_url" : "fourc.ca\/copycat\/"
    } ]
  },
  "geo" : { },
  "id_str" : "287636810316795905",
  "text" : "useful &gt;RT @seburnt Students: copycat, sort of &gt; a commentary and activity on improving critical reading &amp; writing http:\/\/t.co\/TQs7fiQi",
  "id" : 287636810316795905,
  "created_at" : "2013-01-05 19:08:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WIRED",
      "screen_name" : "WIRED",
      "indices" : [ 3, 9 ],
      "id_str" : "1344951",
      "id" : 1344951
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/fgfGgLM4",
      "expanded_url" : "http:\/\/oak.ctx.ly\/r\/1rb4",
      "display_url" : "oak.ctx.ly\/r\/1rb4"
    } ]
  },
  "geo" : { },
  "id_str" : "287622769821237248",
  "text" : "RT @wired Recent Top Stories: Say Bonjour to the Internet\u2019s Long-Lost French Uncle http:\/\/t.co\/fgfGgLM4",
  "id" : 287622769821237248,
  "created_at" : "2013-01-05 18:13:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Simpson",
      "screen_name" : "yearinthelifeof",
      "indices" : [ 0, 16 ],
      "id_str" : "78543378",
      "id" : 78543378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287607639603556352",
  "geo" : { },
  "id_str" : "287610108911960064",
  "in_reply_to_user_id" : 78543378,
  "text" : "@yearinthelifeof @TEFLWorldWiki handy thanks!",
  "id" : 287610108911960064,
  "in_reply_to_status_id" : 287607639603556352,
  "created_at" : "2013-01-05 17:22:48 +0000",
  "in_reply_to_screen_name" : "yearinthelifeof",
  "in_reply_to_user_id_str" : "78543378",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "287600592690507776",
  "text" : "new year resolution - making more use of twitter lists! very handy things!",
  "id" : 287600592690507776,
  "created_at" : "2013-01-05 16:44:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Sample",
      "screen_name" : "samplereality",
      "indices" : [ 3, 17 ],
      "id_str" : "8497292",
      "id" : 8497292
    }, {
      "name" : "Ian Bogost",
      "screen_name" : "ibogost",
      "indices" : [ 30, 38 ],
      "id_str" : "6825792",
      "id" : 6825792
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mla13",
      "indices" : [ 94, 100 ]
    }, {
      "text" : "s307",
      "indices" : [ 101, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/gaQjxwW1",
      "expanded_url" : "http:\/\/www.samplereality.com\/2011\/05\/06\/gamifying-gamification-by-making-it-less-gamely\/",
      "display_url" : "samplereality.com\/2011\/05\/06\/gam\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "287279817328586752",
  "text" : "RT @samplereality: My take on @ibogost's idea of exploitationware: Let's gamify gamification  #mla13 #s307 http:\/\/t.co\/gaQjxwW1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ian Bogost",
        "screen_name" : "ibogost",
        "indices" : [ 11, 19 ],
        "id_str" : "6825792",
        "id" : 6825792
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "mla13",
        "indices" : [ 75, 81 ]
      }, {
        "text" : "s307",
        "indices" : [ 82, 87 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 108 ],
        "url" : "http:\/\/t.co\/gaQjxwW1",
        "expanded_url" : "http:\/\/www.samplereality.com\/2011\/05\/06\/gamifying-gamification-by-making-it-less-gamely\/",
        "display_url" : "samplereality.com\/2011\/05\/06\/gam\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "287276587068579840",
    "text" : "My take on @ibogost's idea of exploitationware: Let's gamify gamification  #mla13 #s307 http:\/\/t.co\/gaQjxwW1",
    "id" : 287276587068579840,
    "created_at" : "2013-01-04 19:17:30 +0000",
    "user" : {
      "name" : "Mark Sample",
      "screen_name" : "samplereality",
      "protected" : false,
      "id_str" : "8497292",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000707852410\/a86167716ecb748acc89638ad165a162_normal.jpeg",
      "id" : 8497292,
      "verified" : false
    }
  },
  "id" : 287279817328586752,
  "created_at" : "2013-01-04 19:30:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 70, 78 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EAPchat",
      "indices" : [ 83, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/JbXs25nu",
      "expanded_url" : "http:\/\/fourc.ca\/the-eapchat-webspace\/",
      "display_url" : "fourc.ca\/the-eapchat-we\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "286984832322506752",
  "text" : "exceedingly nice space tyson, here's to it filling up satisfyingly! RT@seburnt\nThe #EAPchat webspace http:\/\/t.co\/JbXs25nu \u2026",
  "id" : 286984832322506752,
  "created_at" : "2013-01-03 23:58:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Wheeler",
      "screen_name" : "timbuckteeth",
      "indices" : [ 0, 13 ],
      "id_str" : "11435832",
      "id" : 11435832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286981489088933888",
  "geo" : { },
  "id_str" : "286982829567528963",
  "in_reply_to_user_id" : 11435832,
  "text" : "@timbuckteeth remember being given a copy on 5 1\/4 disk for BBC micro but never able to get it to load! still yet to play it fully!",
  "id" : 286982829567528963,
  "in_reply_to_status_id" : 286981489088933888,
  "created_at" : "2013-01-03 23:50:13 +0000",
  "in_reply_to_screen_name" : "timbuckteeth",
  "in_reply_to_user_id_str" : "11435832",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jess Thirlway",
      "screen_name" : "Jess_Thirlway",
      "indices" : [ 0, 14 ],
      "id_str" : "151182674",
      "id" : 151182674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286976375930363904",
  "geo" : { },
  "id_str" : "286979118178910208",
  "in_reply_to_user_id" : 151182674,
  "text" : "@Jess_Thirlway Yea, thats right! Thats right! Youse bad! :)",
  "id" : 286979118178910208,
  "in_reply_to_status_id" : 286976375930363904,
  "created_at" : "2013-01-03 23:35:28 +0000",
  "in_reply_to_screen_name" : "Jess_Thirlway",
  "in_reply_to_user_id_str" : "151182674",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286903063132913664",
  "geo" : { },
  "id_str" : "286968962028277761",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson doh sorry that shld have been thx for share not RT!",
  "id" : 286968962028277761,
  "in_reply_to_status_id" : 286903063132913664,
  "created_at" : "2013-01-03 22:55:06 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    }, {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 45, 56 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286903063132913664",
  "geo" : { },
  "id_str" : "286968097276055552",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson many thx for RT, i read that @hughdellar was thinking of writing a 'what have corpora ever done for us' post; to arms!",
  "id" : 286968097276055552,
  "in_reply_to_status_id" : 286903063132913664,
  "created_at" : "2013-01-03 22:51:40 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John T. Spencer",
      "screen_name" : "JohnTSpencer",
      "indices" : [ 3, 16 ],
      "id_str" : "2285706270",
      "id" : 2285706270
    }, {
      "name" : "chadsansing",
      "screen_name" : "chadsansing",
      "indices" : [ 88, 100 ],
      "id_str" : "76810409",
      "id" : 76810409
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rechat",
      "indices" : [ 122, 129 ]
    }, {
      "text" : "mschat",
      "indices" : [ 130, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/wgwDJ8aV",
      "expanded_url" : "http:\/\/bit.ly\/Ulrjjk",
      "display_url" : "bit.ly\/Ulrjjk"
    } ]
  },
  "geo" : { },
  "id_str" : "286838209651032064",
  "text" : "RT @johntspencer: A thought-provoking story of student-direct, democratic learning - by @chadsansing http:\/\/t.co\/wgwDJ8aV #rechat #mschat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "chadsansing",
        "screen_name" : "chadsansing",
        "indices" : [ 70, 82 ],
        "id_str" : "76810409",
        "id" : 76810409
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "rechat",
        "indices" : [ 104, 111 ]
      }, {
        "text" : "mschat",
        "indices" : [ 112, 119 ]
      } ],
      "urls" : [ {
        "indices" : [ 83, 103 ],
        "url" : "http:\/\/t.co\/wgwDJ8aV",
        "expanded_url" : "http:\/\/bit.ly\/Ulrjjk",
        "display_url" : "bit.ly\/Ulrjjk"
      } ]
    },
    "geo" : { },
    "id_str" : "286831243532840960",
    "text" : "A thought-provoking story of student-direct, democratic learning - by @chadsansing http:\/\/t.co\/wgwDJ8aV #rechat #mschat",
    "id" : 286831243532840960,
    "created_at" : "2013-01-03 13:47:52 +0000",
    "user" : {
      "name" : "John Spencer",
      "screen_name" : "spencerideas",
      "protected" : false,
      "id_str" : "18389166",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751913559160795136\/eU7NtYy4_normal.jpg",
      "id" : 18389166,
      "verified" : false
    }
  },
  "id" : 286838209651032064,
  "created_at" : "2013-01-03 14:15:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 0, 13 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 96 ],
      "url" : "https:\/\/t.co\/bIOm16XB",
      "expanded_url" : "https:\/\/kielikompassi.jyu.fi\/kookit06\/corpus\/view\/viewmain.html#",
      "display_url" : "kielikompassi.jyu.fi\/kookit06\/corpu\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "286827963348049920",
  "geo" : { },
  "id_str" : "286829334919012353",
  "in_reply_to_user_id" : 88655243,
  "text" : "@rosemerebard if you've not seen this before recommended online 'workshop' https:\/\/t.co\/bIOm16XB on using corpus",
  "id" : 286829334919012353,
  "in_reply_to_status_id" : 286827963348049920,
  "created_at" : "2013-01-03 13:40:17 +0000",
  "in_reply_to_screen_name" : "rosemerebard",
  "in_reply_to_user_id_str" : "88655243",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anne Hodgson",
      "screen_name" : "annehodg",
      "indices" : [ 0, 9 ],
      "id_str" : "17589213",
      "id" : 17589213
    }, {
      "name" : "Anne Hodgson",
      "screen_name" : "annehodg",
      "indices" : [ 45, 54 ],
      "id_str" : "17589213",
      "id" : 17589213
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "besig",
      "indices" : [ 133, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/ev13u34N",
      "expanded_url" : "http:\/\/annehodgson.de\/2013\/01\/03\/what-are-you-selling-personality\/",
      "display_url" : "annehodgson.de\/2013\/01\/03\/wha\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "286801200605691904",
  "in_reply_to_user_id" : 17589213,
  "text" : "@annehodg\nWOW that's some sales patter&gt;RT @annehodg Video and transcript of comedian salesman Kenny Brooks http:\/\/t.co\/ev13u34N \u2026 #besig",
  "id" : 286801200605691904,
  "created_at" : "2013-01-03 11:48:29 +0000",
  "in_reply_to_screen_name" : "annehodg",
  "in_reply_to_user_id_str" : "17589213",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "Jean-Luc Raymond",
      "screen_name" : "jeanlucr",
      "indices" : [ 12, 21 ],
      "id_str" : "6120472",
      "id" : 6120472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286752249009561600",
  "geo" : { },
  "id_str" : "286797662836105219",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan @jeanlucr the papr is available for download, makes interesting reading, i don't see why the results wouldnt transfer to twitter",
  "id" : 286797662836105219,
  "in_reply_to_status_id" : 286752249009561600,
  "created_at" : "2013-01-03 11:34:25 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Xanthe",
      "screen_name" : "xanlan",
      "indices" : [ 81, 88 ],
      "id_str" : "39527659",
      "id" : 39527659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/5KoqL5D2",
      "expanded_url" : "http:\/\/helsinki.urbanflow.io\/",
      "display_url" : "helsinki.urbanflow.io"
    } ]
  },
  "geo" : { },
  "id_str" : "286790498776133632",
  "text" : "nice concept interesting no environmental aspects detailed in their proposal? RT @xanlan Urbanflow Helsinki http:\/\/t.co\/5KoqL5D2",
  "id" : 286790498776133632,
  "created_at" : "2013-01-03 11:05:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 28, 36 ],
      "id_str" : "20650366",
      "id" : 20650366
    }, {
      "name" : "Adam Simpson",
      "screen_name" : "yearinthelifeof",
      "indices" : [ 118, 134 ],
      "id_str" : "78543378",
      "id" : 78543378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/I2MfUv5z",
      "expanded_url" : "http:\/\/www.teachthemenglish.com\/2012\/12\/6-essential-practices-in-using-emerging-technologies-in-the-classroom-in-2013\/",
      "display_url" : "teachthemenglish.com\/2012\/12\/6-esse\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "286780758125850624",
  "text" : "sensible observations&gt;MT @seburnt 6 essential practices in using emerging technologies  http:\/\/t.co\/I2MfUv5z \u2026 via @yearinthelifeof",
  "id" : 286780758125850624,
  "created_at" : "2013-01-03 10:27:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 0, 13 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "286777071156486144",
  "in_reply_to_user_id" : 88655243,
  "text" : "@rosemerebard many thx for sharing and liking cup of COCA post!",
  "id" : 286777071156486144,
  "created_at" : "2013-01-03 10:12:36 +0000",
  "in_reply_to_screen_name" : "rosemerebard",
  "in_reply_to_user_id_str" : "88655243",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "indices" : [ 0, 13 ],
      "id_str" : "1685397408",
      "id" : 1685397408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "286612815417073665",
  "text" : "@harrisonmike preetty good, overall imo better than LOTR, but the elven scenes are bad e.g. intro of lady galadriel very corny!",
  "id" : 286612815417073665,
  "created_at" : "2013-01-02 23:19:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "royan lee",
      "screen_name" : "royanlee",
      "indices" : [ 34, 43 ],
      "id_str" : "30651485",
      "id" : 30651485
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "286601885639667712",
  "text" : "another intriguing dlted post frm @royanlee cptrd by WP rdr \"Paulo Freire he de man\"",
  "id" : 286601885639667712,
  "created_at" : "2013-01-02 22:36:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 27, 38 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "286596172360065026",
  "text" : "tantalisng deletd posts by @hughdellar captrd on WP rdr \".. to blog twenty pearls of wisdom I\u2019ve gleaned during my years at the chalk face \"",
  "id" : 286596172360065026,
  "created_at" : "2013-01-02 22:13:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John T. Spencer",
      "screen_name" : "JohnTSpencer",
      "indices" : [ 0, 13 ],
      "id_str" : "2285706270",
      "id" : 2285706270
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286579249798848513",
  "geo" : { },
  "id_str" : "286591137530126336",
  "in_reply_to_user_id" : 18389166,
  "text" : "@johntspencer at first line 1 but  as i reread it it felt kinda trite, line 2 more i read it more i like it :) from a tchrs pov it draws u",
  "id" : 286591137530126336,
  "in_reply_to_status_id" : 286579249798848513,
  "created_at" : "2013-01-02 21:53:46 +0000",
  "in_reply_to_screen_name" : "spencerideas",
  "in_reply_to_user_id_str" : "18389166",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/wG4Vkmgk",
      "expanded_url" : "http:\/\/www.ubuntu.com\/devices\/phone",
      "display_url" : "ubuntu.com\/devices\/phone"
    } ]
  },
  "geo" : { },
  "id_str" : "286583856520368130",
  "text" : "nice to see Ubuntu entering mobile sector http:\/\/t.co\/wG4Vkmgk",
  "id" : 286583856520368130,
  "created_at" : "2013-01-02 21:24:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    }, {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 17, 29 ],
      "id_str" : "525013404",
      "id" : 525013404
    }, {
      "name" : "TheLanguagePoint",
      "screen_name" : "Marie_Sanako",
      "indices" : [ 30, 43 ],
      "id_str" : "356176087",
      "id" : 356176087
    }, {
      "name" : "Carol Goodey",
      "screen_name" : "cgoodey",
      "indices" : [ 44, 52 ],
      "id_str" : "26606833",
      "id" : 26606833
    }, {
      "name" : "Gemma Lunn",
      "screen_name" : "GemL1",
      "indices" : [ 53, 59 ],
      "id_str" : "486146568",
      "id" : 486146568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286483173834108928",
  "geo" : { },
  "id_str" : "286551814076264449",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin @AnneHendler @Marie_Sanako @cgoodey @GemL1 thx hoping to encourage reg use (&amp; report usage of) COCA  with these posts",
  "id" : 286551814076264449,
  "in_reply_to_status_id" : 286483173834108928,
  "created_at" : "2013-01-02 19:17:31 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "286550976645709825",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler thx for inspiration for (and fav and RT) of cup of COCA post :)",
  "id" : 286550976645709825,
  "created_at" : "2013-01-02 19:14:11 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    }, {
      "name" : "TheLanguagePoint",
      "screen_name" : "Marie_Sanako",
      "indices" : [ 18, 31 ],
      "id_str" : "356176087",
      "id" : 356176087
    }, {
      "name" : "Carol Goodey",
      "screen_name" : "cgoodey",
      "indices" : [ 33, 41 ],
      "id_str" : "26606833",
      "id" : 26606833
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/WAxnjuIa",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-do",
      "display_url" : "wp.me\/pgHyE-do"
    } ]
  },
  "geo" : { },
  "id_str" : "286533288267497473",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin, @Marie_Sanako, @cgoodey many thanks for inspiring (and RT and likes) of latest cup of COCA post http:\/\/t.co\/WAxnjuIa",
  "id" : 286533288267497473,
  "created_at" : "2013-01-02 18:03:54 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maria Popova",
      "screen_name" : "brainpicker",
      "indices" : [ 0, 12 ],
      "id_str" : "9207632",
      "id" : 9207632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/Vm3ETtML",
      "expanded_url" : "http:\/\/www.newint.org\/blog\/2012\/04\/11\/nhs-virgin-care-telegraph\/",
      "display_url" : "newint.org\/blog\/2012\/04\/1\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "286523268016533505",
  "geo" : { },
  "id_str" : "286529784501129216",
  "in_reply_to_user_id" : 9207632,
  "text" : "@brainpicker sir pickles real definition of success: protect brand image e.g. http:\/\/t.co\/Vm3ETtML",
  "id" : 286529784501129216,
  "in_reply_to_status_id" : 286523268016533505,
  "created_at" : "2013-01-02 17:49:58 +0000",
  "in_reply_to_screen_name" : "brainpicker",
  "in_reply_to_user_id_str" : "9207632",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    }, {
      "name" : "Mamico Kotani",
      "screen_name" : "mamirrific",
      "indices" : [ 12, 23 ],
      "id_str" : "59648483",
      "id" : 59648483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286473496773681152",
  "geo" : { },
  "id_str" : "286482852747567104",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow @mamirrific did not peg u as a prescriptivist kevin? ;)",
  "id" : 286482852747567104,
  "in_reply_to_status_id" : 286473496773681152,
  "created_at" : "2013-01-02 14:43:29 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 71, 83 ],
      "id_str" : "525013404",
      "id" : 525013404
    }, {
      "name" : "TheLanguagePoint",
      "screen_name" : "Marie_Sanako",
      "indices" : [ 84, 97 ],
      "id_str" : "356176087",
      "id" : 356176087
    }, {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 98, 114 ],
      "id_str" : "394053348",
      "id" : 394053348
    }, {
      "name" : "Carol Goodey",
      "screen_name" : "cgoodey",
      "indices" : [ 115, 123 ],
      "id_str" : "26606833",
      "id" : 26606833
    }, {
      "name" : "Gemma Lunn",
      "screen_name" : "GemL1",
      "indices" : [ 124, 130 ],
      "id_str" : "486146568",
      "id" : 486146568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/WAxnjuIa",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-do",
      "display_url" : "wp.me\/pgHyE-do"
    } ]
  },
  "geo" : { },
  "id_str" : "286479642582466560",
  "text" : "new Quick cup of COCA - bring to * boil http:\/\/t.co\/WAxnjuIa featuring @AnneHendler @Marie_Sanako @michaelegriffin @cgoodey @GemL1",
  "id" : 286479642582466560,
  "created_at" : "2013-01-02 14:30:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/SVf5IpDH",
      "expanded_url" : "http:\/\/bit.ly\/12XVNhO",
      "display_url" : "bit.ly\/12XVNhO"
    } ]
  },
  "in_reply_to_status_id_str" : "286453766033666049",
  "geo" : { },
  "id_str" : "286468297455722496",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler ps here is the direct link http:\/\/t.co\/SVf5IpDH",
  "id" : 286468297455722496,
  "in_reply_to_status_id" : 286453766033666049,
  "created_at" : "2013-01-02 13:45:39 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/8TNxu60n",
      "expanded_url" : "http:\/\/lockerz.com\/s\/274010034",
      "display_url" : "lockerz.com\/s\/274010034"
    } ]
  },
  "in_reply_to_status_id_str" : "286453766033666049",
  "geo" : { },
  "id_str" : "286465482947706881",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler coca gives an interesting picture confirming british vs us bias attached http:\/\/t.co\/8TNxu60n",
  "id" : 286465482947706881,
  "in_reply_to_status_id" : 286453766033666049,
  "created_at" : "2013-01-02 13:34:28 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Telegraph Education",
      "screen_name" : "tele_education",
      "indices" : [ 3, 18 ],
      "id_str" : "318988824",
      "id" : 318988824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/Nhjf6Ir0",
      "expanded_url" : "http:\/\/tgr.ph\/WjPChD",
      "display_url" : "tgr.ph\/WjPChD"
    } ]
  },
  "geo" : { },
  "id_str" : "286434281843195905",
  "text" : "RT @tele_education: Top 10 foreign language faux pas: in pictures http:\/\/t.co\/Nhjf6Ir0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/dlvr.it\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 66 ],
        "url" : "http:\/\/t.co\/Nhjf6Ir0",
        "expanded_url" : "http:\/\/tgr.ph\/WjPChD",
        "display_url" : "tgr.ph\/WjPChD"
      } ]
    },
    "geo" : { },
    "id_str" : "286376166254866432",
    "text" : "Top 10 foreign language faux pas: in pictures http:\/\/t.co\/Nhjf6Ir0",
    "id" : 286376166254866432,
    "created_at" : "2013-01-02 07:39:33 +0000",
    "user" : {
      "name" : "Telegraph Education",
      "screen_name" : "tele_education",
      "protected" : false,
      "id_str" : "318988824",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/704693961332559873\/v0b4ear-_normal.jpg",
      "id" : 318988824,
      "verified" : true
    }
  },
  "id" : 286434281843195905,
  "created_at" : "2013-01-02 11:30:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "le_mac",
      "screen_name" : "le_mac",
      "indices" : [ 0, 7 ],
      "id_str" : "17064137",
      "id" : 17064137
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286216730466992129",
  "geo" : { },
  "id_str" : "286219668161708032",
  "in_reply_to_user_id" : 17064137,
  "text" : "@le_mac dont forget the popcorn! is that 2nd one a horror film? btw does yr lost umbrella have pics of animals?",
  "id" : 286219668161708032,
  "in_reply_to_status_id" : 286216730466992129,
  "created_at" : "2013-01-01 21:17:41 +0000",
  "in_reply_to_screen_name" : "le_mac",
  "in_reply_to_user_id_str" : "17064137",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Levine",
      "screen_name" : "cogdog",
      "indices" : [ 52, 59 ],
      "id_str" : "740343",
      "id" : 740343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/w4XbDwtx",
      "expanded_url" : "http:\/\/wp.me\/pf0PM-4Lj",
      "display_url" : "wp.me\/pf0PM-4Lj"
    } ]
  },
  "geo" : { },
  "id_str" : "286217945963696128",
  "text" : "hehe those numbers are truly numbing and dumbing RT @cogdog CogDogBlogged: 2012 In Numbers http:\/\/t.co\/w4XbDwtx",
  "id" : 286217945963696128,
  "created_at" : "2013-01-01 21:10:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/UWvCD2mO",
      "expanded_url" : "http:\/\/www.indymedia.org.uk\/en\/regions\/london\/2012\/12\/505116.html",
      "display_url" : "indymedia.org.uk\/en\/regions\/lon\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "286207192976224256",
  "text" : "Barbara Tucker now on hunger strike: started Thursday 27th http:\/\/t.co\/UWvCD2mO",
  "id" : 286207192976224256,
  "created_at" : "2013-01-01 20:28:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/7zi1mBYr",
      "expanded_url" : "http:\/\/whowhatwhy.com\/2012\/12\/30\/video-project-censoreds-top-25-unreported-stories-of-2012\/",
      "display_url" : "whowhatwhy.com\/2012\/12\/30\/vid\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "286145556135440385",
  "text" : "VIDEO: Project Censored\u2019s Top 25 Un\/Under reported Stories of 2012 http:\/\/t.co\/7zi1mBYr",
  "id" : 286145556135440385,
  "created_at" : "2013-01-01 16:23:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "285913363454775296",
  "text" : "Rejoice new orbit y'all power to the people y'all. :)",
  "id" : 285913363454775296,
  "created_at" : "2013-01-01 01:00:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
} ]