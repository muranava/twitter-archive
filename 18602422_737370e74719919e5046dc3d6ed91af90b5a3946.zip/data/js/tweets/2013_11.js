Grailbird.data.tweets_2013_11 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Meddings",
      "screen_name" : "LukeMeddings",
      "indices" : [ 3, 16 ],
      "id_str" : "39718253",
      "id" : 39718253
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/QxM0HvzItx",
      "expanded_url" : "http:\/\/lukemeddings.com\/2013\/11\/we-teach-to-reach-they-test-to-invest\/",
      "display_url" : "lukemeddings.com\/2013\/11\/we-tea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "406830053071536128",
  "text" : "RT @LukeMeddings: http:\/\/t.co\/QxM0HvzItx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/QxM0HvzItx",
        "expanded_url" : "http:\/\/lukemeddings.com\/2013\/11\/we-teach-to-reach-they-test-to-invest\/",
        "display_url" : "lukemeddings.com\/2013\/11\/we-tea\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "406767262897811456",
    "text" : "http:\/\/t.co\/QxM0HvzItx",
    "id" : 406767262897811456,
    "created_at" : "2013-11-30 12:50:47 +0000",
    "user" : {
      "name" : "Luke Meddings",
      "screen_name" : "LukeMeddings",
      "protected" : false,
      "id_str" : "39718253",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/564585290413928449\/Oo3yd3WD_normal.jpeg",
      "id" : 39718253,
      "verified" : false
    }
  },
  "id" : 406830053071536128,
  "created_at" : "2013-11-30 17:00:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/tCbq7In0QI",
      "expanded_url" : "http:\/\/tesolornothing.blogspot.com\/2013\/11\/esp-needs-analysis-Canadian-link.html?spref=tw",
      "display_url" : "tesolornothing.blogspot.com\/2013\/11\/esp-ne\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "406822760887746560",
  "text" : "TESOL or nothing: A helpful link for ESP teachers http:\/\/t.co\/tCbq7In0QI",
  "id" : 406822760887746560,
  "created_at" : "2013-11-30 16:31:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "natiserhost197",
      "screen_name" : "esl_robert",
      "indices" : [ 0, 11 ],
      "id_str" : "2982357761",
      "id" : 2982357761
    }, {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "indices" : [ 12, 24 ],
      "id_str" : "849729062",
      "id" : 849729062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "406537869931446272",
  "geo" : { },
  "id_str" : "406590674570448896",
  "in_reply_to_user_id" : 18526186,
  "text" : "@esl_robert @TonyMcEnery concgrams a feature that wordsmith has?",
  "id" : 406590674570448896,
  "in_reply_to_status_id" : 406537869931446272,
  "created_at" : "2013-11-30 01:09:05 +0000",
  "in_reply_to_screen_name" : "RobertEPoole",
  "in_reply_to_user_id_str" : "18526186",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Alec Couros",
      "screen_name" : "courosa",
      "indices" : [ 3, 11 ],
      "id_str" : "739293",
      "id" : 739293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/Krme5G9rW9",
      "expanded_url" : "http:\/\/news.cnet.com\/8301-17938_105-57600799-1\/dad-hacks-wheelchair-to-let-2-year-old-explore-the-world\/",
      "display_url" : "news.cnet.com\/8301-17938_105\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "406476669177065472",
  "text" : "RT @courosa: \"Dad hacks wheelchair to let 2-year-old explore the world\" http:\/\/t.co\/Krme5G9rW9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/Krme5G9rW9",
        "expanded_url" : "http:\/\/news.cnet.com\/8301-17938_105-57600799-1\/dad-hacks-wheelchair-to-let-2-year-old-explore-the-world\/",
        "display_url" : "news.cnet.com\/8301-17938_105\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "406449457803182080",
    "text" : "\"Dad hacks wheelchair to let 2-year-old explore the world\" http:\/\/t.co\/Krme5G9rW9",
    "id" : 406449457803182080,
    "created_at" : "2013-11-29 15:47:56 +0000",
    "user" : {
      "name" : "Dr. Alec Couros",
      "screen_name" : "courosa",
      "protected" : false,
      "id_str" : "739293",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/480186733221249027\/bzI2RIfo_normal.jpeg",
      "id" : 739293,
      "verified" : false
    }
  },
  "id" : 406476669177065472,
  "created_at" : "2013-11-29 17:36:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The-Round ELT",
      "screen_name" : "wetheround",
      "indices" : [ 3, 14 ],
      "id_str" : "281918842",
      "id" : 281918842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 125, 140 ],
      "url" : "http:\/\/t.co\/bNHuT7Ljw8",
      "expanded_url" : "http:\/\/the-round.com\/2013\/11\/52-free-this-weekend\/",
      "display_url" : "the-round.com\/2013\/11\/52-fre\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "406473959874789376",
  "text" : "RT @wetheround: It's Black Friday, and the authors of 52 don't want you to buy it. They're giving it away free this weekend! http:\/\/t.co\/bN\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/bNHuT7Ljw8",
        "expanded_url" : "http:\/\/the-round.com\/2013\/11\/52-free-this-weekend\/",
        "display_url" : "the-round.com\/2013\/11\/52-fre\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "406302942975627265",
    "text" : "It's Black Friday, and the authors of 52 don't want you to buy it. They're giving it away free this weekend! http:\/\/t.co\/bNHuT7Ljw8",
    "id" : 406302942975627265,
    "created_at" : "2013-11-29 06:05:45 +0000",
    "user" : {
      "name" : "The-Round ELT",
      "screen_name" : "wetheround",
      "protected" : false,
      "id_str" : "281918842",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1545068295\/twitter-avatar_normal.jpg",
      "id" : 281918842,
      "verified" : false
    }
  },
  "id" : 406473959874789376,
  "created_at" : "2013-11-29 17:25:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/56D3ZEsSSf",
      "expanded_url" : "http:\/\/www.jonathan-cook.net\/blog\/2013-11-28\/what-would-a-modern-messiah-look-like\/",
      "display_url" : "jonathan-cook.net\/blog\/2013-11-2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "406296810744193024",
  "text" : "RT @johnwhilley: A profound and humanitarian meditation from Jonathan Cook on what might represent a modern messiah.  http:\/\/t.co\/56D3ZEsSSf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/56D3ZEsSSf",
        "expanded_url" : "http:\/\/www.jonathan-cook.net\/blog\/2013-11-28\/what-would-a-modern-messiah-look-like\/",
        "display_url" : "jonathan-cook.net\/blog\/2013-11-2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "406228197210984448",
    "text" : "A profound and humanitarian meditation from Jonathan Cook on what might represent a modern messiah.  http:\/\/t.co\/56D3ZEsSSf",
    "id" : 406228197210984448,
    "created_at" : "2013-11-29 01:08:44 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 406296810744193024,
  "created_at" : "2013-11-29 05:41:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anna Loseva",
      "screen_name" : "AnnLoseva",
      "indices" : [ 0, 10 ],
      "id_str" : "38822368",
      "id" : 38822368
    }, {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 11, 24 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "406183609444614144",
  "geo" : { },
  "id_str" : "406184880624508928",
  "in_reply_to_user_id" : 38822368,
  "text" : "@AnnLoseva @rosemerebard hi i like that tagging activity if i do use it will let u know :)",
  "id" : 406184880624508928,
  "in_reply_to_status_id" : 406183609444614144,
  "created_at" : "2013-11-28 22:16:36 +0000",
  "in_reply_to_screen_name" : "AnnLoseva",
  "in_reply_to_user_id_str" : "38822368",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "406169742471221248",
  "text" : "conditional exercise from alan partridge film: a chemical attack by france results in no sense of smell, what smell would u miss the most :)",
  "id" : 406169742471221248,
  "created_at" : "2013-11-28 21:16:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anna Loseva",
      "screen_name" : "AnnLoseva",
      "indices" : [ 3, 13 ],
      "id_str" : "38822368",
      "id" : 38822368
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FlashmobELT",
      "indices" : [ 110, 122 ]
    }, {
      "text" : "elt",
      "indices" : [ 123, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/b2ulRlCo4c",
      "expanded_url" : "http:\/\/linoit.com\/users\/annaloseva\/canvases\/flashmobELT",
      "display_url" : "linoit.com\/users\/annalose\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "406163150589792256",
  "text" : "RT @AnnLoseva: I\"ve added an activity to the Lino, check it out and use tomorrow, or save it for a rainy day. #FlashmobELT #elt  http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FlashmobELT",
        "indices" : [ 95, 107 ]
      }, {
        "text" : "elt",
        "indices" : [ 108, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/b2ulRlCo4c",
        "expanded_url" : "http:\/\/linoit.com\/users\/annaloseva\/canvases\/flashmobELT",
        "display_url" : "linoit.com\/users\/annalose\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "406161670667386881",
    "text" : "I\"ve added an activity to the Lino, check it out and use tomorrow, or save it for a rainy day. #FlashmobELT #elt  http:\/\/t.co\/b2ulRlCo4c",
    "id" : 406161670667386881,
    "created_at" : "2013-11-28 20:44:23 +0000",
    "user" : {
      "name" : "Anna Loseva",
      "screen_name" : "AnnLoseva",
      "protected" : false,
      "id_str" : "38822368",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/767034457748541441\/VJrp4Jie_normal.jpg",
      "id" : 38822368,
      "verified" : false
    }
  },
  "id" : 406163150589792256,
  "created_at" : "2013-11-28 20:50:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Siva Vaidhyanathan",
      "screen_name" : "sivavaid",
      "indices" : [ 3, 12 ],
      "id_str" : "20406724",
      "id" : 20406724
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 140 ],
      "url" : "http:\/\/t.co\/Eu1nnEdkKU",
      "expanded_url" : "http:\/\/www.bogost.com\/blog\/goldieblox.shtml",
      "display_url" : "bogost.com\/blog\/goldieblo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "405959030180679680",
  "text" : "RT @sivavaid: \"In all I don't really understand how a ribbon game is going to help get girls interested in engineering.\" http:\/\/t.co\/Eu1nnE\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/Eu1nnEdkKU",
        "expanded_url" : "http:\/\/www.bogost.com\/blog\/goldieblox.shtml",
        "display_url" : "bogost.com\/blog\/goldieblo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "405880334983913472",
    "text" : "\"In all I don't really understand how a ribbon game is going to help get girls interested in engineering.\" http:\/\/t.co\/Eu1nnEdkKU",
    "id" : 405880334983913472,
    "created_at" : "2013-11-28 02:06:27 +0000",
    "user" : {
      "name" : "Siva Vaidhyanathan",
      "screen_name" : "sivavaid",
      "protected" : false,
      "id_str" : "20406724",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/767792599050649600\/aaiFpS9e_normal.jpg",
      "id" : 20406724,
      "verified" : false
    }
  },
  "id" : 405959030180679680,
  "created_at" : "2013-11-28 07:19:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "natiserhost197",
      "screen_name" : "esl_robert",
      "indices" : [ 3, 14 ],
      "id_str" : "2982357761",
      "id" : 2982357761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 127, 140 ],
      "url" : "http:\/\/t.co\/QuLkC4Yw2w",
      "expanded_url" : "http:\/\/scn.jkn21.com\/~percinfo\/#",
      "display_url" : "scn.jkn21.com\/~percinfo\/#"
    } ]
  },
  "geo" : { },
  "id_str" : "405952399850110976",
  "text" : "RT @esl_robert: Just discovered the 17-million word corpus of professional english (PERC Corpus). Free access until June 2014. http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/QuLkC4Yw2w",
        "expanded_url" : "http:\/\/scn.jkn21.com\/~percinfo\/#",
        "display_url" : "scn.jkn21.com\/~percinfo\/#"
      } ]
    },
    "geo" : { },
    "id_str" : "405877448991977472",
    "text" : "Just discovered the 17-million word corpus of professional english (PERC Corpus). Free access until June 2014. http:\/\/t.co\/QuLkC4Yw2w",
    "id" : 405877448991977472,
    "created_at" : "2013-11-28 01:54:59 +0000",
    "user" : {
      "name" : "Robert Poole",
      "screen_name" : "RobertEPoole",
      "protected" : false,
      "id_str" : "18526186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/586985086073069568\/UbAcX_I3_normal.jpg",
      "id" : 18526186,
      "verified" : false
    }
  },
  "id" : 405952399850110976,
  "created_at" : "2013-11-28 06:52:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/XBzvdlGmKU",
      "expanded_url" : "http:\/\/ow.ly\/rbXum",
      "display_url" : "ow.ly\/rbXum"
    } ]
  },
  "geo" : { },
  "id_str" : "405667527751380993",
  "text" : "RT @medialens: Media Alert - Endless Stalemate: How Fossil Fuel Interests Are Killing Climate Action http:\/\/t.co\/XBzvdlGmKU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/XBzvdlGmKU",
        "expanded_url" : "http:\/\/ow.ly\/rbXum",
        "display_url" : "ow.ly\/rbXum"
      } ]
    },
    "geo" : { },
    "id_str" : "405341844604612608",
    "text" : "Media Alert - Endless Stalemate: How Fossil Fuel Interests Are Killing Climate Action http:\/\/t.co\/XBzvdlGmKU",
    "id" : 405341844604612608,
    "created_at" : "2013-11-26 14:26:41 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 405667527751380993,
  "created_at" : "2013-11-27 12:00:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "indices" : [ 0, 12 ],
      "id_str" : "849729062",
      "id" : 849729062
    }, {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "indices" : [ 13, 29 ],
      "id_str" : "1326508478",
      "id" : 1326508478
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "405470191066157056",
  "geo" : { },
  "id_str" : "405470870270771200",
  "in_reply_to_user_id" : 849729062,
  "text" : "@TonyMcEnery @CorpusSocialSci ah okay thanks for glossary lk fwd to the mooc :)",
  "id" : 405470870270771200,
  "in_reply_to_status_id" : 405470191066157056,
  "created_at" : "2013-11-26 22:59:23 +0000",
  "in_reply_to_screen_name" : "TonyMcEnery",
  "in_reply_to_user_id_str" : "849729062",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "indices" : [ 0, 16 ],
      "id_str" : "1326508478",
      "id" : 1326508478
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "405084220571123712",
  "geo" : { },
  "id_str" : "405466264195182593",
  "in_reply_to_user_id" : 1326508478,
  "text" : "@CorpusSocialSci hi any particular reason COCA interface not listed?",
  "id" : 405466264195182593,
  "in_reply_to_status_id" : 405084220571123712,
  "created_at" : "2013-11-26 22:41:05 +0000",
  "in_reply_to_screen_name" : "CorpusSocialSci",
  "in_reply_to_user_id_str" : "1326508478",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FLY nonprofit",
      "screen_name" : "FLY_Nonprofit",
      "indices" : [ 0, 14 ],
      "id_str" : "256474731",
      "id" : 256474731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/dX8zgFeXmy",
      "expanded_url" : "http:\/\/wtffunfact.com\/post\/48643990572\/the-bird-turkey-in-turkish",
      "display_url" : "wtffunfact.com\/post\/486439905\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "405462924472221697",
  "geo" : { },
  "id_str" : "405464214052929537",
  "in_reply_to_user_id" : 256474731,
  "text" : "@FLY_Nonprofit found this funfact http:\/\/t.co\/dX8zgFeXmy",
  "id" : 405464214052929537,
  "in_reply_to_status_id" : 405462924472221697,
  "created_at" : "2013-11-26 22:32:56 +0000",
  "in_reply_to_screen_name" : "FLY_Nonprofit",
  "in_reply_to_user_id_str" : "256474731",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FLY nonprofit",
      "screen_name" : "FLY_Nonprofit",
      "indices" : [ 0, 14 ],
      "id_str" : "256474731",
      "id" : 256474731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "405459993131884545",
  "geo" : { },
  "id_str" : "405460671434735616",
  "in_reply_to_user_id" : 256474731,
  "text" : "@FLY_Nonprofit and in Turkish? :)",
  "id" : 405460671434735616,
  "in_reply_to_status_id" : 405459993131884545,
  "created_at" : "2013-11-26 22:18:51 +0000",
  "in_reply_to_screen_name" : "FLY_Nonprofit",
  "in_reply_to_user_id_str" : "256474731",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "indices" : [ 0, 11 ],
      "id_str" : "152051625",
      "id" : 152051625
    }, {
      "name" : "ReadWrite",
      "screen_name" : "RWW",
      "indices" : [ 12, 16 ],
      "id_str" : "4641021",
      "id" : 4641021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/0qodlKrlDj",
      "expanded_url" : "http:\/\/blogs.computerworld.com\/big-data\/23204\/python-really-supplanting-r-data-work",
      "display_url" : "blogs.computerworld.com\/big-data\/23204\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "405339341548814336",
  "geo" : { },
  "id_str" : "405459569570095104",
  "in_reply_to_user_id" : 152051625,
  "text" : "@heatherfro @RWW a critique here http:\/\/t.co\/0qodlKrlDj",
  "id" : 405459569570095104,
  "in_reply_to_status_id" : 405339341548814336,
  "created_at" : "2013-11-26 22:14:29 +0000",
  "in_reply_to_screen_name" : "heatherfro",
  "in_reply_to_user_id_str" : "152051625",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "indices" : [ 3, 19 ],
      "id_str" : "1326508478",
      "id" : 1326508478
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/IFTZYSeAhB",
      "expanded_url" : "http:\/\/cass.lancs.ac.uk\/?page_id=956",
      "display_url" : "cass.lancs.ac.uk\/?page_id=956"
    } ]
  },
  "geo" : { },
  "id_str" : "405299160305651712",
  "text" : "RT @CorpusSocialSci: CASS: Briefings...a new series of free downloadable resources on corpus linguistic research http:\/\/t.co\/IFTZYSeAhB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/IFTZYSeAhB",
        "expanded_url" : "http:\/\/cass.lancs.ac.uk\/?page_id=956",
        "display_url" : "cass.lancs.ac.uk\/?page_id=956"
      } ]
    },
    "geo" : { },
    "id_str" : "405084220571123712",
    "text" : "CASS: Briefings...a new series of free downloadable resources on corpus linguistic research http:\/\/t.co\/IFTZYSeAhB",
    "id" : 405084220571123712,
    "created_at" : "2013-11-25 21:22:58 +0000",
    "user" : {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "protected" : false,
      "id_str" : "1326508478",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3493899777\/ced36fe15c32eb911cbe3d64377524dc_normal.jpeg",
      "id" : 1326508478,
      "verified" : false
    }
  },
  "id" : 405299160305651712,
  "created_at" : "2013-11-26 11:37:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Divya Madhavan",
      "screen_name" : "_divyamadhavan",
      "indices" : [ 0, 15 ],
      "id_str" : "408492806",
      "id" : 408492806
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "404715035358162945",
  "geo" : { },
  "id_str" : "404961104096268290",
  "in_reply_to_user_id" : 408492806,
  "text" : "@_divyamadhavan :)",
  "id" : 404961104096268290,
  "in_reply_to_status_id" : 404715035358162945,
  "created_at" : "2013-11-25 13:13:45 +0000",
  "in_reply_to_screen_name" : "_divyamadhavan",
  "in_reply_to_user_id_str" : "408492806",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jo Sayers",
      "screen_name" : "jo_sayers",
      "indices" : [ 41, 51 ],
      "id_str" : "87176766",
      "id" : 87176766
    }, {
      "name" : "Divya Madhavan",
      "screen_name" : "_divyamadhavan",
      "indices" : [ 52, 67 ],
      "id_str" : "408492806",
      "id" : 408492806
    }, {
      "name" : "Laura Adele Soracco",
      "screen_name" : "LauraSoracco",
      "indices" : [ 68, 81 ],
      "id_str" : "15663328",
      "id" : 15663328
    }, {
      "name" : "MarisaConstantinides",
      "screen_name" : "Marisa_C",
      "indices" : [ 82, 91 ],
      "id_str" : "18272500",
      "id" : 18272500
    }, {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 92, 103 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tesolfr",
      "indices" : [ 26, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "404959103539109888",
  "text" : "thanks for RT and favs of #tesolfr post  @jo_sayers @_divyamadhavan @LauraSoracco @Marisa_C @lexicoloco :)",
  "id" : 404959103539109888,
  "created_at" : "2013-11-25 13:05:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Akira Murakami",
      "screen_name" : "mrkm_a",
      "indices" : [ 3, 10 ],
      "id_str" : "116922669",
      "id" : 116922669
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/961qvmzVt9",
      "expanded_url" : "http:\/\/lttcelc.org\/",
      "display_url" : "lttcelc.org"
    } ]
  },
  "geo" : { },
  "id_str" : "404957495434948608",
  "text" : "RT @mrkm_a: The LTTC English Learner Corpus\nhttp:\/\/t.co\/961qvmzVt9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 32, 54 ],
        "url" : "http:\/\/t.co\/961qvmzVt9",
        "expanded_url" : "http:\/\/lttcelc.org\/",
        "display_url" : "lttcelc.org"
      } ]
    },
    "geo" : { },
    "id_str" : "403990571905056768",
    "text" : "The LTTC English Learner Corpus\nhttp:\/\/t.co\/961qvmzVt9",
    "id" : 403990571905056768,
    "created_at" : "2013-11-22 20:57:12 +0000",
    "user" : {
      "name" : "Akira Murakami",
      "screen_name" : "mrkm_a",
      "protected" : false,
      "id_str" : "116922669",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/491819353784860672\/LqdQ1Sye_normal.jpeg",
      "id" : 116922669,
      "verified" : false
    }
  },
  "id" : 404957495434948608,
  "created_at" : "2013-11-25 12:59:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tesolfr",
      "indices" : [ 0, 8 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 66, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/zPIGFhdnBj",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-Jo",
      "display_url" : "wp.me\/pgHyE-Jo"
    } ]
  },
  "geo" : { },
  "id_str" : "404692443167088640",
  "text" : "#tesolfr slides, handout, notes and thanks http:\/\/t.co\/zPIGFhdnBj #eltchat",
  "id" : 404692443167088640,
  "created_at" : "2013-11-24 19:26:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Teacher ROAR",
      "screen_name" : "TeacherROAR",
      "indices" : [ 3, 15 ],
      "id_str" : "1558774417",
      "id" : 1558774417
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/sometimes_angry\/status\/403419814209015808\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/JjGiZYTnoW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZk8LvCIUAAKGiI.jpg",
      "id_str" : "403419813927997440",
      "id" : 403419813927997440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZk8LvCIUAAKGiI.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/JjGiZYTnoW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "404624926566793216",
  "text" : "RT @TeacherROAR: In case you missed it last night we tweeted this unbelieveable (but totally real) ad for an unqualified Maths teacher http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/sometimes_angry\/status\/403419814209015808\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/JjGiZYTnoW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BZk8LvCIUAAKGiI.jpg",
        "id_str" : "403419813927997440",
        "id" : 403419813927997440,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZk8LvCIUAAKGiI.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/JjGiZYTnoW"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "403779596333494272",
    "text" : "In case you missed it last night we tweeted this unbelieveable (but totally real) ad for an unqualified Maths teacher http:\/\/t.co\/JjGiZYTnoW",
    "id" : 403779596333494272,
    "created_at" : "2013-11-22 06:58:52 +0000",
    "user" : {
      "name" : "Teacher ROAR",
      "screen_name" : "TeacherROAR",
      "protected" : false,
      "id_str" : "1558774417",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/489000703038205952\/iY7K4OxP_normal.jpeg",
      "id" : 1558774417,
      "verified" : false
    }
  },
  "id" : 404624926566793216,
  "created_at" : "2013-11-24 14:57:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/rgPhGk4Dhp",
      "expanded_url" : "http:\/\/www.jonathan-cook.net\/blog\/2013-11-22\/the-false-analogy-of-syria-and-palestine\/",
      "display_url" : "jonathan-cook.net\/blog\/2013-11-2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "404624686904270848",
  "text" : "RT @johnwhilley: Incisive and honourable analysis  - Jonathan Cook answers Louis Proyect: The false analogy of Syria and Palestine http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/rgPhGk4Dhp",
        "expanded_url" : "http:\/\/www.jonathan-cook.net\/blog\/2013-11-22\/the-false-analogy-of-syria-and-palestine\/",
        "display_url" : "jonathan-cook.net\/blog\/2013-11-2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "403913662735200257",
    "text" : "Incisive and honourable analysis  - Jonathan Cook answers Louis Proyect: The false analogy of Syria and Palestine http:\/\/t.co\/rgPhGk4Dhp",
    "id" : 403913662735200257,
    "created_at" : "2013-11-22 15:51:36 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 404624686904270848,
  "created_at" : "2013-11-24 14:56:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth Anne",
      "screen_name" : "eannegrenoble",
      "indices" : [ 0, 14 ],
      "id_str" : "19869781",
      "id" : 19869781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "404586318459830272",
  "geo" : { },
  "id_str" : "404620066919952386",
  "in_reply_to_user_id" : 19869781,
  "text" : "@eannegrenoble sweet cheers :) how did talk go?",
  "id" : 404620066919952386,
  "in_reply_to_status_id" : 404586318459830272,
  "created_at" : "2013-11-24 14:38:36 +0000",
  "in_reply_to_screen_name" : "eannegrenoble",
  "in_reply_to_user_id_str" : "19869781",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dodgyideasdrinkbingo",
      "indices" : [ 25, 46 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "404544554059042816",
  "geo" : { },
  "id_str" : "404545457629581312",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin hehe :) #dodgyideasdrinkbingo like it",
  "id" : 404545457629581312,
  "in_reply_to_status_id" : 404544554059042816,
  "created_at" : "2013-11-24 09:42:07 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MarisaConstantinides",
      "screen_name" : "Marisa_C",
      "indices" : [ 0, 9 ],
      "id_str" : "18272500",
      "id" : 18272500
    }, {
      "name" : "Jo Sayers",
      "screen_name" : "jo_sayers",
      "indices" : [ 10, 20 ],
      "id_str" : "87176766",
      "id" : 87176766
    }, {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 21, 32 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "indices" : [ 33, 46 ],
      "id_str" : "1685397408",
      "id" : 1685397408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "404542364762779648",
  "geo" : { },
  "id_str" : "404544954736734208",
  "in_reply_to_user_id" : 18272500,
  "text" : "@Marisa_C @jo_sayers @leoselivan @harrisonmike :) was at a talk about reading circles which was useful for me",
  "id" : 404544954736734208,
  "in_reply_to_status_id" : 404542364762779648,
  "created_at" : "2013-11-24 09:40:07 +0000",
  "in_reply_to_screen_name" : "Marisa_C",
  "in_reply_to_user_id_str" : "18272500",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tesolfr",
      "indices" : [ 42, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "404538591360978945",
  "text" : "thanks very much for those who came to my #tesolfr talk; did not hit me really at that time who were actually there till now!",
  "id" : 404538591360978945,
  "created_at" : "2013-11-24 09:14:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jo Sayers",
      "screen_name" : "jo_sayers",
      "indices" : [ 0, 10 ],
      "id_str" : "87176766",
      "id" : 87176766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "404534017263161344",
  "geo" : { },
  "id_str" : "404537575936774144",
  "in_reply_to_user_id" : 87176766,
  "text" : "@jo_sayers cycle home seemed long last night! and remembering now your accident pics :0",
  "id" : 404537575936774144,
  "in_reply_to_status_id" : 404534017263161344,
  "created_at" : "2013-11-24 09:10:48 +0000",
  "in_reply_to_screen_name" : "jo_sayers",
  "in_reply_to_user_id_str" : "87176766",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jo Sayers",
      "screen_name" : "jo_sayers",
      "indices" : [ 0, 10 ],
      "id_str" : "87176766",
      "id" : 87176766
    }, {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "indices" : [ 11, 24 ],
      "id_str" : "1685397408",
      "id" : 1685397408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "404534017263161344",
  "geo" : { },
  "id_str" : "404535803407130624",
  "in_reply_to_user_id" : 87176766,
  "text" : "@jo_sayers @harrisonmike agh can't be there son is ill :( enjoy last day",
  "id" : 404535803407130624,
  "in_reply_to_status_id" : 404534017263161344,
  "created_at" : "2013-11-24 09:03:46 +0000",
  "in_reply_to_screen_name" : "jo_sayers",
  "in_reply_to_user_id_str" : "87176766",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MarisaConstantinides",
      "screen_name" : "Marisa_C",
      "indices" : [ 0, 9 ],
      "id_str" : "18272500",
      "id" : 18272500
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "404530222047174656",
  "geo" : { },
  "id_str" : "404531452672360448",
  "in_reply_to_user_id" : 18272500,
  "text" : "@Marisa_C thanks but gotta stay at home today :(",
  "id" : 404531452672360448,
  "in_reply_to_status_id" : 404530222047174656,
  "created_at" : "2013-11-24 08:46:28 +0000",
  "in_reply_to_screen_name" : "Marisa_C",
  "in_reply_to_user_id_str" : "18272500",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "404531143279538176",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan gd luck with yr talk looks like fate has once again stopped me from hearing one of yr talks! my son is running a temperature",
  "id" : 404531143279538176,
  "created_at" : "2013-11-24 08:45:15 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "evanfrendo",
      "screen_name" : "evanfrendo",
      "indices" : [ 0, 11 ],
      "id_str" : "17589664",
      "id" : 17589664
    }, {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 12, 23 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "404381131723644928",
  "geo" : { },
  "id_str" : "404527915976519680",
  "in_reply_to_user_id" : 17589664,
  "text" : "@evanfrendo @leoselivan you too! wish i could be there today!",
  "id" : 404527915976519680,
  "in_reply_to_status_id" : 404381131723644928,
  "created_at" : "2013-11-24 08:32:25 +0000",
  "in_reply_to_screen_name" : "evanfrendo",
  "in_reply_to_user_id_str" : "17589664",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Divya Madhavan",
      "screen_name" : "_divyamadhavan",
      "indices" : [ 0, 15 ],
      "id_str" : "408492806",
      "id" : 408492806
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "404302798986420224",
  "geo" : { },
  "id_str" : "404527737924120576",
  "in_reply_to_user_id" : 408492806,
  "text" : "@_divyamadhavan thanks so much for coming to the talk :)",
  "id" : 404527737924120576,
  "in_reply_to_status_id" : 404302798986420224,
  "created_at" : "2013-11-24 08:31:43 +0000",
  "in_reply_to_screen_name" : "_divyamadhavan",
  "in_reply_to_user_id_str" : "408492806",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth Anne",
      "screen_name" : "eannegrenoble",
      "indices" : [ 0, 14 ],
      "id_str" : "19869781",
      "id" : 19869781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "404296991255310336",
  "geo" : { },
  "id_str" : "404527619766353920",
  "in_reply_to_user_id" : 19869781,
  "text" : "@eannegrenoble ha :) nice to meet up again good luck for yr talk; gotta stay home today son is sick :(",
  "id" : 404527619766353920,
  "in_reply_to_status_id" : 404296991255310336,
  "created_at" : "2013-11-24 08:31:14 +0000",
  "in_reply_to_screen_name" : "eannegrenoble",
  "in_reply_to_user_id_str" : "19869781",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George Wilson",
      "screen_name" : "GDW82",
      "indices" : [ 3, 9 ],
      "id_str" : "1531690604",
      "id" : 1531690604
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tesolfr",
      "indices" : [ 90, 98 ]
    }, {
      "text" : "highered",
      "indices" : [ 134, 140 ]
    }, {
      "text" : "efl",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "404158323693740033",
  "text" : "RT @GDW82: Today's the day! 'Grammar translation alive and kicking in France!' with me at #tesolfr at 10.45! Hopefully see u there :) #high\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tesolfr",
        "indices" : [ 79, 87 ]
      }, {
        "text" : "highered",
        "indices" : [ 123, 132 ]
      }, {
        "text" : "efl",
        "indices" : [ 133, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "404154128320180224",
    "text" : "Today's the day! 'Grammar translation alive and kicking in France!' with me at #tesolfr at 10.45! Hopefully see u there :) #highered #efl",
    "id" : 404154128320180224,
    "created_at" : "2013-11-23 07:47:07 +0000",
    "user" : {
      "name" : "George Wilson",
      "screen_name" : "GDW82",
      "protected" : false,
      "id_str" : "1531690604",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000019487500\/d951373c68959832e2632dfed7771206_normal.jpeg",
      "id" : 1531690604,
      "verified" : false
    }
  },
  "id" : 404158323693740033,
  "created_at" : "2013-11-23 08:03:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jo Sayers",
      "screen_name" : "jo_sayers",
      "indices" : [ 3, 13 ],
      "id_str" : "87176766",
      "id" : 87176766
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tesolfr",
      "indices" : [ 29, 37 ]
    }, {
      "text" : "ELT",
      "indices" : [ 59, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/ef8nBqy6Ar",
      "expanded_url" : "http:\/\/www.eltplustech.com\/2013\/11\/move-fast-and-break-elt-things.html",
      "display_url" : "eltplustech.com\/2013\/11\/move-f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "404150849150390273",
  "text" : "RT @jo_sayers: New post from #tesolfr: Move Fast and Break #ELT Things http:\/\/t.co\/ef8nBqy6Ar",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tesolfr",
        "indices" : [ 14, 22 ]
      }, {
        "text" : "ELT",
        "indices" : [ 44, 48 ]
      } ],
      "urls" : [ {
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/ef8nBqy6Ar",
        "expanded_url" : "http:\/\/www.eltplustech.com\/2013\/11\/move-fast-and-break-elt-things.html",
        "display_url" : "eltplustech.com\/2013\/11\/move-f\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "404026600708386816",
    "text" : "New post from #tesolfr: Move Fast and Break #ELT Things http:\/\/t.co\/ef8nBqy6Ar",
    "id" : 404026600708386816,
    "created_at" : "2013-11-22 23:20:22 +0000",
    "user" : {
      "name" : "Jo Sayers",
      "screen_name" : "jo_sayers",
      "protected" : false,
      "id_str" : "87176766",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/466896591480037376\/EssZHYa4_normal.jpeg",
      "id" : 87176766,
      "verified" : false
    }
  },
  "id" : 404150849150390273,
  "created_at" : "2013-11-23 07:34:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 3, 17 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403885248561553408",
  "text" : "RT @audreywatters: Remember when Bill Gates only fucked with education in the US? Good times Good times",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "403705121327955968",
    "text" : "Remember when Bill Gates only fucked with education in the US? Good times Good times",
    "id" : 403705121327955968,
    "created_at" : "2013-11-22 02:02:56 +0000",
    "user" : {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "protected" : false,
      "id_str" : "25388528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711668009723498496\/pauFZsdv_normal.jpg",
      "id" : 25388528,
      "verified" : false
    }
  },
  "id" : 403885248561553408,
  "created_at" : "2013-11-22 13:58:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Graham Jones",
      "screen_name" : "10Sentences",
      "indices" : [ 101, 113 ],
      "id_str" : "1520318594",
      "id" : 1520318594
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/EwB6DqBJ5p",
      "expanded_url" : "http:\/\/wp.me\/p2roaS-XK",
      "display_url" : "wp.me\/p2roaS-XK"
    } ]
  },
  "geo" : { },
  "id_str" : "403810590520393729",
  "text" : "Is doing a read-through of a movie good for non-native English-speakers?: http:\/\/t.co\/EwB6DqBJ5p via @10Sentences",
  "id" : 403810590520393729,
  "created_at" : "2013-11-22 09:02:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "itdi.pro",
      "screen_name" : "iTDipro",
      "indices" : [ 3, 11 ],
      "id_str" : "374391424",
      "id" : 374391424
    }, {
      "name" : "Anna Loseva",
      "screen_name" : "AnnLoseva",
      "indices" : [ 58, 68 ],
      "id_str" : "38822368",
      "id" : 38822368
    }, {
      "name" : "Josette LeBlanc",
      "screen_name" : "JosetteLB",
      "indices" : [ 69, 79 ],
      "id_str" : "33503694",
      "id" : 33503694
    }, {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 84, 95 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iTDi",
      "indices" : [ 107, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/kYL4iuzOzd",
      "expanded_url" : "http:\/\/ow.ly\/r4A2L",
      "display_url" : "ow.ly\/r4A2L"
    } ]
  },
  "geo" : { },
  "id_str" : "403808790950445056",
  "text" : "RT @iTDipro: How do you feel about teaching observations? @AnnLoseva @JosetteLB and @kevchanwow sound off! #iTDi blog http:\/\/t.co\/kYL4iuzOzd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anna Loseva",
        "screen_name" : "AnnLoseva",
        "indices" : [ 45, 55 ],
        "id_str" : "38822368",
        "id" : 38822368
      }, {
        "name" : "Josette LeBlanc",
        "screen_name" : "JosetteLB",
        "indices" : [ 56, 66 ],
        "id_str" : "33503694",
        "id" : 33503694
      }, {
        "name" : "Kevin Stein",
        "screen_name" : "kevchanwow",
        "indices" : [ 71, 82 ],
        "id_str" : "144663117",
        "id" : 144663117
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "iTDi",
        "indices" : [ 94, 99 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/kYL4iuzOzd",
        "expanded_url" : "http:\/\/ow.ly\/r4A2L",
        "display_url" : "ow.ly\/r4A2L"
      } ]
    },
    "geo" : { },
    "id_str" : "403754131657326592",
    "text" : "How do you feel about teaching observations? @AnnLoseva @JosetteLB and @kevchanwow sound off! #iTDi blog http:\/\/t.co\/kYL4iuzOzd",
    "id" : 403754131657326592,
    "created_at" : "2013-11-22 05:17:41 +0000",
    "user" : {
      "name" : "itdi.pro",
      "screen_name" : "iTDipro",
      "protected" : false,
      "id_str" : "374391424",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1597476537\/iTDinstituteTwitter_normal.png",
      "id" : 374391424,
      "verified" : false
    }
  },
  "id" : 403808790950445056,
  "created_at" : "2013-11-22 08:54:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sandy Millin",
      "screen_name" : "sandymillin",
      "indices" : [ 3, 15 ],
      "id_str" : "144236944",
      "id" : 144236944
    }, {
      "name" : "Laura Patsko",
      "screen_name" : "lauraahaha",
      "indices" : [ 120, 131 ],
      "id_str" : "97957137",
      "id" : 97957137
    }, {
      "name" : "Katy Davies",
      "screen_name" : "katysdavies",
      "indices" : [ 136, 140 ],
      "id_str" : "2919479375",
      "id" : 2919479375
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/4wuQygJ2Nl",
      "expanded_url" : "http:\/\/wp.me\/p3RMIO-o",
      "display_url" : "wp.me\/p3RMIO-o"
    } ]
  },
  "geo" : { },
  "id_str" : "403762107352895488",
  "text" : "RT @sandymillin: ELF Battleships - printable game boards http:\/\/t.co\/4wuQygJ2Nl - great activity for minimal pairs, via @lauraahaha and @ka\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Laura Patsko",
        "screen_name" : "lauraahaha",
        "indices" : [ 103, 114 ],
        "id_str" : "97957137",
        "id" : 97957137
      }, {
        "name" : "Katy Davies",
        "screen_name" : "katysdavies",
        "indices" : [ 119, 131 ],
        "id_str" : "2919479375",
        "id" : 2919479375
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "eltchat",
        "indices" : [ 132, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 40, 62 ],
        "url" : "http:\/\/t.co\/4wuQygJ2Nl",
        "expanded_url" : "http:\/\/wp.me\/p3RMIO-o",
        "display_url" : "wp.me\/p3RMIO-o"
      } ]
    },
    "geo" : { },
    "id_str" : "403760086289367040",
    "text" : "ELF Battleships - printable game boards http:\/\/t.co\/4wuQygJ2Nl - great activity for minimal pairs, via @lauraahaha and @katysdavies #eltchat",
    "id" : 403760086289367040,
    "created_at" : "2013-11-22 05:41:20 +0000",
    "user" : {
      "name" : "Sandy Millin",
      "screen_name" : "sandymillin",
      "protected" : false,
      "id_str" : "144236944",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/429614623923269632\/yY-O4eno_normal.jpeg",
      "id" : 144236944,
      "verified" : false
    }
  },
  "id" : 403762107352895488,
  "created_at" : "2013-11-22 05:49:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Daily Beast",
      "screen_name" : "thedailybeast",
      "indices" : [ 74, 88 ],
      "id_str" : "16012783",
      "id" : 16012783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/9a78tnEGRG",
      "expanded_url" : "http:\/\/thebea.st\/1cFVUBs",
      "display_url" : "thebea.st\/1cFVUBs"
    } ]
  },
  "geo" : { },
  "id_str" : "403759769292267520",
  "text" : "What Is Michel Gondry Doing With Noam Chomsky? http:\/\/t.co\/9a78tnEGRG via @thedailybeast",
  "id" : 403759769292267520,
  "created_at" : "2013-11-22 05:40:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gordon Scruton",
      "screen_name" : "gscruton",
      "indices" : [ 47, 56 ],
      "id_str" : "266898808",
      "id" : 266898808
    }, {
      "name" : "stevemuir",
      "screen_name" : "steve_muir",
      "indices" : [ 102, 113 ],
      "id_str" : "18537988",
      "id" : 18537988
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "phoneticsrevision",
      "indices" : [ 0, 18 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/zAqxegvMlD",
      "expanded_url" : "http:\/\/gordonscruton.blogspot.co.uk\/p\/phonetic-quizzes.html",
      "display_url" : "gordonscruton.blogspot.co.uk\/p\/phonetic-qui\u2026"
    }, {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/gngbzm2Kwh",
      "expanded_url" : "http:\/\/allatc.wordpress.com\/2013\/11\/21\/the-tea-song\/",
      "display_url" : "allatc.wordpress.com\/2013\/11\/21\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "403658844913418240",
  "text" : "#phoneticsrevision last week film phonetics by @gscruton http:\/\/t.co\/zAqxegvMlD this week tea song by @steve_muir http:\/\/t.co\/gngbzm2Kwh",
  "id" : 403658844913418240,
  "created_at" : "2013-11-21 22:59:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 40, 56 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/CFoBWtFUO1",
      "expanded_url" : "http:\/\/wp.me\/p1oNHf-9J",
      "display_url" : "wp.me\/p1oNHf-9J"
    } ]
  },
  "geo" : { },
  "id_str" : "403651692442304513",
  "text" : "The Tea Song http:\/\/t.co\/CFoBWtFUO1 via @wordpressdotcom",
  "id" : 403651692442304513,
  "created_at" : "2013-11-21 22:30:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Adele Soracco",
      "screen_name" : "LauraSoracco",
      "indices" : [ 3, 16 ],
      "id_str" : "15663328",
      "id" : 15663328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/KFU1I6GFbW",
      "expanded_url" : "http:\/\/anotheryearoftesol.weebly.com\/1\/post\/2013\/11\/the-challenge-of-written-feedback.html",
      "display_url" : "anotheryearoftesol.weebly.com\/1\/post\/2013\/11\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "403643963527397378",
  "text" : "RT @LauraSoracco: The challenge of written feedback http:\/\/t.co\/KFU1I6GFbW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.weebly.com\/\" rel=\"nofollow\"\u003EWeebly App\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 34, 56 ],
        "url" : "http:\/\/t.co\/KFU1I6GFbW",
        "expanded_url" : "http:\/\/anotheryearoftesol.weebly.com\/1\/post\/2013\/11\/the-challenge-of-written-feedback.html",
        "display_url" : "anotheryearoftesol.weebly.com\/1\/post\/2013\/11\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "403622884863516672",
    "text" : "The challenge of written feedback http:\/\/t.co\/KFU1I6GFbW",
    "id" : 403622884863516672,
    "created_at" : "2013-11-21 20:36:09 +0000",
    "user" : {
      "name" : "Laura Adele Soracco",
      "screen_name" : "LauraSoracco",
      "protected" : false,
      "id_str" : "15663328",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766919326427254785\/4J5Q1zgQ_normal.jpg",
      "id" : 15663328,
      "verified" : false
    }
  },
  "id" : 403643963527397378,
  "created_at" : "2013-11-21 21:59:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paul braddock",
      "screen_name" : "bcnpaul1",
      "indices" : [ 0, 9 ],
      "id_str" : "130975050",
      "id" : 130975050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "403535833560387584",
  "geo" : { },
  "id_str" : "403630240443805697",
  "in_reply_to_user_id" : 130975050,
  "text" : "@bcnpaul1 fyi your blog does not render in firefox 25.01; ok in chrome, safari",
  "id" : 403630240443805697,
  "in_reply_to_status_id" : 403535833560387584,
  "created_at" : "2013-11-21 21:05:23 +0000",
  "in_reply_to_screen_name" : "bcnpaul1",
  "in_reply_to_user_id_str" : "130975050",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 4, 15 ],
      "id_str" : "88202140",
      "id" : 88202140
    }, {
      "name" : "Jeremy Harmer",
      "screen_name" : "Harmerj",
      "indices" : [ 16, 24 ],
      "id_str" : "21094022",
      "id" : 21094022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/qkeQHzLSW9",
      "expanded_url" : "http:\/\/eflnotes.wordpress.com\/2013\/08\/17\/no-time-for-corpora-no-worries\/#comment-1081",
      "display_url" : "eflnotes.wordpress.com\/2013\/08\/17\/no-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "403171506860994561",
  "geo" : { },
  "id_str" : "403475183421247488",
  "in_reply_to_user_id" : 88202140,
  "text" : "fyi @hughdellar @Harmerj @CELTtraining gives a brief outline of their process http:\/\/t.co\/qkeQHzLSW9",
  "id" : 403475183421247488,
  "in_reply_to_status_id" : 403171506860994561,
  "created_at" : "2013-11-21 10:49:14 +0000",
  "in_reply_to_screen_name" : "hughdellar",
  "in_reply_to_user_id_str" : "88202140",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 3, 17 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/WDvgdWbZ2r",
      "expanded_url" : "http:\/\/hackeducation.com\/2013\/11\/20\/top-ed-tech-trends-2013-the-politics-of-education-technology",
      "display_url" : "hackeducation.com\/2013\/11\/20\/top\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "403470855793287168",
  "text" : "RT @audreywatters: Top Ed-Tech Trends of 2013: The Politics of Education\/Technology http:\/\/t.co\/WDvgdWbZ2r",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/WDvgdWbZ2r",
        "expanded_url" : "http:\/\/hackeducation.com\/2013\/11\/20\/top-ed-tech-trends-2013-the-politics-of-education-technology",
        "display_url" : "hackeducation.com\/2013\/11\/20\/top\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "403358792114397185",
    "text" : "Top Ed-Tech Trends of 2013: The Politics of Education\/Technology http:\/\/t.co\/WDvgdWbZ2r",
    "id" : 403358792114397185,
    "created_at" : "2013-11-21 03:06:44 +0000",
    "user" : {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "protected" : false,
      "id_str" : "25388528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711668009723498496\/pauFZsdv_normal.jpg",
      "id" : 25388528,
      "verified" : false
    }
  },
  "id" : 403470855793287168,
  "created_at" : "2013-11-21 10:32:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharon Turner",
      "screen_name" : "Sharonzspace",
      "indices" : [ 0, 13 ],
      "id_str" : "235194378",
      "id" : 235194378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "403271268918497280",
  "geo" : { },
  "id_str" : "403295420975046656",
  "in_reply_to_user_id" : 235194378,
  "text" : "@Sharonzspace hi sharon, great to hear from u, what kind of books? all is good here :)",
  "id" : 403295420975046656,
  "in_reply_to_status_id" : 403271268918497280,
  "created_at" : "2013-11-20 22:54:55 +0000",
  "in_reply_to_screen_name" : "Sharonzspace",
  "in_reply_to_user_id_str" : "235194378",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JP Vergne",
      "screen_name" : "PirateOrg",
      "indices" : [ 3, 13 ],
      "id_str" : "605856131",
      "id" : 605856131
    }, {
      "name" : "Kim Dotcom",
      "screen_name" : "KimDotcom",
      "indices" : [ 109, 119 ],
      "id_str" : "611986351",
      "id" : 611986351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Bitcoin",
      "indices" : [ 54, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/Fl5ZQ9sOXA",
      "expanded_url" : "http:\/\/fiatleak.com",
      "display_url" : "fiatleak.com"
    } ]
  },
  "geo" : { },
  "id_str" : "403186109171380224",
  "text" : "RT @PirateOrg: Watch the world's currencies flow into #Bitcoin in real-time &gt; http:\/\/t.co\/Fl5ZQ9sOXA (thx @KimDotcom) &lt;= looks like we're b\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kim Dotcom",
        "screen_name" : "KimDotcom",
        "indices" : [ 94, 104 ],
        "id_str" : "611986351",
        "id" : 611986351
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Bitcoin",
        "indices" : [ 39, 47 ]
      } ],
      "urls" : [ {
        "indices" : [ 66, 88 ],
        "url" : "http:\/\/t.co\/Fl5ZQ9sOXA",
        "expanded_url" : "http:\/\/fiatleak.com",
        "display_url" : "fiatleak.com"
      } ]
    },
    "geo" : { },
    "id_str" : "402480458157400064",
    "text" : "Watch the world's currencies flow into #Bitcoin in real-time &gt; http:\/\/t.co\/Fl5ZQ9sOXA (thx @KimDotcom) &lt;= looks like we're being 'bitbombed'",
    "id" : 402480458157400064,
    "created_at" : "2013-11-18 16:56:33 +0000",
    "user" : {
      "name" : "JP Vergne",
      "screen_name" : "PirateOrg",
      "protected" : false,
      "id_str" : "605856131",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/647020803503034368\/FHStVVF7_normal.jpg",
      "id" : 605856131,
      "verified" : false
    }
  },
  "id" : 403186109171380224,
  "created_at" : "2013-11-20 15:40:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darius Kazemi",
      "screen_name" : "tinysubversions",
      "indices" : [ 0, 16 ],
      "id_str" : "14475298",
      "id" : 14475298
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "402908295876194304",
  "geo" : { },
  "id_str" : "402929734083829760",
  "in_reply_to_user_id" : 14475298,
  "text" : "@tinysubversions needs more because + noun, because prepostion :)",
  "id" : 402929734083829760,
  "in_reply_to_status_id" : 402908295876194304,
  "created_at" : "2013-11-19 22:41:49 +0000",
  "in_reply_to_screen_name" : "tinysubversions",
  "in_reply_to_user_id_str" : "14475298",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 3, 17 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/6hAEMs8xGh",
      "expanded_url" : "http:\/\/hackeducation.com\/2013\/11\/18\/top-ed-tech-trends-of-2013-zombie-ideas\/",
      "display_url" : "hackeducation.com\/2013\/11\/18\/top\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "402838659768266752",
  "text" : "RT @audreywatters: Top 10 Ed-Tech Trends of 2013: \"Zombie Ideas\" (Ideas That Refuse to Die Even Though We Know They're Monstrous) http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/6hAEMs8xGh",
        "expanded_url" : "http:\/\/hackeducation.com\/2013\/11\/18\/top-ed-tech-trends-of-2013-zombie-ideas\/",
        "display_url" : "hackeducation.com\/2013\/11\/18\/top\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "402627235317694464",
    "text" : "Top 10 Ed-Tech Trends of 2013: \"Zombie Ideas\" (Ideas That Refuse to Die Even Though We Know They're Monstrous) http:\/\/t.co\/6hAEMs8xGh",
    "id" : 402627235317694464,
    "created_at" : "2013-11-19 02:39:48 +0000",
    "user" : {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "protected" : false,
      "id_str" : "25388528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711668009723498496\/pauFZsdv_normal.jpg",
      "id" : 25388528,
      "verified" : false
    }
  },
  "id" : 402838659768266752,
  "created_at" : "2013-11-19 16:39:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SGI Tesol Training",
      "screen_name" : "TesolTrainingUK",
      "indices" : [ 3, 19 ],
      "id_str" : "353681537",
      "id" : 353681537
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tefl",
      "indices" : [ 128, 133 ]
    }, {
      "text" : "elt",
      "indices" : [ 134, 138 ]
    }, {
      "text" : "edchat",
      "indices" : [ 139, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/rqaUTRR87i",
      "expanded_url" : "http:\/\/www.tesoltraining.co.uk\/blog\/reflecting-on-teaching\/lesson-reflection-how-did-the-previous-class-go\/",
      "display_url" : "tesoltraining.co.uk\/blog\/reflectin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "402749364755759104",
  "text" : "RT @TesolTrainingUK: PODCAST: Reflecting on how an audio based lesson went &amp; lessons to take forward http:\/\/t.co\/rqaUTRR87i #tefl #elt #edc\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tefl",
        "indices" : [ 107, 112 ]
      }, {
        "text" : "elt",
        "indices" : [ 113, 117 ]
      }, {
        "text" : "edchat",
        "indices" : [ 118, 125 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/rqaUTRR87i",
        "expanded_url" : "http:\/\/www.tesoltraining.co.uk\/blog\/reflecting-on-teaching\/lesson-reflection-how-did-the-previous-class-go\/",
        "display_url" : "tesoltraining.co.uk\/blog\/reflectin\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "402743954539806720",
    "text" : "PODCAST: Reflecting on how an audio based lesson went &amp; lessons to take forward http:\/\/t.co\/rqaUTRR87i #tefl #elt #edchat",
    "id" : 402743954539806720,
    "created_at" : "2013-11-19 10:23:36 +0000",
    "user" : {
      "name" : "SGI Tesol Training",
      "screen_name" : "TesolTrainingUK",
      "protected" : false,
      "id_str" : "353681537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1491564841\/SGI-teacher-training-specialists_normal.jpg",
      "id" : 353681537,
      "verified" : false
    }
  },
  "id" : 402749364755759104,
  "created_at" : "2013-11-19 10:45:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/ZfbuNTvTNA",
      "expanded_url" : "http:\/\/www.jonathan-cook.net\/blog\/2013-11-18\/bowing-before-the-inquisitors-on-syria\/",
      "display_url" : "jonathan-cook.net\/blog\/2013-11-1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "402609607035854848",
  "text" : "RT @johnwhilley: Jonathan Cook nailing it on Jones, Scahill and Pulse: Bowing before the inquisitors on Syria http:\/\/t.co\/ZfbuNTvTNA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/ZfbuNTvTNA",
        "expanded_url" : "http:\/\/www.jonathan-cook.net\/blog\/2013-11-18\/bowing-before-the-inquisitors-on-syria\/",
        "display_url" : "jonathan-cook.net\/blog\/2013-11-1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "402551060188778496",
    "text" : "Jonathan Cook nailing it on Jones, Scahill and Pulse: Bowing before the inquisitors on Syria http:\/\/t.co\/ZfbuNTvTNA",
    "id" : 402551060188778496,
    "created_at" : "2013-11-18 21:37:06 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 402609607035854848,
  "created_at" : "2013-11-19 01:29:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 53, 69 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/ppUuuzzxLE",
      "expanded_url" : "http:\/\/wp.me\/p405ce-6c",
      "display_url" : "wp.me\/p405ce-6c"
    } ]
  },
  "geo" : { },
  "id_str" : "402570952501764096",
  "text" : "Pie Protest - Lesson Plan http:\/\/t.co\/ppUuuzzxLE via @wordpressdotcom",
  "id" : 402570952501764096,
  "created_at" : "2013-11-18 22:56:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TEFLAnneOKeeffe",
      "screen_name" : "TEFLclass",
      "indices" : [ 3, 13 ],
      "id_str" : "469244585",
      "id" : 469244585
    }, {
      "name" : "Cambridge ELT",
      "screen_name" : "CambridgeUPELT",
      "indices" : [ 110, 125 ],
      "id_str" : "73107903",
      "id" : 73107903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 126, 140 ],
      "url" : "http:\/\/t.co\/VxkPPUePJ0",
      "expanded_url" : "http:\/\/www.cambridgeenglishteacher.org\/eventdetail\/1277",
      "display_url" : "cambridgeenglishteacher.org\/eventdetail\/12\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "402544566978760704",
  "text" : "RT @TEFLclass: I'm giving my first Cambridge webinar this week on Using Grammar to Create a Good Relationship @CambridgeUPELT http:\/\/t.co\/V\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Cambridge ELT",
        "screen_name" : "CambridgeUPELT",
        "indices" : [ 95, 110 ],
        "id_str" : "73107903",
        "id" : 73107903
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/VxkPPUePJ0",
        "expanded_url" : "http:\/\/www.cambridgeenglishteacher.org\/eventdetail\/1277",
        "display_url" : "cambridgeenglishteacher.org\/eventdetail\/12\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "402541111430115328",
    "text" : "I'm giving my first Cambridge webinar this week on Using Grammar to Create a Good Relationship @CambridgeUPELT http:\/\/t.co\/VxkPPUePJ0",
    "id" : 402541111430115328,
    "created_at" : "2013-11-18 20:57:34 +0000",
    "user" : {
      "name" : "TEFLAnneOKeeffe",
      "screen_name" : "TEFLclass",
      "protected" : false,
      "id_str" : "469244585",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000353527279\/c15d358a877f62d20d0e180a1da73b4c_normal.jpeg",
      "id" : 469244585,
      "verified" : false
    }
  },
  "id" : 402544566978760704,
  "created_at" : "2013-11-18 21:11:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Kern\u24C4h\u24B6n",
      "screen_name" : "dkernohan",
      "indices" : [ 3, 13 ],
      "id_str" : "12219232",
      "id" : 12219232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/C0kEdBofeA",
      "expanded_url" : "http:\/\/www.openaccessbutton.org\/",
      "display_url" : "openaccessbutton.org"
    } ]
  },
  "geo" : { },
  "id_str" : "402543963963682818",
  "text" : "RT @dkernohan: Just installed my own Open Access Button http:\/\/t.co\/C0kEdBofeA - do the same and help track how paywalls keep us from resea\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/janetter.net\/\" rel=\"nofollow\"\u003EJanetter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/C0kEdBofeA",
        "expanded_url" : "http:\/\/www.openaccessbutton.org\/",
        "display_url" : "openaccessbutton.org"
      } ]
    },
    "geo" : { },
    "id_str" : "402477298324365312",
    "text" : "Just installed my own Open Access Button http:\/\/t.co\/C0kEdBofeA - do the same and help track how paywalls keep us from research.",
    "id" : 402477298324365312,
    "created_at" : "2013-11-18 16:44:00 +0000",
    "user" : {
      "name" : "David Kern\u24C4h\u24B6n",
      "screen_name" : "dkernohan",
      "protected" : false,
      "id_str" : "12219232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/757702202437804032\/4Xrm7IIe_normal.jpg",
      "id" : 12219232,
      "verified" : false
    }
  },
  "id" : 402543963963682818,
  "created_at" : "2013-11-18 21:08:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anne Hodgson",
      "screen_name" : "annehodg",
      "indices" : [ 43, 52 ],
      "id_str" : "17589213",
      "id" : 17589213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "402411490184945664",
  "geo" : { },
  "id_str" : "402477384185561088",
  "in_reply_to_user_id" : 17589213,
  "text" : "amazing! :) wonder how many shots it took? @annehodg",
  "id" : 402477384185561088,
  "in_reply_to_status_id" : 402411490184945664,
  "created_at" : "2013-11-18 16:44:20 +0000",
  "in_reply_to_screen_name" : "annehodg",
  "in_reply_to_user_id_str" : "17589213",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/4leOeuOhQJ",
      "expanded_url" : "http:\/\/random-idea-english.blogspot.fr\/2013\/11\/random-thoughts-he-was-sat-she-was-stood.html",
      "display_url" : "random-idea-english.blogspot.fr\/2013\/11\/random\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "402474534948704256",
  "text" : "Random Idea English - He was sat, she was stood http:\/\/t.co\/4leOeuOhQJ",
  "id" : 402474534948704256,
  "created_at" : "2013-11-18 16:33:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sophia Khan",
      "screen_name" : "SophiaKhan4",
      "indices" : [ 19, 31 ],
      "id_str" : "351390617",
      "id" : 351390617
    }, {
      "name" : "ESL Karen Benson",
      "screen_name" : "Eslkazzyb",
      "indices" : [ 74, 84 ],
      "id_str" : "339537127",
      "id" : 339537127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 140 ],
      "url" : "http:\/\/t.co\/PzBUpdqLgk",
      "expanded_url" : "http:\/\/www.auselt.com",
      "display_url" : "auselt.com"
    } ]
  },
  "geo" : { },
  "id_str" : "402468352654077952",
  "text" : "RT @AlexSWalsh: RT @SophiaKhan4: Ever wondered if English lessons matter? @Eslkazzyb's post on volunteering in Palestine. http:\/\/t.co\/PzBUp\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sophia Khan",
        "screen_name" : "SophiaKhan4",
        "indices" : [ 3, 15 ],
        "id_str" : "351390617",
        "id" : 351390617
      }, {
        "name" : "ESL Karen Benson",
        "screen_name" : "Eslkazzyb",
        "indices" : [ 58, 68 ],
        "id_str" : "339537127",
        "id" : 339537127
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/PzBUpdqLgk",
        "expanded_url" : "http:\/\/www.auselt.com",
        "display_url" : "auselt.com"
      } ]
    },
    "geo" : { },
    "id_str" : "402379537511890944",
    "text" : "RT @SophiaKhan4: Ever wondered if English lessons matter? @Eslkazzyb's post on volunteering in Palestine. http:\/\/t.co\/PzBUpdqLgk",
    "id" : 402379537511890944,
    "created_at" : "2013-11-18 10:15:32 +0000",
    "user" : {
      "name" : "Alex Walsh",
      "screen_name" : "AlexSRWalsh",
      "protected" : false,
      "id_str" : "228747458",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738934802355617793\/veV8228l_normal.jpg",
      "id" : 228747458,
      "verified" : false
    }
  },
  "id" : 402468352654077952,
  "created_at" : "2013-11-18 16:08:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jack Askew",
      "screen_name" : "eslonlinejack",
      "indices" : [ 3, 17 ],
      "id_str" : "1513170398",
      "id" : 1513170398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/H14tmLqMOJ",
      "expanded_url" : "http:\/\/bit.ly\/1da47CU",
      "display_url" : "bit.ly\/1da47CU"
    } ]
  },
  "geo" : { },
  "id_str" : "402467907248332800",
  "text" : "RT @eslonlinejack: An English lesson that looks at how to describe something using the present simple. Learn English with Derren Brown! htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/H14tmLqMOJ",
        "expanded_url" : "http:\/\/bit.ly\/1da47CU",
        "display_url" : "bit.ly\/1da47CU"
      } ]
    },
    "geo" : { },
    "id_str" : "402424316421087233",
    "text" : "An English lesson that looks at how to describe something using the present simple. Learn English with Derren Brown! http:\/\/t.co\/H14tmLqMOJ",
    "id" : 402424316421087233,
    "created_at" : "2013-11-18 13:13:28 +0000",
    "user" : {
      "name" : "Jack Askew",
      "screen_name" : "eslonlinejack",
      "protected" : false,
      "id_str" : "1513170398",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/484685723677638657\/aIA1Yymj_normal.png",
      "id" : 1513170398,
      "verified" : false
    }
  },
  "id" : 402467907248332800,
  "created_at" : "2013-11-18 16:06:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 60, 69 ],
      "id_str" : "134211317",
      "id" : 134211317
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/Ps3IVZpN15",
      "expanded_url" : "http:\/\/wp.me\/p3Wm0j-73",
      "display_url" : "wp.me\/p3Wm0j-73"
    } ]
  },
  "geo" : { },
  "id_str" : "402169182743040000",
  "text" : "Sherlock Lesson - Spoken grammar http:\/\/t.co\/Ps3IVZpN15 via @josipa74",
  "id" : 402169182743040000,
  "created_at" : "2013-11-17 20:19:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Pride",
      "screen_name" : "ThomasPride",
      "indices" : [ 92, 104 ],
      "id_str" : "385867551",
      "id" : 385867551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/yZZvJRzkaE",
      "expanded_url" : "http:\/\/wp.me\/p1U04a-5Eq",
      "display_url" : "wp.me\/p1U04a-5Eq"
    } ]
  },
  "geo" : { },
  "id_str" : "402028810423386112",
  "text" : "Cameron's (secret) deal to open immigration door to UAE citizens http:\/\/t.co\/yZZvJRzkaE via @ThomasPride",
  "id" : 402028810423386112,
  "created_at" : "2013-11-17 11:01:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anne Hodgson",
      "screen_name" : "annehodg",
      "indices" : [ 3, 12 ],
      "id_str" : "17589213",
      "id" : 17589213
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELTABB",
      "indices" : [ 34, 41 ]
    }, {
      "text" : "Berlin",
      "indices" : [ 45, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/DQu3A5LI0N",
      "expanded_url" : "http:\/\/eltabb.com\/main\/index.php\/gallery",
      "display_url" : "eltabb.com\/main\/index.php\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "402025314253275136",
  "text" : "RT @annehodg: What we're up to at #ELTABB in #Berlin http:\/\/t.co\/DQu3A5LI0N",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELTABB",
        "indices" : [ 20, 27 ]
      }, {
        "text" : "Berlin",
        "indices" : [ 31, 38 ]
      } ],
      "urls" : [ {
        "indices" : [ 39, 61 ],
        "url" : "http:\/\/t.co\/DQu3A5LI0N",
        "expanded_url" : "http:\/\/eltabb.com\/main\/index.php\/gallery",
        "display_url" : "eltabb.com\/main\/index.php\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "402012990192369664",
    "text" : "What we're up to at #ELTABB in #Berlin http:\/\/t.co\/DQu3A5LI0N",
    "id" : 402012990192369664,
    "created_at" : "2013-11-17 09:59:00 +0000",
    "user" : {
      "name" : "Anne Hodgson",
      "screen_name" : "annehodg",
      "protected" : false,
      "id_str" : "17589213",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618152681920724993\/9dLkbtqM_normal.jpg",
      "id" : 17589213,
      "verified" : false
    }
  },
  "id" : 402025314253275136,
  "created_at" : "2013-11-17 10:47:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wilma Luth",
      "screen_name" : "wilma_luth",
      "indices" : [ 3, 14 ],
      "id_str" : "1976998272",
      "id" : 1976998272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/CiPzlJebGY",
      "expanded_url" : "http:\/\/teachandreflect.com\/2013\/11\/17\/the-other-side-of-obvious\/",
      "display_url" : "teachandreflect.com\/2013\/11\/17\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "402019645005529088",
  "text" : "RT @wilma_luth: Maybe you first have to state the obvious before you can get past it to see what's on the other side. http:\/\/t.co\/CiPzlJebGY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/CiPzlJebGY",
        "expanded_url" : "http:\/\/teachandreflect.com\/2013\/11\/17\/the-other-side-of-obvious\/",
        "display_url" : "teachandreflect.com\/2013\/11\/17\/the\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "401975769888333824",
    "text" : "Maybe you first have to state the obvious before you can get past it to see what's on the other side. http:\/\/t.co\/CiPzlJebGY",
    "id" : 401975769888333824,
    "created_at" : "2013-11-17 07:31:06 +0000",
    "user" : {
      "name" : "Wilma Luth",
      "screen_name" : "wilma_luth",
      "protected" : false,
      "id_str" : "1976998272",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000626412348\/1d675a74a95fbeec29aa4cc20d0270a5_normal.jpeg",
      "id" : 1976998272,
      "verified" : false
    }
  },
  "id" : 402019645005529088,
  "created_at" : "2013-11-17 10:25:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hannah Fry",
      "screen_name" : "FryRsquared",
      "indices" : [ 3, 15 ],
      "id_str" : "273375532",
      "id" : 273375532
    }, {
      "name" : "Bored Panda",
      "screen_name" : "boredpanda",
      "indices" : [ 104, 115 ],
      "id_str" : "59627487",
      "id" : 59627487
    }, {
      "name" : "Clive Dent",
      "screen_name" : "CliveDent",
      "indices" : [ 139, 140 ],
      "id_str" : "1160434968",
      "id" : 1160434968
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/VqPRlmYw7G",
      "expanded_url" : "http:\/\/www.boredpanda.com\/snowflake-macro-photography-diy-alexey-kljatov\/",
      "display_url" : "boredpanda.com\/snowflake-macr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "401336451176337408",
  "text" : "RT @FryRsquared: And while we're at it with the procrastinating, some beautiful fractal snowflakes from @boredpanda http:\/\/t.co\/VqPRlmYw7G \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bored Panda",
        "screen_name" : "boredpanda",
        "indices" : [ 87, 98 ],
        "id_str" : "59627487",
        "id" : 59627487
      }, {
        "name" : "Clive Dent",
        "screen_name" : "CliveDent",
        "indices" : [ 126, 136 ],
        "id_str" : "1160434968",
        "id" : 1160434968
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/VqPRlmYw7G",
        "expanded_url" : "http:\/\/www.boredpanda.com\/snowflake-macro-photography-diy-alexey-kljatov\/",
        "display_url" : "boredpanda.com\/snowflake-macr\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "401322984922562560",
    "text" : "And while we're at it with the procrastinating, some beautiful fractal snowflakes from @boredpanda http:\/\/t.co\/VqPRlmYw7G via @CliveDent",
    "id" : 401322984922562560,
    "created_at" : "2013-11-15 12:17:10 +0000",
    "user" : {
      "name" : "Hannah Fry",
      "screen_name" : "FryRsquared",
      "protected" : false,
      "id_str" : "273375532",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/549666331805483009\/vYR8d3e0_normal.jpeg",
      "id" : 273375532,
      "verified" : false
    }
  },
  "id" : 401336451176337408,
  "created_at" : "2013-11-15 13:10:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anne Hodgson",
      "screen_name" : "annehodg",
      "indices" : [ 0, 9 ],
      "id_str" : "17589213",
      "id" : 17589213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/gnEFqIwmh8",
      "expanded_url" : "https:\/\/plus.google.com\/u\/0\/communities\/101266284417587206243",
      "display_url" : "plus.google.com\/u\/0\/communitie\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "401229582864367616",
  "in_reply_to_user_id" : 17589213,
  "text" : "@annehodg thanks for RT anne, please consider hooking up to corp ling and teaching\/learning comm https:\/\/t.co\/gnEFqIwmh8 :)",
  "id" : 401229582864367616,
  "created_at" : "2013-11-15 06:06:01 +0000",
  "in_reply_to_screen_name" : "annehodg",
  "in_reply_to_user_id_str" : "17589213",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TESOL France",
      "screen_name" : "TESOLFrance",
      "indices" : [ 3, 15 ],
      "id_str" : "70341872",
      "id" : 70341872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 123, 140 ],
      "url" : "http:\/\/t.co\/VYCFENsYY3",
      "expanded_url" : "http:\/\/www.youblisher.com\/p\/754760-TESOL-France-Printed-Programme-2013\/",
      "display_url" : "youblisher.com\/p\/754760-TESOL\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "401228318630244352",
  "text" : "RT @TESOLFrance: The complete printed programme of our upcoming conference (Nov. 22-24) is available online! Check it out! http:\/\/t.co\/VYCF\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/VYCFENsYY3",
        "expanded_url" : "http:\/\/www.youblisher.com\/p\/754760-TESOL-France-Printed-Programme-2013\/",
        "display_url" : "youblisher.com\/p\/754760-TESOL\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "401120695184556032",
    "text" : "The complete printed programme of our upcoming conference (Nov. 22-24) is available online! Check it out! http:\/\/t.co\/VYCFENsYY3",
    "id" : 401120695184556032,
    "created_at" : "2013-11-14 22:53:20 +0000",
    "user" : {
      "name" : "TESOL France",
      "screen_name" : "TESOLFrance",
      "protected" : false,
      "id_str" : "70341872",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1789787647\/TESOL_France_logo_normal.jpg",
      "id" : 70341872,
      "verified" : false
    }
  },
  "id" : 401228318630244352,
  "created_at" : "2013-11-15 06:01:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 101, 109 ]
    }, {
      "text" : "tesol",
      "indices" : [ 110, 116 ]
    }, {
      "text" : "elt",
      "indices" : [ 117, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/m2XCaSn7zK",
      "expanded_url" : "https:\/\/plus.google.com\/104940199413423400545\/posts\/YAi5BvbSDUp",
      "display_url" : "plus.google.com\/10494019941342\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "401103463041347584",
  "text" : "read about a nice exercise format for concordance lines from a Dilin Liu pdf https:\/\/t.co\/m2XCaSn7zK #eltchat #tesol #elt",
  "id" : 401103463041347584,
  "created_at" : "2013-11-14 21:44:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Alexander",
      "screen_name" : "BryanAlexander",
      "indices" : [ 3, 18 ],
      "id_str" : "755991",
      "id" : 755991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/KwPu6oiik6",
      "expanded_url" : "http:\/\/oabutton.wordpress.com\/",
      "display_url" : "oabutton.wordpress.com"
    } ]
  },
  "geo" : { },
  "id_str" : "400970825643597824",
  "text" : "RT @BryanAlexander: Behold the Open Access Button, a quick way to show when paywalls block inquiry: http:\/\/t.co\/KwPu6oiik6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/KwPu6oiik6",
        "expanded_url" : "http:\/\/oabutton.wordpress.com\/",
        "display_url" : "oabutton.wordpress.com"
      } ]
    },
    "geo" : { },
    "id_str" : "400722904486141952",
    "text" : "Behold the Open Access Button, a quick way to show when paywalls block inquiry: http:\/\/t.co\/KwPu6oiik6",
    "id" : 400722904486141952,
    "created_at" : "2013-11-13 20:32:40 +0000",
    "user" : {
      "name" : "Bryan Alexander",
      "screen_name" : "BryanAlexander",
      "protected" : false,
      "id_str" : "755991",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/654391499686313986\/1Fx2eBCq_normal.jpg",
      "id" : 755991,
      "verified" : false
    }
  },
  "id" : 400970825643597824,
  "created_at" : "2013-11-14 12:57:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Guardian",
      "screen_name" : "guardian",
      "indices" : [ 3, 12 ],
      "id_str" : "87818409",
      "id" : 87818409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/wScfkyWfMG",
      "expanded_url" : "http:\/\/trib.al\/47LcvLJ",
      "display_url" : "trib.al\/47LcvLJ"
    } ]
  },
  "geo" : { },
  "id_str" : "400711708265943040",
  "text" : "RT @guardian: Occupy Wall Street activists buy $15m of Americans' personal debt http:\/\/t.co\/wScfkyWfMG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 88 ],
        "url" : "http:\/\/t.co\/wScfkyWfMG",
        "expanded_url" : "http:\/\/trib.al\/47LcvLJ",
        "display_url" : "trib.al\/47LcvLJ"
      } ]
    },
    "geo" : { },
    "id_str" : "400560160042913792",
    "text" : "Occupy Wall Street activists buy $15m of Americans' personal debt http:\/\/t.co\/wScfkyWfMG",
    "id" : 400560160042913792,
    "created_at" : "2013-11-13 09:45:58 +0000",
    "user" : {
      "name" : "The Guardian",
      "screen_name" : "guardian",
      "protected" : false,
      "id_str" : "87818409",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/715857640853741568\/nfNt_pGn_normal.jpg",
      "id" : 87818409,
      "verified" : true
    }
  },
  "id" : 400711708265943040,
  "created_at" : "2013-11-13 19:48:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 79, 95 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/KVMUnaWRsU",
      "expanded_url" : "http:\/\/wp.me\/pglsT-4qf",
      "display_url" : "wp.me\/pglsT-4qf"
    } ]
  },
  "geo" : { },
  "id_str" : "400691226178879488",
  "text" : "\u2018Because\u2019 has become a preposition, because grammar http:\/\/t.co\/KVMUnaWRsU via @wordpressdotcom",
  "id" : 400691226178879488,
  "created_at" : "2013-11-13 18:26:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sylvia A. Sierra",
      "screen_name" : "sociolinguista",
      "indices" : [ 3, 18 ],
      "id_str" : "322933176",
      "id" : 322933176
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 140 ],
      "url" : "http:\/\/t.co\/0uTSd5NV3t",
      "expanded_url" : "http:\/\/nonomella.tumblr.com\/post\/66672487041\/i-made-this-powerpoint-for-this-weeks-lesson",
      "display_url" : "nonomella.tumblr.com\/post\/666724870\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "400645609793028096",
  "text" : "RT @sociolinguista: IT IS LIKE BLOOOD - What my Chinese students think of my 'regional iconic America food' presentation http:\/\/t.co\/0uTSd5\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/0uTSd5NV3t",
        "expanded_url" : "http:\/\/nonomella.tumblr.com\/post\/66672487041\/i-made-this-powerpoint-for-this-weeks-lesson",
        "display_url" : "nonomella.tumblr.com\/post\/666724870\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "400609417768738816",
    "text" : "IT IS LIKE BLOOOD - What my Chinese students think of my 'regional iconic America food' presentation http:\/\/t.co\/0uTSd5NV3t",
    "id" : 400609417768738816,
    "created_at" : "2013-11-13 13:01:42 +0000",
    "user" : {
      "name" : "Sylvia A. Sierra",
      "screen_name" : "sociolinguista",
      "protected" : false,
      "id_str" : "322933176",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629274368552632321\/D3T83FXn_normal.jpg",
      "id" : 322933176,
      "verified" : false
    }
  },
  "id" : 400645609793028096,
  "created_at" : "2013-11-13 15:25:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Hawksey",
      "screen_name" : "mhawksey",
      "indices" : [ 3, 12 ],
      "id_str" : "13046992",
      "id" : 13046992
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "altc",
      "indices" : [ 118, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/CnOujryC3A",
      "expanded_url" : "http:\/\/collaborative-tools-project.blogspot.co.uk\/2013\/11\/using-hangouts-on-air-to-run.html",
      "display_url" : "\u2026borative-tools-project.blogspot.co.uk\/2013\/11\/using-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "400569775145103360",
  "text" : "RT @mhawksey: Using Hangouts on Air To Run A Distributed Mini Conference http:\/\/t.co\/CnOujryC3A ..  the possibilities #altc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "altc",
        "indices" : [ 104, 109 ]
      } ],
      "urls" : [ {
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/CnOujryC3A",
        "expanded_url" : "http:\/\/collaborative-tools-project.blogspot.co.uk\/2013\/11\/using-hangouts-on-air-to-run.html",
        "display_url" : "\u2026borative-tools-project.blogspot.co.uk\/2013\/11\/using-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "400338408884961280",
    "text" : "Using Hangouts on Air To Run A Distributed Mini Conference http:\/\/t.co\/CnOujryC3A ..  the possibilities #altc",
    "id" : 400338408884961280,
    "created_at" : "2013-11-12 19:04:49 +0000",
    "user" : {
      "name" : "Martin Hawksey",
      "screen_name" : "mhawksey",
      "protected" : false,
      "id_str" : "13046992",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2390851993\/xu6aptqy6a8rb2h2w5by_normal.jpeg",
      "id" : 13046992,
      "verified" : false
    }
  },
  "id" : 400569775145103360,
  "created_at" : "2013-11-13 10:24:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Hawksey",
      "screen_name" : "mhawksey",
      "indices" : [ 3, 12 ],
      "id_str" : "13046992",
      "id" : 13046992
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/mhawksey\/status\/400365253583568896\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/UxyDaqWOne",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BY5iE7DCAAA6Ilh.png",
      "id_str" : "400365253591957504",
      "id" : 400365253591957504,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BY5iE7DCAAA6Ilh.png",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 638
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 638
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 322,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 568,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/UxyDaqWOne"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/zx9MD1I8sS",
      "expanded_url" : "https:\/\/blog.twitter.com\/2013\/custom-timelines-in-tweetdeck",
      "display_url" : "blog.twitter.com\/2013\/custom-ti\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "400568918835986432",
  "text" : "RT @mhawksey: Twitter now support curated tweet streams with custom timelines https:\/\/t.co\/zx9MD1I8sS http:\/\/t.co\/UxyDaqWOne",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/mhawksey\/status\/400365253583568896\/photo\/1",
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/UxyDaqWOne",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BY5iE7DCAAA6Ilh.png",
        "id_str" : "400365253591957504",
        "id" : 400365253591957504,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BY5iE7DCAAA6Ilh.png",
        "sizes" : [ {
          "h" : 604,
          "resize" : "fit",
          "w" : 638
        }, {
          "h" : 604,
          "resize" : "fit",
          "w" : 638
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 322,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 568,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/UxyDaqWOne"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/zx9MD1I8sS",
        "expanded_url" : "https:\/\/blog.twitter.com\/2013\/custom-timelines-in-tweetdeck",
        "display_url" : "blog.twitter.com\/2013\/custom-ti\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "400365253583568896",
    "text" : "Twitter now support curated tweet streams with custom timelines https:\/\/t.co\/zx9MD1I8sS http:\/\/t.co\/UxyDaqWOne",
    "id" : 400365253583568896,
    "created_at" : "2013-11-12 20:51:30 +0000",
    "user" : {
      "name" : "Martin Hawksey",
      "screen_name" : "mhawksey",
      "protected" : false,
      "id_str" : "13046992",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2390851993\/xu6aptqy6a8rb2h2w5by_normal.jpeg",
      "id" : 13046992,
      "verified" : false
    }
  },
  "id" : 400568918835986432,
  "created_at" : "2013-11-13 10:20:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donald Clark",
      "screen_name" : "DonaldClark",
      "indices" : [ 3, 15 ],
      "id_str" : "1632891",
      "id" : 1632891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/GM661AaEky",
      "expanded_url" : "http:\/\/bit.ly\/1eKRvlz",
      "display_url" : "bit.ly\/1eKRvlz"
    } ]
  },
  "geo" : { },
  "id_str" : "400566926386409472",
  "text" : "RT @DonaldClark: Grayson Perry \u2013 ramblings of a rip-off celeb http:\/\/t.co\/GM661AaEky",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 67 ],
        "url" : "http:\/\/t.co\/GM661AaEky",
        "expanded_url" : "http:\/\/bit.ly\/1eKRvlz",
        "display_url" : "bit.ly\/1eKRvlz"
      } ]
    },
    "geo" : { },
    "id_str" : "400556593957191680",
    "text" : "Grayson Perry \u2013 ramblings of a rip-off celeb http:\/\/t.co\/GM661AaEky",
    "id" : 400556593957191680,
    "created_at" : "2013-11-13 09:31:48 +0000",
    "user" : {
      "name" : "Donald Clark",
      "screen_name" : "DonaldClark",
      "protected" : false,
      "id_str" : "1632891",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/513085530695663616\/BfWK4n6u_normal.jpeg",
      "id" : 1632891,
      "verified" : false
    }
  },
  "id" : 400566926386409472,
  "created_at" : "2013-11-13 10:12:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulmaglione",
      "screen_name" : "paulmaglione",
      "indices" : [ 40, 53 ],
      "id_str" : "14094921",
      "id" : 14094921
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/OM5iKK6EkX",
      "expanded_url" : "http:\/\/skrashen.blogspot.fr\/2013\/11\/not-valid-test-of-english.html",
      "display_url" : "skrashen.blogspot.fr\/2013\/11\/not-va\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "400553439781871616",
  "geo" : { },
  "id_str" : "400562372772757505",
  "in_reply_to_user_id" : 14094921,
  "text" : "krashen has interesting comment on this @paulmaglione http:\/\/t.co\/OM5iKK6EkX",
  "id" : 400562372772757505,
  "in_reply_to_status_id" : 400553439781871616,
  "created_at" : "2013-11-13 09:54:46 +0000",
  "in_reply_to_screen_name" : "paulmaglione",
  "in_reply_to_user_id_str" : "14094921",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 61, 77 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/3y5haUUHr1",
      "expanded_url" : "http:\/\/wp.me\/p2IyBp-lf",
      "display_url" : "wp.me\/p2IyBp-lf"
    } ]
  },
  "geo" : { },
  "id_str" : "400291026062934016",
  "text" : "Dictogloss sample about housework http:\/\/t.co\/3y5haUUHr1 via @wordpressdotcom",
  "id" : 400291026062934016,
  "created_at" : "2013-11-12 15:56:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mariangela Mihai",
      "screen_name" : "MariangelaMihai",
      "indices" : [ 15, 31 ],
      "id_str" : "1620330066",
      "id" : 1620330066
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "400161056544157697",
  "text" : "@Florentina__T @MariangelaMihai nice thinking there :)",
  "id" : 400161056544157697,
  "created_at" : "2013-11-12 07:20:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anne Hodgson",
      "screen_name" : "annehodg",
      "indices" : [ 0, 9 ],
      "id_str" : "17589213",
      "id" : 17589213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400085109593739264",
  "geo" : { },
  "id_str" : "400159383620820992",
  "in_reply_to_user_id" : 17589213,
  "text" : "@annehodg exact :)",
  "id" : 400159383620820992,
  "in_reply_to_status_id" : 400085109593739264,
  "created_at" : "2013-11-12 07:13:26 +0000",
  "in_reply_to_screen_name" : "annehodg",
  "in_reply_to_user_id_str" : "17589213",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 104, 120 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/vw5aQF3UaI",
      "expanded_url" : "http:\/\/wp.me\/p3augf-bh",
      "display_url" : "wp.me\/p3augf-bh"
    } ]
  },
  "geo" : { },
  "id_str" : "400011844707831808",
  "text" : "\u201CI cannot avoid mixing an asiatic tincture\u201D: a historical perspective on ESL http:\/\/t.co\/vw5aQF3UaI via @wordpressdotcom",
  "id" : 400011844707831808,
  "created_at" : "2013-11-11 21:27:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anne Hodgson",
      "screen_name" : "annehodg",
      "indices" : [ 0, 9 ],
      "id_str" : "17589213",
      "id" : 17589213
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/400010324008386560\/photo\/1",
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/sl1XAeN5rn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BY0fRTWCQAAn4cF.png",
      "id_str" : "400010324016775168",
      "id" : 400010324016775168,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BY0fRTWCQAAn4cF.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 451,
        "resize" : "fit",
        "w" : 1075
      }, {
        "h" : 143,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 430,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 252,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/sl1XAeN5rn"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/cW3cQ8h9PW",
      "expanded_url" : "http:\/\/smlc09.leeds.ac.uk\/itb\/htdocs\/Query.html#",
      "display_url" : "smlc09.leeds.ac.uk\/itb\/htdocs\/Que\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "400002011023687682",
  "geo" : { },
  "id_str" : "400010324008386560",
  "in_reply_to_user_id" : 17589213,
  "text" : "@annehodg attached collocation screenshot gives a big clue ( from http:\/\/t.co\/cW3cQ8h9PW) http:\/\/t.co\/sl1XAeN5rn",
  "id" : 400010324008386560,
  "in_reply_to_status_id" : 400002011023687682,
  "created_at" : "2013-11-11 21:21:07 +0000",
  "in_reply_to_screen_name" : "annehodg",
  "in_reply_to_user_id_str" : "17589213",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jo Sayers",
      "screen_name" : "jo_sayers",
      "indices" : [ 0, 10 ],
      "id_str" : "87176766",
      "id" : 87176766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/gnEFqIwmh8",
      "expanded_url" : "https:\/\/plus.google.com\/u\/0\/communities\/101266284417587206243",
      "display_url" : "plus.google.com\/u\/0\/communitie\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "399929898636021760",
  "geo" : { },
  "id_str" : "399961052823031808",
  "in_reply_to_user_id" : 87176766,
  "text" : "@jo_sayers nice! join up and post to page&amp;brin's site https:\/\/t.co\/gnEFqIwmh8 :)",
  "id" : 399961052823031808,
  "in_reply_to_status_id" : 399929898636021760,
  "created_at" : "2013-11-11 18:05:20 +0000",
  "in_reply_to_screen_name" : "jo_sayers",
  "in_reply_to_user_id_str" : "87176766",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Sakamoto ",
      "screen_name" : "barbsaka",
      "indices" : [ 3, 12 ],
      "id_str" : "2970224781",
      "id" : 2970224781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/qpNzRTzwsO",
      "expanded_url" : "http:\/\/bit.ly\/1bnp6yJ",
      "display_url" : "bit.ly\/1bnp6yJ"
    } ]
  },
  "geo" : { },
  "id_str" : "399894265113100289",
  "text" : "RT @barbsaka: Set strict limits to increase creativiity! New blog post by Daniel Olsson on Teaching Village http:\/\/t.co\/qpNzRTzwsO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/qpNzRTzwsO",
        "expanded_url" : "http:\/\/bit.ly\/1bnp6yJ",
        "display_url" : "bit.ly\/1bnp6yJ"
      } ]
    },
    "geo" : { },
    "id_str" : "399869010952876032",
    "text" : "Set strict limits to increase creativiity! New blog post by Daniel Olsson on Teaching Village http:\/\/t.co\/qpNzRTzwsO",
    "id" : 399869010952876032,
    "created_at" : "2013-11-11 11:59:36 +0000",
    "user" : {
      "name" : "Teaching Village",
      "screen_name" : "TeachingVillage",
      "protected" : false,
      "id_str" : "19234804",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/253051119\/Barb_thumbnail_normal.jpg",
      "id" : 19234804,
      "verified" : false
    }
  },
  "id" : 399894265113100289,
  "created_at" : "2013-11-11 13:39:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Huw Jarvis",
      "screen_name" : "TESOLacademic",
      "indices" : [ 3, 17 ],
      "id_str" : "43409552",
      "id" : 43409552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/TIsuZE9luE",
      "expanded_url" : "http:\/\/bit.ly\/17owH0Y",
      "display_url" : "bit.ly\/17owH0Y"
    } ]
  },
  "geo" : { },
  "id_str" : "399652650767364096",
  "text" : "RT @TESOLacademic: Video Assistance for Understanding Language Teaching - http:\/\/t.co\/TIsuZE9luE An excellent work in progress resource",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/TIsuZE9luE",
        "expanded_url" : "http:\/\/bit.ly\/17owH0Y",
        "display_url" : "bit.ly\/17owH0Y"
      } ]
    },
    "geo" : { },
    "id_str" : "399536595029618689",
    "text" : "Video Assistance for Understanding Language Teaching - http:\/\/t.co\/TIsuZE9luE An excellent work in progress resource",
    "id" : 399536595029618689,
    "created_at" : "2013-11-10 13:58:41 +0000",
    "user" : {
      "name" : "Huw Jarvis",
      "screen_name" : "TESOLacademic",
      "protected" : false,
      "id_str" : "43409552",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/569419268\/bg-logo_normal.jpg",
      "id" : 43409552,
      "verified" : false
    }
  },
  "id" : 399652650767364096,
  "created_at" : "2013-11-10 21:39:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michel Gondry",
      "screen_name" : "MichelGondry",
      "indices" : [ 3, 16 ],
      "id_str" : "112552471",
      "id" : 112552471
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 146, 147 ],
      "url" : "http:\/\/t.co\/zebYdS4z8s",
      "expanded_url" : "http:\/\/ow.ly\/qg88Q",
      "display_url" : "ow.ly\/qg88Q"
    } ]
  },
  "geo" : { },
  "id_str" : "399577262070464512",
  "text" : "RT @MichelGondry: Is the Man Who is Tall Happy ?\nAn animated conversation with Noam Chomsky - In US theaters 11\/22 &amp; iTunes 11\/25 &gt; http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/zebYdS4z8s",
        "expanded_url" : "http:\/\/ow.ly\/qg88Q",
        "display_url" : "ow.ly\/qg88Q"
      } ]
    },
    "geo" : { },
    "id_str" : "394925069387849728",
    "text" : "Is the Man Who is Tall Happy ?\nAn animated conversation with Noam Chomsky - In US theaters 11\/22 &amp; iTunes 11\/25 &gt; http:\/\/t.co\/zebYdS4z8s",
    "id" : 394925069387849728,
    "created_at" : "2013-10-28 20:34:08 +0000",
    "user" : {
      "name" : "Michel Gondry",
      "screen_name" : "MichelGondry",
      "protected" : false,
      "id_str" : "112552471",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3069094357\/3dc0d58daf2c6c58b4682f47d4ce3154_normal.png",
      "id" : 112552471,
      "verified" : true
    }
  },
  "id" : 399577262070464512,
  "created_at" : "2013-11-10 16:40:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "399568223160791040",
  "geo" : { },
  "id_str" : "399568794110021632",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan i think there are a few of those online no?",
  "id" : 399568794110021632,
  "in_reply_to_status_id" : 399568223160791040,
  "created_at" : "2013-11-10 16:06:38 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/YaIGEgsA0W",
      "expanded_url" : "http:\/\/wordandphrase.info\/",
      "display_url" : "wordandphrase.info"
    } ]
  },
  "in_reply_to_status_id_str" : "399564880866336768",
  "geo" : { },
  "id_str" : "399567809631375361",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan it's true developer the evil lex luther works on sundays!?  maybe http:\/\/t.co\/YaIGEgsA0W can help out?",
  "id" : 399567809631375361,
  "in_reply_to_status_id" : 399564880866336768,
  "created_at" : "2013-11-10 16:02:44 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeven",
      "screen_name" : "Jeeves_",
      "indices" : [ 0, 8 ],
      "id_str" : "155264443",
      "id" : 155264443
    }, {
      "name" : "evanfrendo",
      "screen_name" : "evanfrendo",
      "indices" : [ 24, 35 ],
      "id_str" : "17589664",
      "id" : 17589664
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/h4mwOlUzj5",
      "expanded_url" : "http:\/\/verbs.colorado.edu\/enronsent\/",
      "display_url" : "verbs.colorado.edu\/enronsent\/"
    } ]
  },
  "in_reply_to_status_id_str" : "399503762999771136",
  "geo" : { },
  "id_str" : "399508089658810369",
  "in_reply_to_user_id" : 20842594,
  "text" : "@jeeves_ @MattHalsdorff @evanfrendo i'd recommend the enron sent version for offline use http:\/\/t.co\/h4mwOlUzj5",
  "id" : 399508089658810369,
  "in_reply_to_status_id" : 399503762999771136,
  "created_at" : "2013-11-10 12:05:25 +0000",
  "in_reply_to_screen_name" : "peteruthe",
  "in_reply_to_user_id_str" : "20842594",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Gillett",
      "screen_name" : "UEfAP",
      "indices" : [ 23, 29 ],
      "id_str" : "235529625",
      "id" : 235529625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "399139058385178624",
  "geo" : { },
  "id_str" : "399156583797489664",
  "in_reply_to_user_id" : 235529625,
  "text" : "this happens in France @UEfAP, graduate students arrange and pay for refreshments",
  "id" : 399156583797489664,
  "in_reply_to_status_id" : 399139058385178624,
  "created_at" : "2013-11-09 12:48:40 +0000",
  "in_reply_to_screen_name" : "UEfAP",
  "in_reply_to_user_id_str" : "235529625",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hancock McDonald ELT",
      "screen_name" : "HancockMcDonald",
      "indices" : [ 3, 19 ],
      "id_str" : "552929354",
      "id" : 552929354
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EnglishUK",
      "indices" : [ 21, 31 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/JfblU5LxGL",
      "expanded_url" : "http:\/\/tinyurl.com\/nq8qrly",
      "display_url" : "tinyurl.com\/nq8qrly"
    } ]
  },
  "geo" : { },
  "id_str" : "399151756665704450",
  "text" : "RT @HancockMcDonald: #EnglishUK Annie McDonald's talk is \"Teaching Listening with Authentic Texts\" with a guest appearance by Viking mice h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EnglishUK",
        "indices" : [ 0, 10 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/JfblU5LxGL",
        "expanded_url" : "http:\/\/tinyurl.com\/nq8qrly",
        "display_url" : "tinyurl.com\/nq8qrly"
      } ]
    },
    "geo" : { },
    "id_str" : "398767863860715520",
    "text" : "#EnglishUK Annie McDonald's talk is \"Teaching Listening with Authentic Texts\" with a guest appearance by Viking mice http:\/\/t.co\/JfblU5LxGL",
    "id" : 398767863860715520,
    "created_at" : "2013-11-08 11:04:02 +0000",
    "user" : {
      "name" : "Hancock McDonald ELT",
      "screen_name" : "HancockMcDonald",
      "protected" : false,
      "id_str" : "552929354",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2158919436\/HM_portrait_normal.jpg",
      "id" : 552929354,
      "verified" : false
    }
  },
  "id" : 399151756665704450,
  "created_at" : "2013-11-09 12:29:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Vimeo",
      "indices" : [ 66, 72 ]
    }, {
      "text" : "beeple",
      "indices" : [ 73, 80 ]
    }, {
      "text" : "mikewinkelmann",
      "indices" : [ 81, 96 ]
    }, {
      "text" : "cinema4d",
      "indices" : [ 97, 106 ]
    }, {
      "text" : "privacy",
      "indices" : [ 107, 115 ]
    }, {
      "text" : "nsa",
      "indices" : [ 116, 120 ]
    }, {
      "text" : "3danimation",
      "indices" : [ 121, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/1lXSxQIiPD",
      "expanded_url" : "http:\/\/vimeo.com\/78716671",
      "display_url" : "vimeo.com\/78716671"
    } ]
  },
  "geo" : { },
  "id_str" : "399143156374978560",
  "text" : "Check out \"Transparent Machines\u2122\" on Vimeo http:\/\/t.co\/1lXSxQIiPD #Vimeo #beeple #mikewinkelmann #cinema4d #privacy #nsa #3danimation",
  "id" : 399143156374978560,
  "created_at" : "2013-11-09 11:55:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Idibon",
      "screen_name" : "idibon",
      "indices" : [ 3, 10 ],
      "id_str" : "749992082",
      "id" : 749992082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/1fbqaEHPBj",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?feature=player_embedded&v=OnlvPsPyPKk",
      "display_url" : "youtube.com\/watch?feature=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "399105684819968000",
  "text" : "RT @idibon: It's quick and you want to listen to it: \"Huh?\" across the world.\n\nhttps:\/\/t.co\/1fbqaEHPBj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/1fbqaEHPBj",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?feature=player_embedded&v=OnlvPsPyPKk",
        "display_url" : "youtube.com\/watch?feature=\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "398953970909319169",
    "text" : "It's quick and you want to listen to it: \"Huh?\" across the world.\n\nhttps:\/\/t.co\/1fbqaEHPBj",
    "id" : 398953970909319169,
    "created_at" : "2013-11-08 23:23:33 +0000",
    "user" : {
      "name" : "Idibon",
      "screen_name" : "idibon",
      "protected" : false,
      "id_str" : "749992082",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/577899744749481985\/ospcUqfV_normal.jpeg",
      "id" : 749992082,
      "verified" : false
    }
  },
  "id" : 399105684819968000,
  "created_at" : "2013-11-09 09:26:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neyran Reis Kaleli",
      "screen_name" : "nreiskaleli",
      "indices" : [ 0, 12 ],
      "id_str" : "149636726",
      "id" : 149636726
    }, {
      "name" : "Monika Sobejko",
      "screen_name" : "SobejM",
      "indices" : [ 34, 41 ],
      "id_str" : "380504775",
      "id" : 380504775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/gnEFqIwmh8",
      "expanded_url" : "https:\/\/plus.google.com\/u\/0\/communities\/101266284417587206243",
      "display_url" : "plus.google.com\/u\/0\/communitie\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "399104452969238529",
  "in_reply_to_user_id" : 149636726,
  "text" : "@nreiskaleli hi thanks for fav of @SobejM post for more corpora stuff please consider joining g+ community https:\/\/t.co\/gnEFqIwmh8 :)",
  "id" : 399104452969238529,
  "created_at" : "2013-11-09 09:21:31 +0000",
  "in_reply_to_screen_name" : "nreiskaleli",
  "in_reply_to_user_id_str" : "149636726",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 90, 106 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/16NNaGs8ub",
      "expanded_url" : "http:\/\/wp.me\/p3KSwB-8o",
      "display_url" : "wp.me\/p3KSwB-8o"
    } ]
  },
  "geo" : { },
  "id_str" : "398815807326539777",
  "text" : "\"You'll Have to Speak Up, I'm Wearing a Towel\" --Homer Simpson http:\/\/t.co\/16NNaGs8ub via @wordpressdotcom",
  "id" : 398815807326539777,
  "created_at" : "2013-11-08 14:14:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 27, 38 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398804741804654592",
  "geo" : { },
  "id_str" : "398815691538567170",
  "in_reply_to_user_id" : 300734173,
  "text" : "yr welcome thx for sharing @lexicoloco; have u joined the learner corpora association? if so is it worth joining?",
  "id" : 398815691538567170,
  "in_reply_to_status_id" : 398804741804654592,
  "created_at" : "2013-11-08 14:14:05 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpora",
      "indices" : [ 12, 20 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 75, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/KyMco55htz",
      "expanded_url" : "https:\/\/plus.google.com\/104940199413423400545\/posts\/Lfg3xbnkHHn",
      "display_url" : "plus.google.com\/10494019941342\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "398802770372722688",
  "text" : "looking for #corpora with 230 languages? look here https:\/\/t.co\/KyMco55htz #eltchat",
  "id" : 398802770372722688,
  "created_at" : "2013-11-08 13:22:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Alec Couros",
      "screen_name" : "courosa",
      "indices" : [ 3, 11 ],
      "id_str" : "739293",
      "id" : 739293
    }, {
      "name" : "Clarence Fisher",
      "screen_name" : "glassbeed",
      "indices" : [ 16, 26 ],
      "id_str" : "5926752",
      "id" : 5926752
    }, {
      "name" : "Dean Shareski",
      "screen_name" : "shareski",
      "indices" : [ 121, 130 ],
      "id_str" : "739743",
      "id" : 739743
    }, {
      "name" : "Dr. Alec Couros",
      "screen_name" : "courosa",
      "indices" : [ 131, 139 ],
      "id_str" : "739293",
      "id" : 739293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/iVATOV91NE",
      "expanded_url" : "http:\/\/www.cbc.ca\/news\/canada\/saskatchewan\/3d-printer-by-sask-man-gets-record-crowdsourced-cash-1.2417416",
      "display_url" : "cbc.ca\/news\/canada\/sa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "398685133261512704",
  "text" : "RT @courosa: RT @glassbeed: Saskatchewan man creates a 3D printer that will sell for around $100: http:\/\/t.co\/iVATOV91NE @shareski @courosa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Clarence Fisher",
        "screen_name" : "glassbeed",
        "indices" : [ 3, 13 ],
        "id_str" : "5926752",
        "id" : 5926752
      }, {
        "name" : "Dean Shareski",
        "screen_name" : "shareski",
        "indices" : [ 108, 117 ],
        "id_str" : "739743",
        "id" : 739743
      }, {
        "name" : "Dr. Alec Couros",
        "screen_name" : "courosa",
        "indices" : [ 118, 126 ],
        "id_str" : "739293",
        "id" : 739293
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/iVATOV91NE",
        "expanded_url" : "http:\/\/www.cbc.ca\/news\/canada\/saskatchewan\/3d-printer-by-sask-man-gets-record-crowdsourced-cash-1.2417416",
        "display_url" : "cbc.ca\/news\/canada\/sa\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "398680392074412032",
    "text" : "RT @glassbeed: Saskatchewan man creates a 3D printer that will sell for around $100: http:\/\/t.co\/iVATOV91NE @shareski @courosa",
    "id" : 398680392074412032,
    "created_at" : "2013-11-08 05:16:27 +0000",
    "user" : {
      "name" : "Dr. Alec Couros",
      "screen_name" : "courosa",
      "protected" : false,
      "id_str" : "739293",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/480186733221249027\/bzI2RIfo_normal.jpeg",
      "id" : 739293,
      "verified" : false
    }
  },
  "id" : 398685133261512704,
  "created_at" : "2013-11-08 05:35:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Whyte",
      "screen_name" : "eslwriter",
      "indices" : [ 0, 10 ],
      "id_str" : "187481025",
      "id" : 187481025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398593863922626560",
  "geo" : { },
  "id_str" : "398597464434814976",
  "in_reply_to_user_id" : 187481025,
  "text" : "@eslwriter Charlotte YYX in comments points out glaring misreading of report; checked and she is right, how did this article get written?!",
  "id" : 398597464434814976,
  "in_reply_to_status_id" : 398593863922626560,
  "created_at" : "2013-11-07 23:46:55 +0000",
  "in_reply_to_screen_name" : "eslwriter",
  "in_reply_to_user_id_str" : "187481025",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 3, 17 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opened13",
      "indices" : [ 58, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/pTPcl5EXt5",
      "expanded_url" : "http:\/\/hackeducation.com\/2013\/11\/07\/the-education-apocalypse",
      "display_url" : "hackeducation.com\/2013\/11\/07\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "398563536869543936",
  "text" : "RT @audreywatters: Notes and slides from my talk today at #opened13 http:\/\/t.co\/pTPcl5EXt5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "opened13",
        "indices" : [ 39, 48 ]
      } ],
      "urls" : [ {
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/pTPcl5EXt5",
        "expanded_url" : "http:\/\/hackeducation.com\/2013\/11\/07\/the-education-apocalypse",
        "display_url" : "hackeducation.com\/2013\/11\/07\/the\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "398523439591346176",
    "text" : "Notes and slides from my talk today at #opened13 http:\/\/t.co\/pTPcl5EXt5",
    "id" : 398523439591346176,
    "created_at" : "2013-11-07 18:52:46 +0000",
    "user" : {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "protected" : false,
      "id_str" : "25388528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711668009723498496\/pauFZsdv_normal.jpg",
      "id" : 25388528,
      "verified" : false
    }
  },
  "id" : 398563536869543936,
  "created_at" : "2013-11-07 21:32:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyler Schnoebelen",
      "screen_name" : "TSchnoebelen",
      "indices" : [ 3, 16 ],
      "id_str" : "14969147",
      "id" : 14969147
    }, {
      "name" : "Timothy McSweeney",
      "screen_name" : "mcsweeneys",
      "indices" : [ 19, 30 ],
      "id_str" : "30109507",
      "id" : 30109507
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/aY18eNJwRa",
      "expanded_url" : "http:\/\/ow.ly\/26NJoB",
      "display_url" : "ow.ly\/26NJoB"
    } ]
  },
  "geo" : { },
  "id_str" : "398549463423537152",
  "text" : "RT @TSchnoebelen: .@mcsweeneys The most popular \"numeric mnemonics\" since 1800 (\"the 3 R's\" takes 1st place) http:\/\/t.co\/aY18eNJwRa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Timothy McSweeney",
        "screen_name" : "mcsweeneys",
        "indices" : [ 1, 12 ],
        "id_str" : "30109507",
        "id" : 30109507
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/aY18eNJwRa",
        "expanded_url" : "http:\/\/ow.ly\/26NJoB",
        "display_url" : "ow.ly\/26NJoB"
      } ]
    },
    "in_reply_to_status_id_str" : "398490036708343809",
    "geo" : { },
    "id_str" : "398493668447125504",
    "in_reply_to_user_id" : 30109507,
    "text" : ".@mcsweeneys The most popular \"numeric mnemonics\" since 1800 (\"the 3 R's\" takes 1st place) http:\/\/t.co\/aY18eNJwRa",
    "id" : 398493668447125504,
    "in_reply_to_status_id" : 398490036708343809,
    "created_at" : "2013-11-07 16:54:28 +0000",
    "in_reply_to_screen_name" : "mcsweeneys",
    "in_reply_to_user_id_str" : "30109507",
    "user" : {
      "name" : "Tyler Schnoebelen",
      "screen_name" : "TSchnoebelen",
      "protected" : false,
      "id_str" : "14969147",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/604427674203779072\/Y4t_NODB_normal.jpg",
      "id" : 14969147,
      "verified" : false
    }
  },
  "id" : 398549463423537152,
  "created_at" : "2013-11-07 20:36:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "First State",
      "screen_name" : "FirstStateMusic",
      "indices" : [ 0, 16 ],
      "id_str" : "50027817",
      "id" : 50027817
    }, {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 17, 32 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398511298423435265",
  "geo" : { },
  "id_str" : "398545122654027776",
  "in_reply_to_user_id" : 50027817,
  "text" : "@FirstStateMusic @MrChrisJWilson does it go to 11?",
  "id" : 398545122654027776,
  "in_reply_to_status_id" : 398511298423435265,
  "created_at" : "2013-11-07 20:18:56 +0000",
  "in_reply_to_screen_name" : "FirstStateMusic",
  "in_reply_to_user_id_str" : "50027817",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 111, 127 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/fF0785ZGdx",
      "expanded_url" : "http:\/\/wp.me\/p1mEF-2VI",
      "display_url" : "wp.me\/p1mEF-2VI"
    } ]
  },
  "geo" : { },
  "id_str" : "398486034725339137",
  "text" : "Tin Foil Hats or Baseball Caps? Why Your Face is  a Cookie and Your Data is midata: http:\/\/t.co\/fF0785ZGdx via @wordpressdotcom",
  "id" : 398486034725339137,
  "created_at" : "2013-11-07 16:24:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398352816843935745",
  "text" : "&lt;&lt;my english teacher is always saying that there's no stupid questions but if you ask a question, she acts like you're stupid&gt;&gt;",
  "id" : 398352816843935745,
  "created_at" : "2013-11-07 07:34:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/D0hmlkqqVr",
      "expanded_url" : "http:\/\/johnhilley.blogspot.co.uk\/2013\/11\/brand-saying-it-for-real.html",
      "display_url" : "johnhilley.blogspot.co.uk\/2013\/11\/brand-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "398184860600504321",
  "text" : "RT @johnwhilley: Russell Brand saying it for real http:\/\/t.co\/D0hmlkqqVr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 55 ],
        "url" : "http:\/\/t.co\/D0hmlkqqVr",
        "expanded_url" : "http:\/\/johnhilley.blogspot.co.uk\/2013\/11\/brand-saying-it-for-real.html",
        "display_url" : "johnhilley.blogspot.co.uk\/2013\/11\/brand-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "398135940859719681",
    "text" : "Russell Brand saying it for real http:\/\/t.co\/D0hmlkqqVr",
    "id" : 398135940859719681,
    "created_at" : "2013-11-06 17:12:59 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 398184860600504321,
  "created_at" : "2013-11-06 20:27:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alannah Fitzgerald",
      "screen_name" : "AlannahFitz",
      "indices" : [ 3, 15 ],
      "id_str" : "223613160",
      "id" : 223613160
    }, {
      "name" : "The-Round ELT",
      "screen_name" : "wetheround",
      "indices" : [ 108, 119 ],
      "id_str" : "281918842",
      "id" : 281918842
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 96, 100 ]
    }, {
      "text" : "tesol",
      "indices" : [ 101, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/R94UL8tqSx",
      "expanded_url" : "http:\/\/lnkd.in\/b5tWKv3",
      "display_url" : "lnkd.in\/b5tWKv3"
    } ]
  },
  "geo" : { },
  "id_str" : "397888530497941504",
  "text" : "RT @AlannahFitz: Gender imbalances in ELT - some thoughts from the Round http:\/\/t.co\/R94UL8tqSx #elt #tesol @wetheround",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.linkedin.com\/\" rel=\"nofollow\"\u003ELinkedIn\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The-Round ELT",
        "screen_name" : "wetheround",
        "indices" : [ 91, 102 ],
        "id_str" : "281918842",
        "id" : 281918842
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "elt",
        "indices" : [ 79, 83 ]
      }, {
        "text" : "tesol",
        "indices" : [ 84, 90 ]
      } ],
      "urls" : [ {
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/R94UL8tqSx",
        "expanded_url" : "http:\/\/lnkd.in\/b5tWKv3",
        "display_url" : "lnkd.in\/b5tWKv3"
      } ]
    },
    "geo" : { },
    "id_str" : "397884968489058304",
    "text" : "Gender imbalances in ELT - some thoughts from the Round http:\/\/t.co\/R94UL8tqSx #elt #tesol @wetheround",
    "id" : 397884968489058304,
    "created_at" : "2013-11-06 00:35:43 +0000",
    "user" : {
      "name" : "Alannah Fitzgerald",
      "screen_name" : "AlannahFitz",
      "protected" : false,
      "id_str" : "223613160",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2645381550\/e07d3b354efdac11bce2725cbc44e94e_normal.png",
      "id" : 223613160,
      "verified" : false
    }
  },
  "id" : 397888530497941504,
  "created_at" : "2013-11-06 00:49:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Sketch Engine",
      "screen_name" : "SketchEngine",
      "indices" : [ 3, 16 ],
      "id_str" : "841197134",
      "id" : 841197134
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/4fYa4igWCO",
      "expanded_url" : "https:\/\/plus.google.com\/104940199413423400545\/posts\/a9x5QABoios",
      "display_url" : "plus.google.com\/10494019941342\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "397864042515009536",
  "text" : "...@SketchEngine for ELT (beta) flying under the radar but picked up by G+ community https:\/\/t.co\/4fYa4igWCO \u2026",
  "id" : 397864042515009536,
  "created_at" : "2013-11-05 23:12:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "indices" : [ 3, 19 ],
      "id_str" : "1326508478",
      "id" : 1326508478
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/EMEZ5MddyO",
      "expanded_url" : "http:\/\/cass.lancs.ac.uk\/?p=919",
      "display_url" : "cass.lancs.ac.uk\/?p=919"
    } ]
  },
  "geo" : { },
  "id_str" : "397694563969953792",
  "text" : "RT @CorpusSocialSci: Read about 'A criminologist\u2019s introduction to AntConc and concordance analysis' in the latest blog post on our site: h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/EMEZ5MddyO",
        "expanded_url" : "http:\/\/cass.lancs.ac.uk\/?p=919",
        "display_url" : "cass.lancs.ac.uk\/?p=919"
      } ]
    },
    "geo" : { },
    "id_str" : "397661247576883200",
    "text" : "Read about 'A criminologist\u2019s introduction to AntConc and concordance analysis' in the latest blog post on our site: http:\/\/t.co\/EMEZ5MddyO",
    "id" : 397661247576883200,
    "created_at" : "2013-11-05 09:46:44 +0000",
    "user" : {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "protected" : false,
      "id_str" : "1326508478",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3493899777\/ced36fe15c32eb911cbe3d64377524dc_normal.jpeg",
      "id" : 1326508478,
      "verified" : false
    }
  },
  "id" : 397694563969953792,
  "created_at" : "2013-11-05 11:59:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jo Sayers",
      "screen_name" : "jo_sayers",
      "indices" : [ 0, 10 ],
      "id_str" : "87176766",
      "id" : 87176766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "397503769857912833",
  "geo" : { },
  "id_str" : "397504153561223168",
  "in_reply_to_user_id" : 87176766,
  "text" : "@jo_sayers for sure 10,000 sips a beer :)",
  "id" : 397504153561223168,
  "in_reply_to_status_id" : 397503769857912833,
  "created_at" : "2013-11-04 23:22:30 +0000",
  "in_reply_to_screen_name" : "jo_sayers",
  "in_reply_to_user_id_str" : "87176766",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Stults",
      "screen_name" : "JustinStults",
      "indices" : [ 0, 13 ],
      "id_str" : "294217312",
      "id" : 294217312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "397499490464059392",
  "geo" : { },
  "id_str" : "397500464519839744",
  "in_reply_to_user_id" : 294217312,
  "text" : "@JustinStults can you divulge story?",
  "id" : 397500464519839744,
  "in_reply_to_status_id" : 397499490464059392,
  "created_at" : "2013-11-04 23:07:50 +0000",
  "in_reply_to_screen_name" : "JustinStults",
  "in_reply_to_user_id_str" : "294217312",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jo Sayers",
      "screen_name" : "jo_sayers",
      "indices" : [ 0, 10 ],
      "id_str" : "87176766",
      "id" : 87176766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "397470833045549056",
  "geo" : { },
  "id_str" : "397499879292821505",
  "in_reply_to_user_id" : 87176766,
  "text" : "@jo_sayers wow that's a nice number! less, than a year old no?  congrats :)",
  "id" : 397499879292821505,
  "in_reply_to_status_id" : 397470833045549056,
  "created_at" : "2013-11-04 23:05:31 +0000",
  "in_reply_to_screen_name" : "jo_sayers",
  "in_reply_to_user_id_str" : "87176766",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darius Kazemi",
      "screen_name" : "tinysubversions",
      "indices" : [ 18, 34 ],
      "id_str" : "14475298",
      "id" : 14475298
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/397497777325764608\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/O4FPbIimXE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYQyH1kCcAAzXv6.png",
      "id_str" : "397497777334153216",
      "id" : 397497777334153216,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYQyH1kCcAAzXv6.png",
      "sizes" : [ {
        "h" : 569,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 333,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 189,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 795,
        "resize" : "fit",
        "w" : 1431
      } ],
      "display_url" : "pic.twitter.com\/O4FPbIimXE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "397469900782198784",
  "geo" : { },
  "id_str" : "397497777325764608",
  "in_reply_to_user_id" : 14475298,
  "text" : "amazing satire :) @tinysubversions  i wanna go to inlaw school; will u be posting best of gallery? http:\/\/t.co\/O4FPbIimXE",
  "id" : 397497777325764608,
  "in_reply_to_status_id" : 397469900782198784,
  "created_at" : "2013-11-04 22:57:10 +0000",
  "in_reply_to_screen_name" : "tinysubversions",
  "in_reply_to_user_id_str" : "14475298",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darius Kazemi",
      "screen_name" : "tinysubversions",
      "indices" : [ 3, 19 ],
      "id_str" : "14475298",
      "id" : 14475298
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/TwMgODQOBf",
      "expanded_url" : "http:\/\/bit.ly\/1aZ9PEi",
      "display_url" : "bit.ly\/1aZ9PEi"
    } ]
  },
  "geo" : { },
  "id_str" : "397493095228768256",
  "text" : "RT @tinysubversions: BlankSchool: because the only effective pedagogy is forming a startup &amp; launching a webapp:\n\nhttp:\/\/t.co\/TwMgODQOBf\n\nn\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/TwMgODQOBf",
        "expanded_url" : "http:\/\/bit.ly\/1aZ9PEi",
        "display_url" : "bit.ly\/1aZ9PEi"
      } ]
    },
    "geo" : { },
    "id_str" : "397469900782198784",
    "text" : "BlankSchool: because the only effective pedagogy is forming a startup &amp; launching a webapp:\n\nhttp:\/\/t.co\/TwMgODQOBf\n\nnew school every 5 mins",
    "id" : 397469900782198784,
    "created_at" : "2013-11-04 21:06:23 +0000",
    "user" : {
      "name" : "Darius Kazemi",
      "screen_name" : "tinysubversions",
      "protected" : false,
      "id_str" : "14475298",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723889712772059136\/4T8a46Sp_normal.jpg",
      "id" : 14475298,
      "verified" : false
    }
  },
  "id" : 397493095228768256,
  "created_at" : "2013-11-04 22:38:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt O'Brien",
      "screen_name" : "ObsoleteDogma",
      "indices" : [ 3, 17 ],
      "id_str" : "167518667",
      "id" : 167518667
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/DCBGLexrR2",
      "expanded_url" : "http:\/\/www.theatlantic.com\/business\/archive\/2013\/10\/how-to-cut-the-poverty-rate-in-half-its-easy\/280971\/",
      "display_url" : "theatlantic.com\/business\/archi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "397433402120740865",
  "text" : "RT @ObsoleteDogma: How to cut the poverty rate in half. Step 1: Give people money. Step 2: There is no Step 2 http:\/\/t.co\/DCBGLexrR2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/DCBGLexrR2",
        "expanded_url" : "http:\/\/www.theatlantic.com\/business\/archive\/2013\/10\/how-to-cut-the-poverty-rate-in-half-its-easy\/280971\/",
        "display_url" : "theatlantic.com\/business\/archi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "395284624722505729",
    "text" : "How to cut the poverty rate in half. Step 1: Give people money. Step 2: There is no Step 2 http:\/\/t.co\/DCBGLexrR2",
    "id" : 395284624722505729,
    "created_at" : "2013-10-29 20:22:53 +0000",
    "user" : {
      "name" : "Matt O'Brien",
      "screen_name" : "ObsoleteDogma",
      "protected" : false,
      "id_str" : "167518667",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/611957409100095488\/XxpexW62_normal.jpg",
      "id" : 167518667,
      "verified" : true
    }
  },
  "id" : 397433402120740865,
  "created_at" : "2013-11-04 18:41:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darius Kazemi",
      "screen_name" : "tinysubversions",
      "indices" : [ 3, 19 ],
      "id_str" : "14475298",
      "id" : 14475298
    }, {
      "name" : "AutoVids",
      "screen_name" : "AutoVids",
      "indices" : [ 32, 41 ],
      "id_str" : "2157584160",
      "id" : 2157584160
    }, {
      "name" : "AutoVids",
      "screen_name" : "AutoVids",
      "indices" : [ 116, 125 ],
      "id_str" : "2157584160",
      "id" : 2157584160
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cocaine",
      "indices" : [ 127, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/dFkJyHYORn",
      "expanded_url" : "http:\/\/bit.ly\/1gn0Q3F",
      "display_url" : "bit.ly\/1gn0Q3F"
    } ]
  },
  "geo" : { },
  "id_str" : "397391533571588097",
  "text" : "RT @tinysubversions: Aw, thanks @autovids, just what I always wanted: a montage of kids pretending to snort coke RT @AutoVids: #cocaine: ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "AutoVids",
        "screen_name" : "AutoVids",
        "indices" : [ 11, 20 ],
        "id_str" : "2157584160",
        "id" : 2157584160
      }, {
        "name" : "AutoVids",
        "screen_name" : "AutoVids",
        "indices" : [ 95, 104 ],
        "id_str" : "2157584160",
        "id" : 2157584160
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "cocaine",
        "indices" : [ 106, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/dFkJyHYORn",
        "expanded_url" : "http:\/\/bit.ly\/1gn0Q3F",
        "display_url" : "bit.ly\/1gn0Q3F"
      } ]
    },
    "geo" : { },
    "id_str" : "397385327620669440",
    "text" : "Aw, thanks @autovids, just what I always wanted: a montage of kids pretending to snort coke RT @AutoVids: #cocaine: http:\/\/t.co\/dFkJyHYORn",
    "id" : 397385327620669440,
    "created_at" : "2013-11-04 15:30:19 +0000",
    "user" : {
      "name" : "Darius Kazemi",
      "screen_name" : "tinysubversions",
      "protected" : false,
      "id_str" : "14475298",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723889712772059136\/4T8a46Sp_normal.jpg",
      "id" : 14475298,
      "verified" : false
    }
  },
  "id" : 397391533571588097,
  "created_at" : "2013-11-04 15:54:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil Longwell",
      "screen_name" : "teacherphili",
      "indices" : [ 3, 16 ],
      "id_str" : "67863264",
      "id" : 67863264
    }, {
      "name" : "Russell Stannard",
      "screen_name" : "russell1955",
      "indices" : [ 118, 130 ],
      "id_str" : "14796284",
      "id" : 14796284
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "COCA",
      "indices" : [ 51, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/YeJ4Dtnc5Y",
      "expanded_url" : "http:\/\/bit.ly\/1eb9Xnb",
      "display_url" : "bit.ly\/1eb9Xnb"
    } ]
  },
  "geo" : { },
  "id_str" : "397373762922106880",
  "text" : "RT @teacherphili: Step-by-step screencast to using #COCA corpus.  Previously unreleased. Now uploaded to TTV site c\/o @russell1955 - http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Russell Stannard",
        "screen_name" : "russell1955",
        "indices" : [ 100, 112 ],
        "id_str" : "14796284",
        "id" : 14796284
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "COCA",
        "indices" : [ 33, 38 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/YeJ4Dtnc5Y",
        "expanded_url" : "http:\/\/bit.ly\/1eb9Xnb",
        "display_url" : "bit.ly\/1eb9Xnb"
      } ]
    },
    "geo" : { },
    "id_str" : "397369899657342976",
    "text" : "Step-by-step screencast to using #COCA corpus.  Previously unreleased. Now uploaded to TTV site c\/o @russell1955 - http:\/\/t.co\/YeJ4Dtnc5Y",
    "id" : 397369899657342976,
    "created_at" : "2013-11-04 14:29:01 +0000",
    "user" : {
      "name" : "Phil Longwell",
      "screen_name" : "teacherphili",
      "protected" : false,
      "id_str" : "67863264",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637201716295933952\/4n4DCm-q_normal.jpg",
      "id" : 67863264,
      "verified" : false
    }
  },
  "id" : 397373762922106880,
  "created_at" : "2013-11-04 14:44:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 24, 34 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/nFSgo97gPZ",
      "expanded_url" : "http:\/\/tinyurl.com\/qj4sobk",
      "display_url" : "tinyurl.com\/qj4sobk"
    } ]
  },
  "geo" : { },
  "id_str" : "397325019069415424",
  "text" : "int ex of an educom? MT @medialens the Only Fools And Horses episode 'made by the Maureen Oilfield Consortium' http:\/\/t.co\/nFSgo97gPZ",
  "id" : 397325019069415424,
  "created_at" : "2013-11-04 11:30:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Blond",
      "screen_name" : "BillsEnglish",
      "indices" : [ 3, 16 ],
      "id_str" : "1225932950",
      "id" : 1225932950
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ESL",
      "indices" : [ 111, 115 ]
    }, {
      "text" : "ELT",
      "indices" : [ 116, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/hvMFS0Zk0x",
      "expanded_url" : "http:\/\/www.billsenglish.com\/",
      "display_url" : "billsenglish.com"
    } ]
  },
  "geo" : { },
  "id_str" : "397306098891653120",
  "text" : "RT @BillsEnglish: New blog post on pronunciation teaching: \"Billy Graham Goes to Mecca\" http:\/\/t.co\/hvMFS0Zk0x\n#ESL #ELT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ESL",
        "indices" : [ 93, 97 ]
      }, {
        "text" : "ELT",
        "indices" : [ 98, 102 ]
      } ],
      "urls" : [ {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/hvMFS0Zk0x",
        "expanded_url" : "http:\/\/www.billsenglish.com\/",
        "display_url" : "billsenglish.com"
      } ]
    },
    "geo" : { },
    "id_str" : "397159786262695937",
    "text" : "New blog post on pronunciation teaching: \"Billy Graham Goes to Mecca\" http:\/\/t.co\/hvMFS0Zk0x\n#ESL #ELT",
    "id" : 397159786262695937,
    "created_at" : "2013-11-04 00:34:06 +0000",
    "user" : {
      "name" : "Bill Blond",
      "screen_name" : "BillsEnglish",
      "protected" : false,
      "id_str" : "1225932950",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000178985604\/38c86f0ad86b16b49ddd21f7e3d0e4dd_normal.jpeg",
      "id" : 1225932950,
      "verified" : false
    }
  },
  "id" : 397306098891653120,
  "created_at" : "2013-11-04 10:15:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/QFPoQ4mIrD",
      "expanded_url" : "http:\/\/members5.boardhost.com\/medialens\/msg\/1383448221.html",
      "display_url" : "members5.boardhost.com\/medialens\/msg\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "397119869188976640",
  "text" : "Malala and Nabila: World's apart http:\/\/t.co\/QFPoQ4mIrD",
  "id" : 397119869188976640,
  "created_at" : "2013-11-03 21:55:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "evanfrendo",
      "screen_name" : "evanfrendo",
      "indices" : [ 0, 11 ],
      "id_str" : "17589664",
      "id" : 17589664
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "396231559629373441",
  "geo" : { },
  "id_str" : "397078203824496641",
  "in_reply_to_user_id" : 17589664,
  "text" : "@evanfrendo thanks",
  "id" : 397078203824496641,
  "in_reply_to_status_id" : 396231559629373441,
  "created_at" : "2013-11-03 19:09:55 +0000",
  "in_reply_to_screen_name" : "evanfrendo",
  "in_reply_to_user_id_str" : "17589664",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
} ]