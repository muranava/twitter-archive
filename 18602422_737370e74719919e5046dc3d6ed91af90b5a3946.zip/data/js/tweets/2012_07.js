Grailbird.data.tweets_2012_07 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Seymour",
      "screen_name" : "leninology",
      "indices" : [ 40, 51 ],
      "id_str" : "15557246",
      "id" : 15557246
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 35 ],
      "url" : "http:\/\/t.co\/HVzVc5KZ",
      "expanded_url" : "http:\/\/www.leninology.com\/2012\/07\/puke-britannia.html",
      "display_url" : "leninology.com\/2012\/07\/puke-b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "230270313018044418",
  "text" : "Puke Britannia http:\/\/t.co\/HVzVc5KZ via @leninology",
  "id" : 230270313018044418,
  "created_at" : "2012-07-31 11:54:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/K8TeZHzC",
      "expanded_url" : "http:\/\/bit.ly\/OEGeoj",
      "display_url" : "bit.ly\/OEGeoj"
    } ]
  },
  "geo" : { },
  "id_str" : "230076422075592705",
  "text" : "Blair, Olympic deals and why another world is possible by John Pilger: http:\/\/t.co\/K8TeZHzC",
  "id" : 230076422075592705,
  "created_at" : "2012-07-30 23:04:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "indices" : [ 70, 85 ],
      "id_str" : "27716419",
      "id" : 27716419
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Olympic_Inoculation",
      "indices" : [ 0, 20 ]
    } ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/4PtJCy8v",
      "expanded_url" : "http:\/\/www.craigmurray.org.uk\/archives\/2012\/07\/circuses-but-less-bread\/",
      "display_url" : "craigmurray.org.uk\/archives\/2012\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "228871028451995649",
  "text" : "#Olympic_Inoculation: Circuses but less bread http:\/\/t.co\/4PtJCy8v by @craigmurrayorg",
  "id" : 228871028451995649,
  "created_at" : "2012-07-27 15:14:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Olympic",
      "indices" : [ 0, 8 ]
    } ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/oOoZhsQ1",
      "expanded_url" : "http:\/\/counterolympicsnetwork.wordpress.com\/",
      "display_url" : "counterolympicsnetwork.wordpress.com"
    } ]
  },
  "geo" : { },
  "id_str" : "225658247149936640",
  "text" : "#Olympic Inoculation: Counter Olympics Network http:\/\/t.co\/oOoZhsQ1",
  "id" : 225658247149936640,
  "created_at" : "2012-07-18 18:28:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephanie McIntosh",
      "screen_name" : "purple_steph",
      "indices" : [ 0, 13 ],
      "id_str" : "18678010",
      "id" : 18678010
    }, {
      "name" : "Zoelee",
      "screen_name" : "Zoelee",
      "indices" : [ 14, 21 ],
      "id_str" : "19227656",
      "id" : 19227656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225512461967704064",
  "geo" : { },
  "id_str" : "225646283195555840",
  "in_reply_to_user_id" : 18678010,
  "text" : "@purple_steph @Zoelee that's a great pic!",
  "id" : 225646283195555840,
  "in_reply_to_status_id" : 225512461967704064,
  "created_at" : "2012-07-18 17:40:40 +0000",
  "in_reply_to_screen_name" : "purple_steph",
  "in_reply_to_user_id_str" : "18678010",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 93, 103 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/q9IEveQl",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?feature=player_embedded&v=6NMr2VrhmFI",
      "display_url" : "youtube.com\/watch?feature=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "225180981580148736",
  "text" : "Very interesting film on (Western) propaganda  by North Korea http:\/\/t.co\/q9IEveQl HT justin @medialens",
  "id" : 225180981580148736,
  "created_at" : "2012-07-17 10:51:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate Bowles",
      "screen_name" : "KateMfD",
      "indices" : [ 0, 8 ],
      "id_str" : "379065166",
      "id" : 379065166
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224474824037236738",
  "geo" : { },
  "id_str" : "224536801044471808",
  "in_reply_to_user_id" : 379065166,
  "text" : "@KateMfD you're welcome, am enjoying reading yr uni casualisation series",
  "id" : 224536801044471808,
  "in_reply_to_status_id" : 224474824037236738,
  "created_at" : "2012-07-15 16:11:59 +0000",
  "in_reply_to_screen_name" : "KateMfD",
  "in_reply_to_user_id_str" : "379065166",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224533361849405441",
  "geo" : { },
  "id_str" : "224535044407037952",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow no rush as i have loads to read anway!",
  "id" : 224535044407037952,
  "in_reply_to_status_id" : 224533361849405441,
  "created_at" : "2012-07-15 16:05:00 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224524777300303873",
  "geo" : { },
  "id_str" : "224532564835180545",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow grt read it, please do send over fuller paper :)",
  "id" : 224532564835180545,
  "in_reply_to_status_id" : 224524777300303873,
  "created_at" : "2012-07-15 15:55:09 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bethany Cagnol",
      "screen_name" : "bethcagnol",
      "indices" : [ 0, 11 ],
      "id_str" : "27641720",
      "id" : 27641720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224283667781005313",
  "geo" : { },
  "id_str" : "224286274926821376",
  "in_reply_to_user_id" : 27641720,
  "text" : "@bethcagnol with a Bastille night crowd is difficult to see Montmartre from Montmarte :)",
  "id" : 224286274926821376,
  "in_reply_to_status_id" : 224283667781005313,
  "created_at" : "2012-07-14 23:36:29 +0000",
  "in_reply_to_screen_name" : "bethcagnol",
  "in_reply_to_user_id_str" : "27641720",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate Bowles",
      "screen_name" : "KateMfD",
      "indices" : [ 100, 108 ],
      "id_str" : "379065166",
      "id" : 379065166
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 30 ],
      "url" : "http:\/\/t.co\/uDi4YvYk",
      "expanded_url" : "http:\/\/musicfordeckchairs.wordpress.com\/2012\/07\/11\/piecework\/",
      "display_url" : "musicfordeckchairs.wordpress.com\/2012\/07\/11\/pie\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "224274668046123009",
  "text" : "Piecework http:\/\/t.co\/uDi4YvYk&lt;--depressingly familiar issues written in a non-depressing way by @kateMfD",
  "id" : 224274668046123009,
  "created_at" : "2012-07-14 22:50:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anna Loseva",
      "screen_name" : "AnnLoseva",
      "indices" : [ 0, 10 ],
      "id_str" : "38822368",
      "id" : 38822368
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/BU3u1zLK",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-7a",
      "display_url" : "wp.me\/pgHyE-7a"
    } ]
  },
  "in_reply_to_status_id_str" : "223890214807027712",
  "geo" : { },
  "id_str" : "223893401060392960",
  "in_reply_to_user_id" : 38822368,
  "text" : "@AnnLoseva change yr password if you haven't already; some security tips here http:\/\/t.co\/BU3u1zLK",
  "id" : 223893401060392960,
  "in_reply_to_status_id" : 223890214807027712,
  "created_at" : "2012-07-13 21:35:21 +0000",
  "in_reply_to_screen_name" : "AnnLoseva",
  "in_reply_to_user_id_str" : "38822368",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boing Boing",
      "screen_name" : "BoingBoing",
      "indices" : [ 115, 126 ],
      "id_str" : "5971922",
      "id" : 5971922
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OlympicInoculation",
      "indices" : [ 0, 19 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/CipLd0kd",
      "expanded_url" : "http:\/\/boingboing.net\/2012\/07\/13\/london-olympic-committee-says.html",
      "display_url" : "boingboing.net\/2012\/07\/13\/lon\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "223890755456991233",
  "text" : "#OlympicInoculation:London Olympic only link to their site if you have nice things to say http:\/\/t.co\/CipLd0kd via @boingboing",
  "id" : 223890755456991233,
  "created_at" : "2012-07-13 21:24:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 78, 88 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/JBHtuSBl",
      "expanded_url" : "http:\/\/www.guardian.co.uk\/books\/audioslideshow\/2012\/jul\/12\/joe-sacco-chris-hedges-destruction",
      "display_url" : "guardian.co.uk\/books\/audiosli\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "223817308739616769",
  "text" : "Chris Hedges\/Joe Sacco team up see preview here http:\/\/t.co\/JBHtuSBl HT miked @medialens",
  "id" : 223817308739616769,
  "created_at" : "2012-07-13 16:32:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223421089471152129",
  "geo" : { },
  "id_str" : "223705910172848128",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow haha, i think all three of those are happening at the same time :)",
  "id" : 223705910172848128,
  "in_reply_to_status_id" : 223421089471152129,
  "created_at" : "2012-07-13 09:10:19 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "phrasalverbsrock",
      "indices" : [ 74, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223418538864553985",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow \"put up with\" seems to be figuring a lot in my life recently! #phrasalverbsrock",
  "id" : 223418538864553985,
  "created_at" : "2012-07-12 14:08:25 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223414352366153729",
  "text" : "it's great how babies make it okay for adults to indulge in funny voices, pull faces, and generally act like little uns themselves :)",
  "id" : 223414352366153729,
  "created_at" : "2012-07-12 13:51:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/iZMOoKnn",
      "expanded_url" : "http:\/\/www.craigmurray.org.uk\/archives\/2012\/07\/martial-law-britain\/",
      "display_url" : "craigmurray.org.uk\/archives\/2012\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "223408935418331136",
  "text" : "Olympic Inoculation: Marshal Law Britain http:\/\/t.co\/iZMOoKnn@CraigMurrayOrg",
  "id" : 223408935418331136,
  "created_at" : "2012-07-12 13:30:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223389805826945024",
  "text" : "sure all net dependent parents look forward to mainstream wearable computing! hurry up! its been slow catching up with some grt ELT posts!",
  "id" : 223389805826945024,
  "created_at" : "2012-07-12 12:14:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/223385972606369793\/photo\/1",
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/ADKUA6wV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AxmgW8lCAAMYBiM.jpg",
      "id_str" : "223385972610564099",
      "id" : 223385972610564099,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AxmgW8lCAAMYBiM.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 524
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 524
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 524
      }, {
        "h" : 415,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ADKUA6wV"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/2LEi5VKt",
      "expanded_url" : "http:\/\/www.eurotrib.com\/story\/2012\/7\/6\/123844\/1928",
      "display_url" : "eurotrib.com\/story\/2012\/7\/6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "223385972606369793",
  "text" : "Forgetfulness in Leveson inquiry http:\/\/t.co\/2LEi5VKt http:\/\/t.co\/ADKUA6wV",
  "id" : 223385972606369793,
  "created_at" : "2012-07-12 11:59:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 67, 77 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/cXFzyzJm",
      "expanded_url" : "http:\/\/wp.me\/p2tgg6-16",
      "display_url" : "wp.me\/p2tgg6-16"
    } ]
  },
  "geo" : { },
  "id_str" : "222900227252830208",
  "text" : "Olympic Inoculation: Good Evans? http:\/\/t.co\/cXFzyzJm HT Ephialtes @medialens",
  "id" : 222900227252830208,
  "created_at" : "2012-07-11 03:48:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 57, 67 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/OQgK71vS",
      "expanded_url" : "http:\/\/youtu.be\/b0NrS2L6KcE",
      "display_url" : "youtu.be\/b0NrS2L6KcE"
    } ]
  },
  "geo" : { },
  "id_str" : "222892055813308416",
  "text" : "http:\/\/t.co\/OQgK71vS Welcome to the rest of our lives HT @medialens",
  "id" : 222892055813308416,
  "created_at" : "2012-07-11 03:16:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/sVAahBTB",
      "expanded_url" : "http:\/\/www.bbc.co.uk\/news\/health-18708790",
      "display_url" : "bbc.co.uk\/news\/health-18\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "222466884719742979",
  "text" : "Olympic Inoculation:Viewpoint: Ban junk food sponsors from Olympic sports By Dr Aseem Malhotra Cardiologist, London http:\/\/t.co\/sVAahBTB",
  "id" : 222466884719742979,
  "created_at" : "2012-07-09 23:06:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrea Castro",
      "screen_name" : "andreacu19",
      "indices" : [ 14, 25 ],
      "id_str" : "630481197",
      "id" : 630481197
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222029358699786241",
  "geo" : { },
  "id_str" : "222034035336151042",
  "in_reply_to_user_id" : 305248493,
  "text" : "@Ben_Naismith @andreacu19 greetings :]",
  "id" : 222034035336151042,
  "in_reply_to_status_id" : 222029358699786241,
  "created_at" : "2012-07-08 18:26:53 +0000",
  "in_reply_to_screen_name" : "BenNaismithELT",
  "in_reply_to_user_id_str" : "305248493",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/2u0jxhtz",
      "expanded_url" : "http:\/\/johnhilley.blogspot.co.uk\/2012\/07\/significant-particle-discoveries-of.html",
      "display_url" : "johnhilley.blogspot.co.uk\/2012\/07\/signif\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "221722848409038848",
  "text" : "Significant particle discoveries of the week - Higgs and Arafat http:\/\/t.co\/2u0jxhtz",
  "id" : 221722848409038848,
  "created_at" : "2012-07-07 21:50:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 81, 91 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/ogtbjfq3",
      "expanded_url" : "http:\/\/www.ethicalconsumer.org\/commentanalysis\/corporatewatch\/thegreatolympictaxswindle.aspx",
      "display_url" : "ethicalconsumer.org\/commentanalysi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "220605265911885824",
  "text" : "Olympic Inoculation - The great olympic tax swindle http:\/\/t.co\/ogtbjfq3 HT rich @medialens",
  "id" : 220605265911885824,
  "created_at" : "2012-07-04 19:49:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Thornbury",
      "screen_name" : "thornburyscott",
      "indices" : [ 0, 15 ],
      "id_str" : "23090474",
      "id" : 23090474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "220518311815938048",
  "geo" : { },
  "id_str" : "220519983594225664",
  "in_reply_to_user_id" : 23090474,
  "text" : "@thornburyscott is it less lecture talk time more workshop action time?",
  "id" : 220519983594225664,
  "in_reply_to_status_id" : 220518311815938048,
  "created_at" : "2012-07-04 14:10:35 +0000",
  "in_reply_to_screen_name" : "thornburyscott",
  "in_reply_to_user_id_str" : "23090474",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/4ffFHsCT",
      "expanded_url" : "http:\/\/youtu.be\/onrZAYEHkXM",
      "display_url" : "youtu.be\/onrZAYEHkXM"
    } ]
  },
  "geo" : { },
  "id_str" : "220514484664532992",
  "text" : "find a musical use for those old credit\/store cards http:\/\/t.co\/4ffFHsCT, groovy.",
  "id" : 220514484664532992,
  "created_at" : "2012-07-04 13:48:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/9GyN9bJQ",
      "expanded_url" : "http:\/\/boingboing.net\/2012\/07\/03\/where-the-colors-of-fireworks.html",
      "display_url" : "boingboing.net\/2012\/07\/03\/whe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "220235922153807873",
  "text" : "http:\/\/t.co\/9GyN9bJQ&lt;--useful graphic for conversations come Bastille day :)",
  "id" : 220235922153807873,
  "created_at" : "2012-07-03 19:21:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 114, 124 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/jNYeCoeZ",
      "expanded_url" : "http:\/\/www.newsunspun.org\/blogpost\/the-editors\/olympic-protest-imagery-doesnt-last-long-on-bbc-news",
      "display_url" : "newsunspun.org\/blogpost\/the-e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "220231916190830592",
  "text" : "Olympic Inoculation no: lost count: Olympic Protest Imagery Doesn't Last Long on BBC News http:\/\/t.co\/jNYeCoeZ HT @medialens",
  "id" : 220231916190830592,
  "created_at" : "2012-07-03 19:05:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/N10mZzHF",
      "expanded_url" : "http:\/\/assange.fivefilters.org\/",
      "display_url" : "assange.fivefilters.org"
    } ]
  },
  "geo" : { },
  "id_str" : "219500648440397825",
  "text" : "http:\/\/t.co\/N10mZzHF - great collection of tweets showing real nature of our \"free\" press viz Assange",
  "id" : 219500648440397825,
  "created_at" : "2012-07-01 18:40:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
} ]