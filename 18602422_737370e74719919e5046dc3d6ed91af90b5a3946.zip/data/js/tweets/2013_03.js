Grailbird.data.tweets_2013_03 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 0, 11 ],
      "id_str" : "282659955",
      "id" : 282659955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/U8o1r3JFDn",
      "expanded_url" : "http:\/\/www.bbc.co.uk\/podcasts\/series\/bbclp",
      "display_url" : "bbc.co.uk\/podcasts\/serie\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "318282764933791744",
  "geo" : { },
  "id_str" : "318295217218392065",
  "in_reply_to_user_id" : 282659955,
  "text" : "@teflerinha some downloads here http:\/\/t.co\/U8o1r3JFDn",
  "id" : 318295217218392065,
  "in_reply_to_status_id" : 318282764933791744,
  "created_at" : "2013-03-31 09:34:28 +0000",
  "in_reply_to_screen_name" : "teflerinha",
  "in_reply_to_user_id_str" : "282659955",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemma Lunn",
      "screen_name" : "GemL1",
      "indices" : [ 86, 92 ],
      "id_str" : "486146568",
      "id" : 486146568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/KRyDb2w6N8",
      "expanded_url" : "http:\/\/wp.me\/p2NUdz-3Y",
      "display_url" : "wp.me\/p2NUdz-3Y"
    } ]
  },
  "geo" : { },
  "id_str" : "317527663063465985",
  "text" : "6 week challenge: Week 3 - it's oh so quiet and that's ok! http:\/\/t.co\/KRyDb2w6N8 via @GemL1",
  "id" : 317527663063465985,
  "created_at" : "2013-03-29 06:44:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "4TUNE Teller App",
      "screen_name" : "4tunetellernet",
      "indices" : [ 0, 15 ],
      "id_str" : "467634146",
      "id" : 467634146
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "badpunsrus",
      "indices" : [ 24, 35 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317438110482976769",
  "geo" : { },
  "id_str" : "317440494500200449",
  "in_reply_to_user_id" : 467634146,
  "text" : "@4tunetellernet groovy! #badpunsrus",
  "id" : 317440494500200449,
  "in_reply_to_status_id" : 317438110482976769,
  "created_at" : "2013-03-29 00:58:06 +0000",
  "in_reply_to_screen_name" : "4tunetellernet",
  "in_reply_to_user_id_str" : "467634146",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/YSbfgIyi0R",
      "expanded_url" : "http:\/\/www.nature.com\/news\/the-future-of-publishing-a-new-page-1.12665",
      "display_url" : "nature.com\/news\/the-futur\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317439648790097921",
  "text" : "The future of publishing: A new page http:\/\/t.co\/YSbfgIyi0R",
  "id" : 317439648790097921,
  "created_at" : "2013-03-29 00:54:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317423247186604032",
  "text" : "@EBEFL a pleasure",
  "id" : 317423247186604032,
  "created_at" : "2013-03-28 23:49:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 0, 11 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317254165581672449",
  "geo" : { },
  "id_str" : "317421678059741184",
  "in_reply_to_user_id" : 87902543,
  "text" : "@tornhalves feck!",
  "id" : 317421678059741184,
  "in_reply_to_status_id" : 317254165581672449,
  "created_at" : "2013-03-28 23:43:20 +0000",
  "in_reply_to_screen_name" : "tornhalves",
  "in_reply_to_user_id_str" : "87902543",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anna Loseva",
      "screen_name" : "AnnLoseva",
      "indices" : [ 0, 10 ],
      "id_str" : "38822368",
      "id" : 38822368
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 28, 36 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317324067688562688",
  "geo" : { },
  "id_str" : "317421576842776576",
  "in_reply_to_user_id" : 38822368,
  "text" : "@AnnLoseva yr welcome, that #eltchat was a bit of a ghosttown near end!",
  "id" : 317421576842776576,
  "in_reply_to_status_id" : 317324067688562688,
  "created_at" : "2013-03-28 23:42:55 +0000",
  "in_reply_to_screen_name" : "AnnLoseva",
  "in_reply_to_user_id_str" : "38822368",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C Rebuffet-Broadus",
      "screen_name" : "RebuffetBroadus",
      "indices" : [ 0, 16 ],
      "id_str" : "22635290",
      "id" : 22635290
    }, {
      "name" : "Sandy Millin",
      "screen_name" : "sandymillin",
      "indices" : [ 17, 29 ],
      "id_str" : "144236944",
      "id" : 144236944
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317372076812038144",
  "geo" : { },
  "id_str" : "317421373725233154",
  "in_reply_to_user_id" : 22635290,
  "text" : "@RebuffetBroadus @sandymillin glad to help a little",
  "id" : 317421373725233154,
  "in_reply_to_status_id" : 317372076812038144,
  "created_at" : "2013-03-28 23:42:07 +0000",
  "in_reply_to_screen_name" : "RebuffetBroadus",
  "in_reply_to_user_id_str" : "22635290",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Teju Cole",
      "screen_name" : "tejucole",
      "indices" : [ 3, 12 ],
      "id_str" : "83876527",
      "id" : 83876527
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/3WnfxXpIe7",
      "expanded_url" : "http:\/\/nyr.kr\/ZzCUj2",
      "display_url" : "nyr.kr\/ZzCUj2"
    } ]
  },
  "geo" : { },
  "id_str" : "317421226177994752",
  "text" : "RT @tejucole: \"Writing is a much better quality of agony than trying to forget.\" http:\/\/t.co\/3WnfxXpIe7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/3WnfxXpIe7",
        "expanded_url" : "http:\/\/nyr.kr\/ZzCUj2",
        "display_url" : "nyr.kr\/ZzCUj2"
      } ]
    },
    "geo" : { },
    "id_str" : "317280411732549632",
    "text" : "\"Writing is a much better quality of agony than trying to forget.\" http:\/\/t.co\/3WnfxXpIe7",
    "id" : 317280411732549632,
    "created_at" : "2013-03-28 14:21:59 +0000",
    "user" : {
      "name" : "Teju Cole",
      "screen_name" : "tejucole",
      "protected" : false,
      "id_str" : "83876527",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1731884703\/teju3_normal.jpg",
      "id" : 83876527,
      "verified" : true
    }
  },
  "id" : 317421226177994752,
  "created_at" : "2013-03-28 23:41:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 3, 14 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/VhrvnNs4sg",
      "expanded_url" : "http:\/\/bit.ly\/10bQ6Kg",
      "display_url" : "bit.ly\/10bQ6Kg"
    } ]
  },
  "geo" : { },
  "id_str" : "317226787480424448",
  "text" : "RT @tornhalves: One EFL writer's view of the nihilism of the education publishers http:\/\/t.co\/VhrvnNs4sg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 88 ],
        "url" : "http:\/\/t.co\/VhrvnNs4sg",
        "expanded_url" : "http:\/\/bit.ly\/10bQ6Kg",
        "display_url" : "bit.ly\/10bQ6Kg"
      } ]
    },
    "geo" : { },
    "id_str" : "317218798493118464",
    "text" : "One EFL writer's view of the nihilism of the education publishers http:\/\/t.co\/VhrvnNs4sg",
    "id" : 317218798493118464,
    "created_at" : "2013-03-28 10:17:09 +0000",
    "user" : {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "protected" : false,
      "id_str" : "87902543",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3059742703\/1d3c7a2052db17d29644fa0a49af6480_normal.jpeg",
      "id" : 87902543,
      "verified" : false
    }
  },
  "id" : 317226787480424448,
  "created_at" : "2013-03-28 10:48:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Patsko",
      "screen_name" : "lauraahaha",
      "indices" : [ 0, 11 ],
      "id_str" : "97957137",
      "id" : 97957137
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317216050238345216",
  "geo" : { },
  "id_str" : "317219030366842881",
  "in_reply_to_user_id" : 97957137,
  "text" : "@lauraahaha congrats have fun! :)",
  "id" : 317219030366842881,
  "in_reply_to_status_id" : 317216050238345216,
  "created_at" : "2013-03-28 10:18:05 +0000",
  "in_reply_to_screen_name" : "lauraahaha",
  "in_reply_to_user_id_str" : "97957137",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/lkOEU9pNcs",
      "expanded_url" : "http:\/\/www.guardian.co.uk\/politics\/2013\/mar\/27\/ian-duncan-smith-branded-ratbag",
      "display_url" : "guardian.co.uk\/politics\/2013\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317204380631838721",
  "text" : "&lt;&lt;We've more pandas than you&gt;&gt;http:\/\/t.co\/lkOEU9pNcs",
  "id" : 317204380631838721,
  "created_at" : "2013-03-28 09:19:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 0, 11 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/A4zcfhhXAd",
      "expanded_url" : "http:\/\/www.telegraph.co.uk\/news\/politics\/labour\/9957008\/David-Miliband-a-colossus-Hes-a-greedy-failure-in-a-cosmic-sulk.html",
      "display_url" : "telegraph.co.uk\/news\/politics\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "317199783439781889",
  "geo" : { },
  "id_str" : "317203273083936769",
  "in_reply_to_user_id" : 18602422,
  "text" : "@tornhalves this is quite a corker on Miliband http:\/\/t.co\/A4zcfhhXAd",
  "id" : 317203273083936769,
  "in_reply_to_status_id" : 317199783439781889,
  "created_at" : "2013-03-28 09:15:28 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 0, 11 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317195786305818625",
  "geo" : { },
  "id_str" : "317199783439781889",
  "in_reply_to_user_id" : 87902543,
  "text" : "@tornhalves i can distinctly remember the day when the milk stopped at primary school! :(",
  "id" : 317199783439781889,
  "in_reply_to_status_id" : 317195786305818625,
  "created_at" : "2013-03-28 09:01:36 +0000",
  "in_reply_to_screen_name" : "tornhalves",
  "in_reply_to_user_id_str" : "87902543",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 3, 14 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/91VwNFUnYj",
      "expanded_url" : "http:\/\/bit.ly\/11PAlNP",
      "display_url" : "bit.ly\/11PAlNP"
    } ]
  },
  "geo" : { },
  "id_str" : "317199450722418688",
  "text" : "RT @tornhalves: Personalisation of education in the UK - history and politics from Plowden to Thatcher to Miliband http:\/\/t.co\/91VwNFUnYj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/91VwNFUnYj",
        "expanded_url" : "http:\/\/bit.ly\/11PAlNP",
        "display_url" : "bit.ly\/11PAlNP"
      } ]
    },
    "geo" : { },
    "id_str" : "317195786305818625",
    "text" : "Personalisation of education in the UK - history and politics from Plowden to Thatcher to Miliband http:\/\/t.co\/91VwNFUnYj",
    "id" : 317195786305818625,
    "created_at" : "2013-03-28 08:45:43 +0000",
    "user" : {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "protected" : false,
      "id_str" : "87902543",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3059742703\/1d3c7a2052db17d29644fa0a49af6480_normal.jpeg",
      "id" : 87902543,
      "verified" : false
    }
  },
  "id" : 317199450722418688,
  "created_at" : "2013-03-28 09:00:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317193846368903169",
  "text" : "@leakygrammar there is some fascinating data on language classroom experience here",
  "id" : 317193846368903169,
  "created_at" : "2013-03-28 08:38:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TESOL France",
      "screen_name" : "TESOLFrance",
      "indices" : [ 3, 15 ],
      "id_str" : "70341872",
      "id" : 70341872
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TESOLFR",
      "indices" : [ 36, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/oBYieRta9E",
      "expanded_url" : "http:\/\/www.tesol-france.org\/pronunciation_young.php",
      "display_url" : "tesol-france.org\/pronunciation_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317182743702282240",
  "text" : "RT @TESOLFrance: Sunday, April 7th: #TESOLFR Pronunciation Workshop with Roselyn Young. Register today! http:\/\/t.co\/oBYieRta9E",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TESOLFR",
        "indices" : [ 19, 27 ]
      } ],
      "urls" : [ {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/oBYieRta9E",
        "expanded_url" : "http:\/\/www.tesol-france.org\/pronunciation_young.php",
        "display_url" : "tesol-france.org\/pronunciation_\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "317171159047229440",
    "text" : "Sunday, April 7th: #TESOLFR Pronunciation Workshop with Roselyn Young. Register today! http:\/\/t.co\/oBYieRta9E",
    "id" : 317171159047229440,
    "created_at" : "2013-03-28 07:07:51 +0000",
    "user" : {
      "name" : "TESOL France",
      "screen_name" : "TESOLFrance",
      "protected" : false,
      "id_str" : "70341872",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1789787647\/TESOL_France_logo_normal.jpg",
      "id" : 70341872,
      "verified" : false
    }
  },
  "id" : 317182743702282240,
  "created_at" : "2013-03-28 07:53:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TESOL France",
      "screen_name" : "TESOLFrance",
      "indices" : [ 3, 15 ],
      "id_str" : "70341872",
      "id" : 70341872
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TESOLFR",
      "indices" : [ 50, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/uBdfyeW7Jh",
      "expanded_url" : "http:\/\/www.tesol-france.org\/discipline.php",
      "display_url" : "tesol-france.org\/discipline.php"
    } ]
  },
  "geo" : { },
  "id_str" : "317182714627379200",
  "text" : "RT @TESOLFrance: March 30th! A highly interactive #TESOLFR workshop on Classroom Discipline in Higher &amp; Adult Education. http:\/\/t.co ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TESOLFR",
        "indices" : [ 33, 41 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/uBdfyeW7Jh",
        "expanded_url" : "http:\/\/www.tesol-france.org\/discipline.php",
        "display_url" : "tesol-france.org\/discipline.php"
      } ]
    },
    "geo" : { },
    "id_str" : "317170664412946432",
    "text" : "March 30th! A highly interactive #TESOLFR workshop on Classroom Discipline in Higher &amp; Adult Education. http:\/\/t.co\/uBdfyeW7Jh",
    "id" : 317170664412946432,
    "created_at" : "2013-03-28 07:05:53 +0000",
    "user" : {
      "name" : "TESOL France",
      "screen_name" : "TESOLFrance",
      "protected" : false,
      "id_str" : "70341872",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1789787647\/TESOL_France_logo_normal.jpg",
      "id" : 70341872,
      "verified" : false
    }
  },
  "id" : 317182714627379200,
  "created_at" : "2013-03-28 07:53:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "researched2013",
      "indices" : [ 3, 18 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/QEJ0Vyb6kF",
      "expanded_url" : "http:\/\/www.hackeducation.com\/2013\/03\/26\/ed-tech-solutionism-morozov\/",
      "display_url" : "hackeducation.com\/2013\/03\/26\/ed-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317059125286670340",
  "text" : "is #researched2013 a form of solutionism? http:\/\/t.co\/QEJ0Vyb6kF",
  "id" : 317059125286670340,
  "created_at" : "2013-03-27 23:42:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chadsansing",
      "screen_name" : "chadsansing",
      "indices" : [ 0, 12 ],
      "id_str" : "76810409",
      "id" : 76810409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317053708837990401",
  "geo" : { },
  "id_str" : "317058075813113856",
  "in_reply_to_user_id" : 76810409,
  "text" : "@chadsansing personal,collective,homegrown stories used for making sense of the world\/each other still &gt; topdown stories?",
  "id" : 317058075813113856,
  "in_reply_to_status_id" : 317053708837990401,
  "created_at" : "2013-03-27 23:38:30 +0000",
  "in_reply_to_screen_name" : "chadsansing",
  "in_reply_to_user_id_str" : "76810409",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chadsansing",
      "screen_name" : "chadsansing",
      "indices" : [ 0, 12 ],
      "id_str" : "76810409",
      "id" : 76810409
    }, {
      "name" : "douglas rushkoff",
      "screen_name" : "rushkoff",
      "indices" : [ 13, 22 ],
      "id_str" : "15085196",
      "id" : 15085196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317049509765083136",
  "geo" : { },
  "id_str" : "317051919610814464",
  "in_reply_to_user_id" : 76810409,
  "text" : "@chadsansing @rushkoff stories are constantly re-written, a collapse is a rewrite? great post :)",
  "id" : 317051919610814464,
  "in_reply_to_status_id" : 317049509765083136,
  "created_at" : "2013-03-27 23:14:02 +0000",
  "in_reply_to_screen_name" : "chadsansing",
  "in_reply_to_user_id_str" : "76810409",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chadsansing",
      "screen_name" : "chadsansing",
      "indices" : [ 3, 15 ],
      "id_str" : "76810409",
      "id" : 76810409
    }, {
      "name" : "douglas rushkoff",
      "screen_name" : "rushkoff",
      "indices" : [ 68, 77 ],
      "id_str" : "15085196",
      "id" : 15085196
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edchat",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/pPCiKr30EV",
      "expanded_url" : "http:\/\/bit.ly\/10REMVP",
      "display_url" : "bit.ly\/10REMVP"
    } ]
  },
  "geo" : { },
  "id_str" : "317051266033397760",
  "text" : "RT @chadsansing: \"Nothing but this,\" some of my initial thoughts on @Rushkoff's new book, Present Shock, + narrative in schls http:\/\/t.c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "douglas rushkoff",
        "screen_name" : "rushkoff",
        "indices" : [ 51, 60 ],
        "id_str" : "15085196",
        "id" : 15085196
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "edchat",
        "indices" : [ 132, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/pPCiKr30EV",
        "expanded_url" : "http:\/\/bit.ly\/10REMVP",
        "display_url" : "bit.ly\/10REMVP"
      } ]
    },
    "geo" : { },
    "id_str" : "317049509765083136",
    "text" : "\"Nothing but this,\" some of my initial thoughts on @Rushkoff's new book, Present Shock, + narrative in schls http:\/\/t.co\/pPCiKr30EV #edchat",
    "id" : 317049509765083136,
    "created_at" : "2013-03-27 23:04:28 +0000",
    "user" : {
      "name" : "chadsansing",
      "screen_name" : "chadsansing",
      "protected" : false,
      "id_str" : "76810409",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712740640111652869\/NvEwLRy__normal.jpg",
      "id" : 76810409,
      "verified" : false
    }
  },
  "id" : 317051266033397760,
  "created_at" : "2013-03-27 23:11:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AKIRA THE DON",
      "screen_name" : "akirathedon",
      "indices" : [ 107, 119 ],
      "id_str" : "18225967",
      "id" : 18225967
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/zqaciUdeuX",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=TVSJQwjbjgc&feature=youtu.be",
      "display_url" : "youtube.com\/watch?v=TVSJQw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317048409276174336",
  "text" : "&lt;&lt;if good people don't make more good people then we're really fkd&gt;&gt; http:\/\/t.co\/zqaciUdeuX by @akirathedon",
  "id" : 317048409276174336,
  "created_at" : "2013-03-27 23:00:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 32, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317033650669645824",
  "text" : "\/tumbleweed\/........ thx all :) #eltchat",
  "id" : 317033650669645824,
  "created_at" : "2013-03-27 22:01:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 96, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/63c0MEbGjt",
      "expanded_url" : "http:\/\/en.wiktionary.org\/wiki\/Appendix:Glossary_of_false_friends",
      "display_url" : "en.wiktionary.org\/wiki\/Appendix:\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317032391707328514",
  "text" : "a Fr fof once as a kid shkd seeing SALE on shops, exploit false friends? http:\/\/t.co\/63c0MEbGjt #eltchat",
  "id" : 317032391707328514,
  "created_at" : "2013-03-27 21:56:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaunwilden",
      "screen_name" : "Shaunwilden",
      "indices" : [ 0, 12 ],
      "id_str" : "15350512",
      "id" : 15350512
    }, {
      "name" : "Wiktorkompe",
      "screen_name" : "wiktor_k",
      "indices" : [ 40, 49 ],
      "id_str" : "733704413383168000",
      "id" : 733704413383168000
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 108, 116 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317029367719006209",
  "geo" : { },
  "id_str" : "317029827855130624",
  "in_reply_to_user_id" : 15350512,
  "text" : "@Shaunwilden no idea! just bouncing off @Wiktor_K last link :) maybe labelling\/titling a piece of graffiti? #eltchat",
  "id" : 317029827855130624,
  "in_reply_to_status_id" : 317029367719006209,
  "created_at" : "2013-03-27 21:46:15 +0000",
  "in_reply_to_screen_name" : "Shaunwilden",
  "in_reply_to_user_id_str" : "15350512",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 44, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317029311955738624",
  "text" : "street graffiti could be a potential source #eltchat",
  "id" : 317029311955738624,
  "created_at" : "2013-03-27 21:44:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wiktorkompe",
      "screen_name" : "wiktor_k",
      "indices" : [ 0, 9 ],
      "id_str" : "733704413383168000",
      "id" : 733704413383168000
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 28, 36 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317028258879262720",
  "geo" : { },
  "id_str" : "317028725923393537",
  "in_reply_to_user_id" : 222498082,
  "text" : "@Wiktor_K haha nice idea :) #eltchat",
  "id" : 317028725923393537,
  "in_reply_to_status_id" : 317028258879262720,
  "created_at" : "2013-03-27 21:41:53 +0000",
  "in_reply_to_screen_name" : "BRAVE_Learning",
  "in_reply_to_user_id_str" : "222498082",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 113, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317027728329154560",
  "text" : "in major cities multi-lingual public announcements common ask sts to invent their own informative announcements? #eltchat",
  "id" : 317027728329154560,
  "created_at" : "2013-03-27 21:37:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anna Loseva",
      "screen_name" : "AnnLoseva",
      "indices" : [ 24, 34 ],
      "id_str" : "38822368",
      "id" : 38822368
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 103, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317023602014838784",
  "text" : "re e-device landscape - @annloseva once shared grt tip about sts chnging lang of their e-device to Eng #eltchat",
  "id" : 317023602014838784,
  "created_at" : "2013-03-27 21:21:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenn Greenwald",
      "screen_name" : "ggreenwald",
      "indices" : [ 3, 14 ],
      "id_str" : "16076032",
      "id" : 16076032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/4G5adx3w4C",
      "expanded_url" : "http:\/\/www.newstatesman.com\/politics\/politics\/2013\/03\/new-propaganda-liberal-new-slavery-digital",
      "display_url" : "newstatesman.com\/politics\/polit\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317007337208557568",
  "text" : "RT @ggreenwald: John Pilger column on how Liberal Hollywood is returning to its roots of producing US Government propaganda  http:\/\/t.co ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/4G5adx3w4C",
        "expanded_url" : "http:\/\/www.newstatesman.com\/politics\/politics\/2013\/03\/new-propaganda-liberal-new-slavery-digital",
        "display_url" : "newstatesman.com\/politics\/polit\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "316903061253652480",
    "text" : "John Pilger column on how Liberal Hollywood is returning to its roots of producing US Government propaganda  http:\/\/t.co\/4G5adx3w4C",
    "id" : 316903061253652480,
    "created_at" : "2013-03-27 13:22:32 +0000",
    "user" : {
      "name" : "Glenn Greenwald",
      "screen_name" : "ggreenwald",
      "protected" : false,
      "id_str" : "16076032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/659383028771364869\/G9HHnjiI_normal.jpg",
      "id" : 16076032,
      "verified" : true
    }
  },
  "id" : 317007337208557568,
  "created_at" : "2013-03-27 20:16:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George Siemens",
      "screen_name" : "gsiemens",
      "indices" : [ 3, 12 ],
      "id_str" : "18613",
      "id" : 18613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/iKqUtPovh5",
      "expanded_url" : "http:\/\/www.hackeducation.com\/2013\/03\/26\/ed-tech-solutionism-morozov\/",
      "display_url" : "hackeducation.com\/2013\/03\/26\/ed-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "316998672732782593",
  "text" : "RT @gsiemens: \"But it's broken, Silicon Valley repeatedly tells us. It's broken. So click here. Save it.\" http:\/\/t.co\/iKqUtPovh5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/iKqUtPovh5",
        "expanded_url" : "http:\/\/www.hackeducation.com\/2013\/03\/26\/ed-tech-solutionism-morozov\/",
        "display_url" : "hackeducation.com\/2013\/03\/26\/ed-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "316965149917458432",
    "text" : "\"But it's broken, Silicon Valley repeatedly tells us. It's broken. So click here. Save it.\" http:\/\/t.co\/iKqUtPovh5",
    "id" : 316965149917458432,
    "created_at" : "2013-03-27 17:29:15 +0000",
    "user" : {
      "name" : "George Siemens",
      "screen_name" : "gsiemens",
      "protected" : false,
      "id_str" : "18613",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451036825637761025\/7_0RawE8_normal.jpeg",
      "id" : 18613,
      "verified" : false
    }
  },
  "id" : 316998672732782593,
  "created_at" : "2013-03-27 19:42:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liliputing",
      "screen_name" : "liliputingnews",
      "indices" : [ 3, 18 ],
      "id_str" : "268929729",
      "id" : 268929729
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/6Fh2ZUC57Z",
      "expanded_url" : "http:\/\/dlvr.it\/3870LP",
      "display_url" : "dlvr.it\/3870LP"
    } ]
  },
  "geo" : { },
  "id_str" : "316993854790311936",
  "text" : "RT @liliputingnews: Google Translate for Android now works without an internet connection http:\/\/t.co\/6Fh2ZUC57Z",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/dlvr.it\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/6Fh2ZUC57Z",
        "expanded_url" : "http:\/\/dlvr.it\/3870LP",
        "display_url" : "dlvr.it\/3870LP"
      } ]
    },
    "geo" : { },
    "id_str" : "316982346723241985",
    "text" : "Google Translate for Android now works without an internet connection http:\/\/t.co\/6Fh2ZUC57Z",
    "id" : 316982346723241985,
    "created_at" : "2013-03-27 18:37:35 +0000",
    "user" : {
      "name" : "Liliputing",
      "screen_name" : "liliputingnews",
      "protected" : false,
      "id_str" : "268929729",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/694255746297565184\/8rpgQMDB_normal.png",
      "id" : 268929729,
      "verified" : false
    }
  },
  "id" : 316993854790311936,
  "created_at" : "2013-03-27 19:23:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316992808512811008",
  "text" : "@leakygrammar v interesting approach to understand a text",
  "id" : 316992808512811008,
  "created_at" : "2013-03-27 19:19:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 0, 13 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316978198611124224",
  "geo" : { },
  "id_str" : "316989474015936515",
  "in_reply_to_user_id" : 88655243,
  "text" : "@rosemerebard thx for share Rose ;)",
  "id" : 316989474015936515,
  "in_reply_to_status_id" : 316978198611124224,
  "created_at" : "2013-03-27 19:05:54 +0000",
  "in_reply_to_screen_name" : "rosemerebard",
  "in_reply_to_user_id_str" : "88655243",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Willingham",
      "screen_name" : "DTWillingham",
      "indices" : [ 3, 16 ],
      "id_str" : "84619537",
      "id" : 84619537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/hbjCjzFjjE",
      "expanded_url" : "http:\/\/www.sciencedirect.com\/science\/article\/pii\/S0193397313000026",
      "display_url" : "sciencedirect.com\/science\/articl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "316989304326979584",
  "text" : "RT @DTWillingham: meta-analysis: sesame street = good http:\/\/t.co\/hbjCjzFjjE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 36, 58 ],
        "url" : "http:\/\/t.co\/hbjCjzFjjE",
        "expanded_url" : "http:\/\/www.sciencedirect.com\/science\/article\/pii\/S0193397313000026",
        "display_url" : "sciencedirect.com\/science\/articl\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "316839921010753536",
    "text" : "meta-analysis: sesame street = good http:\/\/t.co\/hbjCjzFjjE",
    "id" : 316839921010753536,
    "created_at" : "2013-03-27 09:11:38 +0000",
    "user" : {
      "name" : "Daniel Willingham",
      "screen_name" : "DTWillingham",
      "protected" : false,
      "id_str" : "84619537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1815678310\/Daniel_Willingham_Color_lowres_normal.JPG",
      "id" : 84619537,
      "verified" : false
    }
  },
  "id" : 316989304326979584,
  "created_at" : "2013-03-27 19:05:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 95, 99 ]
    }, {
      "text" : "efl",
      "indices" : [ 100, 104 ]
    }, {
      "text" : "vocab",
      "indices" : [ 105, 111 ]
    }, {
      "text" : "corpora",
      "indices" : [ 112, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/5KkTmCy0uQ",
      "expanded_url" : "http:\/\/bit.ly\/11LEuT0",
      "display_url" : "bit.ly\/11LEuT0"
    } ]
  },
  "geo" : { },
  "id_str" : "316910448886812672",
  "text" : "RT @CELTtraining: Is frequency of words the most important thing when choosing words to teach? #elt #efl #vocab #corpora http:\/\/t.co\/5Kk ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "elt",
        "indices" : [ 77, 81 ]
      }, {
        "text" : "efl",
        "indices" : [ 82, 86 ]
      }, {
        "text" : "vocab",
        "indices" : [ 87, 93 ]
      }, {
        "text" : "corpora",
        "indices" : [ 94, 102 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/5KkTmCy0uQ",
        "expanded_url" : "http:\/\/bit.ly\/11LEuT0",
        "display_url" : "bit.ly\/11LEuT0"
      } ]
    },
    "geo" : { },
    "id_str" : "316903667359940609",
    "text" : "Is frequency of words the most important thing when choosing words to teach? #elt #efl #vocab #corpora http:\/\/t.co\/5KkTmCy0uQ",
    "id" : 316903667359940609,
    "created_at" : "2013-03-27 13:24:56 +0000",
    "user" : {
      "name" : "Lexical Lab",
      "screen_name" : "LexicalLab",
      "protected" : false,
      "id_str" : "857732892",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/559654844831506432\/F4HWliCf_normal.jpeg",
      "id" : 857732892,
      "verified" : false
    }
  },
  "id" : 316910448886812672,
  "created_at" : "2013-03-27 13:51:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 14, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316898698976186369",
  "text" : "thanks all :) #eltchat",
  "id" : 316898698976186369,
  "created_at" : "2013-03-27 13:05:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Pickles",
      "screen_name" : "efl101",
      "indices" : [ 10, 17 ],
      "id_str" : "122995652",
      "id" : 122995652
    }, {
      "name" : "MarisaConstantinides",
      "screen_name" : "Marisa_C",
      "indices" : [ 19, 28 ],
      "id_str" : "18272500",
      "id" : 18272500
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 29, 38 ],
      "id_str" : "18602422",
      "id" : 18602422
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 129, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316891419598012416",
  "text" : "BobK99 RT @efl101: @Marisa_C @muranava do we spend too much time on writing full stop?&gt;many probs in L1 writing so maybe not? #eltchat",
  "id" : 316891419598012416,
  "created_at" : "2013-03-27 12:36:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 87, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316888854936297472",
  "text" : "product\/process\/genre are complimentary&gt; http:\/\/203.72.145.166\/ELT\/files\/54-2-6.pdf #eltchat",
  "id" : 316888854936297472,
  "created_at" : "2013-03-27 12:26:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 54, 70 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/M3O1XFUy9B",
      "expanded_url" : "http:\/\/wp.me\/p2KE8s-341",
      "display_url" : "wp.me\/p2KE8s-341"
    } ]
  },
  "geo" : { },
  "id_str" : "316856626193764352",
  "text" : "My lesson planning process http:\/\/t.co\/M3O1XFUy9B via @wordpressdotcom&gt;&gt;hehe :)",
  "id" : 316856626193764352,
  "created_at" : "2013-03-27 10:18:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Willingham",
      "screen_name" : "DTWillingham",
      "indices" : [ 3, 16 ],
      "id_str" : "84619537",
      "id" : 84619537
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edchat",
      "indices" : [ 104, 111 ]
    }, {
      "text" : "ukedchat",
      "indices" : [ 112, 121 ]
    }, {
      "text" : "researched2013",
      "indices" : [ 122, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/KFXyFO8GIO",
      "expanded_url" : "http:\/\/bit.ly\/X9GuCR",
      "display_url" : "bit.ly\/X9GuCR"
    } ]
  },
  "geo" : { },
  "id_str" : "316688113403572224",
  "text" : "MT @DTWillingham Willingham blog: A new push for science in education in Britain http:\/\/t.co\/KFXyFO8GIO #edchat #ukedchat #researched2013",
  "id" : 316688113403572224,
  "created_at" : "2013-03-26 23:08:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate Bowles",
      "screen_name" : "KateMfD",
      "indices" : [ 3, 11 ],
      "id_str" : "379065166",
      "id" : 379065166
    }, {
      "name" : "Public Intellectuals",
      "screen_name" : "PublicIntellec",
      "indices" : [ 16, 31 ],
      "id_str" : "479173516",
      "id" : 479173516
    }, {
      "name" : "Henry A. Giroux",
      "screen_name" : "HenryGiroux",
      "indices" : [ 103, 115 ],
      "id_str" : "571102278",
      "id" : 571102278
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/FX975bkjYG",
      "expanded_url" : "http:\/\/bit.ly\/YS1NDl",
      "display_url" : "bit.ly\/YS1NDl"
    } ]
  },
  "geo" : { },
  "id_str" : "316685766384308225",
  "text" : "RT @KateMfD: RT @PublicIntellec: Neoliberalism and the Politics of Higher Education: An Interview With @HenryGiroux http:\/\/t.co\/FX975bkjYG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Public Intellectuals",
        "screen_name" : "PublicIntellec",
        "indices" : [ 3, 18 ],
        "id_str" : "479173516",
        "id" : 479173516
      }, {
        "name" : "Henry A. Giroux",
        "screen_name" : "HenryGiroux",
        "indices" : [ 90, 102 ],
        "id_str" : "571102278",
        "id" : 571102278
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/FX975bkjYG",
        "expanded_url" : "http:\/\/bit.ly\/YS1NDl",
        "display_url" : "bit.ly\/YS1NDl"
      } ]
    },
    "geo" : { },
    "id_str" : "316640176648638465",
    "text" : "RT @PublicIntellec: Neoliberalism and the Politics of Higher Education: An Interview With @HenryGiroux http:\/\/t.co\/FX975bkjYG",
    "id" : 316640176648638465,
    "created_at" : "2013-03-26 19:57:55 +0000",
    "user" : {
      "name" : "Kate Bowles",
      "screen_name" : "KateMfD",
      "protected" : false,
      "id_str" : "379065166",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1557363696\/Screen_shot_2011-09-24_at_7.36.20_PM_normal.png",
      "id" : 379065166,
      "verified" : false
    }
  },
  "id" : 316685766384308225,
  "created_at" : "2013-03-26 22:59:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 3, 18 ],
      "id_str" : "20760283",
      "id" : 20760283
    }, {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 116, 127 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 128, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/kWmavRGkGT",
      "expanded_url" : "http:\/\/elt2.co.uk\/16VWc6u",
      "display_url" : "elt2.co.uk\/16VWc6u"
    } ]
  },
  "geo" : { },
  "id_str" : "316645167555821568",
  "text" : "RT @MrChrisJWilson: Why has the lexical approach been so long in coming?  http:\/\/t.co\/kWmavRGkGT &lt;great piece by @leoselivan #eltchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lexical Leo",
        "screen_name" : "leoselivan",
        "indices" : [ 96, 107 ],
        "id_str" : "408365496",
        "id" : 408365496
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "eltchat",
        "indices" : [ 108, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 54, 76 ],
        "url" : "http:\/\/t.co\/kWmavRGkGT",
        "expanded_url" : "http:\/\/elt2.co.uk\/16VWc6u",
        "display_url" : "elt2.co.uk\/16VWc6u"
      } ]
    },
    "geo" : { },
    "id_str" : "316613124776153088",
    "text" : "Why has the lexical approach been so long in coming?  http:\/\/t.co\/kWmavRGkGT &lt;great piece by @leoselivan #eltchat",
    "id" : 316613124776153088,
    "created_at" : "2013-03-26 18:10:25 +0000",
    "user" : {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "protected" : false,
      "id_str" : "20760283",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744952885595758592\/H4bmsUn3_normal.jpg",
      "id" : 20760283,
      "verified" : false
    }
  },
  "id" : 316645167555821568,
  "created_at" : "2013-03-26 20:17:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/EAD19pfBmy",
      "expanded_url" : "http:\/\/www.guardian.co.uk\/commentisfree\/2013\/mar\/22\/below-the-line-cif-contributors",
      "display_url" : "guardian.co.uk\/commentisfree\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "316530694283198464",
  "text" : "nice exploitable text guardian cif commentators profile http:\/\/t.co\/EAD19pfBmy, &amp; recently read sex industry abbrv for cif, makes me chuckle",
  "id" : 316530694283198464,
  "created_at" : "2013-03-26 12:42:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emma Herrod",
      "screen_name" : "EHerrod",
      "indices" : [ 0, 8 ],
      "id_str" : "20005930",
      "id" : 20005930
    }, {
      "name" : "John Spencer",
      "screen_name" : "edrethink",
      "indices" : [ 66, 76 ],
      "id_str" : "3057524486",
      "id" : 3057524486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/PiJTESKqDC",
      "expanded_url" : "http:\/\/www.educationrethink.com\/2013\/03\/my-take-on-what-most-schools-dont-teach.html",
      "display_url" : "educationrethink.com\/2013\/03\/my-tak\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "316135523490091008",
  "geo" : { },
  "id_str" : "316527495686004738",
  "in_reply_to_user_id" : 20005930,
  "text" : "@EHerrod nice critique of that vid here http:\/\/t.co\/PiJTESKqDC by @edrethink",
  "id" : 316527495686004738,
  "in_reply_to_status_id" : 316135523490091008,
  "created_at" : "2013-03-26 12:30:10 +0000",
  "in_reply_to_screen_name" : "EHerrod",
  "in_reply_to_user_id_str" : "20005930",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donald Clark",
      "screen_name" : "DonaldClark",
      "indices" : [ 3, 15 ],
      "id_str" : "1632891",
      "id" : 1632891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/ZVYFEm5ilx",
      "expanded_url" : "http:\/\/bit.ly\/Y8g1UI",
      "display_url" : "bit.ly\/Y8g1UI"
    } ]
  },
  "geo" : { },
  "id_str" : "316525725253517312",
  "text" : "RT @DonaldClark: Tablets in schools may damage literacy and other skills http:\/\/t.co\/ZVYFEm5ilx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/ZVYFEm5ilx",
        "expanded_url" : "http:\/\/bit.ly\/Y8g1UI",
        "display_url" : "bit.ly\/Y8g1UI"
      } ]
    },
    "geo" : { },
    "id_str" : "315865282637877248",
    "text" : "Tablets in schools may damage literacy and other skills http:\/\/t.co\/ZVYFEm5ilx",
    "id" : 315865282637877248,
    "created_at" : "2013-03-24 16:38:46 +0000",
    "user" : {
      "name" : "Donald Clark",
      "screen_name" : "DonaldClark",
      "protected" : false,
      "id_str" : "1632891",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/513085530695663616\/BfWK4n6u_normal.jpeg",
      "id" : 1632891,
      "verified" : false
    }
  },
  "id" : 316525725253517312,
  "created_at" : "2013-03-26 12:23:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ResearchED2013",
      "indices" : [ 70, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/zWYrZRpgcx",
      "expanded_url" : "http:\/\/johnbald.typepad.com\/language\/2010\/08\/randomised-controlled-trials-technical-paper.html",
      "display_url" : "johnbald.typepad.com\/language\/2010\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "316498506762297344",
  "text" : "Randomised Controlled Trials - Technical Paper\nhttp:\/\/t.co\/zWYrZRpgcx #ResearchED2013",
  "id" : 316498506762297344,
  "created_at" : "2013-03-26 10:34:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alannah Fitzgerald",
      "screen_name" : "AlannahFitz",
      "indices" : [ 3, 15 ],
      "id_str" : "223613160",
      "id" : 223613160
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oer13",
      "indices" : [ 94, 100 ]
    }, {
      "text" : "iatefl",
      "indices" : [ 101, 108 ]
    }, {
      "text" : "eapchat",
      "indices" : [ 109, 117 ]
    }, {
      "text" : "tesol",
      "indices" : [ 118, 124 ]
    }, {
      "text" : "edtech",
      "indices" : [ 125, 132 ]
    }, {
      "text" : "creativecommons",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "elt",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/qJ6ogHfqGb",
      "expanded_url" : "http:\/\/bit.ly\/14kZel0",
      "display_url" : "bit.ly\/14kZel0"
    } ]
  },
  "geo" : { },
  "id_str" : "316477162653880321",
  "text" : "RT @AlannahFitz: Re-using Oxford OpenSpires content in podcast corpora http:\/\/t.co\/qJ6ogHfqGb #oer13 #iatefl #eapchat #tesol #edtech #cr ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "oer13",
        "indices" : [ 77, 83 ]
      }, {
        "text" : "iatefl",
        "indices" : [ 84, 91 ]
      }, {
        "text" : "eapchat",
        "indices" : [ 92, 100 ]
      }, {
        "text" : "tesol",
        "indices" : [ 101, 107 ]
      }, {
        "text" : "edtech",
        "indices" : [ 108, 115 ]
      }, {
        "text" : "creativecommons",
        "indices" : [ 116, 132 ]
      }, {
        "text" : "elt",
        "indices" : [ 134, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 54, 76 ],
        "url" : "http:\/\/t.co\/qJ6ogHfqGb",
        "expanded_url" : "http:\/\/bit.ly\/14kZel0",
        "display_url" : "bit.ly\/14kZel0"
      } ]
    },
    "geo" : { },
    "id_str" : "316474901567524864",
    "text" : "Re-using Oxford OpenSpires content in podcast corpora http:\/\/t.co\/qJ6ogHfqGb #oer13 #iatefl #eapchat #tesol #edtech #creativecommons  #elt",
    "id" : 316474901567524864,
    "created_at" : "2013-03-26 09:01:11 +0000",
    "user" : {
      "name" : "Alannah Fitzgerald",
      "screen_name" : "AlannahFitz",
      "protected" : false,
      "id_str" : "223613160",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2645381550\/e07d3b354efdac11bce2725cbc44e94e_normal.png",
      "id" : 223613160,
      "verified" : false
    }
  },
  "id" : 316477162653880321,
  "created_at" : "2013-03-26 09:10:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 3, 14 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 79, 83 ]
    }, {
      "text" : "efl",
      "indices" : [ 84, 88 ]
    }, {
      "text" : "corpus",
      "indices" : [ 89, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/gJKDiBeJly",
      "expanded_url" : "http:\/\/bit.ly\/16UahRK",
      "display_url" : "bit.ly\/16UahRK"
    } ]
  },
  "geo" : { },
  "id_str" : "316309186071887872",
  "text" : "RT @leoselivan: New post: What corpora HAVE done for us http:\/\/t.co\/gJKDiBeJly #elt #efl #corpus",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "elt",
        "indices" : [ 63, 67 ]
      }, {
        "text" : "efl",
        "indices" : [ 68, 72 ]
      }, {
        "text" : "corpus",
        "indices" : [ 73, 80 ]
      } ],
      "urls" : [ {
        "indices" : [ 40, 62 ],
        "url" : "http:\/\/t.co\/gJKDiBeJly",
        "expanded_url" : "http:\/\/bit.ly\/16UahRK",
        "display_url" : "bit.ly\/16UahRK"
      } ]
    },
    "geo" : { },
    "id_str" : "316300306378010624",
    "text" : "New post: What corpora HAVE done for us http:\/\/t.co\/gJKDiBeJly #elt #efl #corpus",
    "id" : 316300306378010624,
    "created_at" : "2013-03-25 21:27:24 +0000",
    "user" : {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "protected" : false,
      "id_str" : "408365496",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/460546508601819136\/12ivDBb__normal.jpeg",
      "id" : 408365496,
      "verified" : false
    }
  },
  "id" : 316309186071887872,
  "created_at" : "2013-03-25 22:02:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheLanguagePoint",
      "screen_name" : "Marie_Sanako",
      "indices" : [ 3, 16 ],
      "id_str" : "356176087",
      "id" : 356176087
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lw2013",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/y92zb3uM8q",
      "expanded_url" : "http:\/\/thelanguagepoint.com\/english_collections\/show\/Tips%2521_Language_World_2013",
      "display_url" : "thelanguagepoint.com\/english_collec\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "316266689102770177",
  "text" : "RT @Marie_Sanako: So here's the first sweep of posts from Language World this year - pls let us know if we can include yours :) http:\/\/t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "lw2013",
        "indices" : [ 133, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/y92zb3uM8q",
        "expanded_url" : "http:\/\/thelanguagepoint.com\/english_collections\/show\/Tips%2521_Language_World_2013",
        "display_url" : "thelanguagepoint.com\/english_collec\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "316260327383760896",
    "text" : "So here's the first sweep of posts from Language World this year - pls let us know if we can include yours :) http:\/\/t.co\/y92zb3uM8q #lw2013",
    "id" : 316260327383760896,
    "created_at" : "2013-03-25 18:48:32 +0000",
    "user" : {
      "name" : "TheLanguagePoint",
      "screen_name" : "Marie_Sanako",
      "protected" : false,
      "id_str" : "356176087",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1810381097\/lpcombined_normal.jpg",
      "id" : 356176087,
      "verified" : false
    }
  },
  "id" : 316266689102770177,
  "created_at" : "2013-03-25 19:13:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316263518146002945",
  "text" : "@EBEFL thx for comment on minimal evidence tweet, replied",
  "id" : 316263518146002945,
  "created_at" : "2013-03-25 19:01:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 0, 13 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316263206219829248",
  "in_reply_to_user_id" : 88655243,
  "text" : "@rosemerebard thank u kindly for like on a corpus post :) hope all is gd with u",
  "id" : 316263206219829248,
  "created_at" : "2013-03-25 18:59:58 +0000",
  "in_reply_to_screen_name" : "rosemerebard",
  "in_reply_to_user_id_str" : "88655243",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ResearchED2013",
      "indices" : [ 79, 94 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 95, 103 ]
    }, {
      "text" : "eapchat",
      "indices" : [ 104, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/RHM3YaYjuD",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-uy",
      "display_url" : "wp.me\/pgHyE-uy"
    } ]
  },
  "geo" : { },
  "id_str" : "316242249887391744",
  "text" : "a quick question and thought - Minimal evidence tweets? http:\/\/t.co\/RHM3YaYjuD #ResearchED2013 #eltchat #eapchat",
  "id" : 316242249887391744,
  "created_at" : "2013-03-25 17:36:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FEED THE TEACHER",
      "screen_name" : "feedtheteacher",
      "indices" : [ 0, 15 ],
      "id_str" : "58839737",
      "id" : 58839737
    }, {
      "name" : "Mike Boyle",
      "screen_name" : "elyoBSekiM",
      "indices" : [ 16, 27 ],
      "id_str" : "1324597350",
      "id" : 1324597350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/liI2Wr1duP",
      "expanded_url" : "http:\/\/www.newscientist.com\/article\/mg21528765.700-the-intelligent-textbook-that-helps-students-learn.html",
      "display_url" : "newscientist.com\/article\/mg2152\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "233007477875146752",
  "geo" : { },
  "id_str" : "316227579038298112",
  "in_reply_to_user_id" : 58839737,
  "text" : "@feedtheteacher @elyoBSekiM\nmore info http:\/\/t.co\/liI2Wr1duP",
  "id" : 316227579038298112,
  "in_reply_to_status_id" : 233007477875146752,
  "created_at" : "2013-03-25 16:38:24 +0000",
  "in_reply_to_screen_name" : "feedtheteacher",
  "in_reply_to_user_id_str" : "58839737",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Huw Jarvis",
      "screen_name" : "TESOLacademic",
      "indices" : [ 3, 17 ],
      "id_str" : "43409552",
      "id" : 43409552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/3vhPTo1XnN",
      "expanded_url" : "http:\/\/www.tesolacademic.org\/keynotesnew.htm#908785573",
      "display_url" : "tesolacademic.org\/keynotesnew.ht\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "316096297495064576",
  "text" : "RT @TESOLacademic: Towards a paradigm shift on culture in ELT.  Learners are cultural travellers.  Prof. Holliday keynote video http:\/\/t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/3vhPTo1XnN",
        "expanded_url" : "http:\/\/www.tesolacademic.org\/keynotesnew.htm#908785573",
        "display_url" : "tesolacademic.org\/keynotesnew.ht\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "315151507525885952",
    "text" : "Towards a paradigm shift on culture in ELT.  Learners are cultural travellers.  Prof. Holliday keynote video http:\/\/t.co\/3vhPTo1XnN",
    "id" : 315151507525885952,
    "created_at" : "2013-03-22 17:22:29 +0000",
    "user" : {
      "name" : "Huw Jarvis",
      "screen_name" : "TESOLacademic",
      "protected" : false,
      "id_str" : "43409552",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/569419268\/bg-logo_normal.jpg",
      "id" : 43409552,
      "verified" : false
    }
  },
  "id" : 316096297495064576,
  "created_at" : "2013-03-25 07:56:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glyn Rogers",
      "screen_name" : "GlynRogers",
      "indices" : [ 3, 14 ],
      "id_str" : "196737704",
      "id" : 196737704
    }, {
      "name" : "IOE",
      "screen_name" : "IOE_London",
      "indices" : [ 139, 140 ],
      "id_str" : "106730860",
      "id" : 106730860
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/GH2wZveFHn",
      "expanded_url" : "http:\/\/wp.me\/p1wqwD-je",
      "display_url" : "wp.me\/p1wqwD-je"
    } ]
  },
  "geo" : { },
  "id_str" : "316084723866800128",
  "text" : "RT @GlynRogers: @researchED2013 Seen this? 'Evidence-based practice: why number-crunching tells only part of the story http:\/\/t.co\/GH2wZ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "IOE",
        "screen_name" : "IOE_London",
        "indices" : [ 127, 138 ],
        "id_str" : "106730860",
        "id" : 106730860
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/GH2wZveFHn",
        "expanded_url" : "http:\/\/wp.me\/p1wqwD-je",
        "display_url" : "wp.me\/p1wqwD-je"
      } ]
    },
    "in_reply_to_status_id_str" : "315956876909105154",
    "geo" : { },
    "id_str" : "315961101814738944",
    "in_reply_to_user_id" : 1289037060,
    "text" : "@researchED2013 Seen this? 'Evidence-based practice: why number-crunching tells only part of the story http:\/\/t.co\/GH2wZveFHn' @IOE_London",
    "id" : 315961101814738944,
    "in_reply_to_status_id" : 315956876909105154,
    "created_at" : "2013-03-24 22:59:31 +0000",
    "in_reply_to_screen_name" : "researchED1",
    "in_reply_to_user_id_str" : "1289037060",
    "user" : {
      "name" : "Glyn Rogers",
      "screen_name" : "GlynRogers",
      "protected" : false,
      "id_str" : "196737704",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/755347411275489280\/WewnpJA-_normal.jpg",
      "id" : 196737704,
      "verified" : false
    }
  },
  "id" : 316084723866800128,
  "created_at" : "2013-03-25 07:10:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315834746305396738",
  "geo" : { },
  "id_str" : "315897033741451264",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler great! here's to playing wth corpora :) thx for share and like of post.",
  "id" : 315897033741451264,
  "in_reply_to_status_id" : 315834746305396738,
  "created_at" : "2013-03-24 18:44:56 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemma Lunn",
      "screen_name" : "GemL1",
      "indices" : [ 0, 6 ],
      "id_str" : "486146568",
      "id" : 486146568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315645595756933121",
  "geo" : { },
  "id_str" : "315795276088627200",
  "in_reply_to_user_id" : 486146568,
  "text" : "@GemL1 thx for the share Gemma hope yr w\/e is going well :)",
  "id" : 315795276088627200,
  "in_reply_to_status_id" : 315645595756933121,
  "created_at" : "2013-03-24 12:00:35 +0000",
  "in_reply_to_screen_name" : "GemL1",
  "in_reply_to_user_id_str" : "486146568",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 74, 82 ]
    }, {
      "text" : "eapchat",
      "indices" : [ 83, 91 ]
    }, {
      "text" : "besig",
      "indices" : [ 92, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/f6KPyOp5vS",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-tW",
      "display_url" : "wp.me\/pgHyE-tW"
    } ]
  },
  "geo" : { },
  "id_str" : "315600022278377473",
  "text" : "new Building your own corpus - sorting body idioms http:\/\/t.co\/f6KPyOp5vS #eltchat #eapchat #besig",
  "id" : 315600022278377473,
  "created_at" : "2013-03-23 23:04:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RapBot",
      "indices" : [ 82, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/ZghznYhY3P",
      "expanded_url" : "http:\/\/rapbot.jit.su",
      "display_url" : "rapbot.jit.su"
    } ]
  },
  "geo" : { },
  "id_str" : "315512218051547136",
  "text" : "I'm a lyricist, I'm a microphone mix \/ Flow so radical, make the ladies all affix #RapBot http:\/\/t.co\/ZghznYhY3P",
  "id" : 315512218051547136,
  "created_at" : "2013-03-23 17:15:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/0HJjs1LmPS",
      "expanded_url" : "http:\/\/www.bmj.com\/content\/346\/bmj.f1848",
      "display_url" : "bmj.com\/content\/346\/bm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "315502223998189568",
  "text" : "The future of the NHS\u2014irreversible privatisation?\nhttp:\/\/t.co\/0HJjs1LmPS",
  "id" : 315502223998189568,
  "created_at" : "2013-03-23 16:36:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/g4ZWDteVf5",
      "expanded_url" : "http:\/\/www.openrightsgroup.org\/campaigns\/leveson",
      "display_url" : "openrightsgroup.org\/campaigns\/leve\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "315173732962410497",
  "text" : "Cameron, please don't clobber bloggers with Leveson http:\/\/t.co\/g4ZWDteVf5",
  "id" : 315173732962410497,
  "created_at" : "2013-03-22 18:50:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Huw Jarvis",
      "screen_name" : "TESOLacademic",
      "indices" : [ 0, 14 ],
      "id_str" : "43409552",
      "id" : 43409552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315151507525885952",
  "geo" : { },
  "id_str" : "315172350452703232",
  "in_reply_to_user_id" : 43409552,
  "text" : "@TESOLacademic \/to learn a lang you have to RESIST it by drawing on yr own cultural resources\/ -&gt;&gt; fascinating hypothesis",
  "id" : 315172350452703232,
  "in_reply_to_status_id" : 315151507525885952,
  "created_at" : "2013-03-22 18:45:18 +0000",
  "in_reply_to_screen_name" : "TESOLacademic",
  "in_reply_to_user_id_str" : "43409552",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicola Prentis",
      "screen_name" : "NicolaPrentis",
      "indices" : [ 0, 14 ],
      "id_str" : "810667033",
      "id" : 810667033
    }, {
      "name" : "Mike Boyle",
      "screen_name" : "elyoBSekiM",
      "indices" : [ 15, 26 ],
      "id_str" : "1324597350",
      "id" : 1324597350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314997235563773952",
  "geo" : { },
  "id_str" : "314999817367588864",
  "in_reply_to_user_id" : 810667033,
  "text" : "@NicolaPrentis @elyoBSekiM probably employment law requirements?",
  "id" : 314999817367588864,
  "in_reply_to_status_id" : 314997235563773952,
  "created_at" : "2013-03-22 07:19:43 +0000",
  "in_reply_to_screen_name" : "NicolaPrentis",
  "in_reply_to_user_id_str" : "810667033",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Moore",
      "screen_name" : "lexicojules",
      "indices" : [ 3, 15 ],
      "id_str" : "424320799",
      "id" : 424320799
    }, {
      "name" : "ben goldacre",
      "screen_name" : "bengoldacre",
      "indices" : [ 90, 102 ],
      "id_str" : "6705042",
      "id" : 6705042
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELTchat",
      "indices" : [ 119, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/FnTgzHyEY5",
      "expanded_url" : "http:\/\/ow.ly\/jhh7D",
      "display_url" : "ow.ly\/jhh7D"
    } ]
  },
  "geo" : { },
  "id_str" : "314719747080085505",
  "text" : "RT @lexicojules: A few thoughts on research in ELT prompted by the surprise appearance of @bengoldacre on last night's #ELTchat http:\/\/t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ben goldacre",
        "screen_name" : "bengoldacre",
        "indices" : [ 73, 85 ],
        "id_str" : "6705042",
        "id" : 6705042
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELTchat",
        "indices" : [ 102, 110 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/FnTgzHyEY5",
        "expanded_url" : "http:\/\/ow.ly\/jhh7D",
        "display_url" : "ow.ly\/jhh7D"
      } ]
    },
    "geo" : { },
    "id_str" : "314698759336493056",
    "text" : "A few thoughts on research in ELT prompted by the surprise appearance of @bengoldacre on last night's #ELTchat http:\/\/t.co\/FnTgzHyEY5",
    "id" : 314698759336493056,
    "created_at" : "2013-03-21 11:23:25 +0000",
    "user" : {
      "name" : "Julie Moore",
      "screen_name" : "lexicojules",
      "protected" : false,
      "id_str" : "424320799",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/478823971870109696\/AzIax4m3_normal.jpeg",
      "id" : 424320799,
      "verified" : false
    }
  },
  "id" : 314719747080085505,
  "created_at" : "2013-03-21 12:46:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 63, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314497213386608641",
  "text" : "thanks all definitely need revisiting a hugely important topic #eltchat",
  "id" : 314497213386608641,
  "created_at" : "2013-03-20 22:02:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MarisaConstantinides",
      "screen_name" : "Marisa_C",
      "indices" : [ 0, 9 ],
      "id_str" : "18272500",
      "id" : 18272500
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 93, 101 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314495878700335105",
  "geo" : { },
  "id_str" : "314496596589031424",
  "in_reply_to_user_id" : 18272500,
  "text" : "@Marisa_C &lt;&lt;is an accessible summary of educational research&gt;&gt; - quote from site #eltchat",
  "id" : 314496596589031424,
  "in_reply_to_status_id" : 314495878700335105,
  "created_at" : "2013-03-20 22:00:06 +0000",
  "in_reply_to_screen_name" : "Marisa_C",
  "in_reply_to_user_id_str" : "18272500",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 59, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/KnmOf3W6lm",
      "expanded_url" : "http:\/\/educationendowmentfoundation.org.uk\/toolkit\/",
      "display_url" : "educationendowmentfoundation.org.uk\/toolkit\/"
    } ]
  },
  "geo" : { },
  "id_str" : "314495583962398720",
  "text" : "this teacher toolkit is interesting http:\/\/t.co\/KnmOf3W6lm #eltchat",
  "id" : 314495583962398720,
  "created_at" : "2013-03-20 21:56:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0414\u0438\u0430\u043D\u043A\u0430 \u0428\u043A\u0443\u0440\u0441\u043A\u0430\u044F",
      "screen_name" : "TheSecretDoS",
      "indices" : [ 0, 13 ],
      "id_str" : "440292980",
      "id" : 440292980
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 68, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314494841050525696",
  "text" : "@TheSecretDoS the big problem of non-publishing of negative results #eltchat",
  "id" : 314494841050525696,
  "created_at" : "2013-03-20 21:53:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 92, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314493599209365505",
  "text" : "anything that helps tchrs to systematize their teaching e.g; checklists, corpora is helpful #eltchat",
  "id" : 314493599209365505,
  "created_at" : "2013-03-20 21:48:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Brown",
      "screen_name" : "sbrowntweets",
      "indices" : [ 0, 13 ],
      "id_str" : "885343459",
      "id" : 885343459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314377901371969536",
  "geo" : { },
  "id_str" : "314383317791297538",
  "in_reply_to_user_id" : 885343459,
  "text" : "@sbrowntweets what's it on? how to access with no subscription? ;)",
  "id" : 314383317791297538,
  "in_reply_to_status_id" : 314377901371969536,
  "created_at" : "2013-03-20 14:29:58 +0000",
  "in_reply_to_screen_name" : "sbrowntweets",
  "in_reply_to_user_id_str" : "885343459",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 84, 100 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/0M8dUl5Jms",
      "expanded_url" : "http:\/\/wp.me\/p2mDjs-3H",
      "display_url" : "wp.me\/p2mDjs-3H"
    } ]
  },
  "geo" : { },
  "id_str" : "314338684633755648",
  "text" : "The hobgoblins are back! Or rather, they never went away http:\/\/t.co\/0M8dUl5Jms via @wordpressdotcom",
  "id" : 314338684633755648,
  "created_at" : "2013-03-20 11:32:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joachim Castellano",
      "screen_name" : "wakisensei",
      "indices" : [ 0, 11 ],
      "id_str" : "59367896",
      "id" : 59367896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "313910152669577216",
  "geo" : { },
  "id_str" : "314337623965585408",
  "in_reply_to_user_id" : 59367896,
  "text" : "@wakisensei yeah lextutor.ca seems to be down for at least a day so far, hope it's nothing long term!",
  "id" : 314337623965585408,
  "in_reply_to_status_id" : 313910152669577216,
  "created_at" : "2013-03-20 11:28:24 +0000",
  "in_reply_to_screen_name" : "wakisensei",
  "in_reply_to_user_id_str" : "59367896",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Rei",
      "screen_name" : "Charlesrei1",
      "indices" : [ 0, 12 ],
      "id_str" : "464454382",
      "id" : 464454382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314333320244764673",
  "geo" : { },
  "id_str" : "314335178547924992",
  "in_reply_to_user_id" : 464454382,
  "text" : "@Charlesrei1 shouldn't be too difficult to work round it : )",
  "id" : 314335178547924992,
  "in_reply_to_status_id" : 314333320244764673,
  "created_at" : "2013-03-20 11:18:41 +0000",
  "in_reply_to_screen_name" : "Charlesrei1",
  "in_reply_to_user_id_str" : "464454382",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evgeny Morozov",
      "screen_name" : "evgenymorozov",
      "indices" : [ 3, 17 ],
      "id_str" : "30331417",
      "id" : 30331417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/QOL4B56aUI",
      "expanded_url" : "http:\/\/www.guardian.co.uk\/global\/2013\/mar\/20\/save-everything-evgeny-morozov-review",
      "display_url" : "guardian.co.uk\/global\/2013\/ma\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "314333816397389824",
  "text" : "RT @evgenymorozov: Nice review of \"To Save Everything...\" In The Guardian  http:\/\/t.co\/QOL4B56aUI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/QOL4B56aUI",
        "expanded_url" : "http:\/\/www.guardian.co.uk\/global\/2013\/mar\/20\/save-everything-evgeny-morozov-review",
        "display_url" : "guardian.co.uk\/global\/2013\/ma\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "314294727732236288",
    "text" : "Nice review of \"To Save Everything...\" In The Guardian  http:\/\/t.co\/QOL4B56aUI",
    "id" : 314294727732236288,
    "created_at" : "2013-03-20 08:37:57 +0000",
    "user" : {
      "name" : "Evgeny Morozov",
      "screen_name" : "evgenymorozov",
      "protected" : false,
      "id_str" : "30331417",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/640536915477794816\/u9TxNsKI_normal.jpg",
      "id" : 30331417,
      "verified" : false
    }
  },
  "id" : 314333816397389824,
  "created_at" : "2013-03-20 11:13:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314257842641178624",
  "text" : "@EBEFL here's to more hits and years :)",
  "id" : 314257842641178624,
  "created_at" : "2013-03-20 06:11:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314133942817128449",
  "geo" : { },
  "id_str" : "314147552889024512",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson did yr boss ever care to enlighten?",
  "id" : 314147552889024512,
  "in_reply_to_status_id" : 314133942817128449,
  "created_at" : "2013-03-19 22:53:07 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pat thomson",
      "screen_name" : "ThomsonPat",
      "indices" : [ 3, 14 ],
      "id_str" : "402209787",
      "id" : 402209787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/xTTqTnPrp1",
      "expanded_url" : "http:\/\/ow.ly\/je6Ew",
      "display_url" : "ow.ly\/je6Ew"
    } ]
  },
  "geo" : { },
  "id_str" : "314128693083643906",
  "text" : "RT @ThomsonPat: 100 academics savage Education Secretary Michael Gove for 'conveyor-belt curriculum' http:\/\/t.co\/xTTqTnPrp1. I was one o ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/xTTqTnPrp1",
        "expanded_url" : "http:\/\/ow.ly\/je6Ew",
        "display_url" : "ow.ly\/je6Ew"
      } ]
    },
    "geo" : { },
    "id_str" : "314124787968507904",
    "text" : "100 academics savage Education Secretary Michael Gove for 'conveyor-belt curriculum' http:\/\/t.co\/xTTqTnPrp1. I was one of them.",
    "id" : 314124787968507904,
    "created_at" : "2013-03-19 21:22:40 +0000",
    "user" : {
      "name" : "pat thomson",
      "screen_name" : "ThomsonPat",
      "protected" : false,
      "id_str" : "402209787",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/755094077977288704\/3J0_LE03_normal.jpg",
      "id" : 402209787,
      "verified" : false
    }
  },
  "id" : 314128693083643906,
  "created_at" : "2013-03-19 21:38:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Rei",
      "screen_name" : "Charlesrei1",
      "indices" : [ 0, 12 ],
      "id_str" : "464454382",
      "id" : 464454382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/UQwF8NsP3e",
      "expanded_url" : "http:\/\/www.bbc.co.uk\/archive\/great_egg_race\/",
      "display_url" : "bbc.co.uk\/archive\/great_\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "314117747208499200",
  "geo" : { },
  "id_str" : "314125804562956288",
  "in_reply_to_user_id" : 464454382,
  "text" : "@Charlesrei1 great task :) reminds me to dig up some Prof Heinz Wolf Great Egg Race tv episodes http:\/\/t.co\/UQwF8NsP3e",
  "id" : 314125804562956288,
  "in_reply_to_status_id" : 314117747208499200,
  "created_at" : "2013-03-19 21:26:42 +0000",
  "in_reply_to_screen_name" : "Charlesrei1",
  "in_reply_to_user_id_str" : "464454382",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Rei",
      "screen_name" : "Charlesrei1",
      "indices" : [ 3, 15 ],
      "id_str" : "464454382",
      "id" : 464454382
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "besig",
      "indices" : [ 106, 112 ]
    }, {
      "text" : "bizeng",
      "indices" : [ 113, 120 ]
    }, {
      "text" : "esl",
      "indices" : [ 121, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/EPJ4ToXukl",
      "expanded_url" : "http:\/\/businessenglishideas.blogspot.de\/2013\/03\/easter-for-engineers.html",
      "display_url" : "businessenglishideas.blogspot.de\/2013\/03\/easter\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "314125292933369856",
  "text" : "RT @Charlesrei1: I've just finished a new blog post - Easter for Engineers with a successful lesson idea. #besig #bizeng #esl http:\/\/t.c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "besig",
        "indices" : [ 89, 95 ]
      }, {
        "text" : "bizeng",
        "indices" : [ 96, 103 ]
      }, {
        "text" : "esl",
        "indices" : [ 104, 108 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/EPJ4ToXukl",
        "expanded_url" : "http:\/\/businessenglishideas.blogspot.de\/2013\/03\/easter-for-engineers.html",
        "display_url" : "businessenglishideas.blogspot.de\/2013\/03\/easter\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "314117747208499200",
    "text" : "I've just finished a new blog post - Easter for Engineers with a successful lesson idea. #besig #bizeng #esl http:\/\/t.co\/EPJ4ToXukl",
    "id" : 314117747208499200,
    "created_at" : "2013-03-19 20:54:41 +0000",
    "user" : {
      "name" : "Charles Rei",
      "screen_name" : "Charlesrei1",
      "protected" : false,
      "id_str" : "464454382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461561508057468928\/BA8otRW0_normal.jpeg",
      "id" : 464454382,
      "verified" : false
    }
  },
  "id" : 314125292933369856,
  "created_at" : "2013-03-19 21:24:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    }, {
      "name" : "Jo Cummins",
      "screen_name" : "jo_cummins",
      "indices" : [ 16, 27 ],
      "id_str" : "897738066",
      "id" : 897738066
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/R7h7rBHv02",
      "expanded_url" : "http:\/\/corpus2.byu.edu\/soap\/?c=soap&q=21800524&q1=21800541",
      "display_url" : "corpus2.byu.edu\/soap\/?c=soap&q\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "314115016481730560",
  "geo" : { },
  "id_str" : "314123603526426624",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson @jo_cummins gotten in US Soaps over 5000 times as likely compared to BNC http:\/\/t.co\/R7h7rBHv02",
  "id" : 314123603526426624,
  "in_reply_to_status_id" : 314115016481730560,
  "created_at" : "2013-03-19 21:17:57 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alannah Fitzgerald",
      "screen_name" : "AlannahFitz",
      "indices" : [ 3, 15 ],
      "id_str" : "223613160",
      "id" : 223613160
    }, {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 77, 85 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/JkFpZ5oGNt",
      "expanded_url" : "http:\/\/youtu.be\/JNb0ugOvwuw?a",
      "display_url" : "youtu.be\/JNb0ugOvwuw?a"
    } ]
  },
  "geo" : { },
  "id_str" : "313740275765878786",
  "text" : "RT @AlannahFitz: FLAX Learning Collocations Play: http:\/\/t.co\/JkFpZ5oGNt via @YouTube",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ 60, 68 ],
        "id_str" : "10228272",
        "id" : 10228272
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 55 ],
        "url" : "http:\/\/t.co\/JkFpZ5oGNt",
        "expanded_url" : "http:\/\/youtu.be\/JNb0ugOvwuw?a",
        "display_url" : "youtu.be\/JNb0ugOvwuw?a"
      } ]
    },
    "geo" : { },
    "id_str" : "313738450664833024",
    "text" : "FLAX Learning Collocations Play: http:\/\/t.co\/JkFpZ5oGNt via @YouTube",
    "id" : 313738450664833024,
    "created_at" : "2013-03-18 19:47:30 +0000",
    "user" : {
      "name" : "Alannah Fitzgerald",
      "screen_name" : "AlannahFitz",
      "protected" : false,
      "id_str" : "223613160",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2645381550\/e07d3b354efdac11bce2725cbc44e94e_normal.png",
      "id" : 223613160,
      "verified" : false
    }
  },
  "id" : 313740275765878786,
  "created_at" : "2013-03-18 19:54:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 5, 20 ],
      "id_str" : "20760283",
      "id" : 20760283
    }, {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 65, 76 ],
      "id_str" : "282659955",
      "id" : 282659955
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oldeltpost",
      "indices" : [ 50, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/8RYTRZpRYl",
      "expanded_url" : "http:\/\/wp.me\/p2hCXG-Bf",
      "display_url" : "wp.me\/p2hCXG-Bf"
    } ]
  },
  "geo" : { },
  "id_str" : "313717152580513793",
  "text" : "Help @MrChrisJWilson out and share your favourite #oldeltpost by @teflerinha http:\/\/t.co\/8RYTRZpRYl",
  "id" : 313717152580513793,
  "created_at" : "2013-03-18 18:22:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Willingham",
      "screen_name" : "DTWillingham",
      "indices" : [ 3, 16 ],
      "id_str" : "84619537",
      "id" : 84619537
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edtech",
      "indices" : [ 78, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/y8eBkVIeu2",
      "expanded_url" : "http:\/\/larrycuban.wordpress.com\/2013\/03\/18\/no-end-to-magical-thinking-when-it-comes-to-high-tech-schooling\/",
      "display_url" : "larrycuban.wordpress.com\/2013\/03\/18\/no-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "313693597050486784",
  "text" : "RT @DTWillingham: Larry Cuban not so keen on the hole-in-the-wall approach to #edtech http:\/\/t.co\/y8eBkVIeu2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "edtech",
        "indices" : [ 60, 67 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/y8eBkVIeu2",
        "expanded_url" : "http:\/\/larrycuban.wordpress.com\/2013\/03\/18\/no-end-to-magical-thinking-when-it-comes-to-high-tech-schooling\/",
        "display_url" : "larrycuban.wordpress.com\/2013\/03\/18\/no-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "313594706888101888",
    "text" : "Larry Cuban not so keen on the hole-in-the-wall approach to #edtech http:\/\/t.co\/y8eBkVIeu2",
    "id" : 313594706888101888,
    "created_at" : "2013-03-18 10:16:19 +0000",
    "user" : {
      "name" : "Daniel Willingham",
      "screen_name" : "DTWillingham",
      "protected" : false,
      "id_str" : "84619537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1815678310\/Daniel_Willingham_Color_lowres_normal.JPG",
      "id" : 84619537,
      "verified" : false
    }
  },
  "id" : 313693597050486784,
  "created_at" : "2013-03-18 16:49:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313598260600258561",
  "text" : "@MattHalsdorff thx for share, enjoy reading yr posts in this area :)",
  "id" : 313598260600258561,
  "created_at" : "2013-03-18 10:30:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/yH1uvMifgX",
      "expanded_url" : "http:\/\/wp.me\/p33cOf-1M",
      "display_url" : "wp.me\/p33cOf-1M"
    } ]
  },
  "geo" : { },
  "id_str" : "313405582705049602",
  "text" : "RLA Workshop Activity - Show Me the Money Cards http:\/\/t.co\/yH1uvMifgX via @MattHalsdorff",
  "id" : 313405582705049602,
  "created_at" : "2013-03-17 21:44:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/kzsjipyeGQ",
      "expanded_url" : "http:\/\/coerll.utexas.edu\/methods\/",
      "display_url" : "coerll.utexas.edu\/methods\/"
    } ]
  },
  "geo" : { },
  "id_str" : "313387092615000064",
  "text" : "very nice PD resource&gt;Foreign Language \nTeaching Methods\nhttp:\/\/t.co\/kzsjipyeGQ",
  "id" : 313387092615000064,
  "created_at" : "2013-03-17 20:31:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/ryCbFV2eFd",
      "expanded_url" : "http:\/\/johnhilley.blogspot.co.uk\/2013\/03\/free-speech-how-insulting.html",
      "display_url" : "johnhilley.blogspot.co.uk\/2013\/03\/free-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "313343852868149248",
  "text" : "Free speech? How insulting. http:\/\/t.co\/ryCbFV2eFd",
  "id" : 313343852868149248,
  "created_at" : "2013-03-17 17:39:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Willingham",
      "screen_name" : "DTWillingham",
      "indices" : [ 3, 16 ],
      "id_str" : "84619537",
      "id" : 84619537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/RdfkgJKKRS",
      "expanded_url" : "http:\/\/psychcentral.com\/news\/2013\/03\/16\/mindfulness-at-school-lowers-depressive-symptoms-in-teens\/52686.html",
      "display_url" : "psychcentral.com\/news\/2013\/03\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "312973285707096064",
  "text" : "RT @DTWillingham: Another study showing benefits to teens of meditation in school, this time reduced incidence of depression http:\/\/t.co ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/RdfkgJKKRS",
        "expanded_url" : "http:\/\/psychcentral.com\/news\/2013\/03\/16\/mindfulness-at-school-lowers-depressive-symptoms-in-teens\/52686.html",
        "display_url" : "psychcentral.com\/news\/2013\/03\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "312957510871023617",
    "text" : "Another study showing benefits to teens of meditation in school, this time reduced incidence of depression http:\/\/t.co\/RdfkgJKKRS",
    "id" : 312957510871023617,
    "created_at" : "2013-03-16 16:04:19 +0000",
    "user" : {
      "name" : "Daniel Willingham",
      "screen_name" : "DTWillingham",
      "protected" : false,
      "id_str" : "84619537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1815678310\/Daniel_Willingham_Color_lowres_normal.JPG",
      "id" : 84619537,
      "verified" : false
    }
  },
  "id" : 312973285707096064,
  "created_at" : "2013-03-16 17:07:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alessandra Martelli",
      "screen_name" : "mtmtranslations",
      "indices" : [ 3, 19 ],
      "id_str" : "229557242",
      "id" : 229557242
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "linguistics",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/n1cNIXymMN",
      "expanded_url" : "http:\/\/youtu.be\/A3fjK1q-0nk",
      "display_url" : "youtu.be\/A3fjK1q-0nk"
    } ]
  },
  "geo" : { },
  "id_str" : "312957276833062912",
  "text" : "RT @mtmtranslations: RT @MelisaPalferro: Noam Chomsky - Current Problems in the Study of Language and Mind: http:\/\/t.co\/n1cNIXymMN  #lin ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "linguistics",
        "indices" : [ 111, 123 ]
      } ],
      "urls" : [ {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/n1cNIXymMN",
        "expanded_url" : "http:\/\/youtu.be\/A3fjK1q-0nk",
        "display_url" : "youtu.be\/A3fjK1q-0nk"
      } ]
    },
    "geo" : { },
    "id_str" : "312930811605286913",
    "text" : "RT @MelisaPalferro: Noam Chomsky - Current Problems in the Study of Language and Mind: http:\/\/t.co\/n1cNIXymMN  #linguistics",
    "id" : 312930811605286913,
    "created_at" : "2013-03-16 14:18:14 +0000",
    "user" : {
      "name" : "Alessandra Martelli",
      "screen_name" : "mtmtranslations",
      "protected" : false,
      "id_str" : "229557242",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/726101337377792000\/81hEU8oU_normal.jpg",
      "id" : 229557242,
      "verified" : false
    }
  },
  "id" : 312957276833062912,
  "created_at" : "2013-03-16 16:03:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 110, 118 ]
    }, {
      "text" : "linguistics",
      "indices" : [ 119, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/ufVIn9t71q",
      "expanded_url" : "http:\/\/blogs.channel4.com\/alex-thomsons-view\/jack-straw-edging-word-iraq\/4330",
      "display_url" : "blogs.channel4.com\/alex-thomsons-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "312946723888697344",
  "text" : "on Jack Straw&lt;&lt;he said he meant criminal adjectivally rather than legally&gt;&gt;http:\/\/t.co\/ufVIn9t71q #eltchat #linguistics - discuss",
  "id" : 312946723888697344,
  "created_at" : "2013-03-16 15:21:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bethany Cagnol",
      "screen_name" : "bethcagnol",
      "indices" : [ 3, 14 ],
      "id_str" : "27641720",
      "id" : 27641720
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 16, 23 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/1JBwXXN6P4",
      "expanded_url" : "https:\/\/connectpro10829081.adobeconnect.com\/_a875541554\/howto\/",
      "display_url" : "connectpro10829081.adobeconnect.com\/_a875541554\/ho\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "312835105213267968",
  "text" : "RT @bethcagnol: #IATEFL \"How To\" Webinar launch today @ 15:00GMT w\/ Susan Barduhn and Catherine Walter. https:\/\/t.co\/1JBwXXN6P4\nYours tr ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IATEFL",
        "indices" : [ 0, 7 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/1JBwXXN6P4",
        "expanded_url" : "https:\/\/connectpro10829081.adobeconnect.com\/_a875541554\/howto\/",
        "display_url" : "connectpro10829081.adobeconnect.com\/_a875541554\/ho\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "312832877958164480",
    "text" : "#IATEFL \"How To\" Webinar launch today @ 15:00GMT w\/ Susan Barduhn and Catherine Walter. https:\/\/t.co\/1JBwXXN6P4\nYours truly will be hosting!",
    "id" : 312832877958164480,
    "created_at" : "2013-03-16 07:49:04 +0000",
    "user" : {
      "name" : "Bethany Cagnol",
      "screen_name" : "bethcagnol",
      "protected" : false,
      "id_str" : "27641720",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/425969412265373696\/jdqAse11_normal.jpeg",
      "id" : 27641720,
      "verified" : false
    }
  },
  "id" : 312835105213267968,
  "created_at" : "2013-03-16 07:57:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bethany Cagnol",
      "screen_name" : "bethcagnol",
      "indices" : [ 0, 11 ],
      "id_str" : "27641720",
      "id" : 27641720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "312832877958164480",
  "geo" : { },
  "id_str" : "312835083205754880",
  "in_reply_to_user_id" : 27641720,
  "text" : "@bethcagnol what are these exactly?",
  "id" : 312835083205754880,
  "in_reply_to_status_id" : 312832877958164480,
  "created_at" : "2013-03-16 07:57:50 +0000",
  "in_reply_to_screen_name" : "bethcagnol",
  "in_reply_to_user_id_str" : "27641720",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 67, 75 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 76, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/vcwTiHAfD7",
      "expanded_url" : "http:\/\/marlajarmer.net.p9.hostingprod.com\/yahoo_site_admin\/assets\/docs\/Writing_for_the_World.303111056.pdf",
      "display_url" : "marlajarmer.net.p9.hostingprod.com\/yahoo_site_adm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "312832387736276992",
  "text" : "Wikipidia as intro to academic writing http:\/\/t.co\/vcwTiHAfD7 \u2026 cc @seburnt #eapchat",
  "id" : 312832387736276992,
  "created_at" : "2013-03-16 07:47:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    }, {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 13, 28 ],
      "id_str" : "20760283",
      "id" : 20760283
    }, {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 29, 45 ],
      "id_str" : "394053348",
      "id" : 394053348
    }, {
      "name" : "chadsansing",
      "screen_name" : "chadsansing",
      "indices" : [ 46, 58 ],
      "id_str" : "76810409",
      "id" : 76810409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "312704789114937345",
  "geo" : { },
  "id_str" : "312822339408633857",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler @MrChrisJWilson @michaelegriffin @chadsansing a pleasure maybe can lk fwd to more of yr linguistic learnings? :)",
  "id" : 312822339408633857,
  "in_reply_to_status_id" : 312704789114937345,
  "created_at" : "2013-03-16 07:07:12 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 3, 16 ],
      "id_str" : "88655243",
      "id" : 88655243
    }, {
      "name" : "Alex Grevett",
      "screen_name" : "breathyvowel",
      "indices" : [ 80, 93 ],
      "id_str" : "237547177",
      "id" : 237547177
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/AOKDV1HOII",
      "expanded_url" : "http:\/\/wp.me\/p1oRWE-ay",
      "display_url" : "wp.me\/p1oRWE-ay"
    } ]
  },
  "geo" : { },
  "id_str" : "312821790466514944",
  "text" : "RT @rosemerebard: Thinking big, making small changes http:\/\/t.co\/AOKDV1HOII via @breathyvowel - I hope you have a great semester Alex.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Alex Grevett",
        "screen_name" : "breathyvowel",
        "indices" : [ 62, 75 ],
        "id_str" : "237547177",
        "id" : 237547177
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 57 ],
        "url" : "http:\/\/t.co\/AOKDV1HOII",
        "expanded_url" : "http:\/\/wp.me\/p1oRWE-ay",
        "display_url" : "wp.me\/p1oRWE-ay"
      } ]
    },
    "geo" : { },
    "id_str" : "312745365948489731",
    "text" : "Thinking big, making small changes http:\/\/t.co\/AOKDV1HOII via @breathyvowel - I hope you have a great semester Alex.",
    "id" : 312745365948489731,
    "created_at" : "2013-03-16 02:01:20 +0000",
    "user" : {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "protected" : false,
      "id_str" : "88655243",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/706508144160145410\/pKzknb5H_normal.jpg",
      "id" : 88655243,
      "verified" : false
    }
  },
  "id" : 312821790466514944,
  "created_at" : "2013-03-16 07:05:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 3, 18 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELT",
      "indices" : [ 47, 51 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 86, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/AJ9eZLKZ43",
      "expanded_url" : "http:\/\/wp.me\/p2hCXG-Bq",
      "display_url" : "wp.me\/p2hCXG-Bq"
    } ]
  },
  "geo" : { },
  "id_str" : "312670120952619008",
  "text" : "RT @MrChrisJWilson: Another Weekly round up in #ELT 15\/03\/2013 http:\/\/t.co\/AJ9eZLKZ43 #eltchat &lt; feel free to add links to good artic ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELT",
        "indices" : [ 27, 31 ]
      }, {
        "text" : "eltchat",
        "indices" : [ 66, 74 ]
      } ],
      "urls" : [ {
        "indices" : [ 43, 65 ],
        "url" : "http:\/\/t.co\/AJ9eZLKZ43",
        "expanded_url" : "http:\/\/wp.me\/p2hCXG-Bq",
        "display_url" : "wp.me\/p2hCXG-Bq"
      } ]
    },
    "geo" : { },
    "id_str" : "312621677261500416",
    "text" : "Another Weekly round up in #ELT 15\/03\/2013 http:\/\/t.co\/AJ9eZLKZ43 #eltchat &lt; feel free to add links to good articles I missed.",
    "id" : 312621677261500416,
    "created_at" : "2013-03-15 17:49:50 +0000",
    "user" : {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "protected" : false,
      "id_str" : "20760283",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744952885595758592\/H4bmsUn3_normal.jpg",
      "id" : 20760283,
      "verified" : false
    }
  },
  "id" : 312670120952619008,
  "created_at" : "2013-03-15 21:02:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chadsansing",
      "screen_name" : "chadsansing",
      "indices" : [ 0, 12 ],
      "id_str" : "76810409",
      "id" : 76810409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/u5AukXGooJ",
      "expanded_url" : "https:\/\/thimble.webmaker.org\/p\/fepv\/",
      "display_url" : "thimble.webmaker.org\/p\/fepv\/"
    } ]
  },
  "in_reply_to_status_id_str" : "312631581456093184",
  "geo" : { },
  "id_str" : "312668180533346304",
  "in_reply_to_user_id" : 76810409,
  "text" : "@chadsansing https:\/\/t.co\/u5AukXGooJ great fun :)",
  "id" : 312668180533346304,
  "in_reply_to_status_id" : 312631581456093184,
  "created_at" : "2013-03-15 20:54:37 +0000",
  "in_reply_to_screen_name" : "chadsansing",
  "in_reply_to_user_id_str" : "76810409",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valentina Morgana",
      "screen_name" : "vmorgana",
      "indices" : [ 0, 9 ],
      "id_str" : "62479177",
      "id" : 62479177
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "312632626856996865",
  "geo" : { },
  "id_str" : "312648651010875393",
  "in_reply_to_user_id" : 62479177,
  "text" : "@vmorgana wow nice one! :)",
  "id" : 312648651010875393,
  "in_reply_to_status_id" : 312632626856996865,
  "created_at" : "2013-03-15 19:37:01 +0000",
  "in_reply_to_screen_name" : "vmorgana",
  "in_reply_to_user_id_str" : "62479177",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "312621677261500416",
  "geo" : { },
  "id_str" : "312624596249612289",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson thx for mention and i like your \"create your own corpus title\", dang, i may steal that :), have a g\/d w\/e",
  "id" : 312624596249612289,
  "in_reply_to_status_id" : 312621677261500416,
  "created_at" : "2013-03-15 18:01:26 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    }, {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 17, 23 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    }, {
      "name" : "Ava Fruin",
      "screen_name" : "avafruin",
      "indices" : [ 24, 33 ],
      "id_str" : "22528522",
      "id" : 22528522
    }, {
      "name" : "Jo Cummins",
      "screen_name" : "jo_cummins",
      "indices" : [ 34, 45 ],
      "id_str" : "897738066",
      "id" : 897738066
    }, {
      "name" : "Nicola Prentis",
      "screen_name" : "NicolaPrentis",
      "indices" : [ 46, 60 ],
      "id_str" : "810667033",
      "id" : 810667033
    }, {
      "name" : "Gemma Lunn",
      "screen_name" : "GemL1",
      "indices" : [ 61, 67 ],
      "id_str" : "486146568",
      "id" : 486146568
    }, {
      "name" : "Tom Randolph",
      "screen_name" : "TomTesol",
      "indices" : [ 68, 77 ],
      "id_str" : "1039673456",
      "id" : 1039673456
    }, {
      "name" : "Valentina Morgana",
      "screen_name" : "vmorgana",
      "indices" : [ 78, 87 ],
      "id_str" : "62479177",
      "id" : 62479177
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "312616191900389377",
  "geo" : { },
  "id_str" : "312619644915699714",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin @EBEFL @avafruin @jo_cummins @NicolaPrentis @GemL1 @TomTesol @vmorgana cheers mike, fab w\/e to all",
  "id" : 312619644915699714,
  "in_reply_to_status_id" : 312616191900389377,
  "created_at" : "2013-03-15 17:41:46 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/pQGvZfooZr",
      "expanded_url" : "http:\/\/ow.ly\/iRmly",
      "display_url" : "ow.ly\/iRmly"
    } ]
  },
  "geo" : { },
  "id_str" : "312618854587187200",
  "text" : "RT @medialens: Latest alert: Death Of A Bogeyman - The Corporate Media Bury Hugo Ch\u00E1vez http:\/\/t.co\/pQGvZfooZr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/pQGvZfooZr",
        "expanded_url" : "http:\/\/ow.ly\/iRmly",
        "display_url" : "ow.ly\/iRmly"
      } ]
    },
    "geo" : { },
    "id_str" : "312511846773047296",
    "text" : "Latest alert: Death Of A Bogeyman - The Corporate Media Bury Hugo Ch\u00E1vez http:\/\/t.co\/pQGvZfooZr",
    "id" : 312511846773047296,
    "created_at" : "2013-03-15 10:33:25 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 312618854587187200,
  "created_at" : "2013-03-15 17:38:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenn Greenwald",
      "screen_name" : "ggreenwald",
      "indices" : [ 3, 14 ],
      "id_str" : "16076032",
      "id" : 16076032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/3tkTEo3pBy",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=6L79wWAFUqg",
      "display_url" : "youtube.com\/watch?v=6L79wW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "312616875760705536",
  "text" : "RT @ggreenwald: Almost 100,000 have viewed Laura Poitras' great 5-minute documentary on the Bradley Manning tape   http:\/\/t.co\/3tkTEo3pBy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/3tkTEo3pBy",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=6L79wWAFUqg",
        "display_url" : "youtube.com\/watch?v=6L79wW\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "312258756601856001",
    "text" : "Almost 100,000 have viewed Laura Poitras' great 5-minute documentary on the Bradley Manning tape   http:\/\/t.co\/3tkTEo3pBy",
    "id" : 312258756601856001,
    "created_at" : "2013-03-14 17:47:43 +0000",
    "user" : {
      "name" : "Glenn Greenwald",
      "screen_name" : "ggreenwald",
      "protected" : false,
      "id_str" : "16076032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/659383028771364869\/G9HHnjiI_normal.jpg",
      "id" : 16076032,
      "verified" : true
    }
  },
  "id" : 312616875760705536,
  "created_at" : "2013-03-15 17:30:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/JEHSwGmKaD",
      "expanded_url" : "http:\/\/lsuvietnam.com\/2013\/03\/15\/do-you-see-what-i-see\/",
      "display_url" : "lsuvietnam.com\/2013\/03\/15\/do-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "312607392435142656",
  "geo" : { },
  "id_str" : "312611692137824257",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson no but you may like this http:\/\/t.co\/JEHSwGmKaD",
  "id" : 312611692137824257,
  "in_reply_to_status_id" : 312607392435142656,
  "created_at" : "2013-03-15 17:10:10 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    }, {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 19, 31 ],
      "id_str" : "525013404",
      "id" : 525013404
    }, {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 56, 72 ],
      "id_str" : "394053348",
      "id" : 394053348
    }, {
      "name" : "chadsansing",
      "screen_name" : "chadsansing",
      "indices" : [ 101, 113 ],
      "id_str" : "76810409",
      "id" : 76810409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/Ag5IVxm0vr",
      "expanded_url" : "http:\/\/lizzieserene.wordpress.com\/2013\/03\/15\/how-i-almost-won-an-argument-using-corpus-linguistics\/",
      "display_url" : "lizzieserene.wordpress.com\/2013\/03\/15\/how\u2026"
    }, {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/JDq57uTQPm",
      "expanded_url" : "http:\/\/wp.me\/p25Kfd-dr",
      "display_url" : "wp.me\/p25Kfd-dr"
    }, {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/7qaPqutsjn",
      "expanded_url" : "http:\/\/bit.ly\/15P7I1V",
      "display_url" : "bit.ly\/15P7I1V"
    } ]
  },
  "in_reply_to_status_id_str" : "312596878703353856",
  "geo" : { },
  "id_str" : "312602811147882497",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson +1 @AnneHendler http:\/\/t.co\/Ag5IVxm0vr, @michaelegriffin  http:\/\/t.co\/JDq57uTQPm and @chadsansing http:\/\/t.co\/7qaPqutsjn",
  "id" : 312602811147882497,
  "in_reply_to_status_id" : 312596878703353856,
  "created_at" : "2013-03-15 16:34:52 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John T. Spencer",
      "screen_name" : "JohnTSpencer",
      "indices" : [ 0, 13 ],
      "id_str" : "2285706270",
      "id" : 2285706270
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/gDSSbfFNLa",
      "expanded_url" : "http:\/\/corpus.byu.edu\/coca\/?c=coca&q=21719975",
      "display_url" : "corpus.byu.edu\/coca\/?c=coca&q\u2026"
    }, {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/5d7buucEWA",
      "expanded_url" : "http:\/\/corpus.byu.edu\/coca\/?c=coca&q=21720007",
      "display_url" : "corpus.byu.edu\/coca\/?c=coca&q\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "312584932297936896",
  "geo" : { },
  "id_str" : "312592990327681024",
  "in_reply_to_user_id" : 18389166,
  "text" : "@johntspencer hmm u cld be onto a trend there - need  http:\/\/t.co\/gDSSbfFNLa vs want http:\/\/t.co\/5d7buucEWA :)",
  "id" : 312592990327681024,
  "in_reply_to_status_id" : 312584932297936896,
  "created_at" : "2013-03-15 15:55:51 +0000",
  "in_reply_to_screen_name" : "spencerideas",
  "in_reply_to_user_id_str" : "18389166",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Meryl Alper",
      "screen_name" : "merylalper",
      "indices" : [ 3, 14 ],
      "id_str" : "103413137",
      "id" : 103413137
    }, {
      "name" : "annmarie thomas",
      "screen_name" : "amptMN",
      "indices" : [ 38, 45 ],
      "id_str" : "20567040",
      "id" : 20567040
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UDL",
      "indices" : [ 89, 93 ]
    }, {
      "text" : "dml2013",
      "indices" : [ 94, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/rRRqaKndpf",
      "expanded_url" : "http:\/\/courseweb.stthomas.edu\/apthomas\/SquishyCircuits\/",
      "display_url" : "courseweb.stthomas.edu\/apthomas\/Squis\u2026"
    }, {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/kamWajlA5b",
      "expanded_url" : "http:\/\/www.sensoryobjects.com\/",
      "display_url" : "sensoryobjects.com"
    } ]
  },
  "geo" : { },
  "id_str" : "312580960262692865",
  "text" : "RT @merylalper: squishy circuits from @amptMN are an amazing example of universal design #UDL #dml2013 http:\/\/t.co\/rRRqaKndpf http:\/\/t.c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "annmarie thomas",
        "screen_name" : "amptMN",
        "indices" : [ 22, 29 ],
        "id_str" : "20567040",
        "id" : 20567040
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UDL",
        "indices" : [ 73, 77 ]
      }, {
        "text" : "dml2013",
        "indices" : [ 78, 86 ]
      } ],
      "urls" : [ {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/rRRqaKndpf",
        "expanded_url" : "http:\/\/courseweb.stthomas.edu\/apthomas\/SquishyCircuits\/",
        "display_url" : "courseweb.stthomas.edu\/apthomas\/Squis\u2026"
      }, {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/kamWajlA5b",
        "expanded_url" : "http:\/\/www.sensoryobjects.com\/",
        "display_url" : "sensoryobjects.com"
      } ]
    },
    "geo" : { },
    "id_str" : "312574016483381248",
    "text" : "squishy circuits from @amptMN are an amazing example of universal design #UDL #dml2013 http:\/\/t.co\/rRRqaKndpf http:\/\/t.co\/kamWajlA5b",
    "id" : 312574016483381248,
    "created_at" : "2013-03-15 14:40:27 +0000",
    "user" : {
      "name" : "Meryl Alper",
      "screen_name" : "merylalper",
      "protected" : false,
      "id_str" : "103413137",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2542560565\/g79ayncnrg6t21s7n4ho_normal.jpeg",
      "id" : 103413137,
      "verified" : true
    }
  },
  "id" : 312580960262692865,
  "created_at" : "2013-03-15 15:08:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Shepherd",
      "screen_name" : "samshep",
      "indices" : [ 3, 11 ],
      "id_str" : "20146035",
      "id" : 20146035
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/6vBUZ9BIU6",
      "expanded_url" : "http:\/\/wp.me\/pZQ5N-nY",
      "display_url" : "wp.me\/pZQ5N-nY"
    } ]
  },
  "geo" : { },
  "id_str" : "312577080560857090",
  "text" : "RT @samshep: Evidence: something I've learned from being a parent http:\/\/t.co\/6vBUZ9BIU6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 75 ],
        "url" : "http:\/\/t.co\/6vBUZ9BIU6",
        "expanded_url" : "http:\/\/wp.me\/pZQ5N-nY",
        "display_url" : "wp.me\/pZQ5N-nY"
      } ]
    },
    "geo" : { },
    "id_str" : "312452914180407296",
    "text" : "Evidence: something I've learned from being a parent http:\/\/t.co\/6vBUZ9BIU6",
    "id" : 312452914180407296,
    "created_at" : "2013-03-15 06:39:14 +0000",
    "user" : {
      "name" : "Sam Shepherd",
      "screen_name" : "samshep",
      "protected" : false,
      "id_str" : "20146035",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/740863245880197120\/_BaMJ5Hf_normal.jpg",
      "id" : 20146035,
      "verified" : false
    }
  },
  "id" : 312577080560857090,
  "created_at" : "2013-03-15 14:52:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemma Lunn",
      "screen_name" : "GemL1",
      "indices" : [ 0, 6 ],
      "id_str" : "486146568",
      "id" : 486146568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "312381468078899200",
  "geo" : { },
  "id_str" : "312570780938539008",
  "in_reply_to_user_id" : 486146568,
  "text" : "@GemL1 thx, that's encouraging to hear :)",
  "id" : 312570780938539008,
  "in_reply_to_status_id" : 312381468078899200,
  "created_at" : "2013-03-15 14:27:36 +0000",
  "in_reply_to_screen_name" : "GemL1",
  "in_reply_to_user_id_str" : "486146568",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lynne Murphy",
      "screen_name" : "lynneguist",
      "indices" : [ 3, 14 ],
      "id_str" : "16316886",
      "id" : 16316886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/9cRKr3xxIG",
      "expanded_url" : "http:\/\/rustleblog.wordpress.com\/2013\/03\/15\/scribing-and-reviewing-an-alternative-to-student-presentations\/",
      "display_url" : "rustleblog.wordpress.com\/2013\/03\/15\/scr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "312567569326411776",
  "text" : "RT @lynneguist: Our teaching &amp; learning blog (@SussexTLDU) has written about one of my seminar activities\/assessments, 'scribing': h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 141 ],
        "url" : "http:\/\/t.co\/9cRKr3xxIG",
        "expanded_url" : "http:\/\/rustleblog.wordpress.com\/2013\/03\/15\/scribing-and-reviewing-an-alternative-to-student-presentations\/",
        "display_url" : "rustleblog.wordpress.com\/2013\/03\/15\/scr\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "312526859541807105",
    "text" : "Our teaching &amp; learning blog (@SussexTLDU) has written about one of my seminar activities\/assessments, 'scribing': http:\/\/t.co\/9cRKr3xxIG",
    "id" : 312526859541807105,
    "created_at" : "2013-03-15 11:33:04 +0000",
    "user" : {
      "name" : "Lynne Murphy",
      "screen_name" : "lynneguist",
      "protected" : false,
      "id_str" : "16316886",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632304665821081601\/BiPmyu1t_normal.jpg",
      "id" : 16316886,
      "verified" : false
    }
  },
  "id" : 312567569326411776,
  "created_at" : "2013-03-15 14:14:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharon Turner",
      "screen_name" : "Sharonzspace",
      "indices" : [ 3, 16 ],
      "id_str" : "235194378",
      "id" : 235194378
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELTCHAT",
      "indices" : [ 87, 95 ]
    }, {
      "text" : "TESOL",
      "indices" : [ 96, 102 ]
    }, {
      "text" : "EAPCHAT",
      "indices" : [ 103, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/enC1nrvkyV",
      "expanded_url" : "http:\/\/www.sharonzspace.com\/?p=1195",
      "display_url" : "sharonzspace.com\/?p=1195"
    } ]
  },
  "geo" : { },
  "id_str" : "312556400188477441",
  "text" : "RT @Sharonzspace: Blog post: Play in EFL with some lesson ideas http:\/\/t.co\/enC1nrvkyV #ELTCHAT #TESOL #EAPCHAT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELTCHAT",
        "indices" : [ 69, 77 ]
      }, {
        "text" : "TESOL",
        "indices" : [ 78, 84 ]
      }, {
        "text" : "EAPCHAT",
        "indices" : [ 85, 93 ]
      } ],
      "urls" : [ {
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/enC1nrvkyV",
        "expanded_url" : "http:\/\/www.sharonzspace.com\/?p=1195",
        "display_url" : "sharonzspace.com\/?p=1195"
      } ]
    },
    "geo" : { },
    "id_str" : "312553151452573696",
    "text" : "Blog post: Play in EFL with some lesson ideas http:\/\/t.co\/enC1nrvkyV #ELTCHAT #TESOL #EAPCHAT",
    "id" : 312553151452573696,
    "created_at" : "2013-03-15 13:17:32 +0000",
    "user" : {
      "name" : "Sharon Turner",
      "screen_name" : "Sharonzspace",
      "protected" : false,
      "id_str" : "235194378",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1228523517\/books_normal.JPG",
      "id" : 235194378,
      "verified" : false
    }
  },
  "id" : 312556400188477441,
  "created_at" : "2013-03-15 13:30:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 3, 14 ],
      "id_str" : "144663117",
      "id" : 144663117
    }, {
      "name" : "Carol Goodey",
      "screen_name" : "cgoodey",
      "indices" : [ 21, 29 ],
      "id_str" : "26606833",
      "id" : 26606833
    }, {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 73, 89 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/fyFGkUupZ0",
      "expanded_url" : "http:\/\/wp.me\/p25Kfd-dr",
      "display_url" : "wp.me\/p25Kfd-dr"
    } ]
  },
  "geo" : { },
  "id_str" : "312550035260841984",
  "text" : "RT @kevchanwow: MT: \u201C@cgoodey: Gr8 'cool things' post &amp; challenge by @michaelegriffin http:\/\/t.co\/fyFGkUupZ0 w\/links to\/comments fro ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Carol Goodey",
        "screen_name" : "cgoodey",
        "indices" : [ 5, 13 ],
        "id_str" : "26606833",
        "id" : 26606833
      }, {
        "name" : "Michael Griffin",
        "screen_name" : "michaelegriffin",
        "indices" : [ 57, 73 ],
        "id_str" : "394053348",
        "id" : 394053348
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/fyFGkUupZ0",
        "expanded_url" : "http:\/\/wp.me\/p25Kfd-dr",
        "display_url" : "wp.me\/p25Kfd-dr"
      } ]
    },
    "geo" : { },
    "id_str" : "312547380161572864",
    "text" : "MT: \u201C@cgoodey: Gr8 'cool things' post &amp; challenge by @michaelegriffin http:\/\/t.co\/fyFGkUupZ0 w\/links to\/comments from others&gt;Gr8 indeed",
    "id" : 312547380161572864,
    "created_at" : "2013-03-15 12:54:36 +0000",
    "user" : {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "protected" : false,
      "id_str" : "144663117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/559618421839507456\/nPF7dP47_normal.jpeg",
      "id" : 144663117,
      "verified" : false
    }
  },
  "id" : 312550035260841984,
  "created_at" : "2013-03-15 13:05:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lewis School HR",
      "screen_name" : "alatlewisschool",
      "indices" : [ 0, 16 ],
      "id_str" : "473783869",
      "id" : 473783869
    }, {
      "name" : "Jonny K",
      "screen_name" : "joko1984",
      "indices" : [ 17, 26 ],
      "id_str" : "18719548",
      "id" : 18719548
    }, {
      "name" : "FlyingSQ",
      "screen_name" : "FlyingSQ",
      "indices" : [ 27, 36 ],
      "id_str" : "2852523222",
      "id" : 2852523222
    }, {
      "name" : "Phil Dawson",
      "screen_name" : "learnocracy",
      "indices" : [ 37, 49 ],
      "id_str" : "17894411",
      "id" : 17894411
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "312483959978201088",
  "geo" : { },
  "id_str" : "312549463048724480",
  "in_reply_to_user_id" : 473783869,
  "text" : "@alatlewisschool @JOKO1984 @flyingsq @learnocracy cheers have a good w\/e :)",
  "id" : 312549463048724480,
  "in_reply_to_status_id" : 312483959978201088,
  "created_at" : "2013-03-15 13:02:53 +0000",
  "in_reply_to_screen_name" : "alatlewisschool",
  "in_reply_to_user_id_str" : "473783869",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donald Clark",
      "screen_name" : "DonaldClark",
      "indices" : [ 3, 15 ],
      "id_str" : "1632891",
      "id" : 1632891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/MGO6svS3hd",
      "expanded_url" : "http:\/\/bit.ly\/ZRzMQr",
      "display_url" : "bit.ly\/ZRzMQr"
    } ]
  },
  "geo" : { },
  "id_str" : "312548857454157826",
  "text" : "RT @DonaldClark: Google Glass: 7 amazing uses in learning http:\/\/t.co\/MGO6svS3hd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/MGO6svS3hd",
        "expanded_url" : "http:\/\/bit.ly\/ZRzMQr",
        "display_url" : "bit.ly\/ZRzMQr"
      } ]
    },
    "geo" : { },
    "id_str" : "312338201551441921",
    "text" : "Google Glass: 7 amazing uses in learning http:\/\/t.co\/MGO6svS3hd",
    "id" : 312338201551441921,
    "created_at" : "2013-03-14 23:03:24 +0000",
    "user" : {
      "name" : "Donald Clark",
      "screen_name" : "DonaldClark",
      "protected" : false,
      "id_str" : "1632891",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/513085530695663616\/BfWK4n6u_normal.jpeg",
      "id" : 1632891,
      "verified" : false
    }
  },
  "id" : 312548857454157826,
  "created_at" : "2013-03-15 13:00:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evgeny Morozov",
      "screen_name" : "evgenymorozov",
      "indices" : [ 3, 17 ],
      "id_str" : "30331417",
      "id" : 30331417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/WGMEWiknDO",
      "expanded_url" : "http:\/\/www.edrants.com\/thirty-five-arguments-against-google-glass\/",
      "display_url" : "edrants.com\/thirty-five-ar\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "312548133215277057",
  "text" : "RT @evgenymorozov: 35 Arguments Against Google Glass http:\/\/t.co\/WGMEWiknDO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 34, 56 ],
        "url" : "http:\/\/t.co\/WGMEWiknDO",
        "expanded_url" : "http:\/\/www.edrants.com\/thirty-five-arguments-against-google-glass\/",
        "display_url" : "edrants.com\/thirty-five-ar\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "312284903079284737",
    "text" : "35 Arguments Against Google Glass http:\/\/t.co\/WGMEWiknDO",
    "id" : 312284903079284737,
    "created_at" : "2013-03-14 19:31:37 +0000",
    "user" : {
      "name" : "Evgeny Morozov",
      "screen_name" : "evgenymorozov",
      "protected" : false,
      "id_str" : "30331417",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/640536915477794816\/u9TxNsKI_normal.jpg",
      "id" : 30331417,
      "verified" : false
    }
  },
  "id" : 312548133215277057,
  "created_at" : "2013-03-15 12:57:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemma Lunn",
      "screen_name" : "GemL1",
      "indices" : [ 0, 6 ],
      "id_str" : "486146568",
      "id" : 486146568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "312345510369452032",
  "geo" : { },
  "id_str" : "312370971896066048",
  "in_reply_to_user_id" : 486146568,
  "text" : "@GemL1 cheers Gemma :)",
  "id" : 312370971896066048,
  "in_reply_to_status_id" : 312345510369452032,
  "created_at" : "2013-03-15 01:13:37 +0000",
  "in_reply_to_screen_name" : "GemL1",
  "in_reply_to_user_id_str" : "486146568",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 3, 15 ],
      "id_str" : "525013404",
      "id" : 525013404
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 17, 26 ],
      "id_str" : "18602422",
      "id" : 18602422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/qi79tJ9uJ4",
      "expanded_url" : "http:\/\/lizzieserene.wordpress.com\/2013\/03\/15\/how-i-almost-won-an-argument-using-corpus-linguistics\/",
      "display_url" : "lizzieserene.wordpress.com\/2013\/03\/15\/how\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "312356665326440448",
  "text" : "RT @AnneHendler: @muranava http:\/\/t.co\/qi79tJ9uJ4 a blog post. ^^ (thanks)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mura Nava",
        "screen_name" : "muranava",
        "indices" : [ 0, 9 ],
        "id_str" : "18602422",
        "id" : 18602422
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 10, 32 ],
        "url" : "http:\/\/t.co\/qi79tJ9uJ4",
        "expanded_url" : "http:\/\/lizzieserene.wordpress.com\/2013\/03\/15\/how-i-almost-won-an-argument-using-corpus-linguistics\/",
        "display_url" : "lizzieserene.wordpress.com\/2013\/03\/15\/how\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "312348741082415104",
    "in_reply_to_user_id" : 18602422,
    "text" : "@muranava http:\/\/t.co\/qi79tJ9uJ4 a blog post. ^^ (thanks)",
    "id" : 312348741082415104,
    "created_at" : "2013-03-14 23:45:17 +0000",
    "in_reply_to_screen_name" : "muranava",
    "in_reply_to_user_id_str" : "18602422",
    "user" : {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "protected" : false,
      "id_str" : "525013404",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766910187911405568\/zw3Ez5M0_normal.jpg",
      "id" : 525013404,
      "verified" : false
    }
  },
  "id" : 312356665326440448,
  "created_at" : "2013-03-15 00:16:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "312348741082415104",
  "geo" : { },
  "id_str" : "312356611983302656",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler dang just about to hit zzz and you write a great post! will comment",
  "id" : 312356611983302656,
  "in_reply_to_status_id" : 312348741082415104,
  "created_at" : "2013-03-15 00:16:34 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John T. Spencer",
      "screen_name" : "JohnTSpencer",
      "indices" : [ 0, 13 ],
      "id_str" : "2285706270",
      "id" : 2285706270
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "312337393275531264",
  "geo" : { },
  "id_str" : "312337858822275073",
  "in_reply_to_user_id" : 18389166,
  "text" : "@johntspencer ah somewhat aware that was happening recently :\/",
  "id" : 312337858822275073,
  "in_reply_to_status_id" : 312337393275531264,
  "created_at" : "2013-03-14 23:02:03 +0000",
  "in_reply_to_screen_name" : "spencerideas",
  "in_reply_to_user_id_str" : "18389166",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John T. Spencer",
      "screen_name" : "JohnTSpencer",
      "indices" : [ 0, 13 ],
      "id_str" : "2285706270",
      "id" : 2285706270
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "312334676058570752",
  "geo" : { },
  "id_str" : "312336999157747712",
  "in_reply_to_user_id" : 18389166,
  "text" : "@johntspencer a remarkable contrast; where are the two photos from?",
  "id" : 312336999157747712,
  "in_reply_to_status_id" : 312334676058570752,
  "created_at" : "2013-03-14 22:58:38 +0000",
  "in_reply_to_screen_name" : "spencerideas",
  "in_reply_to_user_id_str" : "18389166",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chadsansing",
      "screen_name" : "chadsansing",
      "indices" : [ 0, 12 ],
      "id_str" : "76810409",
      "id" : 76810409
    }, {
      "name" : "Paul Oh",
      "screen_name" : "poh",
      "indices" : [ 13, 17 ],
      "id_str" : "12892712",
      "id" : 12892712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "312331985513246721",
  "geo" : { },
  "id_str" : "312332946814169089",
  "in_reply_to_user_id" : 76810409,
  "text" : "@chadsansing @poh okay thgh unlikely!",
  "id" : 312332946814169089,
  "in_reply_to_status_id" : 312331985513246721,
  "created_at" : "2013-03-14 22:42:32 +0000",
  "in_reply_to_screen_name" : "chadsansing",
  "in_reply_to_user_id_str" : "76810409",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Cook",
      "screen_name" : "idc74",
      "indices" : [ 0, 6 ],
      "id_str" : "290521216",
      "id" : 290521216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312331662816063488",
  "in_reply_to_user_id" : 290521216,
  "text" : "@idc74 cheers for RT of latest post!",
  "id" : 312331662816063488,
  "created_at" : "2013-03-14 22:37:25 +0000",
  "in_reply_to_screen_name" : "idc74",
  "in_reply_to_user_id_str" : "290521216",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 15, 28 ],
      "id_str" : "88655243",
      "id" : 88655243
    }, {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 29, 41 ],
      "id_str" : "525013404",
      "id" : 525013404
    }, {
      "name" : "George Chilton",
      "screen_name" : "designerlessons",
      "indices" : [ 42, 58 ],
      "id_str" : "432090149",
      "id" : 432090149
    }, {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 59, 75 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312331489343832065",
  "text" : "belated thx to @rosemerebard @AnneHendler @designerlessons @michaelegriffin for likes on Building your own corpus posts, fab!",
  "id" : 312331489343832065,
  "created_at" : "2013-03-14 22:36:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 78, 86 ]
    }, {
      "text" : "eapchat",
      "indices" : [ 87, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/fWzIYzuLsN",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-rF",
      "display_url" : "wp.me\/pgHyE-rF"
    } ]
  },
  "geo" : { },
  "id_str" : "312327723966148609",
  "text" : "new post Building you own corpus - initial exploration http:\/\/t.co\/fWzIYzuLsN #eltchat #eapchat",
  "id" : 312327723966148609,
  "created_at" : "2013-03-14 22:21:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chadsansing",
      "screen_name" : "chadsansing",
      "indices" : [ 3, 15 ],
      "id_str" : "76810409",
      "id" : 76810409
    }, {
      "name" : "Paul Oh",
      "screen_name" : "poh",
      "indices" : [ 94, 98 ],
      "id_str" : "12892712",
      "id" : 12892712
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "engchat",
      "indices" : [ 99, 107 ]
    }, {
      "text" : "demcomp",
      "indices" : [ 108, 116 ]
    }, {
      "text" : "maketolearn",
      "indices" : [ 117, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/76ghU8pevB",
      "expanded_url" : "http:\/\/bit.ly\/15P7I1V",
      "display_url" : "bit.ly\/15P7I1V"
    } ]
  },
  "geo" : { },
  "id_str" : "312299804418007041",
  "text" : "RT @chadsansing: \"Toy hacking as differentiated vocab\" http:\/\/t.co\/76ghU8pevB this one is for @poh #engchat #demcomp #maketolearn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Paul Oh",
        "screen_name" : "poh",
        "indices" : [ 77, 81 ],
        "id_str" : "12892712",
        "id" : 12892712
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "engchat",
        "indices" : [ 82, 90 ]
      }, {
        "text" : "demcomp",
        "indices" : [ 91, 99 ]
      }, {
        "text" : "maketolearn",
        "indices" : [ 100, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 38, 60 ],
        "url" : "http:\/\/t.co\/76ghU8pevB",
        "expanded_url" : "http:\/\/bit.ly\/15P7I1V",
        "display_url" : "bit.ly\/15P7I1V"
      } ]
    },
    "geo" : { },
    "id_str" : "312291770123841537",
    "text" : "\"Toy hacking as differentiated vocab\" http:\/\/t.co\/76ghU8pevB this one is for @poh #engchat #demcomp #maketolearn",
    "id" : 312291770123841537,
    "created_at" : "2013-03-14 19:58:54 +0000",
    "user" : {
      "name" : "chadsansing",
      "screen_name" : "chadsansing",
      "protected" : false,
      "id_str" : "76810409",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712740640111652869\/NvEwLRy__normal.jpg",
      "id" : 76810409,
      "verified" : false
    }
  },
  "id" : 312299804418007041,
  "created_at" : "2013-03-14 20:30:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chadsansing",
      "screen_name" : "chadsansing",
      "indices" : [ 0, 12 ],
      "id_str" : "76810409",
      "id" : 76810409
    }, {
      "name" : "Paul Oh",
      "screen_name" : "poh",
      "indices" : [ 13, 17 ],
      "id_str" : "12892712",
      "id" : 12892712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "312291770123841537",
  "geo" : { },
  "id_str" : "312299763699687424",
  "in_reply_to_user_id" : 76810409,
  "text" : "@chadsansing @poh that's so amazingly wacky kids wld love it, wonder if it would work with ESL\/EFL learner? :)",
  "id" : 312299763699687424,
  "in_reply_to_status_id" : 312291770123841537,
  "created_at" : "2013-03-14 20:30:40 +0000",
  "in_reply_to_screen_name" : "chadsansing",
  "in_reply_to_user_id_str" : "76810409",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 0, 13 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "312243958094905344",
  "geo" : { },
  "id_str" : "312250026841755648",
  "in_reply_to_user_id" : 88655243,
  "text" : "@rosemerebard i have heard gd things about Messaging, need to get a copy! any reviews oif it that u know?",
  "id" : 312250026841755648,
  "in_reply_to_status_id" : 312243958094905344,
  "created_at" : "2013-03-14 17:13:02 +0000",
  "in_reply_to_screen_name" : "rosemerebard",
  "in_reply_to_user_id_str" : "88655243",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 0, 13 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "312231455826796544",
  "geo" : { },
  "id_str" : "312232614075457536",
  "in_reply_to_user_id" : 88655243,
  "text" : "@rosemerebard cheers Rose that is exactly what these series of posts is trying to encourage tchrs to do :)",
  "id" : 312232614075457536,
  "in_reply_to_status_id" : 312231455826796544,
  "created_at" : "2013-03-14 16:03:50 +0000",
  "in_reply_to_screen_name" : "rosemerebard",
  "in_reply_to_user_id_str" : "88655243",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 78, 86 ]
    }, {
      "text" : "eapchat",
      "indices" : [ 87, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/m6CuzsaJaA",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-r2",
      "display_url" : "wp.me\/pgHyE-r2"
    } ]
  },
  "geo" : { },
  "id_str" : "312229239594295296",
  "text" : "Building your own corpus - using general English lexis http:\/\/t.co\/m6CuzsaJaA #eltchat #eapchat",
  "id" : 312229239594295296,
  "created_at" : "2013-03-14 15:50:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luiz Otavio Barros",
      "screen_name" : "luizotavioELT",
      "indices" : [ 0, 14 ],
      "id_str" : "54798894",
      "id" : 54798894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "312214814229401600",
  "geo" : { },
  "id_str" : "312219388554129409",
  "in_reply_to_user_id" : 54798894,
  "text" : "@luizotavioELT nice meaty post, cheers :)",
  "id" : 312219388554129409,
  "in_reply_to_status_id" : 312214814229401600,
  "created_at" : "2013-03-14 15:11:17 +0000",
  "in_reply_to_screen_name" : "luizotavioELT",
  "in_reply_to_user_id_str" : "54798894",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luiz Otavio Barros",
      "screen_name" : "luizotavioELT",
      "indices" : [ 3, 17 ],
      "id_str" : "54798894",
      "id" : 54798894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/BOahDZ78gy",
      "expanded_url" : "http:\/\/tinyurl.com\/c9e9vo4",
      "display_url" : "tinyurl.com\/c9e9vo4"
    } ]
  },
  "geo" : { },
  "id_str" : "312219328978247681",
  "text" : "RT @luizotavioELT: Why does our students makes subject \/ verb agreement mistakes? 7 things to bear in mind.\nhttp:\/\/t.co\/BOahDZ78gy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/BOahDZ78gy",
        "expanded_url" : "http:\/\/tinyurl.com\/c9e9vo4",
        "display_url" : "tinyurl.com\/c9e9vo4"
      } ]
    },
    "geo" : { },
    "id_str" : "312214814229401600",
    "text" : "Why does our students makes subject \/ verb agreement mistakes? 7 things to bear in mind.\nhttp:\/\/t.co\/BOahDZ78gy",
    "id" : 312214814229401600,
    "created_at" : "2013-03-14 14:53:07 +0000",
    "user" : {
      "name" : "Luiz Otavio Barros",
      "screen_name" : "luizotavioELT",
      "protected" : false,
      "id_str" : "54798894",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2993483640\/18c26077182489c6d9f18ff232617587_normal.jpeg",
      "id" : 54798894,
      "verified" : false
    }
  },
  "id" : 312219328978247681,
  "created_at" : "2013-03-14 15:11:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chia Suan Chong",
      "screen_name" : "chiasuan",
      "indices" : [ 0, 9 ],
      "id_str" : "71588589",
      "id" : 71588589
    }, {
      "name" : "Oxford ELT",
      "screen_name" : "OUPELTGlobal",
      "indices" : [ 10, 23 ],
      "id_str" : "74177226",
      "id" : 74177226
    }, {
      "name" : "Oxford Dictionaries",
      "screen_name" : "OxfordWords",
      "indices" : [ 24, 36 ],
      "id_str" : "249150179",
      "id" : 249150179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "312213122054234112",
  "geo" : { },
  "id_str" : "312219195347701760",
  "in_reply_to_user_id" : 71588589,
  "text" : "@chiasuan @OUPELTGlobal @OxfordWords hehe blogorrhea :)",
  "id" : 312219195347701760,
  "in_reply_to_status_id" : 312213122054234112,
  "created_at" : "2013-03-14 15:10:31 +0000",
  "in_reply_to_screen_name" : "chiasuan",
  "in_reply_to_user_id_str" : "71588589",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsay Clandfield",
      "screen_name" : "lclandfield",
      "indices" : [ 3, 15 ],
      "id_str" : "30663558",
      "id" : 30663558
    }, {
      "name" : "Jonathan Acu\u00F1a",
      "screen_name" : "jonacuso",
      "indices" : [ 25, 34 ],
      "id_str" : "234014699",
      "id" : 234014699
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/Bvd5LEUWMG",
      "expanded_url" : "http:\/\/reflective-online-teaching.blogspot.com.es\/2013\/03\/teaching-sentence-patterns.html",
      "display_url" : "\u2026ctive-online-teaching.blogspot.com.es\/2013\/03\/teachi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "312196526216728576",
  "text" : "RT @lclandfield: Reading @jonacuso's blog this evening... as someone who teaches grammar to teachers I liked this piece http:\/\/t.co\/Bvd5 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jonathan Acu\u00F1a",
        "screen_name" : "jonacuso",
        "indices" : [ 8, 17 ],
        "id_str" : "234014699",
        "id" : 234014699
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/Bvd5LEUWMG",
        "expanded_url" : "http:\/\/reflective-online-teaching.blogspot.com.es\/2013\/03\/teaching-sentence-patterns.html",
        "display_url" : "\u2026ctive-online-teaching.blogspot.com.es\/2013\/03\/teachi\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "311134738796666880",
    "geo" : { },
    "id_str" : "311229200575119360",
    "in_reply_to_user_id" : 234014699,
    "text" : "Reading @jonacuso's blog this evening... as someone who teaches grammar to teachers I liked this piece http:\/\/t.co\/Bvd5LEUWMG",
    "id" : 311229200575119360,
    "in_reply_to_status_id" : 311134738796666880,
    "created_at" : "2013-03-11 21:36:38 +0000",
    "in_reply_to_screen_name" : "jonacuso",
    "in_reply_to_user_id_str" : "234014699",
    "user" : {
      "name" : "Lindsay Clandfield",
      "screen_name" : "lclandfield",
      "protected" : false,
      "id_str" : "30663558",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/688809343781830656\/NMU5P77B_normal.jpg",
      "id" : 30663558,
      "verified" : false
    }
  },
  "id" : 312196526216728576,
  "created_at" : "2013-03-14 13:40:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chia Suan Chong",
      "screen_name" : "chiasuan",
      "indices" : [ 0, 9 ],
      "id_str" : "71588589",
      "id" : 71588589
    }, {
      "name" : "Brad Patterson",
      "screen_name" : "Brad2Earth",
      "indices" : [ 10, 21 ],
      "id_str" : "504441263",
      "id" : 504441263
    }, {
      "name" : "Mike Hogan",
      "screen_name" : "irishmikeh",
      "indices" : [ 22, 33 ],
      "id_str" : "168228402",
      "id" : 168228402
    }, {
      "name" : "evanfrendo",
      "screen_name" : "evanfrendo",
      "indices" : [ 34, 45 ],
      "id_str" : "17589664",
      "id" : 17589664
    }, {
      "name" : "C Rebuffet-Broadus",
      "screen_name" : "RebuffetBroadus",
      "indices" : [ 46, 62 ],
      "id_str" : "22635290",
      "id" : 22635290
    }, {
      "name" : "Bethany Cagnol",
      "screen_name" : "bethcagnol",
      "indices" : [ 63, 74 ],
      "id_str" : "27641720",
      "id" : 27641720
    }, {
      "name" : "Vicky Loras",
      "screen_name" : "vickyloras",
      "indices" : [ 75, 86 ],
      "id_str" : "95957241",
      "id" : 95957241
    }, {
      "name" : "Sandy Millin",
      "screen_name" : "sandymillin",
      "indices" : [ 87, 99 ],
      "id_str" : "144236944",
      "id" : 144236944
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "312193360360255489",
  "geo" : { },
  "id_str" : "312195860316426241",
  "in_reply_to_user_id" : 71588589,
  "text" : "@chiasuan @Brad2Earth @irishmikeh @evanfrendo @RebuffetBroadus @bethcagnol @vickyloras @sandymillin lol was jesting but cool if she does :)",
  "id" : 312195860316426241,
  "in_reply_to_status_id" : 312193360360255489,
  "created_at" : "2013-03-14 13:37:48 +0000",
  "in_reply_to_screen_name" : "chiasuan",
  "in_reply_to_user_id_str" : "71588589",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ben goldacre",
      "screen_name" : "bengoldacre",
      "indices" : [ 3, 15 ],
      "id_str" : "6705042",
      "id" : 6705042
    }, {
      "name" : "DfE",
      "screen_name" : "educationgovuk",
      "indices" : [ 20, 35 ],
      "id_str" : "143039548",
      "id" : 143039548
    }, {
      "name" : "ben goldacre",
      "screen_name" : "bengoldacre",
      "indices" : [ 37, 49 ],
      "id_str" : "6705042",
      "id" : 6705042
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edures",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/zfhrty1fHo",
      "expanded_url" : "http:\/\/ow.ly\/iUK0E",
      "display_url" : "ow.ly\/iUK0E"
    } ]
  },
  "geo" : { },
  "id_str" : "312186115035631616",
  "text" : "RT @bengoldacre: MT @educationgovuk: @bengoldacre's report on how teaching can become a truly evidence based profession: http:\/\/t.co\/zfh ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "DfE",
        "screen_name" : "educationgovuk",
        "indices" : [ 3, 18 ],
        "id_str" : "143039548",
        "id" : 143039548
      }, {
        "name" : "ben goldacre",
        "screen_name" : "bengoldacre",
        "indices" : [ 20, 32 ],
        "id_str" : "6705042",
        "id" : 6705042
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "edures",
        "indices" : [ 127, 134 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/zfhrty1fHo",
        "expanded_url" : "http:\/\/ow.ly\/iUK0E",
        "display_url" : "ow.ly\/iUK0E"
      } ]
    },
    "geo" : { },
    "id_str" : "312156047777349632",
    "text" : "MT @educationgovuk: @bengoldacre's report on how teaching can become a truly evidence based profession: http:\/\/t.co\/zfhrty1fHo #edures",
    "id" : 312156047777349632,
    "created_at" : "2013-03-14 10:59:36 +0000",
    "user" : {
      "name" : "ben goldacre",
      "screen_name" : "bengoldacre",
      "protected" : false,
      "id_str" : "6705042",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/523118410419286016\/qXTUFTZR_normal.png",
      "id" : 6705042,
      "verified" : true
    }
  },
  "id" : 312186115035631616,
  "created_at" : "2013-03-14 12:59:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Patterson",
      "screen_name" : "Brad2Earth",
      "indices" : [ 0, 11 ],
      "id_str" : "504441263",
      "id" : 504441263
    }, {
      "name" : "Mike Hogan",
      "screen_name" : "irishmikeh",
      "indices" : [ 12, 23 ],
      "id_str" : "168228402",
      "id" : 168228402
    }, {
      "name" : "Chia Suan Chong",
      "screen_name" : "chiasuan",
      "indices" : [ 24, 33 ],
      "id_str" : "71588589",
      "id" : 71588589
    }, {
      "name" : "evanfrendo",
      "screen_name" : "evanfrendo",
      "indices" : [ 34, 45 ],
      "id_str" : "17589664",
      "id" : 17589664
    }, {
      "name" : "C Rebuffet-Broadus",
      "screen_name" : "RebuffetBroadus",
      "indices" : [ 46, 62 ],
      "id_str" : "22635290",
      "id" : 22635290
    }, {
      "name" : "Bethany Cagnol",
      "screen_name" : "bethcagnol",
      "indices" : [ 63, 74 ],
      "id_str" : "27641720",
      "id" : 27641720
    }, {
      "name" : "Vicky Loras",
      "screen_name" : "vickyloras",
      "indices" : [ 75, 86 ],
      "id_str" : "95957241",
      "id" : 95957241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "312165509665804288",
  "geo" : { },
  "id_str" : "312177276294950912",
  "in_reply_to_user_id" : 504441263,
  "text" : "@Brad2Earth @irishmikeh @chiasuan @evanfrendo @RebuffetBroadus @bethcagnol @vickyloras hey congrats! will there be tweeting on the day? ;)",
  "id" : 312177276294950912,
  "in_reply_to_status_id" : 312165509665804288,
  "created_at" : "2013-03-14 12:23:57 +0000",
  "in_reply_to_screen_name" : "Brad2Earth",
  "in_reply_to_user_id_str" : "504441263",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 82, 90 ]
    }, {
      "text" : "eapchat",
      "indices" : [ 91, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/fD9kLw7EOW",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-qB",
      "display_url" : "wp.me\/pgHyE-qB"
    } ]
  },
  "geo" : { },
  "id_str" : "312174799474532352",
  "text" : "new post Building your own corpus - First steps in AntConc http:\/\/t.co\/fD9kLw7EOW #eltchat #eapchat",
  "id" : 312174799474532352,
  "created_at" : "2013-03-14 12:14:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George Chilton",
      "screen_name" : "designerlessons",
      "indices" : [ 0, 16 ],
      "id_str" : "432090149",
      "id" : 432090149
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "311976724634140672",
  "geo" : { },
  "id_str" : "312163793734094848",
  "in_reply_to_user_id" : 432090149,
  "text" : "@designerlessons no worries, enjoyed yr inventive ways to get feedback frm sts :)",
  "id" : 312163793734094848,
  "in_reply_to_status_id" : 311976724634140672,
  "created_at" : "2013-03-14 11:30:22 +0000",
  "in_reply_to_screen_name" : "designerlessons",
  "in_reply_to_user_id_str" : "432090149",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 0, 11 ],
      "id_str" : "282659955",
      "id" : 282659955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "311910533160902656",
  "geo" : { },
  "id_str" : "312163614125588480",
  "in_reply_to_user_id" : 282659955,
  "text" : "@teflerinha lk fwd to more of these something differents :)",
  "id" : 312163614125588480,
  "in_reply_to_status_id" : 311910533160902656,
  "created_at" : "2013-03-14 11:29:39 +0000",
  "in_reply_to_screen_name" : "teflerinha",
  "in_reply_to_user_id_str" : "282659955",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Patsko",
      "screen_name" : "lauraahaha",
      "indices" : [ 0, 11 ],
      "id_str" : "97957137",
      "id" : 97957137
    }, {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "indices" : [ 12, 25 ],
      "id_str" : "1685397408",
      "id" : 1685397408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/KV1CtlUiqZ",
      "expanded_url" : "http:\/\/corpus.byu.edu\/coca\/?c=coca&q=21674999",
      "display_url" : "corpus.byu.edu\/coca\/?c=coca&q\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "311903765089361920",
  "geo" : { },
  "id_str" : "311905868755116032",
  "in_reply_to_user_id" : 97957137,
  "text" : "@lauraahaha @harrisonmike a holistic nearly 50 times as frequent as an holistic in COCA http:\/\/t.co\/KV1CtlUiqZ",
  "id" : 311905868755116032,
  "in_reply_to_status_id" : 311903765089361920,
  "created_at" : "2013-03-13 18:25:28 +0000",
  "in_reply_to_screen_name" : "lauraahaha",
  "in_reply_to_user_id_str" : "97957137",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Patsko",
      "screen_name" : "lauraahaha",
      "indices" : [ 0, 11 ],
      "id_str" : "97957137",
      "id" : 97957137
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "311904431291654144",
  "geo" : { },
  "id_str" : "311904719146737665",
  "in_reply_to_user_id" : 97957137,
  "text" : "@lauraahaha it took me 3 listens!",
  "id" : 311904719146737665,
  "in_reply_to_status_id" : 311904431291654144,
  "created_at" : "2013-03-13 18:20:54 +0000",
  "in_reply_to_screen_name" : "lauraahaha",
  "in_reply_to_user_id_str" : "97957137",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Patsko",
      "screen_name" : "lauraahaha",
      "indices" : [ 0, 11 ],
      "id_str" : "97957137",
      "id" : 97957137
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "311898433709539330",
  "geo" : { },
  "id_str" : "311904054043344896",
  "in_reply_to_user_id" : 97957137,
  "text" : "@lauraahaha well you know can you go by appearances because i didn't have a broken leg or a bad back, i had work related stress",
  "id" : 311904054043344896,
  "in_reply_to_status_id" : 311898433709539330,
  "created_at" : "2013-03-13 18:18:16 +0000",
  "in_reply_to_screen_name" : "lauraahaha",
  "in_reply_to_user_id_str" : "97957137",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 0, 11 ],
      "id_str" : "282659955",
      "id" : 282659955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "311888547479162880",
  "geo" : { },
  "id_str" : "311896592590450688",
  "in_reply_to_user_id" : 282659955,
  "text" : "@teflerinha nice summary recog task",
  "id" : 311896592590450688,
  "in_reply_to_status_id" : 311888547479162880,
  "created_at" : "2013-03-13 17:48:37 +0000",
  "in_reply_to_screen_name" : "teflerinha",
  "in_reply_to_user_id_str" : "282659955",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 3, 14 ],
      "id_str" : "282659955",
      "id" : 282659955
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 119, 127 ]
    }, {
      "text" : "ielts",
      "indices" : [ 128, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/syFMzaMTYt",
      "expanded_url" : "http:\/\/wp.me\/p2e2Wf-cA",
      "display_url" : "wp.me\/p2e2Wf-cA"
    } ]
  },
  "geo" : { },
  "id_str" : "311896000044347393",
  "text" : "RT @teflerinha: New post:The Science of Smiling : free downloadable lesson from ELT Resourceful http:\/\/t.co\/syFMzaMTYt #eltchat #ielts",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "eltchat",
        "indices" : [ 103, 111 ]
      }, {
        "text" : "ielts",
        "indices" : [ 112, 118 ]
      } ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/syFMzaMTYt",
        "expanded_url" : "http:\/\/wp.me\/p2e2Wf-cA",
        "display_url" : "wp.me\/p2e2Wf-cA"
      } ]
    },
    "geo" : { },
    "id_str" : "311888547479162880",
    "text" : "New post:The Science of Smiling : free downloadable lesson from ELT Resourceful http:\/\/t.co\/syFMzaMTYt #eltchat #ielts",
    "id" : 311888547479162880,
    "created_at" : "2013-03-13 17:16:38 +0000",
    "user" : {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "protected" : false,
      "id_str" : "282659955",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2149898907\/Rachael_Roberts_headshot_square_normal.jpg",
      "id" : 282659955,
      "verified" : false
    }
  },
  "id" : 311896000044347393,
  "created_at" : "2013-03-13 17:46:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate Bowles",
      "screen_name" : "KateMfD",
      "indices" : [ 3, 11 ],
      "id_str" : "379065166",
      "id" : 379065166
    }, {
      "name" : "David Kern\u24C4h\u24B6n",
      "screen_name" : "dkernohan",
      "indices" : [ 115, 125 ],
      "id_str" : "12219232",
      "id" : 12219232
    }, {
      "name" : "Richard Hall",
      "screen_name" : "HallyMk1",
      "indices" : [ 126, 135 ],
      "id_str" : "15023475",
      "id" : 15023475
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "highered",
      "indices" : [ 97, 106 ]
    }, {
      "text" : "moocs",
      "indices" : [ 107, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/kT3faPV6i4",
      "expanded_url" : "http:\/\/wp.me\/p1tYEb-Cq",
      "display_url" : "wp.me\/p1tYEb-Cq"
    } ]
  },
  "geo" : { },
  "id_str" : "311783846662270976",
  "text" : "RT @KateMfD: New post: Pearsons, the avalanche report, and stress sweat.  http:\/\/t.co\/kT3faPV6i4 #highered #moocs (@dkernohan @HallyMk1)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "David Kern\u24C4h\u24B6n",
        "screen_name" : "dkernohan",
        "indices" : [ 102, 112 ],
        "id_str" : "12219232",
        "id" : 12219232
      }, {
        "name" : "Richard Hall",
        "screen_name" : "HallyMk1",
        "indices" : [ 113, 122 ],
        "id_str" : "15023475",
        "id" : 15023475
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "highered",
        "indices" : [ 84, 93 ]
      }, {
        "text" : "moocs",
        "indices" : [ 94, 100 ]
      } ],
      "urls" : [ {
        "indices" : [ 61, 83 ],
        "url" : "http:\/\/t.co\/kT3faPV6i4",
        "expanded_url" : "http:\/\/wp.me\/p1tYEb-Cq",
        "display_url" : "wp.me\/p1tYEb-Cq"
      } ]
    },
    "geo" : { },
    "id_str" : "311782234828976128",
    "text" : "New post: Pearsons, the avalanche report, and stress sweat.  http:\/\/t.co\/kT3faPV6i4 #highered #moocs (@dkernohan @HallyMk1)",
    "id" : 311782234828976128,
    "created_at" : "2013-03-13 10:14:12 +0000",
    "user" : {
      "name" : "Kate Bowles",
      "screen_name" : "KateMfD",
      "protected" : false,
      "id_str" : "379065166",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1557363696\/Screen_shot_2011-09-24_at_7.36.20_PM_normal.png",
      "id" : 379065166,
      "verified" : false
    }
  },
  "id" : 311783846662270976,
  "created_at" : "2013-03-13 10:20:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chadsansing",
      "screen_name" : "chadsansing",
      "indices" : [ 3, 15 ],
      "id_str" : "76810409",
      "id" : 76810409
    }, {
      "name" : "Andrew Carle",
      "screen_name" : "tieandjeans",
      "indices" : [ 95, 107 ],
      "id_str" : "83852241",
      "id" : 83852241
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "badges",
      "indices" : [ 29, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/JSYRFkQsYx",
      "expanded_url" : "http:\/\/bit.ly\/Zz8hYc",
      "display_url" : "bit.ly\/Zz8hYc"
    } ]
  },
  "geo" : { },
  "id_str" : "311779910559625216",
  "text" : "RT @chadsansing: we are in a #badges lull; pondering why as i read http:\/\/t.co\/JSYRFkQsYx from @tieandjeans",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Carle",
        "screen_name" : "tieandjeans",
        "indices" : [ 78, 90 ],
        "id_str" : "83852241",
        "id" : 83852241
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "badges",
        "indices" : [ 12, 19 ]
      } ],
      "urls" : [ {
        "indices" : [ 50, 72 ],
        "url" : "http:\/\/t.co\/JSYRFkQsYx",
        "expanded_url" : "http:\/\/bit.ly\/Zz8hYc",
        "display_url" : "bit.ly\/Zz8hYc"
      } ]
    },
    "geo" : { },
    "id_str" : "311778086066733056",
    "text" : "we are in a #badges lull; pondering why as i read http:\/\/t.co\/JSYRFkQsYx from @tieandjeans",
    "id" : 311778086066733056,
    "created_at" : "2013-03-13 09:57:42 +0000",
    "user" : {
      "name" : "chadsansing",
      "screen_name" : "chadsansing",
      "protected" : false,
      "id_str" : "76810409",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712740640111652869\/NvEwLRy__normal.jpg",
      "id" : 76810409,
      "verified" : false
    }
  },
  "id" : 311779910559625216,
  "created_at" : "2013-03-13 10:04:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George Chilton",
      "screen_name" : "designerlessons",
      "indices" : [ 3, 19 ],
      "id_str" : "432090149",
      "id" : 432090149
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 129, 133 ]
    }, {
      "text" : "TEFL",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "TDsig",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/aJRd2lYqkY",
      "expanded_url" : "http:\/\/wp.me\/P235qa-2u",
      "display_url" : "wp.me\/P235qa-2u"
    } ]
  },
  "geo" : { },
  "id_str" : "311772067815124992",
  "text" : "RT @designerlessons: How are you really doing? This is a post about getting feedback from your students.  http:\/\/t.co\/aJRd2lYqkY #elt #T ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "elt",
        "indices" : [ 108, 112 ]
      }, {
        "text" : "TEFL",
        "indices" : [ 113, 118 ]
      }, {
        "text" : "TDsig",
        "indices" : [ 119, 125 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/aJRd2lYqkY",
        "expanded_url" : "http:\/\/wp.me\/P235qa-2u",
        "display_url" : "wp.me\/P235qa-2u"
      } ]
    },
    "geo" : { },
    "id_str" : "311756017899819009",
    "text" : "How are you really doing? This is a post about getting feedback from your students.  http:\/\/t.co\/aJRd2lYqkY #elt #TEFL #TDsig",
    "id" : 311756017899819009,
    "created_at" : "2013-03-13 08:30:01 +0000",
    "user" : {
      "name" : "George Chilton",
      "screen_name" : "designerlessons",
      "protected" : false,
      "id_str" : "432090149",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/468158165914501121\/aHVWzkwG_normal.jpeg",
      "id" : 432090149,
      "verified" : false
    }
  },
  "id" : 311772067815124992,
  "created_at" : "2013-03-13 09:33:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 0, 11 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "311738751716044800",
  "geo" : { },
  "id_str" : "311761749361709056",
  "in_reply_to_user_id" : 87902543,
  "text" : "@tornhalves thanks!",
  "id" : 311761749361709056,
  "in_reply_to_status_id" : 311738751716044800,
  "created_at" : "2013-03-13 08:52:47 +0000",
  "in_reply_to_screen_name" : "tornhalves",
  "in_reply_to_user_id_str" : "87902543",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Wheeler",
      "screen_name" : "timbuckteeth",
      "indices" : [ 0, 13 ],
      "id_str" : "11435832",
      "id" : 11435832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "311719613777993728",
  "geo" : { },
  "id_str" : "311761491676233728",
  "in_reply_to_user_id" : 11435832,
  "text" : "@timbuckteeth grt lk fwd to it :)",
  "id" : 311761491676233728,
  "in_reply_to_status_id" : 311719613777993728,
  "created_at" : "2013-03-13 08:51:46 +0000",
  "in_reply_to_screen_name" : "timbuckteeth",
  "in_reply_to_user_id_str" : "11435832",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Wheeler",
      "screen_name" : "timbuckteeth",
      "indices" : [ 0, 13 ],
      "id_str" : "11435832",
      "id" : 11435832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "311616689131368448",
  "geo" : { },
  "id_str" : "311637785696145408",
  "in_reply_to_user_id" : 11435832,
  "text" : "@timbuckteeth minimally invasive questioning? :\/",
  "id" : 311637785696145408,
  "in_reply_to_status_id" : 311616689131368448,
  "created_at" : "2013-03-13 00:40:12 +0000",
  "in_reply_to_screen_name" : "timbuckteeth",
  "in_reply_to_user_id_str" : "11435832",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 60, 76 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/BkpTeDUvXm",
      "expanded_url" : "http:\/\/wp.me\/p1oNHf-7t",
      "display_url" : "wp.me\/p1oNHf-7t"
    } ]
  },
  "geo" : { },
  "id_str" : "311581625580392451",
  "text" : "Storytelling at TESOL Spain 2013 http:\/\/t.co\/BkpTeDUvXm via @wordpressdotcom",
  "id" : 311581625580392451,
  "created_at" : "2013-03-12 20:57:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate Bowles",
      "screen_name" : "KateMfD",
      "indices" : [ 3, 11 ],
      "id_str" : "379065166",
      "id" : 379065166
    }, {
      "name" : "Xeni Jardin \uD83E\uDD84",
      "screen_name" : "xeni",
      "indices" : [ 16, 21 ],
      "id_str" : "767",
      "id" : 767
    }, {
      "name" : "Glenn Greenwald",
      "screen_name" : "ggreenwald",
      "indices" : [ 23, 34 ],
      "id_str" : "16076032",
      "id" : 16076032
    }, {
      "name" : "Boing Boing",
      "screen_name" : "BoingBoing",
      "indices" : [ 114, 125 ],
      "id_str" : "5971922",
      "id" : 5971922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/mv7KhkVJoP",
      "expanded_url" : "http:\/\/www.guardian.co.uk\/commentisfree\/2013\/mar\/12\/bradley-manning-tapes-own-words",
      "display_url" : "guardian.co.uk\/commentisfree\/\u2026"
    }, {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/VEpC0rZWan",
      "expanded_url" : "http:\/\/boingboing.net\/2013\/03\/12\/leaked-audio-of-bradley-mannin.html",
      "display_url" : "boingboing.net\/2013\/03\/12\/lea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "311578048329822209",
  "text" : "RT @KateMfD: RT @xeni: @ggreenwald: \"It is way past time for Manning's voice to be heard.\" http:\/\/t.co\/mv7KhkVJoP @boingboing http:\/\/t.c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Xeni Jardin \uD83E\uDD84",
        "screen_name" : "xeni",
        "indices" : [ 3, 8 ],
        "id_str" : "767",
        "id" : 767
      }, {
        "name" : "Glenn Greenwald",
        "screen_name" : "ggreenwald",
        "indices" : [ 10, 21 ],
        "id_str" : "16076032",
        "id" : 16076032
      }, {
        "name" : "Boing Boing",
        "screen_name" : "BoingBoing",
        "indices" : [ 101, 112 ],
        "id_str" : "5971922",
        "id" : 5971922
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/mv7KhkVJoP",
        "expanded_url" : "http:\/\/www.guardian.co.uk\/commentisfree\/2013\/mar\/12\/bradley-manning-tapes-own-words",
        "display_url" : "guardian.co.uk\/commentisfree\/\u2026"
      }, {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/VEpC0rZWan",
        "expanded_url" : "http:\/\/boingboing.net\/2013\/03\/12\/leaked-audio-of-bradley-mannin.html",
        "display_url" : "boingboing.net\/2013\/03\/12\/lea\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "311498890681675776",
    "text" : "RT @xeni: @ggreenwald: \"It is way past time for Manning's voice to be heard.\" http:\/\/t.co\/mv7KhkVJoP @boingboing http:\/\/t.co\/VEpC0rZWan",
    "id" : 311498890681675776,
    "created_at" : "2013-03-12 15:28:17 +0000",
    "user" : {
      "name" : "Kate Bowles",
      "screen_name" : "KateMfD",
      "protected" : false,
      "id_str" : "379065166",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1557363696\/Screen_shot_2011-09-24_at_7.36.20_PM_normal.png",
      "id" : 379065166,
      "verified" : false
    }
  },
  "id" : 311578048329822209,
  "created_at" : "2013-03-12 20:42:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 0, 11 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "311557879352139776",
  "geo" : { },
  "id_str" : "311567930313830402",
  "in_reply_to_user_id" : 87902543,
  "text" : "@tornhalves hehe no idea what it could mean though.",
  "id" : 311567930313830402,
  "in_reply_to_status_id" : 311557879352139776,
  "created_at" : "2013-03-12 20:02:37 +0000",
  "in_reply_to_screen_name" : "tornhalves",
  "in_reply_to_user_id_str" : "87902543",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 0, 11 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "311416013822509056",
  "geo" : { },
  "id_str" : "311551398196178944",
  "in_reply_to_user_id" : 87902543,
  "text" : "@tornhalves nihilism of ed-materials biz - a great title for a blog post! :)",
  "id" : 311551398196178944,
  "in_reply_to_status_id" : 311416013822509056,
  "created_at" : "2013-03-12 18:56:56 +0000",
  "in_reply_to_screen_name" : "tornhalves",
  "in_reply_to_user_id_str" : "87902543",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hancock McDonald ELT",
      "screen_name" : "HancockMcDonald",
      "indices" : [ 0, 16 ],
      "id_str" : "552929354",
      "id" : 552929354
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/x7oYAIUYun",
      "expanded_url" : "http:\/\/elllo.org",
      "display_url" : "elllo.org"
    } ]
  },
  "in_reply_to_status_id_str" : "311452520629284865",
  "geo" : { },
  "id_str" : "311510726927872000",
  "in_reply_to_user_id" : 552929354,
  "text" : "@HancockMcDonald typo for http:\/\/t.co\/x7oYAIUYun i always do that with this site!",
  "id" : 311510726927872000,
  "in_reply_to_status_id" : 311452520629284865,
  "created_at" : "2013-03-12 16:15:19 +0000",
  "in_reply_to_screen_name" : "HancockMcDonald",
  "in_reply_to_user_id_str" : "552929354",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hancock McDonald ELT",
      "screen_name" : "HancockMcDonald",
      "indices" : [ 3, 19 ],
      "id_str" : "552929354",
      "id" : 552929354
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tesolspain",
      "indices" : [ 106, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/LffocmkZd4",
      "expanded_url" : "http:\/\/tinyurl.com\/cnbhlf4",
      "display_url" : "tinyurl.com\/cnbhlf4"
    } ]
  },
  "geo" : { },
  "id_str" : "311510131521245185",
  "text" : "RT @HancockMcDonald: Genre\/discourse analysis for primary kids? You bet! Claire Azevedo's semi-plenary at #tesolspain http:\/\/t.co\/LffocmkZd4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tesolspain",
        "indices" : [ 85, 96 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/LffocmkZd4",
        "expanded_url" : "http:\/\/tinyurl.com\/cnbhlf4",
        "display_url" : "tinyurl.com\/cnbhlf4"
      } ]
    },
    "geo" : { },
    "id_str" : "311453160696868865",
    "text" : "Genre\/discourse analysis for primary kids? You bet! Claire Azevedo's semi-plenary at #tesolspain http:\/\/t.co\/LffocmkZd4",
    "id" : 311453160696868865,
    "created_at" : "2013-03-12 12:26:34 +0000",
    "user" : {
      "name" : "Hancock McDonald ELT",
      "screen_name" : "HancockMcDonald",
      "protected" : false,
      "id_str" : "552929354",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2158919436\/HM_portrait_normal.jpg",
      "id" : 552929354,
      "verified" : false
    }
  },
  "id" : 311510131521245185,
  "created_at" : "2013-03-12 16:12:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hancock McDonald ELT",
      "screen_name" : "HancockMcDonald",
      "indices" : [ 3, 19 ],
      "id_str" : "552929354",
      "id" : 552929354
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tesolspain",
      "indices" : [ 77, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/F5bOjLSApo",
      "expanded_url" : "http:\/\/tinyurl.com\/c5247ho",
      "display_url" : "tinyurl.com\/c5247ho"
    } ]
  },
  "geo" : { },
  "id_str" : "311509505609433088",
  "text" : "RT @HancockMcDonald: Robin Walker on technology in pronunciation teaching at #tesolspain http:\/\/t.co\/F5bOjLSApo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tesolspain",
        "indices" : [ 56, 67 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/F5bOjLSApo",
        "expanded_url" : "http:\/\/tinyurl.com\/c5247ho",
        "display_url" : "tinyurl.com\/c5247ho"
      } ]
    },
    "geo" : { },
    "id_str" : "311452520629284865",
    "text" : "Robin Walker on technology in pronunciation teaching at #tesolspain http:\/\/t.co\/F5bOjLSApo",
    "id" : 311452520629284865,
    "created_at" : "2013-03-12 12:24:02 +0000",
    "user" : {
      "name" : "Hancock McDonald ELT",
      "screen_name" : "HancockMcDonald",
      "protected" : false,
      "id_str" : "552929354",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2158919436\/HM_portrait_normal.jpg",
      "id" : 552929354,
      "verified" : false
    }
  },
  "id" : 311509505609433088,
  "created_at" : "2013-03-12 16:10:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Sketchley",
      "screen_name" : "ELTExperiences",
      "indices" : [ 0, 15 ],
      "id_str" : "22779473",
      "id" : 22779473
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/2MYfRtxy80",
      "expanded_url" : "http:\/\/corpus.byu.edu\/coca\/?c=coca&q=21646245",
      "display_url" : "corpus.byu.edu\/coca\/?c=coca&q\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "311419532436705280",
  "geo" : { },
  "id_str" : "311508236178169856",
  "in_reply_to_user_id" : 22779473,
  "text" : "@ELTExperiences cld help? http:\/\/t.co\/2MYfRtxy80 e.g. passive form is most frequent, followed by find.",
  "id" : 311508236178169856,
  "in_reply_to_status_id" : 311419532436705280,
  "created_at" : "2013-03-12 16:05:25 +0000",
  "in_reply_to_screen_name" : "ELTExperiences",
  "in_reply_to_user_id_str" : "22779473",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sirja",
      "screen_name" : "swisssirja",
      "indices" : [ 3, 14 ],
      "id_str" : "363694777",
      "id" : 363694777
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/oisS5k23ac",
      "expanded_url" : "http:\/\/wp.me\/p33cOf-1p",
      "display_url" : "wp.me\/p33cOf-1p"
    } ]
  },
  "geo" : { },
  "id_str" : "311480919393443841",
  "text" : "RT @swisssirja: What can native speakers learn from Big Bang Theory? Check it out ;-) http:\/\/t.co\/oisS5k23ac via @MattHalsdorff",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/oisS5k23ac",
        "expanded_url" : "http:\/\/wp.me\/p33cOf-1p",
        "display_url" : "wp.me\/p33cOf-1p"
      } ]
    },
    "geo" : { },
    "id_str" : "311479410127683584",
    "text" : "What can native speakers learn from Big Bang Theory? Check it out ;-) http:\/\/t.co\/oisS5k23ac via @MattHalsdorff",
    "id" : 311479410127683584,
    "created_at" : "2013-03-12 14:10:53 +0000",
    "user" : {
      "name" : "sirja",
      "screen_name" : "swisssirja",
      "protected" : false,
      "id_str" : "363694777",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1517463960\/049_normal.jpg",
      "id" : 363694777,
      "verified" : false
    }
  },
  "id" : 311480919393443841,
  "created_at" : "2013-03-12 14:16:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 0, 14 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "311228401463730177",
  "geo" : { },
  "id_str" : "311236155867811840",
  "in_reply_to_user_id" : 25388528,
  "text" : "@audreywatters were not intelli tut sys grown out of  psychometric testing in that .mil era ? :\/",
  "id" : 311236155867811840,
  "in_reply_to_status_id" : 311228401463730177,
  "created_at" : "2013-03-11 22:04:16 +0000",
  "in_reply_to_screen_name" : "audreywatters",
  "in_reply_to_user_id_str" : "25388528",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Mearns",
      "screen_name" : "davidmearns",
      "indices" : [ 0, 12 ],
      "id_str" : "30931681",
      "id" : 30931681
    }, {
      "name" : "Graham Chandler",
      "screen_name" : "gnc957",
      "indices" : [ 107, 114 ],
      "id_str" : "504959994",
      "id" : 504959994
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/C2WZj14EGT",
      "expanded_url" : "http:\/\/www.reading.ac.uk\/internal\/engageinfeedback\/EFB-Home.aspx",
      "display_url" : "reading.ac.uk\/internal\/engag\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "311204881434284036",
  "geo" : { },
  "id_str" : "311230240166916096",
  "in_reply_to_user_id" : 30931681,
  "text" : "@davidmearns  int results u got, have u seen this website on feedback resources http:\/\/t.co\/C2WZj14EGT  HT @gnc957",
  "id" : 311230240166916096,
  "in_reply_to_status_id" : 311204881434284036,
  "created_at" : "2013-03-11 21:40:46 +0000",
  "in_reply_to_screen_name" : "davidmearns",
  "in_reply_to_user_id_str" : "30931681",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luiz Otavio Barros",
      "screen_name" : "luizotavioELT",
      "indices" : [ 3, 17 ],
      "id_str" : "54798894",
      "id" : 54798894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/WaiOdHvYcw",
      "expanded_url" : "http:\/\/tinyurl.com\/a768jf6",
      "display_url" : "tinyurl.com\/a768jf6"
    } ]
  },
  "geo" : { },
  "id_str" : "311228732633399296",
  "text" : "RT @luizotavioELT: If u thought inversions were only used in formal English, this guest post by R.Barros will surprise you.http:\/\/t.co\/W ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/WaiOdHvYcw",
        "expanded_url" : "http:\/\/tinyurl.com\/a768jf6",
        "display_url" : "tinyurl.com\/a768jf6"
      } ]
    },
    "geo" : { },
    "id_str" : "311138895771344896",
    "text" : "If u thought inversions were only used in formal English, this guest post by R.Barros will surprise you.http:\/\/t.co\/WaiOdHvYcw @ricm_barros",
    "id" : 311138895771344896,
    "created_at" : "2013-03-11 15:37:48 +0000",
    "user" : {
      "name" : "Luiz Otavio Barros",
      "screen_name" : "luizotavioELT",
      "protected" : false,
      "id_str" : "54798894",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2993483640\/18c26077182489c6d9f18ff232617587_normal.jpeg",
      "id" : 54798894,
      "verified" : false
    }
  },
  "id" : 311228732633399296,
  "created_at" : "2013-03-11 21:34:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 61, 72 ],
      "id_str" : "87902543",
      "id" : 87902543
    }, {
      "name" : "stevemuir",
      "screen_name" : "steve_muir",
      "indices" : [ 109, 120 ],
      "id_str" : "18537988",
      "id" : 18537988
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 97, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/k6oGYx6Hgt",
      "expanded_url" : "http:\/\/www.fullspate.net\/efl-worksheets.html",
      "display_url" : "fullspate.net\/efl-worksheets\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "311221747489832961",
  "text" : "just found this set of v int adv level worksheets by i think @tornhalves? http:\/\/t.co\/k6oGYx6Hgt #eltchat cc @steve_muir",
  "id" : 311221747489832961,
  "created_at" : "2013-03-11 21:07:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate Bowles",
      "screen_name" : "KateMfD",
      "indices" : [ 3, 11 ],
      "id_str" : "379065166",
      "id" : 379065166
    }, {
      "name" : "Donald Clark",
      "screen_name" : "DonaldClark",
      "indices" : [ 31, 43 ],
      "id_str" : "1632891",
      "id" : 1632891
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edtech",
      "indices" : [ 84, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/2AD6dpB5t3",
      "expanded_url" : "http:\/\/dlvr.it\/342LqF",
      "display_url" : "dlvr.it\/342LqF"
    } ]
  },
  "geo" : { },
  "id_str" : "311163073815773185",
  "text" : "RT @KateMfD: This, this, this: @DonaldClark on educational colonialists parachuting #edtech solutions in to the underserved: http:\/\/t.co ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Donald Clark",
        "screen_name" : "DonaldClark",
        "indices" : [ 18, 30 ],
        "id_str" : "1632891",
        "id" : 1632891
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "edtech",
        "indices" : [ 71, 78 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/2AD6dpB5t3",
        "expanded_url" : "http:\/\/dlvr.it\/342LqF",
        "display_url" : "dlvr.it\/342LqF"
      } ]
    },
    "geo" : { },
    "id_str" : "311157136405184512",
    "text" : "This, this, this: @DonaldClark on educational colonialists parachuting #edtech solutions in to the underserved: http:\/\/t.co\/2AD6dpB5t3",
    "id" : 311157136405184512,
    "created_at" : "2013-03-11 16:50:16 +0000",
    "user" : {
      "name" : "Kate Bowles",
      "screen_name" : "KateMfD",
      "protected" : false,
      "id_str" : "379065166",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1557363696\/Screen_shot_2011-09-24_at_7.36.20_PM_normal.png",
      "id" : 379065166,
      "verified" : false
    }
  },
  "id" : 311163073815773185,
  "created_at" : "2013-03-11 17:13:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "311119308296163329",
  "geo" : { },
  "id_str" : "311124963367211009",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan look forward to it, be gentle! :)",
  "id" : 311124963367211009,
  "in_reply_to_status_id" : 311119308296163329,
  "created_at" : "2013-03-11 14:42:26 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "311121277224103936",
  "geo" : { },
  "id_str" : "311124828751011840",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson looking out for delta posts might encourage me to have a go ;) you doing part time distance?",
  "id" : 311124828751011840,
  "in_reply_to_status_id" : 311121277224103936,
  "created_at" : "2013-03-11 14:41:54 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mieke Kenis",
      "screen_name" : "mkofab",
      "indices" : [ 0, 7 ],
      "id_str" : "96527212",
      "id" : 96527212
    }, {
      "name" : "British Council",
      "screen_name" : "BritishCouncil",
      "indices" : [ 8, 23 ],
      "id_str" : "14732889",
      "id" : 14732889
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/uWH5H1KLWr",
      "expanded_url" : "http:\/\/statistics.about.com\/od\/Inferential-Statistics\/a\/How-To-Calculate-The-Margin-Of-Error.htm",
      "display_url" : "statistics.about.com\/od\/Inferential\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "311071618883543041",
  "geo" : { },
  "id_str" : "311123024793440258",
  "in_reply_to_user_id" : 96527212,
  "text" : "@mkofab @BritishCouncil int, any info on error margins? seems about 5% using total sample(n=367) and 95% CI?http:\/\/t.co\/uWH5H1KLWr \u2026",
  "id" : 311123024793440258,
  "in_reply_to_status_id" : 311071618883543041,
  "created_at" : "2013-03-11 14:34:44 +0000",
  "in_reply_to_screen_name" : "mkofab",
  "in_reply_to_user_id_str" : "96527212",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 45, 60 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/Wlm5B4gwLA",
      "expanded_url" : "http:\/\/www.eltsquared.co.uk\/delta-diary-week-1\/",
      "display_url" : "eltsquared.co.uk\/delta-diary-we\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "311110789916422145",
  "text" : "DELTA diary week 1 http:\/\/t.co\/Wlm5B4gwLA by @MrChrisJWilson",
  "id" : 311110789916422145,
  "created_at" : "2013-03-11 13:46:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "311106134205427713",
  "geo" : { },
  "id_str" : "311110000837791744",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson France ok. tgh i did notice trouble when connecting from inside big uni LAN.",
  "id" : 311110000837791744,
  "in_reply_to_status_id" : 311106134205427713,
  "created_at" : "2013-03-11 13:42:59 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    }, {
      "name" : "webmonkey",
      "screen_name" : "webmonkey",
      "indices" : [ 38, 48 ],
      "id_str" : "14288386",
      "id" : 14288386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/BqAVZxq4ov",
      "expanded_url" : "https:\/\/twitter.com\/webmonkey\/status\/297337524039323650",
      "display_url" : "twitter.com\/webmonkey\/stat\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "311101933328936960",
  "geo" : { },
  "id_str" : "311109564848287744",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler hehe that refers to this @webmonkey tweet an xkcd comic link https:\/\/t.co\/BqAVZxq4ov",
  "id" : 311109564848287744,
  "in_reply_to_status_id" : 311101933328936960,
  "created_at" : "2013-03-11 13:41:15 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311101278396747776",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler cheers for RT of post, have a good w\/k.",
  "id" : 311101278396747776,
  "created_at" : "2013-03-11 13:08:19 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 89, 97 ]
    }, {
      "text" : "eapchat",
      "indices" : [ 98, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/LgIvYDW1ES",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-qg",
      "display_url" : "wp.me\/pgHyE-qg"
    } ]
  },
  "geo" : { },
  "id_str" : "311099207828271104",
  "text" : "3rd building your own corpus post - cleaning up your text file(s) http:\/\/t.co\/LgIvYDW1ES #eltchat #eapchat",
  "id" : 311099207828271104,
  "created_at" : "2013-03-11 13:00:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309439655525359618",
  "geo" : { },
  "id_str" : "310919744188473344",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson thx for mention on yr last ELT weekly Chris",
  "id" : 310919744188473344,
  "in_reply_to_status_id" : 309439655525359618,
  "created_at" : "2013-03-11 01:06:58 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Sample",
      "screen_name" : "samplereality",
      "indices" : [ 0, 14 ],
      "id_str" : "8497292",
      "id" : 8497292
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "310864794720808960",
  "geo" : { },
  "id_str" : "310914071069347841",
  "in_reply_to_user_id" : 8497292,
  "text" : "@samplereality very speculative but very thought provoking, thx",
  "id" : 310914071069347841,
  "in_reply_to_status_id" : 310864794720808960,
  "created_at" : "2013-03-11 00:44:25 +0000",
  "in_reply_to_screen_name" : "samplereality",
  "in_reply_to_user_id_str" : "8497292",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Sample",
      "screen_name" : "samplereality",
      "indices" : [ 3, 17 ],
      "id_str" : "8497292",
      "id" : 8497292
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/WsuQ1wzpqv",
      "expanded_url" : "http:\/\/www.samplereality.com\/2013\/03\/10\/from-a-murmur-to-a-drone\/",
      "display_url" : "samplereality.com\/2013\/03\/10\/fro\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "310913843473813504",
  "text" : "RT @samplereality: \"From a Murmur to a Drone\" - a speculative post by me about things that fly http:\/\/t.co\/WsuQ1wzpqv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.metrotwit.com\/\" rel=\"nofollow\"\u003EMetroTwit\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/WsuQ1wzpqv",
        "expanded_url" : "http:\/\/www.samplereality.com\/2013\/03\/10\/from-a-murmur-to-a-drone\/",
        "display_url" : "samplereality.com\/2013\/03\/10\/fro\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "310864794720808960",
    "text" : "\"From a Murmur to a Drone\" - a speculative post by me about things that fly http:\/\/t.co\/WsuQ1wzpqv",
    "id" : 310864794720808960,
    "created_at" : "2013-03-10 21:28:37 +0000",
    "user" : {
      "name" : "Mark Sample",
      "screen_name" : "samplereality",
      "protected" : false,
      "id_str" : "8497292",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000707852410\/a86167716ecb748acc89638ad165a162_normal.jpeg",
      "id" : 8497292,
      "verified" : false
    }
  },
  "id" : 310913843473813504,
  "created_at" : "2013-03-11 00:43:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 94, 105 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/t88mSrAnJi",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-pU",
      "display_url" : "wp.me\/pgHyE-pU"
    }, {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/tBC7HlUgJh",
      "expanded_url" : "http:\/\/leoxicon.blogspot.fr\/2013\/03\/binomials.html",
      "display_url" : "leoxicon.blogspot.fr\/2013\/03\/binomi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "310906845277597697",
  "text" : "new post Building your own corpus - binomials example http:\/\/t.co\/t88mSrAnJi mke sure to read @leoselivan http:\/\/t.co\/tBC7HlUgJh first :)",
  "id" : 310906845277597697,
  "created_at" : "2013-03-11 00:15:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Digital Play",
      "screen_name" : "eltdigitalplay",
      "indices" : [ 0, 15 ],
      "id_str" : "67682458",
      "id" : 67682458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/klvLLMltRM",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-2H",
      "display_url" : "wp.me\/pgHyE-2H"
    } ]
  },
  "in_reply_to_status_id_str" : "309850920311734272",
  "geo" : { },
  "id_str" : "310439857543598081",
  "in_reply_to_user_id" : 67682458,
  "text" : "@eltdigitalplay sts love to explore it have used it a lot e.g. http:\/\/t.co\/klvLLMltRM, like yr question making take on it",
  "id" : 310439857543598081,
  "in_reply_to_status_id" : 309850920311734272,
  "created_at" : "2013-03-09 17:20:04 +0000",
  "in_reply_to_screen_name" : "eltdigitalplay",
  "in_reply_to_user_id_str" : "67682458",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 3, 17 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "webwise",
      "indices" : [ 66, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/IuHChwxiRT",
      "expanded_url" : "http:\/\/hackeducation.com\/2013\/03\/08\/whose-learning-is-it-anyway-webwise-2013\/",
      "display_url" : "hackeducation.com\/2013\/03\/08\/who\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "310371090289532929",
  "text" : "RT @audreywatters: Notes, tweets, slides from my keynote today at #webwise - \"Whose Learning Is It Anyway?\" http:\/\/t.co\/IuHChwxiRT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "webwise",
        "indices" : [ 47, 55 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/IuHChwxiRT",
        "expanded_url" : "http:\/\/hackeducation.com\/2013\/03\/08\/whose-learning-is-it-anyway-webwise-2013\/",
        "display_url" : "hackeducation.com\/2013\/03\/08\/who\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "310252519966269440",
    "text" : "Notes, tweets, slides from my keynote today at #webwise - \"Whose Learning Is It Anyway?\" http:\/\/t.co\/IuHChwxiRT",
    "id" : 310252519966269440,
    "created_at" : "2013-03-09 04:55:39 +0000",
    "user" : {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "protected" : false,
      "id_str" : "25388528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711668009723498496\/pauFZsdv_normal.jpg",
      "id" : 25388528,
      "verified" : false
    }
  },
  "id" : 310371090289532929,
  "created_at" : "2013-03-09 12:46:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 0, 11 ],
      "id_str" : "87902543",
      "id" : 87902543
    }, {
      "name" : "markwarschauer",
      "screen_name" : "markwarschauer",
      "indices" : [ 31, 46 ],
      "id_str" : "17316060",
      "id" : 17316060
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/T0X8DbiiCt",
      "expanded_url" : "http:\/\/www.google.fr\/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&ved=0CDUQFjAA&url=ftp%3A%2F%2F195.214.211.1%2Fbooks%2FDVD-028%2FWarschauer_M._Technology_and_Social_Inclusion%5Bc%5D_Rethinking_the_Digital_Divide_(2003)(en)(272s).pdf&ei=2iI7Ufb0HcGR7AaetICYDQ&usg=AFQjCNFSOrQR0QKl_G9tPSeYs79MHLG6lg&sig2=Op0Onk4owst1Jhux3vBygw&bvm=bv.43287494,d.ZGU&cad=rja",
      "display_url" : "google.fr\/url?sa=t&rct=j\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "310347414076796928",
  "geo" : { },
  "id_str" : "310362291495399424",
  "in_reply_to_user_id" : 87902543,
  "text" : "@tornhalves ellen seiter cites @markwarschauer http:\/\/t.co\/T0X8DbiiCt",
  "id" : 310362291495399424,
  "in_reply_to_status_id" : 310347414076796928,
  "created_at" : "2013-03-09 12:11:51 +0000",
  "in_reply_to_screen_name" : "tornhalves",
  "in_reply_to_user_id_str" : "87902543",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 0, 11 ],
      "id_str" : "88202140",
      "id" : 88202140
    }, {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 12, 23 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 42, 53 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/HrPg3vtlmL",
      "expanded_url" : "http:\/\/www.digitalcounterrevolution.co.uk\/2012\/digital-wisdom-how-wise-is-marc-prensky\/",
      "display_url" : "digitalcounterrevolution.co.uk\/2012\/digital-w\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "310177881051512832",
  "geo" : { },
  "id_str" : "310182126106591232",
  "in_reply_to_user_id" : 88202140,
  "text" : "@hughdellar @leoselivan  u need a dose of @tornhalves e.g. http:\/\/t.co\/HrPg3vtlmL",
  "id" : 310182126106591232,
  "in_reply_to_status_id" : 310177881051512832,
  "created_at" : "2013-03-09 00:15:56 +0000",
  "in_reply_to_screen_name" : "hughdellar",
  "in_reply_to_user_id_str" : "88202140",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 32, 43 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sugatamitra",
      "indices" : [ 44, 56 ]
    }, {
      "text" : "edtech",
      "indices" : [ 60, 67 ]
    }, {
      "text" : "edchat",
      "indices" : [ 131, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/dh2mJtjQDM",
      "expanded_url" : "http:\/\/bit.ly\/Z70fHD",
      "display_url" : "bit.ly\/Z70fHD"
    } ]
  },
  "geo" : { },
  "id_str" : "310181601818587136",
  "text" : "damn was jst abt to hit sack&gt;@tornhalves #sugatamitra on #edtech and empire - a critique of his TED talk http:\/\/t.co\/dh2mJtjQDM #edchat",
  "id" : 310181601818587136,
  "created_at" : "2013-03-09 00:13:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "Chris Bunyan",
      "screen_name" : "bunyanchris",
      "indices" : [ 45, 57 ],
      "id_str" : "237402639",
      "id" : 237402639
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309724710726426624",
  "geo" : { },
  "id_str" : "310067202948747265",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan thanks for share Leo and thx to \n@bunyanchris for RT, have an enjoyable w\/e",
  "id" : 310067202948747265,
  "in_reply_to_status_id" : 309724710726426624,
  "created_at" : "2013-03-08 16:39:16 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Renshaw",
      "screen_name" : "englishraven",
      "indices" : [ 3, 16 ],
      "id_str" : "19515321",
      "id" : 19515321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/OVoReRrAQx",
      "expanded_url" : "http:\/\/lnkd.in\/VScpef",
      "display_url" : "lnkd.in\/VScpef"
    } ]
  },
  "geo" : { },
  "id_str" : "309688332261150720",
  "text" : "RT @englishraven: E-Learning Design Matters (5): The Foggy (but clear) concept of 'tiny habits' http:\/\/t.co\/OVoReRrAQx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.linkedin.com\/\" rel=\"nofollow\"\u003ELinkedIn\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/OVoReRrAQx",
        "expanded_url" : "http:\/\/lnkd.in\/VScpef",
        "display_url" : "lnkd.in\/VScpef"
      } ]
    },
    "geo" : { },
    "id_str" : "309684275991699458",
    "text" : "E-Learning Design Matters (5): The Foggy (but clear) concept of 'tiny habits' http:\/\/t.co\/OVoReRrAQx",
    "id" : 309684275991699458,
    "created_at" : "2013-03-07 15:17:39 +0000",
    "user" : {
      "name" : "Jason Renshaw",
      "screen_name" : "englishraven",
      "protected" : false,
      "id_str" : "19515321",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/485651582596300800\/7-bBqtn__normal.jpeg",
      "id" : 19515321,
      "verified" : false
    }
  },
  "id" : 309688332261150720,
  "created_at" : "2013-03-07 15:33:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pat thomson",
      "screen_name" : "ThomsonPat",
      "indices" : [ 53, 64 ],
      "id_str" : "402209787",
      "id" : 402209787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/JXaOZylNUp",
      "expanded_url" : "http:\/\/wp.me\/p1GJk8-tw",
      "display_url" : "wp.me\/p1GJk8-tw"
    } ]
  },
  "geo" : { },
  "id_str" : "309679964947636225",
  "text" : "getting tense about tense http:\/\/t.co\/JXaOZylNUp via @ThomsonPat",
  "id" : 309679964947636225,
  "created_at" : "2013-03-07 15:00:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marjorie Rosenberg",
      "screen_name" : "MarjorieRosenbe",
      "indices" : [ 0, 16 ],
      "id_str" : "328052618",
      "id" : 328052618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/GESRyKj5vR",
      "expanded_url" : "http:\/\/corpus.byu.edu\/coca\/?c=coca&q=21542539",
      "display_url" : "corpus.byu.edu\/coca\/?c=coca&q\u2026"
    }, {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/R1fW1SOH6x",
      "expanded_url" : "http:\/\/corpus.byu.edu\/coca\/?c=coca&q=21542579",
      "display_url" : "corpus.byu.edu\/coca\/?c=coca&q\u2026"
    }, {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/2AQEIXaufR",
      "expanded_url" : "http:\/\/corpus.byu.edu\/coca\/?c=coca&q=21542738",
      "display_url" : "corpus.byu.edu\/coca\/?c=coca&q\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "309392560978280448",
  "geo" : { },
  "id_str" : "309658481265373185",
  "in_reply_to_user_id" : 328052618,
  "text" : "@MarjorieRosenbe on twitter ^ freq http:\/\/t.co\/GESRyKj5vR; go to &gt; go on http:\/\/t.co\/R1fW1SOH6x; follow ^ freq http:\/\/t.co\/2AQEIXaufR",
  "id" : 309658481265373185,
  "in_reply_to_status_id" : 309392560978280448,
  "created_at" : "2013-03-07 13:35:09 +0000",
  "in_reply_to_screen_name" : "MarjorieRosenbe",
  "in_reply_to_user_id_str" : "328052618",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Cook",
      "screen_name" : "idc74",
      "indices" : [ 0, 6 ],
      "id_str" : "290521216",
      "id" : 290521216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309650691872407552",
  "geo" : { },
  "id_str" : "309651496088248320",
  "in_reply_to_user_id" : 290521216,
  "text" : "@idc74 do let me know if u find anything",
  "id" : 309651496088248320,
  "in_reply_to_status_id" : 309650691872407552,
  "created_at" : "2013-03-07 13:07:24 +0000",
  "in_reply_to_screen_name" : "idc74",
  "in_reply_to_user_id_str" : "290521216",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jo Cummins",
      "screen_name" : "jo_cummins",
      "indices" : [ 0, 11 ],
      "id_str" : "897738066",
      "id" : 897738066
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309592681053573120",
  "geo" : { },
  "id_str" : "309649447523074048",
  "in_reply_to_user_id" : 897738066,
  "text" : "@jo_cummins a pleasure",
  "id" : 309649447523074048,
  "in_reply_to_status_id" : 309592681053573120,
  "created_at" : "2013-03-07 12:59:15 +0000",
  "in_reply_to_screen_name" : "jo_cummins",
  "in_reply_to_user_id_str" : "897738066",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 0, 11 ],
      "id_str" : "282659955",
      "id" : 282659955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309587566276009984",
  "geo" : { },
  "id_str" : "309649368674361344",
  "in_reply_to_user_id" : 282659955,
  "text" : "@teflerinha yr welcome lk fwd to chance to get to use some of yr grt lessons",
  "id" : 309649368674361344,
  "in_reply_to_status_id" : 309587566276009984,
  "created_at" : "2013-03-07 12:58:57 +0000",
  "in_reply_to_screen_name" : "teflerinha",
  "in_reply_to_user_id_str" : "282659955",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Cook",
      "screen_name" : "idc74",
      "indices" : [ 0, 6 ],
      "id_str" : "290521216",
      "id" : 290521216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309584685355397121",
  "geo" : { },
  "id_str" : "309649099467157504",
  "in_reply_to_user_id" : 290521216,
  "text" : "@idc74 yet more research hidden from paying public?! :(",
  "id" : 309649099467157504,
  "in_reply_to_status_id" : 309584685355397121,
  "created_at" : "2013-03-07 12:57:52 +0000",
  "in_reply_to_screen_name" : "idc74",
  "in_reply_to_user_id_str" : "290521216",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "anotherfunnyhashtagfromkevin",
      "indices" : [ 17, 46 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309527338264166400",
  "geo" : { },
  "id_str" : "309648740594110465",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow hehe #anotherfunnyhashtagfromkevin",
  "id" : 309648740594110465,
  "in_reply_to_status_id" : 309527338264166400,
  "created_at" : "2013-03-07 12:56:27 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    }, {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 35, 51 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309527576890712064",
  "geo" : { },
  "id_str" : "309648466995466240",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow cheers Kevin! and also @michaelegriffin for RT!",
  "id" : 309648466995466240,
  "in_reply_to_status_id" : 309527576890712064,
  "created_at" : "2013-03-07 12:55:22 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 75, 86 ],
      "id_str" : "282659955",
      "id" : 282659955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/ELhpDeNOKb",
      "expanded_url" : "http:\/\/wp.me\/p2e2Wf-ci",
      "display_url" : "wp.me\/p2e2Wf-ci"
    } ]
  },
  "geo" : { },
  "id_str" : "309438497561931776",
  "text" : "The Icing on the Cake- free downloadable lesson http:\/\/t.co\/ELhpDeNOKb via @teflerinha",
  "id" : 309438497561931776,
  "created_at" : "2013-03-06 23:01:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jo Cummins",
      "screen_name" : "jo_cummins",
      "indices" : [ 49, 60 ],
      "id_str" : "897738066",
      "id" : 897738066
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/6tWvcyCDl2",
      "expanded_url" : "http:\/\/wp.me\/p31JKG-9C",
      "display_url" : "wp.me\/p31JKG-9C"
    } ]
  },
  "geo" : { },
  "id_str" : "309437890314792961",
  "text" : "As Simple as a Simile http:\/\/t.co\/6tWvcyCDl2 via @jo_cummins",
  "id" : 309437890314792961,
  "created_at" : "2013-03-06 22:58:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sharon noseley",
      "screen_name" : "shaznosel",
      "indices" : [ 0, 10 ],
      "id_str" : "140167864",
      "id" : 140167864
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309411909411680256",
  "geo" : { },
  "id_str" : "309433663580413952",
  "in_reply_to_user_id" : 140167864,
  "text" : "@shaznosel  hi are there word lists based on CEFR levels? do you know of any TOEIC based lists? thx",
  "id" : 309433663580413952,
  "in_reply_to_status_id" : 309411909411680256,
  "created_at" : "2013-03-06 22:41:49 +0000",
  "in_reply_to_screen_name" : "shaznosel",
  "in_reply_to_user_id_str" : "140167864",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Cook",
      "screen_name" : "idc74",
      "indices" : [ 0, 6 ],
      "id_str" : "290521216",
      "id" : 290521216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309430146128031744",
  "in_reply_to_user_id" : 290521216,
  "text" : "@idc74 hi the link to CANELC in yr post is broken",
  "id" : 309430146128031744,
  "created_at" : "2013-03-06 22:27:50 +0000",
  "in_reply_to_screen_name" : "idc74",
  "in_reply_to_user_id_str" : "290521216",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MarisaConstantinides",
      "screen_name" : "Marisa_C",
      "indices" : [ 0, 9 ],
      "id_str" : "18272500",
      "id" : 18272500
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309426629967499264",
  "geo" : { },
  "id_str" : "309427136773623808",
  "in_reply_to_user_id" : 18272500,
  "text" : "@Marisa_C yes he does a lot of v int work",
  "id" : 309427136773623808,
  "in_reply_to_status_id" : 309426629967499264,
  "created_at" : "2013-03-06 22:15:52 +0000",
  "in_reply_to_screen_name" : "Marisa_C",
  "in_reply_to_user_id_str" : "18272500",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "BobDignen_YA",
      "screen_name" : "BobDignen_YA",
      "indices" : [ 105, 118 ],
      "id_str" : "416886093",
      "id" : 416886093
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/SnGTMqtoh8",
      "expanded_url" : "http:\/\/www.intercultural.org\/die.php",
      "display_url" : "intercultural.org\/die.php"
    } ]
  },
  "in_reply_to_status_id_str" : "309418745980416000",
  "geo" : { },
  "id_str" : "309426991877222401",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan also wanted to do this but not able to find any ambig objects yet! http:\/\/t.co\/SnGTMqtoh8 HT @BobDignen_YA",
  "id" : 309426991877222401,
  "in_reply_to_status_id" : 309418745980416000,
  "created_at" : "2013-03-06 22:15:18 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 11, 19 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309426003296534530",
  "text" : "thanks all #eltchat",
  "id" : 309426003296534530,
  "created_at" : "2013-03-06 22:11:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MarisaConstantinides",
      "screen_name" : "Marisa_C",
      "indices" : [ 0, 9 ],
      "id_str" : "18272500",
      "id" : 18272500
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 63, 71 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309425309176983552",
  "geo" : { },
  "id_str" : "309425619870048258",
  "in_reply_to_user_id" : 18272500,
  "text" : "@Marisa_C from my limited exp they are usually very interested #eltchat",
  "id" : 309425619870048258,
  "in_reply_to_status_id" : 309425309176983552,
  "created_at" : "2013-03-06 22:09:51 +0000",
  "in_reply_to_screen_name" : "Marisa_C",
  "in_reply_to_user_id_str" : "18272500",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 46, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/t9vp6Col6Q",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-1t",
      "display_url" : "wp.me\/pgHyE-1t"
    } ]
  },
  "geo" : { },
  "id_str" : "309425299001597952",
  "text" : "last linky from me http:\/\/t.co\/t9vp6Col6Q :)  #eltchat",
  "id" : 309425299001597952,
  "created_at" : "2013-03-06 22:08:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Cook",
      "screen_name" : "idc74",
      "indices" : [ 0, 6 ],
      "id_str" : "290521216",
      "id" : 290521216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309423609888256001",
  "geo" : { },
  "id_str" : "309424909841469440",
  "in_reply_to_user_id" : 290521216,
  "text" : "@idc74 thkx for link reading now",
  "id" : 309424909841469440,
  "in_reply_to_status_id" : 309423609888256001,
  "created_at" : "2013-03-06 22:07:02 +0000",
  "in_reply_to_screen_name" : "idc74",
  "in_reply_to_user_id_str" : "290521216",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MarisaConstantinides",
      "screen_name" : "Marisa_C",
      "indices" : [ 0, 9 ],
      "id_str" : "18272500",
      "id" : 18272500
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309422584271892480",
  "geo" : { },
  "id_str" : "309423128344408064",
  "in_reply_to_user_id" : 18272500,
  "text" : "@Marisa_C true though a lot of useful discussion arose from it imo :)",
  "id" : 309423128344408064,
  "in_reply_to_status_id" : 309422584271892480,
  "created_at" : "2013-03-06 21:59:57 +0000",
  "in_reply_to_screen_name" : "Marisa_C",
  "in_reply_to_user_id_str" : "18272500",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 53, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/82OcVfIXAK",
      "expanded_url" : "http:\/\/www.ark.cs.cmu.edu\/TweetNLP\/cluster_viewer.html",
      "display_url" : "ark.cs.cmu.edu\/TweetNLP\/clust\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "309422637334032386",
  "text" : "interesting corpus of Twitter http:\/\/t.co\/82OcVfIXAK #eltchat",
  "id" : 309422637334032386,
  "created_at" : "2013-03-06 21:58:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 16, 27 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "MarisaConstantinides",
      "screen_name" : "Marisa_C",
      "indices" : [ 28, 37 ],
      "id_str" : "18272500",
      "id" : 18272500
    }, {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 65, 76 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 101, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/Fq34GXpgea",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-hr",
      "display_url" : "wp.me\/pgHyE-hr"
    } ]
  },
  "geo" : { },
  "id_str" : "309422049007382529",
  "text" : "theteacherjames @leoselivan @Marisa_C have u read my response to @hughdellar? http:\/\/t.co\/Fq34GXpgea #eltchat",
  "id" : 309422049007382529,
  "created_at" : "2013-03-06 21:55:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Onestopenglish",
      "screen_name" : "onestopenglish",
      "indices" : [ 0, 15 ],
      "id_str" : "21865822",
      "id" : 21865822
    }, {
      "name" : "Phil Longwell",
      "screen_name" : "teacherphili",
      "indices" : [ 16, 29 ],
      "id_str" : "67863264",
      "id" : 67863264
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309413821695537153",
  "geo" : { },
  "id_str" : "309421489273323521",
  "in_reply_to_user_id" : 21865822,
  "text" : "@Onestopenglish @teacherphili any chance all the articles be freed? :)",
  "id" : 309421489273323521,
  "in_reply_to_status_id" : 309413821695537153,
  "created_at" : "2013-03-06 21:53:26 +0000",
  "in_reply_to_screen_name" : "onestopenglish",
  "in_reply_to_user_id_str" : "21865822",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Moore",
      "screen_name" : "lexicojules",
      "indices" : [ 0, 12 ],
      "id_str" : "424320799",
      "id" : 424320799
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 77, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/vYlGkRayvf",
      "expanded_url" : "http:\/\/flax.nzdl.org\/greenstone3\/flax?a=fp&sa=collAbout&c=BAWEPS&if=flax",
      "display_url" : "flax.nzdl.org\/greenstone3\/fl\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "309418906123132928",
  "geo" : { },
  "id_str" : "309420000907759616",
  "in_reply_to_user_id" : 424320799,
  "text" : "@lexicojules the FLAX interface to the BAWE is great!http:\/\/t.co\/vYlGkRayvf  #eltchat",
  "id" : 309420000907759616,
  "in_reply_to_status_id" : 309418906123132928,
  "created_at" : "2013-03-06 21:47:31 +0000",
  "in_reply_to_screen_name" : "lexicojules",
  "in_reply_to_user_id_str" : "424320799",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MarisaConstantinides",
      "screen_name" : "Marisa_C",
      "indices" : [ 0, 9 ],
      "id_str" : "18272500",
      "id" : 18272500
    }, {
      "name" : "Lizzie Pinard",
      "screen_name" : "LizziePinard",
      "indices" : [ 10, 23 ],
      "id_str" : "287093748",
      "id" : 287093748
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 92, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/ozwNnpGhRW",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-oJ",
      "display_url" : "wp.me\/pgHyE-oJ"
    } ]
  },
  "in_reply_to_status_id_str" : "309417965940523008",
  "geo" : { },
  "id_str" : "309419093507850240",
  "in_reply_to_user_id" : 18272500,
  "text" : "@Marisa_C @LizziePinard can use free software to build yr own corpus http:\/\/t.co\/ozwNnpGhRW #eltchat",
  "id" : 309419093507850240,
  "in_reply_to_status_id" : 309417965940523008,
  "created_at" : "2013-03-06 21:43:55 +0000",
  "in_reply_to_screen_name" : "Marisa_C",
  "in_reply_to_user_id_str" : "18272500",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 58, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/jGJ3KTOn0i",
      "expanded_url" : "http:\/\/flax.nzdl.org\/greenstone3\/flax;jsessionid=E13CFBF4E8F25F301263221FC6341040?a=fp&sa=demos",
      "display_url" : "flax.nzdl.org\/greenstone3\/fl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "309418013336150016",
  "text" : "demo activities  FLAX lrner corpus http:\/\/t.co\/jGJ3KTOn0i #eltchat",
  "id" : 309418013336150016,
  "created_at" : "2013-03-06 21:39:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lizzie Pinard",
      "screen_name" : "LizziePinard",
      "indices" : [ 0, 13 ],
      "id_str" : "287093748",
      "id" : 287093748
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 98, 106 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309414725370912768",
  "geo" : { },
  "id_str" : "309415330399256576",
  "in_reply_to_user_id" : 287093748,
  "text" : "@LizziePinard i use it to focus reading texts, e.g. word like \"features\", then collocates of that #eltchat",
  "id" : 309415330399256576,
  "in_reply_to_status_id" : 309414725370912768,
  "created_at" : "2013-03-06 21:28:58 +0000",
  "in_reply_to_screen_name" : "LizziePinard",
  "in_reply_to_user_id_str" : "287093748",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MarisaConstantinides",
      "screen_name" : "Marisa_C",
      "indices" : [ 0, 9 ],
      "id_str" : "18272500",
      "id" : 18272500
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 45, 53 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309414184620269568",
  "geo" : { },
  "id_str" : "309414436953784321",
  "in_reply_to_user_id" : 18272500,
  "text" : "@Marisa_C i use it with multi-media students #eltchat",
  "id" : 309414436953784321,
  "in_reply_to_status_id" : 309414184620269568,
  "created_at" : "2013-03-06 21:25:25 +0000",
  "in_reply_to_screen_name" : "Marisa_C",
  "in_reply_to_user_id_str" : "18272500",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 80, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309413996807745536",
  "text" : "imo tchrs need to play around with corpora first then go on to use it in class  #eltchat",
  "id" : 309413996807745536,
  "created_at" : "2013-03-06 21:23:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Onestopenglish",
      "screen_name" : "onestopenglish",
      "indices" : [ 0, 15 ],
      "id_str" : "21865822",
      "id" : 21865822
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 65, 73 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309412802966204416",
  "geo" : { },
  "id_str" : "309413095812509696",
  "in_reply_to_user_id" : 21865822,
  "text" : "@Onestopenglish can you make that available w\/o subscription? ;) #eltchat",
  "id" : 309413095812509696,
  "in_reply_to_status_id" : 309412802966204416,
  "created_at" : "2013-03-06 21:20:05 +0000",
  "in_reply_to_screen_name" : "onestopenglish",
  "in_reply_to_user_id_str" : "21865822",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 87, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/0tgPw1RFAp",
      "expanded_url" : "http:\/\/eflnotes.wordpress.com\/tag\/cupofcoca\/",
      "display_url" : "eflnotes.wordpress.com\/tag\/cupofcoca\/"
    } ]
  },
  "geo" : { },
  "id_str" : "309412712977416192",
  "text" : "also have a series of short examples to encrge tchr use of COCA http:\/\/t.co\/0tgPw1RFAp #eltchat",
  "id" : 309412712977416192,
  "created_at" : "2013-03-06 21:18:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 64, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/0sOS9p9tq5",
      "expanded_url" : "http:\/\/eflnotes.wordpress.com\/2013\/02\/03\/this-corpora-bashing-parrot-has-ceased-to-be\/",
      "display_url" : "eflnotes.wordpress.com\/2013\/02\/03\/thi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "309411376152068096",
  "text" : "post with some links for the doubters :) http:\/\/t.co\/0sOS9p9tq5 #eltchat",
  "id" : 309411376152068096,
  "created_at" : "2013-03-06 21:13:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sue Annan",
      "screen_name" : "SueAnnan",
      "indices" : [ 0, 9 ],
      "id_str" : "136001411",
      "id" : 136001411
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 105, 113 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309409898133856257",
  "geo" : { },
  "id_str" : "309410871468236800",
  "in_reply_to_user_id" : 136001411,
  "text" : "@SueAnnan use software to help me pick rel targets will detail in some upcoming blog posts , stay tuned! #eltchat",
  "id" : 309410871468236800,
  "in_reply_to_status_id" : 309409898133856257,
  "created_at" : "2013-03-06 21:11:14 +0000",
  "in_reply_to_screen_name" : "SueAnnan",
  "in_reply_to_user_id_str" : "136001411",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 61, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309409770706718720",
  "text" : "i use it to focus my reading tasks in a vocab oriented class #eltchat",
  "id" : 309409770706718720,
  "created_at" : "2013-03-06 21:06:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 10, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309409059554070528",
  "text" : "hey all \n #eltchat",
  "id" : 309409059554070528,
  "created_at" : "2013-03-06 21:04:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "BobDignen_YA",
      "screen_name" : "BobDignen_YA",
      "indices" : [ 13, 26 ],
      "id_str" : "416886093",
      "id" : 416886093
    }, {
      "name" : "Chia Suan Chong",
      "screen_name" : "chiasuan",
      "indices" : [ 64, 73 ],
      "id_str" : "71588589",
      "id" : 71588589
    }, {
      "name" : "John Hughes",
      "screen_name" : "johnhugheselt",
      "indices" : [ 80, 94 ],
      "id_str" : "20094894",
      "id" : 20094894
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "besig",
      "indices" : [ 118, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/tYRcAVE4RQ",
      "expanded_url" : "http:\/\/peo.cambridge.org\/index.php?option=com_content&view=section&layout=blog&id=9&Itemid=2",
      "display_url" : "peo.cambridge.org\/index.php?opti\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "309394230223179776",
  "geo" : { },
  "id_str" : "309407455815815169",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan  @BobDignen_YA has some http:\/\/t.co\/tYRcAVE4RQ also @chiasuan &amp; @johnhugheselt and int discussions on #besig ning",
  "id" : 309407455815815169,
  "in_reply_to_status_id" : 309394230223179776,
  "created_at" : "2013-03-06 20:57:40 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    }, {
      "name" : "\u5F20\u5F64\u4F1A\u53D1\u5149\u5440",
      "screen_name" : "Lemonzt",
      "indices" : [ 17, 25 ],
      "id_str" : "3013470183",
      "id" : 3013470183
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309309134388461568",
  "geo" : { },
  "id_str" : "309401676903751680",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin @lemonzt too kind Mike, thx for share and like on post",
  "id" : 309401676903751680,
  "in_reply_to_status_id" : 309309134388461568,
  "created_at" : "2013-03-06 20:34:42 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309344527863390209",
  "geo" : { },
  "id_str" : "309401497660162049",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson cheers for share Chris maybe my upcoming posts on this may give you some ideas :)",
  "id" : 309401497660162049,
  "in_reply_to_status_id" : 309344527863390209,
  "created_at" : "2013-03-06 20:34:00 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John T. Spencer",
      "screen_name" : "JohnTSpencer",
      "indices" : [ 3, 16 ],
      "id_str" : "2285706270",
      "id" : 2285706270
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mschat",
      "indices" : [ 113, 120 ]
    }, {
      "text" : "cpchat",
      "indices" : [ 121, 128 ]
    }, {
      "text" : "rechat",
      "indices" : [ 129, 136 ]
    }, {
      "text" : "edchat",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/uao5ZmpUm3",
      "expanded_url" : "http:\/\/bit.ly\/10dZIIy",
      "display_url" : "bit.ly\/10dZIIy"
    } ]
  },
  "geo" : { },
  "id_str" : "309401203769503745",
  "text" : "RT @johntspencer: Do We Still Need Schools and Teachers? (A Thought on Holes in the Wall) http:\/\/t.co\/uao5ZmpUm3 #mschat #cpchat #rechat ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "mschat",
        "indices" : [ 95, 102 ]
      }, {
        "text" : "cpchat",
        "indices" : [ 103, 110 ]
      }, {
        "text" : "rechat",
        "indices" : [ 111, 118 ]
      }, {
        "text" : "edchat",
        "indices" : [ 119, 126 ]
      } ],
      "urls" : [ {
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/uao5ZmpUm3",
        "expanded_url" : "http:\/\/bit.ly\/10dZIIy",
        "display_url" : "bit.ly\/10dZIIy"
      } ]
    },
    "geo" : { },
    "id_str" : "309279272437174272",
    "text" : "Do We Still Need Schools and Teachers? (A Thought on Holes in the Wall) http:\/\/t.co\/uao5ZmpUm3 #mschat #cpchat #rechat #edchat",
    "id" : 309279272437174272,
    "created_at" : "2013-03-06 12:28:19 +0000",
    "user" : {
      "name" : "John Spencer",
      "screen_name" : "spencerideas",
      "protected" : false,
      "id_str" : "18389166",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751913559160795136\/eU7NtYy4_normal.jpg",
      "id" : 18389166,
      "verified" : false
    }
  },
  "id" : 309401203769503745,
  "created_at" : "2013-03-06 20:32:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 3, 14 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 16, 22 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 109, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309290365272334337",
  "text" : "RT @leoselivan: @EBEFL I don't think strategies are comparable there. Larger vocab L1, Critical mass and all #eltchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Russ Mayne",
        "screen_name" : "ebefl",
        "indices" : [ 0, 6 ],
        "id_str" : "2228367554",
        "id" : 2228367554
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "eltchat",
        "indices" : [ 93, 101 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "309288529341583361",
    "text" : "@EBEFL I don't think strategies are comparable there. Larger vocab L1, Critical mass and all #eltchat",
    "id" : 309288529341583361,
    "created_at" : "2013-03-06 13:05:06 +0000",
    "user" : {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "protected" : false,
      "id_str" : "408365496",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/460546508601819136\/12ivDBb__normal.jpeg",
      "id" : 408365496,
      "verified" : false
    }
  },
  "id" : 309290365272334337,
  "created_at" : "2013-03-06 13:12:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 11, 19 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309290193708535808",
  "text" : "thanks all #eltchat",
  "id" : 309290193708535808,
  "created_at" : "2013-03-06 13:11:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309120124818976770",
  "geo" : { },
  "id_str" : "309289763628777472",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt thanks for comment replied.",
  "id" : 309289763628777472,
  "in_reply_to_status_id" : 309120124818976770,
  "created_at" : "2013-03-06 13:10:00 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob Knowles",
      "screen_name" : "BobK99",
      "indices" : [ 0, 7 ],
      "id_str" : "15167486",
      "id" : 15167486
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 40, 48 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309287316621512704",
  "geo" : { },
  "id_str" : "309289538428227585",
  "in_reply_to_user_id" : 15167486,
  "text" : "@BobK99 haha, the very question in this #eltchat :)",
  "id" : 309289538428227585,
  "in_reply_to_status_id" : 309287316621512704,
  "created_at" : "2013-03-06 13:09:06 +0000",
  "in_reply_to_screen_name" : "BobK99",
  "in_reply_to_user_id_str" : "15167486",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenny Ankenbauer",
      "screen_name" : "jankenb2",
      "indices" : [ 0, 9 ],
      "id_str" : "30187301",
      "id" : 30187301
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 113, 121 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309287171372769280",
  "geo" : { },
  "id_str" : "309288386051588098",
  "in_reply_to_user_id" : 30187301,
  "text" : "@jankenb2 mass - that's general world knowledge? not up on schema theory as applied to lang any refs to explore? #eltchat",
  "id" : 309288386051588098,
  "in_reply_to_status_id" : 309287171372769280,
  "created_at" : "2013-03-06 13:04:32 +0000",
  "in_reply_to_screen_name" : "jankenb2",
  "in_reply_to_user_id_str" : "30187301",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 91, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309286596350455808",
  "text" : "from what i recall schema theory maybe applicable to general experiences but not to lang?\n #eltchat",
  "id" : 309286596350455808,
  "created_at" : "2013-03-06 12:57:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MarisaConstantinides",
      "screen_name" : "Marisa_C",
      "indices" : [ 0, 9 ],
      "id_str" : "18272500",
      "id" : 18272500
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 50, 58 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309285376776888320",
  "geo" : { },
  "id_str" : "309286156015644672",
  "in_reply_to_user_id" : 18272500,
  "text" : "@Marisa_C need to weigh up what to teach for sure #eltchat",
  "id" : 309286156015644672,
  "in_reply_to_status_id" : 309285376776888320,
  "created_at" : "2013-03-06 12:55:40 +0000",
  "in_reply_to_screen_name" : "Marisa_C",
  "in_reply_to_user_id_str" : "18272500",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 46, 54 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309285306706829316",
  "geo" : { },
  "id_str" : "309285934736736258",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler depends on learner level i guess #eltchat",
  "id" : 309285934736736258,
  "in_reply_to_status_id" : 309285306706829316,
  "created_at" : "2013-03-06 12:54:47 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 67, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309285127542939648",
  "text" : "if the biarn flils in coextnt nlautarly do we need to tceah it? :) #eltchat",
  "id" : 309285127542939648,
  "created_at" : "2013-03-06 12:51:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jo Cummins",
      "screen_name" : "jo_cummins",
      "indices" : [ 0, 11 ],
      "id_str" : "897738066",
      "id" : 897738066
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/lpqd6EsVzL",
      "expanded_url" : "http:\/\/www.youtube.com\/v\/b0bI9KQQ_fo?version=3&hl=en_US",
      "display_url" : "youtube.com\/v\/b0bI9KQQ_fo?\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "309230298653143040",
  "geo" : { },
  "id_str" : "309232883598495744",
  "in_reply_to_user_id" : 897738066,
  "text" : "@jo_cummins abs, Oliver Stone's South of the Border is no bad also http:\/\/t.co\/lpqd6EsVzL",
  "id" : 309232883598495744,
  "in_reply_to_status_id" : 309230298653143040,
  "created_at" : "2013-03-06 09:23:59 +0000",
  "in_reply_to_screen_name" : "jo_cummins",
  "in_reply_to_user_id_str" : "897738066",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ch\u00E1vez",
      "indices" : [ 5, 12 ]
    } ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/UyReOkk2GG",
      "expanded_url" : "http:\/\/www.thehindu.com\/news\/international\/world\/hugo-chvez-death-of-a-socialist\/article4481169.ece",
      "display_url" : "thehindu.com\/news\/internati\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "309227885330300928",
  "text" : "Hugo #Ch\u00E1vez: Death of a socialist http:\/\/t.co\/UyReOkk2GG",
  "id" : 309227885330300928,
  "created_at" : "2013-03-06 09:04:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paul braddock",
      "screen_name" : "bcnpaul1",
      "indices" : [ 70, 79 ],
      "id_str" : "130975050",
      "id" : 130975050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/fBkiAv08Go",
      "expanded_url" : "http:\/\/wp.me\/p1VGfu-6m",
      "display_url" : "wp.me\/p1VGfu-6m"
    } ]
  },
  "geo" : { },
  "id_str" : "309225821518835712",
  "text" : "Interactive techno-travels http:\/\/t.co\/fBkiAv08Go via @elt_pics &amp; @bcnpaul1",
  "id" : 309225821518835712,
  "created_at" : "2013-03-06 08:55:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    }, {
      "name" : "Tamas Lorincz",
      "screen_name" : "tamaslorincz",
      "indices" : [ 17, 30 ],
      "id_str" : "24491222",
      "id" : 24491222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309214316878499841",
  "geo" : { },
  "id_str" : "309217529245609984",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin @tamaslorincz i like this activity as well i think it's called pyramid discussion?",
  "id" : 309217529245609984,
  "in_reply_to_status_id" : 309214316878499841,
  "created_at" : "2013-03-06 08:22:58 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Chavez",
      "indices" : [ 18, 25 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/QBi0KOBXib",
      "expanded_url" : "http:\/\/www.voltairenet.org\/article171585.html",
      "display_url" : "voltairenet.org\/article171585.\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "309196369636233216",
  "text" : "Statement by Hugo #Chavez at 66th UN General Assembly\nhttp:\/\/t.co\/QBi0KOBXib",
  "id" : 309196369636233216,
  "created_at" : "2013-03-06 06:58:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Chavez",
      "indices" : [ 9, 16 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309194967996317696",
  "text" : "RIP Hugo #Chavez",
  "id" : 309194967996317696,
  "created_at" : "2013-03-06 06:53:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309188281915023360",
  "text" : "&lt;&lt;Schools in the Cloud &gt;&gt;I guess Schools with Mainframes and Terminals doesn\u00B4t have that buzzword ring :\/",
  "id" : 309188281915023360,
  "created_at" : "2013-03-06 06:26:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309120124818976770",
  "geo" : { },
  "id_str" : "309174749999800320",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt thx for share Tyson have a good \u00B4un.",
  "id" : 309174749999800320,
  "in_reply_to_status_id" : 309120124818976770,
  "created_at" : "2013-03-06 05:32:59 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 109, 117 ]
    }, {
      "text" : "tesol",
      "indices" : [ 118, 124 ]
    }, {
      "text" : "elt",
      "indices" : [ 125, 129 ]
    }, {
      "text" : "besig",
      "indices" : [ 130, 136 ]
    }, {
      "text" : "esp",
      "indices" : [ 137, 141 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/ozwNnpGhRW",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-oJ",
      "display_url" : "wp.me\/pgHyE-oJ"
    } ]
  },
  "geo" : { },
  "id_str" : "309069349291958272",
  "text" : "New post Building your own corpus \u2013 TextSTAT &amp; AntConc\nhttp:\/\/t.co\/ozwNnpGhRW &gt;&gt;screenshot alert!! #eltchat #tesol #elt #besig #esp",
  "id" : 309069349291958272,
  "created_at" : "2013-03-05 22:34:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    }, {
      "name" : "James Taylor",
      "screen_name" : "theteacherjames",
      "indices" : [ 7, 23 ],
      "id_str" : "71746265",
      "id" : 71746265
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mitra",
      "indices" : [ 29, 35 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/A5AXvt1lZ2",
      "expanded_url" : "http:\/\/hackeducation.com\/2013\/03\/03\/hacking-your-education-stephens-hole-in-the-wall-mitra\/",
      "display_url" : "hackeducation.com\/2013\/03\/03\/hac\u2026"
    }, {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/dJ7FCeTAaO",
      "expanded_url" : "http:\/\/www.digitalcounterrevolution.co.uk\/2012\/sugata-mitra-and-the-enemies-within\/",
      "display_url" : "digitalcounterrevolution.co.uk\/2012\/sugata-mi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "309057464089858048",
  "text" : "@EBEFL @theteacherjames more #mitra critiques and mre reading! here http:\/\/t.co\/A5AXvt1lZ2 &amp; http:\/\/t.co\/dJ7FCeTAaO",
  "id" : 309057464089858048,
  "created_at" : "2013-03-05 21:46:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lynne Murphy",
      "screen_name" : "lynneguist",
      "indices" : [ 3, 14 ],
      "id_str" : "16316886",
      "id" : 16316886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/BasuNxtE2X",
      "expanded_url" : "http:\/\/bit.ly\/12pliuY",
      "display_url" : "bit.ly\/12pliuY"
    } ]
  },
  "geo" : { },
  "id_str" : "308884708069109760",
  "text" : "RT @lynneguist: Linguistics Research Digest: Accommodating across social borders http:\/\/t.co\/BasuNxtE2X",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/BasuNxtE2X",
        "expanded_url" : "http:\/\/bit.ly\/12pliuY",
        "display_url" : "bit.ly\/12pliuY"
      } ]
    },
    "geo" : { },
    "id_str" : "308692871693864960",
    "text" : "Linguistics Research Digest: Accommodating across social borders http:\/\/t.co\/BasuNxtE2X",
    "id" : 308692871693864960,
    "created_at" : "2013-03-04 21:38:10 +0000",
    "user" : {
      "name" : "Lynne Murphy",
      "screen_name" : "lynneguist",
      "protected" : false,
      "id_str" : "16316886",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632304665821081601\/BiPmyu1t_normal.jpg",
      "id" : 16316886,
      "verified" : false
    }
  },
  "id" : 308884708069109760,
  "created_at" : "2013-03-05 10:20:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BobDignen_YA",
      "screen_name" : "BobDignen_YA",
      "indices" : [ 3, 16 ],
      "id_str" : "416886093",
      "id" : 416886093
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/drWtqbDfhT",
      "expanded_url" : "http:\/\/conversation.cipr.co.uk\/posts\/cipr.account\/why-brits-abroad-could-do-with-a-little-more-in-the-way-of-pr-skills",
      "display_url" : "conversation.cipr.co.uk\/posts\/cipr.acc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "308878667713503232",
  "text" : "RT @BobDignen_YA: PR advice for Brits working internationally:) http:\/\/t.co\/drWtqbDfhT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/drWtqbDfhT",
        "expanded_url" : "http:\/\/conversation.cipr.co.uk\/posts\/cipr.account\/why-brits-abroad-could-do-with-a-little-more-in-the-way-of-pr-skills",
        "display_url" : "conversation.cipr.co.uk\/posts\/cipr.acc\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "308876124056866817",
    "text" : "PR advice for Brits working internationally:) http:\/\/t.co\/drWtqbDfhT",
    "id" : 308876124056866817,
    "created_at" : "2013-03-05 09:46:21 +0000",
    "user" : {
      "name" : "BobDignen_YA",
      "screen_name" : "BobDignen_YA",
      "protected" : false,
      "id_str" : "416886093",
      "profile_image_url_https" : "https:\/\/abs.twimg.com\/sticky\/default_profile_images\/default_profile_1_normal.png",
      "id" : 416886093,
      "verified" : false
    }
  },
  "id" : 308878667713503232,
  "created_at" : "2013-03-05 09:56:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BobDignen_YA",
      "screen_name" : "BobDignen_YA",
      "indices" : [ 0, 13 ],
      "id_str" : "416886093",
      "id" : 416886093
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "308876124056866817",
  "geo" : { },
  "id_str" : "308878596171255808",
  "in_reply_to_user_id" : 416886093,
  "text" : "@BobDignen_YA interesting, hve anecdote re planning time btw Fr &amp; UK team mbrs, FR spnd mre time UK less time so more revisions wth UK team!",
  "id" : 308878596171255808,
  "in_reply_to_status_id" : 308876124056866817,
  "created_at" : "2013-03-05 09:56:10 +0000",
  "in_reply_to_screen_name" : "BobDignen_YA",
  "in_reply_to_user_id_str" : "416886093",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/9D0Oz1Hn2W",
      "expanded_url" : "http:\/\/www.counterpunch.org\/2013\/03\/04\/where-the-left-triumphs\/",
      "display_url" : "counterpunch.org\/2013\/03\/04\/whe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "308722451699879936",
  "text" : "Tripura! Where the Left Triumphs http:\/\/t.co\/9D0Oz1Hn2W",
  "id" : 308722451699879936,
  "created_at" : "2013-03-04 23:35:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/IGD4Ph2b75",
      "expanded_url" : "http:\/\/tinyurl.com\/bm83zoh",
      "display_url" : "tinyurl.com\/bm83zoh"
    } ]
  },
  "geo" : { },
  "id_str" : "308710392224428032",
  "text" : "RT @medialens: \"The Most Important Leak\" Aimed at Stopping the Iraq War: 'It's not even a footnote in the history of Iraq.' http:\/\/t.co\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/IGD4Ph2b75",
        "expanded_url" : "http:\/\/tinyurl.com\/bm83zoh",
        "display_url" : "tinyurl.com\/bm83zoh"
      } ]
    },
    "geo" : { },
    "id_str" : "308649106430119936",
    "text" : "\"The Most Important Leak\" Aimed at Stopping the Iraq War: 'It's not even a footnote in the history of Iraq.' http:\/\/t.co\/IGD4Ph2b75",
    "id" : 308649106430119936,
    "created_at" : "2013-03-04 18:44:16 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 308710392224428032,
  "created_at" : "2013-03-04 22:47:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George Siemens",
      "screen_name" : "gsiemens",
      "indices" : [ 3, 12 ],
      "id_str" : "18613",
      "id" : 18613
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sxswedu",
      "indices" : [ 78, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/UmjiQ1MYjl",
      "expanded_url" : "http:\/\/www.reuters.com\/article\/2013\/03\/03\/us-education-database-idUSBRE92204W20130303",
      "display_url" : "reuters.com\/article\/2013\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "308706241239195648",
  "text" : "RT @gsiemens: The most important, least known, project impacting education at #sxswedu? http:\/\/t.co\/UmjiQ1MYjl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "sxswedu",
        "indices" : [ 64, 72 ]
      } ],
      "urls" : [ {
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/UmjiQ1MYjl",
        "expanded_url" : "http:\/\/www.reuters.com\/article\/2013\/03\/03\/us-education-database-idUSBRE92204W20130303",
        "display_url" : "reuters.com\/article\/2013\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "308686810769408000",
    "text" : "The most important, least known, project impacting education at #sxswedu? http:\/\/t.co\/UmjiQ1MYjl",
    "id" : 308686810769408000,
    "created_at" : "2013-03-04 21:14:05 +0000",
    "user" : {
      "name" : "George Siemens",
      "screen_name" : "gsiemens",
      "protected" : false,
      "id_str" : "18613",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451036825637761025\/7_0RawE8_normal.jpeg",
      "id" : 18613,
      "verified" : false
    }
  },
  "id" : 308706241239195648,
  "created_at" : "2013-03-04 22:31:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Motivated Grammar",
      "screen_name" : "MGrammar",
      "indices" : [ 107, 116 ],
      "id_str" : "32516315",
      "id" : 32516315
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/CsxTHiqCl8",
      "expanded_url" : "http:\/\/wp.me\/p67QB-13C",
      "display_url" : "wp.me\/p67QB-13C"
    } ]
  },
  "geo" : { },
  "id_str" : "308701828462280705",
  "text" : "today apparently&gt;National Grammar Day 2013: Ten More Grammar Myths, Debunked http:\/\/t.co\/CsxTHiqCl8 via @MGrammar",
  "id" : 308701828462280705,
  "created_at" : "2013-03-04 22:13:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Taylor",
      "screen_name" : "theteacherjames",
      "indices" : [ 3, 19 ],
      "id_str" : "71746265",
      "id" : 71746265
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 114, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/PGTPsiF7jn",
      "expanded_url" : "http:\/\/ow.ly\/ilkhx",
      "display_url" : "ow.ly\/ilkhx"
    } ]
  },
  "geo" : { },
  "id_str" : "308694956673998848",
  "text" : "RT @theteacherjames: Very interesting article questioning the claims made by Sugata Mitra. http:\/\/t.co\/PGTPsiF7jn #eltchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "eltchat",
        "indices" : [ 93, 101 ]
      } ],
      "urls" : [ {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/PGTPsiF7jn",
        "expanded_url" : "http:\/\/ow.ly\/ilkhx",
        "display_url" : "ow.ly\/ilkhx"
      } ]
    },
    "geo" : { },
    "id_str" : "308680620907827200",
    "text" : "Very interesting article questioning the claims made by Sugata Mitra. http:\/\/t.co\/PGTPsiF7jn #eltchat",
    "id" : 308680620907827200,
    "created_at" : "2013-03-04 20:49:29 +0000",
    "user" : {
      "name" : "James Taylor",
      "screen_name" : "theteacherjames",
      "protected" : false,
      "id_str" : "71746265",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/595367704090939392\/nJCWaI_Z_normal.jpg",
      "id" : 71746265,
      "verified" : false
    }
  },
  "id" : 308694956673998848,
  "created_at" : "2013-03-04 21:46:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 46, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308653199458463744",
  "text" : "+1 for google hangout, thx to all for chat :) #eapchat",
  "id" : 308653199458463744,
  "created_at" : "2013-03-04 19:00:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nagehan Tunar",
      "screen_name" : "stiiiv",
      "indices" : [ 0, 7 ],
      "id_str" : "799058600",
      "id" : 799058600
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 13, 21 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "308649619552882689",
  "geo" : { },
  "id_str" : "308650039276871680",
  "in_reply_to_user_id" : 69068757,
  "text" : "@stiiiv haha #eapchat",
  "id" : 308650039276871680,
  "in_reply_to_status_id" : 308649619552882689,
  "created_at" : "2013-03-04 18:47:58 +0000",
  "in_reply_to_screen_name" : "stiivkirk",
  "in_reply_to_user_id_str" : "69068757",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 89, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/xnluInhIgU",
      "expanded_url" : "http:\/\/explorationsofstyle.com\/2011\/03\/02\/verbs\/",
      "display_url" : "explorationsofstyle.com\/2011\/03\/02\/ver\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "308648955988811776",
  "text" : "there's another view of verbs for expressing action vs nouns here http:\/\/t.co\/xnluInhIgU #eapchat",
  "id" : 308648955988811776,
  "created_at" : "2013-03-04 18:43:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Moore",
      "screen_name" : "lexicojules",
      "indices" : [ 0, 12 ],
      "id_str" : "424320799",
      "id" : 424320799
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 53, 61 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "308647113611419648",
  "geo" : { },
  "id_str" : "308647644362846208",
  "in_reply_to_user_id" : 424320799,
  "text" : "@lexicojules thats int, any refs to explore on this? #eapchat",
  "id" : 308647644362846208,
  "in_reply_to_status_id" : 308647113611419648,
  "created_at" : "2013-03-04 18:38:27 +0000",
  "in_reply_to_screen_name" : "lexicojules",
  "in_reply_to_user_id_str" : "424320799",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nagehan Tunar",
      "screen_name" : "stiiiv",
      "indices" : [ 0, 7 ],
      "id_str" : "799058600",
      "id" : 799058600
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 38, 46 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "308645398891884544",
  "geo" : { },
  "id_str" : "308645755097333760",
  "in_reply_to_user_id" : 69068757,
  "text" : "@stiiiv SFL=systemic functional lang? #eapchat",
  "id" : 308645755097333760,
  "in_reply_to_status_id" : 308645398891884544,
  "created_at" : "2013-03-04 18:30:57 +0000",
  "in_reply_to_screen_name" : "stiivkirk",
  "in_reply_to_user_id_str" : "69068757",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 55, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308644857495289856",
  "text" : "do we include vocab when we talk about grammar in EAP? #eapchat",
  "id" : 308644857495289856,
  "created_at" : "2013-03-04 18:27:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Umes Shrestha",
      "screen_name" : "umes_shrestha",
      "indices" : [ 0, 14 ],
      "id_str" : "47920557",
      "id" : 47920557
    }, {
      "name" : "Jo Cummins",
      "screen_name" : "jo_cummins",
      "indices" : [ 15, 26 ],
      "id_str" : "897738066",
      "id" : 897738066
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "308514941680373760",
  "geo" : { },
  "id_str" : "308519210663948289",
  "in_reply_to_user_id" : 47920557,
  "text" : "@umes_shrestha @jo_cummins utterly creative i'd say, esp dog ate my easy :) (also would blame the newspaper typos not author)",
  "id" : 308519210663948289,
  "in_reply_to_status_id" : 308514941680373760,
  "created_at" : "2013-03-04 10:08:06 +0000",
  "in_reply_to_screen_name" : "umes_shrestha",
  "in_reply_to_user_id_str" : "47920557",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Umes Shrestha",
      "screen_name" : "umes_shrestha",
      "indices" : [ 3, 17 ],
      "id_str" : "47920557",
      "id" : 47920557
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "poem",
      "indices" : [ 111, 116 ]
    }, {
      "text" : "eltnepal",
      "indices" : [ 117, 126 ]
    }, {
      "text" : "nepal",
      "indices" : [ 127, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/JjiVzmyCQU",
      "expanded_url" : "http:\/\/latebecame.wordpress.com\/2013\/03\/04\/utterly-creative-or-ridiculously-terrible-poems\/",
      "display_url" : "latebecame.wordpress.com\/2013\/03\/04\/utt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "308518764218028032",
  "text" : "RT @umes_shrestha: A new blog post: \nUtterly creative or ridiculously terrible poems - \nhttp:\/\/t.co\/JjiVzmyCQU #poem #eltnepal #nepal",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "poem",
        "indices" : [ 92, 97 ]
      }, {
        "text" : "eltnepal",
        "indices" : [ 98, 107 ]
      }, {
        "text" : "nepal",
        "indices" : [ 108, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/JjiVzmyCQU",
        "expanded_url" : "http:\/\/latebecame.wordpress.com\/2013\/03\/04\/utterly-creative-or-ridiculously-terrible-poems\/",
        "display_url" : "latebecame.wordpress.com\/2013\/03\/04\/utt\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "308514941680373760",
    "text" : "A new blog post: \nUtterly creative or ridiculously terrible poems - \nhttp:\/\/t.co\/JjiVzmyCQU #poem #eltnepal #nepal",
    "id" : 308514941680373760,
    "created_at" : "2013-03-04 09:51:08 +0000",
    "user" : {
      "name" : "Umes Shrestha",
      "screen_name" : "umes_shrestha",
      "protected" : false,
      "id_str" : "47920557",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3593955878\/7f32482cfb17e625324e1bd024944554_normal.jpeg",
      "id" : 47920557,
      "verified" : false
    }
  },
  "id" : 308518764218028032,
  "created_at" : "2013-03-04 10:06:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol Goodey",
      "screen_name" : "cgoodey",
      "indices" : [ 0, 8 ],
      "id_str" : "26606833",
      "id" : 26606833
    }, {
      "name" : "Josette LeBlanc",
      "screen_name" : "JosetteLB",
      "indices" : [ 9, 19 ],
      "id_str" : "33503694",
      "id" : 33503694
    }, {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 20, 31 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "308514395259011072",
  "geo" : { },
  "id_str" : "308517208563265536",
  "in_reply_to_user_id" : 26606833,
  "text" : "@cgoodey @JosetteLB @kevchanwow kevin's 2nd way point struck me most  \"Honor and welcome who my student is today.\" always a challenge!",
  "id" : 308517208563265536,
  "in_reply_to_status_id" : 308514395259011072,
  "created_at" : "2013-03-04 10:00:09 +0000",
  "in_reply_to_screen_name" : "cgoodey",
  "in_reply_to_user_id_str" : "26606833",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josette LeBlanc",
      "screen_name" : "JosetteLB",
      "indices" : [ 3, 13 ],
      "id_str" : "33503694",
      "id" : 33503694
    }, {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 80, 91 ],
      "id_str" : "144663117",
      "id" : 144663117
    }, {
      "name" : "Naomi Epstein",
      "screen_name" : "naomishema",
      "indices" : [ 92, 103 ],
      "id_str" : "228469472",
      "id" : 228469472
    }, {
      "name" : "Tamas Lorincz",
      "screen_name" : "tamaslorincz",
      "indices" : [ 104, 117 ],
      "id_str" : "24491222",
      "id" : 24491222
    }, {
      "name" : "Vladimira Chalyova",
      "screen_name" : "vladkaslniecko",
      "indices" : [ 118, 133 ],
      "id_str" : "116543200",
      "id" : 116543200
    }, {
      "name" : "Miguel Mendoza",
      "screen_name" : "mike08",
      "indices" : [ 139, 140 ],
      "id_str" : "9444972",
      "id" : 9444972
    }, {
      "name" : "Gareth Knight",
      "screen_name" : "gknightbkk",
      "indices" : [ 139, 140 ],
      "id_str" : "40383354",
      "id" : 40383354
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TDi",
      "indices" : [ 19, 23 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/xY8QZzBM4I",
      "expanded_url" : "http:\/\/itdi.pro\/blog\/2013\/03\/04\/the-special-needs-issue\/",
      "display_url" : "itdi.pro\/blog\/2013\/03\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "308516430574411777",
  "text" : "RT @JosetteLB: New #TDi blog: The Special Needs Issue http:\/\/t.co\/xY8QZzBM4I by @kevchanwow @naomishema @tamaslorincz @vladkaslniecko @m ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kevin Stein",
        "screen_name" : "kevchanwow",
        "indices" : [ 65, 76 ],
        "id_str" : "144663117",
        "id" : 144663117
      }, {
        "name" : "Naomi Epstein",
        "screen_name" : "naomishema",
        "indices" : [ 77, 88 ],
        "id_str" : "228469472",
        "id" : 228469472
      }, {
        "name" : "Tamas Lorincz",
        "screen_name" : "tamaslorincz",
        "indices" : [ 89, 102 ],
        "id_str" : "24491222",
        "id" : 24491222
      }, {
        "name" : "Vladimira Chalyova",
        "screen_name" : "vladkaslniecko",
        "indices" : [ 103, 118 ],
        "id_str" : "116543200",
        "id" : 116543200
      }, {
        "name" : "Miguel Mendoza",
        "screen_name" : "mike08",
        "indices" : [ 119, 126 ],
        "id_str" : "9444972",
        "id" : 9444972
      }, {
        "name" : "Gareth Knight",
        "screen_name" : "gknightbkk",
        "indices" : [ 127, 138 ],
        "id_str" : "40383354",
        "id" : 40383354
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TDi",
        "indices" : [ 4, 8 ]
      } ],
      "urls" : [ {
        "indices" : [ 39, 61 ],
        "url" : "http:\/\/t.co\/xY8QZzBM4I",
        "expanded_url" : "http:\/\/itdi.pro\/blog\/2013\/03\/04\/the-special-needs-issue\/",
        "display_url" : "itdi.pro\/blog\/2013\/03\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "308507664634228736",
    "text" : "New #TDi blog: The Special Needs Issue http:\/\/t.co\/xY8QZzBM4I by @kevchanwow @naomishema @tamaslorincz @vladkaslniecko @mike08 @gknightbkk",
    "id" : 308507664634228736,
    "created_at" : "2013-03-04 09:22:13 +0000",
    "user" : {
      "name" : "Josette LeBlanc",
      "screen_name" : "JosetteLB",
      "protected" : false,
      "id_str" : "33503694",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/692220258900377601\/uWdvfCiP_normal.jpg",
      "id" : 33503694,
      "verified" : false
    }
  },
  "id" : 308516430574411777,
  "created_at" : "2013-03-04 09:57:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308498168092446720",
  "text" : "@EBEFL i like interactionandlearning's concepualisation of context in yr blog post",
  "id" : 308498168092446720,
  "created_at" : "2013-03-04 08:44:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308496077152215040",
  "text" : "@EBEFL acc to that chapter he refs Schmitt, N. (1997). Vocabulary learning strategies. In N. Schmitt &amp; M. McCarthy (Eds.), Vocabulary..",
  "id" : 308496077152215040,
  "created_at" : "2013-03-04 08:36:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308490414741155840",
  "text" : "@EBEFL Schmitt seems to like guessing from context as a strategy to promote in class, book publshed in 2007?",
  "id" : 308490414741155840,
  "created_at" : "2013-03-04 08:13:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John T. Spencer",
      "screen_name" : "JohnTSpencer",
      "indices" : [ 0, 13 ],
      "id_str" : "2285706270",
      "id" : 2285706270
    }, {
      "name" : "Evgeny Morozov",
      "screen_name" : "evgenymorozov",
      "indices" : [ 122, 136 ],
      "id_str" : "30331417",
      "id" : 30331417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/rA4gkFwTEl",
      "expanded_url" : "http:\/\/www.google.com\/url?q=http:\/\/www.newrepublic.com\/article\/books-and-arts\/magazine\/105703\/the-naked-and-the-ted-khanna&sa=U&ei=MEY0Ua6KHcaK0AXu7YCQBw&ved=0CBEQFjAA&usg=AFQjCNHMZmLrjWnOIgz9hfl5tZkIhZ8eag",
      "display_url" : "google.com\/url?q=http:\/\/w\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "308429650940526592",
  "geo" : { },
  "id_str" : "308472912061538304",
  "in_reply_to_user_id" : 18389166,
  "text" : "@johntspencer i like \/how \u201Cideas worth spreading\u201D become \u201Cideas no footnotes can support.\u201D\/ frm http:\/\/t.co\/rA4gkFwTEl by @evgenymorozov",
  "id" : 308472912061538304,
  "in_reply_to_status_id" : 308429650940526592,
  "created_at" : "2013-03-04 07:04:08 +0000",
  "in_reply_to_screen_name" : "spencerideas",
  "in_reply_to_user_id_str" : "18389166",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 3, 17 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/mVpoyyfG9Y",
      "expanded_url" : "http:\/\/hackeducation.com\/2013\/03\/03\/hacking-your-education-stephens-hole-in-the-wall-mitra\/",
      "display_url" : "hackeducation.com\/2013\/03\/03\/hac\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "308364309514305536",
  "text" : "RT @audreywatters: Hacking at Education: TED and Tech Entrepreneurship (my review of Dale Stephens' new book &amp; Sugata Mitra's TED Pr ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/mVpoyyfG9Y",
        "expanded_url" : "http:\/\/hackeducation.com\/2013\/03\/03\/hacking-your-education-stephens-hole-in-the-wall-mitra\/",
        "display_url" : "hackeducation.com\/2013\/03\/03\/hac\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "308255811187118081",
    "text" : "Hacking at Education: TED and Tech Entrepreneurship (my review of Dale Stephens' new book &amp; Sugata Mitra's TED Prize) http:\/\/t.co\/mVpoyyfG9Y",
    "id" : 308255811187118081,
    "created_at" : "2013-03-03 16:41:27 +0000",
    "user" : {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "protected" : false,
      "id_str" : "25388528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711668009723498496\/pauFZsdv_normal.jpg",
      "id" : 25388528,
      "verified" : false
    }
  },
  "id" : 308364309514305536,
  "created_at" : "2013-03-03 23:52:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/0l69uQMDR0",
      "expanded_url" : "http:\/\/wp.me\/p1lYoF-2C",
      "display_url" : "wp.me\/p1lYoF-2C"
    } ]
  },
  "geo" : { },
  "id_str" : "308254109901926401",
  "text" : "Encouraging Pedagogical Tinkering through the Experiential Learning Cycle http:\/\/t.co\/0l69uQMDR0 via @kevingiddens",
  "id" : 308254109901926401,
  "created_at" : "2013-03-03 16:34:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "indices" : [ 0, 13 ],
      "id_str" : "1685397408",
      "id" : 1685397408
    }, {
      "name" : "Nagehan Tunar",
      "screen_name" : "stiiiv",
      "indices" : [ 14, 21 ],
      "id_str" : "799058600",
      "id" : 799058600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307928532477173761",
  "text" : "@harrisonmike @stiiiv youse was playing hookey frm the jibber jabber u say? no ah hockey! any particular reason for yr question btw?",
  "id" : 307928532477173761,
  "created_at" : "2013-03-02 19:00:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    }, {
      "name" : "sirja",
      "screen_name" : "swisssirja",
      "indices" : [ 17, 28 ],
      "id_str" : "363694777",
      "id" : 363694777
    }, {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 29, 37 ],
      "id_str" : "20650366",
      "id" : 20650366
    }, {
      "name" : "Nikki Biddison",
      "screen_name" : "onlyincambodia",
      "indices" : [ 38, 53 ],
      "id_str" : "26354110",
      "id" : 26354110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307876732940210177",
  "geo" : { },
  "id_str" : "307928013234909184",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin @swisssirja @seburnt @onlyincambodia added another comment",
  "id" : 307928013234909184,
  "in_reply_to_status_id" : 307876732940210177,
  "created_at" : "2013-03-02 18:58:54 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nagehan Tunar",
      "screen_name" : "stiiiv",
      "indices" : [ 0, 7 ],
      "id_str" : "799058600",
      "id" : 799058600
    }, {
      "name" : "Hybrid Pedagogy",
      "screen_name" : "HybridPed",
      "indices" : [ 8, 18 ],
      "id_str" : "416608920",
      "id" : 416608920
    }, {
      "name" : "Dan Blickensderfer",
      "screen_name" : "Dan_Blick",
      "indices" : [ 19, 29 ],
      "id_str" : "188554158",
      "id" : 188554158
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/IM9fsCgkyn",
      "expanded_url" : "http:\/\/hawksey.info\/tagsexplorer\/?key=txvQFGaRPV0juVyLGkwOlDw&sheet=oaw",
      "display_url" : "hawksey.info\/tagsexplorer\/?\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "307849834742837249",
  "geo" : { },
  "id_str" : "307855414089883648",
  "in_reply_to_user_id" : 69068757,
  "text" : "@stiiiv @HybridPed @Dan_Blick thx trying to ctch up disc using http:\/\/t.co\/IM9fsCgkyn - best in goog chrome",
  "id" : 307855414089883648,
  "in_reply_to_status_id" : 307849834742837249,
  "created_at" : "2013-03-02 14:10:25 +0000",
  "in_reply_to_screen_name" : "stiivkirk",
  "in_reply_to_user_id_str" : "69068757",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chadsansing",
      "screen_name" : "chadsansing",
      "indices" : [ 0, 12 ],
      "id_str" : "76810409",
      "id" : 76810409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/jVknjpNYw4",
      "expanded_url" : "http:\/\/fr.scribd.com\/doc\/40076481\/Seiter-InternetPlayground",
      "display_url" : "fr.scribd.com\/doc\/40076481\/S\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "307840298963312640",
  "in_reply_to_user_id" : 76810409,
  "text" : "@chadsansing am reading http:\/\/t.co\/jVknjpNYw4 and only realise now that US clsrm in The Evaluation is now not near future!",
  "id" : 307840298963312640,
  "created_at" : "2013-03-02 13:10:21 +0000",
  "in_reply_to_screen_name" : "chadsansing",
  "in_reply_to_user_id_str" : "76810409",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nagehan Tunar",
      "screen_name" : "stiiiv",
      "indices" : [ 0, 7 ],
      "id_str" : "799058600",
      "id" : 799058600
    }, {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "indices" : [ 8, 21 ],
      "id_str" : "1685397408",
      "id" : 1685397408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307832509847179264",
  "geo" : { },
  "id_str" : "307833545454411777",
  "in_reply_to_user_id" : 69068757,
  "text" : "@stiiiv @harrisonmike thx for yr ruminations passed the time while keeping eye on baby :)",
  "id" : 307833545454411777,
  "in_reply_to_status_id" : 307832509847179264,
  "created_at" : "2013-03-02 12:43:31 +0000",
  "in_reply_to_screen_name" : "stiivkirk",
  "in_reply_to_user_id_str" : "69068757",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chadsansing",
      "screen_name" : "chadsansing",
      "indices" : [ 3, 15 ],
      "id_str" : "76810409",
      "id" : 76810409
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "demcomp",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/XKKkOoI32e",
      "expanded_url" : "http:\/\/Classroots.org",
      "display_url" : "Classroots.org"
    }, {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/wkWdgRFBAO",
      "expanded_url" : "http:\/\/bit.ly\/Wna878",
      "display_url" : "bit.ly\/Wna878"
    } ]
  },
  "geo" : { },
  "id_str" : "307832062717607936",
  "text" : "RT @chadsansing: \"Collaboration as play\" on http:\/\/t.co\/XKKkOoI32e http:\/\/t.co\/wkWdgRFBAO fun w\/ coordinates in Scratch, Minecraft, &amp ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "demcomp",
        "indices" : [ 133, 141 ]
      } ],
      "urls" : [ {
        "indices" : [ 27, 49 ],
        "url" : "http:\/\/t.co\/XKKkOoI32e",
        "expanded_url" : "http:\/\/Classroots.org",
        "display_url" : "Classroots.org"
      }, {
        "indices" : [ 50, 72 ],
        "url" : "http:\/\/t.co\/wkWdgRFBAO",
        "expanded_url" : "http:\/\/bit.ly\/Wna878",
        "display_url" : "bit.ly\/Wna878"
      } ]
    },
    "geo" : { },
    "id_str" : "307828095740674048",
    "text" : "\"Collaboration as play\" on http:\/\/t.co\/XKKkOoI32e http:\/\/t.co\/wkWdgRFBAO fun w\/ coordinates in Scratch, Minecraft, &amp; tchr collab #demcomp",
    "id" : 307828095740674048,
    "created_at" : "2013-03-02 12:21:51 +0000",
    "user" : {
      "name" : "chadsansing",
      "screen_name" : "chadsansing",
      "protected" : false,
      "id_str" : "76810409",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712740640111652869\/NvEwLRy__normal.jpg",
      "id" : 76810409,
      "verified" : false
    }
  },
  "id" : 307832062717607936,
  "created_at" : "2013-03-02 12:37:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nagehan Tunar",
      "screen_name" : "stiiiv",
      "indices" : [ 0, 7 ],
      "id_str" : "799058600",
      "id" : 799058600
    }, {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "indices" : [ 8, 21 ],
      "id_str" : "1685397408",
      "id" : 1685397408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307829643908636672",
  "geo" : { },
  "id_str" : "307830392969379840",
  "in_reply_to_user_id" : 69068757,
  "text" : "@stiiiv @harrisonmike agreed so searching for something is v diff from creating that something? mike's initial Q.",
  "id" : 307830392969379840,
  "in_reply_to_status_id" : 307829643908636672,
  "created_at" : "2013-03-02 12:30:59 +0000",
  "in_reply_to_screen_name" : "stiivkirk",
  "in_reply_to_user_id_str" : "69068757",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nagehan Tunar",
      "screen_name" : "stiiiv",
      "indices" : [ 0, 7 ],
      "id_str" : "799058600",
      "id" : 799058600
    }, {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "indices" : [ 8, 21 ],
      "id_str" : "1685397408",
      "id" : 1685397408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307827244062101506",
  "geo" : { },
  "id_str" : "307828188468371457",
  "in_reply_to_user_id" : 69068757,
  "text" : "@stiiiv @harrisonmike a phys would rely less on stored knowledge and work things out from first principles more so than a chemist?",
  "id" : 307828188468371457,
  "in_reply_to_status_id" : 307827244062101506,
  "created_at" : "2013-03-02 12:22:13 +0000",
  "in_reply_to_screen_name" : "stiivkirk",
  "in_reply_to_user_id_str" : "69068757",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/9DBeUte4LD",
      "expanded_url" : "http:\/\/www.counterpunch.org\/2013\/03\/01\/a-robot-didnt-steal-your-job\/",
      "display_url" : "counterpunch.org\/2013\/03\/01\/a-r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "307827065787404290",
  "text" : "A robot didn't steal your job http:\/\/t.co\/9DBeUte4LD",
  "id" : 307827065787404290,
  "created_at" : "2013-03-02 12:17:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nagehan Tunar",
      "screen_name" : "stiiiv",
      "indices" : [ 0, 7 ],
      "id_str" : "799058600",
      "id" : 799058600
    }, {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "indices" : [ 8, 21 ],
      "id_str" : "1685397408",
      "id" : 1685397408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307821795506012162",
  "geo" : { },
  "id_str" : "307823219048587264",
  "in_reply_to_user_id" : 69068757,
  "text" : "@stiiiv @harrisonmike field dependent? genralisation alert!  e.g. amount of memorisation btw say chemist and physicist very diff?c &gt; p?",
  "id" : 307823219048587264,
  "in_reply_to_status_id" : 307821795506012162,
  "created_at" : "2013-03-02 12:02:29 +0000",
  "in_reply_to_screen_name" : "stiivkirk",
  "in_reply_to_user_id_str" : "69068757",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nagehan Tunar",
      "screen_name" : "stiiiv",
      "indices" : [ 0, 7 ],
      "id_str" : "799058600",
      "id" : 799058600
    }, {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "indices" : [ 8, 21 ],
      "id_str" : "1685397408",
      "id" : 1685397408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307809205597917184",
  "geo" : { },
  "id_str" : "307818114320584704",
  "in_reply_to_user_id" : 69068757,
  "text" : "@stiiiv @harrisonmike what is a fact? being able to look for something is different from producing that something i wld say, maybe ;)",
  "id" : 307818114320584704,
  "in_reply_to_status_id" : 307809205597917184,
  "created_at" : "2013-03-02 11:42:12 +0000",
  "in_reply_to_screen_name" : "stiivkirk",
  "in_reply_to_user_id_str" : "69068757",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nagehan Tunar",
      "screen_name" : "stiiiv",
      "indices" : [ 0, 7 ],
      "id_str" : "799058600",
      "id" : 799058600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307815211841232896",
  "geo" : { },
  "id_str" : "307817473409966080",
  "in_reply_to_user_id" : 69068757,
  "text" : "@stiiiv sounds like a medical condition? :)",
  "id" : 307817473409966080,
  "in_reply_to_status_id" : 307815211841232896,
  "created_at" : "2013-03-02 11:39:39 +0000",
  "in_reply_to_screen_name" : "stiivkirk",
  "in_reply_to_user_id_str" : "69068757",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chia Suan Chong",
      "screen_name" : "chiasuan",
      "indices" : [ 0, 9 ],
      "id_str" : "71588589",
      "id" : 71588589
    }, {
      "name" : "John Hughes",
      "screen_name" : "johnhugheselt",
      "indices" : [ 83, 97 ],
      "id_str" : "20094894",
      "id" : 20094894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/U9axULrIKD",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=XxFJiIntvvU",
      "display_url" : "youtube.com\/watch?v=XxFJiI\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "307801304837808128",
  "geo" : { },
  "id_str" : "307817060539437057",
  "in_reply_to_user_id" : 71588589,
  "text" : "@chiasuan hi chia have u seen this video http:\/\/t.co\/U9axULrIKD from 3:40 mark? HT @johnhugheselt",
  "id" : 307817060539437057,
  "in_reply_to_status_id" : 307801304837808128,
  "created_at" : "2013-03-02 11:38:00 +0000",
  "in_reply_to_screen_name" : "chiasuan",
  "in_reply_to_user_id_str" : "71588589",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John T. Spencer",
      "screen_name" : "JohnTSpencer",
      "indices" : [ 3, 16 ],
      "id_str" : "2285706270",
      "id" : 2285706270
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edchat",
      "indices" : [ 97, 104 ]
    }, {
      "text" : "edtech",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/mn6LReFO2a",
      "expanded_url" : "http:\/\/bit.ly\/Xtyv09",
      "display_url" : "bit.ly\/Xtyv09"
    } ]
  },
  "geo" : { },
  "id_str" : "307623150986862592",
  "text" : "RT @johntspencer: edrethink: My Take on \"What Most Schools Don't Teach.\" http:\/\/t.co\/mn6LReFO2a  #edchat (how about tech criticism?) #edtech",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "edchat",
        "indices" : [ 79, 86 ]
      }, {
        "text" : "edtech",
        "indices" : [ 115, 122 ]
      } ],
      "urls" : [ {
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/mn6LReFO2a",
        "expanded_url" : "http:\/\/bit.ly\/Xtyv09",
        "display_url" : "bit.ly\/Xtyv09"
      } ]
    },
    "geo" : { },
    "id_str" : "307622046161063936",
    "text" : "edrethink: My Take on \"What Most Schools Don't Teach.\" http:\/\/t.co\/mn6LReFO2a  #edchat (how about tech criticism?) #edtech",
    "id" : 307622046161063936,
    "created_at" : "2013-03-01 22:43:05 +0000",
    "user" : {
      "name" : "John Spencer",
      "screen_name" : "spencerideas",
      "protected" : false,
      "id_str" : "18389166",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751913559160795136\/eU7NtYy4_normal.jpg",
      "id" : 18389166,
      "verified" : false
    }
  },
  "id" : 307623150986862592,
  "created_at" : "2013-03-01 22:47:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John T. Spencer",
      "screen_name" : "JohnTSpencer",
      "indices" : [ 0, 13 ],
      "id_str" : "2285706270",
      "id" : 2285706270
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307622046161063936",
  "geo" : { },
  "id_str" : "307623136080314368",
  "in_reply_to_user_id" : 18389166,
  "text" : "@johntspencer good effort to plug the computing memory hole!",
  "id" : 307623136080314368,
  "in_reply_to_status_id" : 307622046161063936,
  "created_at" : "2013-03-01 22:47:25 +0000",
  "in_reply_to_screen_name" : "spencerideas",
  "in_reply_to_user_id_str" : "18389166",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John T. Spencer",
      "screen_name" : "JohnTSpencer",
      "indices" : [ 0, 13 ],
      "id_str" : "2285706270",
      "id" : 2285706270
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307505373525467138",
  "geo" : { },
  "id_str" : "307506576997109760",
  "in_reply_to_user_id" : 18389166,
  "text" : "@johntspencer wow 6 years, Congrats! here's to more years! :)",
  "id" : 307506576997109760,
  "in_reply_to_status_id" : 307505373525467138,
  "created_at" : "2013-03-01 15:04:15 +0000",
  "in_reply_to_screen_name" : "spencerideas",
  "in_reply_to_user_id_str" : "18389166",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/6jYs6jeUV5",
      "expanded_url" : "http:\/\/liliputing.com\/2013\/02\/drivedroid-lets-you-boot-linux-on-a-pc-by-plugging-in-your-rooted-android-phone.html",
      "display_url" : "liliputing.com\/2013\/02\/drived\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "307506131876597760",
  "text" : "Very neat&gt;&gt;DriveDroid lets you boot Linux on a PC by plugging in your (rooted) Android phone http:\/\/t.co\/6jYs6jeUV5",
  "id" : 307506131876597760,
  "created_at" : "2013-03-01 15:02:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stevemuir",
      "screen_name" : "steve_muir",
      "indices" : [ 0, 11 ],
      "id_str" : "18537988",
      "id" : 18537988
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307463530704171008",
  "geo" : { },
  "id_str" : "307492936696872960",
  "in_reply_to_user_id" : 18537988,
  "text" : "@steve_muir Cheers Steve, enjoy the w.e, :)",
  "id" : 307492936696872960,
  "in_reply_to_status_id" : 307463530704171008,
  "created_at" : "2013-03-01 14:10:03 +0000",
  "in_reply_to_screen_name" : "steve_muir",
  "in_reply_to_user_id_str" : "18537988",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "Ava Fruin",
      "screen_name" : "avafruin",
      "indices" : [ 12, 21 ],
      "id_str" : "22528522",
      "id" : 22528522
    }, {
      "name" : "Sue Annan",
      "screen_name" : "SueAnnan",
      "indices" : [ 22, 31 ],
      "id_str" : "136001411",
      "id" : 136001411
    }, {
      "name" : "Laura Phelps",
      "screen_name" : "pterolaur",
      "indices" : [ 32, 42 ],
      "id_str" : "90093887",
      "id" : 90093887
    }, {
      "name" : "Carol Goodey",
      "screen_name" : "cgoodey",
      "indices" : [ 43, 51 ],
      "id_str" : "26606833",
      "id" : 26606833
    }, {
      "name" : "Laura Patsko",
      "screen_name" : "lauraahaha",
      "indices" : [ 52, 63 ],
      "id_str" : "97957137",
      "id" : 97957137
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307477923273773056",
  "geo" : { },
  "id_str" : "307492668836040704",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan @avafruin @SueAnnan @pterolaur @cgoodey @lauraahaha thx Leo! Hope Fri is gng good fr u :)",
  "id" : 307492668836040704,
  "in_reply_to_status_id" : 307477923273773056,
  "created_at" : "2013-03-01 14:08:59 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "Mieke Kenis",
      "screen_name" : "mkofab",
      "indices" : [ 12, 19 ],
      "id_str" : "96527212",
      "id" : 96527212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307429266214236160",
  "geo" : { },
  "id_str" : "307455728015257600",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan @mkofab many thanks for share Leo and Mieke! have a great w\/e!",
  "id" : 307455728015257600,
  "in_reply_to_status_id" : 307429266214236160,
  "created_at" : "2013-03-01 11:42:12 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 114, 125 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/jVknjpNYw4",
      "expanded_url" : "http:\/\/fr.scribd.com\/doc\/40076481\/Seiter-InternetPlayground",
      "display_url" : "fr.scribd.com\/doc\/40076481\/S\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "307454668366299137",
  "text" : "Ellen Seiter The Internet Playground Children\u2019s Access, Entertainment, and Miseducation http:\/\/t.co\/jVknjpNYw4 HT @tornhalves",
  "id" : 307454668366299137,
  "created_at" : "2013-03-01 11:37:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 12, 23 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/dJ7FCeTAaO",
      "expanded_url" : "http:\/\/www.digitalcounterrevolution.co.uk\/2012\/sugata-mitra-and-the-enemies-within\/",
      "display_url" : "digitalcounterrevolution.co.uk\/2012\/sugata-mi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "307453244135858176",
  "text" : "grt cmmt by @tornhalves re Mitra ...making other holes in the walls of slums that have holograms of piles of money...http:\/\/t.co\/dJ7FCeTAaO",
  "id" : 307453244135858176,
  "created_at" : "2013-03-01 11:32:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 3, 13 ],
      "id_str" : "681813",
      "id" : 681813
    }, {
      "name" : "Mark Hurst",
      "screen_name" : "markhurst",
      "indices" : [ 91, 101 ],
      "id_str" : "14390164",
      "id" : 14390164
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/wiP0v9LSI4",
      "expanded_url" : "http:\/\/creativegood.com\/blog\/the-google-glass-feature-no-one-is-talking-about\/",
      "display_url" : "creativegood.com\/blog\/the-googl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "307420932358688769",
  "text" : "RT @avantgame: The Google Glass feature no one is talking about http:\/\/t.co\/wiP0v9LSI4 via @markhurst",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mark Hurst",
        "screen_name" : "markhurst",
        "indices" : [ 76, 86 ],
        "id_str" : "14390164",
        "id" : 14390164
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/wiP0v9LSI4",
        "expanded_url" : "http:\/\/creativegood.com\/blog\/the-google-glass-feature-no-one-is-talking-about\/",
        "display_url" : "creativegood.com\/blog\/the-googl\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "307230989619433472",
    "text" : "The Google Glass feature no one is talking about http:\/\/t.co\/wiP0v9LSI4 via @markhurst",
    "id" : 307230989619433472,
    "created_at" : "2013-02-28 20:49:10 +0000",
    "user" : {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "protected" : false,
      "id_str" : "681813",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000116152853\/47c4501ee2d80e97b423129fe0db016a_normal.jpeg",
      "id" : 681813,
      "verified" : true
    }
  },
  "id" : 307420932358688769,
  "created_at" : "2013-03-01 09:23:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gareth davies",
      "screen_name" : "reasons4",
      "indices" : [ 3, 12 ],
      "id_str" : "413454135",
      "id" : 413454135
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "shortstory",
      "indices" : [ 89, 100 ]
    }, {
      "text" : "writing",
      "indices" : [ 101, 109 ]
    }, {
      "text" : "fiction",
      "indices" : [ 110, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/RHewzXFgB8",
      "expanded_url" : "http:\/\/garethsrorystorycubes.blogspot.co.uk\/2013\/03\/angel.html",
      "display_url" : "garethsrorystorycubes.blogspot.co.uk\/2013\/03\/angel.\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "307402482030628864",
  "text" : "RT @reasons4: To celebrate welsh national day a nice gentle story http:\/\/t.co\/RHewzXFgB8 #shortstory #writing #fiction",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "shortstory",
        "indices" : [ 75, 86 ]
      }, {
        "text" : "writing",
        "indices" : [ 87, 95 ]
      }, {
        "text" : "fiction",
        "indices" : [ 96, 104 ]
      } ],
      "urls" : [ {
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/RHewzXFgB8",
        "expanded_url" : "http:\/\/garethsrorystorycubes.blogspot.co.uk\/2013\/03\/angel.html",
        "display_url" : "garethsrorystorycubes.blogspot.co.uk\/2013\/03\/angel.\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "307394501280952320",
    "text" : "To celebrate welsh national day a nice gentle story http:\/\/t.co\/RHewzXFgB8 #shortstory #writing #fiction",
    "id" : 307394501280952320,
    "created_at" : "2013-03-01 07:38:54 +0000",
    "user" : {
      "name" : "gareth davies",
      "screen_name" : "reasons4",
      "protected" : false,
      "id_str" : "413454135",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1640992210\/image_normal.jpg",
      "id" : 413454135,
      "verified" : false
    }
  },
  "id" : 307402482030628864,
  "created_at" : "2013-03-01 08:10:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 3, 14 ],
      "id_str" : "144663117",
      "id" : 144663117
    }, {
      "name" : "Josette LeBlanc",
      "screen_name" : "JosetteLB",
      "indices" : [ 16, 26 ],
      "id_str" : "33503694",
      "id" : 33503694
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EFL",
      "indices" : [ 128, 132 ]
    }, {
      "text" : "moving",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/60Labku39q",
      "expanded_url" : "http:\/\/tokenteach.wordpress.com\/2013\/03\/01\/the-mirror-that-sees-me-a-short-story\/",
      "display_url" : "tokenteach.wordpress.com\/2013\/03\/01\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "307399286218432514",
  "text" : "RT @kevchanwow: @JosetteLB has a short story about real magic and it has everything to do with LEARNING: http:\/\/t.co\/60Labku39q #EFL #moving",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Josette LeBlanc",
        "screen_name" : "JosetteLB",
        "indices" : [ 0, 10 ],
        "id_str" : "33503694",
        "id" : 33503694
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EFL",
        "indices" : [ 112, 116 ]
      }, {
        "text" : "moving",
        "indices" : [ 117, 124 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/60Labku39q",
        "expanded_url" : "http:\/\/tokenteach.wordpress.com\/2013\/03\/01\/the-mirror-that-sees-me-a-short-story\/",
        "display_url" : "tokenteach.wordpress.com\/2013\/03\/01\/the\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "307365901911588864",
    "in_reply_to_user_id" : 33503694,
    "text" : "@JosetteLB has a short story about real magic and it has everything to do with LEARNING: http:\/\/t.co\/60Labku39q #EFL #moving",
    "id" : 307365901911588864,
    "created_at" : "2013-03-01 05:45:16 +0000",
    "in_reply_to_screen_name" : "JosetteLB",
    "in_reply_to_user_id_str" : "33503694",
    "user" : {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "protected" : false,
      "id_str" : "144663117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/559618421839507456\/nPF7dP47_normal.jpeg",
      "id" : 144663117,
      "verified" : false
    }
  },
  "id" : 307399286218432514,
  "created_at" : "2013-03-01 07:57:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 3, 14 ],
      "id_str" : "144663117",
      "id" : 144663117
    }, {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 16, 28 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PLNlove",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "fanclubMember",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/UwyxGXjD65",
      "expanded_url" : "http:\/\/lizzieserene.wordpress.com\/2013\/02\/28\/living-and-learning\/",
      "display_url" : "lizzieserene.wordpress.com\/2013\/02\/28\/liv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "307398070725914624",
  "text" : "RT @kevchanwow: @AnneHendler it's her birthday but she gives us all a birthday present with this blog post: http:\/\/t.co\/UwyxGXjD65 #PLNl ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
        "screen_name" : "AnneHendler",
        "indices" : [ 0, 12 ],
        "id_str" : "525013404",
        "id" : 525013404
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PLNlove",
        "indices" : [ 115, 123 ]
      }, {
        "text" : "fanclubMember",
        "indices" : [ 124, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/UwyxGXjD65",
        "expanded_url" : "http:\/\/lizzieserene.wordpress.com\/2013\/02\/28\/living-and-learning\/",
        "display_url" : "lizzieserene.wordpress.com\/2013\/02\/28\/liv\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "307369649442525184",
    "in_reply_to_user_id" : 525013404,
    "text" : "@AnneHendler it's her birthday but she gives us all a birthday present with this blog post: http:\/\/t.co\/UwyxGXjD65 #PLNlove #fanclubMember!",
    "id" : 307369649442525184,
    "created_at" : "2013-03-01 06:00:09 +0000",
    "in_reply_to_screen_name" : "AnneHendler",
    "in_reply_to_user_id_str" : "525013404",
    "user" : {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "protected" : false,
      "id_str" : "144663117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/559618421839507456\/nPF7dP47_normal.jpeg",
      "id" : 144663117,
      "verified" : false
    }
  },
  "id" : 307398070725914624,
  "created_at" : "2013-03-01 07:53:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
} ]