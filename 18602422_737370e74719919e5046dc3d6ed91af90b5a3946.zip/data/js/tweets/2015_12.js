Grailbird.data.tweets_2015_12 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "682546617602342913",
  "geo" : { },
  "id_str" : "682553523607842817",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish I read that initially as the menthols :) u are mint mate happy new year",
  "id" : 682553523607842817,
  "in_reply_to_status_id" : 682546617602342913,
  "created_at" : "2015-12-31 13:26:55 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 3, 14 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 77, 88 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 127, 131 ]
    }, {
      "text" : "tefl",
      "indices" : [ 132, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/xa4Vty6mI2",
      "expanded_url" : "http:\/\/buff.ly\/1IEAF8x",
      "display_url" : "buff.ly\/1IEAF8x"
    } ]
  },
  "geo" : { },
  "id_str" : "682520719457128448",
  "text" : "RT @leoselivan: The Lexical Approach and natural selection by Ivor Timmis on @hughdellar's Lexical lab https:\/\/t.co\/xa4Vty6mI2 #elt #tefl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "hugh dellar",
        "screen_name" : "hughdellar",
        "indices" : [ 61, 72 ],
        "id_str" : "88202140",
        "id" : 88202140
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "elt",
        "indices" : [ 111, 115 ]
      }, {
        "text" : "tefl",
        "indices" : [ 116, 121 ]
      } ],
      "urls" : [ {
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/xa4Vty6mI2",
        "expanded_url" : "http:\/\/buff.ly\/1IEAF8x",
        "display_url" : "buff.ly\/1IEAF8x"
      } ]
    },
    "geo" : { },
    "id_str" : "682517618025205760",
    "text" : "The Lexical Approach and natural selection by Ivor Timmis on @hughdellar's Lexical lab https:\/\/t.co\/xa4Vty6mI2 #elt #tefl",
    "id" : 682517618025205760,
    "created_at" : "2015-12-31 11:04:15 +0000",
    "user" : {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "protected" : false,
      "id_str" : "408365496",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/460546508601819136\/12ivDBb__normal.jpeg",
      "id" : 408365496,
      "verified" : false
    }
  },
  "id" : 682520719457128448,
  "created_at" : "2015-12-31 11:16:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DMLL",
      "screen_name" : "DiMLL",
      "indices" : [ 42, 48 ],
      "id_str" : "1114312832",
      "id" : 1114312832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/U3jfbLHFcH",
      "expanded_url" : "http:\/\/digitalmobilelanguagelearning.org\/2015\/11\/kaiten-presen\/",
      "display_url" : "digitalmobilelanguagelearning.org\/2015\/11\/kaiten\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "682220204085088256",
  "text" : "Kaiten Presen https:\/\/t.co\/U3jfbLHFcH via @DiMLL",
  "id" : 682220204085088256,
  "created_at" : "2015-12-30 15:22:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 52, 68 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/pdp7HJ0CB0",
      "expanded_url" : "http:\/\/wp.me\/p40HiS-aX",
      "display_url" : "wp.me\/p40HiS-aX"
    } ]
  },
  "geo" : { },
  "id_str" : "682202589027524608",
  "text" : "Why racism isn't racism https:\/\/t.co\/pdp7HJ0CB0 via @wordpressdotcom",
  "id" : 682202589027524608,
  "created_at" : "2015-12-30 14:12:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusresources",
      "indices" : [ 91, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/HbkRLkjuPd",
      "expanded_url" : "http:\/\/www.corpus4u.org\/threads\/9628\/",
      "display_url" : "corpus4u.org\/threads\/9628\/"
    } ]
  },
  "geo" : { },
  "id_str" : "681964251590836226",
  "text" : "TECCL corpus Ten-thousand English Compositions of Chinese Learners https:\/\/t.co\/HbkRLkjuPd #corpusresources",
  "id" : 681964251590836226,
  "created_at" : "2015-12-29 22:25:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TES Resources",
      "screen_name" : "tesResources",
      "indices" : [ 0, 13 ],
      "id_str" : "33856511",
      "id" : 33856511
    }, {
      "name" : "IHWO YL Advisor",
      "screen_name" : "IHWO_YL_Ts",
      "indices" : [ 14, 25 ],
      "id_str" : "52217770",
      "id" : 52217770
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "681795068173377540",
  "geo" : { },
  "id_str" : "681835922590142464",
  "in_reply_to_user_id" : 33856511,
  "text" : "@tesResources @IHWO_YL_Ts a bit difficult to answer as ISS is not in zero gravity : )",
  "id" : 681835922590142464,
  "in_reply_to_status_id" : 681795068173377540,
  "created_at" : "2015-12-29 13:55:26 +0000",
  "in_reply_to_screen_name" : "tesResources",
  "in_reply_to_user_id_str" : "33856511",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 3, 18 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/Qi8YMgoJ7F",
      "expanded_url" : "https:\/\/canlloparot.wordpress.com\/2015\/12\/28\/a-final-tilt-at-the-windmill-of-thornburys-a-to-z\/",
      "display_url" : "canlloparot.wordpress.com\/2015\/12\/28\/a-f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "681833805783691264",
  "text" : "RT @GeoffreyJordan: I've added 2 appendices to my post on Thornbury and POS https:\/\/t.co\/Qi8YMgoJ7F 1. Why you can't prove a theory is true\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/Qi8YMgoJ7F",
        "expanded_url" : "https:\/\/canlloparot.wordpress.com\/2015\/12\/28\/a-final-tilt-at-the-windmill-of-thornburys-a-to-z\/",
        "display_url" : "canlloparot.wordpress.com\/2015\/12\/28\/a-f\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "681832205350531072",
    "text" : "I've added 2 appendices to my post on Thornbury and POS https:\/\/t.co\/Qi8YMgoJ7F 1. Why you can't prove a theory is true. 2. Empiricism.",
    "id" : 681832205350531072,
    "created_at" : "2015-12-29 13:40:40 +0000",
    "user" : {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "protected" : false,
      "id_str" : "334332424",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/455317817537986561\/SD4wNKO3_normal.jpeg",
      "id" : 334332424,
      "verified" : false
    }
  },
  "id" : 681833805783691264,
  "created_at" : "2015-12-29 13:47:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "renbenbear",
      "screen_name" : "renbenbear",
      "indices" : [ 3, 14 ],
      "id_str" : "20035987",
      "id" : 20035987
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/renbenbear\/status\/681441405361848320\/photo\/1",
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/qzn5QrIYS4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CXT3VzwWcAAJ6wT.jpg",
      "id_str" : "681441397682106368",
      "id" : 681441397682106368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXT3VzwWcAAJ6wT.jpg",
      "sizes" : [ {
        "h" : 360,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 372,
        "resize" : "fit",
        "w" : 620
      }, {
        "h" : 204,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 372,
        "resize" : "fit",
        "w" : 620
      } ],
      "display_url" : "pic.twitter.com\/qzn5QrIYS4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "681831837950439424",
  "text" : "RT @renbenbear: Tory economy: https:\/\/t.co\/qzn5QrIYS4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/renbenbear\/status\/681441405361848320\/photo\/1",
        "indices" : [ 14, 37 ],
        "url" : "https:\/\/t.co\/qzn5QrIYS4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CXT3VzwWcAAJ6wT.jpg",
        "id_str" : "681441397682106368",
        "id" : 681441397682106368,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXT3VzwWcAAJ6wT.jpg",
        "sizes" : [ {
          "h" : 360,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 372,
          "resize" : "fit",
          "w" : 620
        }, {
          "h" : 204,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 372,
          "resize" : "fit",
          "w" : 620
        } ],
        "display_url" : "pic.twitter.com\/qzn5QrIYS4"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "681441405361848320",
    "text" : "Tory economy: https:\/\/t.co\/qzn5QrIYS4",
    "id" : 681441405361848320,
    "created_at" : "2015-12-28 11:47:46 +0000",
    "user" : {
      "name" : "renbenbear",
      "screen_name" : "renbenbear",
      "protected" : false,
      "id_str" : "20035987",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/463422300873060352\/UhjwTsQB_normal.jpeg",
      "id" : 20035987,
      "verified" : false
    }
  },
  "id" : 681831837950439424,
  "created_at" : "2015-12-29 13:39:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DonaldTrump",
      "indices" : [ 102, 114 ]
    }, {
      "text" : "Trump2016",
      "indices" : [ 115, 125 ]
    }, {
      "text" : "HillaryClinton",
      "indices" : [ 126, 140 ]
    }, {
      "text" : "Hillary2016",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/OwotIPeWD5",
      "expanded_url" : "http:\/\/johnhilley.blogspot.co.uk\/2015\/12\/donald-trump-just-mad-haircut-of-deeper.html",
      "display_url" : "johnhilley.blogspot.co.uk\/2015\/12\/donald\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "681827827013038080",
  "text" : "RT @johnwhilley: Donald Trump, just the mad haircut of deeper fascist America https:\/\/t.co\/OwotIPeWD5 #DonaldTrump #Trump2016 #HillaryClint\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DonaldTrump",
        "indices" : [ 85, 97 ]
      }, {
        "text" : "Trump2016",
        "indices" : [ 98, 108 ]
      }, {
        "text" : "HillaryClinton",
        "indices" : [ 109, 124 ]
      }, {
        "text" : "Hillary2016",
        "indices" : [ 125, 137 ]
      } ],
      "urls" : [ {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/OwotIPeWD5",
        "expanded_url" : "http:\/\/johnhilley.blogspot.co.uk\/2015\/12\/donald-trump-just-mad-haircut-of-deeper.html",
        "display_url" : "johnhilley.blogspot.co.uk\/2015\/12\/donald\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "681822078014746624",
    "text" : "Donald Trump, just the mad haircut of deeper fascist America https:\/\/t.co\/OwotIPeWD5 #DonaldTrump #Trump2016 #HillaryClinton #Hillary2016",
    "id" : 681822078014746624,
    "created_at" : "2015-12-29 13:00:25 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 681827827013038080,
  "created_at" : "2015-12-29 13:23:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Raquel Parra",
      "screen_name" : "rparranunez",
      "indices" : [ 0, 12 ],
      "id_str" : "1249688144",
      "id" : 1249688144
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "681246708748124160",
  "geo" : { },
  "id_str" : "681448815249993728",
  "in_reply_to_user_id" : 1249688144,
  "text" : "@rparranunez hi thanks very much for sharing :)",
  "id" : 681448815249993728,
  "in_reply_to_status_id" : 681246708748124160,
  "created_at" : "2015-12-28 12:17:12 +0000",
  "in_reply_to_screen_name" : "rparranunez",
  "in_reply_to_user_id_str" : "1249688144",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "indices" : [ 0, 10 ],
      "id_str" : "577931950",
      "id" : 577931950
    }, {
      "name" : "Patricia Brenes",
      "screen_name" : "patriciambr",
      "indices" : [ 11, 23 ],
      "id_str" : "35764443",
      "id" : 35764443
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "681133772893478912",
  "geo" : { },
  "id_str" : "681139656239517696",
  "in_reply_to_user_id" : 577931950,
  "text" : "@RudyLoock @patriciambr hi sorry not used antpconc hopefully Rudy's suggestion helps?",
  "id" : 681139656239517696,
  "in_reply_to_status_id" : 681133772893478912,
  "created_at" : "2015-12-27 15:48:43 +0000",
  "in_reply_to_screen_name" : "RudyLoock",
  "in_reply_to_user_id_str" : "577931950",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 50, 66 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/cCuYtyQjgn",
      "expanded_url" : "http:\/\/wp.me\/p7186F-25",
      "display_url" : "wp.me\/p7186F-25"
    } ]
  },
  "geo" : { },
  "id_str" : "680692649154736129",
  "text" : "Student thinking time https:\/\/t.co\/cCuYtyQjgn via @wordpressdotcom",
  "id" : 680692649154736129,
  "created_at" : "2015-12-26 10:12:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "4TUNE Teller App",
      "screen_name" : "4tunetellernet",
      "indices" : [ 3, 18 ],
      "id_str" : "467634146",
      "id" : 467634146
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/zDJRJOkjev",
      "expanded_url" : "https:\/\/twitter.com\/gotanda\/status\/680342179559137281",
      "display_url" : "twitter.com\/gotanda\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "680351384236081152",
  "text" : ":) @4tunetellernet  https:\/\/t.co\/zDJRJOkjev",
  "id" : 680351384236081152,
  "created_at" : "2015-12-25 11:36:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "YouAintNoChristianBruv",
      "indices" : [ 119, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "680054265264664576",
  "text" : "RT @pchallinor: It is easier for a rich boy's todger to pass through a pig's mouth than for a poor man to enter Heaven #YouAintNoChristianB\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "YouAintNoChristianBruv",
        "indices" : [ 103, 126 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "680049853070766080",
    "text" : "It is easier for a rich boy's todger to pass through a pig's mouth than for a poor man to enter Heaven #YouAintNoChristianBruv",
    "id" : 680049853070766080,
    "created_at" : "2015-12-24 15:38:14 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 680054265264664576,
  "created_at" : "2015-12-24 15:55:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/cjitnMdFef",
      "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2015\/12\/holy-britishness.html",
      "display_url" : "thecurmudgeonly.blogspot.co.uk\/2015\/12\/holy-b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "680024147557224449",
  "text" : "RT @pchallinor: New mudgeonry: Holy Britishness https:\/\/t.co\/cjitnMdFef",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 32, 55 ],
        "url" : "https:\/\/t.co\/cjitnMdFef",
        "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2015\/12\/holy-britishness.html",
        "display_url" : "thecurmudgeonly.blogspot.co.uk\/2015\/12\/holy-b\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "680017259948077056",
    "text" : "New mudgeonry: Holy Britishness https:\/\/t.co\/cjitnMdFef",
    "id" : 680017259948077056,
    "created_at" : "2015-12-24 13:28:43 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 680024147557224449,
  "created_at" : "2015-12-24 13:56:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "679971884658593792",
  "geo" : { },
  "id_str" : "679992845495828480",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish all the best to you and yours : )",
  "id" : 679992845495828480,
  "in_reply_to_status_id" : 679971884658593792,
  "created_at" : "2015-12-24 11:51:42 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 84, 95 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/QFzssXfrnj",
      "expanded_url" : "http:\/\/www.digitalcounterrevolution.co.uk\/2015\/radical-digital-connectivity-myth\/",
      "display_url" : "digitalcounterrevolution.co.uk\/2015\/radical-d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "679990173594193920",
  "text" : "\"Digital natives of the world unite; you have nothing to lose but your teachers\" by\n@tornhalves https:\/\/t.co\/QFzssXfrnj",
  "id" : 679990173594193920,
  "created_at" : "2015-12-24 11:41:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hana Tich\u00E1",
      "screen_name" : "HanaTicha",
      "indices" : [ 0, 10 ],
      "id_str" : "512296705",
      "id" : 512296705
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "679967132902363136",
  "geo" : { },
  "id_str" : "679988724269236224",
  "in_reply_to_user_id" : 512296705,
  "text" : "@HanaTicha yr very welcome Hana, hope u have a restful holiday : )",
  "id" : 679988724269236224,
  "in_reply_to_status_id" : 679967132902363136,
  "created_at" : "2015-12-24 11:35:20 +0000",
  "in_reply_to_screen_name" : "HanaTicha",
  "in_reply_to_user_id_str" : "512296705",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Gaughan",
      "screen_name" : "AnthonyGaughan",
      "indices" : [ 0, 15 ],
      "id_str" : "245975798",
      "id" : 245975798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "679611217632190464",
  "geo" : { },
  "id_str" : "679727514479124480",
  "in_reply_to_user_id" : 18602422,
  "text" : "@AnthonyGaughan a pleasure :)",
  "id" : 679727514479124480,
  "in_reply_to_status_id" : 679611217632190464,
  "created_at" : "2015-12-23 18:17:22 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 103, 114 ]
    }, {
      "text" : "corpusresources",
      "indices" : [ 115, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/JkbXI2WikN",
      "expanded_url" : "http:\/\/nav4.stringnet.org\/index.php",
      "display_url" : "nav4.stringnet.org\/index.php"
    } ]
  },
  "geo" : { },
  "id_str" : "679635711247708160",
  "text" : "new version of stringnet is out , collocation feature and new pattern features https:\/\/t.co\/JkbXI2WikN #corpusmooc #corpusresources",
  "id" : 679635711247708160,
  "created_at" : "2015-12-23 12:12:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hana Tich\u00E1",
      "screen_name" : "HanaTicha",
      "indices" : [ 47, 57 ],
      "id_str" : "512296705",
      "id" : 512296705
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/fAE8Yrq6yu",
      "expanded_url" : "http:\/\/wp.me\/p6aVNf-vM",
      "display_url" : "wp.me\/p6aVNf-vM"
    } ]
  },
  "geo" : { },
  "id_str" : "679612858183905280",
  "text" : "C'mon, let's speak https:\/\/t.co\/fAE8Yrq6yu via @HanaTicha",
  "id" : 679612858183905280,
  "created_at" : "2015-12-23 10:41:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Gaughan",
      "screen_name" : "AnthonyGaughan",
      "indices" : [ 85, 100 ],
      "id_str" : "245975798",
      "id" : 245975798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/QTbWJhxgNK",
      "expanded_url" : "http:\/\/teachertrainingunplugged.com\/unplugged-radio-episode-5-teaching-without-terminology\/",
      "display_url" : "teachertrainingunplugged.com\/unplugged-radi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "679611217632190464",
  "text" : "Unplugged Radio Episode 5 - teaching without terminology https:\/\/t.co\/QTbWJhxgNK via @AnthonyGaughan",
  "id" : 679611217632190464,
  "created_at" : "2015-12-23 10:35:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/sueRwocKVL",
      "expanded_url" : "http:\/\/chronicle.com\/article\/What-Its-Like-to-Be-Noam\/234667",
      "display_url" : "chronicle.com\/article\/What-I\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "679226165819764737",
  "text" : "after the Ali-G interview \"Noam came to me afterward looking dazed. \"No more men in gold suits,\" he said, sighing.\" https:\/\/t.co\/sueRwocKVL",
  "id" : 679226165819764737,
  "created_at" : "2015-12-22 09:05:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "4TUNE Teller App",
      "screen_name" : "4tunetellernet",
      "indices" : [ 0, 15 ],
      "id_str" : "467634146",
      "id" : 467634146
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/O4gfnjKnZg",
      "expanded_url" : "https:\/\/twitter.com\/treycausey\/status\/678933791155478528",
      "display_url" : "twitter.com\/treycausey\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "678952437345099776",
  "in_reply_to_user_id" : 467634146,
  "text" : "@4tunetellernet    Any ideas of the rock track mentioned at end of article? https:\/\/t.co\/O4gfnjKnZg",
  "id" : 678952437345099776,
  "created_at" : "2015-12-21 14:57:30 +0000",
  "in_reply_to_screen_name" : "4tunetellernet",
  "in_reply_to_user_id_str" : "467634146",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/D4GH9tfmTh",
      "expanded_url" : "http:\/\/spager.home.xs4all.nl\/Scorn\/toot\/sturr.htm",
      "display_url" : "spager.home.xs4all.nl\/Scorn\/toot\/stu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "678890716307787776",
  "text" : "https:\/\/t.co\/D4GH9tfmTh Hobbits in space JG Ballard",
  "id" : 678890716307787776,
  "created_at" : "2015-12-21 10:52:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Latent Discourses",
      "screen_name" : "latentdiscourse",
      "indices" : [ 0, 16 ],
      "id_str" : "3361426301",
      "id" : 3361426301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/IvLBykBpjh",
      "expanded_url" : "https:\/\/magic.piktochart.com\/output\/3731871-muliti-word-expressions",
      "display_url" : "magic.piktochart.com\/output\/3731871\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "678736148991238148",
  "geo" : { },
  "id_str" : "678737119792222208",
  "in_reply_to_user_id" : 3361426301,
  "text" : "@latentdiscourse yeah even multi-word  units are also called multi-word expressions gah! here is a pretty picture https:\/\/t.co\/IvLBykBpjh",
  "id" : 678737119792222208,
  "in_reply_to_status_id" : 678736148991238148,
  "created_at" : "2015-12-21 00:41:54 +0000",
  "in_reply_to_screen_name" : "latentdiscourse",
  "in_reply_to_user_id_str" : "3361426301",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MarisaConstantinides",
      "screen_name" : "Marisa_C",
      "indices" : [ 0, 9 ],
      "id_str" : "18272500",
      "id" : 18272500
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/22SotR5sXF",
      "expanded_url" : "http:\/\/www.wired.com\/2014\/02\/paris-subway-remodels\/",
      "display_url" : "wired.com\/2014\/02\/paris-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "678727749712777216",
  "geo" : { },
  "id_str" : "678731798189375490",
  "in_reply_to_user_id" : 18272500,
  "text" : "@Marisa_C hmm from 2014 story about could turn (https:\/\/t.co\/22SotR5sXF) -&gt; to 2015 story of is turning?",
  "id" : 678731798189375490,
  "in_reply_to_status_id" : 678727749712777216,
  "created_at" : "2015-12-21 00:20:45 +0000",
  "in_reply_to_screen_name" : "Marisa_C",
  "in_reply_to_user_id_str" : "18272500",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Theobald",
      "screen_name" : "JamesTheo",
      "indices" : [ 58, 68 ],
      "id_str" : "87903271",
      "id" : 87903271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/IW35sYGSaQ",
      "expanded_url" : "http:\/\/wp.me\/p4osBC-gD",
      "display_url" : "wp.me\/p4osBC-gD"
    } ]
  },
  "geo" : { },
  "id_str" : "678601896026836992",
  "text" : "It's a Wonderful Battery Life https:\/\/t.co\/IW35sYGSaQ via @JamesTheo",
  "id" : 678601896026836992,
  "created_at" : "2015-12-20 15:44:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Read",
      "screen_name" : "dreadnought001",
      "indices" : [ 0, 15 ],
      "id_str" : "83207734",
      "id" : 83207734
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/woDiYd0OYM",
      "expanded_url" : "https:\/\/play.google.com\/store\/apps\/details?id=me.englishup.phave_dictionary",
      "display_url" : "play.google.com\/store\/apps\/det\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "678475422020030464",
  "geo" : { },
  "id_str" : "678499938091859968",
  "in_reply_to_user_id" : 83207734,
  "text" : "@dreadnought001 hi David u may be interested in this android app https:\/\/t.co\/woDiYd0OYM ; )",
  "id" : 678499938091859968,
  "in_reply_to_status_id" : 678475422020030464,
  "created_at" : "2015-12-20 08:59:25 +0000",
  "in_reply_to_screen_name" : "dreadnought001",
  "in_reply_to_user_id_str" : "83207734",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eily Murphy",
      "screen_name" : "eilymurphy",
      "indices" : [ 0, 11 ],
      "id_str" : "111091623",
      "id" : 111091623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "677931476990730240",
  "geo" : { },
  "id_str" : "678174562224312321",
  "in_reply_to_user_id" : 111091623,
  "text" : "@eilymurphy thanks Eily hope the  holidays have started well :)",
  "id" : 678174562224312321,
  "in_reply_to_status_id" : 677931476990730240,
  "created_at" : "2015-12-19 11:26:30 +0000",
  "in_reply_to_screen_name" : "eilymurphy",
  "in_reply_to_user_id_str" : "111091623",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fab Englishteacher",
      "screen_name" : "fabenglishteach",
      "indices" : [ 3, 19 ],
      "id_str" : "439299435",
      "id" : 439299435
    }, {
      "name" : "Gumroad",
      "screen_name" : "gumroad",
      "indices" : [ 77, 85 ],
      "id_str" : "276271004",
      "id" : 276271004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/sl3VdjgiDk",
      "expanded_url" : "https:\/\/gum.co\/DFnp",
      "display_url" : "gum.co\/DFnp"
    } ]
  },
  "geo" : { },
  "id_str" : "677856716353052672",
  "text" : "RT @fabenglishteach: 50% reduction on \"100 Activities for Fast Finishers\" on @Gumroad https:\/\/t.co\/sl3VdjgiDk with code - happyhols!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gumroad",
        "screen_name" : "gumroad",
        "indices" : [ 56, 64 ],
        "id_str" : "276271004",
        "id" : 276271004
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 88 ],
        "url" : "https:\/\/t.co\/sl3VdjgiDk",
        "expanded_url" : "https:\/\/gum.co\/DFnp",
        "display_url" : "gum.co\/DFnp"
      } ]
    },
    "geo" : { },
    "id_str" : "677804578029588480",
    "text" : "50% reduction on \"100 Activities for Fast Finishers\" on @Gumroad https:\/\/t.co\/sl3VdjgiDk with code - happyhols!",
    "id" : 677804578029588480,
    "created_at" : "2015-12-18 10:56:19 +0000",
    "user" : {
      "name" : "Fab Englishteacher",
      "screen_name" : "fabenglishteach",
      "protected" : false,
      "id_str" : "439299435",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/691540822597046272\/pxcaIY-U_normal.jpg",
      "id" : 439299435,
      "verified" : false
    }
  },
  "id" : 677856716353052672,
  "created_at" : "2015-12-18 14:23:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 76, 84 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/TmyMkN0ZJk",
      "expanded_url" : "https:\/\/youtu.be\/-DFlT1R5SoM",
      "display_url" : "youtu.be\/-DFlT1R5SoM"
    } ]
  },
  "geo" : { },
  "id_str" : "677849666390650881",
  "text" : "Bomb The World - Ft David Cameron &amp; Friends https:\/\/t.co\/TmyMkN0ZJk via @YouTube",
  "id" : 677849666390650881,
  "created_at" : "2015-12-18 13:55:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helen Legge",
      "screen_name" : "ITLegge",
      "indices" : [ 0, 8 ],
      "id_str" : "2201561838",
      "id" : 2201561838
    }, {
      "name" : "Guardian Education",
      "screen_name" : "GuardianEdu",
      "indices" : [ 9, 21 ],
      "id_str" : "24907913",
      "id" : 24907913
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "677792938030706688",
  "geo" : { },
  "id_str" : "677823019230863360",
  "in_reply_to_user_id" : 2201561838,
  "text" : "@ITLegge @GuardianEdu flip side: + casualisation in HE = don't \"own\" job &amp; its responsibilities?",
  "id" : 677823019230863360,
  "in_reply_to_status_id" : 677792938030706688,
  "created_at" : "2015-12-18 12:09:35 +0000",
  "in_reply_to_screen_name" : "ITLegge",
  "in_reply_to_user_id_str" : "2201561838",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stevemuir",
      "screen_name" : "steve_muir",
      "indices" : [ 0, 11 ],
      "id_str" : "18537988",
      "id" : 18537988
    }, {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 12, 28 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "677730855838683136",
  "geo" : { },
  "id_str" : "677818971073196032",
  "in_reply_to_user_id" : 18537988,
  "text" : "@steve_muir @getgreatenglish many thx for sharing have a good we",
  "id" : 677818971073196032,
  "in_reply_to_status_id" : 677730855838683136,
  "created_at" : "2015-12-18 11:53:30 +0000",
  "in_reply_to_screen_name" : "steve_muir",
  "in_reply_to_user_id_str" : "18537988",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EAPsteve",
      "screen_name" : "EAPstephen",
      "indices" : [ 0, 11 ],
      "id_str" : "2717005711",
      "id" : 2717005711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "677762015885180929",
  "geo" : { },
  "id_str" : "677818761890648064",
  "in_reply_to_user_id" : 2717005711,
  "text" : "@EAPstephen thx, as ever ideas like bingo listening are never original :)",
  "id" : 677818761890648064,
  "in_reply_to_status_id" : 677762015885180929,
  "created_at" : "2015-12-18 11:52:40 +0000",
  "in_reply_to_screen_name" : "EAPstephen",
  "in_reply_to_user_id_str" : "2717005711",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 57, 73 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/dPPWJis4JH",
      "expanded_url" : "http:\/\/wp.me\/p4gDtp-49",
      "display_url" : "wp.me\/p4gDtp-49"
    } ]
  },
  "geo" : { },
  "id_str" : "677646401237622784",
  "text" : "Vocabulary apps: a wish list https:\/\/t.co\/dPPWJis4JH via @wordpressdotcom",
  "id" : 677646401237622784,
  "created_at" : "2015-12-18 00:27:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bruce Arthur",
      "screen_name" : "bruce_arthur",
      "indices" : [ 3, 16 ],
      "id_str" : "86002394",
      "id" : 86002394
    }, {
      "name" : "Richard Dawkins",
      "screen_name" : "RichardDawkins",
      "indices" : [ 18, 33 ],
      "id_str" : "15143478",
      "id" : 15143478
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "677639309076353024",
  "text" : "RT @bruce_arthur: @RichardDawkins As an atheist, I do wish you'd join another team",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Richard Dawkins",
        "screen_name" : "RichardDawkins",
        "indices" : [ 0, 15 ],
        "id_str" : "15143478",
        "id" : 15143478
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "677550557113032705",
    "geo" : { },
    "id_str" : "677603934358384641",
    "in_reply_to_user_id" : 15143478,
    "text" : "@RichardDawkins As an atheist, I do wish you'd join another team",
    "id" : 677603934358384641,
    "in_reply_to_status_id" : 677550557113032705,
    "created_at" : "2015-12-17 21:39:01 +0000",
    "in_reply_to_screen_name" : "RichardDawkins",
    "in_reply_to_user_id_str" : "15143478",
    "user" : {
      "name" : "Bruce Arthur",
      "screen_name" : "bruce_arthur",
      "protected" : false,
      "id_str" : "86002394",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1015899671\/Photo_109_normal.jpg",
      "id" : 86002394,
      "verified" : true
    }
  },
  "id" : 677639309076353024,
  "created_at" : "2015-12-17 23:59:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/F4E8jKuoEa",
      "expanded_url" : "http:\/\/members5.boardhost.com\/medialens\/msg\/1450373999.html",
      "display_url" : "members5.boardhost.com\/medialens\/msg\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "677633261594611713",
  "text" : "Re: \"The Left...\" \"The Hard Left...blah blah...\"https:\/\/t.co\/F4E8jKuoEa",
  "id" : 677633261594611713,
  "created_at" : "2015-12-17 23:35:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "indices" : [ 3, 15 ],
      "id_str" : "192437743",
      "id" : 192437743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/l2L7UlNZiQ",
      "expanded_url" : "http:\/\/bit.ly\/1mbaCey",
      "display_url" : "bit.ly\/1mbaCey"
    } ]
  },
  "geo" : { },
  "id_str" : "677627172035670016",
  "text" : "RT @nathanghall: \u2018Star Wars\u2019: YouTube Star Creates New Language For Aliens https:\/\/t.co\/l2L7UlNZiQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/l2L7UlNZiQ",
        "expanded_url" : "http:\/\/bit.ly\/1mbaCey",
        "display_url" : "bit.ly\/1mbaCey"
      } ]
    },
    "geo" : { },
    "id_str" : "677626331996299269",
    "text" : "\u2018Star Wars\u2019: YouTube Star Creates New Language For Aliens https:\/\/t.co\/l2L7UlNZiQ",
    "id" : 677626331996299269,
    "created_at" : "2015-12-17 23:08:01 +0000",
    "user" : {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "protected" : false,
      "id_str" : "192437743",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/715691315158061056\/_00s_D48_normal.jpg",
      "id" : 192437743,
      "verified" : false
    }
  },
  "id" : 677627172035670016,
  "created_at" : "2015-12-17 23:11:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ellensclass",
      "screen_name" : "ellensclass",
      "indices" : [ 3, 15 ],
      "id_str" : "451058137",
      "id" : 451058137
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/ellensclass\/status\/677621148641828866\/photo\/1",
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/CtRPis5hkz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWdk2AyWIAEJSDQ.jpg",
      "id_str" : "677621148029427713",
      "id" : 677621148029427713,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWdk2AyWIAEJSDQ.jpg",
      "sizes" : [ {
        "h" : 398,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 531,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 531,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/CtRPis5hkz"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/BsozXP4hIr",
      "expanded_url" : "https:\/\/useenglisheveryday.wordpress.com\/2015\/12\/18\/the-cultural-impact-of-star-wars",
      "display_url" : "useenglisheveryday.wordpress.com\/2015\/12\/18\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "677625846165827586",
  "text" : "RT @ellensclass: The cultural impact of Star\u00A0Wars https:\/\/t.co\/BsozXP4hIr https:\/\/t.co\/CtRPis5hkz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ellensclass\/status\/677621148641828866\/photo\/1",
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/CtRPis5hkz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CWdk2AyWIAEJSDQ.jpg",
        "id_str" : "677621148029427713",
        "id" : 677621148029427713,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWdk2AyWIAEJSDQ.jpg",
        "sizes" : [ {
          "h" : 398,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 531,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 531,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/CtRPis5hkz"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 56 ],
        "url" : "https:\/\/t.co\/BsozXP4hIr",
        "expanded_url" : "https:\/\/useenglisheveryday.wordpress.com\/2015\/12\/18\/the-cultural-impact-of-star-wars",
        "display_url" : "useenglisheveryday.wordpress.com\/2015\/12\/18\/the\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "677621148641828866",
    "text" : "The cultural impact of Star\u00A0Wars https:\/\/t.co\/BsozXP4hIr https:\/\/t.co\/CtRPis5hkz",
    "id" : 677621148641828866,
    "created_at" : "2015-12-17 22:47:26 +0000",
    "user" : {
      "name" : "ellensclass",
      "screen_name" : "ellensclass",
      "protected" : false,
      "id_str" : "451058137",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1724689649\/NYThatWay_normal.jpg",
      "id" : 451058137,
      "verified" : false
    }
  },
  "id" : 677625846165827586,
  "created_at" : "2015-12-17 23:06:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "noapologiesforbandwagoning",
      "indices" : [ 30, 57 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 61, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/LGotndOiWv",
      "expanded_url" : "https:\/\/eflnotes.wordpress.com\/2015\/12\/18\/lesson-kit-1-star-wars-puns",
      "display_url" : "eflnotes.wordpress.com\/2015\/12\/18\/les\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "677613849596444672",
  "text" : "Lesson Kit 1: Star Wars puns  #noapologiesforbandwagoning :) #eltchat https:\/\/t.co\/LGotndOiWv",
  "id" : 677613849596444672,
  "created_at" : "2015-12-17 22:18:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Spencer",
      "screen_name" : "spencerideas",
      "indices" : [ 0, 13 ],
      "id_str" : "18389166",
      "id" : 18389166
    }, {
      "name" : "someecards",
      "screen_name" : "someecards",
      "indices" : [ 14, 25 ],
      "id_str" : "14094741",
      "id" : 14094741
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "677561510411939840",
  "geo" : { },
  "id_str" : "677593576801480704",
  "in_reply_to_user_id" : 18389166,
  "text" : "@spencerideas @someecards i counted 10\/11",
  "id" : 677593576801480704,
  "in_reply_to_status_id" : 677561510411939840,
  "created_at" : "2015-12-17 20:57:52 +0000",
  "in_reply_to_screen_name" : "spencerideas",
  "in_reply_to_user_id_str" : "18389166",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Spencer",
      "screen_name" : "spencerideas",
      "indices" : [ 3, 16 ],
      "id_str" : "18389166",
      "id" : 18389166
    }, {
      "name" : "someecards",
      "screen_name" : "someecards",
      "indices" : [ 139, 140 ],
      "id_str" : "14094741",
      "id" : 14094741
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/fyCbBoc1Ko",
      "expanded_url" : "http:\/\/some.ly\/eueXrZZ",
      "display_url" : "some.ly\/eueXrZZ"
    } ]
  },
  "geo" : { },
  "id_str" : "677591915764785152",
  "text" : "RT @spencerideas: Weather presenter drops 12 'Star Wars' puns in 40-second report. Nerds everywhere fall in love. https:\/\/t.co\/fyCbBoc1Ko v\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "someecards",
        "screen_name" : "someecards",
        "indices" : [ 124, 135 ],
        "id_str" : "14094741",
        "id" : 14094741
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/fyCbBoc1Ko",
        "expanded_url" : "http:\/\/some.ly\/eueXrZZ",
        "display_url" : "some.ly\/eueXrZZ"
      } ]
    },
    "geo" : { },
    "id_str" : "677561510411939840",
    "text" : "Weather presenter drops 12 'Star Wars' puns in 40-second report. Nerds everywhere fall in love. https:\/\/t.co\/fyCbBoc1Ko via @someecards",
    "id" : 677561510411939840,
    "created_at" : "2015-12-17 18:50:27 +0000",
    "user" : {
      "name" : "John Spencer",
      "screen_name" : "spencerideas",
      "protected" : false,
      "id_str" : "18389166",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751913559160795136\/eU7NtYy4_normal.jpg",
      "id" : 18389166,
      "verified" : false
    }
  },
  "id" : 677591915764785152,
  "created_at" : "2015-12-17 20:51:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Cantarutti",
      "screen_name" : "pronbites",
      "indices" : [ 0, 10 ],
      "id_str" : "2451770871",
      "id" : 2451770871
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "677585446424190976",
  "geo" : { },
  "id_str" : "677587646865100800",
  "in_reply_to_user_id" : 2451770871,
  "text" : "@pronbites thx must have been phone link working on desktop",
  "id" : 677587646865100800,
  "in_reply_to_status_id" : 677585446424190976,
  "created_at" : "2015-12-17 20:34:18 +0000",
  "in_reply_to_screen_name" : "pronbites",
  "in_reply_to_user_id_str" : "2451770871",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Cantarutti",
      "screen_name" : "pronbites",
      "indices" : [ 0, 10 ],
      "id_str" : "2451770871",
      "id" : 2451770871
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "677539021871017984",
  "geo" : { },
  "id_str" : "677558546754633728",
  "in_reply_to_user_id" : 2451770871,
  "text" : "@pronbites hi broken link?",
  "id" : 677558546754633728,
  "in_reply_to_status_id" : 677539021871017984,
  "created_at" : "2015-12-17 18:38:40 +0000",
  "in_reply_to_screen_name" : "pronbites",
  "in_reply_to_user_id_str" : "2451770871",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/medialens\/status\/677484163793072128\/photo\/1",
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/ulxBwhhar2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWboQV-WEAEH2pj.png",
      "id_str" : "677484161440026625",
      "id" : 677484161440026625,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWboQV-WEAEH2pj.png",
      "sizes" : [ {
        "h" : 64,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 136,
        "resize" : "fit",
        "w" : 721
      }, {
        "h" : 113,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 136,
        "resize" : "crop",
        "w" : 136
      }, {
        "h" : 136,
        "resize" : "fit",
        "w" : 721
      } ],
      "display_url" : "pic.twitter.com\/ulxBwhhar2"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/4lb6f48U94",
      "expanded_url" : "http:\/\/www.medialens.org\/index.php\/alerts\/alert-archive\/2015\/808-the-new-mccarthyism-keep-the-war-versus-stop-the-war.html",
      "display_url" : "medialens.org\/index.php\/aler\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "677522457629204481",
  "text" : "RT @medialens: A response from the corporate 'left' to our latest media alert https:\/\/t.co\/4lb6f48U94 https:\/\/t.co\/ulxBwhhar2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/medialens\/status\/677484163793072128\/photo\/1",
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/ulxBwhhar2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CWboQV-WEAEH2pj.png",
        "id_str" : "677484161440026625",
        "id" : 677484161440026625,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWboQV-WEAEH2pj.png",
        "sizes" : [ {
          "h" : 64,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 136,
          "resize" : "fit",
          "w" : 721
        }, {
          "h" : 113,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 136,
          "resize" : "crop",
          "w" : 136
        }, {
          "h" : 136,
          "resize" : "fit",
          "w" : 721
        } ],
        "display_url" : "pic.twitter.com\/ulxBwhhar2"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/4lb6f48U94",
        "expanded_url" : "http:\/\/www.medialens.org\/index.php\/alerts\/alert-archive\/2015\/808-the-new-mccarthyism-keep-the-war-versus-stop-the-war.html",
        "display_url" : "medialens.org\/index.php\/aler\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "677484163793072128",
    "text" : "A response from the corporate 'left' to our latest media alert https:\/\/t.co\/4lb6f48U94 https:\/\/t.co\/ulxBwhhar2",
    "id" : 677484163793072128,
    "created_at" : "2015-12-17 13:43:06 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 677522457629204481,
  "created_at" : "2015-12-17 16:15:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "teacherstories",
      "screen_name" : "bee_visible",
      "indices" : [ 3, 15 ],
      "id_str" : "3112144043",
      "id" : 3112144043
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/bee_visible\/status\/677446814019231744\/photo\/1",
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/GHahC81aHw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWbGSYCWoAAlyQN.jpg",
      "id_str" : "677446812958105600",
      "id" : 677446812958105600,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWbGSYCWoAAlyQN.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/GHahC81aHw"
    } ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 87, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/rbOP2xB1TB",
      "expanded_url" : "https:\/\/www.smashwords.com\/books\/view\/601039",
      "display_url" : "smashwords.com\/books\/view\/601\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "677450140479803393",
  "text" : "RT @bee_visible: Teacher Stories is out now - spread the word! https:\/\/t.co\/rbOP2xB1TB #elt https:\/\/t.co\/GHahC81aHw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/bee_visible\/status\/677446814019231744\/photo\/1",
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/GHahC81aHw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CWbGSYCWoAAlyQN.jpg",
        "id_str" : "677446812958105600",
        "id" : 677446812958105600,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWbGSYCWoAAlyQN.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/GHahC81aHw"
      } ],
      "hashtags" : [ {
        "text" : "elt",
        "indices" : [ 70, 74 ]
      } ],
      "urls" : [ {
        "indices" : [ 46, 69 ],
        "url" : "https:\/\/t.co\/rbOP2xB1TB",
        "expanded_url" : "https:\/\/www.smashwords.com\/books\/view\/601039",
        "display_url" : "smashwords.com\/books\/view\/601\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "677446814019231744",
    "text" : "Teacher Stories is out now - spread the word! https:\/\/t.co\/rbOP2xB1TB #elt https:\/\/t.co\/GHahC81aHw",
    "id" : 677446814019231744,
    "created_at" : "2015-12-17 11:14:41 +0000",
    "user" : {
      "name" : "teacherstories",
      "screen_name" : "bee_visible",
      "protected" : false,
      "id_str" : "3112144043",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629055941850320901\/kumvict0_normal.png",
      "id" : 3112144043,
      "verified" : false
    }
  },
  "id" : 677450140479803393,
  "created_at" : "2015-12-17 11:27:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "indices" : [ 0, 13 ],
      "id_str" : "1685397408",
      "id" : 1685397408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/DLlMkochE5",
      "expanded_url" : "http:\/\/www.wikihow.com\/Make-Saline-Nasal-Spray",
      "display_url" : "wikihow.com\/Make-Saline-Na\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "677442164775874560",
  "geo" : { },
  "id_str" : "677443110398525441",
  "in_reply_to_user_id" : 1685397408,
  "text" : "@harrisonmike some tips here https:\/\/t.co\/DLlMkochE5",
  "id" : 677443110398525441,
  "in_reply_to_status_id" : 677442164775874560,
  "created_at" : "2015-12-17 10:59:58 +0000",
  "in_reply_to_screen_name" : "harrisonmike",
  "in_reply_to_user_id_str" : "1685397408",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "indices" : [ 0, 13 ],
      "id_str" : "1685397408",
      "id" : 1685397408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "677441653431525377",
  "geo" : { },
  "id_str" : "677442025550127104",
  "in_reply_to_user_id" : 1685397408,
  "text" : "@harrisonmike a big sniff :) or pharmacies sell sprays",
  "id" : 677442025550127104,
  "in_reply_to_status_id" : 677441653431525377,
  "created_at" : "2015-12-17 10:55:39 +0000",
  "in_reply_to_screen_name" : "harrisonmike",
  "in_reply_to_user_id_str" : "1685397408",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "indices" : [ 0, 13 ],
      "id_str" : "1685397408",
      "id" : 1685397408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "677436390045536256",
  "geo" : { },
  "id_str" : "677441483633508352",
  "in_reply_to_user_id" : 1685397408,
  "text" : "@harrisonmike salt-solution clean the nose?",
  "id" : 677441483633508352,
  "in_reply_to_status_id" : 677436390045536256,
  "created_at" : "2015-12-17 10:53:30 +0000",
  "in_reply_to_screen_name" : "harrisonmike",
  "in_reply_to_user_id_str" : "1685397408",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Speech Events",
      "screen_name" : "SpeechEvents",
      "indices" : [ 97, 110 ],
      "id_str" : "1468444922",
      "id" : 1468444922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/7ATS2LFy64",
      "expanded_url" : "http:\/\/wp.me\/p3Amm5-ig",
      "display_url" : "wp.me\/p3Amm5-ig"
    } ]
  },
  "geo" : { },
  "id_str" : "677439283561648128",
  "text" : "The Languages of Star Wars: A Sociolinguistic Investigation (Part 1) https:\/\/t.co\/7ATS2LFy64 via @speechevents",
  "id" : 677439283561648128,
  "created_at" : "2015-12-17 10:44:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hana Tich\u00E1",
      "screen_name" : "HanaTicha",
      "indices" : [ 0, 10 ],
      "id_str" : "512296705",
      "id" : 512296705
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "677433734061285376",
  "geo" : { },
  "id_str" : "677434215626055681",
  "in_reply_to_user_id" : 512296705,
  "text" : "@HanaTicha hello Hana's class from sunny Paris :)",
  "id" : 677434215626055681,
  "in_reply_to_status_id" : 677433734061285376,
  "created_at" : "2015-12-17 10:24:37 +0000",
  "in_reply_to_screen_name" : "HanaTicha",
  "in_reply_to_user_id_str" : "512296705",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EAPsteve",
      "screen_name" : "EAPstephen",
      "indices" : [ 0, 11 ],
      "id_str" : "2717005711",
      "id" : 2717005711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "677431831847936000",
  "geo" : { },
  "id_str" : "677432222161477632",
  "in_reply_to_user_id" : 2717005711,
  "text" : "@EAPstephen did it last time recommended!",
  "id" : 677432222161477632,
  "in_reply_to_status_id" : 677431831847936000,
  "created_at" : "2015-12-17 10:16:42 +0000",
  "in_reply_to_screen_name" : "EAPstephen",
  "in_reply_to_user_id_str" : "2717005711",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Sherlock",
      "screen_name" : "DavidMSherlock",
      "indices" : [ 3, 18 ],
      "id_str" : "1479898584",
      "id" : 1479898584
    }, {
      "name" : "D-CENT",
      "screen_name" : "dcentproject",
      "indices" : [ 24, 37 ],
      "id_str" : "2233307005",
      "id" : 2233307005
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/55Eo86K8C1",
      "expanded_url" : "http:\/\/dcentproject.eu\/",
      "display_url" : "dcentproject.eu"
    } ]
  },
  "geo" : { },
  "id_str" : "677430876645519361",
  "text" : "RT @DavidMSherlock: the @dcentproject looks really interesting: https:\/\/t.co\/55Eo86K8C1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "D-CENT",
        "screen_name" : "dcentproject",
        "indices" : [ 4, 17 ],
        "id_str" : "2233307005",
        "id" : 2233307005
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 67 ],
        "url" : "https:\/\/t.co\/55Eo86K8C1",
        "expanded_url" : "http:\/\/dcentproject.eu\/",
        "display_url" : "dcentproject.eu"
      } ]
    },
    "geo" : { },
    "id_str" : "677422576696692737",
    "text" : "the @dcentproject looks really interesting: https:\/\/t.co\/55Eo86K8C1",
    "id" : 677422576696692737,
    "created_at" : "2015-12-17 09:38:22 +0000",
    "user" : {
      "name" : "David Sherlock",
      "screen_name" : "DavidMSherlock",
      "protected" : false,
      "id_str" : "1479898584",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/596225422360195072\/NVf3LX8c_normal.jpg",
      "id" : 1479898584,
      "verified" : false
    }
  },
  "id" : 677430876645519361,
  "created_at" : "2015-12-17 10:11:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/677259810207698944\/photo\/1",
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/zHNuCZeUXR",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CWYcLYCW4AAp92l.png",
      "id_str" : "677259775722315776",
      "id" : 677259775722315776,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CWYcLYCW4AAp92l.png",
      "sizes" : [ {
        "h" : 192,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 336,
        "resize" : "fit",
        "w" : 596
      }, {
        "h" : 336,
        "resize" : "fit",
        "w" : 596
      }, {
        "h" : 336,
        "resize" : "fit",
        "w" : 596
      } ],
      "display_url" : "pic.twitter.com\/zHNuCZeUXR"
    } ],
    "hashtags" : [ {
      "text" : "syria",
      "indices" : [ 28, 34 ]
    }, {
      "text" : "fracking",
      "indices" : [ 35, 44 ]
    }, {
      "text" : "Principia",
      "indices" : [ 45, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "677259810207698944",
  "text" : "mojo back does britain have #syria #fracking #Principia https:\/\/t.co\/zHNuCZeUXR",
  "id" : 677259810207698944,
  "created_at" : "2015-12-16 22:51:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Paskale",
      "screen_name" : "speak2all",
      "indices" : [ 3, 13 ],
      "id_str" : "20900313",
      "id" : 20900313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/Bnpi4Lc1dN",
      "expanded_url" : "http:\/\/makeapowerfulpoint.com\/2015\/12\/15\/dirty-rhetoric-podcast-3-last-word-first-word\/#DirtyRhetoric",
      "display_url" : "makeapowerfulpoint.com\/2015\/12\/15\/dir\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "677224365432377344",
  "text" : "RT @speak2all: REVEALED! The top rhetorical techniques of Yoda! Help you he will! https:\/\/t.co\/Bnpi4Lc1dN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/Bnpi4Lc1dN",
        "expanded_url" : "http:\/\/makeapowerfulpoint.com\/2015\/12\/15\/dirty-rhetoric-podcast-3-last-word-first-word\/#DirtyRhetoric",
        "display_url" : "makeapowerfulpoint.com\/2015\/12\/15\/dir\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "677215001590001664",
    "text" : "REVEALED! The top rhetorical techniques of Yoda! Help you he will! https:\/\/t.co\/Bnpi4Lc1dN",
    "id" : 677215001590001664,
    "created_at" : "2015-12-16 19:53:33 +0000",
    "user" : {
      "name" : "Peter Paskale",
      "screen_name" : "speak2all",
      "protected" : false,
      "id_str" : "20900313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/555413218571468800\/oXbEP2Zs_normal.jpeg",
      "id" : 20900313,
      "verified" : false
    }
  },
  "id" : 677224365432377344,
  "created_at" : "2015-12-16 20:30:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darius Kazemi",
      "screen_name" : "tinysubversions",
      "indices" : [ 3, 19 ],
      "id_str" : "14475298",
      "id" : 14475298
    }, {
      "name" : "\u2630 colin mitchell \u2630",
      "screen_name" : "muffinista",
      "indices" : [ 33, 44 ],
      "id_str" : "1160471",
      "id" : 1160471
    }, {
      "name" : "BoggleBot",
      "screen_name" : "Botgle",
      "indices" : [ 48, 55 ],
      "id_str" : "3299372399",
      "id" : 3299372399
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/6hya5j0z5w",
      "expanded_url" : "http:\/\/qz.com\/572763\/the-best-twitter-bots-of-2015\/",
      "display_url" : "qz.com\/572763\/the-bes\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "677211577574141952",
  "text" : "RT @tinysubversions: Congrats to @muffinista on @Botgle being called \"bot of the year\" in this roundup: https:\/\/t.co\/6hya5j0z5w (lots of ot\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u2630 colin mitchell \u2630",
        "screen_name" : "muffinista",
        "indices" : [ 12, 23 ],
        "id_str" : "1160471",
        "id" : 1160471
      }, {
        "name" : "BoggleBot",
        "screen_name" : "Botgle",
        "indices" : [ 27, 34 ],
        "id_str" : "3299372399",
        "id" : 3299372399
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/6hya5j0z5w",
        "expanded_url" : "http:\/\/qz.com\/572763\/the-best-twitter-bots-of-2015\/",
        "display_url" : "qz.com\/572763\/the-bes\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "677186635339948034",
    "text" : "Congrats to @muffinista on @Botgle being called \"bot of the year\" in this roundup: https:\/\/t.co\/6hya5j0z5w (lots of other great bots there)",
    "id" : 677186635339948034,
    "created_at" : "2015-12-16 18:00:50 +0000",
    "user" : {
      "name" : "Darius Kazemi",
      "screen_name" : "tinysubversions",
      "protected" : false,
      "id_str" : "14475298",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723889712772059136\/4T8a46Sp_normal.jpg",
      "id" : 14475298,
      "verified" : false
    }
  },
  "id" : 677211577574141952,
  "created_at" : "2015-12-16 19:39:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/677172202622595072\/photo\/1",
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/bjyJOiiZJf",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CWXMbQ7WUAAzeT1.png",
      "id_str" : "677172087761555456",
      "id" : 677172087761555456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CWXMbQ7WUAAzeT1.png",
      "sizes" : [ {
        "h" : 192,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 336,
        "resize" : "fit",
        "w" : 596
      }, {
        "h" : 336,
        "resize" : "fit",
        "w" : 596
      }, {
        "h" : 336,
        "resize" : "fit",
        "w" : 596
      } ],
      "display_url" : "pic.twitter.com\/bjyJOiiZJf"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "677172202622595072",
  "text" : "phew nearly there the end of year https:\/\/t.co\/bjyJOiiZJf",
  "id" : 677172202622595072,
  "created_at" : "2015-12-16 17:03:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 48, 64 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/rBwGgqNVLW",
      "expanded_url" : "http:\/\/wp.me\/p5JYqQ-2b",
      "display_url" : "wp.me\/p5JYqQ-2b"
    } ]
  },
  "geo" : { },
  "id_str" : "677113793135157248",
  "text" : "Let's get the best! https:\/\/t.co\/rBwGgqNVLW via @wordpressdotcom",
  "id" : 677113793135157248,
  "created_at" : "2015-12-16 13:11:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 111, 127 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/o1eRPzb7Wc",
      "expanded_url" : "http:\/\/wp.me\/p3VIfJ-7B",
      "display_url" : "wp.me\/p3VIfJ-7B"
    } ]
  },
  "geo" : { },
  "id_str" : "677111928532148224",
  "text" : "Who is benefiting most from computer coding being part of the National Curriculum? https:\/\/t.co\/o1eRPzb7Wc via @wordpressdotcom",
  "id" : 677111928532148224,
  "created_at" : "2015-12-16 13:03:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Yau",
      "screen_name" : "flowingdata",
      "indices" : [ 59, 71 ],
      "id_str" : "14109167",
      "id" : 14109167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/AVtl6Xh3Gg",
      "expanded_url" : "http:\/\/flowingdata.com\/2015\/12\/15\/a-day-in-the-life-of-americans\/",
      "display_url" : "flowingdata.com\/2015\/12\/15\/a-d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "676884362571456513",
  "text" : "A Day in the Life of Americans https:\/\/t.co\/AVtl6Xh3Gg via @flowingdata",
  "id" : 676884362571456513,
  "created_at" : "2015-12-15 21:59:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Lavigne",
      "screen_name" : "sam_lavigne",
      "indices" : [ 0, 12 ],
      "id_str" : "6428702",
      "id" : 6428702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/Oz7jb7oiSH",
      "expanded_url" : "http:\/\/greetingcompany.biz\/",
      "display_url" : "greetingcompany.biz"
    } ]
  },
  "geo" : { },
  "id_str" : "676875252165648384",
  "in_reply_to_user_id" : 6428702,
  "text" : "@sam_lavigne https:\/\/t.co\/Oz7jb7oiSH is so fun thx, be cool to be able to keep 1 or 2 images whilst spinning another?",
  "id" : 676875252165648384,
  "created_at" : "2015-12-15 21:23:30 +0000",
  "in_reply_to_screen_name" : "sam_lavigne",
  "in_reply_to_user_id_str" : "6428702",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Lavigne",
      "screen_name" : "sam_lavigne",
      "indices" : [ 62, 74 ],
      "id_str" : "6428702",
      "id" : 6428702
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/676874061545390080\/photo\/1",
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/AZvH9GxJB4",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CWS9Qh7XIAAxW7S.png",
      "id_str" : "676873935695323136",
      "id" : 676873935695323136,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CWS9Qh7XIAAxW7S.png",
      "sizes" : [ {
        "h" : 192,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 336,
        "resize" : "fit",
        "w" : 596
      }, {
        "h" : 336,
        "resize" : "fit",
        "w" : 596
      }, {
        "h" : 336,
        "resize" : "fit",
        "w" : 596
      } ],
      "display_url" : "pic.twitter.com\/AZvH9GxJB4"
    } ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 12, 18 ]
    } ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/Oz7jb7oiSH",
      "expanded_url" : "http:\/\/greetingcompany.biz\/",
      "display_url" : "greetingcompany.biz"
    } ]
  },
  "geo" : { },
  "id_str" : "676874061545390080",
  "text" : "Hilary Benn #Syria hours of fun at https:\/\/t.co\/Oz7jb7oiSH by @sam_lavigne https:\/\/t.co\/AZvH9GxJB4",
  "id" : 676874061545390080,
  "created_at" : "2015-12-15 21:18:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/dqfDCdwEuP",
      "expanded_url" : "http:\/\/www.theguardian.com\/uk-news\/2015\/dec\/15\/revealed-prince-charles-has-received-confidential-cabinet-papers-for-decades",
      "display_url" : "theguardian.com\/uk-news\/2015\/d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "676804069617463296",
  "text" : "RT @pchallinor: And this is why we're qualified to teach the Euro-wogs and Johnny Arab about democracy https:\/\/t.co\/dqfDCdwEuP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/dqfDCdwEuP",
        "expanded_url" : "http:\/\/www.theguardian.com\/uk-news\/2015\/dec\/15\/revealed-prince-charles-has-received-confidential-cabinet-papers-for-decades",
        "display_url" : "theguardian.com\/uk-news\/2015\/d\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "676802635970793472",
    "text" : "And this is why we're qualified to teach the Euro-wogs and Johnny Arab about democracy https:\/\/t.co\/dqfDCdwEuP",
    "id" : 676802635970793472,
    "created_at" : "2015-12-15 16:34:57 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 676804069617463296,
  "created_at" : "2015-12-15 16:40:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/676760096798560256\/photo\/1",
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/CNTGuzVinK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWRVtlIXAAAaxXR.jpg",
      "id_str" : "676760085562064896",
      "id" : 676760085562064896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWRVtlIXAAAaxXR.jpg",
      "sizes" : [ {
        "h" : 1822,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1151
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1068,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 605,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/CNTGuzVinK"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "676760096798560256",
  "text" : "Nice code play &amp; pron play https:\/\/t.co\/CNTGuzVinK",
  "id" : 676760096798560256,
  "created_at" : "2015-12-15 13:45:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/5dKXgSWguw",
      "expanded_url" : "http:\/\/Antiwar.com",
      "display_url" : "Antiwar.com"
    }, {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/5dKXgSWguw",
      "expanded_url" : "http:\/\/Antiwar.com",
      "display_url" : "Antiwar.com"
    }, {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/TVWaHZvoTz",
      "expanded_url" : "http:\/\/original.antiwar.com\/Dan_Sanchez\/2015\/12\/14\/the-road-to-galactic-serfdom\/#.VnAKkjf9eZ0.twitter",
      "display_url" : "original.antiwar.com\/Dan_Sanchez\/20\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "676744018349412352",
  "text" : "The Road to Galactic Serfdom - Dan Sanchez - https:\/\/t.co\/5dKXgSWguw by -- https:\/\/t.co\/5dKXgSWguw https:\/\/t.co\/TVWaHZvoTz",
  "id" : 676744018349412352,
  "created_at" : "2015-12-15 12:42:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DMLL",
      "screen_name" : "DiMLL",
      "indices" : [ 0, 6 ],
      "id_str" : "1114312832",
      "id" : 1114312832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/o1i5MlusUq",
      "expanded_url" : "https:\/\/eflnotes.wordpress.com\/2015\/03\/06\/grassroots-language-technology-paul-raine-apps4efl\/",
      "display_url" : "eflnotes.wordpress.com\/2015\/03\/06\/gra\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "676735761526292484",
  "geo" : { },
  "id_str" : "676741232291397632",
  "in_reply_to_user_id" : 1114312832,
  "text" : "@DiMLL hi here's another Paul Raine interview if u have not read it https:\/\/t.co\/o1i5MlusUq",
  "id" : 676741232291397632,
  "in_reply_to_status_id" : 676735761526292484,
  "created_at" : "2015-12-15 12:30:57 +0000",
  "in_reply_to_screen_name" : "DiMLL",
  "in_reply_to_user_id_str" : "1114312832",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DMLL",
      "screen_name" : "DiMLL",
      "indices" : [ 3, 9 ],
      "id_str" : "1114312832",
      "id" : 1114312832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/2jVhd3EGfA",
      "expanded_url" : "http:\/\/wp.me\/p6uIkR-Jy",
      "display_url" : "wp.me\/p6uIkR-Jy"
    } ]
  },
  "geo" : { },
  "id_str" : "676736020075962368",
  "text" : "RT @DiMLL: This is what happens when a brilliant computer programmer becomes a dedicated language teacher. https:\/\/t.co\/2jVhd3EGfA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/2jVhd3EGfA",
        "expanded_url" : "http:\/\/wp.me\/p6uIkR-Jy",
        "display_url" : "wp.me\/p6uIkR-Jy"
      } ]
    },
    "geo" : { },
    "id_str" : "676735761526292484",
    "text" : "This is what happens when a brilliant computer programmer becomes a dedicated language teacher. https:\/\/t.co\/2jVhd3EGfA",
    "id" : 676735761526292484,
    "created_at" : "2015-12-15 12:09:13 +0000",
    "user" : {
      "name" : "DMLL",
      "screen_name" : "DiMLL",
      "protected" : false,
      "id_str" : "1114312832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/675557516583919620\/LTTt0aXN_normal.jpg",
      "id" : 1114312832,
      "verified" : false
    }
  },
  "id" : 676736020075962368,
  "created_at" : "2015-12-15 12:10:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donald Clark",
      "screen_name" : "DonaldClark",
      "indices" : [ 0, 12 ],
      "id_str" : "1632891",
      "id" : 1632891
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/676729966738997250\/photo\/1",
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/9c3QDwIXAd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWQ6S45WcAAigfg.png",
      "id_str" : "676729940197404672",
      "id" : 676729940197404672,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWQ6S45WcAAigfg.png",
      "sizes" : [ {
        "h" : 220,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 220,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 220,
        "resize" : "fit",
        "w" : 440
      } ],
      "display_url" : "pic.twitter.com\/9c3QDwIXAd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "676716987419115520",
  "geo" : { },
  "id_str" : "676729966738997250",
  "in_reply_to_user_id" : 1632891,
  "text" : "@DonaldClark but still :) https:\/\/t.co\/9c3QDwIXAd",
  "id" : 676729966738997250,
  "in_reply_to_status_id" : 676716987419115520,
  "created_at" : "2015-12-15 11:46:11 +0000",
  "in_reply_to_screen_name" : "DonaldClark",
  "in_reply_to_user_id_str" : "1632891",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenys Hanson",
      "screen_name" : "GlenysHanson",
      "indices" : [ 0, 13 ],
      "id_str" : "527238447",
      "id" : 527238447
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "676557269220335617",
  "geo" : { },
  "id_str" : "676653898640326656",
  "in_reply_to_user_id" : 527238447,
  "text" : "@GlenysHanson le cin\u00E9ma am\u00E9ricain c'est \"Rencontres du 3eme type\" le cin\u00E9ma fran\u00E7ais c'est 3 types qui se rencontrent : )",
  "id" : 676653898640326656,
  "in_reply_to_status_id" : 676557269220335617,
  "created_at" : "2015-12-15 06:43:55 +0000",
  "in_reply_to_screen_name" : "GlenysHanson",
  "in_reply_to_user_id_str" : "527238447",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Latent Discourses",
      "screen_name" : "latentdiscourse",
      "indices" : [ 0, 16 ],
      "id_str" : "3361426301",
      "id" : 3361426301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/p3oO380YgX",
      "expanded_url" : "http:\/\/writeaway.nlpweb.org\/",
      "display_url" : "writeaway.nlpweb.org"
    } ]
  },
  "in_reply_to_status_id_str" : "676553984958689280",
  "geo" : { },
  "id_str" : "676554564129169408",
  "in_reply_to_user_id" : 3361426301,
  "text" : "@latentdiscourse hi u might like this tool that is inspired by pattern grammar https:\/\/t.co\/p3oO380YgX",
  "id" : 676554564129169408,
  "in_reply_to_status_id" : 676553984958689280,
  "created_at" : "2015-12-15 00:09:12 +0000",
  "in_reply_to_screen_name" : "latentdiscourse",
  "in_reply_to_user_id_str" : "3361426301",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gilles j.",
      "screen_name" : "gill68",
      "indices" : [ 3, 10 ],
      "id_str" : "17438966",
      "id" : 17438966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/4Ga9eRJJIO",
      "expanded_url" : "http:\/\/twitthat.com\/xd0TL",
      "display_url" : "twitthat.com\/xd0TL"
    } ]
  },
  "geo" : { },
  "id_str" : "676547018802774017",
  "text" : "RT @gill68: \"Un cauchemar Orwellien (My dinner with Andre - 1981) [VOSTFR] sur Vimeo\" ( https:\/\/t.co\/4Ga9eRJJIO )",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitthat.com\/\" rel=\"nofollow\"\u003Etwitthat\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/4Ga9eRJJIO",
        "expanded_url" : "http:\/\/twitthat.com\/xd0TL",
        "display_url" : "twitthat.com\/xd0TL"
      } ]
    },
    "geo" : { },
    "id_str" : "674558264466632704",
    "text" : "\"Un cauchemar Orwellien (My dinner with Andre - 1981) [VOSTFR] sur Vimeo\" ( https:\/\/t.co\/4Ga9eRJJIO )",
    "id" : 674558264466632704,
    "created_at" : "2015-12-09 11:56:37 +0000",
    "user" : {
      "name" : "gilles j.",
      "screen_name" : "gill68",
      "protected" : false,
      "id_str" : "17438966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/453579361208123392\/NClbZJJ8_normal.jpeg",
      "id" : 17438966,
      "verified" : false
    }
  },
  "id" : 676547018802774017,
  "created_at" : "2015-12-14 23:39:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 48, 64 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/ynbrwssGL6",
      "expanded_url" : "http:\/\/wp.me\/p1oNHf-it",
      "display_url" : "wp.me\/p1oNHf-it"
    } ]
  },
  "geo" : { },
  "id_str" : "676513988394512385",
  "text" : "The Man on the Moon https:\/\/t.co\/ynbrwssGL6 via @wordpressdotcom",
  "id" : 676513988394512385,
  "created_at" : "2015-12-14 21:27:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mahmoud",
      "screen_name" : "MahmoudRamsey",
      "indices" : [ 3, 17 ],
      "id_str" : "33203801",
      "id" : 33203801
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/MahmoudRamsey\/status\/676393775086850049\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/3wEHzhhheX",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CWK_vnIWwAA0mkg.png",
      "id_str" : "676313718737780736",
      "id" : 676313718737780736,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CWK_vnIWwAA0mkg.png",
      "sizes" : [ {
        "h" : 360,
        "resize" : "fit",
        "w" : 467
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 467
      }, {
        "h" : 262,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 467
      } ],
      "display_url" : "pic.twitter.com\/3wEHzhhheX"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "676512802790592512",
  "text" : "RT @MahmoudRamsey: On this blessed day in 2008, George W. Bush nearly took a pair of shoes to the face on behalf of the Iraqi people. https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/MahmoudRamsey\/status\/676393775086850049\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/3wEHzhhheX",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CWK_vnIWwAA0mkg.png",
        "id_str" : "676313718737780736",
        "id" : 676313718737780736,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CWK_vnIWwAA0mkg.png",
        "sizes" : [ {
          "h" : 360,
          "resize" : "fit",
          "w" : 467
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 467
        }, {
          "h" : 262,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 467
        } ],
        "display_url" : "pic.twitter.com\/3wEHzhhheX"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "676393775086850049",
    "text" : "On this blessed day in 2008, George W. Bush nearly took a pair of shoes to the face on behalf of the Iraqi people. https:\/\/t.co\/3wEHzhhheX",
    "id" : 676393775086850049,
    "created_at" : "2015-12-14 13:30:17 +0000",
    "user" : {
      "name" : "Mahmoud",
      "screen_name" : "MahmoudRamsey",
      "protected" : false,
      "id_str" : "33203801",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751754062589296640\/DUuLDjIs_normal.jpg",
      "id" : 33203801,
      "verified" : false
    }
  },
  "id" : 676512802790592512,
  "created_at" : "2015-12-14 21:23:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    }, {
      "name" : "John Rees",
      "screen_name" : "JohnWRees",
      "indices" : [ 35, 45 ],
      "id_str" : "35458530",
      "id" : 35458530
    }, {
      "name" : "Stop the War",
      "screen_name" : "STWuk",
      "indices" : [ 49, 55 ],
      "id_str" : "23053980",
      "id" : 23053980
    }, {
      "name" : "BBC Radio 4",
      "screen_name" : "BBCRadio4",
      "indices" : [ 59, 69 ],
      "id_str" : "23937508",
      "id" : 23937508
    }, {
      "name" : "Emma Reynolds",
      "screen_name" : "EmmaReynoldsMP",
      "indices" : [ 101, 116 ],
      "id_str" : "32965648",
      "id" : 32965648
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 117, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 125, 140 ],
      "url" : "https:\/\/t.co\/wCjuNyTRf8",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=bmfBD5cDNJs&sns=tw",
      "display_url" : "youtube.com\/watch?v=bmfBD5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "676507541627641857",
  "text" : "RT @medialens: Excellent points by @JohnWRees of @STWuk in @BBCRadio4 debate with pro-bombing Labour @EmmaReynoldsMP #Syria  https:\/\/t.co\/w\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Rees",
        "screen_name" : "JohnWRees",
        "indices" : [ 20, 30 ],
        "id_str" : "35458530",
        "id" : 35458530
      }, {
        "name" : "Stop the War",
        "screen_name" : "STWuk",
        "indices" : [ 34, 40 ],
        "id_str" : "23053980",
        "id" : 23053980
      }, {
        "name" : "BBC Radio 4",
        "screen_name" : "BBCRadio4",
        "indices" : [ 44, 54 ],
        "id_str" : "23937508",
        "id" : 23937508
      }, {
        "name" : "Emma Reynolds",
        "screen_name" : "EmmaReynoldsMP",
        "indices" : [ 86, 101 ],
        "id_str" : "32965648",
        "id" : 32965648
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Syria",
        "indices" : [ 102, 108 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/wCjuNyTRf8",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=bmfBD5cDNJs&sns=tw",
        "display_url" : "youtube.com\/watch?v=bmfBD5\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "676417683529842688",
    "text" : "Excellent points by @JohnWRees of @STWuk in @BBCRadio4 debate with pro-bombing Labour @EmmaReynoldsMP #Syria  https:\/\/t.co\/wCjuNyTRf8",
    "id" : 676417683529842688,
    "created_at" : "2015-12-14 15:05:17 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 676507541627641857,
  "created_at" : "2015-12-14 21:02:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George Galloway",
      "screen_name" : "georgegalloway",
      "indices" : [ 3, 18 ],
      "id_str" : "15484198",
      "id" : 15484198
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "676504714440261632",
  "text" : "RT @georgegalloway: I remain expelled by Labour while the rabble within trying to destroy Corbyn are not of course \"bringing the Labour Par\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "676440929704787968",
    "text" : "I remain expelled by Labour while the rabble within trying to destroy Corbyn are not of course \"bringing the Labour Party into disrepute\".",
    "id" : 676440929704787968,
    "created_at" : "2015-12-14 16:37:39 +0000",
    "user" : {
      "name" : "George Galloway",
      "screen_name" : "georgegalloway",
      "protected" : false,
      "id_str" : "15484198",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746211361793802244\/cMbIcHMP_normal.jpg",
      "id" : 15484198,
      "verified" : true
    }
  },
  "id" : 676504714440261632,
  "created_at" : "2015-12-14 20:51:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "goieltsdotnet",
      "screen_name" : "goieltsdotnet",
      "indices" : [ 0, 14 ],
      "id_str" : "3052238274",
      "id" : 3052238274
    }, {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 15, 31 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    }, {
      "name" : "Chris Jones",
      "screen_name" : "ELTResearch",
      "indices" : [ 32, 44 ],
      "id_str" : "3308043417",
      "id" : 3308043417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "676411627185508354",
  "geo" : { },
  "id_str" : "676453506627280896",
  "in_reply_to_user_id" : 3052238274,
  "text" : "@goieltsdotnet @getgreatenglish @ELTResearch thx for sharing PHaVE addition : )",
  "id" : 676453506627280896,
  "in_reply_to_status_id" : 676411627185508354,
  "created_at" : "2015-12-14 17:27:38 +0000",
  "in_reply_to_screen_name" : "goieltsdotnet",
  "in_reply_to_user_id_str" : "3052238274",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robbie Love",
      "screen_name" : "lovermob",
      "indices" : [ 3, 12 ],
      "id_str" : "19469715",
      "id" : 19469715
    }, {
      "name" : "Cambridge Uni Press",
      "screen_name" : "CambridgeUP",
      "indices" : [ 32, 44 ],
      "id_str" : "319110295",
      "id" : 319110295
    }, {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "indices" : [ 117, 133 ],
      "id_str" : "1326508478",
      "id" : 1326508478
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/lovermob\/status\/676434847733317632\/photo\/1",
      "indices" : [ 143, 144 ],
      "url" : "https:\/\/t.co\/ldosqm6JLT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWMt6MNWUAArkCa.jpg",
      "id_str" : "676434846768582656",
      "id" : 676434846768582656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWMt6MNWUAArkCa.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 478,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 478,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/ldosqm6JLT"
    } ],
    "hashtags" : [ {
      "text" : "BNC2014",
      "indices" : [ 58, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "676452800474324992",
  "text" : "RT @lovermob: This just in from @CambridgeUP &amp; Spoken #BNC2014: \"I woke up in my high heels in the kitchen sink\" @CorpusSocialSci https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Cambridge Uni Press",
        "screen_name" : "CambridgeUP",
        "indices" : [ 18, 30 ],
        "id_str" : "319110295",
        "id" : 319110295
      }, {
        "name" : "CASS",
        "screen_name" : "CorpusSocialSci",
        "indices" : [ 103, 119 ],
        "id_str" : "1326508478",
        "id" : 1326508478
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/lovermob\/status\/676434847733317632\/photo\/1",
        "indices" : [ 120, 143 ],
        "url" : "https:\/\/t.co\/ldosqm6JLT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CWMt6MNWUAArkCa.jpg",
        "id_str" : "676434846768582656",
        "id" : 676434846768582656,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWMt6MNWUAArkCa.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 254,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 478,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 448,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 478,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/ldosqm6JLT"
      } ],
      "hashtags" : [ {
        "text" : "BNC2014",
        "indices" : [ 44, 52 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "676434847733317632",
    "text" : "This just in from @CambridgeUP &amp; Spoken #BNC2014: \"I woke up in my high heels in the kitchen sink\" @CorpusSocialSci https:\/\/t.co\/ldosqm6JLT",
    "id" : 676434847733317632,
    "created_at" : "2015-12-14 16:13:29 +0000",
    "user" : {
      "name" : "Robbie Love",
      "screen_name" : "lovermob",
      "protected" : false,
      "id_str" : "19469715",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733371018056716288\/4lRj6knU_normal.jpg",
      "id" : 19469715,
      "verified" : false
    }
  },
  "id" : 676452800474324992,
  "created_at" : "2015-12-14 17:24:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Babel",
      "screen_name" : "Babelzine",
      "indices" : [ 3, 13 ],
      "id_str" : "927973879",
      "id" : 927973879
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Babelzine\/status\/676410092183494656\/photo\/1",
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/g8XHsq5nL2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWMXZN0UAAIVlgw.png",
      "id_str" : "676410091008950274",
      "id" : 676410091008950274,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWMXZN0UAAIVlgw.png",
      "sizes" : [ {
        "h" : 529,
        "resize" : "fit",
        "w" : 412
      }, {
        "h" : 529,
        "resize" : "fit",
        "w" : 412
      }, {
        "h" : 437,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 529,
        "resize" : "fit",
        "w" : 412
      } ],
      "display_url" : "pic.twitter.com\/g8XHsq5nL2"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/R3h8NXXcW8",
      "expanded_url" : "http:\/\/ow.ly\/VR0Pb",
      "display_url" : "ow.ly\/VR0Pb"
    } ]
  },
  "geo" : { },
  "id_str" : "676416221101858817",
  "text" : "RT @Babelzine: Peter Trudgill explains changes in how we pronounce the 'goose' vowel - https:\/\/t.co\/R3h8NXXcW8 https:\/\/t.co\/g8XHsq5nL2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Babelzine\/status\/676410092183494656\/photo\/1",
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/g8XHsq5nL2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CWMXZN0UAAIVlgw.png",
        "id_str" : "676410091008950274",
        "id" : 676410091008950274,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWMXZN0UAAIVlgw.png",
        "sizes" : [ {
          "h" : 529,
          "resize" : "fit",
          "w" : 412
        }, {
          "h" : 529,
          "resize" : "fit",
          "w" : 412
        }, {
          "h" : 437,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 529,
          "resize" : "fit",
          "w" : 412
        } ],
        "display_url" : "pic.twitter.com\/g8XHsq5nL2"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/R3h8NXXcW8",
        "expanded_url" : "http:\/\/ow.ly\/VR0Pb",
        "display_url" : "ow.ly\/VR0Pb"
      } ]
    },
    "geo" : { },
    "id_str" : "676410092183494656",
    "text" : "Peter Trudgill explains changes in how we pronounce the 'goose' vowel - https:\/\/t.co\/R3h8NXXcW8 https:\/\/t.co\/g8XHsq5nL2",
    "id" : 676410092183494656,
    "created_at" : "2015-12-14 14:35:07 +0000",
    "user" : {
      "name" : "Babel",
      "screen_name" : "Babelzine",
      "protected" : false,
      "id_str" : "927973879",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/759438974247178240\/bsgKYczV_normal.jpg",
      "id" : 927973879,
      "verified" : false
    }
  },
  "id" : 676416221101858817,
  "created_at" : "2015-12-14 14:59:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 114, 122 ]
    }, {
      "text" : "esl",
      "indices" : [ 123, 127 ]
    }, {
      "text" : "efl",
      "indices" : [ 128, 132 ]
    }, {
      "text" : "TEFL",
      "indices" : [ 133, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/RTbkKLQvCx",
      "expanded_url" : "http:\/\/phave-dictionary.englishup.me\/faq\/index.html",
      "display_url" : "phave-dictionary.englishup.me\/faq\/index.html"
    } ]
  },
  "geo" : { },
  "id_str" : "676411379025354752",
  "text" : "English Grammar Profile phrasal forms added to PHaVE dictionary help https:\/\/t.co\/RTbkKLQvCx any comments welcome #eltchat #esl #efl #TEFL",
  "id" : 676411379025354752,
  "created_at" : "2015-12-14 14:40:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "676267132888309760",
  "geo" : { },
  "id_str" : "676374865985863680",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish will have a think",
  "id" : 676374865985863680,
  "in_reply_to_status_id" : 676267132888309760,
  "created_at" : "2015-12-14 12:15:09 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Antonio Ruiz Tinoco",
      "screen_name" : "aruiztinoco",
      "indices" : [ 0, 12 ],
      "id_str" : "26511350",
      "id" : 26511350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "676231983354085377",
  "geo" : { },
  "id_str" : "676269913707819008",
  "in_reply_to_user_id" : 26511350,
  "text" : "@aruiztinoco be nice to be able to copy paste the gap fills that is available only for Jpn speakers",
  "id" : 676269913707819008,
  "in_reply_to_status_id" : 676231983354085377,
  "created_at" : "2015-12-14 05:18:06 +0000",
  "in_reply_to_screen_name" : "aruiztinoco",
  "in_reply_to_user_id_str" : "26511350",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "676265584149987329",
  "geo" : { },
  "id_str" : "676266922611245056",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish yr welcome also good to be reminded of your tblt lino board",
  "id" : 676266922611245056,
  "in_reply_to_status_id" : 676265584149987329,
  "created_at" : "2015-12-14 05:06:13 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 3, 19 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/getgreatenglish\/status\/676258769211252737\/photo\/1",
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/LwfyaRjeeF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWKNxEGUAAEg3yO.jpg",
      "id_str" : "676258768112320513",
      "id" : 676258768112320513,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWKNxEGUAAEg3yO.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/LwfyaRjeeF"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/LFP1lRSFd3",
      "expanded_url" : "https:\/\/freelanceteacherselfdevelopment.wordpress.com\/2015\/12\/14\/actually-doing-task-based-teaching\/",
      "display_url" : "\u2026eteacherselfdevelopment.wordpress.com\/2015\/12\/14\/act\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "676265329912389633",
  "text" : "RT @getgreatenglish: Actually Doing Task-Based Teaching https:\/\/t.co\/LFP1lRSFd3 https:\/\/t.co\/LwfyaRjeeF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/getgreatenglish\/status\/676258769211252737\/photo\/1",
        "indices" : [ 59, 82 ],
        "url" : "https:\/\/t.co\/LwfyaRjeeF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CWKNxEGUAAEg3yO.jpg",
        "id_str" : "676258768112320513",
        "id" : 676258768112320513,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWKNxEGUAAEg3yO.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/LwfyaRjeeF"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 58 ],
        "url" : "https:\/\/t.co\/LFP1lRSFd3",
        "expanded_url" : "https:\/\/freelanceteacherselfdevelopment.wordpress.com\/2015\/12\/14\/actually-doing-task-based-teaching\/",
        "display_url" : "\u2026eteacherselfdevelopment.wordpress.com\/2015\/12\/14\/act\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "676258769211252737",
    "text" : "Actually Doing Task-Based Teaching https:\/\/t.co\/LFP1lRSFd3 https:\/\/t.co\/LwfyaRjeeF",
    "id" : 676258769211252737,
    "created_at" : "2015-12-14 04:33:49 +0000",
    "user" : {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "protected" : false,
      "id_str" : "2273617656",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724115932742721537\/LWTpFJX2_normal.jpg",
      "id" : 2273617656,
      "verified" : false
    }
  },
  "id" : 676265329912389633,
  "created_at" : "2015-12-14 04:59:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 93, 109 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/RBvfaCnAQU",
      "expanded_url" : "http:\/\/wp.me\/p2CPYN-lb",
      "display_url" : "wp.me\/p2CPYN-lb"
    } ]
  },
  "geo" : { },
  "id_str" : "676169473506811906",
  "text" : "The strange advocacy of pro-war anti-war activist Peter Tatchell https:\/\/t.co\/RBvfaCnAQU via @wordpressdotcom",
  "id" : 676169473506811906,
  "created_at" : "2015-12-13 22:38:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "676153285745709056",
  "geo" : { },
  "id_str" : "676164751773343744",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan h\/t&gt;via&gt;RT? : )",
  "id" : 676164751773343744,
  "in_reply_to_status_id" : 676153285745709056,
  "created_at" : "2015-12-13 22:20:14 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "676143590603640832",
  "geo" : { },
  "id_str" : "676162745767710721",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt the monthly digests may well suit me",
  "id" : 676162745767710721,
  "in_reply_to_status_id" : 676143590603640832,
  "created_at" : "2015-12-13 22:12:15 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "676074406041493504",
  "geo" : { },
  "id_str" : "676107407018299393",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt of all social media FB make me like \uD83D\uDE35\uD83D\uDD2B",
  "id" : 676107407018299393,
  "in_reply_to_status_id" : 676074406041493504,
  "created_at" : "2015-12-13 18:32:21 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "675768278808190979",
  "geo" : { },
  "id_str" : "676055003375759364",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt bah humbug to Zuckerberg's site ; )",
  "id" : 676055003375759364,
  "in_reply_to_status_id" : 675768278808190979,
  "created_at" : "2015-12-13 15:04:07 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yuichiro Kobayashi",
      "screen_name" : "langstat",
      "indices" : [ 91, 100 ],
      "id_str" : "108896452",
      "id" : 108896452
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 66, 77 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 78, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/YqjS0iHUtT",
      "expanded_url" : "http:\/\/score.lagoinst.info\/",
      "display_url" : "score.lagoinst.info"
    } ]
  },
  "geo" : { },
  "id_str" : "676054251999744000",
  "text" : "https:\/\/t.co\/YqjS0iHUtT Sentence Corpus of Remedial English SCoRE #corpusmooc #eltchat h\/t @langstat",
  "id" : 676054251999744000,
  "created_at" : "2015-12-13 15:01:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frankie Boyle",
      "screen_name" : "frankieboyle",
      "indices" : [ 3, 16 ],
      "id_str" : "17336372",
      "id" : 17336372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/IbhZwJmVdW",
      "expanded_url" : "http:\/\/www.frankieboyle.com\/one-time-4-mind\/",
      "display_url" : "frankieboyle.com\/one-time-4-min\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "675676684276862977",
  "text" : "RT @frankieboyle: Here is a transcript of the lecture I gave at the Southbank the other night\nhttps:\/\/t.co\/IbhZwJmVdW\nBig up again to Akala\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/IbhZwJmVdW",
        "expanded_url" : "http:\/\/www.frankieboyle.com\/one-time-4-mind\/",
        "display_url" : "frankieboyle.com\/one-time-4-min\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "672126912928555008",
    "text" : "Here is a transcript of the lecture I gave at the Southbank the other night\nhttps:\/\/t.co\/IbhZwJmVdW\nBig up again to Akala for having me on",
    "id" : 672126912928555008,
    "created_at" : "2015-12-02 18:55:18 +0000",
    "user" : {
      "name" : "Frankie Boyle",
      "screen_name" : "frankieboyle",
      "protected" : false,
      "id_str" : "17336372",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/743772932892131328\/ZcekAc_1_normal.jpg",
      "id" : 17336372,
      "verified" : true
    }
  },
  "id" : 675676684276862977,
  "created_at" : "2015-12-12 14:00:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sketch Engine",
      "screen_name" : "SketchEngine",
      "indices" : [ 3, 16 ],
      "id_str" : "841197134",
      "id" : 841197134
    }, {
      "name" : "The Sketch Engine",
      "screen_name" : "SketchEngine",
      "indices" : [ 28, 41 ],
      "id_str" : "841197134",
      "id" : 841197134
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/1WclROrjAm",
      "expanded_url" : "http:\/\/bit.ly\/1OjK9lN",
      "display_url" : "bit.ly\/1OjK9lN"
    } ]
  },
  "geo" : { },
  "id_str" : "675261863748325376",
  "text" : "RT @SketchEngine: Check out @SketchEngine tutorials prepared by James Thomas: https:\/\/t.co\/1WclROrjAm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Sketch Engine",
        "screen_name" : "SketchEngine",
        "indices" : [ 10, 23 ],
        "id_str" : "841197134",
        "id" : 841197134
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/1WclROrjAm",
        "expanded_url" : "http:\/\/bit.ly\/1OjK9lN",
        "display_url" : "bit.ly\/1OjK9lN"
      } ]
    },
    "geo" : { },
    "id_str" : "674920470542729217",
    "text" : "Check out @SketchEngine tutorials prepared by James Thomas: https:\/\/t.co\/1WclROrjAm",
    "id" : 674920470542729217,
    "created_at" : "2015-12-10 11:55:54 +0000",
    "user" : {
      "name" : "Sketch Engine",
      "screen_name" : "SketchEngine",
      "protected" : false,
      "id_str" : "841197134",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/763331747538997248\/ua_lo7Zd_normal.jpg",
      "id" : 841197134,
      "verified" : false
    }
  },
  "id" : 675261863748325376,
  "created_at" : "2015-12-11 10:32:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Yearly Awards",
      "screen_name" : "YearlyAwards",
      "indices" : [ 3, 16 ],
      "id_str" : "2951486632",
      "id" : 2951486632
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 18, 27 ],
      "id_str" : "18602422",
      "id" : 18602422
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/YearlyAwards\/status\/675102828772392961\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/UTXL4SbABw",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CV5ycf-XIAAgwgJ.png",
      "id_str" : "675102828097118208",
      "id" : 675102828097118208,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CV5ycf-XIAAgwgJ.png",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 400
      } ],
      "display_url" : "pic.twitter.com\/UTXL4SbABw"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "675172306260480000",
  "text" : "RT @YearlyAwards: @muranava Congrats, you just won a Yearly Award for Least Reflexively Carrion Exemption of 2015! https:\/\/t.co\/UTXL4SbABw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tinysubversions.com\" rel=\"nofollow\"\u003EThe Yearly Awards\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mura Nava",
        "screen_name" : "muranava",
        "indices" : [ 0, 9 ],
        "id_str" : "18602422",
        "id" : 18602422
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/YearlyAwards\/status\/675102828772392961\/photo\/1",
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/UTXL4SbABw",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CV5ycf-XIAAgwgJ.png",
        "id_str" : "675102828097118208",
        "id" : 675102828097118208,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CV5ycf-XIAAgwgJ.png",
        "sizes" : [ {
          "h" : 300,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 400
        } ],
        "display_url" : "pic.twitter.com\/UTXL4SbABw"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "675102828772392961",
    "in_reply_to_user_id" : 18602422,
    "text" : "@muranava Congrats, you just won a Yearly Award for Least Reflexively Carrion Exemption of 2015! https:\/\/t.co\/UTXL4SbABw",
    "id" : 675102828772392961,
    "created_at" : "2015-12-11 00:00:31 +0000",
    "in_reply_to_screen_name" : "muranava",
    "in_reply_to_user_id_str" : "18602422",
    "user" : {
      "name" : "The Yearly Awards",
      "screen_name" : "YearlyAwards",
      "protected" : false,
      "id_str" : "2951486632",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/549979314541039617\/fZ_XDnWz_normal.jpeg",
      "id" : 2951486632,
      "verified" : false
    }
  },
  "id" : 675172306260480000,
  "created_at" : "2015-12-11 04:36:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    }, {
      "name" : "Anthony Ash FRSA",
      "screen_name" : "Ashowski",
      "indices" : [ 17, 26 ],
      "id_str" : "316596356",
      "id" : 316596356
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/c37Q60nRfN",
      "expanded_url" : "https:\/\/docs.google.com\/spreadsheets\/d\/19v3SBsb7aEhvAQ0k4YrOpNHNNo_tH5wHUI32r4ANU-8\/pubhtml",
      "display_url" : "docs.google.com\/spreadsheets\/d\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "674949451769778178",
  "geo" : { },
  "id_str" : "674978081510178818",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish @Ashowski the keyword is Dale cone https:\/\/t.co\/c37Q60nRfN",
  "id" : 674978081510178818,
  "in_reply_to_status_id" : 674949451769778178,
  "created_at" : "2015-12-10 15:44:49 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Running Dog",
      "screen_name" : "benton_dan",
      "indices" : [ 3, 14 ],
      "id_str" : "337679613",
      "id" : 337679613
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/benton_dan\/status\/674969890344837120\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/9Wf53Kp2XU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CV35idMWEAEMSv3.jpg",
      "id_str" : "674969889522716673",
      "id" : 674969889522716673,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CV35idMWEAEMSv3.jpg",
      "sizes" : [ {
        "h" : 315,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 179,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 348,
        "resize" : "fit",
        "w" : 662
      }, {
        "h" : 348,
        "resize" : "fit",
        "w" : 662
      } ],
      "display_url" : "pic.twitter.com\/9Wf53Kp2XU"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/pA0czk2Ihg",
      "expanded_url" : "http:\/\/new.spectator.co.uk\/2015\/12\/ancient-and-modern-on-jeremy-corbyns-puppet-statecraft\/",
      "display_url" : "new.spectator.co.uk\/2015\/12\/ancien\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "674976103677693952",
  "text" : "RT @benton_dan: \"Corbyn's probably ruining democracy or whatever. Who can we quote?\"\n\"Aristotle?\"\n\"Good lad\"\nhttps:\/\/t.co\/pA0czk2Ihg https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/benton_dan\/status\/674969890344837120\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/9Wf53Kp2XU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CV35idMWEAEMSv3.jpg",
        "id_str" : "674969889522716673",
        "id" : 674969889522716673,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CV35idMWEAEMSv3.jpg",
        "sizes" : [ {
          "h" : 315,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 179,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 348,
          "resize" : "fit",
          "w" : 662
        }, {
          "h" : 348,
          "resize" : "fit",
          "w" : 662
        } ],
        "display_url" : "pic.twitter.com\/9Wf53Kp2XU"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/pA0czk2Ihg",
        "expanded_url" : "http:\/\/new.spectator.co.uk\/2015\/12\/ancient-and-modern-on-jeremy-corbyns-puppet-statecraft\/",
        "display_url" : "new.spectator.co.uk\/2015\/12\/ancien\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "674969890344837120",
    "text" : "\"Corbyn's probably ruining democracy or whatever. Who can we quote?\"\n\"Aristotle?\"\n\"Good lad\"\nhttps:\/\/t.co\/pA0czk2Ihg https:\/\/t.co\/9Wf53Kp2XU",
    "id" : 674969890344837120,
    "created_at" : "2015-12-10 15:12:16 +0000",
    "user" : {
      "name" : "Running Dog",
      "screen_name" : "benton_dan",
      "protected" : false,
      "id_str" : "337679613",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/761669254160744448\/BalT_iW6_normal.jpg",
      "id" : 337679613,
      "verified" : false
    }
  },
  "id" : 674976103677693952,
  "created_at" : "2015-12-10 15:36:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Price",
      "screen_name" : "fionaljp",
      "indices" : [ 0, 9 ],
      "id_str" : "251372057",
      "id" : 251372057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "674932005067452416",
  "geo" : { },
  "id_str" : "674936181851860992",
  "in_reply_to_user_id" : 251372057,
  "text" : "@fionaljp oh that's interesting I don't remember that when I did it has it always been on celta?",
  "id" : 674936181851860992,
  "in_reply_to_status_id" : 674932005067452416,
  "created_at" : "2015-12-10 12:58:20 +0000",
  "in_reply_to_screen_name" : "fionaljp",
  "in_reply_to_user_id_str" : "251372057",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenys Hanson",
      "screen_name" : "GlenysHanson",
      "indices" : [ 0, 13 ],
      "id_str" : "527238447",
      "id" : 527238447
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "674916239253336065",
  "geo" : { },
  "id_str" : "674916983213830144",
  "in_reply_to_user_id" : 527238447,
  "text" : "@GlenysHanson i read that somewhere but can't recall it well now ;)",
  "id" : 674916983213830144,
  "in_reply_to_status_id" : 674916239253336065,
  "created_at" : "2015-12-10 11:42:02 +0000",
  "in_reply_to_screen_name" : "GlenysHanson",
  "in_reply_to_user_id_str" : "527238447",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HaveUread",
      "screen_name" : "thisbyanychance",
      "indices" : [ 21, 37 ],
      "id_str" : "3416415189",
      "id" : 3416415189
    }, {
      "name" : "Fiona Price",
      "screen_name" : "fionaljp",
      "indices" : [ 44, 53 ],
      "id_str" : "251372057",
      "id" : 251372057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "674909359349059584",
  "geo" : { },
  "id_str" : "674914483886800897",
  "in_reply_to_user_id" : 251372057,
  "text" : "interesting title :0 @thisbyanychance  tell @fionaljp to tell others about learning styles",
  "id" : 674914483886800897,
  "in_reply_to_status_id" : 674909359349059584,
  "created_at" : "2015-12-10 11:32:06 +0000",
  "in_reply_to_screen_name" : "fionaljp",
  "in_reply_to_user_id_str" : "251372057",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "indices" : [ 0, 10 ],
      "id_str" : "577931950",
      "id" : 577931950
    }, {
      "name" : "Academia",
      "screen_name" : "academia",
      "indices" : [ 11, 20 ],
      "id_str" : "22809165",
      "id" : 22809165
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "674911673346605056",
  "geo" : { },
  "id_str" : "674913409033502720",
  "in_reply_to_user_id" : 577931950,
  "text" : "@RudyLoock @academia oui une question de \u2696 ?",
  "id" : 674913409033502720,
  "in_reply_to_status_id" : 674911673346605056,
  "created_at" : "2015-12-10 11:27:50 +0000",
  "in_reply_to_screen_name" : "RudyLoock",
  "in_reply_to_user_id_str" : "577931950",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "indices" : [ 0, 10 ],
      "id_str" : "577931950",
      "id" : 577931950
    }, {
      "name" : "Academia",
      "screen_name" : "academia",
      "indices" : [ 11, 20 ],
      "id_str" : "22809165",
      "id" : 22809165
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "674906742531203072",
  "geo" : { },
  "id_str" : "674907438236176384",
  "in_reply_to_user_id" : 577931950,
  "text" : "@RudyLoock @academia oui et gratuit entre guillemets?",
  "id" : 674907438236176384,
  "in_reply_to_status_id" : 674906742531203072,
  "created_at" : "2015-12-10 11:04:07 +0000",
  "in_reply_to_screen_name" : "RudyLoock",
  "in_reply_to_user_id_str" : "577931950",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "indices" : [ 0, 10 ],
      "id_str" : "577931950",
      "id" : 577931950
    }, {
      "name" : "Academia",
      "screen_name" : "academia",
      "indices" : [ 11, 20 ],
      "id_str" : "22809165",
      "id" : 22809165
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "674905350420713472",
  "geo" : { },
  "id_str" : "674906117424717824",
  "in_reply_to_user_id" : 577931950,
  "text" : "@RudyLoock @academia c'est comme Facebook mais en pire?",
  "id" : 674906117424717824,
  "in_reply_to_status_id" : 674905350420713472,
  "created_at" : "2015-12-10 10:58:52 +0000",
  "in_reply_to_screen_name" : "RudyLoock",
  "in_reply_to_user_id_str" : "577931950",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HaveUread",
      "screen_name" : "thisbyanychance",
      "indices" : [ 0, 16 ],
      "id_str" : "3416415189",
      "id" : 3416415189
    }, {
      "name" : "NikPeachey",
      "screen_name" : "NikPeachey",
      "indices" : [ 23, 34 ],
      "id_str" : "14548913",
      "id" : 14548913
    }, {
      "name" : "Clare  Lavery",
      "screen_name" : "clerotto",
      "indices" : [ 35, 44 ],
      "id_str" : "1445778456",
      "id" : 1445778456
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "anyothers",
      "indices" : [ 53, 63 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "674902567218999296",
  "geo" : { },
  "id_str" : "674903223719866368",
  "in_reply_to_user_id" : 18602422,
  "text" : "@thisbyanychance tell  @NikPeachey @clerotto to tell #anyothers about Dale cone",
  "id" : 674903223719866368,
  "in_reply_to_status_id" : 674902567218999296,
  "created_at" : "2015-12-10 10:47:22 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NikPeachey",
      "screen_name" : "NikPeachey",
      "indices" : [ 0, 11 ],
      "id_str" : "14548913",
      "id" : 14548913
    }, {
      "name" : "Clare  Lavery",
      "screen_name" : "clerotto",
      "indices" : [ 12, 21 ],
      "id_str" : "1445778456",
      "id" : 1445778456
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "674897268500246528",
  "geo" : { },
  "id_str" : "674902567218999296",
  "in_reply_to_user_id" : 14548913,
  "text" : "@NikPeachey @clerotto i like the symmetry here replacing one misconception with another : )",
  "id" : 674902567218999296,
  "in_reply_to_status_id" : 674897268500246528,
  "created_at" : "2015-12-10 10:44:45 +0000",
  "in_reply_to_screen_name" : "NikPeachey",
  "in_reply_to_user_id_str" : "14548913",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenny Eclair",
      "screen_name" : "jennyeclair",
      "indices" : [ 3, 15 ],
      "id_str" : "191768822",
      "id" : 191768822
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/jennyeclair\/status\/674886564175093764\/photo\/1",
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/oumBha7N5k",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CV2tv7rXIAACSnV.jpg",
      "id_str" : "674886558160461824",
      "id" : 674886558160461824,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CV2tv7rXIAACSnV.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 852
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 852
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 451,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/oumBha7N5k"
    } ],
    "hashtags" : [ {
      "text" : "respect",
      "indices" : [ 88, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "674895128071446528",
  "text" : "RT @jennyeclair: Here is a giant picture of a man who has just set fire to his own fart #respect https:\/\/t.co\/oumBha7N5k",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/jennyeclair\/status\/674886564175093764\/photo\/1",
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/oumBha7N5k",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CV2tv7rXIAACSnV.jpg",
        "id_str" : "674886558160461824",
        "id" : 674886558160461824,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CV2tv7rXIAACSnV.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 852
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 852
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 451,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/oumBha7N5k"
      } ],
      "hashtags" : [ {
        "text" : "respect",
        "indices" : [ 71, 79 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "674886564175093764",
    "text" : "Here is a giant picture of a man who has just set fire to his own fart #respect https:\/\/t.co\/oumBha7N5k",
    "id" : 674886564175093764,
    "created_at" : "2015-12-10 09:41:10 +0000",
    "user" : {
      "name" : "Jenny Eclair",
      "screen_name" : "jennyeclair",
      "protected" : false,
      "id_str" : "191768822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1125601841\/je_twitter_normal.jpg",
      "id" : 191768822,
      "verified" : true
    }
  },
  "id" : 674895128071446528,
  "created_at" : "2015-12-10 10:15:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Caulfield",
      "screen_name" : "holden",
      "indices" : [ 3, 10 ],
      "id_str" : "1912681",
      "id" : 1912681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/EiIkxoOMLc",
      "expanded_url" : "http:\/\/hapgood.us\/2015\/12\/09\/introducing-wikity\/",
      "display_url" : "hapgood.us\/2015\/12\/09\/int\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "674840015998963712",
  "text" : "RT @holden: New Hapgood post: Introducing Wikity. https:\/\/t.co\/EiIkxoOMLc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 61 ],
        "url" : "https:\/\/t.co\/EiIkxoOMLc",
        "expanded_url" : "http:\/\/hapgood.us\/2015\/12\/09\/introducing-wikity\/",
        "display_url" : "hapgood.us\/2015\/12\/09\/int\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "674764313962254336",
    "text" : "New Hapgood post: Introducing Wikity. https:\/\/t.co\/EiIkxoOMLc",
    "id" : 674764313962254336,
    "created_at" : "2015-12-10 01:35:23 +0000",
    "user" : {
      "name" : "Mike Caulfield",
      "screen_name" : "holden",
      "protected" : false,
      "id_str" : "1912681",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/752538301538545665\/mXNoIc4W_normal.jpg",
      "id" : 1912681,
      "verified" : false
    }
  },
  "id" : 674840015998963712,
  "created_at" : "2015-12-10 06:36:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/medialens\/status\/674592085207556096\/photo\/1",
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/XDsEtTqq4O",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVyh7RIWwAAn6F9.png",
      "id_str" : "674592083781533696",
      "id" : 674592083781533696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVyh7RIWwAAn6F9.png",
      "sizes" : [ {
        "h" : 182,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 418,
        "resize" : "fit",
        "w" : 782
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 321,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 418,
        "resize" : "fit",
        "w" : 782
      } ],
      "display_url" : "pic.twitter.com\/XDsEtTqq4O"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/vq9Md8PIDR",
      "expanded_url" : "http:\/\/www.medialens.org\/index.php\/alerts\/alert-archive\/2015\/807-manufacturing-consensus.html",
      "display_url" : "medialens.org\/index.php\/aler\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "674663078974332928",
  "text" : "RT @medialens: Media Alert: Manufacturing Consensus - Hilary Benn's Speech https:\/\/t.co\/vq9Md8PIDR https:\/\/t.co\/XDsEtTqq4O",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/medialens\/status\/674592085207556096\/photo\/1",
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/XDsEtTqq4O",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CVyh7RIWwAAn6F9.png",
        "id_str" : "674592083781533696",
        "id" : 674592083781533696,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVyh7RIWwAAn6F9.png",
        "sizes" : [ {
          "h" : 182,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 418,
          "resize" : "fit",
          "w" : 782
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 321,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 418,
          "resize" : "fit",
          "w" : 782
        } ],
        "display_url" : "pic.twitter.com\/XDsEtTqq4O"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/vq9Md8PIDR",
        "expanded_url" : "http:\/\/www.medialens.org\/index.php\/alerts\/alert-archive\/2015\/807-manufacturing-consensus.html",
        "display_url" : "medialens.org\/index.php\/aler\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "674592085207556096",
    "text" : "Media Alert: Manufacturing Consensus - Hilary Benn's Speech https:\/\/t.co\/vq9Md8PIDR https:\/\/t.co\/XDsEtTqq4O",
    "id" : 674592085207556096,
    "created_at" : "2015-12-09 14:11:01 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 674663078974332928,
  "created_at" : "2015-12-09 18:53:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bella Caledonia",
      "screen_name" : "bellacaledonia",
      "indices" : [ 3, 18 ],
      "id_str" : "103554348",
      "id" : 103554348
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/bellacaledonia\/status\/674647078245695489\/photo\/1",
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/7dGGPfnILp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVzT8SxU8AA8Qbz.jpg",
      "id_str" : "674647076983074816",
      "id" : 674647076983074816,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVzT8SxU8AA8Qbz.jpg",
      "sizes" : [ {
        "h" : 390,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 650,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 221,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 650,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/7dGGPfnILp"
    } ],
    "hashtags" : [ {
      "text" : "COP21",
      "indices" : [ 33, 39 ]
    }, {
      "text" : "Brandalism",
      "indices" : [ 40, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "674651218153758721",
  "text" : "RT @bellacaledonia: Real ads for #COP21 #Brandalism https:\/\/t.co\/7dGGPfnILp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/bellacaledonia\/status\/674647078245695489\/photo\/1",
        "indices" : [ 32, 55 ],
        "url" : "https:\/\/t.co\/7dGGPfnILp",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CVzT8SxU8AA8Qbz.jpg",
        "id_str" : "674647076983074816",
        "id" : 674647076983074816,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVzT8SxU8AA8Qbz.jpg",
        "sizes" : [ {
          "h" : 390,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 650,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 221,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 650,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/7dGGPfnILp"
      } ],
      "hashtags" : [ {
        "text" : "COP21",
        "indices" : [ 13, 19 ]
      }, {
        "text" : "Brandalism",
        "indices" : [ 20, 31 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "674647078245695489",
    "text" : "Real ads for #COP21 #Brandalism https:\/\/t.co\/7dGGPfnILp",
    "id" : 674647078245695489,
    "created_at" : "2015-12-09 17:49:32 +0000",
    "user" : {
      "name" : "Bella Caledonia",
      "screen_name" : "bellacaledonia",
      "protected" : false,
      "id_str" : "103554348",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/732831340194897925\/WGVyJGiO_normal.jpg",
      "id" : 103554348,
      "verified" : false
    }
  },
  "id" : 674651218153758721,
  "created_at" : "2015-12-09 18:05:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/5dKXgSWguw",
      "expanded_url" : "http:\/\/Antiwar.com",
      "display_url" : "Antiwar.com"
    }, {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/5dKXgSWguw",
      "expanded_url" : "http:\/\/Antiwar.com",
      "display_url" : "Antiwar.com"
    }, {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/hUoBlOzzAG",
      "expanded_url" : "http:\/\/original.antiwar.com\/john-v-walsh\/2015\/12\/07\/diana-johnstone-dissects-hillary-queen-of-chaos\/#.VmfxRSaEQCI.twitter",
      "display_url" : "original.antiwar.com\/john-v-walsh\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "674517851777212416",
  "text" : "Diana Johnstone Dissects Hillary, Queen of Chaos - https:\/\/t.co\/5dKXgSWguw Original by -- https:\/\/t.co\/5dKXgSWguw https:\/\/t.co\/hUoBlOzzAG",
  "id" : 674517851777212416,
  "created_at" : "2015-12-09 09:16:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "674406021083762688",
  "geo" : { },
  "id_str" : "674514138492739584",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish ooh nice cheers for that :) my adult students so far have had ios devices :\/",
  "id" : 674514138492739584,
  "in_reply_to_status_id" : 674406021083762688,
  "created_at" : "2015-12-09 09:01:17 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Lavigne",
      "screen_name" : "sam_lavigne",
      "indices" : [ 3, 15 ],
      "id_str" : "6428702",
      "id" : 6428702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/4HZgoy1ipB",
      "expanded_url" : "http:\/\/antiboredom.github.io\/zuckify\/",
      "display_url" : "antiboredom.github.io\/zuckify\/"
    } ]
  },
  "geo" : { },
  "id_str" : "674389227598045185",
  "text" : "RT @sam_lavigne: zuckify something: https:\/\/t.co\/4HZgoy1ipB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 19, 42 ],
        "url" : "https:\/\/t.co\/4HZgoy1ipB",
        "expanded_url" : "http:\/\/antiboredom.github.io\/zuckify\/",
        "display_url" : "antiboredom.github.io\/zuckify\/"
      } ]
    },
    "geo" : { },
    "id_str" : "672891198185611264",
    "text" : "zuckify something: https:\/\/t.co\/4HZgoy1ipB",
    "id" : 672891198185611264,
    "created_at" : "2015-12-04 21:32:18 +0000",
    "user" : {
      "name" : "Sam Lavigne",
      "screen_name" : "sam_lavigne",
      "protected" : false,
      "id_str" : "6428702",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/453703393907712000\/-NTZsg_T_normal.jpeg",
      "id" : 6428702,
      "verified" : false
    }
  },
  "id" : 674389227598045185,
  "created_at" : "2015-12-09 00:44:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "William Ian O'Byrne",
      "screen_name" : "wiobyrne",
      "indices" : [ 3, 12 ],
      "id_str" : "88676762",
      "id" : 88676762
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/wiobyrne\/status\/674380975887941633\/photo\/1",
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/x0iUi70YfY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVvh7HWUEAA1S5-.png",
      "id_str" : "674380974923190272",
      "id" : 674380974923190272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVvh7HWUEAA1S5-.png",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 358,
        "resize" : "fit",
        "w" : 636
      }, {
        "h" : 358,
        "resize" : "fit",
        "w" : 636
      } ],
      "display_url" : "pic.twitter.com\/x0iUi70YfY"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/vYMXU7JsJC",
      "expanded_url" : "http:\/\/bit.ly\/1jN2aAF",
      "display_url" : "bit.ly\/1jN2aAF"
    } ]
  },
  "geo" : { },
  "id_str" : "674388537425264640",
  "text" : "RT @wiobyrne: Star Wars Smashed Up With Biggie's Life After Death Is Awesome https:\/\/t.co\/vYMXU7JsJC https:\/\/t.co\/x0iUi70YfY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/friendsplus.me\" rel=\"nofollow\"\u003EFriends Me\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/wiobyrne\/status\/674380975887941633\/photo\/1",
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/x0iUi70YfY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CVvh7HWUEAA1S5-.png",
        "id_str" : "674380974923190272",
        "id" : 674380974923190272,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVvh7HWUEAA1S5-.png",
        "sizes" : [ {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 358,
          "resize" : "fit",
          "w" : 636
        }, {
          "h" : 358,
          "resize" : "fit",
          "w" : 636
        } ],
        "display_url" : "pic.twitter.com\/x0iUi70YfY"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/vYMXU7JsJC",
        "expanded_url" : "http:\/\/bit.ly\/1jN2aAF",
        "display_url" : "bit.ly\/1jN2aAF"
      } ]
    },
    "geo" : { },
    "id_str" : "674380975887941633",
    "text" : "Star Wars Smashed Up With Biggie's Life After Death Is Awesome https:\/\/t.co\/vYMXU7JsJC https:\/\/t.co\/x0iUi70YfY",
    "id" : 674380975887941633,
    "created_at" : "2015-12-09 00:12:08 +0000",
    "user" : {
      "name" : "William Ian O'Byrne",
      "screen_name" : "wiobyrne",
      "protected" : false,
      "id_str" : "88676762",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/519580082\/twitter_normal.jpg",
      "id" : 88676762,
      "verified" : false
    }
  },
  "id" : 674388537425264640,
  "created_at" : "2015-12-09 00:42:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "William Ian O'Byrne",
      "screen_name" : "wiobyrne",
      "indices" : [ 0, 9 ],
      "id_str" : "88676762",
      "id" : 88676762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "674380975887941633",
  "geo" : { },
  "id_str" : "674388473915252740",
  "in_reply_to_user_id" : 88676762,
  "text" : "@wiobyrne ha Big Poppa refrain is nice touch :)",
  "id" : 674388473915252740,
  "in_reply_to_status_id" : 674380975887941633,
  "created_at" : "2015-12-09 00:41:56 +0000",
  "in_reply_to_screen_name" : "wiobyrne",
  "in_reply_to_user_id_str" : "88676762",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "674370632201674753",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish hi seems need to have same settings has user who left review i.e. same locale &amp; lang",
  "id" : 674370632201674753,
  "created_at" : "2015-12-08 23:31:02 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "4TUNE Teller App",
      "screen_name" : "4tunetellernet",
      "indices" : [ 0, 15 ],
      "id_str" : "467634146",
      "id" : 467634146
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "674366885853556736",
  "geo" : { },
  "id_str" : "674369719093354496",
  "in_reply_to_user_id" : 467634146,
  "text" : "@4tunetellernet yah yah sent u text",
  "id" : 674369719093354496,
  "in_reply_to_status_id" : 674366885853556736,
  "created_at" : "2015-12-08 23:27:24 +0000",
  "in_reply_to_screen_name" : "4tunetellernet",
  "in_reply_to_user_id_str" : "467634146",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 89, 105 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "YouAintNoMuslimBruv",
      "indices" : [ 0, 20 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/wY0PJOsU1O",
      "expanded_url" : "http:\/\/wp.me\/p3swZr-bD",
      "display_url" : "wp.me\/p3swZr-bD"
    } ]
  },
  "geo" : { },
  "id_str" : "674250209778663424",
  "text" : "#YouAintNoMuslimBruv? It\u2019s just not true, says David Cameron https:\/\/t.co\/wY0PJOsU1O via @wordpressdotcom",
  "id" : 674250209778663424,
  "created_at" : "2015-12-08 15:32:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patricia Brenes",
      "screen_name" : "patriciambr",
      "indices" : [ 0, 12 ],
      "id_str" : "35764443",
      "id" : 35764443
    }, {
      "name" : "Sandra Cravero",
      "screen_name" : "sandracravero",
      "indices" : [ 13, 27 ],
      "id_str" : "18705997",
      "id" : 18705997
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/JNCVwNAy6P",
      "expanded_url" : "https:\/\/sites.google.com\/site\/multidimensionaltagger\/",
      "display_url" : "sites.google.com\/site\/multidime\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "674233584232869888",
  "geo" : { },
  "id_str" : "674234739583266816",
  "in_reply_to_user_id" : 35764443,
  "text" : "@patriciambr @sandracravero thx but am no expert :) register? you could try https:\/\/t.co\/JNCVwNAy6P ?",
  "id" : 674234739583266816,
  "in_reply_to_status_id" : 674233584232869888,
  "created_at" : "2015-12-08 14:31:03 +0000",
  "in_reply_to_screen_name" : "patriciambr",
  "in_reply_to_user_id_str" : "35764443",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELTjam",
      "screen_name" : "eltjam",
      "indices" : [ 0, 7 ],
      "id_str" : "1356363686",
      "id" : 1356363686
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "674150198088564737",
  "geo" : { },
  "id_str" : "674150950282657792",
  "in_reply_to_user_id" : 1356363686,
  "text" : "@eltjam great link to a pdf of Language Machine in comments",
  "id" : 674150950282657792,
  "in_reply_to_status_id" : 674150198088564737,
  "created_at" : "2015-12-08 08:58:06 +0000",
  "in_reply_to_screen_name" : "eltjam",
  "in_reply_to_user_id_str" : "1356363686",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patricia Brenes",
      "screen_name" : "patriciambr",
      "indices" : [ 3, 15 ],
      "id_str" : "35764443",
      "id" : 35764443
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/patriciambr\/status\/674076151535575040\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/xDrpbpvAG7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVrMsC1WcAAXIec.jpg",
      "id_str" : "674076151292260352",
      "id" : 674076151292260352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVrMsC1WcAAXIec.jpg",
      "sizes" : [ {
        "h" : 200,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 200,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 200,
        "resize" : "fit",
        "w" : 400
      } ],
      "display_url" : "pic.twitter.com\/xDrpbpvAG7"
    } ],
    "hashtags" : [ {
      "text" : "1nt",
      "indices" : [ 55, 59 ]
    }, {
      "text" : "xl8",
      "indices" : [ 76, 80 ]
    }, {
      "text" : "t9y",
      "indices" : [ 81, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/oqkNZ6E21F",
      "expanded_url" : "http:\/\/bit.ly\/1PSnOlv",
      "display_url" : "bit.ly\/1PSnOlv"
    } ]
  },
  "geo" : { },
  "id_str" : "674142024786968576",
  "text" : "RT @patriciambr: Readings, tools, and useful links for #1nt corpus analysis #xl8 #t9y # https:\/\/t.co\/oqkNZ6E21F https:\/\/t.co\/xDrpbpvAG7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/patriciambr\/status\/674076151535575040\/photo\/1",
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/xDrpbpvAG7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CVrMsC1WcAAXIec.jpg",
        "id_str" : "674076151292260352",
        "id" : 674076151292260352,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVrMsC1WcAAXIec.jpg",
        "sizes" : [ {
          "h" : 200,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 200,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 200,
          "resize" : "fit",
          "w" : 400
        } ],
        "display_url" : "pic.twitter.com\/xDrpbpvAG7"
      } ],
      "hashtags" : [ {
        "text" : "1nt",
        "indices" : [ 38, 42 ]
      }, {
        "text" : "xl8",
        "indices" : [ 59, 63 ]
      }, {
        "text" : "t9y",
        "indices" : [ 64, 68 ]
      } ],
      "urls" : [ {
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/oqkNZ6E21F",
        "expanded_url" : "http:\/\/bit.ly\/1PSnOlv",
        "display_url" : "bit.ly\/1PSnOlv"
      } ]
    },
    "geo" : { },
    "id_str" : "674076151535575040",
    "text" : "Readings, tools, and useful links for #1nt corpus analysis #xl8 #t9y # https:\/\/t.co\/oqkNZ6E21F https:\/\/t.co\/xDrpbpvAG7",
    "id" : 674076151535575040,
    "created_at" : "2015-12-08 04:00:52 +0000",
    "user" : {
      "name" : "Patricia Brenes",
      "screen_name" : "patriciambr",
      "protected" : false,
      "id_str" : "35764443",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/540310171541438464\/YprBqoGt_normal.jpeg",
      "id" : 35764443,
      "verified" : false
    }
  },
  "id" : 674142024786968576,
  "created_at" : "2015-12-08 08:22:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dreamreader",
      "screen_name" : "dreamreadernet",
      "indices" : [ 3, 18 ],
      "id_str" : "570887893",
      "id" : 570887893
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 140 ],
      "url" : "https:\/\/t.co\/29XBmMTU7F",
      "expanded_url" : "http:\/\/dreamreader.net\/making-a-difference\/",
      "display_url" : "dreamreader.net\/making-a-diffe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "674141840493453312",
  "text" : "RT @dreamreadernet: Our newest blog post: Neil talks about his motivational strategy for the classroom and why it works: https:\/\/t.co\/29XBm\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/29XBmMTU7F",
        "expanded_url" : "http:\/\/dreamreader.net\/making-a-difference\/",
        "display_url" : "dreamreader.net\/making-a-diffe\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "674104412583907328",
    "text" : "Our newest blog post: Neil talks about his motivational strategy for the classroom and why it works: https:\/\/t.co\/29XBmMTU7F",
    "id" : 674104412583907328,
    "created_at" : "2015-12-08 05:53:10 +0000",
    "user" : {
      "name" : "dreamreader",
      "screen_name" : "dreamreadernet",
      "protected" : false,
      "id_str" : "570887893",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724839393731706880\/hkJymXOR_normal.jpg",
      "id" : 570887893,
      "verified" : false
    }
  },
  "id" : 674141840493453312,
  "created_at" : "2015-12-08 08:21:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Old",
      "screen_name" : "oldandrewuk",
      "indices" : [ 0, 12 ],
      "id_str" : "97858519",
      "id" : 97858519
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/O2vXePtqIS",
      "expanded_url" : "http:\/\/gph.is\/1c6lVI8",
      "display_url" : "gph.is\/1c6lVI8"
    } ]
  },
  "in_reply_to_status_id_str" : "673993607775461389",
  "geo" : { },
  "id_str" : "673995736774782976",
  "in_reply_to_user_id" : 97858519,
  "text" : "@oldandrewuk true maybe too nuanced a representation less nuanced https:\/\/t.co\/O2vXePtqIS",
  "id" : 673995736774782976,
  "in_reply_to_status_id" : 673993607775461389,
  "created_at" : "2015-12-07 22:41:20 +0000",
  "in_reply_to_screen_name" : "oldandrewuk",
  "in_reply_to_user_id_str" : "97858519",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 0, 11 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/Uqd0TIL7sE",
      "expanded_url" : "http:\/\/capitolwords.org\/term\/mojo\/?search=1",
      "display_url" : "capitolwords.org\/term\/mojo\/?sea\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "673992337517842434",
  "geo" : { },
  "id_str" : "673993167641976832",
  "in_reply_to_user_id" : 14663837,
  "text" : "@pchallinor mojo favoured by Republicans so Osborne knows his audience https:\/\/t.co\/Uqd0TIL7sE",
  "id" : 673993167641976832,
  "in_reply_to_status_id" : 673992337517842434,
  "created_at" : "2015-12-07 22:31:08 +0000",
  "in_reply_to_screen_name" : "pchallinor",
  "in_reply_to_user_id_str" : "14663837",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 0, 11 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/We9XJE8zDR",
      "expanded_url" : "http:\/\/bit.ly\/1OezyJ3",
      "display_url" : "bit.ly\/1OezyJ3"
    } ]
  },
  "in_reply_to_status_id_str" : "673986696208347136",
  "geo" : { },
  "id_str" : "673990384767340544",
  "in_reply_to_user_id" : 18602422,
  "text" : "@pchallinor mojo been been used 3 times in past all by Labour hmm https:\/\/t.co\/We9XJE8zDR",
  "id" : 673990384767340544,
  "in_reply_to_status_id" : 673986696208347136,
  "created_at" : "2015-12-07 22:20:04 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 30, 41 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/673988559234289664\/photo\/1",
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/bMxfneATaD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVp9BdyWcAApJMP.png",
      "id_str" : "673988558374465536",
      "id" : 673988558374465536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVp9BdyWcAApJMP.png",
      "sizes" : [ {
        "h" : 149,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 149,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 99,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 149,
        "resize" : "crop",
        "w" : 149
      }, {
        "h" : 56,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/bMxfneATaD"
    } ],
    "hashtags" : [ {
      "text" : "mojo",
      "indices" : [ 0, 5 ]
    }, {
      "text" : "YouAintNoBruvMoron",
      "indices" : [ 7, 26 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "673975383247732736",
  "geo" : { },
  "id_str" : "673988559234289664",
  "in_reply_to_user_id" : 14663837,
  "text" : "#mojo  #YouAintNoBruvMoron :\/ @pchallinor https:\/\/t.co\/bMxfneATaD",
  "id" : 673988559234289664,
  "in_reply_to_status_id" : 673975383247732736,
  "created_at" : "2015-12-07 22:12:49 +0000",
  "in_reply_to_screen_name" : "pchallinor",
  "in_reply_to_user_id_str" : "14663837",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 0, 11 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "673980577524109314",
  "geo" : { },
  "id_str" : "673986696208347136",
  "in_reply_to_user_id" : 14663837,
  "text" : "@pchallinor 4 and 5 for Osborne no doubt",
  "id" : 673986696208347136,
  "in_reply_to_status_id" : 673980577524109314,
  "created_at" : "2015-12-07 22:05:25 +0000",
  "in_reply_to_screen_name" : "pchallinor",
  "in_reply_to_user_id_str" : "14663837",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "YouAintNoBruvMoron",
      "indices" : [ 84, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/m6IDazGiHI",
      "expanded_url" : "http:\/\/www.heraldscotland.com\/news\/14129765.Osborne__UK_has__got_its_mojo_back__with_air_strikes\/",
      "display_url" : "heraldscotland.com\/news\/14129765.\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "673985886426693632",
  "text" : "RT @pchallinor: You talkin ta me, ya sand-nigga muthafucka? You fuckin wid da Gidz! #YouAintNoBruvMoron https:\/\/t.co\/m6IDazGiHI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "YouAintNoBruvMoron",
        "indices" : [ 68, 87 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/m6IDazGiHI",
        "expanded_url" : "http:\/\/www.heraldscotland.com\/news\/14129765.Osborne__UK_has__got_its_mojo_back__with_air_strikes\/",
        "display_url" : "heraldscotland.com\/news\/14129765.\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "673975383247732736",
    "text" : "You talkin ta me, ya sand-nigga muthafucka? You fuckin wid da Gidz! #YouAintNoBruvMoron https:\/\/t.co\/m6IDazGiHI",
    "id" : 673975383247732736,
    "created_at" : "2015-12-07 21:20:27 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 673985886426693632,
  "created_at" : "2015-12-07 22:02:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "20 Minutes",
      "screen_name" : "20Minutes",
      "indices" : [ 86, 96 ],
      "id_str" : "2649991",
      "id" : 2649991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/zQgP5KdoVh",
      "expanded_url" : "http:\/\/www.20minutes.fr\/elections\/1745291-20151207-sondage-regionales-2015-34-jeunes-vote-front-national",
      "display_url" : "20minutes.fr\/elections\/1745\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "673729644827398144",
  "text" : "R\u00E9gionales 2015: 34% des jeunes ont vot\u00E9 Front national - https:\/\/t.co\/zQgP5KdoVh via @20minutes",
  "id" : 673729644827398144,
  "created_at" : "2015-12-07 05:03:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kamila Linkov\u00E1",
      "screen_name" : "kamilaofprague",
      "indices" : [ 0, 15 ],
      "id_str" : "3439998148",
      "id" : 3439998148
    }, {
      "name" : "Michelle Worgan",
      "screen_name" : "michelleworgan",
      "indices" : [ 62, 77 ],
      "id_str" : "20764799",
      "id" : 20764799
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "673576586172571650",
  "geo" : { },
  "id_str" : "673584492465020928",
  "in_reply_to_user_id" : 3439998148,
  "text" : "@kamilaofprague those short stories are really great kudos to @michelleworgan",
  "id" : 673584492465020928,
  "in_reply_to_status_id" : 673576586172571650,
  "created_at" : "2015-12-06 19:27:12 +0000",
  "in_reply_to_screen_name" : "kamilaofprague",
  "in_reply_to_user_id_str" : "3439998148",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kamila Linkov\u00E1",
      "screen_name" : "kamilaofprague",
      "indices" : [ 0, 15 ],
      "id_str" : "3439998148",
      "id" : 3439998148
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "673575911510396928",
  "in_reply_to_user_id" : 3439998148,
  "text" : "@kamilaofprague great thanks for RT of PHaVE Dictionary :)",
  "id" : 673575911510396928,
  "created_at" : "2015-12-06 18:53:06 +0000",
  "in_reply_to_screen_name" : "kamilaofprague",
  "in_reply_to_user_id_str" : "3439998148",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 3, 14 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "673575634317258752",
  "text" : "RT @hughdellar: Judging from Sugata Mitra's rhetorical style, someone needs to create a new law stating the time before opponents are compa\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "672697592707489792",
    "text" : "Judging from Sugata Mitra's rhetorical style, someone needs to create a new law stating the time before opponents are compared to ISIS!",
    "id" : 672697592707489792,
    "created_at" : "2015-12-04 08:42:58 +0000",
    "user" : {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "protected" : false,
      "id_str" : "88202140",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2040881292\/Hugh_Dellar_photo_normal.jpg",
      "id" : 88202140,
      "verified" : false
    }
  },
  "id" : 673575634317258752,
  "created_at" : "2015-12-06 18:52:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil Clark",
      "screen_name" : "NeilClark66",
      "indices" : [ 3, 15 ],
      "id_str" : "728039605",
      "id" : 728039605
    }, {
      "name" : "George Galloway",
      "screen_name" : "georgegalloway",
      "indices" : [ 103, 118 ],
      "id_str" : "15484198",
      "id" : 15484198
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/hEvWT3cyEV",
      "expanded_url" : "http:\/\/bit.ly\/1NzsxXk",
      "display_url" : "bit.ly\/1NzsxXk"
    } ]
  },
  "geo" : { },
  "id_str" : "673543294715056128",
  "text" : "RT @NeilClark66: As prowar MPs complain of 'bullying' a reminder of how a brutal physical attack on MP @georgegalloway was ignored \u200B https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "George Galloway",
        "screen_name" : "georgegalloway",
        "indices" : [ 86, 101 ],
        "id_str" : "15484198",
        "id" : 15484198
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/hEvWT3cyEV",
        "expanded_url" : "http:\/\/bit.ly\/1NzsxXk",
        "display_url" : "bit.ly\/1NzsxXk"
      } ]
    },
    "geo" : { },
    "id_str" : "673536865245519872",
    "text" : "As prowar MPs complain of 'bullying' a reminder of how a brutal physical attack on MP @georgegalloway was ignored \u200B https:\/\/t.co\/hEvWT3cyEV",
    "id" : 673536865245519872,
    "created_at" : "2015-12-06 16:17:57 +0000",
    "user" : {
      "name" : "Neil Clark",
      "screen_name" : "NeilClark66",
      "protected" : false,
      "id_str" : "728039605",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2451450991\/neil_clark_normal.png",
      "id" : 728039605,
      "verified" : false
    }
  },
  "id" : 673543294715056128,
  "created_at" : "2015-12-06 16:43:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lynn Cherny",
      "screen_name" : "arnicas",
      "indices" : [ 3, 11 ],
      "id_str" : "6146692",
      "id" : 6146692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 143, 144 ],
      "url" : "https:\/\/t.co\/gnbK2DA8oX",
      "expanded_url" : "http:\/\/www.slate.com\/blogs\/future_tense\/2015\/12\/04\/follow_the_paris_cop21_climate_talks_live_via_google_docs.html?wpsrc=sh_all_dt_tw_ru",
      "display_url" : "slate.com\/blogs\/future_t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "673490103889719297",
  "text" : "RT @arnicas: Great &amp; awful: the \u201Conly public record of the Climate Talks is this Google Doc\u201D turns out to be authored by students https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/gnbK2DA8oX",
        "expanded_url" : "http:\/\/www.slate.com\/blogs\/future_tense\/2015\/12\/04\/follow_the_paris_cop21_climate_talks_live_via_google_docs.html?wpsrc=sh_all_dt_tw_ru",
        "display_url" : "slate.com\/blogs\/future_t\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "673271760091938816",
    "text" : "Great &amp; awful: the \u201Conly public record of the Climate Talks is this Google Doc\u201D turns out to be authored by students https:\/\/t.co\/gnbK2DA8oX",
    "id" : 673271760091938816,
    "created_at" : "2015-12-05 22:44:31 +0000",
    "user" : {
      "name" : "Lynn Cherny",
      "screen_name" : "arnicas",
      "protected" : false,
      "id_str" : "6146692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53142956\/Saw-whet_Owl_10_normal.jpg",
      "id" : 6146692,
      "verified" : false
    }
  },
  "id" : 673490103889719297,
  "created_at" : "2015-12-06 13:12:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patricia Brenes",
      "screen_name" : "patriciambr",
      "indices" : [ 0, 12 ],
      "id_str" : "35764443",
      "id" : 35764443
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "673240589786357762",
  "geo" : { },
  "id_str" : "673486114561372161",
  "in_reply_to_user_id" : 35764443,
  "text" : "@patriciambr ah I see ok",
  "id" : 673486114561372161,
  "in_reply_to_status_id" : 673240589786357762,
  "created_at" : "2015-12-06 12:56:17 +0000",
  "in_reply_to_screen_name" : "patriciambr",
  "in_reply_to_user_id_str" : "35764443",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gosia Kwiatkowska",
      "screen_name" : "LessonPlansDig",
      "indices" : [ 3, 18 ],
      "id_str" : "3293928293",
      "id" : 3293928293
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/LessonPlansDig\/status\/673453491789008896\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/j0t7GnNDeU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CViWYbEWsAAF0kY.jpg",
      "id_str" : "673453490618937344",
      "id" : 673453490618937344,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CViWYbEWsAAF0kY.jpg",
      "sizes" : [ {
        "h" : 396,
        "resize" : "fit",
        "w" : 559
      }, {
        "h" : 396,
        "resize" : "fit",
        "w" : 559
      }, {
        "h" : 241,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 396,
        "resize" : "fit",
        "w" : 559
      } ],
      "display_url" : "pic.twitter.com\/j0t7GnNDeU"
    } ],
    "hashtags" : [ {
      "text" : "ESL",
      "indices" : [ 107, 111 ]
    }, {
      "text" : "ELT",
      "indices" : [ 112, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/7Y3aL6Nh9J",
      "expanded_url" : "http:\/\/bit.ly\/1jGouMi",
      "display_url" : "bit.ly\/1jGouMi"
    } ]
  },
  "geo" : { },
  "id_str" : "673456327751020544",
  "text" : "RT @LessonPlansDig: What to tell students who struggle with learning phrasal verbs?https:\/\/t.co\/7Y3aL6Nh9J #ESL #ELT https:\/\/t.co\/j0t7GnNDeU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/LessonPlansDig\/status\/673453491789008896\/photo\/1",
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/j0t7GnNDeU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CViWYbEWsAAF0kY.jpg",
        "id_str" : "673453490618937344",
        "id" : 673453490618937344,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CViWYbEWsAAF0kY.jpg",
        "sizes" : [ {
          "h" : 396,
          "resize" : "fit",
          "w" : 559
        }, {
          "h" : 396,
          "resize" : "fit",
          "w" : 559
        }, {
          "h" : 241,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 396,
          "resize" : "fit",
          "w" : 559
        } ],
        "display_url" : "pic.twitter.com\/j0t7GnNDeU"
      } ],
      "hashtags" : [ {
        "text" : "ESL",
        "indices" : [ 87, 91 ]
      }, {
        "text" : "ELT",
        "indices" : [ 92, 96 ]
      } ],
      "urls" : [ {
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/7Y3aL6Nh9J",
        "expanded_url" : "http:\/\/bit.ly\/1jGouMi",
        "display_url" : "bit.ly\/1jGouMi"
      } ]
    },
    "geo" : { },
    "id_str" : "673453491789008896",
    "text" : "What to tell students who struggle with learning phrasal verbs?https:\/\/t.co\/7Y3aL6Nh9J #ESL #ELT https:\/\/t.co\/j0t7GnNDeU",
    "id" : 673453491789008896,
    "created_at" : "2015-12-06 10:46:39 +0000",
    "user" : {
      "name" : "Gosia Kwiatkowska",
      "screen_name" : "LessonPlansDig",
      "protected" : false,
      "id_str" : "3293928293",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/658204893291806720\/O5Hw1gNN_normal.jpg",
      "id" : 3293928293,
      "verified" : false
    }
  },
  "id" : 673456327751020544,
  "created_at" : "2015-12-06 10:57:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "673455217879347200",
  "geo" : { },
  "id_str" : "673456194858692608",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish hmm maybe Google vets them first?",
  "id" : 673456194858692608,
  "in_reply_to_status_id" : 673455217879347200,
  "created_at" : "2015-12-06 10:57:23 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 99, 115 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/iH1CvaA5si",
      "expanded_url" : "http:\/\/wp.me\/p1U04a-9My",
      "display_url" : "wp.me\/p1U04a-9My"
    } ]
  },
  "geo" : { },
  "id_str" : "673455447874121728",
  "text" : "UK flood defences cut - while millions spent on bombing Syria and Iraq https:\/\/t.co\/iH1CvaA5si via @wordpressdotcom",
  "id" : 673455447874121728,
  "created_at" : "2015-12-06 10:54:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "673454616894431232",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish many thanks for the nice review of PHaVE Marc though not sure why it's not showing up on the site?",
  "id" : 673454616894431232,
  "created_at" : "2015-12-06 10:51:07 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 73, 88 ],
      "id_str" : "285614027",
      "id" : 285614027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/VGoip72Ri5",
      "expanded_url" : "http:\/\/www.anthonyteacher.com\/blog\/researchbites\/research-bites-why-is-reading-so-difficult",
      "display_url" : "anthonyteacher.com\/blog\/researchb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "673448997206495232",
  "text" : "Research Bites: Why is reading so difficult? https:\/\/t.co\/VGoip72Ri5 via @AnthonyTeacher",
  "id" : 673448997206495232,
  "created_at" : "2015-12-06 10:28:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoff Jordan",
      "screen_name" : "GeoffJordan",
      "indices" : [ 70, 82 ],
      "id_str" : "29510765",
      "id" : 29510765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/gyT2RDxK5X",
      "expanded_url" : "http:\/\/wp.me\/p3qkCB-1pR",
      "display_url" : "wp.me\/p3qkCB-1pR"
    } ]
  },
  "geo" : { },
  "id_str" : "673448521710833664",
  "text" : "Call that evidence? Russ Mayne on Chomsky https:\/\/t.co\/gyT2RDxK5X via @GeoffJordan",
  "id" : 673448521710833664,
  "created_at" : "2015-12-06 10:26:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "673421562935156736",
  "geo" : { },
  "id_str" : "673448162124763136",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl one thing worse than being talked about is being talked about by Geoff?",
  "id" : 673448162124763136,
  "in_reply_to_status_id" : 673421562935156736,
  "created_at" : "2015-12-06 10:25:28 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patricia Brenes",
      "screen_name" : "patriciambr",
      "indices" : [ 0, 12 ],
      "id_str" : "35764443",
      "id" : 35764443
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/gnEFqIeLpA",
      "expanded_url" : "https:\/\/plus.google.com\/u\/0\/communities\/101266284417587206243",
      "display_url" : "plus.google.com\/u\/0\/communitie\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "673192776079646720",
  "geo" : { },
  "id_str" : "673197243801931776",
  "in_reply_to_user_id" : 35764443,
  "text" : "@patriciambr great! perhaps u wld like to share it on the G+ CL communty? https:\/\/t.co\/gnEFqIeLpA",
  "id" : 673197243801931776,
  "in_reply_to_status_id" : 673192776079646720,
  "created_at" : "2015-12-05 17:48:24 +0000",
  "in_reply_to_screen_name" : "patriciambr",
  "in_reply_to_user_id_str" : "35764443",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 95, 111 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/AGzwYAVo9n",
      "expanded_url" : "http:\/\/wp.me\/p2P66-e2",
      "display_url" : "wp.me\/p2P66-e2"
    } ]
  },
  "geo" : { },
  "id_str" : "673162228439392256",
  "text" : "Hilary Benn\u2019s speech \u2013 The media\u2019s war footing on Corbyn and Syria https:\/\/t.co\/AGzwYAVo9n via @wordpressdotcom",
  "id" : 673162228439392256,
  "created_at" : "2015-12-05 15:29:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Local France",
      "screen_name" : "TheLocalFrance",
      "indices" : [ 72, 87 ],
      "id_str" : "333366997",
      "id" : 333366997
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/6kSPhVLjQB",
      "expanded_url" : "http:\/\/www.thelocal.fr\/20151203\/france-to-extend-state-of-emergency-to-six-months",
      "display_url" : "thelocal.fr\/20151203\/franc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "673075705534619648",
  "text" : "States of emergency may have no time limits https:\/\/t.co\/6kSPhVLjQB via @TheLocalFrance",
  "id" : 673075705534619648,
  "created_at" : "2015-12-05 09:45:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foreign Policy",
      "screen_name" : "ForeignPolicy",
      "indices" : [ 3, 17 ],
      "id_str" : "26792275",
      "id" : 26792275
    }, {
      "name" : "MSF International",
      "screen_name" : "MSF",
      "indices" : [ 90, 94 ],
      "id_str" : "2195671183",
      "id" : 2195671183
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/ForeignPolicy\/status\/672907517983367168\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/KzWNw4fEjU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVal0kyWsAAsogE.jpg",
      "id_str" : "672907516985126912",
      "id" : 672907516985126912,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVal0kyWsAAsogE.jpg",
      "sizes" : [ {
        "h" : 1000,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/KzWNw4fEjU"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/46hgk3Jqee",
      "expanded_url" : "http:\/\/atfp.co\/1SCV0LA",
      "display_url" : "atfp.co\/1SCV0LA"
    } ]
  },
  "geo" : { },
  "id_str" : "672910781315473408",
  "text" : "RT @ForeignPolicy: [GRAPHIC] A portrait of life -- and death -- in the U.S. attack on the @MSF Kunduz hospital. https:\/\/t.co\/46hgk3Jqee htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "MSF International",
        "screen_name" : "MSF",
        "indices" : [ 71, 75 ],
        "id_str" : "2195671183",
        "id" : 2195671183
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ForeignPolicy\/status\/672907517983367168\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/KzWNw4fEjU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CVal0kyWsAAsogE.jpg",
        "id_str" : "672907516985126912",
        "id" : 672907516985126912,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVal0kyWsAAsogE.jpg",
        "sizes" : [ {
          "h" : 1000,
          "resize" : "fit",
          "w" : 2000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/KzWNw4fEjU"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/46hgk3Jqee",
        "expanded_url" : "http:\/\/atfp.co\/1SCV0LA",
        "display_url" : "atfp.co\/1SCV0LA"
      } ]
    },
    "geo" : { },
    "id_str" : "672907517983367168",
    "text" : "[GRAPHIC] A portrait of life -- and death -- in the U.S. attack on the @MSF Kunduz hospital. https:\/\/t.co\/46hgk3Jqee https:\/\/t.co\/KzWNw4fEjU",
    "id" : 672907517983367168,
    "created_at" : "2015-12-04 22:37:08 +0000",
    "user" : {
      "name" : "Foreign Policy",
      "screen_name" : "ForeignPolicy",
      "protected" : false,
      "id_str" : "26792275",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/560557786350637057\/GXv25iue_normal.png",
      "id" : 26792275,
      "verified" : true
    }
  },
  "id" : 672910781315473408,
  "created_at" : "2015-12-04 22:50:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicola Prentis",
      "screen_name" : "NicolaPrentis",
      "indices" : [ 3, 17 ],
      "id_str" : "810667033",
      "id" : 810667033
    }, {
      "name" : "The Establishment",
      "screen_name" : "ESTBLSHMNT",
      "indices" : [ 129, 140 ],
      "id_str" : "3418972445",
      "id" : 3418972445
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/7i1A4v3y0a",
      "expanded_url" : "http:\/\/www.theestablishment.co\/2015\/12\/04\/motherhood-freed-me-from-the-male-gaze\/",
      "display_url" : "theestablishment.co\/2015\/12\/04\/mot\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "672910273733369856",
  "text" : "RT @NicolaPrentis: Motherhood Freed Me From The Male Gaze aka Fuck off with your \"compliments\" guys! https:\/\/t.co\/7i1A4v3y0a via @ESTBLSHMNT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Establishment",
        "screen_name" : "ESTBLSHMNT",
        "indices" : [ 110, 121 ],
        "id_str" : "3418972445",
        "id" : 3418972445
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/7i1A4v3y0a",
        "expanded_url" : "http:\/\/www.theestablishment.co\/2015\/12\/04\/motherhood-freed-me-from-the-male-gaze\/",
        "display_url" : "theestablishment.co\/2015\/12\/04\/mot\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "672850917885091840",
    "text" : "Motherhood Freed Me From The Male Gaze aka Fuck off with your \"compliments\" guys! https:\/\/t.co\/7i1A4v3y0a via @ESTBLSHMNT",
    "id" : 672850917885091840,
    "created_at" : "2015-12-04 18:52:14 +0000",
    "user" : {
      "name" : "Nicola Prentis",
      "screen_name" : "NicolaPrentis",
      "protected" : false,
      "id_str" : "810667033",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3046181441\/a51ef543c16ff30fdb8966f23237790d_normal.jpeg",
      "id" : 810667033,
      "verified" : false
    }
  },
  "id" : 672910273733369856,
  "created_at" : "2015-12-04 22:48:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/u2qWm4rdj8",
      "expanded_url" : "http:\/\/eveningharold.com\/2015\/12\/04\/jeremy-corbyn-now-abandoned-by-everyone-apart-from-voters\/",
      "display_url" : "eveningharold.com\/2015\/12\/04\/jer\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "672907310524719106",
  "text" : "Jeremy Corbyn now abandoned by everyone apart from 'voters' https:\/\/t.co\/u2qWm4rdj8",
  "id" : 672907310524719106,
  "created_at" : "2015-12-04 22:36:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "indices" : [ 3, 18 ],
      "id_str" : "152194866",
      "id" : 152194866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/riMVDxWlgO",
      "expanded_url" : "http:\/\/tm.durusau.net\/?p=66021From",
      "display_url" : "tm.durusau.net\/?p=66021From"
    } ]
  },
  "geo" : { },
  "id_str" : "672905676608376832",
  "text" : "RT @patrickDurusau: https:\/\/t.co\/riMVDxWlgO God to Google",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/riMVDxWlgO",
        "expanded_url" : "http:\/\/tm.durusau.net\/?p=66021From",
        "display_url" : "tm.durusau.net\/?p=66021From"
      } ]
    },
    "geo" : { },
    "id_str" : "672842846433615872",
    "text" : "https:\/\/t.co\/riMVDxWlgO God to Google",
    "id" : 672842846433615872,
    "created_at" : "2015-12-04 18:20:10 +0000",
    "user" : {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "protected" : false,
      "id_str" : "152194866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/961579480\/patrick_normal.jpeg",
      "id" : 152194866,
      "verified" : false
    }
  },
  "id" : 672905676608376832,
  "created_at" : "2015-12-04 22:29:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Lavigne",
      "screen_name" : "sam_lavigne",
      "indices" : [ 60, 72 ],
      "id_str" : "6428702",
      "id" : 6428702
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/672903220918886400\/photo\/1",
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/NBgsN5Cwfa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVah6dNWIAEnouJ.png",
      "id_str" : "672903219983556609",
      "id" : 672903219983556609,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVah6dNWIAEnouJ.png",
      "sizes" : [ {
        "h" : 67,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 177,
        "resize" : "fit",
        "w" : 902
      }, {
        "h" : 118,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 177,
        "resize" : "fit",
        "w" : 902
      } ],
      "display_url" : "pic.twitter.com\/NBgsN5Cwfa"
    } ],
    "hashtags" : [ {
      "text" : "SyriaVote",
      "indices" : [ 22, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/2PUo8sJiZH",
      "expanded_url" : "http:\/\/antiboredom.github.io\/zuckify\/",
      "display_url" : "antiboredom.github.io\/zuckify\/"
    } ]
  },
  "geo" : { },
  "id_str" : "672903220918886400",
  "text" : "international brigade #SyriaVote https:\/\/t.co\/2PUo8sJiZH by @sam_lavigne https:\/\/t.co\/NBgsN5Cwfa",
  "id" : 672903220918886400,
  "created_at" : "2015-12-04 22:20:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer MacDonald",
      "screen_name" : "JenMac_ESL",
      "indices" : [ 0, 11 ],
      "id_str" : "608800026",
      "id" : 608800026
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/woDiYd0OYM",
      "expanded_url" : "https:\/\/play.google.com\/store\/apps\/details?id=me.englishup.phave_dictionary",
      "display_url" : "play.google.com\/store\/apps\/det\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "672901238195953666",
  "in_reply_to_user_id" : 608800026,
  "text" : "@JenMac_ESL many thanks for sharing PHaVE Dictionary :) https:\/\/t.co\/woDiYd0OYM",
  "id" : 672901238195953666,
  "created_at" : "2015-12-04 22:12:11 +0000",
  "in_reply_to_screen_name" : "JenMac_ESL",
  "in_reply_to_user_id_str" : "608800026",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 0, 11 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/672900686342959105\/photo\/1",
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/iNj9gAJVOX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVafm7DWoAAw8Ug.png",
      "id_str" : "672900685374070784",
      "id" : 672900685374070784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVafm7DWoAAw8Ug.png",
      "sizes" : [ {
        "h" : 195,
        "resize" : "fit",
        "w" : 873
      }, {
        "h" : 76,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 134,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 195,
        "resize" : "fit",
        "w" : 873
      } ],
      "display_url" : "pic.twitter.com\/iNj9gAJVOX"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/2PUo8sJiZH",
      "expanded_url" : "http:\/\/antiboredom.github.io\/zuckify\/",
      "display_url" : "antiboredom.github.io\/zuckify\/"
    } ]
  },
  "in_reply_to_status_id_str" : "672697592707489792",
  "geo" : { },
  "id_str" : "672900686342959105",
  "in_reply_to_user_id" : 88202140,
  "text" : "@hughdellar :) https:\/\/t.co\/2PUo8sJiZH https:\/\/t.co\/iNj9gAJVOX",
  "id" : 672900686342959105,
  "in_reply_to_status_id" : 672697592707489792,
  "created_at" : "2015-12-04 22:10:00 +0000",
  "in_reply_to_screen_name" : "hughdellar",
  "in_reply_to_user_id_str" : "88202140",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/9LUuCfTNjq",
      "expanded_url" : "http:\/\/gu.com\/p\/4ez5y\/stw",
      "display_url" : "gu.com\/p\/4ez5y\/stw"
    } ]
  },
  "geo" : { },
  "id_str" : "672839958420434944",
  "text" : "Isis wants an insane race war \u2013 and we\u2019ve decided to give them one | Frankie Boyle https:\/\/t.co\/9LUuCfTNjq",
  "id" : 672839958420434944,
  "created_at" : "2015-12-04 18:08:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/vW3dmVkhTM",
      "expanded_url" : "http:\/\/hpmor.com\/",
      "display_url" : "hpmor.com"
    } ]
  },
  "geo" : { },
  "id_str" : "672804584243503104",
  "text" : "Harry Potter and the Methods of Rationality https:\/\/t.co\/vW3dmVkhTM",
  "id" : 672804584243503104,
  "created_at" : "2015-12-04 15:48:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/QD5lOtXcWC",
      "expanded_url" : "http:\/\/flyingrodent.blogspot.com\/2015\/12\/that-catch-all-war-vote-speech.html?spref=tw",
      "display_url" : "flyingrodent.blogspot.com\/2015\/12\/that-c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "672771723830366208",
  "text" : "Between the Hammer and the Anvil: That Catch-All War Vote Speech https:\/\/t.co\/QD5lOtXcWC",
  "id" : 672771723830366208,
  "created_at" : "2015-12-04 13:37:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/6iHAvtG5G7",
      "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2015\/12\/good-little-taxpayers-shouldnt-ask.html",
      "display_url" : "thecurmudgeonly.blogspot.co.uk\/2015\/12\/good-l\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "672767824062889984",
  "text" : "RT @pchallinor: New mudgeonry: Good little taxpayers shouldn't ask questions https:\/\/t.co\/6iHAvtG5G7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/6iHAvtG5G7",
        "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2015\/12\/good-little-taxpayers-shouldnt-ask.html",
        "display_url" : "thecurmudgeonly.blogspot.co.uk\/2015\/12\/good-l\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "672767147194621953",
    "text" : "New mudgeonry: Good little taxpayers shouldn't ask questions https:\/\/t.co\/6iHAvtG5G7",
    "id" : 672767147194621953,
    "created_at" : "2015-12-04 13:19:21 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 672767824062889984,
  "created_at" : "2015-12-04 13:22:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/l8XSk6SIjE",
      "expanded_url" : "http:\/\/www.washingtonsblog.com\/2015\/12\/mass-killings-bother.html",
      "display_url" : "washingtonsblog.com\/2015\/12\/mass-k\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "672764883872673792",
  "text" : "Do Mass Killings Bother You? https:\/\/t.co\/l8XSk6SIjE",
  "id" : 672764883872673792,
  "created_at" : "2015-12-04 13:10:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "indices" : [ 3, 18 ],
      "id_str" : "27716419",
      "id" : 27716419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/6VT55XeLG1",
      "expanded_url" : "http:\/\/www.craigmurray.org.uk\/archives\/2015\/12\/massive-collapse-in-tory-vote-share-in-oldham\/",
      "display_url" : "craigmurray.org.uk\/archives\/2015\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "672762279667048450",
  "text" : "RT @CraigMurrayOrg: New post: Massive Collapse in Tory Vote Share in Oldham https:\/\/t.co\/6VT55XeLG1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.craigmurray.org.uk\" rel=\"nofollow\"\u003ECraig Murray posting plugin\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/6VT55XeLG1",
        "expanded_url" : "http:\/\/www.craigmurray.org.uk\/archives\/2015\/12\/massive-collapse-in-tory-vote-share-in-oldham\/",
        "display_url" : "craigmurray.org.uk\/archives\/2015\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "672589998500225026",
    "text" : "New post: Massive Collapse in Tory Vote Share in Oldham https:\/\/t.co\/6VT55XeLG1",
    "id" : 672589998500225026,
    "created_at" : "2015-12-04 01:35:26 +0000",
    "user" : {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "protected" : false,
      "id_str" : "27716419",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1388436826\/cm_normal.jpg",
      "id" : 27716419,
      "verified" : false
    }
  },
  "id" : 672762279667048450,
  "created_at" : "2015-12-04 13:00:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eily Murphy",
      "screen_name" : "eilymurphy",
      "indices" : [ 11, 22 ],
      "id_str" : "111091623",
      "id" : 111091623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/woDiYd0OYM",
      "expanded_url" : "https:\/\/play.google.com\/store\/apps\/details?id=me.englishup.phave_dictionary",
      "display_url" : "play.google.com\/store\/apps\/det\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "672757312889712641",
  "in_reply_to_user_id" : 44631065,
  "text" : "@HadaLitim @eilymurphy hey many thx for spreading the word of PHaVE https:\/\/t.co\/woDiYd0OYM :)",
  "id" : 672757312889712641,
  "created_at" : "2015-12-04 12:40:17 +0000",
  "in_reply_to_screen_name" : "Hada_ELT",
  "in_reply_to_user_id_str" : "44631065",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Asya Pereltsvaig",
      "screen_name" : "LangsOfTheWorld",
      "indices" : [ 3, 19 ],
      "id_str" : "438063254",
      "id" : 438063254
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/uMa3Mivv5b",
      "expanded_url" : "http:\/\/bit.ly\/1PBKuXc",
      "display_url" : "bit.ly\/1PBKuXc"
    } ]
  },
  "geo" : { },
  "id_str" : "672639826252996608",
  "text" : "RT @LangsOfTheWorld: Why Are There Different Languages?\u2014Response to Vyvyan Evans (Part 4, Conclusion): [Many thanks to Martin W. Le... http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/uMa3Mivv5b",
        "expanded_url" : "http:\/\/bit.ly\/1PBKuXc",
        "display_url" : "bit.ly\/1PBKuXc"
      } ]
    },
    "geo" : { },
    "id_str" : "672555888754819072",
    "text" : "Why Are There Different Languages?\u2014Response to Vyvyan Evans (Part 4, Conclusion): [Many thanks to Martin W. Le... https:\/\/t.co\/uMa3Mivv5b",
    "id" : 672555888754819072,
    "created_at" : "2015-12-03 23:19:54 +0000",
    "user" : {
      "name" : "Asya Pereltsvaig",
      "screen_name" : "LangsOfTheWorld",
      "protected" : false,
      "id_str" : "438063254",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1696093867\/Languages_Of_The_World_Button-Blue-Forward_normal.jpg",
      "id" : 438063254,
      "verified" : false
    }
  },
  "id" : 672639826252996608,
  "created_at" : "2015-12-04 04:53:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bbcqt",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 140 ],
      "url" : "https:\/\/t.co\/ob8M0smz3j",
      "expanded_url" : "http:\/\/johnhilley.blogspot.co.uk\/2015\/12\/once-more-to-insane-corporate-loving.html",
      "display_url" : "johnhilley.blogspot.co.uk\/2015\/12\/once-m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "672558199036387329",
  "text" : "RT @johnwhilley: Relentless bombing as Western ideology. Why does media never talk of Britain as a war-addicted state? https:\/\/t.co\/ob8M0sm\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bbcqt",
        "indices" : [ 126, 132 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/ob8M0smz3j",
        "expanded_url" : "http:\/\/johnhilley.blogspot.co.uk\/2015\/12\/once-more-to-insane-corporate-loving.html",
        "display_url" : "johnhilley.blogspot.co.uk\/2015\/12\/once-m\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "672557618221727744",
    "text" : "Relentless bombing as Western ideology. Why does media never talk of Britain as a war-addicted state? https:\/\/t.co\/ob8M0smz3j #bbcqt",
    "id" : 672557618221727744,
    "created_at" : "2015-12-03 23:26:46 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 672558199036387329,
  "created_at" : "2015-12-03 23:29:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Red Pepper magazine",
      "screen_name" : "RedPeppermag",
      "indices" : [ 3, 16 ],
      "id_str" : "20451618",
      "id" : 20451618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "https:\/\/t.co\/R0Hk8hhouW",
      "expanded_url" : "http:\/\/www.redpepper.org.uk\/we-marched-for-peace-not-to-bully-stella-creasy\/",
      "display_url" : "redpepper.org.uk\/we-marched-for\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "672529219101065217",
  "text" : "RT @RedPeppermag: Eye witness account: the truth behind reports of 'intimidating' anti-war protest and MP Stella Creasy https:\/\/t.co\/R0Hk8h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/R0Hk8hhouW",
        "expanded_url" : "http:\/\/www.redpepper.org.uk\/we-marched-for-peace-not-to-bully-stella-creasy\/",
        "display_url" : "redpepper.org.uk\/we-marched-for\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "672518561911455744",
    "text" : "Eye witness account: the truth behind reports of 'intimidating' anti-war protest and MP Stella Creasy https:\/\/t.co\/R0Hk8hhouW",
    "id" : 672518561911455744,
    "created_at" : "2015-12-03 20:51:34 +0000",
    "user" : {
      "name" : "Red Pepper magazine",
      "screen_name" : "RedPeppermag",
      "protected" : false,
      "id_str" : "20451618",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2363310402\/5k7q22q7dwkdmlw4zcg6_normal.png",
      "id" : 20451618,
      "verified" : false
    }
  },
  "id" : 672529219101065217,
  "created_at" : "2015-12-03 21:33:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Robinson",
      "screen_name" : "nmkrobinson",
      "indices" : [ 3, 15 ],
      "id_str" : "20425399",
      "id" : 20425399
    }, {
      "name" : "ESA",
      "screen_name" : "TOEFLnews",
      "indices" : [ 26, 36 ],
      "id_str" : "3554778013",
      "id" : 3554778013
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edtech",
      "indices" : [ 105, 112 ]
    }, {
      "text" : "elt",
      "indices" : [ 113, 117 ]
    }, {
      "text" : "esl",
      "indices" : [ 118, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/P2Y9gNiyCT",
      "expanded_url" : "http:\/\/englishsuccessacademy.com\/open-letter-to-toefl-speaking-teacher\/",
      "display_url" : "englishsuccessacademy.com\/open-letter-to\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "672527296486637568",
  "text" : "RT @nmkrobinson: Love how @TOEFLnews is handing the theft of her online content: https:\/\/t.co\/P2Y9gNiyCT #edtech #elt #esl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ESA",
        "screen_name" : "TOEFLnews",
        "indices" : [ 9, 19 ],
        "id_str" : "3554778013",
        "id" : 3554778013
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "edtech",
        "indices" : [ 88, 95 ]
      }, {
        "text" : "elt",
        "indices" : [ 96, 100 ]
      }, {
        "text" : "esl",
        "indices" : [ 101, 105 ]
      } ],
      "urls" : [ {
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/P2Y9gNiyCT",
        "expanded_url" : "http:\/\/englishsuccessacademy.com\/open-letter-to-toefl-speaking-teacher\/",
        "display_url" : "englishsuccessacademy.com\/open-letter-to\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "671690315892396032",
    "text" : "Love how @TOEFLnews is handing the theft of her online content: https:\/\/t.co\/P2Y9gNiyCT #edtech #elt #esl",
    "id" : 671690315892396032,
    "created_at" : "2015-12-01 14:00:25 +0000",
    "user" : {
      "name" : "Nick Robinson",
      "screen_name" : "nmkrobinson",
      "protected" : false,
      "id_str" : "20425399",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/706797940669599744\/6lTpszWm_normal.jpg",
      "id" : 20425399,
      "verified" : false
    }
  },
  "id" : 672527296486637568,
  "created_at" : "2015-12-03 21:26:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenys Hanson",
      "screen_name" : "GlenysHanson",
      "indices" : [ 0, 13 ],
      "id_str" : "527238447",
      "id" : 527238447
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "672523073598455808",
  "geo" : { },
  "id_str" : "672523516936343553",
  "in_reply_to_user_id" : 527238447,
  "text" : "@GlenysHanson they seem to work as is",
  "id" : 672523516936343553,
  "in_reply_to_status_id" : 672523073598455808,
  "created_at" : "2015-12-03 21:11:15 +0000",
  "in_reply_to_screen_name" : "GlenysHanson",
  "in_reply_to_user_id_str" : "527238447",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Emersberger",
      "screen_name" : "rosendo_joe",
      "indices" : [ 0, 12 ],
      "id_str" : "3351345863",
      "id" : 3351345863
    }, {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 13, 23 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/9FfRmtorZh",
      "expanded_url" : "https:\/\/historicalchaos.wordpress.com\/2015\/12\/03\/hilary-benns-good-samaritan\/",
      "display_url" : "historicalchaos.wordpress.com\/2015\/12\/03\/hil\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "672521665029513216",
  "geo" : { },
  "id_str" : "672522633620168705",
  "in_reply_to_user_id" : 3351345863,
  "text" : "@rosendo_joe @medialens nice analysis of some of the rhetoric here https:\/\/t.co\/9FfRmtorZh",
  "id" : 672522633620168705,
  "in_reply_to_status_id" : 672521665029513216,
  "created_at" : "2015-12-03 21:07:45 +0000",
  "in_reply_to_screen_name" : "rosendo_joe",
  "in_reply_to_user_id_str" : "3351345863",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenys Hanson",
      "screen_name" : "GlenysHanson",
      "indices" : [ 0, 13 ],
      "id_str" : "527238447",
      "id" : 527238447
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "672515410751811585",
  "geo" : { },
  "id_str" : "672518239616966656",
  "in_reply_to_user_id" : 527238447,
  "text" : "@GlenysHanson the images\/diagrams in the phrasal verb exercises",
  "id" : 672518239616966656,
  "in_reply_to_status_id" : 672515410751811585,
  "created_at" : "2015-12-03 20:50:17 +0000",
  "in_reply_to_screen_name" : "GlenysHanson",
  "in_reply_to_user_id_str" : "527238447",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Seymour",
      "screen_name" : "leninology",
      "indices" : [ 3, 14 ],
      "id_str" : "15557246",
      "id" : 15557246
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/lJZL6fj2nj",
      "expanded_url" : "http:\/\/www.leninology.co.uk\/2015\/12\/why-does-cameron-want-to-bomb-syria.html",
      "display_url" : "leninology.co.uk\/2015\/12\/why-do\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "672514668523593728",
  "text" : "RT @leninology: Why does Cameron want to bomb Syria? https:\/\/t.co\/lJZL6fj2nj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 60 ],
        "url" : "https:\/\/t.co\/lJZL6fj2nj",
        "expanded_url" : "http:\/\/www.leninology.co.uk\/2015\/12\/why-does-cameron-want-to-bomb-syria.html",
        "display_url" : "leninology.co.uk\/2015\/12\/why-do\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "672190196495065088",
    "text" : "Why does Cameron want to bomb Syria? https:\/\/t.co\/lJZL6fj2nj",
    "id" : 672190196495065088,
    "created_at" : "2015-12-02 23:06:46 +0000",
    "user" : {
      "name" : "Richard Seymour",
      "screen_name" : "leninology",
      "protected" : false,
      "id_str" : "15557246",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762344914583781377\/UDn8tMrp_normal.jpg",
      "id" : 15557246,
      "verified" : false
    }
  },
  "id" : 672514668523593728,
  "created_at" : "2015-12-03 20:36:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenys Hanson",
      "screen_name" : "GlenysHanson",
      "indices" : [ 0, 13 ],
      "id_str" : "527238447",
      "id" : 527238447
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "672501567967338498",
  "geo" : { },
  "id_str" : "672513016777326595",
  "in_reply_to_user_id" : 527238447,
  "text" : "@GlenysHanson the imagery exercises worked well with this student",
  "id" : 672513016777326595,
  "in_reply_to_status_id" : 672501567967338498,
  "created_at" : "2015-12-03 20:29:32 +0000",
  "in_reply_to_screen_name" : "GlenysHanson",
  "in_reply_to_user_id_str" : "527238447",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenys Hanson",
      "screen_name" : "GlenysHanson",
      "indices" : [ 3, 16 ],
      "id_str" : "527238447",
      "id" : 527238447
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/K1hngZQ3Js",
      "expanded_url" : "http:\/\/www.esl-exos.info\/",
      "display_url" : "esl-exos.info"
    }, {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/zctQSlMsNn",
      "expanded_url" : "https:\/\/twitter.com\/muranava\/status\/672359551165952000",
      "display_url" : "twitter.com\/muranava\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "672512839475662849",
  "text" : "RT @GlenysHanson: If others are interested, they're here: https:\/\/t.co\/K1hngZQ3Js https:\/\/t.co\/zctQSlMsNn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 63 ],
        "url" : "https:\/\/t.co\/K1hngZQ3Js",
        "expanded_url" : "http:\/\/www.esl-exos.info\/",
        "display_url" : "esl-exos.info"
      }, {
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/zctQSlMsNn",
        "expanded_url" : "https:\/\/twitter.com\/muranava\/status\/672359551165952000",
        "display_url" : "twitter.com\/muranava\/statu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "672501900206604288",
    "text" : "If others are interested, they're here: https:\/\/t.co\/K1hngZQ3Js https:\/\/t.co\/zctQSlMsNn",
    "id" : 672501900206604288,
    "created_at" : "2015-12-03 19:45:22 +0000",
    "user" : {
      "name" : "Glenys Hanson",
      "screen_name" : "GlenysHanson",
      "protected" : false,
      "id_str" : "527238447",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/488943744226299904\/6SULCTUl_normal.png",
      "id" : 527238447,
      "verified" : false
    }
  },
  "id" : 672512839475662849,
  "created_at" : "2015-12-03 20:28:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "672490541658062848",
  "geo" : { },
  "id_str" : "672493000472305665",
  "in_reply_to_user_id" : 44631065,
  "text" : "@HadaLitim great thx, yes good point something to work on",
  "id" : 672493000472305665,
  "in_reply_to_status_id" : 672490541658062848,
  "created_at" : "2015-12-03 19:10:00 +0000",
  "in_reply_to_screen_name" : "Hada_ELT",
  "in_reply_to_user_id_str" : "44631065",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/HuAv3nPEan",
      "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2015\/12\/the-grown-ups.html",
      "display_url" : "thecurmudgeonly.blogspot.co.uk\/2015\/12\/the-gr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "672488108659744768",
  "text" : "RT @pchallinor: New mudgeonry: The grown-ups https:\/\/t.co\/HuAv3nPEan",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 29, 52 ],
        "url" : "https:\/\/t.co\/HuAv3nPEan",
        "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2015\/12\/the-grown-ups.html",
        "display_url" : "thecurmudgeonly.blogspot.co.uk\/2015\/12\/the-gr\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "672484099303546880",
    "text" : "New mudgeonry: The grown-ups https:\/\/t.co\/HuAv3nPEan",
    "id" : 672484099303546880,
    "created_at" : "2015-12-03 18:34:38 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 672488108659744768,
  "created_at" : "2015-12-03 18:50:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 57, 73 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/lDNCPPTtFE",
      "expanded_url" : "http:\/\/wp.me\/p4V5DN-6x",
      "display_url" : "wp.me\/p4V5DN-6x"
    } ]
  },
  "geo" : { },
  "id_str" : "672394858573766656",
  "text" : "Hilary Benn's Good Samaritan https:\/\/t.co\/lDNCPPTtFE via @wordpressdotcom",
  "id" : 672394858573766656,
  "created_at" : "2015-12-03 12:40:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenys Hanson",
      "screen_name" : "GlenysHanson",
      "indices" : [ 0, 13 ],
      "id_str" : "527238447",
      "id" : 527238447
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "672359551165952000",
  "in_reply_to_user_id" : 527238447,
  "text" : "@GlenysHanson hi a weakish intermediate student enjoyed your phrasal verb exercises today, many thx :)",
  "id" : 672359551165952000,
  "created_at" : "2015-12-03 10:19:43 +0000",
  "in_reply_to_screen_name" : "GlenysHanson",
  "in_reply_to_user_id_str" : "527238447",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HilaryBenn",
      "indices" : [ 17, 28 ]
    }, {
      "text" : "Syria",
      "indices" : [ 49, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "672357335340290048",
  "text" : "RT @johnwhilley: #HilaryBenn equating bombing of #Syria with past fighting of fascism will go down in history as one the greatest ever poli\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HilaryBenn",
        "indices" : [ 0, 11 ]
      }, {
        "text" : "Syria",
        "indices" : [ 32, 38 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "672209792518221824",
    "text" : "#HilaryBenn equating bombing of #Syria with past fighting of fascism will go down in history as one the greatest ever political distortions.",
    "id" : 672209792518221824,
    "created_at" : "2015-12-03 00:24:38 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 672357335340290048,
  "created_at" : "2015-12-03 10:10:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "672308407597072384",
  "geo" : { },
  "id_str" : "672354785325096960",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish good to hear :)",
  "id" : 672354785325096960,
  "in_reply_to_status_id" : 672308407597072384,
  "created_at" : "2015-12-03 10:00:47 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "goieltsdotnet",
      "screen_name" : "goieltsdotnet",
      "indices" : [ 0, 14 ],
      "id_str" : "3052238274",
      "id" : 3052238274
    }, {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "indices" : [ 15, 27 ],
      "id_str" : "192437743",
      "id" : 192437743
    }, {
      "name" : "Natallia Novikava",
      "screen_name" : "Natashetta",
      "indices" : [ 28, 39 ],
      "id_str" : "56308635",
      "id" : 56308635
    }, {
      "name" : "Mike S. Boyle",
      "screen_name" : "heyboyle",
      "indices" : [ 40, 49 ],
      "id_str" : "612840231",
      "id" : 612840231
    }, {
      "name" : "Kamila Linkov\u00E1",
      "screen_name" : "kamilaofprague",
      "indices" : [ 50, 65 ],
      "id_str" : "3439998148",
      "id" : 3439998148
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "672299021134929925",
  "geo" : { },
  "id_str" : "672354734691459072",
  "in_reply_to_user_id" : 3052238274,
  "text" : "@goieltsdotnet @nathanghall @Natashetta @heyboyle @kamilaofprague many thanks for RTs &amp; likes any feedback welcome :)",
  "id" : 672354734691459072,
  "in_reply_to_status_id" : 672299021134929925,
  "created_at" : "2015-12-03 10:00:35 +0000",
  "in_reply_to_screen_name" : "goieltsdotnet",
  "in_reply_to_user_id_str" : "3052238274",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELTchat",
      "indices" : [ 130, 138 ]
    }, {
      "text" : "ESL",
      "indices" : [ 139, 143 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/woDiYd0OYM",
      "expanded_url" : "https:\/\/play.google.com\/store\/apps\/details?id=me.englishup.phave_dictionary",
      "display_url" : "play.google.com\/store\/apps\/det\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "672298338297978881",
  "text" : "have an Android &amp; looking for phrasal verbs in your pocket? do consider PHaVE Phrasal Verb Dictionary https:\/\/t.co\/woDiYd0OYM #ELTchat #ESL",
  "id" : 672298338297978881,
  "created_at" : "2015-12-03 06:16:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Hands Up Project",
      "screen_name" : "nickbilbrough",
      "indices" : [ 3, 17 ],
      "id_str" : "273391079",
      "id" : 273391079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/O42mNab771",
      "expanded_url" : "https:\/\/www.facebook.com\/Hands-up-4-Gaza-917350095017969\/?fref=ts",
      "display_url" : "facebook.com\/Hands-up-4-Gaz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "672204929990283265",
  "text" : "RT @nickbilbrough: My new Hands up 4 Gaza facebook page! https:\/\/t.co\/O42mNab771",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 61 ],
        "url" : "https:\/\/t.co\/O42mNab771",
        "expanded_url" : "https:\/\/www.facebook.com\/Hands-up-4-Gaza-917350095017969\/?fref=ts",
        "display_url" : "facebook.com\/Hands-up-4-Gaz\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "672196766079590400",
    "text" : "My new Hands up 4 Gaza facebook page! https:\/\/t.co\/O42mNab771",
    "id" : 672196766079590400,
    "created_at" : "2015-12-02 23:32:52 +0000",
    "user" : {
      "name" : "The Hands Up Project",
      "screen_name" : "nickbilbrough",
      "protected" : false,
      "id_str" : "273391079",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705302580944117760\/4q5JmOoa_normal.jpg",
      "id" : 273391079,
      "verified" : false
    }
  },
  "id" : 672204929990283265,
  "created_at" : "2015-12-03 00:05:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mhairi Black MP",
      "screen_name" : "MhairiBlack",
      "indices" : [ 3, 15 ],
      "id_str" : "120236641",
      "id" : 120236641
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SyriaVote",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "672204256259215361",
  "text" : "RT @MhairiBlack: Very dark night in parliament.Will never forget the noise of some Labour and Tory cheering together at the idea of bombs f\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SyriaVote",
        "indices" : [ 129, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "672189825571758080",
    "text" : "Very dark night in parliament.Will never forget the noise of some Labour and Tory cheering together at the idea of bombs falling #SyriaVote",
    "id" : 672189825571758080,
    "created_at" : "2015-12-02 23:05:17 +0000",
    "user" : {
      "name" : "Mhairi Black MP",
      "screen_name" : "MhairiBlack",
      "protected" : false,
      "id_str" : "120236641",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/717419655141396480\/M3t91jp6_normal.jpg",
      "id" : 120236641,
      "verified" : true
    }
  },
  "id" : 672204256259215361,
  "created_at" : "2015-12-03 00:02:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Michael Riccioli",
      "screen_name" : "curvedway",
      "indices" : [ 3, 13 ],
      "id_str" : "124707247",
      "id" : 124707247
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 15, 24 ],
      "id_str" : "18602422",
      "id" : 18602422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/cmoMiAVBha",
      "expanded_url" : "https:\/\/www.facebook.com\/cloakedtruth\/videos\/501139246726445\/?pnref=story",
      "display_url" : "facebook.com\/cloakedtruth\/v\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "672186374250999809",
  "text" : "RT @curvedway: @muranava \nTony Benn talking in Parliament about supplying the middle east with weapons.\nhttps:\/\/t.co\/cmoMiAVBha",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mura Nava",
        "screen_name" : "muranava",
        "indices" : [ 0, 9 ],
        "id_str" : "18602422",
        "id" : 18602422
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/cmoMiAVBha",
        "expanded_url" : "https:\/\/www.facebook.com\/cloakedtruth\/videos\/501139246726445\/?pnref=story",
        "display_url" : "facebook.com\/cloakedtruth\/v\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "672182958535614464",
    "geo" : { },
    "id_str" : "672184590803607552",
    "in_reply_to_user_id" : 18602422,
    "text" : "@muranava \nTony Benn talking in Parliament about supplying the middle east with weapons.\nhttps:\/\/t.co\/cmoMiAVBha",
    "id" : 672184590803607552,
    "in_reply_to_status_id" : 672182958535614464,
    "created_at" : "2015-12-02 22:44:29 +0000",
    "in_reply_to_screen_name" : "muranava",
    "in_reply_to_user_id_str" : "18602422",
    "user" : {
      "name" : "Dr. Michael Riccioli",
      "screen_name" : "curvedway",
      "protected" : false,
      "id_str" : "124707247",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/439859868434837505\/-h531G_i_normal.jpeg",
      "id" : 124707247,
      "verified" : false
    }
  },
  "id" : 672186374250999809,
  "created_at" : "2015-12-02 22:51:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Michael Riccioli",
      "screen_name" : "curvedway",
      "indices" : [ 0, 10 ],
      "id_str" : "124707247",
      "id" : 124707247
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "672185975200722944",
  "geo" : { },
  "id_str" : "672186286095114246",
  "in_reply_to_user_id" : 124707247,
  "text" : "@curvedway :\/",
  "id" : 672186286095114246,
  "in_reply_to_status_id" : 672185975200722944,
  "created_at" : "2015-12-02 22:51:13 +0000",
  "in_reply_to_screen_name" : "curvedway",
  "in_reply_to_user_id_str" : "124707247",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Michael Riccioli",
      "screen_name" : "curvedway",
      "indices" : [ 0, 10 ],
      "id_str" : "124707247",
      "id" : 124707247
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "672184590803607552",
  "geo" : { },
  "id_str" : "672185141217918976",
  "in_reply_to_user_id" : 124707247,
  "text" : "@curvedway thanks great vid that such a shame his kid does not take more notice",
  "id" : 672185141217918976,
  "in_reply_to_status_id" : 672184590803607552,
  "created_at" : "2015-12-02 22:46:40 +0000",
  "in_reply_to_screen_name" : "curvedway",
  "in_reply_to_user_id_str" : "124707247",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Graham",
      "screen_name" : "onalifeglug",
      "indices" : [ 3, 15 ],
      "id_str" : "19516039",
      "id" : 19516039
    }, {
      "name" : "stellacreasy",
      "screen_name" : "stellacreasy",
      "indices" : [ 21, 34 ],
      "id_str" : "15580900",
      "id" : 15580900
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "672183705201455104",
  "text" : "RT @onalifeglug: LOL @stellacreasy, so prior to Benn's sophistry you didn't already think fascism needed to be defeated?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "stellacreasy",
        "screen_name" : "stellacreasy",
        "indices" : [ 4, 17 ],
        "id_str" : "15580900",
        "id" : 15580900
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "672177814284693504",
    "geo" : { },
    "id_str" : "672183585131077633",
    "in_reply_to_user_id" : 15580900,
    "text" : "LOL @stellacreasy, so prior to Benn's sophistry you didn't already think fascism needed to be defeated?",
    "id" : 672183585131077633,
    "in_reply_to_status_id" : 672177814284693504,
    "created_at" : "2015-12-02 22:40:29 +0000",
    "in_reply_to_screen_name" : "stellacreasy",
    "in_reply_to_user_id_str" : "15580900",
    "user" : {
      "name" : "Graham",
      "screen_name" : "onalifeglug",
      "protected" : false,
      "id_str" : "19516039",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/586664577095622656\/NwBHdlk5_normal.jpg",
      "id" : 19516039,
      "verified" : false
    }
  },
  "id" : 672183705201455104,
  "created_at" : "2015-12-02 22:40:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "blairitebombers",
      "indices" : [ 84, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "672182958535614464",
  "text" : "ams sure just heard Tony Benn in the distant sighing the sigh of a disappointed dad #blairitebombers",
  "id" : 672182958535614464,
  "created_at" : "2015-12-02 22:38:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donald Clark",
      "screen_name" : "DonaldClark",
      "indices" : [ 0, 12 ],
      "id_str" : "1632891",
      "id" : 1632891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/e9rRiViKqh",
      "expanded_url" : "http:\/\/antiboredom.github.io\/a-letter-to-our-zuckerberg\/",
      "display_url" : "antiboredom.github.io\/a-letter-to-ou\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "672172509849088000",
  "geo" : { },
  "id_str" : "672173298315300864",
  "in_reply_to_user_id" : 1632891,
  "text" : "@DonaldClark astonishing is one word here are some more : ) https:\/\/t.co\/e9rRiViKqh",
  "id" : 672173298315300864,
  "in_reply_to_status_id" : 672172509849088000,
  "created_at" : "2015-12-02 21:59:37 +0000",
  "in_reply_to_screen_name" : "DonaldClark",
  "in_reply_to_user_id_str" : "1632891",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Lavigne",
      "screen_name" : "sam_lavigne",
      "indices" : [ 3, 15 ],
      "id_str" : "6428702",
      "id" : 6428702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/0E7mAvcrsi",
      "expanded_url" : "http:\/\/antiboredom.github.io\/a-letter-to-our-zuckerberg\/",
      "display_url" : "antiboredom.github.io\/a-letter-to-ou\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "672084865005785088",
  "text" : "RT @sam_lavigne: \"a letter to our zuckerberg\" - https:\/\/t.co\/0E7mAvcrsi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 31, 54 ],
        "url" : "https:\/\/t.co\/0E7mAvcrsi",
        "expanded_url" : "http:\/\/antiboredom.github.io\/a-letter-to-our-zuckerberg\/",
        "display_url" : "antiboredom.github.io\/a-letter-to-ou\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "672083528427941888",
    "text" : "\"a letter to our zuckerberg\" - https:\/\/t.co\/0E7mAvcrsi",
    "id" : 672083528427941888,
    "created_at" : "2015-12-02 16:02:54 +0000",
    "user" : {
      "name" : "Sam Lavigne",
      "screen_name" : "sam_lavigne",
      "protected" : false,
      "id_str" : "6428702",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/453703393907712000\/-NTZsg_T_normal.jpeg",
      "id" : 6428702,
      "verified" : false
    }
  },
  "id" : 672084865005785088,
  "created_at" : "2015-12-02 16:08:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Danny McDonald",
      "screen_name" : "interro_gator",
      "indices" : [ 0, 14 ],
      "id_str" : "2896075806",
      "id" : 2896075806
    }, {
      "name" : "Regular Expression",
      "screen_name" : "RegexTip",
      "indices" : [ 19, 28 ],
      "id_str" : "93473293",
      "id" : 93473293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "671965907607027712",
  "geo" : { },
  "id_str" : "671967697085833216",
  "in_reply_to_user_id" : 2896075806,
  "text" : "@interro_gator  hi @RegexTip has some good links usually",
  "id" : 671967697085833216,
  "in_reply_to_status_id" : 671965907607027712,
  "created_at" : "2015-12-02 08:22:38 +0000",
  "in_reply_to_screen_name" : "interro_gator",
  "in_reply_to_user_id_str" : "2896075806",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Harbeck",
      "screen_name" : "sesquiotic",
      "indices" : [ 3, 14 ],
      "id_str" : "325005504",
      "id" : 325005504
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/nQnV7bipUc",
      "expanded_url" : "http:\/\/theweek.com\/audio\/591398\/5-subtle-sounds-that-english-speakers-have-trouble-catching",
      "display_url" : "theweek.com\/audio\/591398\/5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "671922457360601088",
  "text" : "RT @sesquiotic: Here's a bit of intro phonology for non-linguist anglophones https:\/\/t.co\/nQnV7bipUc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/nQnV7bipUc",
        "expanded_url" : "http:\/\/theweek.com\/audio\/591398\/5-subtle-sounds-that-english-speakers-have-trouble-catching",
        "display_url" : "theweek.com\/audio\/591398\/5\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "671768081321082882",
    "text" : "Here's a bit of intro phonology for non-linguist anglophones https:\/\/t.co\/nQnV7bipUc",
    "id" : 671768081321082882,
    "created_at" : "2015-12-01 19:09:26 +0000",
    "user" : {
      "name" : "James Harbeck",
      "screen_name" : "sesquiotic",
      "protected" : false,
      "id_str" : "325005504",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751902925274943488\/ZOeYdJww_normal.jpg",
      "id" : 325005504,
      "verified" : false
    }
  },
  "id" : 671922457360601088,
  "created_at" : "2015-12-02 05:22:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil Clark",
      "screen_name" : "NeilClark66",
      "indices" : [ 3, 15 ],
      "id_str" : "728039605",
      "id" : 728039605
    }, {
      "name" : "brian g",
      "screen_name" : "bodhibrian",
      "indices" : [ 17, 28 ],
      "id_str" : "2686106365",
      "id" : 2686106365
    }, {
      "name" : "John Wight",
      "screen_name" : "JohnWight1",
      "indices" : [ 29, 40 ],
      "id_str" : "313221429",
      "id" : 313221429
    }, {
      "name" : "Mehdi Hasan",
      "screen_name" : "mehdirhasan",
      "indices" : [ 41, 53 ],
      "id_str" : "130557513",
      "id" : 130557513
    }, {
      "name" : "Dr Shahid",
      "screen_name" : "Dr_Shahid",
      "indices" : [ 54, 64 ],
      "id_str" : "51670985",
      "id" : 51670985
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/HQ4I4YueD4",
      "expanded_url" : "http:\/\/on.rt.com\/6vsy",
      "display_url" : "on.rt.com\/6vsy"
    } ]
  },
  "geo" : { },
  "id_str" : "671919438573281280",
  "text" : "RT @NeilClark66: @bodhibrian @JohnWight1 @mehdirhasan @DR_SHAHID Syrians who suppt their govt are 'unpeople' 4 west faux-democrats\nhttps:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "brian g",
        "screen_name" : "bodhibrian",
        "indices" : [ 0, 11 ],
        "id_str" : "2686106365",
        "id" : 2686106365
      }, {
        "name" : "John Wight",
        "screen_name" : "JohnWight1",
        "indices" : [ 12, 23 ],
        "id_str" : "313221429",
        "id" : 313221429
      }, {
        "name" : "Mehdi Hasan",
        "screen_name" : "mehdirhasan",
        "indices" : [ 24, 36 ],
        "id_str" : "130557513",
        "id" : 130557513
      }, {
        "name" : "Dr Shahid",
        "screen_name" : "Dr_Shahid",
        "indices" : [ 37, 47 ],
        "id_str" : "51670985",
        "id" : 51670985
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/HQ4I4YueD4",
        "expanded_url" : "http:\/\/on.rt.com\/6vsy",
        "display_url" : "on.rt.com\/6vsy"
      } ]
    },
    "in_reply_to_status_id_str" : "671802224276692993",
    "geo" : { },
    "id_str" : "671803309515251714",
    "in_reply_to_user_id" : 2686106365,
    "text" : "@bodhibrian @JohnWight1 @mehdirhasan @DR_SHAHID Syrians who suppt their govt are 'unpeople' 4 west faux-democrats\nhttps:\/\/t.co\/HQ4I4YueD4",
    "id" : 671803309515251714,
    "in_reply_to_status_id" : 671802224276692993,
    "created_at" : "2015-12-01 21:29:25 +0000",
    "in_reply_to_screen_name" : "bodhibrian",
    "in_reply_to_user_id_str" : "2686106365",
    "user" : {
      "name" : "Neil Clark",
      "screen_name" : "NeilClark66",
      "protected" : false,
      "id_str" : "728039605",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2451450991\/neil_clark_normal.png",
      "id" : 728039605,
      "verified" : false
    }
  },
  "id" : 671919438573281280,
  "created_at" : "2015-12-02 05:10:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 88, 99 ],
      "id_str" : "282659955",
      "id" : 282659955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/pWjN1A1L25",
      "expanded_url" : "http:\/\/wp.me\/p2e2Wf-hb",
      "display_url" : "wp.me\/p2e2Wf-hb"
    } ]
  },
  "geo" : { },
  "id_str" : "671788637764325376",
  "text" : "What are reading skills? \u2013They\u2019re not (only) what you think https:\/\/t.co\/pWjN1A1L25 via @teflerinha",
  "id" : 671788637764325376,
  "created_at" : "2015-12-01 20:31:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HaveUread",
      "screen_name" : "thisbyanychance",
      "indices" : [ 0, 16 ],
      "id_str" : "3416415189",
      "id" : 3416415189
    }, {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 22, 38 ],
      "id_str" : "394053348",
      "id" : 394053348
    }, {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 39, 54 ],
      "id_str" : "285614027",
      "id" : 285614027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "671658107634712576",
  "geo" : { },
  "id_str" : "671730868822650881",
  "in_reply_to_user_id" : 394053348,
  "text" : "@thisbyanychance tell @michaelegriffin @AnthonyTeacher to tell @anyoneinterested about Dale cone",
  "id" : 671730868822650881,
  "in_reply_to_status_id" : 671658107634712576,
  "created_at" : "2015-12-01 16:41:33 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 76, 91 ],
      "id_str" : "285614027",
      "id" : 285614027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/2duAVYX8CR",
      "expanded_url" : "http:\/\/www.anthonyteacher.com\/blog\/dictaphrase-a-listening-comprehension-activity",
      "display_url" : "anthonyteacher.com\/blog\/dictaphra\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "671729218347208705",
  "text" : "Dictaphrase: A Listening Comprehension Activity https:\/\/t.co\/2duAVYX8CR via @AnthonyTeacher",
  "id" : 671729218347208705,
  "created_at" : "2015-12-01 16:35:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RadRes",
      "screen_name" : "Radicalisation",
      "indices" : [ 3, 18 ],
      "id_str" : "335350868",
      "id" : 335350868
    }, {
      "name" : "Paul Baker",
      "screen_name" : "_paulbaker_",
      "indices" : [ 80, 92 ],
      "id_str" : "1026683874",
      "id" : 1026683874
    }, {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "indices" : [ 93, 105 ],
      "id_str" : "849729062",
      "id" : 849729062
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Radicalisation\/status\/671630770407129088\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/y3XdE8NxhS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVIcfu3WoAA52zA.jpg",
      "id_str" : "671630625913348096",
      "id" : 671630625913348096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVIcfu3WoAA52zA.jpg",
      "sizes" : [ {
        "h" : 397,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 463,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 463,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/y3XdE8NxhS"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/hHfBsbLZWM",
      "expanded_url" : "http:\/\/goo.gl\/GQkZI5",
      "display_url" : "goo.gl\/GQkZI5"
    } ]
  },
  "geo" : { },
  "id_str" : "671656019089575936",
  "text" : "RT @Radicalisation: The British press and radicalisation - summary of report by @_paulbaker_ @TonyMcEnery https:\/\/t.co\/hHfBsbLZWM https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Paul Baker",
        "screen_name" : "_paulbaker_",
        "indices" : [ 60, 72 ],
        "id_str" : "1026683874",
        "id" : 1026683874
      }, {
        "name" : "Tony McEnery",
        "screen_name" : "TonyMcEnery",
        "indices" : [ 73, 85 ],
        "id_str" : "849729062",
        "id" : 849729062
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Radicalisation\/status\/671630770407129088\/photo\/1",
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/y3XdE8NxhS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CVIcfu3WoAA52zA.jpg",
        "id_str" : "671630625913348096",
        "id" : 671630625913348096,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVIcfu3WoAA52zA.jpg",
        "sizes" : [ {
          "h" : 397,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 463,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 463,
          "resize" : "fit",
          "w" : 700
        } ],
        "display_url" : "pic.twitter.com\/y3XdE8NxhS"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/hHfBsbLZWM",
        "expanded_url" : "http:\/\/goo.gl\/GQkZI5",
        "display_url" : "goo.gl\/GQkZI5"
      } ]
    },
    "geo" : { },
    "id_str" : "671630770407129088",
    "text" : "The British press and radicalisation - summary of report by @_paulbaker_ @TonyMcEnery https:\/\/t.co\/hHfBsbLZWM https:\/\/t.co\/y3XdE8NxhS",
    "id" : 671630770407129088,
    "created_at" : "2015-12-01 10:03:48 +0000",
    "user" : {
      "name" : "RadRes",
      "screen_name" : "Radicalisation",
      "protected" : false,
      "id_str" : "335350868",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464363931096461312\/EfgqPKzL_normal.jpeg",
      "id" : 335350868,
      "verified" : false
    }
  },
  "id" : 671656019089575936,
  "created_at" : "2015-12-01 11:44:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
} ]