Grailbird.data.tweets_2016_04 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Caulfield",
      "screen_name" : "holden",
      "indices" : [ 3, 10 ],
      "id_str" : "1912681",
      "id" : 1912681
    }, {
      "name" : "David Wiley, PhD",
      "screen_name" : "opencontent",
      "indices" : [ 79, 91 ],
      "id_str" : "4514361",
      "id" : 4514361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 140 ],
      "url" : "https:\/\/t.co\/f76zrzyJRO",
      "expanded_url" : "https:\/\/hapgood.us\/2016\/04\/30\/simons-watchmakers-and-the-future-of-courseware\/",
      "display_url" : "hapgood.us\/2016\/04\/30\/sim\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "726521201410072576",
  "text" : "RT @holden: So you know that thing when you start to write a short reply to an @opencontent post and 3100 words later... https:\/\/t.co\/f76zr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "David Wiley, PhD",
        "screen_name" : "opencontent",
        "indices" : [ 67, 79 ],
        "id_str" : "4514361",
        "id" : 4514361
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/f76zrzyJRO",
        "expanded_url" : "https:\/\/hapgood.us\/2016\/04\/30\/simons-watchmakers-and-the-future-of-courseware\/",
        "display_url" : "hapgood.us\/2016\/04\/30\/sim\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "726512242418700288",
    "text" : "So you know that thing when you start to write a short reply to an @opencontent post and 3100 words later... https:\/\/t.co\/f76zrzyJRO",
    "id" : 726512242418700288,
    "created_at" : "2016-04-30 20:43:11 +0000",
    "user" : {
      "name" : "Mike Caulfield",
      "screen_name" : "holden",
      "protected" : false,
      "id_str" : "1912681",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/752538301538545665\/mXNoIc4W_normal.jpg",
      "id" : 1912681,
      "verified" : false
    }
  },
  "id" : 726521201410072576,
  "created_at" : "2016-04-30 21:18:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Scott",
      "screen_name" : "mike_lexically",
      "indices" : [ 0, 15 ],
      "id_str" : "3347309967",
      "id" : 3347309967
    }, {
      "name" : "EAPsteve",
      "screen_name" : "EAPstephen",
      "indices" : [ 16, 27 ],
      "id_str" : "2717005711",
      "id" : 2717005711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "725782707473682433",
  "geo" : { },
  "id_str" : "726495848826294272",
  "in_reply_to_user_id" : 18602422,
  "text" : "@mike_lexically @EAPstephen thanks for RT Stephen",
  "id" : 726495848826294272,
  "in_reply_to_status_id" : 725782707473682433,
  "created_at" : "2016-04-30 19:38:02 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenn Greenwald",
      "screen_name" : "ggreenwald",
      "indices" : [ 3, 14 ],
      "id_str" : "16076032",
      "id" : 16076032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 143, 144 ],
      "url" : "https:\/\/t.co\/Pagc7pLyqB",
      "expanded_url" : "http:\/\/forward.com\/culture\/books\/339119\/qa-michael-chabon-talks-occupation-injustice-and-literature-after-visit-to\/#ixzz46mZImSny",
      "display_url" : "forward.com\/culture\/books\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "726484981661446144",
  "text" : "RT @ggreenwald: Michael Chabon visits WB &amp; Gaza, calls Israeli occupation \"the most grievous injustice I have ever seen in my life\" https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 143 ],
        "url" : "https:\/\/t.co\/Pagc7pLyqB",
        "expanded_url" : "http:\/\/forward.com\/culture\/books\/339119\/qa-michael-chabon-talks-occupation-injustice-and-literature-after-visit-to\/#ixzz46mZImSny",
        "display_url" : "forward.com\/culture\/books\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "726374790882271232",
    "text" : "Michael Chabon visits WB &amp; Gaza, calls Israeli occupation \"the most grievous injustice I have ever seen in my life\" https:\/\/t.co\/Pagc7pLyqB",
    "id" : 726374790882271232,
    "created_at" : "2016-04-30 11:37:00 +0000",
    "user" : {
      "name" : "Glenn Greenwald",
      "screen_name" : "ggreenwald",
      "protected" : false,
      "id_str" : "16076032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/659383028771364869\/G9HHnjiI_normal.jpg",
      "id" : 16076032,
      "verified" : true
    }
  },
  "id" : 726484981661446144,
  "created_at" : "2016-04-30 18:54:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "askboris",
      "indices" : [ 16, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "726360674239139840",
  "text" : "RT @pchallinor: #askboris Are you at all worried that your party's sudden attack of anti-racism will include watermelon smiles and piccanin\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "askboris",
        "indices" : [ 0, 9 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "725682629656326145",
    "text" : "#askboris Are you at all worried that your party's sudden attack of anti-racism will include watermelon smiles and piccaninnies?",
    "id" : 725682629656326145,
    "created_at" : "2016-04-28 13:46:36 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 726360674239139840,
  "created_at" : "2016-04-30 10:40:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Edwards",
      "screen_name" : "EdLaur",
      "indices" : [ 0, 7 ],
      "id_str" : "1834826917",
      "id" : 1834826917
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "726335932715143172",
  "geo" : { },
  "id_str" : "726340078256185344",
  "in_reply_to_user_id" : 1834826917,
  "text" : "@EdLaur thanks : )",
  "id" : 726340078256185344,
  "in_reply_to_status_id" : 726335932715143172,
  "created_at" : "2016-04-30 09:19:04 +0000",
  "in_reply_to_screen_name" : "EdLaur",
  "in_reply_to_user_id_str" : "1834826917",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 81, 93 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/OeQzKvMVCL",
      "expanded_url" : "https:\/\/lizzieserene.wordpress.com\/2016\/04\/30\/writers-world-how-i-learned-to-use-antwordprofiler\/",
      "display_url" : "lizzieserene.wordpress.com\/2016\/04\/30\/wri\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "726335343277051904",
  "text" : "Writer's World: How I learned to use AntWordProfiler https:\/\/t.co\/OeQzKvMVCL via @annehendler",
  "id" : 726335343277051904,
  "created_at" : "2016-04-30 09:00:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "726219417999151104",
  "geo" : { },
  "id_str" : "726335149349179392",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler coolio : ) excel is very handy for many things indeed",
  "id" : 726335149349179392,
  "in_reply_to_status_id" : 726219417999151104,
  "created_at" : "2016-04-30 08:59:28 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Purland",
      "screen_name" : "englishbanana",
      "indices" : [ 0, 14 ],
      "id_str" : "1065987680",
      "id" : 1065987680
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "726113786428559360",
  "geo" : { },
  "id_str" : "726120151507189761",
  "in_reply_to_user_id" : 1065987680,
  "text" : "@englishbanana admittedly the rules may not be \"simple\" for beginners but there are rules",
  "id" : 726120151507189761,
  "in_reply_to_status_id" : 726113786428559360,
  "created_at" : "2016-04-29 18:45:09 +0000",
  "in_reply_to_screen_name" : "englishbanana",
  "in_reply_to_user_id_str" : "1065987680",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Purland",
      "screen_name" : "englishbanana",
      "indices" : [ 0, 14 ],
      "id_str" : "1065987680",
      "id" : 1065987680
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "726099859741224961",
  "geo" : { },
  "id_str" : "726109162992766977",
  "in_reply_to_user_id" : 1065987680,
  "text" : "@englishbanana the rules listed in that post are designed to do just that",
  "id" : 726109162992766977,
  "in_reply_to_status_id" : 726099859741224961,
  "created_at" : "2016-04-29 18:01:29 +0000",
  "in_reply_to_screen_name" : "englishbanana",
  "in_reply_to_user_id_str" : "1065987680",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Purland",
      "screen_name" : "englishbanana",
      "indices" : [ 0, 14 ],
      "id_str" : "1065987680",
      "id" : 1065987680
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/wKCiCoqd1O",
      "expanded_url" : "http:\/\/www.zompist.com\/spell.html",
      "display_url" : "zompist.com\/spell.html"
    } ]
  },
  "in_reply_to_status_id_str" : "726093229767184384",
  "geo" : { },
  "id_str" : "726096136843476992",
  "in_reply_to_user_id" : 1065987680,
  "text" : "@englishbanana not really broken according to https:\/\/t.co\/wKCiCoqd1O",
  "id" : 726096136843476992,
  "in_reply_to_status_id" : 726093229767184384,
  "created_at" : "2016-04-29 17:09:43 +0000",
  "in_reply_to_screen_name" : "englishbanana",
  "in_reply_to_user_id_str" : "1065987680",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "indices" : [ 3, 18 ],
      "id_str" : "152194866",
      "id" : 152194866
    }, {
      "name" : "Glenn Greenwald",
      "screen_name" : "ggreenwald",
      "indices" : [ 126, 137 ],
      "id_str" : "16076032",
      "id" : 16076032
    }, {
      "name" : "Anonymous",
      "screen_name" : "YourAnonNews",
      "indices" : [ 139, 140 ],
      "id_str" : "279390084",
      "id" : 279390084
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/UMW2vvKV4b",
      "expanded_url" : "http:\/\/wp.me\/pSoaD-hXf",
      "display_url" : "wp.me\/pSoaD-hXf"
    } ]
  },
  "geo" : { },
  "id_str" : "725961980184543232",
  "text" : "RT @patrickDurusau: U.S. Government Surveillance Breeds Meekness, Fear and Self-Censorship [Old News] https:\/\/t.co\/UMW2vvKV4b @ggreenwald @\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Glenn Greenwald",
        "screen_name" : "ggreenwald",
        "indices" : [ 106, 117 ],
        "id_str" : "16076032",
        "id" : 16076032
      }, {
        "name" : "Anonymous",
        "screen_name" : "YourAnonNews",
        "indices" : [ 118, 131 ],
        "id_str" : "279390084",
        "id" : 279390084
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/UMW2vvKV4b",
        "expanded_url" : "http:\/\/wp.me\/pSoaD-hXf",
        "display_url" : "wp.me\/pSoaD-hXf"
      } ]
    },
    "geo" : { },
    "id_str" : "725849442335772673",
    "text" : "U.S. Government Surveillance Breeds Meekness, Fear and Self-Censorship [Old News] https:\/\/t.co\/UMW2vvKV4b @ggreenwald @YourAnonNews",
    "id" : 725849442335772673,
    "created_at" : "2016-04-29 00:49:27 +0000",
    "user" : {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "protected" : false,
      "id_str" : "152194866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/961579480\/patrick_normal.jpeg",
      "id" : 152194866,
      "verified" : false
    }
  },
  "id" : 725961980184543232,
  "created_at" : "2016-04-29 08:16:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamie C",
      "screen_name" : "timedingtable",
      "indices" : [ 0, 14 ],
      "id_str" : "2500889389",
      "id" : 2500889389
    }, {
      "name" : "Matthew Noble",
      "screen_name" : "tesolmatthew",
      "indices" : [ 15, 28 ],
      "id_str" : "1519875330",
      "id" : 1519875330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "725860219713019906",
  "geo" : { },
  "id_str" : "725960499020500992",
  "in_reply_to_user_id" : 2500889389,
  "text" : "@timedingtable @tesolmatthew there's a GUI based version for OSX if commandline one is problematic",
  "id" : 725960499020500992,
  "in_reply_to_status_id" : 725860219713019906,
  "created_at" : "2016-04-29 08:10:45 +0000",
  "in_reply_to_screen_name" : "timedingtable",
  "in_reply_to_user_id_str" : "2500889389",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Scott",
      "screen_name" : "mike_lexically",
      "indices" : [ 0, 15 ],
      "id_str" : "3347309967",
      "id" : 3347309967
    }, {
      "name" : "umasslinguistics",
      "screen_name" : "umasslinguistic",
      "indices" : [ 16, 32 ],
      "id_str" : "149239362",
      "id" : 149239362
    }, {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 33, 48 ],
      "id_str" : "334332424",
      "id" : 334332424
    }, {
      "name" : "\u0633\u0644\u0637\u0627\u0646 \u0627\u0644\u0645\u062C\u064A\u0648\u0644",
      "screen_name" : "Arabic_CL",
      "indices" : [ 49, 59 ],
      "id_str" : "469764795",
      "id" : 469764795
    }, {
      "name" : "Chris Jones",
      "screen_name" : "ELTResearch",
      "indices" : [ 60, 72 ],
      "id_str" : "3308043417",
      "id" : 3308043417
    }, {
      "name" : "Mairead Moriarty",
      "screen_name" : "MawsMoriarty",
      "indices" : [ 73, 86 ],
      "id_str" : "2353100574",
      "id" : 2353100574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "725782707473682433",
  "geo" : { },
  "id_str" : "725960285064851456",
  "in_reply_to_user_id" : 18602422,
  "text" : "@mike_lexically @umasslinguistic @GeoffreyJordan @Arabic_CL @ELTResearch @MawsMoriarty thanks for sharing post : )",
  "id" : 725960285064851456,
  "in_reply_to_status_id" : 725782707473682433,
  "created_at" : "2016-04-29 08:09:54 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Scott",
      "screen_name" : "mike_lexically",
      "indices" : [ 15, 30 ],
      "id_str" : "3347309967",
      "id" : 3347309967
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpuslinguistics",
      "indices" : [ 93, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/lCX6WNYzBy",
      "expanded_url" : "https:\/\/eflnotes.wordpress.com\/2016\/04\/18\/interview-with-mike-scott-wordsmith-tools-developer\/",
      "display_url" : "eflnotes.wordpress.com\/2016\/04\/18\/int\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "725782707473682433",
  "text" : "Interview with @mike_lexically Mike Scott, WordSmith Tools developer https:\/\/t.co\/lCX6WNYzBy #corpuslinguistics",
  "id" : 725782707473682433,
  "created_at" : "2016-04-28 20:24:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eily Murphy",
      "screen_name" : "eilymurphy",
      "indices" : [ 0, 11 ],
      "id_str" : "111091623",
      "id" : 111091623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "725770546416390145",
  "geo" : { },
  "id_str" : "725773421506924546",
  "in_reply_to_user_id" : 111091623,
  "text" : "@eilymurphy hi Eily thanks for reading not sure if it makes sense but seeing as part of record has disappeared recently decided to publish",
  "id" : 725773421506924546,
  "in_reply_to_status_id" : 725770546416390145,
  "created_at" : "2016-04-28 19:47:22 +0000",
  "in_reply_to_screen_name" : "eilymurphy",
  "in_reply_to_user_id_str" : "111091623",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/ybNcCcgnyu",
      "expanded_url" : "https:\/\/storify.com\/muranava\/carcrash",
      "display_url" : "storify.com\/muranava\/carcr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "725769309574823937",
  "text" : "Carcrashing https:\/\/t.co\/ybNcCcgnyu How not to debate on Twitter",
  "id" : 725769309574823937,
  "created_at" : "2016-04-28 19:31:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Field",
      "screen_name" : "John__Field",
      "indices" : [ 118, 130 ],
      "id_str" : "126258726",
      "id" : 126258726
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/bfuhx1Y7pJ",
      "expanded_url" : "https:\/\/thelearningprofessor.wordpress.com\/2016\/04\/28\/anti-semitism-and-the-history-of-zionist-emigration-it-seems-i-might-be-a-nazi-apologist\/",
      "display_url" : "thelearningprofessor.wordpress.com\/2016\/04\/28\/ant\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "725768686691311616",
  "text" : "Anti-semitism and the history of Zionist emigration: it seems I might be a Nazi apologist https:\/\/t.co\/bfuhx1Y7pJ via @John__Field",
  "id" : 725768686691311616,
  "created_at" : "2016-04-28 19:28:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/725688442764550144\/photo\/1",
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/amxl78lEL4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChIpx_WXEAAWa8i.jpg",
      "id_str" : "725688428755619840",
      "id" : 725688428755619840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChIpx_WXEAAWa8i.jpg",
      "sizes" : [ {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1151
      }, {
        "h" : 1068,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 605,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1822,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/amxl78lEL4"
    } ],
    "hashtags" : [ {
      "text" : "paris",
      "indices" : [ 35, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725688442764550144",
  "text" : "renovated Les Halles shopping area #paris looking much improved https:\/\/t.co\/amxl78lEL4",
  "id" : 725688442764550144,
  "created_at" : "2016-04-28 14:09:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Seymour",
      "screen_name" : "leninology",
      "indices" : [ 3, 14 ],
      "id_str" : "15557246",
      "id" : 15557246
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/wvIbXLB6CG",
      "expanded_url" : "http:\/\/www.jewishsocialist.org.uk\/news\/item\/statement-on-labours-problem-with-antisemitism-from-the-jewish-socialists-g",
      "display_url" : "jewishsocialist.org.uk\/news\/item\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "725687272025284609",
  "text" : "RT @leninology: Jewish Socialist Group statement on 'antisemitism' claims: https:\/\/t.co\/wvIbXLB6CG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 82 ],
        "url" : "https:\/\/t.co\/wvIbXLB6CG",
        "expanded_url" : "http:\/\/www.jewishsocialist.org.uk\/news\/item\/statement-on-labours-problem-with-antisemitism-from-the-jewish-socialists-g",
        "display_url" : "jewishsocialist.org.uk\/news\/item\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "725640352619761664",
    "text" : "Jewish Socialist Group statement on 'antisemitism' claims: https:\/\/t.co\/wvIbXLB6CG",
    "id" : 725640352619761664,
    "created_at" : "2016-04-28 10:58:36 +0000",
    "user" : {
      "name" : "Richard Seymour",
      "screen_name" : "leninology",
      "protected" : false,
      "id_str" : "15557246",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762344914583781377\/UDn8tMrp_normal.jpg",
      "id" : 15557246,
      "verified" : false
    }
  },
  "id" : 725687272025284609,
  "created_at" : "2016-04-28 14:05:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    }, {
      "name" : "Liam T",
      "screen_name" : "Liam_ELT",
      "indices" : [ 17, 26 ],
      "id_str" : "3165901457",
      "id" : 3165901457
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/X2xF28H5Wg",
      "expanded_url" : "http:\/\/corpus.byu.edu\/coca\/?c=coca&q=47290695",
      "display_url" : "corpus.byu.edu\/coca\/?c=coca&q\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "725683495608012802",
  "geo" : { },
  "id_str" : "725684652388827137",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish @Liam_ELT some here https:\/\/t.co\/X2xF28H5Wg",
  "id" : 725684652388827137,
  "in_reply_to_status_id" : 725683495608012802,
  "created_at" : "2016-04-28 13:54:38 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Guillaume Desagulier",
      "screen_name" : "gdlinguist",
      "indices" : [ 3, 14 ],
      "id_str" : "4901184795",
      "id" : 4901184795
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/gdlinguist\/status\/725574764056727552\/photo\/1",
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/jdTxReBCdh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChHCZyCWUAArUr7.jpg",
      "id_str" : "725574763167502336",
      "id" : 725574763167502336,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChHCZyCWUAArUr7.jpg",
      "sizes" : [ {
        "h" : 870,
        "resize" : "fit",
        "w" : 1480
      }, {
        "h" : 602,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 200,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 353,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/jdTxReBCdh"
    } ],
    "hashtags" : [ {
      "text" : "LT",
      "indices" : [ 16, 19 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725596262049964032",
  "text" : "RT @gdlinguist: #LT Tattoo artists, here is my contribution: the tree of English intensifiers https:\/\/t.co\/jdTxReBCdh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/gdlinguist\/status\/725574764056727552\/photo\/1",
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/jdTxReBCdh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ChHCZyCWUAArUr7.jpg",
        "id_str" : "725574763167502336",
        "id" : 725574763167502336,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChHCZyCWUAArUr7.jpg",
        "sizes" : [ {
          "h" : 870,
          "resize" : "fit",
          "w" : 1480
        }, {
          "h" : 602,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 200,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 353,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/jdTxReBCdh"
      } ],
      "hashtags" : [ {
        "text" : "LT",
        "indices" : [ 0, 3 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "725574764056727552",
    "text" : "#LT Tattoo artists, here is my contribution: the tree of English intensifiers https:\/\/t.co\/jdTxReBCdh",
    "id" : 725574764056727552,
    "created_at" : "2016-04-28 06:37:58 +0000",
    "user" : {
      "name" : "Guillaume Desagulier",
      "screen_name" : "gdlinguist",
      "protected" : false,
      "id_str" : "4901184795",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/698131603168563200\/n6PZzu5f_normal.jpg",
      "id" : 4901184795,
      "verified" : false
    }
  },
  "id" : 725596262049964032,
  "created_at" : "2016-04-28 08:03:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Guillaume Desagulier",
      "screen_name" : "gdlinguist",
      "indices" : [ 0, 11 ],
      "id_str" : "4901184795",
      "id" : 4901184795
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "725593875658752000",
  "geo" : { },
  "id_str" : "725596168722485248",
  "in_reply_to_user_id" : 4901184795,
  "text" : "@gdlinguist cool thkx : )",
  "id" : 725596168722485248,
  "in_reply_to_status_id" : 725593875658752000,
  "created_at" : "2016-04-28 08:03:02 +0000",
  "in_reply_to_screen_name" : "gdlinguist",
  "in_reply_to_user_id_str" : "4901184795",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Guillaume Desagulier",
      "screen_name" : "gdlinguist",
      "indices" : [ 0, 11 ],
      "id_str" : "4901184795",
      "id" : 4901184795
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "725574764056727552",
  "geo" : { },
  "id_str" : "725590908541001729",
  "in_reply_to_user_id" : 4901184795,
  "text" : "@gdlinguist hi how did you do this?",
  "id" : 725590908541001729,
  "in_reply_to_status_id" : 725574764056727552,
  "created_at" : "2016-04-28 07:42:08 +0000",
  "in_reply_to_screen_name" : "gdlinguist",
  "in_reply_to_user_id_str" : "4901184795",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/725486052954263552\/photo\/1",
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/PxitzBivSy",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/ChFwd9hWgAA7yYO.jpg",
      "id_str" : "725484675016327168",
      "id" : 725484675016327168,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/ChFwd9hWgAA7yYO.jpg",
      "sizes" : [ {
        "h" : 278,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 190,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 278,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 278,
        "resize" : "fit",
        "w" : 498
      } ],
      "display_url" : "pic.twitter.com\/PxitzBivSy"
    } ],
    "hashtags" : [ {
      "text" : "weirdchunks",
      "indices" : [ 31, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/jW0YA6IMH8",
      "expanded_url" : "http:\/\/www.ncl.ac.uk\/ecls\/staff\/profile\/sugata.mitra",
      "display_url" : "ncl.ac.uk\/ecls\/staff\/pro\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "725486052954263552",
  "text" : "\"seminally speculative paper\"  #weirdchunks https:\/\/t.co\/jW0YA6IMH8 https:\/\/t.co\/PxitzBivSy",
  "id" : 725486052954263552,
  "created_at" : "2016-04-28 00:45:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Edwards",
      "screen_name" : "EdLaur",
      "indices" : [ 0, 7 ],
      "id_str" : "1834826917",
      "id" : 1834826917
    }, {
      "name" : "Scott Thornbury",
      "screen_name" : "thornburyscott",
      "indices" : [ 8, 23 ],
      "id_str" : "23090474",
      "id" : 23090474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/zw34sc3cxK",
      "expanded_url" : "http:\/\/www.diva-portal.org\/smash\/get\/diva2:638164\/FULLTEXT01.pdf",
      "display_url" : "diva-portal.org\/smash\/get\/diva\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "725412082938732545",
  "geo" : { },
  "id_str" : "725413150875619329",
  "in_reply_to_user_id" : 1834826917,
  "text" : "@EdLaur @thornburyscott it's Swedish context https:\/\/t.co\/zw34sc3cxK",
  "id" : 725413150875619329,
  "in_reply_to_status_id" : 725412082938732545,
  "created_at" : "2016-04-27 19:55:47 +0000",
  "in_reply_to_screen_name" : "EdLaur",
  "in_reply_to_user_id_str" : "1834826917",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Edwards",
      "screen_name" : "EdLaur",
      "indices" : [ 0, 7 ],
      "id_str" : "1834826917",
      "id" : 1834826917
    }, {
      "name" : "Matthew Noble",
      "screen_name" : "tesolmatthew",
      "indices" : [ 8, 21 ],
      "id_str" : "1519875330",
      "id" : 1519875330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/WN7E9CnMA0",
      "expanded_url" : "http:\/\/playphrase.me\/en\/search?q=this%20one&p=54bd0bad5be5fff816201d43",
      "display_url" : "playphrase.me\/en\/search?q=th\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "725221990592860160",
  "geo" : { },
  "id_str" : "725224096544464896",
  "in_reply_to_user_id" : 1834826917,
  "text" : "@EdLaur @tesolmatthew this one - https:\/\/t.co\/WN7E9CnMA0 ?",
  "id" : 725224096544464896,
  "in_reply_to_status_id" : 725221990592860160,
  "created_at" : "2016-04-27 07:24:33 +0000",
  "in_reply_to_screen_name" : "EdLaur",
  "in_reply_to_user_id_str" : "1834826917",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/724966031882633216\/photo\/1",
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/WZreHWDRds",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cg-YvzHWMAAdtNF.jpg",
      "id_str" : "724966011972235264",
      "id" : 724966011972235264,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cg-YvzHWMAAdtNF.jpg",
      "sizes" : [ {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1151
      }, {
        "h" : 1068,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 605,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1822,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/WZreHWDRds"
    } ],
    "hashtags" : [ {
      "text" : "japon",
      "indices" : [ 49, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "724966031882633216",
  "text" : "Gundam not impressed by Godzilla's TESOL musings #japon https:\/\/t.co\/WZreHWDRds",
  "id" : 724966031882633216,
  "created_at" : "2016-04-26 14:19:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Serveis Ling\u00FC\u00EDstics",
      "screen_name" : "SLBCoop",
      "indices" : [ 0, 8 ],
      "id_str" : "2365399801",
      "id" : 2365399801
    }, {
      "name" : "Myles Klynhout",
      "screen_name" : "myles_klynhout",
      "indices" : [ 9, 24 ],
      "id_str" : "2908069515",
      "id" : 2908069515
    }, {
      "name" : "teachers_as_workers",
      "screen_name" : "taw_sig",
      "indices" : [ 25, 33 ],
      "id_str" : "3152637711",
      "id" : 3152637711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "724964530078502913",
  "geo" : { },
  "id_str" : "724964738686435329",
  "in_reply_to_user_id" : 2365399801,
  "text" : "@SLBCoop @myles_klynhout @taw_sig great : )",
  "id" : 724964738686435329,
  "in_reply_to_status_id" : 724964530078502913,
  "created_at" : "2016-04-26 14:13:57 +0000",
  "in_reply_to_screen_name" : "SLBCoop",
  "in_reply_to_user_id_str" : "2365399801",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Patsko",
      "screen_name" : "lauraahaha",
      "indices" : [ 0, 11 ],
      "id_str" : "97957137",
      "id" : 97957137
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "724878440546066432",
  "geo" : { },
  "id_str" : "724964559732244481",
  "in_reply_to_user_id" : 97957137,
  "text" : "@lauraahaha a bath(onsen) in Tokyo with a Disney like Japan entertainment complex attached",
  "id" : 724964559732244481,
  "in_reply_to_status_id" : 724878440546066432,
  "created_at" : "2016-04-26 14:13:14 +0000",
  "in_reply_to_screen_name" : "lauraahaha",
  "in_reply_to_user_id_str" : "97957137",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Myles Klynhout",
      "screen_name" : "myles_klynhout",
      "indices" : [ 0, 15 ],
      "id_str" : "2908069515",
      "id" : 2908069515
    }, {
      "name" : "teachers_as_workers",
      "screen_name" : "taw_sig",
      "indices" : [ 16, 24 ],
      "id_str" : "3152637711",
      "id" : 3152637711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "724940196073099266",
  "geo" : { },
  "id_str" : "724963948236279808",
  "in_reply_to_user_id" : 2908069515,
  "text" : "@myles_klynhout @taw_sig hey no but will surely follow any reports : l",
  "id" : 724963948236279808,
  "in_reply_to_status_id" : 724940196073099266,
  "created_at" : "2016-04-26 14:10:49 +0000",
  "in_reply_to_screen_name" : "myles_klynhout",
  "in_reply_to_user_id_str" : "2908069515",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/MLMhQlRPBM",
      "expanded_url" : "http:\/\/www.danielwillingham.com\/1\/post\/2016\/04\/the-brain-in-your-pocket.html",
      "display_url" : "danielwillingham.com\/1\/post\/2016\/04\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "724721974748962817",
  "text" : "The brain in your pocket - Daniel Willingham https:\/\/t.co\/MLMhQlRPBM",
  "id" : 724721974748962817,
  "created_at" : "2016-04-25 22:09:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/Mk80RBWmJy",
      "expanded_url" : "http:\/\/www.slb.coop\/innovate-elt-2016-conference-a-critical-preflection\/",
      "display_url" : "slb.coop\/innovate-elt-2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "724721565577805824",
  "text" : "Shared from CSLB https:\/\/t.co\/Mk80RBWmJy",
  "id" : 724721565577805824,
  "created_at" : "2016-04-25 22:07:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "drunkequityadvocates",
      "indices" : [ 43, 64 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "724571512884203520",
  "geo" : { },
  "id_str" : "724576814153093120",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler and only for male bathers : ) #drunkequityadvocates",
  "id" : 724576814153093120,
  "in_reply_to_status_id" : 724571512884203520,
  "created_at" : "2016-04-25 12:32:29 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Miss O'Kistic",
      "screen_name" : "missokistic",
      "indices" : [ 3, 15 ],
      "id_str" : "14697045",
      "id" : 14697045
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "724562694779457536",
  "text" : "RT @missokistic: Ayn Rand, Rand Paul and Paul Ryan walk into a bar. The bartender serves them tainted alcohol because there are no regulati\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "466416327666974722",
    "text" : "Ayn Rand, Rand Paul and Paul Ryan walk into a bar. The bartender serves them tainted alcohol because there are no regulations. They die.",
    "id" : 466416327666974722,
    "created_at" : "2014-05-14 03:14:52 +0000",
    "user" : {
      "name" : "Miss O'Kistic",
      "screen_name" : "missokistic",
      "protected" : false,
      "id_str" : "14697045",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3579141312\/747f961ba02ede59bf47ede2177926f0_normal.jpeg",
      "id" : 14697045,
      "verified" : false
    }
  },
  "id" : 724562694779457536,
  "created_at" : "2016-04-25 11:36:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/724546884287619072\/photo\/1",
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/iu84gOYKrI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cg4bi1BVEAMVff-.jpg",
      "id_str" : "724546875215384579",
      "id" : 724546875215384579,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cg4bi1BVEAMVff-.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1281
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/iu84gOYKrI"
    } ],
    "hashtags" : [ {
      "text" : "Japon",
      "indices" : [ 22, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "724546884287619072",
  "text" : "Very wise words (^0^) #Japon https:\/\/t.co\/iu84gOYKrI",
  "id" : 724546884287619072,
  "created_at" : "2016-04-25 10:33:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 66, 82 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/R2aIqffHhn",
      "expanded_url" : "https:\/\/blog.jonudell.net\/2016\/04\/24\/annotation-is-not-only-web-comments\/",
      "display_url" : "blog.jonudell.net\/2016\/04\/24\/ann\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "724408910220685313",
  "text" : "Annotation is not (only) web comments https:\/\/t.co\/R2aIqffHhn via @wordpressdotcom",
  "id" : 724408910220685313,
  "created_at" : "2016-04-25 01:25:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Raine",
      "screen_name" : "paul_sensei",
      "indices" : [ 0, 12 ],
      "id_str" : "176429301",
      "id" : 176429301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/6kYVnXfcoV",
      "expanded_url" : "http:\/\/lingorank.com\/talks\/",
      "display_url" : "lingorank.com\/talks\/"
    } ]
  },
  "geo" : { },
  "id_str" : "724151100035600388",
  "in_reply_to_user_id" : 176429301,
  "text" : "@paul_sensei that Ted talks by cefr levels site https:\/\/t.co\/6kYVnXfcoV",
  "id" : 724151100035600388,
  "created_at" : "2016-04-24 08:20:50 +0000",
  "in_reply_to_screen_name" : "paul_sensei",
  "in_reply_to_user_id_str" : "176429301",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Parise",
      "screen_name" : "peterrenshu",
      "indices" : [ 38, 50 ],
      "id_str" : "631949549",
      "id" : 631949549
    }, {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 51, 67 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    }, {
      "name" : "Paul Raine",
      "screen_name" : "paul_sensei",
      "indices" : [ 68, 80 ],
      "id_str" : "176429301",
      "id" : 176429301
    }, {
      "name" : "Michael Brown",
      "screen_name" : "Za_Maikeru",
      "indices" : [ 81, 92 ],
      "id_str" : "703598479944208384",
      "id" : 703598479944208384
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/724146347129999360\/photo\/1",
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/vYjRNRzUjc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgyvQIKUYAEGeS7.jpg",
      "id_str" : "724146331703336961",
      "id" : 724146331703336961,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgyvQIKUYAEGeS7.jpg",
      "sizes" : [ {
        "h" : 605,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1151
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1822,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1068,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/vYjRNRzUjc"
    } ],
    "hashtags" : [ {
      "text" : "Japon",
      "indices" : [ 93, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "724146347129999360",
  "text" : "Godzilla ponders current tesol issues @peterrenshu @getgreatenglish @paul_sensei @Za_Maikeru #Japon https:\/\/t.co\/vYjRNRzUjc",
  "id" : 724146347129999360,
  "created_at" : "2016-04-24 08:01:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Apps 4 EFL",
      "screen_name" : "apps4efl",
      "indices" : [ 3, 12 ],
      "id_str" : "2594237072",
      "id" : 2594237072
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/apps4efl\/status\/723782165809369088\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/U4LVsLv5ZM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgtkCvNVEAESfXM.jpg",
      "id_str" : "723782163317985281",
      "id" : 723782163317985281,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgtkCvNVEAESfXM.jpg",
      "sizes" : [ {
        "h" : 632,
        "resize" : "fit",
        "w" : 638
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 632,
        "resize" : "fit",
        "w" : 638
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 594,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/U4LVsLv5ZM"
    } ],
    "hashtags" : [ {
      "text" : "langchat",
      "indices" : [ 84, 93 ]
    }, {
      "text" : "flteach",
      "indices" : [ 94, 102 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 103, 111 ]
    }, {
      "text" : "efl",
      "indices" : [ 112, 116 ]
    }, {
      "text" : "tesl",
      "indices" : [ 117, 122 ]
    }, {
      "text" : "esl",
      "indices" : [ 123, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/JjEk5R0WhS",
      "expanded_url" : "http:\/\/text2flash.apps4efl.com",
      "display_url" : "text2flash.apps4efl.com"
    } ]
  },
  "geo" : { },
  "id_str" : "724056930625286145",
  "text" : "RT @apps4efl: https:\/\/t.co\/JjEk5R0WhS: Automatically convert any text to flashcards #langchat #flteach #eltchat #efl #tesl #esl https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/apps4efl\/status\/723782165809369088\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/U4LVsLv5ZM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CgtkCvNVEAESfXM.jpg",
        "id_str" : "723782163317985281",
        "id" : 723782163317985281,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgtkCvNVEAESfXM.jpg",
        "sizes" : [ {
          "h" : 632,
          "resize" : "fit",
          "w" : 638
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 632,
          "resize" : "fit",
          "w" : 638
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 594,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/U4LVsLv5ZM"
      } ],
      "hashtags" : [ {
        "text" : "langchat",
        "indices" : [ 70, 79 ]
      }, {
        "text" : "flteach",
        "indices" : [ 80, 88 ]
      }, {
        "text" : "eltchat",
        "indices" : [ 89, 97 ]
      }, {
        "text" : "efl",
        "indices" : [ 98, 102 ]
      }, {
        "text" : "tesl",
        "indices" : [ 103, 108 ]
      }, {
        "text" : "esl",
        "indices" : [ 109, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/JjEk5R0WhS",
        "expanded_url" : "http:\/\/text2flash.apps4efl.com",
        "display_url" : "text2flash.apps4efl.com"
      } ]
    },
    "geo" : { },
    "id_str" : "723782165809369088",
    "text" : "https:\/\/t.co\/JjEk5R0WhS: Automatically convert any text to flashcards #langchat #flteach #eltchat #efl #tesl #esl https:\/\/t.co\/U4LVsLv5ZM",
    "id" : 723782165809369088,
    "created_at" : "2016-04-23 07:54:50 +0000",
    "user" : {
      "name" : "Apps 4 EFL",
      "screen_name" : "apps4efl",
      "protected" : false,
      "id_str" : "2594237072",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/652102680504963072\/peqnCRQT_normal.png",
      "id" : 2594237072,
      "verified" : false
    }
  },
  "id" : 724056930625286145,
  "created_at" : "2016-04-24 02:06:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenys Hanson",
      "screen_name" : "GlenysHanson",
      "indices" : [ 0, 13 ],
      "id_str" : "527238447",
      "id" : 527238447
    }, {
      "name" : "Matthew Noble",
      "screen_name" : "tesolmatthew",
      "indices" : [ 14, 27 ],
      "id_str" : "1519875330",
      "id" : 1519875330
    }, {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 28, 44 ],
      "id_str" : "394053348",
      "id" : 394053348
    }, {
      "name" : "Rob Sheppard",
      "screen_name" : "uncoeuraweigh",
      "indices" : [ 45, 59 ],
      "id_str" : "2998216702",
      "id" : 2998216702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "723984606404481024",
  "geo" : { },
  "id_str" : "724045116504076288",
  "in_reply_to_user_id" : 527238447,
  "text" : "@GlenysHanson @tesolmatthew @michaelegriffin @uncoeuraweigh tru thg there is a strong aspect of \"insight\" thru \"activities\"?",
  "id" : 724045116504076288,
  "in_reply_to_status_id" : 723984606404481024,
  "created_at" : "2016-04-24 01:19:42 +0000",
  "in_reply_to_screen_name" : "GlenysHanson",
  "in_reply_to_user_id_str" : "527238447",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "723683865936596993",
  "geo" : { },
  "id_str" : "723691066637967360",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow thx yes great time need to visit for longer next time : )",
  "id" : 723691066637967360,
  "in_reply_to_status_id" : 723683865936596993,
  "created_at" : "2016-04-23 01:52:50 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "vanessa beeley",
      "screen_name" : "VanessaBeeley",
      "indices" : [ 94, 108 ],
      "id_str" : "956171191",
      "id" : 956171191
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/LywAFrpe3C",
      "expanded_url" : "https:\/\/thewallwillfall.wordpress.com\/2016\/04\/22\/the-paris-nuit-debout-movement-journey-to-the-end-of-the-night\/",
      "display_url" : "thewallwillfall.wordpress.com\/2016\/04\/22\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "723675095797919744",
  "text" : "The Paris \"Nuit Debout\" Movement, Journey to the End of the Night https:\/\/t.co\/LywAFrpe3C via @VanessaBeeley",
  "id" : 723675095797919744,
  "created_at" : "2016-04-23 00:49:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    }, {
      "name" : "Ian Sinclair",
      "screen_name" : "IanJSinclair",
      "indices" : [ 94, 107 ],
      "id_str" : "270100506",
      "id" : 270100506
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/fzU32utnX7",
      "expanded_url" : "https:\/\/www.morningstaronline.co.uk\/a-3305-An-unelected-dictatorship-of-money",
      "display_url" : "morningstaronline.co.uk\/a-3305-An-unel\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "723674711058567168",
  "text" : "RT @medialens: Must-read short piece on the US presidential elections https:\/\/t.co\/fzU32utnX7 @IanJSinclair",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ian Sinclair",
        "screen_name" : "IanJSinclair",
        "indices" : [ 79, 92 ],
        "id_str" : "270100506",
        "id" : 270100506
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 78 ],
        "url" : "https:\/\/t.co\/fzU32utnX7",
        "expanded_url" : "https:\/\/www.morningstaronline.co.uk\/a-3305-An-unelected-dictatorship-of-money",
        "display_url" : "morningstaronline.co.uk\/a-3305-An-unel\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "723440753498693632",
    "text" : "Must-read short piece on the US presidential elections https:\/\/t.co\/fzU32utnX7 @IanJSinclair",
    "id" : 723440753498693632,
    "created_at" : "2016-04-22 09:18:11 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 723674711058567168,
  "created_at" : "2016-04-23 00:47:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "723546599440273408",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow hi Kev what was the better shochu, wheat or potato?",
  "id" : 723546599440273408,
  "created_at" : "2016-04-22 16:18:46 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/723545573442224128\/photo\/1",
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/AtR3njes0p",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgqM22QU0AEbjCo.jpg",
      "id_str" : "723545564051197953",
      "id" : 723545564051197953,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgqM22QU0AEbjCo.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1281
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/AtR3njes0p"
    } ],
    "hashtags" : [ {
      "text" : "Japon",
      "indices" : [ 21, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "723545573442224128",
  "text" : "Fugu pufferfish dish #Japon one of many amazing meals at a wedding anniversary https:\/\/t.co\/AtR3njes0p",
  "id" : 723545573442224128,
  "created_at" : "2016-04-22 16:14:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BYUHumanitiesCenter",
      "screen_name" : "byuhumcenter",
      "indices" : [ 3, 16 ],
      "id_str" : "3431832207",
      "id" : 3431832207
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/byuhumcenter\/status\/720273857941086208\/photo\/1",
      "indices" : [ 143, 144 ],
      "url" : "https:\/\/t.co\/LVAVH96duD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cf7tQaPVAAEaDjp.jpg",
      "id_str" : "720273856603160577",
      "id" : 720273856603160577,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cf7tQaPVAAEaDjp.jpg",
      "sizes" : [ {
        "h" : 186,
        "resize" : "fit",
        "w" : 186
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 186,
        "resize" : "fit",
        "w" : 186
      }, {
        "h" : 186,
        "resize" : "fit",
        "w" : 186
      }, {
        "h" : 186,
        "resize" : "fit",
        "w" : 186
      } ],
      "display_url" : "pic.twitter.com\/LVAVH96duD"
    } ],
    "hashtags" : [ {
      "text" : "corpuslinguistics",
      "indices" : [ 30, 48 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/b7CUKDP3rS",
      "expanded_url" : "http:\/\/humanitiescenter.byu.edu\/making-a-difference-the-use-of-corpora-in-legal-analysis\/",
      "display_url" : "humanitiescenter.byu.edu\/making-a-diffe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "723538907954978816",
  "text" : "RT @byuhumcenter: Corpora and #corpuslinguistics can help analyze words &amp; phrases in their natural setting\nhttps:\/\/t.co\/b7CUKDP3rS https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/byuhumcenter\/status\/720273857941086208\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/LVAVH96duD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cf7tQaPVAAEaDjp.jpg",
        "id_str" : "720273856603160577",
        "id" : 720273856603160577,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cf7tQaPVAAEaDjp.jpg",
        "sizes" : [ {
          "h" : 186,
          "resize" : "fit",
          "w" : 186
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 186,
          "resize" : "fit",
          "w" : 186
        }, {
          "h" : 186,
          "resize" : "fit",
          "w" : 186
        }, {
          "h" : 186,
          "resize" : "fit",
          "w" : 186
        } ],
        "display_url" : "pic.twitter.com\/LVAVH96duD"
      } ],
      "hashtags" : [ {
        "text" : "corpuslinguistics",
        "indices" : [ 12, 30 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/b7CUKDP3rS",
        "expanded_url" : "http:\/\/humanitiescenter.byu.edu\/making-a-difference-the-use-of-corpora-in-legal-analysis\/",
        "display_url" : "humanitiescenter.byu.edu\/making-a-diffe\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "720273857941086208",
    "text" : "Corpora and #corpuslinguistics can help analyze words &amp; phrases in their natural setting\nhttps:\/\/t.co\/b7CUKDP3rS https:\/\/t.co\/LVAVH96duD",
    "id" : 720273857941086208,
    "created_at" : "2016-04-13 15:34:04 +0000",
    "user" : {
      "name" : "BYUHumanitiesCenter",
      "screen_name" : "byuhumcenter",
      "protected" : false,
      "id_str" : "3431832207",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/634080387707240452\/o3nEFJw-_normal.jpg",
      "id" : 3431832207,
      "verified" : false
    }
  },
  "id" : 723538907954978816,
  "created_at" : "2016-04-22 15:48:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "indices" : [ 0, 13 ],
      "id_str" : "1685397408",
      "id" : 1685397408
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/723520692361134080\/photo\/1",
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/j3W2VB28n7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cgp2Om_UkAAkXSV.jpg",
      "id_str" : "723520683502768128",
      "id" : 723520683502768128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cgp2Om_UkAAkXSV.jpg",
      "sizes" : [ {
        "h" : 1067,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 720
      } ],
      "display_url" : "pic.twitter.com\/j3W2VB28n7"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/4ULvQcJblm",
      "expanded_url" : "http:\/\/www.eat.rl.ac.uk\/",
      "display_url" : "eat.rl.ac.uk"
    } ]
  },
  "in_reply_to_status_id_str" : "723453037604298752",
  "geo" : { },
  "id_str" : "723520692361134080",
  "in_reply_to_user_id" : 1685397408,
  "text" : "@harrisonmike as a response these associations may be of use from EAT https:\/\/t.co\/4ULvQcJblm https:\/\/t.co\/j3W2VB28n7",
  "id" : 723520692361134080,
  "in_reply_to_status_id" : 723453037604298752,
  "created_at" : "2016-04-22 14:35:50 +0000",
  "in_reply_to_screen_name" : "harrisonmike",
  "in_reply_to_user_id_str" : "1685397408",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Voyant Tools",
      "screen_name" : "VoyantTools",
      "indices" : [ 3, 15 ],
      "id_str" : "602254044",
      "id" : 602254044
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/1Hjts2CsTD",
      "expanded_url" : "https:\/\/github.com\/sgsinclair\/VoyantServer\/releases\/tag\/2.1.0-M1",
      "display_url" : "github.com\/sgsinclair\/Voy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "723438585517477888",
  "text" : "RT @VoyantTools: new milestone release of V2, including several improvements for hundreds or thousands of documents https:\/\/t.co\/1Hjts2CsTD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/1Hjts2CsTD",
        "expanded_url" : "https:\/\/github.com\/sgsinclair\/VoyantServer\/releases\/tag\/2.1.0-M1",
        "display_url" : "github.com\/sgsinclair\/Voy\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "723321875645009920",
    "text" : "new milestone release of V2, including several improvements for hundreds or thousands of documents https:\/\/t.co\/1Hjts2CsTD",
    "id" : 723321875645009920,
    "created_at" : "2016-04-22 01:25:48 +0000",
    "user" : {
      "name" : "Voyant Tools",
      "screen_name" : "VoyantTools",
      "protected" : false,
      "id_str" : "602254044",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2287695172\/7q9w4cyr1r3edmpy6dc0_normal.png",
      "id" : 602254044,
      "verified" : false
    }
  },
  "id" : 723438585517477888,
  "created_at" : "2016-04-22 09:09:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    }, {
      "name" : "Melih",
      "screen_name" : "melihELT",
      "indices" : [ 13, 22 ],
      "id_str" : "2797763892",
      "id" : 2797763892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "722943656995344384",
  "geo" : { },
  "id_str" : "723433323284946945",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler @melihELT thx for sharing : ) appreciate it",
  "id" : 723433323284946945,
  "in_reply_to_status_id" : 722943656995344384,
  "created_at" : "2016-04-22 08:48:39 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tressie Mc",
      "screen_name" : "tressiemcphd",
      "indices" : [ 68, 81 ],
      "id_str" : "148593548",
      "id" : 148593548
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/U1XhR5Qkjp",
      "expanded_url" : "https:\/\/tressiemc.com\/2016\/04\/21\/there-are-thieves-in-the-temple-tonight\/",
      "display_url" : "tressiemc.com\/2016\/04\/21\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "723345414976495617",
  "text" : "There Are Thieves In The Temple Tonight https:\/\/t.co\/U1XhR5Qkjp via @tressiemcphd",
  "id" : 723345414976495617,
  "created_at" : "2016-04-22 02:59:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Melville",
      "screen_name" : "JamesMelville",
      "indices" : [ 0, 14 ],
      "id_str" : "20675681",
      "id" : 20675681
    }, {
      "name" : "Adam Beale",
      "screen_name" : "bealer81",
      "indices" : [ 15, 24 ],
      "id_str" : "238993337",
      "id" : 238993337
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "723209964790120448",
  "geo" : { },
  "id_str" : "723213314071793664",
  "in_reply_to_user_id" : 20675681,
  "text" : "@JamesMelville @bealer81 foookkkk no way foooook :(",
  "id" : 723213314071793664,
  "in_reply_to_status_id" : 723209964790120448,
  "created_at" : "2016-04-21 18:14:25 +0000",
  "in_reply_to_screen_name" : "JamesMelville",
  "in_reply_to_user_id_str" : "20675681",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cara Leopold",
      "screen_name" : "eltinfrance",
      "indices" : [ 0, 12 ],
      "id_str" : "721733786577276929",
      "id" : 721733786577276929
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "723175588089847809",
  "geo" : { },
  "id_str" : "723203500797104129",
  "in_reply_to_user_id" : 721733786577276929,
  "text" : "@eltinfrance purely holiday, a bit of elt only",
  "id" : 723203500797104129,
  "in_reply_to_status_id" : 723175588089847809,
  "created_at" : "2016-04-21 17:35:25 +0000",
  "in_reply_to_screen_name" : "eltinfrance",
  "in_reply_to_user_id_str" : "721733786577276929",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cara Leopold",
      "screen_name" : "eltinfrance",
      "indices" : [ 0, 12 ],
      "id_str" : "721733786577276929",
      "id" : 721733786577276929
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "723081635772522497",
  "geo" : { },
  "id_str" : "723086104434372608",
  "in_reply_to_user_id" : 721733786577276929,
  "text" : "@eltinfrance 3 weeks will be great only here for 10 days",
  "id" : 723086104434372608,
  "in_reply_to_status_id" : 723081635772522497,
  "created_at" : "2016-04-21 09:48:56 +0000",
  "in_reply_to_screen_name" : "eltinfrance",
  "in_reply_to_user_id_str" : "721733786577276929",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/723068117572685824\/photo\/1",
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/GhUy5xQALg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgjanAkUoAIkSnO.jpg",
      "id_str" : "723068103895064578",
      "id" : 723068103895064578,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgjanAkUoAIkSnO.jpg",
      "sizes" : [ {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1281
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/GhUy5xQALg"
    } ],
    "hashtags" : [ {
      "text" : "japon",
      "indices" : [ 94, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "723068117572685824",
  "text" : "To my non-Japanese ears the 2nd F of this nice alliterative attempt not sounding  quite right #japon : ) https:\/\/t.co\/GhUy5xQALg",
  "id" : 723068117572685824,
  "created_at" : "2016-04-21 08:37:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 100, 116 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/GRXxzPOCL0",
      "expanded_url" : "https:\/\/mathbabe.org\/2016\/04\/07\/ill-stop-calling-algorithms-racist-when-you-stop-anthropomorphizing-ai\/",
      "display_url" : "mathbabe.org\/2016\/04\/07\/ill\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "722990342899793920",
  "text" : "I'll stop calling algorithms racist when you stop anthropomorphizing AI https:\/\/t.co\/GRXxzPOCL0 via @wordpressdotcom",
  "id" : 722990342899793920,
  "created_at" : "2016-04-21 03:28:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frank Jania",
      "screen_name" : "fjania",
      "indices" : [ 3, 10 ],
      "id_str" : "797383",
      "id" : 797383
    }, {
      "name" : "Nathan Yau",
      "screen_name" : "flowingdata",
      "indices" : [ 12, 24 ],
      "id_str" : "14109167",
      "id" : 14109167
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/fjania\/status\/722860750553931776\/photo\/1",
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/SGKAa8cyqQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cggd_p_WQAAK1BK.png",
      "id_str" : "722860719633481728",
      "id" : 722860719633481728,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cggd_p_WQAAK1BK.png",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/SGKAa8cyqQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "722970936903770113",
  "text" : "RT @fjania: @flowingdata It\u2019s simple. https:\/\/t.co\/SGKAa8cyqQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nathan Yau",
        "screen_name" : "flowingdata",
        "indices" : [ 0, 12 ],
        "id_str" : "14109167",
        "id" : 14109167
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/fjania\/status\/722860750553931776\/photo\/1",
        "indices" : [ 26, 49 ],
        "url" : "https:\/\/t.co\/SGKAa8cyqQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cggd_p_WQAAK1BK.png",
        "id_str" : "722860719633481728",
        "id" : 722860719633481728,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cggd_p_WQAAK1BK.png",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/SGKAa8cyqQ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "722852407227473921",
    "geo" : { },
    "id_str" : "722860750553931776",
    "in_reply_to_user_id" : 14109167,
    "text" : "@flowingdata It\u2019s simple. https:\/\/t.co\/SGKAa8cyqQ",
    "id" : 722860750553931776,
    "in_reply_to_status_id" : 722852407227473921,
    "created_at" : "2016-04-20 18:53:27 +0000",
    "in_reply_to_screen_name" : "flowingdata",
    "in_reply_to_user_id_str" : "14109167",
    "user" : {
      "name" : "Frank Jania",
      "screen_name" : "fjania",
      "protected" : false,
      "id_str" : "797383",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744958179159777280\/rndeIWV1_normal.jpg",
      "id" : 797383,
      "verified" : false
    }
  },
  "id" : 722970936903770113,
  "created_at" : "2016-04-21 02:11:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamie C",
      "screen_name" : "timedingtable",
      "indices" : [ 0, 14 ],
      "id_str" : "2500889389",
      "id" : 2500889389
    }, {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 15, 30 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "722963900052856834",
  "geo" : { },
  "id_str" : "722965912962236416",
  "in_reply_to_user_id" : 2500889389,
  "text" : "@timedingtable @GeoffreyJordan great read as usual by Geoff",
  "id" : 722965912962236416,
  "in_reply_to_status_id" : 722963900052856834,
  "created_at" : "2016-04-21 01:51:20 +0000",
  "in_reply_to_screen_name" : "timedingtable",
  "in_reply_to_user_id_str" : "2500889389",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer MacDonald",
      "screen_name" : "JenMac_ESL",
      "indices" : [ 0, 11 ],
      "id_str" : "608800026",
      "id" : 608800026
    }, {
      "name" : "Scott Roy Douglas",
      "screen_name" : "scottroydouglas",
      "indices" : [ 12, 28 ],
      "id_str" : "1263168308",
      "id" : 1263168308
    }, {
      "name" : "Julie Moore",
      "screen_name" : "lexicojules",
      "indices" : [ 29, 41 ],
      "id_str" : "424320799",
      "id" : 424320799
    }, {
      "name" : "Gretchen McCulloch",
      "screen_name" : "GretchenAMcC",
      "indices" : [ 42, 55 ],
      "id_str" : "920491754",
      "id" : 920491754
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/XZOTydqGtK",
      "expanded_url" : "https:\/\/bridgingtheunbridgeable.com\/about\/",
      "display_url" : "bridgingtheunbridgeable.com\/about\/"
    } ]
  },
  "in_reply_to_status_id_str" : "722964697692155905",
  "geo" : { },
  "id_str" : "722965834491039748",
  "in_reply_to_user_id" : 608800026,
  "text" : "@JenMac_ESL @scottroydouglas @lexicojules @GretchenAMcC do u know this project https:\/\/t.co\/XZOTydqGtK ?",
  "id" : 722965834491039748,
  "in_reply_to_status_id" : 722964697692155905,
  "created_at" : "2016-04-21 01:51:01 +0000",
  "in_reply_to_screen_name" : "JenMac_ESL",
  "in_reply_to_user_id_str" : "608800026",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/medialens\/status\/722730530811297793\/photo\/1",
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/x3UhR1l6WB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgenlmzWQAAsv1C.jpg",
      "id_str" : "722730529729167360",
      "id" : 722730529729167360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgenlmzWQAAsv1C.jpg",
      "sizes" : [ {
        "h" : 408,
        "resize" : "fit",
        "w" : 807
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 303,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 172,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 408,
        "resize" : "fit",
        "w" : 807
      } ],
      "display_url" : "pic.twitter.com\/x3UhR1l6WB"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/DXhjc7dINc",
      "expanded_url" : "http:\/\/medialens.org\/index.php\/alerts\/alert-archive\/2016\/817-corbyn-s-millions-blair-s-millions.html",
      "display_url" : "medialens.org\/index.php\/aler\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "722961912187637760",
  "text" : "RT @medialens: Media Alert: Corbyn's Millions - Blair's Millions https:\/\/t.co\/DXhjc7dINc https:\/\/t.co\/x3UhR1l6WB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/medialens\/status\/722730530811297793\/photo\/1",
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/x3UhR1l6WB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CgenlmzWQAAsv1C.jpg",
        "id_str" : "722730529729167360",
        "id" : 722730529729167360,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgenlmzWQAAsv1C.jpg",
        "sizes" : [ {
          "h" : 408,
          "resize" : "fit",
          "w" : 807
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 303,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 172,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 408,
          "resize" : "fit",
          "w" : 807
        } ],
        "display_url" : "pic.twitter.com\/x3UhR1l6WB"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 73 ],
        "url" : "https:\/\/t.co\/DXhjc7dINc",
        "expanded_url" : "http:\/\/medialens.org\/index.php\/alerts\/alert-archive\/2016\/817-corbyn-s-millions-blair-s-millions.html",
        "display_url" : "medialens.org\/index.php\/aler\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "722730530811297793",
    "text" : "Media Alert: Corbyn's Millions - Blair's Millions https:\/\/t.co\/DXhjc7dINc https:\/\/t.co\/x3UhR1l6WB",
    "id" : 722730530811297793,
    "created_at" : "2016-04-20 10:16:00 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 722961912187637760,
  "created_at" : "2016-04-21 01:35:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 82, 97 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/o6KBmpl2Wv",
      "expanded_url" : "https:\/\/criticalelt.wordpress.com\/2016\/04\/20\/iatefl-2016-plenary-scott-thornbury-the-entertainer\/",
      "display_url" : "criticalelt.wordpress.com\/2016\/04\/20\/iat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "722956507189374976",
  "text" : "IATEFL 2016 Plenary. Scott Thornbury: The Entertainer https:\/\/t.co\/o6KBmpl2Wv via @GeoffreyJordan",
  "id" : 722956507189374976,
  "created_at" : "2016-04-21 01:13:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AllThingsLinguistic",
      "screen_name" : "AllThingsLing",
      "indices" : [ 3, 17 ],
      "id_str" : "857291268",
      "id" : 857291268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 140 ],
      "url" : "https:\/\/t.co\/tpzVUGhMIz",
      "expanded_url" : "https:\/\/tmblr.co\/ZuWOEv25JS6JY",
      "display_url" : "tmblr.co\/ZuWOEv25JS6JY"
    } ]
  },
  "geo" : { },
  "id_str" : "722954398830219264",
  "text" : "RT @AllThingsLing: How to remember the IPA consonant chart - keywords, mnemonics, and advice for practising the IPA... https:\/\/t.co\/tpzVUGh\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/tpzVUGhMIz",
        "expanded_url" : "https:\/\/tmblr.co\/ZuWOEv25JS6JY",
        "display_url" : "tmblr.co\/ZuWOEv25JS6JY"
      } ]
    },
    "geo" : { },
    "id_str" : "722915414456537088",
    "text" : "How to remember the IPA consonant chart - keywords, mnemonics, and advice for practising the IPA... https:\/\/t.co\/tpzVUGhMIz",
    "id" : 722915414456537088,
    "created_at" : "2016-04-20 22:30:40 +0000",
    "user" : {
      "name" : "AllThingsLinguistic",
      "screen_name" : "AllThingsLing",
      "protected" : false,
      "id_str" : "857291268",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750400997206454273\/N0DmrmFi_normal.jpg",
      "id" : 857291268,
      "verified" : false
    }
  },
  "id" : 722954398830219264,
  "created_at" : "2016-04-21 01:05:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "722943656995344384",
  "geo" : { },
  "id_str" : "722952571468455940",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler thanks Anne :\/)",
  "id" : 722952571468455940,
  "in_reply_to_status_id" : 722943656995344384,
  "created_at" : "2016-04-21 00:58:19 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer MacDonald",
      "screen_name" : "JenMac_ESL",
      "indices" : [ 0, 11 ],
      "id_str" : "608800026",
      "id" : 608800026
    }, {
      "name" : "Julie Moore",
      "screen_name" : "lexicojules",
      "indices" : [ 12, 24 ],
      "id_str" : "424320799",
      "id" : 424320799
    }, {
      "name" : "Gretchen McCulloch",
      "screen_name" : "GretchenAMcC",
      "indices" : [ 25, 38 ],
      "id_str" : "920491754",
      "id" : 920491754
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/YRCBIgkG1w",
      "expanded_url" : "http:\/\/scholarsarchive.byu.edu\/etd\/3986\/",
      "display_url" : "scholarsarchive.byu.edu\/etd\/3986\/"
    } ]
  },
  "in_reply_to_status_id_str" : "722888495673442304",
  "geo" : { },
  "id_str" : "722952503596158976",
  "in_reply_to_user_id" : 608800026,
  "text" : "@JenMac_ESL @lexicojules @GretchenAMcC the lit review here mentions some partial uses https:\/\/t.co\/YRCBIgkG1w",
  "id" : 722952503596158976,
  "in_reply_to_status_id" : 722888495673442304,
  "created_at" : "2016-04-21 00:58:03 +0000",
  "in_reply_to_screen_name" : "JenMac_ESL",
  "in_reply_to_user_id_str" : "608800026",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noor Adnan",
      "screen_name" : "n00rbaizura",
      "indices" : [ 0, 12 ],
      "id_str" : "412094121",
      "id" : 412094121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "722515871932026880",
  "geo" : { },
  "id_str" : "722587516700721152",
  "in_reply_to_user_id" : 412094121,
  "text" : "@n00rbaizura apparently!",
  "id" : 722587516700721152,
  "in_reply_to_status_id" : 722515871932026880,
  "created_at" : "2016-04-20 00:47:43 +0000",
  "in_reply_to_screen_name" : "n00rbaizura",
  "in_reply_to_user_id_str" : "412094121",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Jones",
      "screen_name" : "ELTResearch",
      "indices" : [ 0, 12 ],
      "id_str" : "3308043417",
      "id" : 3308043417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "722460009364393984",
  "geo" : { },
  "id_str" : "722587464573919232",
  "in_reply_to_user_id" : 3308043417,
  "text" : "@ELTResearch thanks!",
  "id" : 722587464573919232,
  "in_reply_to_status_id" : 722460009364393984,
  "created_at" : "2016-04-20 00:47:31 +0000",
  "in_reply_to_screen_name" : "ELTResearch",
  "in_reply_to_user_id_str" : "3308043417",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "722547053851619329",
  "geo" : { },
  "id_str" : "722587358084763648",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow yes too short but great natter thanks!",
  "id" : 722587358084763648,
  "in_reply_to_status_id" : 722547053851619329,
  "created_at" : "2016-04-20 00:47:05 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Apps 4 EFL",
      "screen_name" : "apps4efl",
      "indices" : [ 0, 9 ],
      "id_str" : "2594237072",
      "id" : 2594237072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "722560034257809408",
  "geo" : { },
  "id_str" : "722587233375490048",
  "in_reply_to_user_id" : 2594237072,
  "text" : "@apps4efl yes see u  in Tokyo : )",
  "id" : 722587233375490048,
  "in_reply_to_status_id" : 722560034257809408,
  "created_at" : "2016-04-20 00:46:36 +0000",
  "in_reply_to_screen_name" : "apps4efl",
  "in_reply_to_user_id_str" : "2594237072",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/irRScRuHsI",
      "expanded_url" : "https:\/\/www.routledge.com\/posts\/9632",
      "display_url" : "routledge.com\/posts\/9632"
    } ]
  },
  "geo" : { },
  "id_str" : "722459437957402624",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow here's link to that free eBook https:\/\/t.co\/irRScRuHsI",
  "id" : 722459437957402624,
  "created_at" : "2016-04-19 16:18:47 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 65, 76 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/722454337943810048\/photo\/1",
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/0AnnccG286",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgasYkJUIAEZ2Fr.jpg",
      "id_str" : "722454328259125249",
      "id" : 722454328259125249,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgasYkJUIAEZ2Fr.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/0AnnccG286"
    } ],
    "hashtags" : [ {
      "text" : "japon",
      "indices" : [ 77, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "722454337943810048",
  "text" : "Forgot what this hot plate dish is called but  a great choice by @kevchanwow #japon https:\/\/t.co\/0AnnccG286",
  "id" : 722454337943810048,
  "created_at" : "2016-04-19 15:58:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cara Leopold",
      "screen_name" : "eltinfrance",
      "indices" : [ 0, 12 ],
      "id_str" : "721733786577276929",
      "id" : 721733786577276929
    }, {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 13, 29 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "722435377059995652",
  "geo" : { },
  "id_str" : "722449594714460160",
  "in_reply_to_user_id" : 721733786577276929,
  "text" : "@eltinfrance @wordpressdotcom yr welcome nice blog : )",
  "id" : 722449594714460160,
  "in_reply_to_status_id" : 722435377059995652,
  "created_at" : "2016-04-19 15:39:40 +0000",
  "in_reply_to_screen_name" : "eltinfrance",
  "in_reply_to_user_id_str" : "721733786577276929",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 110, 126 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/GsF6oZpN7H",
      "expanded_url" : "https:\/\/eltinfrance.com\/2016\/03\/31\/why-all-freelance-efl-teachers-should-read-pricing-matters-by-janine-bray-mueller\/",
      "display_url" : "eltinfrance.com\/2016\/03\/31\/why\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "722382762229927937",
  "text" : "Why all freelance EFL teachers should read Pricing Matters by Janine Bray-Mueller https:\/\/t.co\/GsF6oZpN7H via @wordpressdotcom",
  "id" : 722382762229927937,
  "created_at" : "2016-04-19 11:14:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 125, 140 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/YJ6RemRSHy",
      "expanded_url" : "https:\/\/criticalelt.wordpress.com\/2016\/04\/19\/larsen-freemans-iatefl-2016-plenary-shifting-metaphors-from-computer-input-to-ecological-affordances\/",
      "display_url" : "criticalelt.wordpress.com\/2016\/04\/19\/lar\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "722379433407942658",
  "text" : "Larsen Freeman's IATEFL 2016 Plenary: Shifting metaphors from computer input to ecological affo\u2026 https:\/\/t.co\/YJ6RemRSHy via @GeoffreyJordan",
  "id" : 722379433407942658,
  "created_at" : "2016-04-19 11:00:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Brown",
      "screen_name" : "Za_Maikeru",
      "indices" : [ 57, 68 ],
      "id_str" : "703598479944208384",
      "id" : 703598479944208384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/1csAY2iYzg",
      "expanded_url" : "https:\/\/corpling4efl.wordpress.com\/2016\/04\/19\/skell-homonymy-and-polysemy\/",
      "display_url" : "corpling4efl.wordpress.com\/2016\/04\/19\/ske\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "722379044285644800",
  "text" : "SkELL: Homonymy and Polysemy https:\/\/t.co\/1csAY2iYzg via @Za_Maikeru",
  "id" : 722379044285644800,
  "created_at" : "2016-04-19 10:59:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Noble",
      "screen_name" : "tesolmatthew",
      "indices" : [ 0, 13 ],
      "id_str" : "1519875330",
      "id" : 1519875330
    }, {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 14, 25 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "regressive",
      "indices" : [ 65, 76 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "722260891849207808",
  "geo" : { },
  "id_str" : "722262021736009728",
  "in_reply_to_user_id" : 1519875330,
  "text" : "@tesolmatthew @hughdellar sorry I was being sardonic re hash tag #regressive I did put winky face : )",
  "id" : 722262021736009728,
  "in_reply_to_status_id" : 722260891849207808,
  "created_at" : "2016-04-19 03:14:19 +0000",
  "in_reply_to_screen_name" : "tesolmatthew",
  "in_reply_to_user_id_str" : "1519875330",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Noble",
      "screen_name" : "tesolmatthew",
      "indices" : [ 0, 13 ],
      "id_str" : "1519875330",
      "id" : 1519875330
    }, {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 14, 25 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "regressivecelta",
      "indices" : [ 52, 68 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "722202370017349635",
  "geo" : { },
  "id_str" : "722258527247446016",
  "in_reply_to_user_id" : 1519875330,
  "text" : "@tesolmatthew @hughdellar maybe need a hashtag like #regressivecelta? ; )",
  "id" : 722258527247446016,
  "in_reply_to_status_id" : 722202370017349635,
  "created_at" : "2016-04-19 03:00:26 +0000",
  "in_reply_to_screen_name" : "tesolmatthew",
  "in_reply_to_user_id_str" : "1519875330",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Guardian Australia",
      "screen_name" : "GuardianAus",
      "indices" : [ 3, 15 ],
      "id_str" : "1092378031",
      "id" : 1092378031
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/8k4XBZkNVk",
      "expanded_url" : "http:\/\/trib.al\/2gVSQQW",
      "display_url" : "trib.al\/2gVSQQW"
    } ]
  },
  "geo" : { },
  "id_str" : "722257997813014528",
  "text" : "RT @GuardianAus: Calling things Marxist is the new political correctness | First Dog on the Moon https:\/\/t.co\/8k4XBZkNVk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/8k4XBZkNVk",
        "expanded_url" : "http:\/\/trib.al\/2gVSQQW",
        "display_url" : "trib.al\/2gVSQQW"
      } ]
    },
    "geo" : { },
    "id_str" : "722232499603169280",
    "text" : "Calling things Marxist is the new political correctness | First Dog on the Moon https:\/\/t.co\/8k4XBZkNVk",
    "id" : 722232499603169280,
    "created_at" : "2016-04-19 01:17:00 +0000",
    "user" : {
      "name" : "Guardian Australia",
      "screen_name" : "GuardianAus",
      "protected" : false,
      "id_str" : "1092378031",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/759954899513675776\/DC_I4Vvt_normal.jpg",
      "id" : 1092378031,
      "verified" : true
    }
  },
  "id" : 722257997813014528,
  "created_at" : "2016-04-19 02:58:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Guardian Australia",
      "screen_name" : "GuardianAus",
      "indices" : [ 0, 12 ],
      "id_str" : "1092378031",
      "id" : 1092378031
    }, {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 13, 23 ],
      "id_str" : "525274103",
      "id" : 525274103
    }, {
      "name" : "The Guardian",
      "screen_name" : "guardian",
      "indices" : [ 24, 33 ],
      "id_str" : "87818409",
      "id" : 87818409
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "regressiveleft",
      "indices" : [ 52, 67 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "722232499603169280",
  "geo" : { },
  "id_str" : "722257934370013184",
  "in_reply_to_user_id" : 1092378031,
  "text" : "@GuardianAus @ElkySmith @guardian there is also the #regressiveleft variant",
  "id" : 722257934370013184,
  "in_reply_to_status_id" : 722232499603169280,
  "created_at" : "2016-04-19 02:58:05 +0000",
  "in_reply_to_screen_name" : "GuardianAus",
  "in_reply_to_user_id_str" : "1092378031",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greg Borenstein",
      "screen_name" : "atduskgreg",
      "indices" : [ 3, 14 ],
      "id_str" : "26853",
      "id" : 26853
    }, {
      "name" : "Fantastic Vocab",
      "screen_name" : "fantasticvocab",
      "indices" : [ 52, 67 ],
      "id_str" : "2819231208",
      "id" : 2819231208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/bBfzUo2Hhf",
      "expanded_url" : "http:\/\/www.fantasticvocab.com\/",
      "display_url" : "fantasticvocab.com"
    } ]
  },
  "geo" : { },
  "id_str" : "722183031201468417",
  "text" : "RT @atduskgreg: So I took the words generated by my @fantasticvocab bot and made them into a dictionary you can contribute to: https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Fantastic Vocab",
        "screen_name" : "fantasticvocab",
        "indices" : [ 36, 51 ],
        "id_str" : "2819231208",
        "id" : 2819231208
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/bBfzUo2Hhf",
        "expanded_url" : "http:\/\/www.fantasticvocab.com\/",
        "display_url" : "fantasticvocab.com"
      } ]
    },
    "geo" : { },
    "id_str" : "722129069832167425",
    "text" : "So I took the words generated by my @fantasticvocab bot and made them into a dictionary you can contribute to: https:\/\/t.co\/bBfzUo2Hhf",
    "id" : 722129069832167425,
    "created_at" : "2016-04-18 18:26:01 +0000",
    "user" : {
      "name" : "Greg Borenstein",
      "screen_name" : "atduskgreg",
      "protected" : false,
      "id_str" : "26853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/722894017818529793\/WKA4BzfG_normal.jpg",
      "id" : 26853,
      "verified" : false
    }
  },
  "id" : 722183031201468417,
  "created_at" : "2016-04-18 22:00:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/722179327081615360\/photo\/1",
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/hYA4syTKbF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgWyQf-UYAEGhgF.jpg",
      "id_str" : "722179311793364993",
      "id" : 722179311793364993,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgWyQf-UYAEGhgF.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 605,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/hYA4syTKbF"
    } ],
    "hashtags" : [ {
      "text" : "japon",
      "indices" : [ 52, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "722179327081615360",
  "text" : "I think I will wish for bumper (whisky) crops today #japon https:\/\/t.co\/hYA4syTKbF",
  "id" : 722179327081615360,
  "created_at" : "2016-04-18 21:45:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 69, 85 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/MmIEU7XClZ",
      "expanded_url" : "https:\/\/educationbookcast.com\/2016\/04\/18\/15-the-power-of-habit-by-charles-duhigg\/",
      "display_url" : "educationbookcast.com\/2016\/04\/18\/15-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "722174821434458112",
  "text" : "15. The Power of Habit by Charles Duhigg https:\/\/t.co\/MmIEU7XClZ via @wordpressdotcom",
  "id" : 722174821434458112,
  "created_at" : "2016-04-18 21:27:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patricia Brenes",
      "screen_name" : "patriciambr",
      "indices" : [ 0, 12 ],
      "id_str" : "35764443",
      "id" : 35764443
    }, {
      "name" : "Nat Leo",
      "screen_name" : "LogosNat",
      "indices" : [ 13, 22 ],
      "id_str" : "2520668425",
      "id" : 2520668425
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "722160995016302592",
  "geo" : { },
  "id_str" : "722173679535173632",
  "in_reply_to_user_id" : 35764443,
  "text" : "@patriciambr @LogosNat thanks for sharing :)",
  "id" : 722173679535173632,
  "in_reply_to_status_id" : 722160995016302592,
  "created_at" : "2016-04-18 21:23:17 +0000",
  "in_reply_to_screen_name" : "patriciambr",
  "in_reply_to_user_id_str" : "35764443",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sandy Millin",
      "screen_name" : "sandymillin",
      "indices" : [ 60, 72 ],
      "id_str" : "144236944",
      "id" : 144236944
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/Q5aDClPvPN",
      "expanded_url" : "https:\/\/sandymillin.wordpress.com\/2016\/04\/18\/iatefl2016corpora\/",
      "display_url" : "sandymillin.wordpress.com\/2016\/04\/18\/iat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "722172774773448705",
  "text" : "IATEFL Birmingham 2016: Corpora https:\/\/t.co\/Q5aDClPvPN via @sandymillin",
  "id" : 722172774773448705,
  "created_at" : "2016-04-18 21:19:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/LxceztCPIk",
      "expanded_url" : "http:\/\/www.rochester.edu\/newscenter\/conversations-on-linguistics-and-politics-with-noam-chomsky-152592\/#.VxVOu9Nh0u0.twitter",
      "display_url" : "rochester.edu\/newscenter\/con\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "722172065877340160",
  "text" : "Conversations on linguistics and politics with Noam Chomsky : NewsCenter https:\/\/t.co\/LxceztCPIk",
  "id" : 722172065877340160,
  "created_at" : "2016-04-18 21:16:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cara Leopold",
      "screen_name" : "eltinfrance",
      "indices" : [ 0, 12 ],
      "id_str" : "721733786577276929",
      "id" : 721733786577276929
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "722093993778114560",
  "geo" : { },
  "id_str" : "722096920097718272",
  "in_reply_to_user_id" : 721733786577276929,
  "text" : "@eltinfrance yes with the new video concordancing seems very attractive though I still have inertia &amp; stick with AntConc ; )",
  "id" : 722096920097718272,
  "in_reply_to_status_id" : 722093993778114560,
  "created_at" : "2016-04-18 16:18:16 +0000",
  "in_reply_to_screen_name" : "eltinfrance",
  "in_reply_to_user_id_str" : "721733786577276929",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/559WEk3wXn",
      "expanded_url" : "https:\/\/eflnotes.wordpress.com\/2016\/04\/18\/interview-with-mike-scott-wordsmith-tools-developer",
      "display_url" : "eflnotes.wordpress.com\/2016\/04\/18\/int\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "722092483165888513",
  "text" : "Interview with Mike Scott, WordSmith Tools developer https:\/\/t.co\/559WEk3wXn",
  "id" : 722092483165888513,
  "created_at" : "2016-04-18 16:00:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Chesnut",
      "screen_name" : "MichaelChesnut2",
      "indices" : [ 0, 16 ],
      "id_str" : "820940430",
      "id" : 820940430
    }, {
      "name" : "The Guardian",
      "screen_name" : "guardian",
      "indices" : [ 17, 26 ],
      "id_str" : "87818409",
      "id" : 87818409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "722012911665684482",
  "geo" : { },
  "id_str" : "722019172566192128",
  "in_reply_to_user_id" : 820940430,
  "text" : "@MichaelChesnut2 @guardian there are directories like yazikopen",
  "id" : 722019172566192128,
  "in_reply_to_status_id" : 722012911665684482,
  "created_at" : "2016-04-18 11:09:19 +0000",
  "in_reply_to_screen_name" : "MichaelChesnut2",
  "in_reply_to_user_id_str" : "820940430",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/etuX5OSxpF",
      "expanded_url" : "http:\/\/www.theguardian.com\/world\/2016\/apr\/18\/woman-makes-fake-fingers-yakuza-japan-reformed-gangsters",
      "display_url" : "theguardian.com\/world\/2016\/apr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "722016800553054208",
  "text" : "RT @pchallinor: I think somebody googled Fukushima and had a happy accident https:\/\/t.co\/etuX5OSxpF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/etuX5OSxpF",
        "expanded_url" : "http:\/\/www.theguardian.com\/world\/2016\/apr\/18\/woman-makes-fake-fingers-yakuza-japan-reformed-gangsters",
        "display_url" : "theguardian.com\/world\/2016\/apr\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "722014614591053824",
    "text" : "I think somebody googled Fukushima and had a happy accident https:\/\/t.co\/etuX5OSxpF",
    "id" : 722014614591053824,
    "created_at" : "2016-04-18 10:51:13 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 722016800553054208,
  "created_at" : "2016-04-18 10:59:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/722014260595785728\/photo\/1",
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/1vS7u4tHvH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgUcH3BUYAAI9J-.jpg",
      "id_str" : "722014236616974336",
      "id" : 722014236616974336,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgUcH3BUYAAI9J-.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1281
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/1vS7u4tHvH"
    } ],
    "hashtags" : [ {
      "text" : "Japon",
      "indices" : [ 43, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "722014260595785728",
  "text" : "Non-verbal entertainment show - intriguing #Japon https:\/\/t.co\/1vS7u4tHvH",
  "id" : 722014260595785728,
  "created_at" : "2016-04-18 10:49:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 91, 106 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/n1k1AD7mkW",
      "expanded_url" : "https:\/\/criticalelt.wordpress.com\/2016\/04\/17\/iatefl-2016-plenary-by-silvana-richardson-the-case-for-nnests\/",
      "display_url" : "criticalelt.wordpress.com\/2016\/04\/17\/iat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "721924209157378049",
  "text" : "IATEFL 2016 Plenary by Silvana Richardson: The Case for NNESTs https:\/\/t.co\/n1k1AD7mkW via @GeoffreyJordan",
  "id" : 721924209157378049,
  "created_at" : "2016-04-18 04:51:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/721581691597414402\/photo\/1",
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/RiPbGjmTMT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgOSY0IUYAAV5Xl.jpg",
      "id_str" : "721581320317460480",
      "id" : 721581320317460480,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgOSY0IUYAAV5Xl.jpg",
      "sizes" : [ {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1151
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1822,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 605,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1068,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/RiPbGjmTMT"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "721581691597414402",
  "text" : "Delayed train Bento https:\/\/t.co\/RiPbGjmTMT",
  "id" : 721581691597414402,
  "created_at" : "2016-04-17 06:10:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Parise",
      "screen_name" : "peterrenshu",
      "indices" : [ 0, 12 ],
      "id_str" : "631949549",
      "id" : 631949549
    }, {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 13, 29 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "721577537986428928",
  "geo" : { },
  "id_str" : "721578063885012993",
  "in_reply_to_user_id" : 631949549,
  "text" : "@peterrenshu @getgreatenglish thanks!",
  "id" : 721578063885012993,
  "in_reply_to_status_id" : 721577537986428928,
  "created_at" : "2016-04-17 05:56:31 +0000",
  "in_reply_to_screen_name" : "peterrenshu",
  "in_reply_to_user_id_str" : "631949549",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "721572044421238784",
  "geo" : { },
  "id_str" : "721572621620359168",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish arigato (^_^)",
  "id" : 721572621620359168,
  "in_reply_to_status_id" : 721572044421238784,
  "created_at" : "2016-04-17 05:34:53 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/721550561892380672\/video\/1",
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/mWA2pBLjcY",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/721549767071834112\/pu\/img\/IoLkBvC21zr_nde1.jpg",
      "id_str" : "721549767071834112",
      "id" : 721549767071834112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/721549767071834112\/pu\/img\/IoLkBvC21zr_nde1.jpg",
      "sizes" : [ {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/mWA2pBLjcY"
    } ],
    "hashtags" : [ {
      "text" : "Japon",
      "indices" : [ 24, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "721550561892380672",
  "text" : "Consonant cluster delay #Japon https:\/\/t.co\/mWA2pBLjcY",
  "id" : 721550561892380672,
  "created_at" : "2016-04-17 04:07:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Adele Soracco",
      "screen_name" : "LauraSoracco",
      "indices" : [ 0, 13 ],
      "id_str" : "15663328",
      "id" : 15663328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "721153871079313408",
  "geo" : { },
  "id_str" : "721347837213196288",
  "in_reply_to_user_id" : 15663328,
  "text" : "@LauraSoracco can you say pianoer? Pianoest? No? then noun",
  "id" : 721347837213196288,
  "in_reply_to_status_id" : 721153871079313408,
  "created_at" : "2016-04-16 14:41:41 +0000",
  "in_reply_to_screen_name" : "LauraSoracco",
  "in_reply_to_user_id_str" : "15663328",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer MacDonald",
      "screen_name" : "JenMac_ESL",
      "indices" : [ 0, 11 ],
      "id_str" : "608800026",
      "id" : 608800026
    }, {
      "name" : "Tim Knight",
      "screen_name" : "nakanotim",
      "indices" : [ 12, 22 ],
      "id_str" : "295968758",
      "id" : 295968758
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "721341719221026816",
  "geo" : { },
  "id_str" : "721342175892647937",
  "in_reply_to_user_id" : 608800026,
  "text" : "@JenMac_ESL @nakanotim he mentioned something to do with hydraulic jack I think",
  "id" : 721342175892647937,
  "in_reply_to_status_id" : 721341719221026816,
  "created_at" : "2016-04-16 14:19:11 +0000",
  "in_reply_to_screen_name" : "JenMac_ESL",
  "in_reply_to_user_id_str" : "608800026",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer MacDonald",
      "screen_name" : "JenMac_ESL",
      "indices" : [ 0, 11 ],
      "id_str" : "608800026",
      "id" : 608800026
    }, {
      "name" : "Tim Knight",
      "screen_name" : "nakanotim",
      "indices" : [ 12, 22 ],
      "id_str" : "295968758",
      "id" : 295968758
    }, {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 23, 39 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "721115298271739905",
  "geo" : { },
  "id_str" : "721337332708864001",
  "in_reply_to_user_id" : 608800026,
  "text" : "@JenMac_ESL @nakanotim @wordpressdotcom I tried the number &amp; got someone who was changing to summer tires from winter ones :)",
  "id" : 721337332708864001,
  "in_reply_to_status_id" : 721115298271739905,
  "created_at" : "2016-04-16 13:59:56 +0000",
  "in_reply_to_screen_name" : "JenMac_ESL",
  "in_reply_to_user_id_str" : "608800026",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jemima",
      "screen_name" : "Waitingirl13",
      "indices" : [ 63, 76 ],
      "id_str" : "1537344882",
      "id" : 1537344882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/DdbQL4zW3P",
      "expanded_url" : "https:\/\/sometimesitsjustacigar.wordpress.com\/2016\/04\/15\/i-dont-want-your-pity-stephen-fry\/",
      "display_url" : "sometimesitsjustacigar.wordpress.com\/2016\/04\/15\/i-d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "721315246225387520",
  "text" : "I dont want your pity Stephen Fry. https:\/\/t.co\/DdbQL4zW3P via @waitingirl13",
  "id" : 721315246225387520,
  "created_at" : "2016-04-16 12:32:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemma",
      "screen_name" : "GemmaELT",
      "indices" : [ 0, 9 ],
      "id_str" : "3380674715",
      "id" : 3380674715
    }, {
      "name" : "Helen Legge",
      "screen_name" : "ITLegge",
      "indices" : [ 10, 18 ],
      "id_str" : "2201561838",
      "id" : 2201561838
    }, {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 19, 30 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "721098949004759041",
  "geo" : { },
  "id_str" : "721313877644984320",
  "in_reply_to_user_id" : 3380674715,
  "text" : "@GemmaELT @ITLegge @hughdellar thx guys : )",
  "id" : 721313877644984320,
  "in_reply_to_status_id" : 721098949004759041,
  "created_at" : "2016-04-16 12:26:44 +0000",
  "in_reply_to_screen_name" : "GemmaELT",
  "in_reply_to_user_id_str" : "3380674715",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Eily Murphy",
      "screen_name" : "eilymurphy",
      "indices" : [ 10, 21 ],
      "id_str" : "111091623",
      "id" : 111091623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "721065690308825088",
  "geo" : { },
  "id_str" : "721311569724968960",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava @eilymurphy thx!",
  "id" : 721311569724968960,
  "in_reply_to_status_id" : 721065690308825088,
  "created_at" : "2016-04-16 12:17:34 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Natallia Novikava",
      "screen_name" : "Natashetta",
      "indices" : [ 0, 11 ],
      "id_str" : "56308635",
      "id" : 56308635
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "721284690888495106",
  "geo" : { },
  "id_str" : "721311433959555073",
  "in_reply_to_user_id" : 56308635,
  "text" : "@Natashetta thx!",
  "id" : 721311433959555073,
  "in_reply_to_status_id" : 721284690888495106,
  "created_at" : "2016-04-16 12:17:01 +0000",
  "in_reply_to_screen_name" : "Natashetta",
  "in_reply_to_user_id_str" : "56308635",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemma",
      "screen_name" : "GemmaELT",
      "indices" : [ 0, 9 ],
      "id_str" : "3380674715",
      "id" : 3380674715
    }, {
      "name" : "Sandy Millin",
      "screen_name" : "sandymillin",
      "indices" : [ 10, 22 ],
      "id_str" : "144236944",
      "id" : 144236944
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "721098949004759041",
  "geo" : { },
  "id_str" : "721311391446102018",
  "in_reply_to_user_id" : 3380674715,
  "text" : "@GemmaELT @sandymillin thx  for yr brill corpus tweeting Sandy :)",
  "id" : 721311391446102018,
  "in_reply_to_status_id" : 721098949004759041,
  "created_at" : "2016-04-16 12:16:51 +0000",
  "in_reply_to_screen_name" : "GemmaELT",
  "in_reply_to_user_id_str" : "3380674715",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "indices" : [ 10, 20 ],
      "id_str" : "577931950",
      "id" : 577931950
    }, {
      "name" : "Barbara Anna",
      "screen_name" : "bar_zie",
      "indices" : [ 21, 29 ],
      "id_str" : "2231464708",
      "id" : 2231464708
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "721065690308825088",
  "geo" : { },
  "id_str" : "721311040911380480",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava @RudyLoock @bar_zie thx!",
  "id" : 721311040911380480,
  "in_reply_to_status_id" : 721065690308825088,
  "created_at" : "2016-04-16 12:15:28 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemma",
      "screen_name" : "GemmaELT",
      "indices" : [ 0, 9 ],
      "id_str" : "3380674715",
      "id" : 3380674715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "721098834198335490",
  "geo" : { },
  "id_str" : "721205828645203969",
  "in_reply_to_user_id" : 3380674715,
  "text" : "@GemmaELT cheers Gemma : )",
  "id" : 721205828645203969,
  "in_reply_to_status_id" : 721098834198335490,
  "created_at" : "2016-04-16 05:17:23 +0000",
  "in_reply_to_screen_name" : "GemmaELT",
  "in_reply_to_user_id_str" : "3380674715",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemma",
      "screen_name" : "GemmaELT",
      "indices" : [ 0, 9 ],
      "id_str" : "3380674715",
      "id" : 3380674715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "721098949004759041",
  "geo" : { },
  "id_str" : "721205775511744512",
  "in_reply_to_user_id" : 3380674715,
  "text" : "@GemmaELT thx : )",
  "id" : 721205775511744512,
  "in_reply_to_status_id" : 721098949004759041,
  "created_at" : "2016-04-16 05:17:10 +0000",
  "in_reply_to_screen_name" : "GemmaELT",
  "in_reply_to_user_id_str" : "3380674715",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemma",
      "screen_name" : "GemmaELT",
      "indices" : [ 0, 9 ],
      "id_str" : "3380674715",
      "id" : 3380674715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "721099183168614401",
  "geo" : { },
  "id_str" : "721205724026695680",
  "in_reply_to_user_id" : 3380674715,
  "text" : "@GemmaELT ta!",
  "id" : 721205724026695680,
  "in_reply_to_status_id" : 721099183168614401,
  "created_at" : "2016-04-16 05:16:58 +0000",
  "in_reply_to_screen_name" : "GemmaELT",
  "in_reply_to_user_id_str" : "3380674715",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemma",
      "screen_name" : "GemmaELT",
      "indices" : [ 0, 9 ],
      "id_str" : "3380674715",
      "id" : 3380674715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "721099329201696769",
  "geo" : { },
  "id_str" : "721205679193767937",
  "in_reply_to_user_id" : 3380674715,
  "text" : "@GemmaELT cheers : )",
  "id" : 721205679193767937,
  "in_reply_to_status_id" : 721099329201696769,
  "created_at" : "2016-04-16 05:16:47 +0000",
  "in_reply_to_screen_name" : "GemmaELT",
  "in_reply_to_user_id_str" : "3380674715",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "721173307333025793",
  "geo" : { },
  "id_str" : "721205638764826624",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler thanks : )",
  "id" : 721205638764826624,
  "in_reply_to_status_id" : 721173307333025793,
  "created_at" : "2016-04-16 05:16:38 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Chris Jones",
      "screen_name" : "ELTResearch",
      "indices" : [ 10, 22 ],
      "id_str" : "3308043417",
      "id" : 3308043417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "721065690308825088",
  "geo" : { },
  "id_str" : "721097406906019840",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava @ELTResearch thanks for RT : )",
  "id" : 721097406906019840,
  "in_reply_to_status_id" : 721065690308825088,
  "created_at" : "2016-04-15 22:06:33 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/721065690308825088\/photo\/1",
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/5FNVgZ8Alq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgG9bINUIAA_pH4.jpg",
      "id_str" : "721065689113436160",
      "id" : 721065689113436160,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgG9bINUIAA_pH4.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/5FNVgZ8Alq"
    } ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/KSyEuxSGJF",
      "expanded_url" : "https:\/\/eflnotes.wordpress.com\/2016\/04\/15\/iatefl-2016-corpus-tweets-4\/",
      "display_url" : "eflnotes.wordpress.com\/2016\/04\/15\/iat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "721065690308825088",
  "text" : "#IATEFL 2016 - Corpus Tweets 4 https:\/\/t.co\/KSyEuxSGJF https:\/\/t.co\/5FNVgZ8Alq",
  "id" : 721065690308825088,
  "created_at" : "2016-04-15 20:00:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 10, 26 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720700011248377856",
  "geo" : { },
  "id_str" : "721030587377717248",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava @getgreatenglish ta bud!",
  "id" : 721030587377717248,
  "in_reply_to_status_id" : 720700011248377856,
  "created_at" : "2016-04-15 17:41:02 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720816585032617984",
  "geo" : { },
  "id_str" : "721030504565383170",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler cheers!",
  "id" : 721030504565383170,
  "in_reply_to_status_id" : 720816585032617984,
  "created_at" : "2016-04-15 17:40:43 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720815862379204609",
  "geo" : { },
  "id_str" : "721030473577807872",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler thanks Anne : )",
  "id" : 721030473577807872,
  "in_reply_to_status_id" : 720815862379204609,
  "created_at" : "2016-04-15 17:40:35 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "indices" : [ 10, 20 ],
      "id_str" : "577931950",
      "id" : 577931950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720700011248377856",
  "geo" : { },
  "id_str" : "720954098661638144",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava @RudyLoock merci :)",
  "id" : 720954098661638144,
  "in_reply_to_status_id" : 720700011248377856,
  "created_at" : "2016-04-15 12:37:06 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Carr",
      "screen_name" : "MattCarr55",
      "indices" : [ 56, 67 ],
      "id_str" : "288409122",
      "id" : 288409122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/dehDbx6DtO",
      "expanded_url" : "http:\/\/infernalmachine.co.uk\/the-world-according-to-bono\/",
      "display_url" : "infernalmachine.co.uk\/the-world-acco\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "720953680514662401",
  "text" : "The World According to Bono https:\/\/t.co\/dehDbx6DtO via @MattCarr55",
  "id" : 720953680514662401,
  "created_at" : "2016-04-15 12:35:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 3, 12 ],
      "id_str" : "134211317",
      "id" : 134211317
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/josipa74\/status\/720766725768159232\/photo\/1",
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/oMrGwmc8eL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgCthF7WQAQ5_Ur.jpg",
      "id_str" : "720766724417667076",
      "id" : 720766724417667076,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgCthF7WQAQ5_Ur.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/oMrGwmc8eL"
    } ],
    "hashtags" : [ {
      "text" : "iatefl2016",
      "indices" : [ 54, 65 ]
    }, {
      "text" : "IATEFL",
      "indices" : [ 66, 73 ]
    }, {
      "text" : "elt",
      "indices" : [ 74, 78 ]
    }, {
      "text" : "esl",
      "indices" : [ 79, 83 ]
    }, {
      "text" : "efl",
      "indices" : [ 84, 88 ]
    }, {
      "text" : "tefl",
      "indices" : [ 89, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720953307745923074",
  "text" : "RT @josipa74: Sue Lawley speaks on working conditions #iatefl2016 #IATEFL #elt #esl #efl #tefl https:\/\/t.co\/oMrGwmc8eL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/josipa74\/status\/720766725768159232\/photo\/1",
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/oMrGwmc8eL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CgCthF7WQAQ5_Ur.jpg",
        "id_str" : "720766724417667076",
        "id" : 720766724417667076,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgCthF7WQAQ5_Ur.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/oMrGwmc8eL"
      } ],
      "hashtags" : [ {
        "text" : "iatefl2016",
        "indices" : [ 40, 51 ]
      }, {
        "text" : "IATEFL",
        "indices" : [ 52, 59 ]
      }, {
        "text" : "elt",
        "indices" : [ 60, 64 ]
      }, {
        "text" : "esl",
        "indices" : [ 65, 69 ]
      }, {
        "text" : "efl",
        "indices" : [ 70, 74 ]
      }, {
        "text" : "tefl",
        "indices" : [ 75, 80 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "720766725768159232",
    "text" : "Sue Lawley speaks on working conditions #iatefl2016 #IATEFL #elt #esl #efl #tefl https:\/\/t.co\/oMrGwmc8eL",
    "id" : 720766725768159232,
    "created_at" : "2016-04-15 00:12:33 +0000",
    "user" : {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "protected" : false,
      "id_str" : "134211317",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/526853654377021441\/MtEFhYIs_normal.jpeg",
      "id" : 134211317,
      "verified" : false
    }
  },
  "id" : 720953307745923074,
  "created_at" : "2016-04-15 12:33:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Raf",
      "screen_name" : "1Rafz",
      "indices" : [ 3, 9 ],
      "id_str" : "2889040021",
      "id" : 2889040021
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whatbritishmuslimsreallythink",
      "indices" : [ 119, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720727995539984384",
  "text" : "RT @1Rafz: Muslims believe Zayn Malik was a fundamental pillar of 1D. Without him, they're just four moody white boys. #whatbritishmuslimsr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whatbritishmuslimsreallythink",
        "indices" : [ 108, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "720384003359051776",
    "text" : "Muslims believe Zayn Malik was a fundamental pillar of 1D. Without him, they're just four moody white boys. #whatbritishmuslimsreallythink",
    "id" : 720384003359051776,
    "created_at" : "2016-04-13 22:51:45 +0000",
    "user" : {
      "name" : "Raf",
      "screen_name" : "1Rafz",
      "protected" : false,
      "id_str" : "2889040021",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/726438942132809731\/2nTD0sEz_normal.jpg",
      "id" : 2889040021,
      "verified" : false
    }
  },
  "id" : 720727995539984384,
  "created_at" : "2016-04-14 21:38:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ifhat smith",
      "screen_name" : "issmith3",
      "indices" : [ 3, 12 ],
      "id_str" : "1956403670",
      "id" : 1956403670
    }, {
      "name" : "Raf",
      "screen_name" : "1Rafz",
      "indices" : [ 57, 63 ],
      "id_str" : "2889040021",
      "id" : 2889040021
    }, {
      "name" : "Channel 4",
      "screen_name" : "Channel4",
      "indices" : [ 97, 106 ],
      "id_str" : "183585551",
      "id" : 183585551
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WhatMuslimsReallyThink",
      "indices" : [ 107, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/b6FeCa9x71",
      "expanded_url" : "https:\/\/twitter.com\/crookedrib\/status\/720702676762279936",
      "display_url" : "twitter.com\/crookedrib\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "720726824020525056",
  "text" : "RT @issmith3: very good analysis, a good read, thanks at @1Rafz for challenging the islamophobia @Channel4 #WhatMuslimsReallyThink https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Raf",
        "screen_name" : "1Rafz",
        "indices" : [ 43, 49 ],
        "id_str" : "2889040021",
        "id" : 2889040021
      }, {
        "name" : "Channel 4",
        "screen_name" : "Channel4",
        "indices" : [ 83, 92 ],
        "id_str" : "183585551",
        "id" : 183585551
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WhatMuslimsReallyThink",
        "indices" : [ 93, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/b6FeCa9x71",
        "expanded_url" : "https:\/\/twitter.com\/crookedrib\/status\/720702676762279936",
        "display_url" : "twitter.com\/crookedrib\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "720720184466612227",
    "text" : "very good analysis, a good read, thanks at @1Rafz for challenging the islamophobia @Channel4 #WhatMuslimsReallyThink https:\/\/t.co\/b6FeCa9x71",
    "id" : 720720184466612227,
    "created_at" : "2016-04-14 21:07:36 +0000",
    "user" : {
      "name" : "ifhat smith",
      "screen_name" : "issmith3",
      "protected" : false,
      "id_str" : "1956403670",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/550437644782403585\/1nC1T__x_normal.jpeg",
      "id" : 1956403670,
      "verified" : false
    }
  },
  "id" : 720726824020525056,
  "created_at" : "2016-04-14 21:33:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Magnus Nissel",
      "screen_name" : "u203d",
      "indices" : [ 0, 6 ],
      "id_str" : "533114985",
      "id" : 533114985
    }, {
      "name" : "SwiftOnSecurity",
      "screen_name" : "SwiftOnSecurity",
      "indices" : [ 7, 23 ],
      "id_str" : "2436389418",
      "id" : 2436389418
    }, {
      "name" : "James Harbeck",
      "screen_name" : "sesquiotic",
      "indices" : [ 24, 35 ],
      "id_str" : "325005504",
      "id" : 325005504
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720716541390663680",
  "geo" : { },
  "id_str" : "720719926990938112",
  "in_reply_to_user_id" : 533114985,
  "text" : "@u203d @SwiftOnSecurity @sesquiotic bloody hell poor bugger",
  "id" : 720719926990938112,
  "in_reply_to_status_id" : 720716541390663680,
  "created_at" : "2016-04-14 21:06:35 +0000",
  "in_reply_to_screen_name" : "u203d",
  "in_reply_to_user_id_str" : "533114985",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lizzie Pinard",
      "screen_name" : "LizziePinard",
      "indices" : [ 127, 140 ],
      "id_str" : "287093748",
      "id" : 287093748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/AyfIgqHmnY",
      "expanded_url" : "https:\/\/reflectiveteachingreflectivelearning.com\/2016\/04\/14\/iatefl-2016-tackling-native-speakerism-marek-kiczkowiak-burcu-akyol-christopher-graham-josh-round\/",
      "display_url" : "\u2026lectiveteachingreflectivelearning.com\/2016\/04\/14\/iat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "720717794485137409",
  "text" : "IATEFL 2016 Tackling Native Speakerism (Marek Kiczkowiak, Burcu Akyol, Christopher Graham, Josh R\u2026 https:\/\/t.co\/AyfIgqHmnY via @lizziepinard",
  "id" : 720717794485137409,
  "created_at" : "2016-04-14 20:58:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 63, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/y7ziUxIzSX",
      "expanded_url" : "http:\/\/www.speechinaction.org\/blog\/listening-cherry-20-of-mush-and-mess\/",
      "display_url" : "speechinaction.org\/blog\/listening\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "720714018311303168",
  "text" : "Listening Cherry 20 \u2013 Of mush and mess\nhttps:\/\/t.co\/y7ziUxIzSX #IATEFL",
  "id" : 720714018311303168,
  "created_at" : "2016-04-14 20:43:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Divya Madhavan",
      "screen_name" : "_divyamadhavan",
      "indices" : [ 10, 25 ],
      "id_str" : "408492806",
      "id" : 408492806
    }, {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "indices" : [ 26, 36 ],
      "id_str" : "577931950",
      "id" : 577931950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720673577482059776",
  "geo" : { },
  "id_str" : "720701207950528513",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava @_divyamadhavan @RudyLoock thanks guys!",
  "id" : 720701207950528513,
  "in_reply_to_status_id" : 720673577482059776,
  "created_at" : "2016-04-14 19:52:12 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/67ZVH8l8JQ",
      "expanded_url" : "https:\/\/eflnotes.wordpress.com\/2016\/04\/14\/iatefl-2016-corpus-tweets-3\/",
      "display_url" : "eflnotes.wordpress.com\/2016\/04\/14\/iat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "720700011248377856",
  "text" : "#IATEFL Corpus Tweets 3 https:\/\/t.co\/67ZVH8l8JQ",
  "id" : 720700011248377856,
  "created_at" : "2016-04-14 19:47:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/N7OYO1RU16",
      "expanded_url" : "https:\/\/eflnotes.wordpress.com\/2016\/04\/14\/iatefl-2016-corpus-tweets-2\/",
      "display_url" : "eflnotes.wordpress.com\/2016\/04\/14\/iat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "720673577482059776",
  "text" : "#IATEFL 2016 - Corpus Tweets 2 https:\/\/t.co\/N7OYO1RU16",
  "id" : 720673577482059776,
  "created_at" : "2016-04-14 18:02:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 3, 12 ],
      "id_str" : "134211317",
      "id" : 134211317
    }, {
      "name" : "Anthony Ash FRSA",
      "screen_name" : "Ashowski",
      "indices" : [ 14, 23 ],
      "id_str" : "316596356",
      "id" : 316596356
    }, {
      "name" : "James Pengelley",
      "screen_name" : "HairyChef",
      "indices" : [ 24, 34 ],
      "id_str" : "616576518",
      "id" : 616576518
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720622904422043648",
  "text" : "RT @josipa74: @Ashowski @HairyChef 'Without any money, teachers will leave the profession.'",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anthony Ash FRSA",
        "screen_name" : "Ashowski",
        "indices" : [ 0, 9 ],
        "id_str" : "316596356",
        "id" : 316596356
      }, {
        "name" : "James Pengelley",
        "screen_name" : "HairyChef",
        "indices" : [ 10, 20 ],
        "id_str" : "616576518",
        "id" : 616576518
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "720618119635562496",
    "geo" : { },
    "id_str" : "720622354473295873",
    "in_reply_to_user_id" : 316596356,
    "text" : "@Ashowski @HairyChef 'Without any money, teachers will leave the profession.'",
    "id" : 720622354473295873,
    "in_reply_to_status_id" : 720618119635562496,
    "created_at" : "2016-04-14 14:38:52 +0000",
    "in_reply_to_screen_name" : "Ashowski",
    "in_reply_to_user_id_str" : "316596356",
    "user" : {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "protected" : false,
      "id_str" : "134211317",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/526853654377021441\/MtEFhYIs_normal.jpeg",
      "id" : 134211317,
      "verified" : false
    }
  },
  "id" : 720622904422043648,
  "created_at" : "2016-04-14 14:41:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Ash FRSA",
      "screen_name" : "Ashowski",
      "indices" : [ 0, 9 ],
      "id_str" : "316596356",
      "id" : 316596356
    }, {
      "name" : "Chris Jones",
      "screen_name" : "ELTResearch",
      "indices" : [ 10, 22 ],
      "id_str" : "3308043417",
      "id" : 3308043417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720614744999202816",
  "geo" : { },
  "id_str" : "720615576360591360",
  "in_reply_to_user_id" : 316596356,
  "text" : "@Ashowski @ELTResearch oh ok nevermind me then : )",
  "id" : 720615576360591360,
  "in_reply_to_status_id" : 720614744999202816,
  "created_at" : "2016-04-14 14:11:56 +0000",
  "in_reply_to_screen_name" : "Ashowski",
  "in_reply_to_user_id_str" : "316596356",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Ash FRSA",
      "screen_name" : "Ashowski",
      "indices" : [ 0, 9 ],
      "id_str" : "316596356",
      "id" : 316596356
    }, {
      "name" : "Chris Jones",
      "screen_name" : "ELTResearch",
      "indices" : [ 10, 22 ],
      "id_str" : "3308043417",
      "id" : 3308043417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/rtaMSZxyEm",
      "expanded_url" : "http:\/\/www.ncbi.nlm.nih.gov\/pmc\/articles\/PMC3153823\/",
      "display_url" : "ncbi.nlm.nih.gov\/pmc\/articles\/P\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "720613537303957504",
  "geo" : { },
  "id_str" : "720614397006192640",
  "in_reply_to_user_id" : 316596356,
  "text" : "@Ashowski @ELTResearch it's funny subs can account for reading performance better than speech corpora! e.g https:\/\/t.co\/rtaMSZxyEm",
  "id" : 720614397006192640,
  "in_reply_to_status_id" : 720613537303957504,
  "created_at" : "2016-04-14 14:07:15 +0000",
  "in_reply_to_screen_name" : "Ashowski",
  "in_reply_to_user_id_str" : "316596356",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Ash FRSA",
      "screen_name" : "Ashowski",
      "indices" : [ 0, 9 ],
      "id_str" : "316596356",
      "id" : 316596356
    }, {
      "name" : "Chris Jones",
      "screen_name" : "ELTResearch",
      "indices" : [ 10, 22 ],
      "id_str" : "3308043417",
      "id" : 3308043417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720611965987594240",
  "geo" : { },
  "id_str" : "720613208097189888",
  "in_reply_to_user_id" : 316596356,
  "text" : "@Ashowski @ELTResearch sorry don't understand question?",
  "id" : 720613208097189888,
  "in_reply_to_status_id" : 720611965987594240,
  "created_at" : "2016-04-14 14:02:31 +0000",
  "in_reply_to_screen_name" : "Ashowski",
  "in_reply_to_user_id_str" : "316596356",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Jones",
      "screen_name" : "ELTResearch",
      "indices" : [ 0, 12 ],
      "id_str" : "3308043417",
      "id" : 3308043417
    }, {
      "name" : "Anthony Ash FRSA",
      "screen_name" : "Ashowski",
      "indices" : [ 13, 22 ],
      "id_str" : "316596356",
      "id" : 316596356
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720609495865520128",
  "geo" : { },
  "id_str" : "720611625196199936",
  "in_reply_to_user_id" : 3308043417,
  "text" : "@ELTResearch @Ashowski subtitles found to reflect conversation quite well",
  "id" : 720611625196199936,
  "in_reply_to_status_id" : 720609495865520128,
  "created_at" : "2016-04-14 13:56:14 +0000",
  "in_reply_to_screen_name" : "ELTResearch",
  "in_reply_to_user_id_str" : "3308043417",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patricia Brenes",
      "screen_name" : "patriciambr",
      "indices" : [ 0, 12 ],
      "id_str" : "35764443",
      "id" : 35764443
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720607002200825856",
  "geo" : { },
  "id_str" : "720608761912668160",
  "in_reply_to_user_id" : 35764443,
  "text" : "@patriciambr thanks Patricia : )",
  "id" : 720608761912668160,
  "in_reply_to_status_id" : 720607002200825856,
  "created_at" : "2016-04-14 13:44:51 +0000",
  "in_reply_to_screen_name" : "patriciambr",
  "in_reply_to_user_id_str" : "35764443",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720605333782040576",
  "geo" : { },
  "id_str" : "720606691298033664",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish ok fair enough : )",
  "id" : 720606691298033664,
  "in_reply_to_status_id" : 720605333782040576,
  "created_at" : "2016-04-14 13:36:38 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "macmillanelt",
      "screen_name" : "MacmillanELT",
      "indices" : [ 0, 13 ],
      "id_str" : "16294897",
      "id" : 16294897
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 74, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/feVV1F8lKr",
      "expanded_url" : "http:\/\/phave-dictionary.englishup.me\/",
      "display_url" : "phave-dictionary.englishup.me"
    } ]
  },
  "in_reply_to_status_id_str" : "720581806857314304",
  "geo" : { },
  "id_str" : "720605522173550593",
  "in_reply_to_user_id" : 16294897,
  "text" : "@MacmillanELT PHaVE dictionary can help with this https:\/\/t.co\/feVV1F8lKr #IATEFL",
  "id" : 720605522173550593,
  "in_reply_to_status_id" : 720581806857314304,
  "created_at" : "2016-04-14 13:31:59 +0000",
  "in_reply_to_screen_name" : "MacmillanELT",
  "in_reply_to_user_id_str" : "16294897",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720604585711120384",
  "geo" : { },
  "id_str" : "720605110057975808",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish what u doing on twitter?! git going : )",
  "id" : 720605110057975808,
  "in_reply_to_status_id" : 720604585711120384,
  "created_at" : "2016-04-14 13:30:21 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jo Sayers",
      "screen_name" : "jo_sayers",
      "indices" : [ 0, 10 ],
      "id_str" : "87176766",
      "id" : 87176766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720604038623010816",
  "geo" : { },
  "id_str" : "720604200149872642",
  "in_reply_to_user_id" : 87176766,
  "text" : "@jo_sayers that's very 21st century of you : )",
  "id" : 720604200149872642,
  "in_reply_to_status_id" : 720604038623010816,
  "created_at" : "2016-04-14 13:26:44 +0000",
  "in_reply_to_screen_name" : "jo_sayers",
  "in_reply_to_user_id_str" : "87176766",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    }, {
      "name" : "Sandy Millin",
      "screen_name" : "sandymillin",
      "indices" : [ 17, 29 ],
      "id_str" : "144236944",
      "id" : 144236944
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720599673275219970",
  "geo" : { },
  "id_str" : "720604042628620289",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish @sandymillin thx Marc",
  "id" : 720604042628620289,
  "in_reply_to_status_id" : 720599673275219970,
  "created_at" : "2016-04-14 13:26:06 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cambridge ELT",
      "screen_name" : "CambridgeUPELT",
      "indices" : [ 0, 15 ],
      "id_str" : "73107903",
      "id" : 73107903
    }, {
      "name" : "TEFLAnneOKeeffe",
      "screen_name" : "TEFLclass",
      "indices" : [ 16, 26 ],
      "id_str" : "469244585",
      "id" : 469244585
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 95, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/S8Glp9TVkS",
      "expanded_url" : "https:\/\/eflnotes.wordpress.com\/2013\/09\/19\/counting-countability-efcamdat\/",
      "display_url" : "eflnotes.wordpress.com\/2013\/09\/19\/cou\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "720580669332656128",
  "geo" : { },
  "id_str" : "720603097383485440",
  "in_reply_to_user_id" : 73107903,
  "text" : "@CambridgeUPELT @TEFLclass EFCAMDAT data for Fr learners shows similar https:\/\/t.co\/S8Glp9TVkS #IATEFL",
  "id" : 720603097383485440,
  "in_reply_to_status_id" : 720580669332656128,
  "created_at" : "2016-04-14 13:22:21 +0000",
  "in_reply_to_screen_name" : "CambridgeUPELT",
  "in_reply_to_user_id_str" : "73107903",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TEFLology Podcast",
      "screen_name" : "TEFLology",
      "indices" : [ 87, 97 ],
      "id_str" : "2882870444",
      "id" : 2882870444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/TLOQRXD3oJ",
      "expanded_url" : "https:\/\/teflology-podcast.com\/2016\/04\/13\/tefl-interviews-19-batia-laufer-on-vocabulary-acquisition\/",
      "display_url" : "teflology-podcast.com\/2016\/04\/13\/tef\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "720600469937201158",
  "text" : "TEFL Interviews 19: Batia Laufer on Vocabulary Acquisition https:\/\/t.co\/TLOQRXD3oJ via @TEFLology",
  "id" : 720600469937201158,
  "created_at" : "2016-04-14 13:11:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Patsko",
      "screen_name" : "lauraahaha",
      "indices" : [ 0, 11 ],
      "id_str" : "97957137",
      "id" : 97957137
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 71, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/28IIB1vgHW",
      "expanded_url" : "http:\/\/yohasebe.com\/tcse",
      "display_url" : "yohasebe.com\/tcse"
    } ]
  },
  "in_reply_to_status_id_str" : "720581581161803777",
  "geo" : { },
  "id_str" : "720588842944884737",
  "in_reply_to_user_id" : 97957137,
  "text" : "@lauraahaha TED Corpus Search Engine is useful https:\/\/t.co\/28IIB1vgHW #IATEFL",
  "id" : 720588842944884737,
  "in_reply_to_status_id" : 720581581161803777,
  "created_at" : "2016-04-14 12:25:42 +0000",
  "in_reply_to_screen_name" : "lauraahaha",
  "in_reply_to_user_id_str" : "97957137",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rafiiiiii",
      "screen_name" : "rafialarm",
      "indices" : [ 3, 13 ],
      "id_str" : "7635732",
      "id" : 7635732
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/rafialarm\/status\/720200513975746561\/photo\/1",
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/VvxLSFdnvv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cf6qjNvUkAA2P9E.jpg",
      "id_str" : "720200512386142208",
      "id" : 720200512386142208,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cf6qjNvUkAA2P9E.jpg",
      "sizes" : [ {
        "h" : 288,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 163,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 491,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 563,
        "resize" : "fit",
        "w" : 1174
      } ],
      "display_url" : "pic.twitter.com\/VvxLSFdnvv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720585100140900352",
  "text" : "RT @rafialarm: William and Kate visit India https:\/\/t.co\/VvxLSFdnvv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/rafialarm\/status\/720200513975746561\/photo\/1",
        "indices" : [ 29, 52 ],
        "url" : "https:\/\/t.co\/VvxLSFdnvv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cf6qjNvUkAA2P9E.jpg",
        "id_str" : "720200512386142208",
        "id" : 720200512386142208,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cf6qjNvUkAA2P9E.jpg",
        "sizes" : [ {
          "h" : 288,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 163,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 491,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 563,
          "resize" : "fit",
          "w" : 1174
        } ],
        "display_url" : "pic.twitter.com\/VvxLSFdnvv"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "720200513975746561",
    "text" : "William and Kate visit India https:\/\/t.co\/VvxLSFdnvv",
    "id" : 720200513975746561,
    "created_at" : "2016-04-13 10:42:37 +0000",
    "user" : {
      "name" : "rafiiiiii",
      "screen_name" : "rafialarm",
      "protected" : false,
      "id_str" : "7635732",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/698177500875087872\/mtbyEO5a_normal.jpg",
      "id" : 7635732,
      "verified" : false
    }
  },
  "id" : 720585100140900352,
  "created_at" : "2016-04-14 12:10:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 84, 100 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/l0ulYeGUi6",
      "expanded_url" : "https:\/\/historicalchaos.wordpress.com\/2016\/04\/14\/the-dogs-bark-but-the-caravan-goes-by-orwell-and-zizek\/",
      "display_url" : "historicalchaos.wordpress.com\/2016\/04\/14\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "720584365756063744",
  "text" : "The dogs bark and the caravan goes by: Orwell and \u017Di\u017Eek https:\/\/t.co\/l0ulYeGUi6 via @wordpressdotcom",
  "id" : 720584365756063744,
  "created_at" : "2016-04-14 12:07:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Moore",
      "screen_name" : "lexicojules",
      "indices" : [ 0, 12 ],
      "id_str" : "424320799",
      "id" : 424320799
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iatefl",
      "indices" : [ 68, 75 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720556671299424256",
  "geo" : { },
  "id_str" : "720567192375468033",
  "in_reply_to_user_id" : 424320799,
  "text" : "@lexicojules hi yes that was the point i took : ) hope u r enjoying #iatefl",
  "id" : 720567192375468033,
  "in_reply_to_status_id" : 720556671299424256,
  "created_at" : "2016-04-14 10:59:40 +0000",
  "in_reply_to_screen_name" : "lexicojules",
  "in_reply_to_user_id_str" : "424320799",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "Dan Ruelle",
      "screen_name" : "danrmitvn",
      "indices" : [ 12, 22 ],
      "id_str" : "125853393",
      "id" : 125853393
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/QTOOjb86rl",
      "expanded_url" : "https:\/\/www.sketchengine.co.uk\/glossary-of-terms\/#salience",
      "display_url" : "sketchengine.co.uk\/glossary-of-te\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "720560017829707776",
  "geo" : { },
  "id_str" : "720565533578543105",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan @danrmitvn  salience as measured by log-dice according to https:\/\/t.co\/QTOOjb86rl",
  "id" : 720565533578543105,
  "in_reply_to_status_id" : 720560017829707776,
  "created_at" : "2016-04-14 10:53:05 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Moore",
      "screen_name" : "lexicojules",
      "indices" : [ 0, 12 ],
      "id_str" : "424320799",
      "id" : 424320799
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720555756441976832",
  "geo" : { },
  "id_str" : "720556323155374080",
  "in_reply_to_user_id" : 424320799,
  "text" : "@lexicojules not \"new\" but i take your point : ) - i.e. see Stefanowitsch &amp; Gries",
  "id" : 720556323155374080,
  "in_reply_to_status_id" : 720555756441976832,
  "created_at" : "2016-04-14 10:16:29 +0000",
  "in_reply_to_screen_name" : "lexicojules",
  "in_reply_to_user_id_str" : "424320799",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennie Wright",
      "screen_name" : "teflhelper",
      "indices" : [ 66, 77 ],
      "id_str" : "1728294235",
      "id" : 1728294235
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/s22OLuLLhk",
      "expanded_url" : "https:\/\/teflhelperblog.wordpress.com\/2016\/04\/14\/free-resources-and-guides-for-corpora\/",
      "display_url" : "teflhelperblog.wordpress.com\/2016\/04\/14\/fre\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "720554548725739520",
  "text" : "Free resources and guides for corpora https:\/\/t.co\/s22OLuLLhk via @teflhelper",
  "id" : 720554548725739520,
  "created_at" : "2016-04-14 10:09:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/720521596633509888\/photo\/1",
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/qSPqlK7ebS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cf_OktrWEAAdiFg.jpg",
      "id_str" : "720521595534577664",
      "id" : 720521595534577664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cf_OktrWEAAdiFg.jpg",
      "sizes" : [ {
        "h" : 86,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 199,
        "resize" : "fit",
        "w" : 1386
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 49,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 147,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/qSPqlK7ebS"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/ngrkoPwr3j",
      "expanded_url" : "http:\/\/cfgg.decontextualize.com\/gen.html?key=1s-uCFGAck3a7L-cfRUpfT2En92wcxxiXnN2g1S5Jjug",
      "display_url" : "cfgg.decontextualize.com\/gen.html?key=1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "720521596633509888",
  "text" : "Vive Game of Charlies https:\/\/t.co\/ngrkoPwr3j https:\/\/t.co\/qSPqlK7ebS",
  "id" : 720521596633509888,
  "created_at" : "2016-04-14 07:58:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720484331144224771",
  "geo" : { },
  "id_str" : "720521117346177024",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler dude dog is way too cool for blogs : )",
  "id" : 720521117346177024,
  "in_reply_to_status_id" : 720484331144224771,
  "created_at" : "2016-04-14 07:56:35 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Ling Space",
      "screen_name" : "TheLingSpace",
      "indices" : [ 3, 16 ],
      "id_str" : "2598450223",
      "id" : 2598450223
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 143, 144 ],
      "url" : "https:\/\/t.co\/ndJeVEf75Y",
      "expanded_url" : "https:\/\/youtu.be\/EOfGgqPeeC4",
      "display_url" : "youtu.be\/EOfGgqPeeC4"
    } ]
  },
  "geo" : { },
  "id_str" : "720497502005366784",
  "text" : "RT @TheLingSpace: Our interview with Lisa Pearl: stats models of lang acquisition, natural lang processing, write-prints, &amp; more! https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/ndJeVEf75Y",
        "expanded_url" : "https:\/\/youtu.be\/EOfGgqPeeC4",
        "display_url" : "youtu.be\/EOfGgqPeeC4"
      } ]
    },
    "geo" : { },
    "id_str" : "720348400277794816",
    "text" : "Our interview with Lisa Pearl: stats models of lang acquisition, natural lang processing, write-prints, &amp; more! https:\/\/t.co\/ndJeVEf75Y",
    "id" : 720348400277794816,
    "created_at" : "2016-04-13 20:30:16 +0000",
    "user" : {
      "name" : "The Ling Space",
      "screen_name" : "TheLingSpace",
      "protected" : false,
      "id_str" : "2598450223",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493941750713421825\/7vym1MUG_normal.jpeg",
      "id" : 2598450223,
      "verified" : false
    }
  },
  "id" : 720497502005366784,
  "created_at" : "2016-04-14 06:22:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "EAPsteve",
      "screen_name" : "EAPstephen",
      "indices" : [ 10, 21 ],
      "id_str" : "2717005711",
      "id" : 2717005711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720351454863556609",
  "geo" : { },
  "id_str" : "720497343305498625",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava @EAPstephen thanks!",
  "id" : 720497343305498625,
  "in_reply_to_status_id" : 720351454863556609,
  "created_at" : "2016-04-14 06:22:07 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "indices" : [ 10, 20 ],
      "id_str" : "577931950",
      "id" : 577931950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720374916890042369",
  "geo" : { },
  "id_str" : "720497217337954304",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava @RudyLoock thanks!",
  "id" : 720497217337954304,
  "in_reply_to_status_id" : 720374916890042369,
  "created_at" : "2016-04-14 06:21:37 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Ellman",
      "screen_name" : "MatthewEllman",
      "indices" : [ 0, 14 ],
      "id_str" : "394987109",
      "id" : 394987109
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720425762931793920",
  "geo" : { },
  "id_str" : "720475699669245953",
  "in_reply_to_user_id" : 394987109,
  "text" : "@MatthewEllman much appreciated : )",
  "id" : 720475699669245953,
  "in_reply_to_status_id" : 720425762931793920,
  "created_at" : "2016-04-14 04:56:07 +0000",
  "in_reply_to_screen_name" : "MatthewEllman",
  "in_reply_to_user_id_str" : "394987109",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720385779562721281",
  "geo" : { },
  "id_str" : "720475621441277952",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler thanks!",
  "id" : 720475621441277952,
  "in_reply_to_status_id" : 720385779562721281,
  "created_at" : "2016-04-14 04:55:48 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/720475561622114305\/photo\/1",
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/V660LBDM7k",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Cf-khUtXEAMCm1Q.jpg",
      "id_str" : "720475357804171267",
      "id" : 720475357804171267,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Cf-khUtXEAMCm1Q.jpg",
      "sizes" : [ {
        "h" : 260,
        "resize" : "fit",
        "w" : 270
      }, {
        "h" : 260,
        "resize" : "fit",
        "w" : 270
      }, {
        "h" : 260,
        "resize" : "fit",
        "w" : 270
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 260,
        "resize" : "fit",
        "w" : 270
      } ],
      "display_url" : "pic.twitter.com\/V660LBDM7k"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720385317128122368",
  "geo" : { },
  "id_str" : "720475561622114305",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler cheers Anne : ) not as cool this this fella though https:\/\/t.co\/V660LBDM7k",
  "id" : 720475561622114305,
  "in_reply_to_status_id" : 720385317128122368,
  "created_at" : "2016-04-14 04:55:34 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AllThingsLinguistic",
      "screen_name" : "AllThingsLing",
      "indices" : [ 3, 17 ],
      "id_str" : "857291268",
      "id" : 857291268
    }, {
      "name" : "The Daily Dot",
      "screen_name" : "dailydot",
      "indices" : [ 53, 62 ],
      "id_str" : "211620426",
      "id" : 211620426
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/vTgasDTOFs",
      "expanded_url" : "https:\/\/tmblr.co\/ZuWOEv24zCKF7",
      "display_url" : "tmblr.co\/ZuWOEv24zCKF7"
    } ]
  },
  "geo" : { },
  "id_str" : "720380932566360064",
  "text" : "RT @AllThingsLing: I did a really fun interview with\u00A0@dailydot\u200B about the \u201Csnek\u201D meme, gosh hecking darn it... https:\/\/t.co\/vTgasDTOFs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Daily Dot",
        "screen_name" : "dailydot",
        "indices" : [ 34, 43 ],
        "id_str" : "211620426",
        "id" : 211620426
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/vTgasDTOFs",
        "expanded_url" : "https:\/\/tmblr.co\/ZuWOEv24zCKF7",
        "display_url" : "tmblr.co\/ZuWOEv24zCKF7"
      } ]
    },
    "geo" : { },
    "id_str" : "720378693558870016",
    "text" : "I did a really fun interview with\u00A0@dailydot\u200B about the \u201Csnek\u201D meme, gosh hecking darn it... https:\/\/t.co\/vTgasDTOFs",
    "id" : 720378693558870016,
    "created_at" : "2016-04-13 22:30:39 +0000",
    "user" : {
      "name" : "AllThingsLinguistic",
      "screen_name" : "AllThingsLing",
      "protected" : false,
      "id_str" : "857291268",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750400997206454273\/N0DmrmFi_normal.jpg",
      "id" : 857291268,
      "verified" : false
    }
  },
  "id" : 720380932566360064,
  "created_at" : "2016-04-13 22:39:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Mairead Moriarty",
      "screen_name" : "MawsMoriarty",
      "indices" : [ 10, 23 ],
      "id_str" : "2353100574",
      "id" : 2353100574
    }, {
      "name" : "Tim Knight",
      "screen_name" : "nakanotim",
      "indices" : [ 24, 34 ],
      "id_str" : "295968758",
      "id" : 295968758
    }, {
      "name" : "Ahmed Abdul Kareem",
      "screen_name" : "ayhamahmed2000",
      "indices" : [ 35, 50 ],
      "id_str" : "593132304",
      "id" : 593132304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720351454863556609",
  "geo" : { },
  "id_str" : "720375430914580480",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava @MawsMoriarty @nakanotim @ayhamahmed2000 thanks folks! : )",
  "id" : 720375430914580480,
  "in_reply_to_status_id" : 720351454863556609,
  "created_at" : "2016-04-13 22:17:41 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/720374916890042369\/photo\/1",
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/0cNW2chdHS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cf9JKz2UkAEv---.jpg",
      "id_str" : "720374915468136449",
      "id" : 720374915468136449,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cf9JKz2UkAEv---.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/0cNW2chdHS"
    } ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/q2Ac3C61mV",
      "expanded_url" : "https:\/\/eflnotes.wordpress.com\/2016\/04\/14\/iatefl-2016-corpus-tweets-1\/",
      "display_url" : "eflnotes.wordpress.com\/2016\/04\/14\/iat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "720374916890042369",
  "text" : "#IATEFL 2016 - Corpus Tweets 1 https:\/\/t.co\/q2Ac3C61mV https:\/\/t.co\/0cNW2chdHS",
  "id" : 720374916890042369,
  "created_at" : "2016-04-13 22:15:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Rachel Daw",
      "screen_name" : "racheldaw18",
      "indices" : [ 10, 22 ],
      "id_str" : "289983899",
      "id" : 289983899
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720351454863556609",
  "geo" : { },
  "id_str" : "720366132826222593",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava @racheldaw18 ta Rachel : )",
  "id" : 720366132826222593,
  "in_reply_to_status_id" : 720351454863556609,
  "created_at" : "2016-04-13 21:40:44 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil Longwell",
      "screen_name" : "teacherphili",
      "indices" : [ 0, 13 ],
      "id_str" : "67863264",
      "id" : 67863264
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720364041491890176",
  "geo" : { },
  "id_str" : "720365546210873344",
  "in_reply_to_user_id" : 67863264,
  "text" : "@teacherphili kk sleep tight : )",
  "id" : 720365546210873344,
  "in_reply_to_status_id" : 720364041491890176,
  "created_at" : "2016-04-13 21:38:24 +0000",
  "in_reply_to_screen_name" : "teacherphili",
  "in_reply_to_user_id_str" : "67863264",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil Longwell",
      "screen_name" : "teacherphili",
      "indices" : [ 0, 13 ],
      "id_str" : "67863264",
      "id" : 67863264
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720357747154235393",
  "geo" : { },
  "id_str" : "720358643393101828",
  "in_reply_to_user_id" : 18602422,
  "text" : "@teacherphili oops sorry that should have beend [viddler id=id_of_video]",
  "id" : 720358643393101828,
  "in_reply_to_status_id" : 720357747154235393,
  "created_at" : "2016-04-13 21:10:58 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Gemma",
      "screen_name" : "GemmaELT",
      "indices" : [ 10, 19 ],
      "id_str" : "3380674715",
      "id" : 3380674715
    }, {
      "name" : "Eily Murphy",
      "screen_name" : "eilymurphy",
      "indices" : [ 20, 31 ],
      "id_str" : "111091623",
      "id" : 111091623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720351454863556609",
  "geo" : { },
  "id_str" : "720357923017220097",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava @GemmaELT @eilymurphy thank you for RT and likes : )",
  "id" : 720357923017220097,
  "in_reply_to_status_id" : 720351454863556609,
  "created_at" : "2016-04-13 21:08:07 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil Longwell",
      "screen_name" : "teacherphili",
      "indices" : [ 0, 13 ],
      "id_str" : "67863264",
      "id" : 67863264
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720355773935521794",
  "geo" : { },
  "id_str" : "720357747154235393",
  "in_reply_to_user_id" : 67863264,
  "text" : "@teacherphili hi use the [Viddler=ID] shortcode; you can get video ID from embed info.",
  "id" : 720357747154235393,
  "in_reply_to_status_id" : 720355773935521794,
  "created_at" : "2016-04-13 21:07:25 +0000",
  "in_reply_to_screen_name" : "teacherphili",
  "in_reply_to_user_id_str" : "67863264",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/oKgmH3Yhim",
      "expanded_url" : "https:\/\/eflnotes.wordpress.com\/2016\/04\/13\/iatefl-2016-can-a-language-test-measure-integration\/",
      "display_url" : "eflnotes.wordpress.com\/2016\/04\/13\/iat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "720351454863556609",
  "text" : "#IATEFL 2016 - Can a language test measure integration https:\/\/t.co\/oKgmH3Yhim",
  "id" : 720351454863556609,
  "created_at" : "2016-04-13 20:42:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sketch Engine",
      "screen_name" : "SketchEngine",
      "indices" : [ 3, 16 ],
      "id_str" : "841197134",
      "id" : 841197134
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/SketchEngine\/status\/720306494504177665\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/lkLgaRzv5u",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cf8K8G5WIAAzyTP.jpg",
      "id_str" : "720306493162135552",
      "id" : 720306493162135552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cf8K8G5WIAAzyTP.jpg",
      "sizes" : [ {
        "h" : 297,
        "resize" : "fit",
        "w" : 227
      }, {
        "h" : 297,
        "resize" : "fit",
        "w" : 227
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 297,
        "resize" : "fit",
        "w" : 227
      }, {
        "h" : 297,
        "resize" : "fit",
        "w" : 227
      } ],
      "display_url" : "pic.twitter.com\/lkLgaRzv5u"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/23yJT4f0SH",
      "expanded_url" : "http:\/\/bit.ly\/DESkE",
      "display_url" : "bit.ly\/DESkE"
    } ]
  },
  "geo" : { },
  "id_str" : "720322657397403648",
  "text" : "RT @SketchEngine: Discovering English with SkE, 2nd ed. + a workbook and glossary. Highly recommended! https:\/\/t.co\/23yJT4f0SH https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/SketchEngine\/status\/720306494504177665\/photo\/1",
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/lkLgaRzv5u",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cf8K8G5WIAAzyTP.jpg",
        "id_str" : "720306493162135552",
        "id" : 720306493162135552,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cf8K8G5WIAAzyTP.jpg",
        "sizes" : [ {
          "h" : 297,
          "resize" : "fit",
          "w" : 227
        }, {
          "h" : 297,
          "resize" : "fit",
          "w" : 227
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 297,
          "resize" : "fit",
          "w" : 227
        }, {
          "h" : 297,
          "resize" : "fit",
          "w" : 227
        } ],
        "display_url" : "pic.twitter.com\/lkLgaRzv5u"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/23yJT4f0SH",
        "expanded_url" : "http:\/\/bit.ly\/DESkE",
        "display_url" : "bit.ly\/DESkE"
      } ]
    },
    "geo" : { },
    "id_str" : "720306494504177665",
    "text" : "Discovering English with SkE, 2nd ed. + a workbook and glossary. Highly recommended! https:\/\/t.co\/23yJT4f0SH https:\/\/t.co\/lkLgaRzv5u",
    "id" : 720306494504177665,
    "created_at" : "2016-04-13 17:43:45 +0000",
    "user" : {
      "name" : "Sketch Engine",
      "screen_name" : "SketchEngine",
      "protected" : false,
      "id_str" : "841197134",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/763331747538997248\/ua_lo7Zd_normal.jpg",
      "id" : 841197134,
      "verified" : false
    }
  },
  "id" : 720322657397403648,
  "created_at" : "2016-04-13 18:47:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShareThis",
      "screen_name" : "ShareThis",
      "indices" : [ 97, 107 ],
      "id_str" : "14116807",
      "id" : 14116807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/Yz8fHLBPKl",
      "expanded_url" : "https:\/\/shar.es\/1j6POf",
      "display_url" : "shar.es\/1j6POf"
    } ]
  },
  "geo" : { },
  "id_str" : "720319399366758401",
  "text" : "Latest Corbyn hit-piece: he earns MP\u2019s salary | Jonathan Cook's Blog https:\/\/t.co\/Yz8fHLBPKl via @sharethis",
  "id" : 720319399366758401,
  "created_at" : "2016-04-13 18:35:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stanford DP",
      "screen_name" : "stanford_dp",
      "indices" : [ 3, 15 ],
      "id_str" : "2552027898",
      "id" : 2552027898
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "health",
      "indices" : [ 77, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/yDrgnJRPrT",
      "expanded_url" : "http:\/\/dragplus.com\/post\/id\/34544002",
      "display_url" : "dragplus.com\/post\/id\/345440\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "720317084090175488",
  "text" : "RT @stanford_dp: Stanford study sheds light on wealth, zip code and lifespan #health https:\/\/t.co\/yDrgnJRPrT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/dragplus.com\" rel=\"nofollow\"\u003EDragPlus\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "health",
        "indices" : [ 60, 67 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/yDrgnJRPrT",
        "expanded_url" : "http:\/\/dragplus.com\/post\/id\/34544002",
        "display_url" : "dragplus.com\/post\/id\/345440\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "720121102303932417",
    "text" : "Stanford study sheds light on wealth, zip code and lifespan #health https:\/\/t.co\/yDrgnJRPrT",
    "id" : 720121102303932417,
    "created_at" : "2016-04-13 05:27:04 +0000",
    "user" : {
      "name" : "Stanford DP",
      "screen_name" : "stanford_dp",
      "protected" : false,
      "id_str" : "2552027898",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/475191422362984448\/0ouui6k6_normal.jpeg",
      "id" : 2552027898,
      "verified" : false
    }
  },
  "id" : 720317084090175488,
  "created_at" : "2016-04-13 18:25:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Strong Language",
      "screen_name" : "stronglang",
      "indices" : [ 83, 94 ],
      "id_str" : "2918426355",
      "id" : 2918426355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/1u0liFE3cS",
      "expanded_url" : "https:\/\/stronglang.wordpress.com\/2016\/04\/13\/four-femmes-on-the-thames-woman-up-and-grow-a-twat\/",
      "display_url" : "stronglang.wordpress.com\/2016\/04\/13\/fou\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "720311944536678401",
  "text" : "Four Femmes on the Thames: \u2018Woman up and grow a twat!\u2019 https:\/\/t.co\/1u0liFE3cS via @stronglang",
  "id" : 720311944536678401,
  "created_at" : "2016-04-13 18:05:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kaam jawaan ki mauth",
      "screen_name" : "naziasmirza",
      "indices" : [ 3, 15 ],
      "id_str" : "256910790",
      "id" : 256910790
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WhatBritishMuslimsReallyThink",
      "indices" : [ 62, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720305771779649536",
  "text" : "RT @naziasmirza: Is Chilcot ever going to publish his report? #WhatBritishMuslimsReallyThink",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WhatBritishMuslimsReallyThink",
        "indices" : [ 45, 75 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "719157185968750594",
    "text" : "Is Chilcot ever going to publish his report? #WhatBritishMuslimsReallyThink",
    "id" : 719157185968750594,
    "created_at" : "2016-04-10 13:36:49 +0000",
    "user" : {
      "name" : "kaam jawaan ki mauth",
      "screen_name" : "naziasmirza",
      "protected" : false,
      "id_str" : "256910790",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/757479938266103808\/cVF0N0zG_normal.jpg",
      "id" : 256910790,
      "verified" : false
    }
  },
  "id" : 720305771779649536,
  "created_at" : "2016-04-13 17:40:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bilal Hassam",
      "screen_name" : "bilalhassam",
      "indices" : [ 3, 15 ],
      "id_str" : "39517015",
      "id" : 39517015
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WhatBritishMuslimsReallyThink",
      "indices" : [ 63, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720305698567954433",
  "text" : "RT @bilalhassam: If only Adele said Salaam instead of Hello... #WhatBritishMuslimsReallyThink",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WhatBritishMuslimsReallyThink",
        "indices" : [ 46, 76 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "719190217706614786",
    "text" : "If only Adele said Salaam instead of Hello... #WhatBritishMuslimsReallyThink",
    "id" : 719190217706614786,
    "created_at" : "2016-04-10 15:48:04 +0000",
    "user" : {
      "name" : "Bilal Hassam",
      "screen_name" : "bilalhassam",
      "protected" : false,
      "id_str" : "39517015",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/621861363925823488\/QNsUugQA_normal.jpg",
      "id" : 39517015,
      "verified" : false
    }
  },
  "id" : 720305698567954433,
  "created_at" : "2016-04-13 17:40:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Baroness Hussein-Ece",
      "screen_name" : "meralhece",
      "indices" : [ 3, 13 ],
      "id_str" : "62603750",
      "id" : 62603750
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WhatBritishMuslimsReallyThink",
      "indices" : [ 55, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720305351128707072",
  "text" : "RT @meralhece: Will Idris Elba be the next James Bond? #WhatBritishMuslimsReallyThink",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WhatBritishMuslimsReallyThink",
        "indices" : [ 40, 70 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "719184616582705154",
    "text" : "Will Idris Elba be the next James Bond? #WhatBritishMuslimsReallyThink",
    "id" : 719184616582705154,
    "created_at" : "2016-04-10 15:25:49 +0000",
    "user" : {
      "name" : "Baroness Hussein-Ece",
      "screen_name" : "meralhece",
      "protected" : false,
      "id_str" : "62603750",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/624661616215334913\/9FXU5pEF_normal.jpg",
      "id" : 62603750,
      "verified" : false
    }
  },
  "id" : 720305351128707072,
  "created_at" : "2016-04-13 17:39:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/PwvzNG6viq",
      "expanded_url" : "http:\/\/www.digitalpedagogylab.com\/hybridped\/from-under-volcano\/",
      "display_url" : "digitalpedagogylab.com\/hybridped\/from\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "720288716518875136",
  "text" : "From Under the Volcano - https:\/\/t.co\/PwvzNG6viq",
  "id" : 720288716518875136,
  "created_at" : "2016-04-13 16:33:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Michael Riccioli",
      "screen_name" : "curvedway",
      "indices" : [ 0, 10 ],
      "id_str" : "124707247",
      "id" : 124707247
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720267486453637122",
  "in_reply_to_user_id" : 124707247,
  "text" : "@curvedway thanks for all RTs and likes Michael : )",
  "id" : 720267486453637122,
  "created_at" : "2016-04-13 15:08:45 +0000",
  "in_reply_to_screen_name" : "curvedway",
  "in_reply_to_user_id_str" : "124707247",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Small Axe",
      "screen_name" : "SankofaMind",
      "indices" : [ 0, 12 ],
      "id_str" : "3198097774",
      "id" : 3198097774
    }, {
      "name" : "Mind",
      "screen_name" : "MindCharity",
      "indices" : [ 13, 25 ],
      "id_str" : "27033505",
      "id" : 27033505
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720255214381608960",
  "geo" : { },
  "id_str" : "720255617592524801",
  "in_reply_to_user_id" : 3198097774,
  "text" : "@SankofaMind @MindCharity true that",
  "id" : 720255617592524801,
  "in_reply_to_status_id" : 720255214381608960,
  "created_at" : "2016-04-13 14:21:35 +0000",
  "in_reply_to_screen_name" : "SankofaMind",
  "in_reply_to_user_id_str" : "3198097774",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IATEFL BESIG",
      "screen_name" : "iatefl_besig",
      "indices" : [ 0, 13 ],
      "id_str" : "146913655",
      "id" : 146913655
    }, {
      "name" : "Jennie Wright",
      "screen_name" : "teflhelper",
      "indices" : [ 14, 25 ],
      "id_str" : "1728294235",
      "id" : 1728294235
    }, {
      "name" : "Laura Edwards",
      "screen_name" : "EdLaur",
      "indices" : [ 26, 33 ],
      "id_str" : "1834826917",
      "id" : 1834826917
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720189985878601728",
  "geo" : { },
  "id_str" : "720255314025693184",
  "in_reply_to_user_id" : 18602422,
  "text" : "@iatefl_besig @teflhelper @EdLaur thanks Laura : )",
  "id" : 720255314025693184,
  "in_reply_to_status_id" : 720189985878601728,
  "created_at" : "2016-04-13 14:20:23 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Small Axe",
      "screen_name" : "SankofaMind",
      "indices" : [ 0, 12 ],
      "id_str" : "3198097774",
      "id" : 3198097774
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720253498164703232",
  "geo" : { },
  "id_str" : "720254693180461057",
  "in_reply_to_user_id" : 3198097774,
  "text" : "@SankofaMind his point about simplistic thinking vs complex ignores fundamental attribution bias; i.e. your probs complex others simple",
  "id" : 720254693180461057,
  "in_reply_to_status_id" : 720253498164703232,
  "created_at" : "2016-04-13 14:17:55 +0000",
  "in_reply_to_screen_name" : "SankofaMind",
  "in_reply_to_user_id_str" : "3198097774",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Small Axe",
      "screen_name" : "SankofaMind",
      "indices" : [ 0, 12 ],
      "id_str" : "3198097774",
      "id" : 3198097774
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720251626699800576",
  "geo" : { },
  "id_str" : "720252194197516288",
  "in_reply_to_user_id" : 3198097774,
  "text" : "@SankofaMind the infantilism focus was on mainstream US no? e.g. stop watching superhero films? Funny line he can still crack em",
  "id" : 720252194197516288,
  "in_reply_to_status_id" : 720251626699800576,
  "created_at" : "2016-04-13 14:07:59 +0000",
  "in_reply_to_screen_name" : "SankofaMind",
  "in_reply_to_user_id_str" : "3198097774",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Small Axe",
      "screen_name" : "SankofaMind",
      "indices" : [ 0, 12 ],
      "id_str" : "3198097774",
      "id" : 3198097774
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720248232228458497",
  "geo" : { },
  "id_str" : "720250129559789569",
  "in_reply_to_user_id" : 18602422,
  "text" : "@SankofaMind a bit of clarity \"because America leads and Britain follows\" but not in sense Fry was using I suspect",
  "id" : 720250129559789569,
  "in_reply_to_status_id" : 720248232228458497,
  "created_at" : "2016-04-13 13:59:47 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Small Axe",
      "screen_name" : "SankofaMind",
      "indices" : [ 0, 12 ],
      "id_str" : "3198097774",
      "id" : 3198097774
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720248232228458497",
  "geo" : { },
  "id_str" : "720248727768686593",
  "in_reply_to_user_id" : 18602422,
  "text" : "@SankofaMind mind you he does pop in \"genocide\" blink and you might have missed it though",
  "id" : 720248727768686593,
  "in_reply_to_status_id" : 720248232228458497,
  "created_at" : "2016-04-13 13:54:12 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Small Axe",
      "screen_name" : "SankofaMind",
      "indices" : [ 0, 12 ],
      "id_str" : "3198097774",
      "id" : 3198097774
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720246669653069828",
  "geo" : { },
  "id_str" : "720248232228458497",
  "in_reply_to_user_id" : 3198097774,
  "text" : "@SankofaMind oh dear i c what u mean \"america went horribly wrong in first 100 years\" cos history US starts with european settlers of course",
  "id" : 720248232228458497,
  "in_reply_to_status_id" : 720246669653069828,
  "created_at" : "2016-04-13 13:52:14 +0000",
  "in_reply_to_screen_name" : "SankofaMind",
  "in_reply_to_user_id_str" : "3198097774",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Small Axe",
      "screen_name" : "SankofaMind",
      "indices" : [ 0, 12 ],
      "id_str" : "3198097774",
      "id" : 3198097774
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720236191375863809",
  "geo" : { },
  "id_str" : "720245977106370560",
  "in_reply_to_user_id" : 3198097774,
  "text" : "@SankofaMind hi where is available? thx",
  "id" : 720245977106370560,
  "in_reply_to_status_id" : 720236191375863809,
  "created_at" : "2016-04-13 13:43:17 +0000",
  "in_reply_to_screen_name" : "SankofaMind",
  "in_reply_to_user_id_str" : "3198097774",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iatefl",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/B9HPVomYfC",
      "expanded_url" : "https:\/\/storify.com\/muranava\/iatefl2016-corpus-tweets-1",
      "display_url" : "storify.com\/muranava\/iatef\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "720241963103072256",
  "text" : "#iatefl  https:\/\/t.co\/B9HPVomYfC \nIATEFL2016 Corpus Tweets 1 Making trouble free corpus tasks - Jennie Wright as reported by Sandy Millin",
  "id" : 720241963103072256,
  "created_at" : "2016-04-13 13:27:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Daw",
      "screen_name" : "racheldaw18",
      "indices" : [ 0, 12 ],
      "id_str" : "289983899",
      "id" : 289983899
    }, {
      "name" : "Chris Jones",
      "screen_name" : "ELTResearch",
      "indices" : [ 28, 40 ],
      "id_str" : "3308043417",
      "id" : 3308043417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720234857851437056",
  "geo" : { },
  "id_str" : "720235474678390784",
  "in_reply_to_user_id" : 289983899,
  "text" : "@racheldaw18 hi Rachel it's @ELTResearch",
  "id" : 720235474678390784,
  "in_reply_to_status_id" : 720234857851437056,
  "created_at" : "2016-04-13 13:01:33 +0000",
  "in_reply_to_screen_name" : "racheldaw18",
  "in_reply_to_user_id_str" : "289983899",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "EAPsteve",
      "screen_name" : "EAPstephen",
      "indices" : [ 10, 21 ],
      "id_str" : "2717005711",
      "id" : 2717005711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720032452618620928",
  "geo" : { },
  "id_str" : "720234652880019456",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava @EAPstephen thanks!  : )",
  "id" : 720234652880019456,
  "in_reply_to_status_id" : 720032452618620928,
  "created_at" : "2016-04-13 12:58:17 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IATEFL BESIG",
      "screen_name" : "iatefl_besig",
      "indices" : [ 0, 13 ],
      "id_str" : "146913655",
      "id" : 146913655
    }, {
      "name" : "Jennie Wright",
      "screen_name" : "teflhelper",
      "indices" : [ 14, 25 ],
      "id_str" : "1728294235",
      "id" : 1728294235
    }, {
      "name" : "Sandy Millin",
      "screen_name" : "sandymillin",
      "indices" : [ 26, 38 ],
      "id_str" : "144236944",
      "id" : 144236944
    }, {
      "name" : "Dan Ruelle",
      "screen_name" : "danrmitvn",
      "indices" : [ 39, 49 ],
      "id_str" : "125853393",
      "id" : 125853393
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720189985878601728",
  "geo" : { },
  "id_str" : "720234322918260736",
  "in_reply_to_user_id" : 18602422,
  "text" : "@iatefl_besig @teflhelper @sandymillin @danrmitvn many thanks for sharing and liking : )",
  "id" : 720234322918260736,
  "in_reply_to_status_id" : 720189985878601728,
  "created_at" : "2016-04-13 12:56:58 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cherry M P",
      "screen_name" : "cherrymp",
      "indices" : [ 0, 9 ],
      "id_str" : "42655926",
      "id" : 42655926
    }, {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 10, 22 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720213926030503936",
  "geo" : { },
  "id_str" : "720233826006540288",
  "in_reply_to_user_id" : 42655926,
  "text" : "@cherrymp @AnneHendler if u have android 6 marshmallow can set app permissions; otherwise needed rooted phone + xposed framework + xprivacy",
  "id" : 720233826006540288,
  "in_reply_to_status_id" : 720213926030503936,
  "created_at" : "2016-04-13 12:55:00 +0000",
  "in_reply_to_screen_name" : "cherrymp",
  "in_reply_to_user_id_str" : "42655926",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IATEFL BESIG",
      "screen_name" : "iatefl_besig",
      "indices" : [ 54, 67 ],
      "id_str" : "146913655",
      "id" : 146913655
    }, {
      "name" : "Jennie Wright",
      "screen_name" : "teflhelper",
      "indices" : [ 68, 79 ],
      "id_str" : "1728294235",
      "id" : 1728294235
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 104, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/LxCThE4Wv7",
      "expanded_url" : "https:\/\/www.smashwords.com\/books\/view\/618387",
      "display_url" : "smashwords.com\/books\/view\/618\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "720188177525444608",
  "geo" : { },
  "id_str" : "720189985878601728",
  "in_reply_to_user_id" : 146913655,
  "text" : "there's a wee ebook that could help with search terms @iatefl_besig @teflhelper https:\/\/t.co\/LxCThE4Wv7 #IATEFL : )",
  "id" : 720189985878601728,
  "in_reply_to_status_id" : 720188177525444608,
  "created_at" : "2016-04-13 10:00:47 +0000",
  "in_reply_to_screen_name" : "iatefl_besig",
  "in_reply_to_user_id_str" : "146913655",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sandy Millin",
      "screen_name" : "sandymillin",
      "indices" : [ 0, 12 ],
      "id_str" : "144236944",
      "id" : 144236944
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iatefl",
      "indices" : [ 63, 70 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720186658960883713",
  "geo" : { },
  "id_str" : "720187087727763456",
  "in_reply_to_user_id" : 144236944,
  "text" : "@sandymillin fyi new interface due in May seems more intuitive #iatefl : )",
  "id" : 720187087727763456,
  "in_reply_to_status_id" : 720186658960883713,
  "created_at" : "2016-04-13 09:49:16 +0000",
  "in_reply_to_screen_name" : "sandymillin",
  "in_reply_to_user_id_str" : "144236944",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Helen Legge",
      "screen_name" : "ITLegge",
      "indices" : [ 10, 18 ],
      "id_str" : "2201561838",
      "id" : 2201561838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720032452618620928",
  "geo" : { },
  "id_str" : "720185636658016257",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava @ITLegge thanks :Helen : )",
  "id" : 720185636658016257,
  "in_reply_to_status_id" : 720032452618620928,
  "created_at" : "2016-04-13 09:43:30 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    }, {
      "name" : "Faten Romdhani",
      "screen_name" : "Romdhanifaten",
      "indices" : [ 13, 27 ],
      "id_str" : "304559688",
      "id" : 304559688
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720156890164953088",
  "geo" : { },
  "id_str" : "720185476607553536",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler @Romdhanifaten thanks for sharing :)",
  "id" : 720185476607553536,
  "in_reply_to_status_id" : 720156890164953088,
  "created_at" : "2016-04-13 09:42:52 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oxford ELT",
      "screen_name" : "OUPELTGlobal",
      "indices" : [ 78, 91 ],
      "id_str" : "74177226",
      "id" : 74177226
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/0B5o19BTDh",
      "expanded_url" : "https:\/\/oupeltglobalblog.com\/2016\/04\/13\/a-way-to-make-demonstrative-determiners-teachable\/",
      "display_url" : "oupeltglobalblog.com\/2016\/04\/13\/a-w\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "720185058460635136",
  "text" : "A way to make demonstrative determiners teachable https:\/\/t.co\/0B5o19BTDh via @OUPELTGlobal",
  "id" : 720185058460635136,
  "created_at" : "2016-04-13 09:41:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alannah Fitzgerald",
      "screen_name" : "AlannahFitz",
      "indices" : [ 3, 15 ],
      "id_str" : "223613160",
      "id" : 223613160
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/AlannahFitz\/status\/720139927724232704\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/yG73mpI7l2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cf5zcq5UIAE4-VV.jpg",
      "id_str" : "720139926814072833",
      "id" : 720139926814072833,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cf5zcq5UIAE4-VV.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/yG73mpI7l2"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/UZ3v2Z5TLz",
      "expanded_url" : "https:\/\/plus.google.com\/+alannahfitzgerald\/posts\/CdCtYAHgXAz",
      "display_url" : "plus.google.com\/+alannahfitzge\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "720140546644254720",
  "text" : "RT @AlannahFitz: Come and find out about the open FLAX project at IATEFL Interactive Language Learning Fair,\u2026 https:\/\/t.co\/UZ3v2Z5TLz https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/friendsplus.me\" rel=\"nofollow\"\u003EFriends Me\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/AlannahFitz\/status\/720139927724232704\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/yG73mpI7l2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cf5zcq5UIAE4-VV.jpg",
        "id_str" : "720139926814072833",
        "id" : 720139926814072833,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cf5zcq5UIAE4-VV.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/yG73mpI7l2"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/UZ3v2Z5TLz",
        "expanded_url" : "https:\/\/plus.google.com\/+alannahfitzgerald\/posts\/CdCtYAHgXAz",
        "display_url" : "plus.google.com\/+alannahfitzge\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "720139927724232704",
    "text" : "Come and find out about the open FLAX project at IATEFL Interactive Language Learning Fair,\u2026 https:\/\/t.co\/UZ3v2Z5TLz https:\/\/t.co\/yG73mpI7l2",
    "id" : 720139927724232704,
    "created_at" : "2016-04-13 06:41:52 +0000",
    "user" : {
      "name" : "Alannah Fitzgerald",
      "screen_name" : "AlannahFitz",
      "protected" : false,
      "id_str" : "223613160",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2645381550\/e07d3b354efdac11bce2725cbc44e94e_normal.png",
      "id" : 223613160,
      "verified" : false
    }
  },
  "id" : 720140546644254720,
  "created_at" : "2016-04-13 06:44:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Fordham",
      "screen_name" : "mfordhamhistory",
      "indices" : [ 69, 85 ],
      "id_str" : "267094769",
      "id" : 267094769
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/BgP7dDAj8i",
      "expanded_url" : "https:\/\/clioetcetera.com\/2016\/04\/13\/the-curse-of-the-generic-a-small-satire\/",
      "display_url" : "clioetcetera.com\/2016\/04\/13\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "720139465805717504",
  "text" : "The curse of the generic: a small satire https:\/\/t.co\/BgP7dDAj8i via @mfordhamhistory",
  "id" : 720139465805717504,
  "created_at" : "2016-04-13 06:40:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "indices" : [ 3, 18 ],
      "id_str" : "152194866",
      "id" : 152194866
    }, {
      "name" : "Anonymous",
      "screen_name" : "YourAnonNews",
      "indices" : [ 106, 119 ],
      "id_str" : "279390084",
      "id" : 279390084
    }, {
      "name" : "Cory Doctorow",
      "screen_name" : "doctorow",
      "indices" : [ 120, 129 ],
      "id_str" : "2729061",
      "id" : 2729061
    }, {
      "name" : "EFF",
      "screen_name" : "EFF",
      "indices" : [ 130, 134 ],
      "id_str" : "4816",
      "id" : 4816
    }, {
      "name" : "switched",
      "screen_name" : "switch_d",
      "indices" : [ 135, 140 ],
      "id_str" : "263917895",
      "id" : 263917895
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/dkFeMcupFp",
      "expanded_url" : "http:\/\/wp.me\/pSoaD-hSA",
      "display_url" : "wp.me\/pSoaD-hSA"
    } ]
  },
  "geo" : { },
  "id_str" : "720138784059297792",
  "text" : "RT @patrickDurusau: Please retweet: Anonymous Chat Service https:\/\/t.co\/dkFeMcupFp Go dark, go very dark! @YourAnonNews @doctorow @EFF @swi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anonymous",
        "screen_name" : "YourAnonNews",
        "indices" : [ 86, 99 ],
        "id_str" : "279390084",
        "id" : 279390084
      }, {
        "name" : "Cory Doctorow",
        "screen_name" : "doctorow",
        "indices" : [ 100, 109 ],
        "id_str" : "2729061",
        "id" : 2729061
      }, {
        "name" : "EFF",
        "screen_name" : "EFF",
        "indices" : [ 110, 114 ],
        "id_str" : "4816",
        "id" : 4816
      }, {
        "name" : "switched",
        "screen_name" : "switch_d",
        "indices" : [ 115, 124 ],
        "id_str" : "263917895",
        "id" : 263917895
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 62 ],
        "url" : "https:\/\/t.co\/dkFeMcupFp",
        "expanded_url" : "http:\/\/wp.me\/pSoaD-hSA",
        "display_url" : "wp.me\/pSoaD-hSA"
      } ]
    },
    "geo" : { },
    "id_str" : "720049963703644161",
    "text" : "Please retweet: Anonymous Chat Service https:\/\/t.co\/dkFeMcupFp Go dark, go very dark! @YourAnonNews @doctorow @EFF @switch_d",
    "id" : 720049963703644161,
    "created_at" : "2016-04-13 00:44:23 +0000",
    "user" : {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "protected" : false,
      "id_str" : "152194866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/961579480\/patrick_normal.jpeg",
      "id" : 152194866,
      "verified" : false
    }
  },
  "id" : 720138784059297792,
  "created_at" : "2016-04-13 06:37:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Venning",
      "screen_name" : "linkstoenglish",
      "indices" : [ 3, 18 ],
      "id_str" : "3083991707",
      "id" : 3083991707
    }, {
      "name" : "Fast Company",
      "screen_name" : "FastCompany",
      "indices" : [ 48, 60 ],
      "id_str" : "2735591",
      "id" : 2735591
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "businessEnglish",
      "indices" : [ 137, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/3DGDa3muuY",
      "expanded_url" : "http:\/\/www.fastcompany.com\/3055375\/every-meeting-youve-ever-been-to-in-two-minutes",
      "display_url" : "fastcompany.com\/3055375\/every-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "720136070680158208",
  "text" : "RT @linkstoenglish: VIDEO: Those nice people at @FastCompany have decoded what people REALLY mean at meetings: \n\nhttps:\/\/t.co\/3DGDa3muuY #b\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Fast Company",
        "screen_name" : "FastCompany",
        "indices" : [ 28, 40 ],
        "id_str" : "2735591",
        "id" : 2735591
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "businessEnglish",
        "indices" : [ 117, 133 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/3DGDa3muuY",
        "expanded_url" : "http:\/\/www.fastcompany.com\/3055375\/every-meeting-youve-ever-been-to-in-two-minutes",
        "display_url" : "fastcompany.com\/3055375\/every-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "720135008908918784",
    "text" : "VIDEO: Those nice people at @FastCompany have decoded what people REALLY mean at meetings: \n\nhttps:\/\/t.co\/3DGDa3muuY #businessEnglish",
    "id" : 720135008908918784,
    "created_at" : "2016-04-13 06:22:20 +0000",
    "user" : {
      "name" : "Mark Venning",
      "screen_name" : "linkstoenglish",
      "protected" : false,
      "id_str" : "3083991707",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/575341765269458944\/MQ14AxmY_normal.jpeg",
      "id" : 3083991707,
      "verified" : false
    }
  },
  "id" : 720136070680158208,
  "created_at" : "2016-04-13 06:26:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720092821567344640",
  "geo" : { },
  "id_str" : "720134307331903488",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler thanks Anne : )",
  "id" : 720134307331903488,
  "in_reply_to_status_id" : 720092821567344640,
  "created_at" : "2016-04-13 06:19:32 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Rachel Daw",
      "screen_name" : "racheldaw18",
      "indices" : [ 10, 22 ],
      "id_str" : "289983899",
      "id" : 289983899
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720032452618620928",
  "geo" : { },
  "id_str" : "720134192244400130",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava @racheldaw18 thx Rachel how's the conference going?",
  "id" : 720134192244400130,
  "in_reply_to_status_id" : 720032452618620928,
  "created_at" : "2016-04-13 06:19:05 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "TTTJournal.",
      "screen_name" : "TTT_Journal",
      "indices" : [ 10, 22 ],
      "id_str" : "710551825787830272",
      "id" : 710551825787830272
    }, {
      "name" : "damon_tokyo",
      "screen_name" : "damon_tokyo",
      "indices" : [ 23, 35 ],
      "id_str" : "17856980",
      "id" : 17856980
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720032452618620928",
  "geo" : { },
  "id_str" : "720044491290382336",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava @TTT_Journal @damon_tokyo thks for RT :)",
  "id" : 720044491290382336,
  "in_reply_to_status_id" : 720032452618620928,
  "created_at" : "2016-04-13 00:22:39 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "patrick",
      "screen_name" : "patrickamon",
      "indices" : [ 0, 12 ],
      "id_str" : "46382179",
      "id" : 46382179
    }, {
      "name" : "Paris Lees",
      "screen_name" : "ParisLees",
      "indices" : [ 13, 23 ],
      "id_str" : "146894920",
      "id" : 146894920
    }, {
      "name" : "Guardian Opinion",
      "screen_name" : "guardianopinion",
      "indices" : [ 24, 40 ],
      "id_str" : "14275129",
      "id" : 14275129
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720042314937319425",
  "geo" : { },
  "id_str" : "720043869799362561",
  "in_reply_to_user_id" : 46382179,
  "text" : "@patrickamon @ParisLees @guardianopinion true that",
  "id" : 720043869799362561,
  "in_reply_to_status_id" : 720042314937319425,
  "created_at" : "2016-04-13 00:20:10 +0000",
  "in_reply_to_screen_name" : "patrickamon",
  "in_reply_to_user_id_str" : "46382179",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "patrick",
      "screen_name" : "patrickamon",
      "indices" : [ 0, 12 ],
      "id_str" : "46382179",
      "id" : 46382179
    }, {
      "name" : "Paris Lees",
      "screen_name" : "ParisLees",
      "indices" : [ 13, 23 ],
      "id_str" : "146894920",
      "id" : 146894920
    }, {
      "name" : "Guardian Opinion",
      "screen_name" : "guardianopinion",
      "indices" : [ 24, 40 ],
      "id_str" : "14275129",
      "id" : 14275129
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720040535034093568",
  "geo" : { },
  "id_str" : "720041429825937410",
  "in_reply_to_user_id" : 46382179,
  "text" : "@patrickamon @ParisLees @guardianopinion true this particular situation seems messed up and does this weaken sig general point?",
  "id" : 720041429825937410,
  "in_reply_to_status_id" : 720040535034093568,
  "created_at" : "2016-04-13 00:10:29 +0000",
  "in_reply_to_screen_name" : "patrickamon",
  "in_reply_to_user_id_str" : "46382179",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/IoqHvnXqcd",
      "expanded_url" : "https:\/\/twitter.com\/holden\/status\/720022733371756544",
      "display_url" : "twitter.com\/holden\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "720038490415697920",
  "text" : "erm RTing with a comment? : ) https:\/\/t.co\/IoqHvnXqcd",
  "id" : 720038490415697920,
  "created_at" : "2016-04-12 23:58:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "patrick",
      "screen_name" : "patrickamon",
      "indices" : [ 0, 12 ],
      "id_str" : "46382179",
      "id" : 46382179
    }, {
      "name" : "Paris Lees",
      "screen_name" : "ParisLees",
      "indices" : [ 13, 23 ],
      "id_str" : "146894920",
      "id" : 146894920
    }, {
      "name" : "Guardian Opinion",
      "screen_name" : "guardianopinion",
      "indices" : [ 24, 40 ],
      "id_str" : "14275129",
      "id" : 14275129
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720034489376903169",
  "geo" : { },
  "id_str" : "720038280998338561",
  "in_reply_to_user_id" : 46382179,
  "text" : "@patrickamon @ParisLees @guardianopinion u mean both \"errors\" of language equally insensitive?",
  "id" : 720038280998338561,
  "in_reply_to_status_id" : 720034489376903169,
  "created_at" : "2016-04-12 23:57:58 +0000",
  "in_reply_to_screen_name" : "patrickamon",
  "in_reply_to_user_id_str" : "46382179",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/720032452618620928\/photo\/1",
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/28wFHKGxKy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cf4Rs0GW4AEcvI0.jpg",
      "id_str" : "720032452023083009",
      "id" : 720032452023083009,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cf4Rs0GW4AEcvI0.jpg",
      "sizes" : [ {
        "h" : 1067,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 720
      } ],
      "display_url" : "pic.twitter.com\/28wFHKGxKy"
    } ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/XQK3KJuNYg",
      "expanded_url" : "https:\/\/eflnotes.wordpress.com\/2016\/04\/13\/iatefl-2016-conference-app-review",
      "display_url" : "eflnotes.wordpress.com\/2016\/04\/13\/iat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "720032452618620928",
  "text" : "#IATEFL 2016 - conference app review https:\/\/t.co\/XQK3KJuNYg https:\/\/t.co\/28wFHKGxKy",
  "id" : 720032452618620928,
  "created_at" : "2016-04-12 23:34:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paris Lees",
      "screen_name" : "ParisLees",
      "indices" : [ 3, 13 ],
      "id_str" : "146894920",
      "id" : 146894920
    }, {
      "name" : "Guardian Opinion",
      "screen_name" : "guardianopinion",
      "indices" : [ 138, 139 ],
      "id_str" : "14275129",
      "id" : 14275129
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/8wglhPUney",
      "expanded_url" : "http:\/\/www.theguardian.com\/commentisfree\/2016\/apr\/12\/stephen-fry-free-speech-child-abuse-bullying-safe-spaces?CMP=soc_3156",
      "display_url" : "theguardian.com\/commentisfree\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "720007799586103296",
  "text" : "RT @ParisLees: Free speech isn\u2019t under attack; platform privilege is. On Stephen Fry and other chatterati bullies: https:\/\/t.co\/8wglhPUney\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Guardian Opinion",
        "screen_name" : "guardianopinion",
        "indices" : [ 124, 140 ],
        "id_str" : "14275129",
        "id" : 14275129
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/8wglhPUney",
        "expanded_url" : "http:\/\/www.theguardian.com\/commentisfree\/2016\/apr\/12\/stephen-fry-free-speech-child-abuse-bullying-safe-spaces?CMP=soc_3156",
        "display_url" : "theguardian.com\/commentisfree\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "719982342102757376",
    "text" : "Free speech isn\u2019t under attack; platform privilege is. On Stephen Fry and other chatterati bullies: https:\/\/t.co\/8wglhPUney @guardianopinion",
    "id" : 719982342102757376,
    "created_at" : "2016-04-12 20:15:41 +0000",
    "user" : {
      "name" : "Paris Lees",
      "screen_name" : "ParisLees",
      "protected" : false,
      "id_str" : "146894920",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700033272449994753\/XxIB4vyq_normal.png",
      "id" : 146894920,
      "verified" : true
    }
  },
  "id" : 720007799586103296,
  "created_at" : "2016-04-12 21:56:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Stewart-Ahn",
      "screen_name" : "somebadideas",
      "indices" : [ 3, 16 ],
      "id_str" : "25484126",
      "id" : 25484126
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 147, 148 ],
      "url" : "https:\/\/t.co\/jFX9yIOEeb",
      "expanded_url" : "http:\/\/www.independent.co.uk\/voices\/i-am-on-the-us-kill-list-this-is-what-it-feels-like-to-be-hunted-by-drones-a6980141.html",
      "display_url" : "independent.co.uk\/voices\/i-am-on\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "719977595220205570",
  "text" : "RT @somebadideas: A first person memoir of what it's like to be on the US &amp; UK drone Kill List &amp; begging the govts to be taken off it. http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 125, 148 ],
        "url" : "https:\/\/t.co\/jFX9yIOEeb",
        "expanded_url" : "http:\/\/www.independent.co.uk\/voices\/i-am-on-the-us-kill-list-this-is-what-it-feels-like-to-be-hunted-by-drones-a6980141.html",
        "display_url" : "independent.co.uk\/voices\/i-am-on\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "719905368684511232",
    "text" : "A first person memoir of what it's like to be on the US &amp; UK drone Kill List &amp; begging the govts to be taken off it. https:\/\/t.co\/jFX9yIOEeb",
    "id" : 719905368684511232,
    "created_at" : "2016-04-12 15:09:49 +0000",
    "user" : {
      "name" : "Aaron Stewart-Ahn",
      "screen_name" : "somebadideas",
      "protected" : false,
      "id_str" : "25484126",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/643352901801377792\/FOIrU73D_normal.jpg",
      "id" : 25484126,
      "verified" : false
    }
  },
  "id" : 719977595220205570,
  "created_at" : "2016-04-12 19:56:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "indices" : [ 0, 12 ],
      "id_str" : "192437743",
      "id" : 192437743
    }, {
      "name" : "Lesley",
      "screen_name" : "cioccas",
      "indices" : [ 13, 21 ],
      "id_str" : "227474018",
      "id" : 227474018
    }, {
      "name" : "Sophia Khan",
      "screen_name" : "SophiaKhan4",
      "indices" : [ 22, 34 ],
      "id_str" : "351390617",
      "id" : 351390617
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/6x5ukCaruD",
      "expanded_url" : "https:\/\/www.ausnc.org.au\/",
      "display_url" : "ausnc.org.au"
    } ]
  },
  "in_reply_to_status_id_str" : "719971280343011328",
  "geo" : { },
  "id_str" : "719972829593255936",
  "in_reply_to_user_id" : 192437743,
  "text" : "@nathanghall @cioccas @SophiaKhan4 it's a nice variation u cld try to explore it more using ANC? https:\/\/t.co\/6x5ukCaruD",
  "id" : 719972829593255936,
  "in_reply_to_status_id" : 719971280343011328,
  "created_at" : "2016-04-12 19:37:53 +0000",
  "in_reply_to_screen_name" : "nathanghall",
  "in_reply_to_user_id_str" : "192437743",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lesley",
      "screen_name" : "cioccas",
      "indices" : [ 0, 8 ],
      "id_str" : "227474018",
      "id" : 227474018
    }, {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "indices" : [ 9, 21 ],
      "id_str" : "192437743",
      "id" : 192437743
    }, {
      "name" : "Sophia Khan",
      "screen_name" : "SophiaKhan4",
      "indices" : [ 22, 34 ],
      "id_str" : "351390617",
      "id" : 351390617
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/9TW99SfPHZ",
      "expanded_url" : "http:\/\/corpus.byu.edu\/glowbe\/?c=glowbe&q=46777742",
      "display_url" : "corpus.byu.edu\/glowbe\/?c=glow\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "719967995276070912",
  "geo" : { },
  "id_str" : "719969490453282816",
  "in_reply_to_user_id" : 227474018,
  "text" : "@cioccas @nathanghall @SophiaKhan4 GLOWBE distribution info here suggest aus\/nz preferences for square https:\/\/t.co\/9TW99SfPHZ",
  "id" : 719969490453282816,
  "in_reply_to_status_id" : 719967995276070912,
  "created_at" : "2016-04-12 19:24:37 +0000",
  "in_reply_to_screen_name" : "cioccas",
  "in_reply_to_user_id_str" : "227474018",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Miqdaad Versi",
      "screen_name" : "miqdaad",
      "indices" : [ 3, 11 ],
      "id_str" : "16559786",
      "id" : 16559786
    }, {
      "name" : "The Guardian",
      "screen_name" : "guardian",
      "indices" : [ 107, 116 ],
      "id_str" : "87818409",
      "id" : 87818409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/hkVQrUEGC4",
      "expanded_url" : "http:\/\/www.theguardian.com\/commentisfree\/2016\/apr\/12\/what-do-muslims-think-skewed-poll-wont-tell-us",
      "display_url" : "theguardian.com\/commentisfree\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "719968542058287104",
  "text" : "RT @miqdaad: What do British Muslims really think? This skewed poll certainly won\u2019t tell us. My article in @guardian https:\/\/t.co\/hkVQrUEGC4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Guardian",
        "screen_name" : "guardian",
        "indices" : [ 94, 103 ],
        "id_str" : "87818409",
        "id" : 87818409
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/hkVQrUEGC4",
        "expanded_url" : "http:\/\/www.theguardian.com\/commentisfree\/2016\/apr\/12\/what-do-muslims-think-skewed-poll-wont-tell-us",
        "display_url" : "theguardian.com\/commentisfree\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "719788461880975360",
    "text" : "What do British Muslims really think? This skewed poll certainly won\u2019t tell us. My article in @guardian https:\/\/t.co\/hkVQrUEGC4",
    "id" : 719788461880975360,
    "created_at" : "2016-04-12 07:25:16 +0000",
    "user" : {
      "name" : "Miqdaad Versi",
      "screen_name" : "miqdaad",
      "protected" : false,
      "id_str" : "16559786",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/579624413492092928\/JdYwwlP__normal.jpg",
      "id" : 16559786,
      "verified" : false
    }
  },
  "id" : 719968542058287104,
  "created_at" : "2016-04-12 19:20:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Edwards",
      "screen_name" : "EdLaur",
      "indices" : [ 0, 7 ],
      "id_str" : "1834826917",
      "id" : 1834826917
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "719925798652813312",
  "geo" : { },
  "id_str" : "719966870883995650",
  "in_reply_to_user_id" : 1834826917,
  "text" : "@EdLaur yr welcome : )",
  "id" : 719966870883995650,
  "in_reply_to_status_id" : 719925798652813312,
  "created_at" : "2016-04-12 19:14:13 +0000",
  "in_reply_to_screen_name" : "EdLaur",
  "in_reply_to_user_id_str" : "1834826917",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sophia Khan",
      "screen_name" : "SophiaKhan4",
      "indices" : [ 0, 12 ],
      "id_str" : "351390617",
      "id" : 351390617
    }, {
      "name" : "Phil Longwell",
      "screen_name" : "teacherphili",
      "indices" : [ 13, 26 ],
      "id_str" : "67863264",
      "id" : 67863264
    }, {
      "name" : "Huw Jarvis",
      "screen_name" : "TESOLacademic",
      "indices" : [ 27, 41 ],
      "id_str" : "43409552",
      "id" : 43409552
    }, {
      "name" : "IATEFL Head Office",
      "screen_name" : "iatefl",
      "indices" : [ 42, 49 ],
      "id_str" : "85042286",
      "id" : 85042286
    }, {
      "name" : "IATEFL Online",
      "screen_name" : "iateflonline",
      "indices" : [ 50, 63 ],
      "id_str" : "17447359",
      "id" : 17447359
    }, {
      "name" : "bot",
      "screen_name" : "TESOL_IATEFL_50",
      "indices" : [ 84, 100 ],
      "id_str" : "710852790948642817",
      "id" : 710852790948642817
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "719913198497849344",
  "geo" : { },
  "id_str" : "719914498660896768",
  "in_reply_to_user_id" : 351390617,
  "text" : "@SophiaKhan4 @teacherphili @TESOLacademic @iatefl @iateflonline u cld try following @TESOL_IATEFL_50",
  "id" : 719914498660896768,
  "in_reply_to_status_id" : 719913198497849344,
  "created_at" : "2016-04-12 15:46:06 +0000",
  "in_reply_to_screen_name" : "SophiaKhan4",
  "in_reply_to_user_id_str" : "351390617",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Apps 4 EFL",
      "screen_name" : "apps4efl",
      "indices" : [ 0, 9 ],
      "id_str" : "2594237072",
      "id" : 2594237072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "719838749803196417",
  "geo" : { },
  "id_str" : "719855336778244098",
  "in_reply_to_user_id" : 2594237072,
  "text" : "@apps4efl no worries have added it to ideas dataset doc",
  "id" : 719855336778244098,
  "in_reply_to_status_id" : 719838749803196417,
  "created_at" : "2016-04-12 11:51:01 +0000",
  "in_reply_to_screen_name" : "apps4efl",
  "in_reply_to_user_id_str" : "2594237072",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Noble",
      "screen_name" : "tesolmatthew",
      "indices" : [ 0, 13 ],
      "id_str" : "1519875330",
      "id" : 1519875330
    }, {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 14, 30 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "719388583627333633",
  "geo" : { },
  "id_str" : "719672484656738308",
  "in_reply_to_user_id" : 1519875330,
  "text" : "@tesolmatthew @michaelegriffin was he reading it upside down before passing out you think?",
  "id" : 719672484656738308,
  "in_reply_to_status_id" : 719388583627333633,
  "created_at" : "2016-04-11 23:44:25 +0000",
  "in_reply_to_screen_name" : "tesolmatthew",
  "in_reply_to_user_id_str" : "1519875330",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "719669374341234688",
  "text" : "RT @pchallinor: Our Davey is purple and podgy\nAnd pinky and stinky and stodgy\nAnd smarmy and smirky,\nMendacious and murky,\nDuplicitous, dir\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "719667596736520192",
    "text" : "Our Davey is purple and podgy\nAnd pinky and stinky and stodgy\nAnd smarmy and smirky,\nMendacious and murky,\nDuplicitous, dirty and dodgy.",
    "id" : 719667596736520192,
    "created_at" : "2016-04-11 23:25:00 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 719669374341234688,
  "created_at" : "2016-04-11 23:32:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Patricia Brenes",
      "screen_name" : "patriciambr",
      "indices" : [ 10, 22 ],
      "id_str" : "35764443",
      "id" : 35764443
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "718179195323437056",
  "geo" : { },
  "id_str" : "719664920036556800",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava @patriciambr thanks for sharing : )",
  "id" : 719664920036556800,
  "in_reply_to_status_id" : 718179195323437056,
  "created_at" : "2016-04-11 23:14:22 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/66ux7W7JOG",
      "expanded_url" : "http:\/\/eapcreatively.blogspot.com\/2016\/04\/introduction-to-writing.html?spref=tw",
      "display_url" : "eapcreatively.blogspot.com\/2016\/04\/introd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "719664705623703552",
  "text" : "English for Academic Purposes Creatively   : Introduction to writing https:\/\/t.co\/66ux7W7JOG",
  "id" : 719664705623703552,
  "created_at" : "2016-04-11 23:13:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "languagetrivia",
      "indices" : [ 0, 15 ]
    } ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/RIGhmBmfBf",
      "expanded_url" : "https:\/\/twitter.com\/Glenn_Hadikin\/status\/718912655273127936",
      "display_url" : "twitter.com\/Glenn_Hadikin\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "719594118960279552",
  "text" : "#languagetrivia https:\/\/t.co\/RIGhmBmfBf",
  "id" : 719594118960279552,
  "created_at" : "2016-04-11 18:33:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AskZac",
      "indices" : [ 16, 23 ]
    } ],
    "urls" : [ {
      "indices" : [ 125, 140 ],
      "url" : "https:\/\/t.co\/zq2pkkdNsF",
      "expanded_url" : "http:\/\/www.theguardian.com\/uk-news\/2016\/apr\/11\/british-muslims-strong-sense-of-belonging-poll-homosexuality-sharia-law",
      "display_url" : "theguardian.com\/uk-news\/2016\/a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "719578412906627074",
  "text" : "RT @pchallinor: #AskZac I take it your next non-divisive Crosbygram will be claiming that half of Sadiq Khan is a homophobe? https:\/\/t.co\/z\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AskZac",
        "indices" : [ 0, 7 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/zq2pkkdNsF",
        "expanded_url" : "http:\/\/www.theguardian.com\/uk-news\/2016\/apr\/11\/british-muslims-strong-sense-of-belonging-poll-homosexuality-sharia-law",
        "display_url" : "theguardian.com\/uk-news\/2016\/a\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "719569226755940352",
    "text" : "#AskZac I take it your next non-divisive Crosbygram will be claiming that half of Sadiq Khan is a homophobe? https:\/\/t.co\/zq2pkkdNsF",
    "id" : 719569226755940352,
    "created_at" : "2016-04-11 16:54:07 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 719578412906627074,
  "created_at" : "2016-04-11 17:30:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenny Lewin-Jones",
      "screen_name" : "JennyLewinJones",
      "indices" : [ 0, 16 ],
      "id_str" : "1484808264",
      "id" : 1484808264
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/WpfQrcy7Oj",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/Social_currency",
      "display_url" : "en.wikipedia.org\/wiki\/Social_cu\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "719506509735010305",
  "geo" : { },
  "id_str" : "719508510820667392",
  "in_reply_to_user_id" : 1484808264,
  "text" : "@JennyLewinJones social currency is the \"positive\" term to this https:\/\/t.co\/WpfQrcy7Oj",
  "id" : 719508510820667392,
  "in_reply_to_status_id" : 719506509735010305,
  "created_at" : "2016-04-11 12:52:51 +0000",
  "in_reply_to_screen_name" : "JennyLewinJones",
  "in_reply_to_user_id_str" : "1484808264",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kenneth Roth",
      "screen_name" : "KenRoth",
      "indices" : [ 3, 11 ],
      "id_str" : "17839398",
      "id" : 17839398
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/KenRoth\/status\/719330670233985025\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/7faBwJSCUF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfuTbsgUkAAXtOa.jpg",
      "id_str" : "719330669508202496",
      "id" : 719330669508202496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfuTbsgUkAAXtOa.jpg",
      "sizes" : [ {
        "h" : 168,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 168,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 168,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 168,
        "resize" : "fit",
        "w" : 300
      } ],
      "display_url" : "pic.twitter.com\/7faBwJSCUF"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/N216VbLKEN",
      "expanded_url" : "http:\/\/bit.ly\/1N2YZCX",
      "display_url" : "bit.ly\/1N2YZCX"
    } ]
  },
  "geo" : { },
  "id_str" : "719507165946454016",
  "text" : "RT @KenRoth: Ex Abu Ghraib interrogator says Israelis taught the \"Palestinian chair\" torture technique. https:\/\/t.co\/N216VbLKEN https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/KenRoth\/status\/719330670233985025\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/7faBwJSCUF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CfuTbsgUkAAXtOa.jpg",
        "id_str" : "719330669508202496",
        "id" : 719330669508202496,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfuTbsgUkAAXtOa.jpg",
        "sizes" : [ {
          "h" : 168,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 168,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 168,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 168,
          "resize" : "fit",
          "w" : 300
        } ],
        "display_url" : "pic.twitter.com\/7faBwJSCUF"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/N216VbLKEN",
        "expanded_url" : "http:\/\/bit.ly\/1N2YZCX",
        "display_url" : "bit.ly\/1N2YZCX"
      } ]
    },
    "geo" : { },
    "id_str" : "719330670233985025",
    "text" : "Ex Abu Ghraib interrogator says Israelis taught the \"Palestinian chair\" torture technique. https:\/\/t.co\/N216VbLKEN https:\/\/t.co\/7faBwJSCUF",
    "id" : 719330670233985025,
    "created_at" : "2016-04-11 01:06:10 +0000",
    "user" : {
      "name" : "Kenneth Roth",
      "screen_name" : "KenRoth",
      "protected" : false,
      "id_str" : "17839398",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/759478721808068608\/F5s3fgyl_normal.jpg",
      "id" : 17839398,
      "verified" : true
    }
  },
  "id" : 719507165946454016,
  "created_at" : "2016-04-11 12:47:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "halfjoking",
      "indices" : [ 111, 122 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "717668625524523008",
  "geo" : { },
  "id_str" : "719501679163547648",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow Can we say for example \"failure\" to do what teacher says shows students are already autonomous : ) #halfjoking",
  "id" : 719501679163547648,
  "in_reply_to_status_id" : 717668625524523008,
  "created_at" : "2016-04-11 12:25:42 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Raine",
      "screen_name" : "paul_sensei",
      "indices" : [ 0, 12 ],
      "id_str" : "176429301",
      "id" : 176429301
    }, {
      "name" : "Apps 4 EFL",
      "screen_name" : "apps4efl",
      "indices" : [ 13, 22 ],
      "id_str" : "2594237072",
      "id" : 2594237072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/mIqrOTypaQ",
      "expanded_url" : "https:\/\/twitter.com\/heatherfro\/status\/719493391508180992",
      "display_url" : "twitter.com\/heatherfro\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "719495502132326400",
  "in_reply_to_user_id" : 176429301,
  "text" : "@paul_sensei @apps4efl  https:\/\/t.co\/mIqrOTypaQ",
  "id" : 719495502132326400,
  "created_at" : "2016-04-11 12:01:09 +0000",
  "in_reply_to_screen_name" : "paul_sensei",
  "in_reply_to_user_id_str" : "176429301",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Gallagher",
      "screen_name" : "rj_gallagher",
      "indices" : [ 3, 16 ],
      "id_str" : "224698363",
      "id" : 224698363
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 147, 148 ],
      "url" : "https:\/\/t.co\/8ChUZ2B4iD",
      "expanded_url" : "http:\/\/www.theguardian.com\/world\/2016\/apr\/10\/immigration-officials-can-hack-refugees-phones",
      "display_url" : "theguardian.com\/world\/2016\/apr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "719480644607324160",
  "text" : "RT @rj_gallagher: UK immigration officials \"permitted to hack phones of refugees &amp; asylum seekers, including rape &amp; torture victims\": https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 124, 147 ],
        "url" : "https:\/\/t.co\/8ChUZ2B4iD",
        "expanded_url" : "http:\/\/www.theguardian.com\/world\/2016\/apr\/10\/immigration-officials-can-hack-refugees-phones",
        "display_url" : "theguardian.com\/world\/2016\/apr\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "719186256874356736",
    "text" : "UK immigration officials \"permitted to hack phones of refugees &amp; asylum seekers, including rape &amp; torture victims\": https:\/\/t.co\/8ChUZ2B4iD",
    "id" : 719186256874356736,
    "created_at" : "2016-04-10 15:32:20 +0000",
    "user" : {
      "name" : "Ryan Gallagher",
      "screen_name" : "rj_gallagher",
      "protected" : false,
      "id_str" : "224698363",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/560095880720568322\/ls_jqSNo_normal.png",
      "id" : 224698363,
      "verified" : true
    }
  },
  "id" : 719480644607324160,
  "created_at" : "2016-04-11 11:02:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Natallia Novikava",
      "screen_name" : "Natashetta",
      "indices" : [ 0, 11 ],
      "id_str" : "56308635",
      "id" : 56308635
    }, {
      "name" : "Rachael TESOL",
      "screen_name" : "RachaelTESOL",
      "indices" : [ 12, 25 ],
      "id_str" : "537057787",
      "id" : 537057787
    }, {
      "name" : "Savant English",
      "screen_name" : "savant_app",
      "indices" : [ 26, 37 ],
      "id_str" : "716813334763278337",
      "id" : 716813334763278337
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "718710458639872001",
  "geo" : { },
  "id_str" : "719476461346897920",
  "in_reply_to_user_id" : 56308635,
  "text" : "@Natashetta @RachaelTESOL @savant_app thanks for sharing : )",
  "id" : 719476461346897920,
  "in_reply_to_status_id" : 718710458639872001,
  "created_at" : "2016-04-11 10:45:30 +0000",
  "in_reply_to_screen_name" : "Natashetta",
  "in_reply_to_user_id_str" : "56308635",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Pickles",
      "screen_name" : "efl101",
      "indices" : [ 3, 10 ],
      "id_str" : "122995652",
      "id" : 122995652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/GKfWr0Tmw4",
      "expanded_url" : "http:\/\/bit.ly\/1VhL2U9",
      "display_url" : "bit.ly\/1VhL2U9"
    } ]
  },
  "geo" : { },
  "id_str" : "719467386068418560",
  "text" : "RT @efl101: SERP | Word Generation - Home https:\/\/t.co\/GKfWr0Tmw4 - topical lessons to build vocabulary - free",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/bitly.com\/\" rel=\"nofollow\"\u003EBitly\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 30, 53 ],
        "url" : "https:\/\/t.co\/GKfWr0Tmw4",
        "expanded_url" : "http:\/\/bit.ly\/1VhL2U9",
        "display_url" : "bit.ly\/1VhL2U9"
      } ]
    },
    "geo" : { },
    "id_str" : "719445938880802816",
    "text" : "SERP | Word Generation - Home https:\/\/t.co\/GKfWr0Tmw4 - topical lessons to build vocabulary - free",
    "id" : 719445938880802816,
    "created_at" : "2016-04-11 08:44:13 +0000",
    "user" : {
      "name" : "Andrew Pickles",
      "screen_name" : "efl101",
      "protected" : false,
      "id_str" : "122995652",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/558273414750670848\/lVnXLNr5_normal.jpeg",
      "id" : 122995652,
      "verified" : false
    }
  },
  "id" : 719467386068418560,
  "created_at" : "2016-04-11 10:09:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Pickles",
      "screen_name" : "efl101",
      "indices" : [ 0, 7 ],
      "id_str" : "122995652",
      "id" : 122995652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "719445938880802816",
  "geo" : { },
  "id_str" : "719465659067985920",
  "in_reply_to_user_id" : 122995652,
  "text" : "@efl101 thanks these material look good have you used any?",
  "id" : 719465659067985920,
  "in_reply_to_status_id" : 719445938880802816,
  "created_at" : "2016-04-11 10:02:34 +0000",
  "in_reply_to_screen_name" : "efl101",
  "in_reply_to_user_id_str" : "122995652",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Cantarutti",
      "screen_name" : "pronbites",
      "indices" : [ 3, 13 ],
      "id_str" : "2451770871",
      "id" : 2451770871
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/AFmJYIC9w1",
      "expanded_url" : "http:\/\/fb.me\/7kJREPtcs",
      "display_url" : "fb.me\/7kJREPtcs"
    } ]
  },
  "geo" : { },
  "id_str" : "719463516185473024",
  "text" : "RT @pronbites: New post! English Word Stress mess makes you feel stressed? Pronunciation Integration 3: Word Stress and Word... https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/AFmJYIC9w1",
        "expanded_url" : "http:\/\/fb.me\/7kJREPtcs",
        "display_url" : "fb.me\/7kJREPtcs"
      } ]
    },
    "geo" : { },
    "id_str" : "719345896480206848",
    "text" : "New post! English Word Stress mess makes you feel stressed? Pronunciation Integration 3: Word Stress and Word... https:\/\/t.co\/AFmJYIC9w1",
    "id" : 719345896480206848,
    "created_at" : "2016-04-11 02:06:41 +0000",
    "user" : {
      "name" : "Marina Cantarutti",
      "screen_name" : "pronbites",
      "protected" : false,
      "id_str" : "2451770871",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744911290766868480\/VQAhoA7h_normal.jpg",
      "id" : 2451770871,
      "verified" : false
    }
  },
  "id" : 719463516185473024,
  "created_at" : "2016-04-11 09:54:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vedrana Vojkovi\u0107",
      "screen_name" : "Ven_VVE",
      "indices" : [ 0, 8 ],
      "id_str" : "270839603",
      "id" : 270839603
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "719282870058164224",
  "geo" : { },
  "id_str" : "719283469910679557",
  "in_reply_to_user_id" : 270839603,
  "text" : "@Ven_VVE yeah i usually say edu-pieceofpoodontwork-roam : )",
  "id" : 719283469910679557,
  "in_reply_to_status_id" : 719282870058164224,
  "created_at" : "2016-04-10 21:58:37 +0000",
  "in_reply_to_screen_name" : "Ven_VVE",
  "in_reply_to_user_id_str" : "270839603",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Poole",
      "screen_name" : "RobertEPoole",
      "indices" : [ 0, 13 ],
      "id_str" : "18526186",
      "id" : 18526186
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/719279155595100160\/photo\/1",
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/9pCROkYEr2",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CftkhagW4AApVSc.jpg",
      "id_str" : "719279090709225472",
      "id" : 719279090709225472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CftkhagW4AApVSc.jpg",
      "sizes" : [ {
        "h" : 176,
        "resize" : "fit",
        "w" : 176
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 176,
        "resize" : "fit",
        "w" : 176
      }, {
        "h" : 176,
        "resize" : "fit",
        "w" : 176
      }, {
        "h" : 176,
        "resize" : "fit",
        "w" : 176
      } ],
      "display_url" : "pic.twitter.com\/9pCROkYEr2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "719277167381753856",
  "geo" : { },
  "id_str" : "719279155595100160",
  "in_reply_to_user_id" : 18526186,
  "text" : "@RobertEPoole https:\/\/t.co\/9pCROkYEr2",
  "id" : 719279155595100160,
  "in_reply_to_status_id" : 719277167381753856,
  "created_at" : "2016-04-10 21:41:28 +0000",
  "in_reply_to_screen_name" : "RobertEPoole",
  "in_reply_to_user_id_str" : "18526186",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "languagetrivia",
      "indices" : [ 0, 15 ]
    } ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/Xxsm7hMpx8",
      "expanded_url" : "https:\/\/twitter.com\/ConceptCzech\/status\/716000773348454400",
      "display_url" : "twitter.com\/ConceptCzech\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "719272842492264448",
  "text" : "#languagetrivia https:\/\/t.co\/Xxsm7hMpx8",
  "id" : 719272842492264448,
  "created_at" : "2016-04-10 21:16:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "languagetrivia",
      "indices" : [ 0, 15 ]
    } ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/j7NjMLRMMS",
      "expanded_url" : "https:\/\/twitter.com\/dreadnought001\/status\/719266835695280128",
      "display_url" : "twitter.com\/dreadnought001\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "719270844359385090",
  "text" : "#languagetrivia https:\/\/t.co\/j7NjMLRMMS",
  "id" : 719270844359385090,
  "created_at" : "2016-04-10 21:08:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    }, {
      "name" : "Tim Fenton",
      "screen_name" : "zelo_street",
      "indices" : [ 96, 108 ],
      "id_str" : "217844980",
      "id" : 217844980
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/bJitxanXjk",
      "expanded_url" : "https:\/\/www.byline.com\/project\/48\/article\/966",
      "display_url" : "byline.com\/project\/48\/art\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "719248426727301121",
  "text" : "RT @pchallinor: The Cultchah Sec, the dominatrix and the Free Press https:\/\/t.co\/bJitxanXjk via @zelo_street",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tim Fenton",
        "screen_name" : "zelo_street",
        "indices" : [ 80, 92 ],
        "id_str" : "217844980",
        "id" : 217844980
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 75 ],
        "url" : "https:\/\/t.co\/bJitxanXjk",
        "expanded_url" : "https:\/\/www.byline.com\/project\/48\/article\/966",
        "display_url" : "byline.com\/project\/48\/art\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "719247594929668096",
    "text" : "The Cultchah Sec, the dominatrix and the Free Press https:\/\/t.co\/bJitxanXjk via @zelo_street",
    "id" : 719247594929668096,
    "created_at" : "2016-04-10 19:36:04 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 719248426727301121,
  "created_at" : "2016-04-10 19:39:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darius Kazemi",
      "screen_name" : "tinysubversions",
      "indices" : [ 0, 16 ],
      "id_str" : "14475298",
      "id" : 14475298
    }, {
      "name" : "Allison Parrish",
      "screen_name" : "aparrish",
      "indices" : [ 17, 26 ],
      "id_str" : "6857962",
      "id" : 6857962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "719247824798498816",
  "geo" : { },
  "id_str" : "719248236200988672",
  "in_reply_to_user_id" : 14475298,
  "text" : "@tinysubversions @aparrish get on the case! : )",
  "id" : 719248236200988672,
  "in_reply_to_status_id" : 719247824798498816,
  "created_at" : "2016-04-10 19:38:37 +0000",
  "in_reply_to_screen_name" : "tinysubversions",
  "in_reply_to_user_id_str" : "14475298",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allison Parrish",
      "screen_name" : "aparrish",
      "indices" : [ 0, 9 ],
      "id_str" : "6857962",
      "id" : 6857962
    }, {
      "name" : "Darius Kazemi",
      "screen_name" : "tinysubversions",
      "indices" : [ 10, 26 ],
      "id_str" : "14475298",
      "id" : 14475298
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "719246800595599361",
  "in_reply_to_user_id" : 6857962,
  "text" : "@aparrish @tinysubversions hi r there any twitter bots that tweet based on recognising images in tweets?",
  "id" : 719246800595599361,
  "created_at" : "2016-04-10 19:32:54 +0000",
  "in_reply_to_screen_name" : "aparrish",
  "in_reply_to_user_id_str" : "6857962",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/719239850478694405\/photo\/1",
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/AX7B4AcdJ5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CftA1PLWwAAfXvm.jpg",
      "id_str" : "719239848847130624",
      "id" : 719239848847130624,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CftA1PLWwAAfXvm.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 63,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 1364
      }, {
        "h" : 112,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/AX7B4AcdJ5"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/ngrkoPwr3j",
      "expanded_url" : "http:\/\/cfgg.decontextualize.com\/gen.html?key=1s-uCFGAck3a7L-cfRUpfT2En92wcxxiXnN2g1S5Jjug",
      "display_url" : "cfgg.decontextualize.com\/gen.html?key=1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "719239850478694405",
  "text" : "Vive Game of Charlies https:\/\/t.co\/ngrkoPwr3j https:\/\/t.co\/AX7B4AcdJ5",
  "id" : 719239850478694405,
  "created_at" : "2016-04-10 19:05:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/719239407971250177\/photo\/1",
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/3cJ7UX3F50",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CftAbRLWQAAmS0N.jpg",
      "id_str" : "719239402707369984",
      "id" : 719239402707369984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CftAbRLWQAAmS0N.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 105,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 180,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 233,
        "resize" : "fit",
        "w" : 1329
      }, {
        "h" : 60,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/3cJ7UX3F50"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/ngrkoPwr3j",
      "expanded_url" : "http:\/\/cfgg.decontextualize.com\/gen.html?key=1s-uCFGAck3a7L-cfRUpfT2En92wcxxiXnN2g1S5Jjug",
      "display_url" : "cfgg.decontextualize.com\/gen.html?key=1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "719239407971250177",
  "text" : "Vive Game of Charlies https:\/\/t.co\/ngrkoPwr3j https:\/\/t.co\/3cJ7UX3F50",
  "id" : 719239407971250177,
  "created_at" : "2016-04-10 19:03:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Poole",
      "screen_name" : "RobertEPoole",
      "indices" : [ 0, 13 ],
      "id_str" : "18526186",
      "id" : 18526186
    }, {
      "name" : "natiserhost197",
      "screen_name" : "esl_robert",
      "indices" : [ 14, 25 ],
      "id_str" : "2982357761",
      "id" : 2982357761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "719230506878038016",
  "geo" : { },
  "id_str" : "719231540488704000",
  "in_reply_to_user_id" : 18526186,
  "text" : "@RobertEPoole @esl_robert kk : ) how did the talk go?",
  "id" : 719231540488704000,
  "in_reply_to_status_id" : 719230506878038016,
  "created_at" : "2016-04-10 18:32:16 +0000",
  "in_reply_to_screen_name" : "RobertEPoole",
  "in_reply_to_user_id_str" : "18526186",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "natiserhost197",
      "screen_name" : "esl_robert",
      "indices" : [ 0, 11 ],
      "id_str" : "2982357761",
      "id" : 2982357761
    }, {
      "name" : "Robert Poole",
      "screen_name" : "RobertEPoole",
      "indices" : [ 12, 25 ],
      "id_str" : "18526186",
      "id" : 18526186
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "719228864678010881",
  "geo" : { },
  "id_str" : "719230101074886656",
  "in_reply_to_user_id" : 18602422,
  "text" : "@esl_robert @RobertEPoole hi Robert is that first twitter handle good?",
  "id" : 719230101074886656,
  "in_reply_to_status_id" : 719228864678010881,
  "created_at" : "2016-04-10 18:26:33 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Aysegul Liman Kaban",
      "screen_name" : "Aysegul_Kaban",
      "indices" : [ 10, 24 ],
      "id_str" : "1389180271",
      "id" : 1389180271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "718179195323437056",
  "geo" : { },
  "id_str" : "719229713210830848",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava @Aysegul_Kaban thanks : )",
  "id" : 719229713210830848,
  "in_reply_to_status_id" : 718179195323437056,
  "created_at" : "2016-04-10 18:25:00 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kamila Linkov\u00E1",
      "screen_name" : "kamilaofprague",
      "indices" : [ 0, 15 ],
      "id_str" : "3439998148",
      "id" : 3439998148
    }, {
      "name" : "Matthew Noble",
      "screen_name" : "tesolmatthew",
      "indices" : [ 16, 29 ],
      "id_str" : "1519875330",
      "id" : 1519875330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "719228416344657924",
  "geo" : { },
  "id_str" : "719229458046132224",
  "in_reply_to_user_id" : 3439998148,
  "text" : "@kamilaofprague @tesolmatthew twitter for the win : )",
  "id" : 719229458046132224,
  "in_reply_to_status_id" : 719228416344657924,
  "created_at" : "2016-04-10 18:24:00 +0000",
  "in_reply_to_screen_name" : "kamilaofprague",
  "in_reply_to_user_id_str" : "3439998148",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "natiserhost197",
      "screen_name" : "esl_robert",
      "indices" : [ 97, 108 ],
      "id_str" : "2982357761",
      "id" : 2982357761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/09UuzxiHpR",
      "expanded_url" : "https:\/\/repoole.wordpress.com\/2016\/04\/10\/aaal-2016-implementing-specialized-corpora-in-l2-classrooms\/",
      "display_url" : "repoole.wordpress.com\/2016\/04\/10\/aaa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "719228864678010881",
  "text" : "AAAL 2016: Implementing Specialized Corpora in L2 Writing Classrooms https:\/\/t.co\/09UuzxiHpR via @esl_robert",
  "id" : 719228864678010881,
  "created_at" : "2016-04-10 18:21:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Noble",
      "screen_name" : "tesolmatthew",
      "indices" : [ 0, 13 ],
      "id_str" : "1519875330",
      "id" : 1519875330
    }, {
      "name" : "Kamila Linkov\u00E1",
      "screen_name" : "kamilaofprague",
      "indices" : [ 14, 29 ],
      "id_str" : "3439998148",
      "id" : 3439998148
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/qHUI9H2LHI",
      "expanded_url" : "http:\/\/corpus.byu.edu\/coca\/?c=coca&q=46712279",
      "display_url" : "corpus.byu.edu\/coca\/?c=coca&q\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "719222880806940673",
  "geo" : { },
  "id_str" : "719224029941493762",
  "in_reply_to_user_id" : 1519875330,
  "text" : "@tesolmatthew @kamilaofprague COCA seems to support Matthew's response https:\/\/t.co\/qHUI9H2LHI",
  "id" : 719224029941493762,
  "in_reply_to_status_id" : 719222880806940673,
  "created_at" : "2016-04-10 18:02:25 +0000",
  "in_reply_to_screen_name" : "tesolmatthew",
  "in_reply_to_user_id_str" : "1519875330",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 13, 20 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/CyWuuJqJNm",
      "expanded_url" : "https:\/\/eflnotes.wordpress.com\/2016\/04\/07\/iatefl-2016-corpus-related-mini-interviews\/",
      "display_url" : "eflnotes.wordpress.com\/2016\/04\/07\/iat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "719142518768693248",
  "text" : "2 more added #IATEFL 2016 - corpus related mini-interviews https:\/\/t.co\/CyWuuJqJNm",
  "id" : 719142518768693248,
  "created_at" : "2016-04-10 12:38:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bret Victor",
      "screen_name" : "worrydream",
      "indices" : [ 3, 14 ],
      "id_str" : "255617445",
      "id" : 255617445
    }, {
      "name" : "William Coletto",
      "screen_name" : "willisbueller",
      "indices" : [ 16, 30 ],
      "id_str" : "347344082",
      "id" : 347344082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/czmNyt0AY7",
      "expanded_url" : "http:\/\/explorableexplanations.com",
      "display_url" : "explorableexplanations.com"
    } ]
  },
  "geo" : { },
  "id_str" : "719137741129256961",
  "text" : "RT @worrydream: @willisbueller https:\/\/t.co\/czmNyt0AY7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "William Coletto",
        "screen_name" : "willisbueller",
        "indices" : [ 0, 14 ],
        "id_str" : "347344082",
        "id" : 347344082
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 15, 38 ],
        "url" : "https:\/\/t.co\/czmNyt0AY7",
        "expanded_url" : "http:\/\/explorableexplanations.com",
        "display_url" : "explorableexplanations.com"
      } ]
    },
    "in_reply_to_status_id_str" : "718275377148338176",
    "geo" : { },
    "id_str" : "718279820283654145",
    "in_reply_to_user_id" : 347344082,
    "text" : "@willisbueller https:\/\/t.co\/czmNyt0AY7",
    "id" : 718279820283654145,
    "in_reply_to_status_id" : 718275377148338176,
    "created_at" : "2016-04-08 03:30:28 +0000",
    "in_reply_to_screen_name" : "willisbueller",
    "in_reply_to_user_id_str" : "347344082",
    "user" : {
      "name" : "Bret Victor",
      "screen_name" : "worrydream",
      "protected" : false,
      "id_str" : "255617445",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/767981637623685120\/7WgbPNE9_normal.jpg",
      "id" : 255617445,
      "verified" : false
    }
  },
  "id" : 719137741129256961,
  "created_at" : "2016-04-10 12:19:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jan Oliver R\u00FCdiger",
      "screen_name" : "notesJOR",
      "indices" : [ 3, 12 ],
      "id_str" : "2382676952",
      "id" : 2382676952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/MwPf74QmqX",
      "expanded_url" : "http:\/\/notes.jan-oliver-ruediger.de\/corpusexplorer-v2-0-april-update\/",
      "display_url" : "notes.jan-oliver-ruediger.de\/corpusexplorer\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "719135285867606017",
  "text" : "RT @notesJOR: CorpusExplorer v2.0 \u2013 April\u00A0Update https:\/\/t.co\/MwPf74QmqX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 58 ],
        "url" : "https:\/\/t.co\/MwPf74QmqX",
        "expanded_url" : "http:\/\/notes.jan-oliver-ruediger.de\/corpusexplorer-v2-0-april-update\/",
        "display_url" : "notes.jan-oliver-ruediger.de\/corpusexplorer\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "718878461100601344",
    "text" : "CorpusExplorer v2.0 \u2013 April\u00A0Update https:\/\/t.co\/MwPf74QmqX",
    "id" : 718878461100601344,
    "created_at" : "2016-04-09 19:09:15 +0000",
    "user" : {
      "name" : "Jan Oliver R\u00FCdiger",
      "screen_name" : "notesJOR",
      "protected" : false,
      "id_str" : "2382676952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/473570675542618112\/OMt7J5tr_normal.png",
      "id" : 2382676952,
      "verified" : false
    }
  },
  "id" : 719135285867606017,
  "created_at" : "2016-04-10 12:09:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ian bremmer",
      "screen_name" : "ianbremmer",
      "indices" : [ 3, 14 ],
      "id_str" : "60783724",
      "id" : 60783724
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/ianbremmer\/status\/718807562733223937\/photo\/1",
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/EPHMrgq7HE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cfm3qnjVIAM0QqX.jpg",
      "id_str" : "718807558341861379",
      "id" : 718807558341861379,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cfm3qnjVIAM0QqX.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 229,
        "resize" : "fit",
        "w" : 380
      }, {
        "h" : 205,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 229,
        "resize" : "fit",
        "w" : 380
      }, {
        "h" : 229,
        "resize" : "fit",
        "w" : 380
      } ],
      "display_url" : "pic.twitter.com\/EPHMrgq7HE"
    } ],
    "hashtags" : [ {
      "text" : "PanamaPapers",
      "indices" : [ 49, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "719133254218031104",
  "text" : "RT @ianbremmer: The best explanation of the week #PanamaPapers https:\/\/t.co\/EPHMrgq7HE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ianbremmer\/status\/718807562733223937\/photo\/1",
        "indices" : [ 47, 70 ],
        "url" : "https:\/\/t.co\/EPHMrgq7HE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cfm3qnjVIAM0QqX.jpg",
        "id_str" : "718807558341861379",
        "id" : 718807558341861379,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cfm3qnjVIAM0QqX.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 229,
          "resize" : "fit",
          "w" : 380
        }, {
          "h" : 205,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 229,
          "resize" : "fit",
          "w" : 380
        }, {
          "h" : 229,
          "resize" : "fit",
          "w" : 380
        } ],
        "display_url" : "pic.twitter.com\/EPHMrgq7HE"
      } ],
      "hashtags" : [ {
        "text" : "PanamaPapers",
        "indices" : [ 33, 46 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "718807562733223937",
    "text" : "The best explanation of the week #PanamaPapers https:\/\/t.co\/EPHMrgq7HE",
    "id" : 718807562733223937,
    "created_at" : "2016-04-09 14:27:32 +0000",
    "user" : {
      "name" : "ian bremmer",
      "screen_name" : "ianbremmer",
      "protected" : false,
      "id_str" : "60783724",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/760130489353134080\/vPLJkNWY_normal.jpg",
      "id" : 60783724,
      "verified" : true
    }
  },
  "id" : 719133254218031104,
  "created_at" : "2016-04-10 12:01:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helen Legge",
      "screen_name" : "ITLegge",
      "indices" : [ 0, 8 ],
      "id_str" : "2201561838",
      "id" : 2201561838
    }, {
      "name" : "bot",
      "screen_name" : "TESOL_IATEFL_50",
      "indices" : [ 34, 50 ],
      "id_str" : "710852790948642817",
      "id" : 710852790948642817
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "719072535606898688",
  "geo" : { },
  "id_str" : "719075800432144384",
  "in_reply_to_user_id" : 2201561838,
  "text" : "@ITLegge yr welcome there is also @TESOL_IATEFL_50",
  "id" : 719075800432144384,
  "in_reply_to_status_id" : 719072535606898688,
  "created_at" : "2016-04-10 08:13:25 +0000",
  "in_reply_to_screen_name" : "ITLegge",
  "in_reply_to_user_id_str" : "2201561838",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AlterNet",
      "screen_name" : "AlterNet",
      "indices" : [ 90, 99 ],
      "id_str" : "18851248",
      "id" : 18851248
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/BPSdeLT9z2",
      "expanded_url" : "http:\/\/www.alternet.org\/grayzone-project\/under-guise-saving-them-french-elites-declare-open-season-attacking-muslim-women",
      "display_url" : "alternet.org\/grayzone-proje\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "719068364728070145",
  "text" : "Under Guise of 'Saving' Them, French Elites Declare Open Season on Attacking Muslim Women @alternet https:\/\/t.co\/BPSdeLT9z2",
  "id" : 719068364728070145,
  "created_at" : "2016-04-10 07:43:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/A9i76sR6Nb",
      "expanded_url" : "http:\/\/www.mintpressnews.com\/213478-2\/213478\/",
      "display_url" : "mintpressnews.com\/213478-2\/21347\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "719062058449379328",
  "text" : "RT @johnwhilley: British Doctors Demand Israel\u2019s Expulsion From World Medical Association https:\/\/t.co\/A9i76sR6Nb \nPlease share",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/A9i76sR6Nb",
        "expanded_url" : "http:\/\/www.mintpressnews.com\/213478-2\/213478\/",
        "display_url" : "mintpressnews.com\/213478-2\/21347\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "719037305588224001",
    "text" : "British Doctors Demand Israel\u2019s Expulsion From World Medical Association https:\/\/t.co\/A9i76sR6Nb \nPlease share",
    "id" : 719037305588224001,
    "created_at" : "2016-04-10 05:40:27 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 719062058449379328,
  "created_at" : "2016-04-10 07:18:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "4TUNE Teller App",
      "screen_name" : "4tunetellernet",
      "indices" : [ 3, 18 ],
      "id_str" : "467634146",
      "id" : 467634146
    }, {
      "name" : "LOUDNESS_OFFICIAL",
      "screen_name" : "LOUDNESS_INFO",
      "indices" : [ 58, 72 ],
      "id_str" : "314704213",
      "id" : 314704213
    }, {
      "name" : "BABYMETAL",
      "screen_name" : "BABYMETAL_JAPAN",
      "indices" : [ 110, 126 ],
      "id_str" : "413253370",
      "id" : 413253370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/VPu9woBe9K",
      "expanded_url" : "https:\/\/youtu.be\/GvD3CHA48pA",
      "display_url" : "youtu.be\/GvD3CHA48pA"
    } ]
  },
  "geo" : { },
  "id_str" : "718921164287000581",
  "text" : "RT @4tunetellernet: From someone who grew up listening to @LOUDNESS_INFO (Japanese metal) , I'm fascinated w\/ @BABYMETAL_JAPAN https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "LOUDNESS_OFFICIAL",
        "screen_name" : "LOUDNESS_INFO",
        "indices" : [ 38, 52 ],
        "id_str" : "314704213",
        "id" : 314704213
      }, {
        "name" : "BABYMETAL",
        "screen_name" : "BABYMETAL_JAPAN",
        "indices" : [ 90, 106 ],
        "id_str" : "413253370",
        "id" : 413253370
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/VPu9woBe9K",
        "expanded_url" : "https:\/\/youtu.be\/GvD3CHA48pA",
        "display_url" : "youtu.be\/GvD3CHA48pA"
      } ]
    },
    "geo" : { },
    "id_str" : "718919518958051328",
    "text" : "From someone who grew up listening to @LOUDNESS_INFO (Japanese metal) , I'm fascinated w\/ @BABYMETAL_JAPAN https:\/\/t.co\/VPu9woBe9K",
    "id" : 718919518958051328,
    "created_at" : "2016-04-09 21:52:24 +0000",
    "user" : {
      "name" : "4TUNE Teller App",
      "screen_name" : "4tunetellernet",
      "protected" : false,
      "id_str" : "467634146",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/638018712629592065\/i8nHx3y0_normal.png",
      "id" : 467634146,
      "verified" : false
    }
  },
  "id" : 718921164287000581,
  "created_at" : "2016-04-09 21:58:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "4TUNE Teller App",
      "screen_name" : "4tunetellernet",
      "indices" : [ 0, 15 ],
      "id_str" : "467634146",
      "id" : 467634146
    }, {
      "name" : "LOUDNESS_OFFICIAL",
      "screen_name" : "LOUDNESS_INFO",
      "indices" : [ 16, 30 ],
      "id_str" : "314704213",
      "id" : 314704213
    }, {
      "name" : "BABYMETAL",
      "screen_name" : "BABYMETAL_JAPAN",
      "indices" : [ 31, 47 ],
      "id_str" : "413253370",
      "id" : 413253370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "718919518958051328",
  "geo" : { },
  "id_str" : "718920563830472705",
  "in_reply_to_user_id" : 467634146,
  "text" : "@4tunetellernet @LOUDNESS_INFO @BABYMETAL_JAPAN AWESOME!!!",
  "id" : 718920563830472705,
  "in_reply_to_status_id" : 718919518958051328,
  "created_at" : "2016-04-09 21:56:33 +0000",
  "in_reply_to_screen_name" : "4tunetellernet",
  "in_reply_to_user_id_str" : "467634146",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Michael Riccioli",
      "screen_name" : "curvedway",
      "indices" : [ 0, 10 ],
      "id_str" : "124707247",
      "id" : 124707247
    }, {
      "name" : "Jeremy Paxman",
      "screen_name" : "JeremyPaxman",
      "indices" : [ 11, 24 ],
      "id_str" : "472098458",
      "id" : 472098458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "718891739768090624",
  "geo" : { },
  "id_str" : "718918753178750976",
  "in_reply_to_user_id" : 124707247,
  "text" : "@curvedway @JeremyPaxman trolling from the old school : )",
  "id" : 718918753178750976,
  "in_reply_to_status_id" : 718891739768090624,
  "created_at" : "2016-04-09 21:49:22 +0000",
  "in_reply_to_screen_name" : "curvedway",
  "in_reply_to_user_id_str" : "124707247",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iatefl",
      "indices" : [ 44, 51 ]
    }, {
      "text" : "iatefl16",
      "indices" : [ 52, 61 ]
    }, {
      "text" : "iatefl2016",
      "indices" : [ 62, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/giySKTScMC",
      "expanded_url" : "https:\/\/script.googleusercontent.com\/macros\/echo?user_content_key=eX2STVZD1fQit4c1GQchifJKojSnMxgeubSv2fXjZiTiC82KjWT4Bxqu5UJwDLGp6UV6eZyLmba7Dcy-zs_R3vz_t-Ktl9PPm5_BxDlH2jW0nuo2oDemN9CCS2h10ox_1xSncGQajx_ryfhECjZEnLBpisWxHJ7vHjwebm3yZnRuveeSz7hzaMveceuWLB6rlJeC07JO6h34IX8OcILuBYUHLoJxFchqNyh2OijmYeDAbmoLK6xWKzmNZR4Xhv64&lib=MmhWt8s1JXYWll_KKCb_3qyKctFh_LT3R",
      "display_url" : "script.googleusercontent.com\/macros\/echo?us\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "718905230289723393",
  "text" : "for those inclined get Twitter RSS feed for #iatefl #iatefl16 #iatefl2016 https:\/\/t.co\/giySKTScMC",
  "id" : 718905230289723393,
  "created_at" : "2016-04-09 20:55:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Jones",
      "screen_name" : "ELTResearch",
      "indices" : [ 0, 12 ],
      "id_str" : "3308043417",
      "id" : 3308043417
    }, {
      "name" : "Gavin Reddin",
      "screen_name" : "ReddinGavin",
      "indices" : [ 13, 25 ],
      "id_str" : "2723204205",
      "id" : 2723204205
    }, {
      "name" : "The Guardian",
      "screen_name" : "guardian",
      "indices" : [ 26, 35 ],
      "id_str" : "87818409",
      "id" : 87818409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "718890185996562432",
  "geo" : { },
  "id_str" : "718899023965458433",
  "in_reply_to_user_id" : 3308043417,
  "text" : "@ELTResearch @ReddinGavin @guardian hmm so it is Chomsky's fault that people r not more linguistically literate hmm yeah ok",
  "id" : 718899023965458433,
  "in_reply_to_status_id" : 718890185996562432,
  "created_at" : "2016-04-09 20:30:58 +0000",
  "in_reply_to_screen_name" : "ELTResearch",
  "in_reply_to_user_id_str" : "3308043417",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/2dpr4KcfPL",
      "expanded_url" : "http:\/\/www.eurotrib.com\/story\/2016\/4\/6\/16244\/29592",
      "display_url" : "eurotrib.com\/story\/2016\/4\/6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "718823023827136513",
  "text" : "LQD: The Economist worried by \"abnormal profits\"\nhttps:\/\/t.co\/2dpr4KcfPL",
  "id" : 718823023827136513,
  "created_at" : "2016-04-09 15:28:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FamilyValuesIn5Words",
      "indices" : [ 50, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "718821216732213249",
  "text" : "RT @pchallinor: Fuck the poor, breed billionaires #FamilyValuesIn5Words",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FamilyValuesIn5Words",
        "indices" : [ 34, 55 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "718817504978669568",
    "text" : "Fuck the poor, breed billionaires #FamilyValuesIn5Words",
    "id" : 718817504978669568,
    "created_at" : "2016-04-09 15:07:02 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 718821216732213249,
  "created_at" : "2016-04-09 15:21:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maria Pia Montoro",
      "screen_name" : "WordLo",
      "indices" : [ 3, 10 ],
      "id_str" : "190569306",
      "id" : 190569306
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/zV7QBSANjq",
      "expanded_url" : "https:\/\/peoplescode.wordpress.com\/2016\/03\/29\/taste-the-translation\/",
      "display_url" : "peoplescode.wordpress.com\/2016\/03\/29\/tas\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "718796126053380096",
  "text" : "RT @WordLo: Tasting google translated recipes \uD83D\uDE06\uD83D\uDE02 https:\/\/t.co\/zV7QBSANjq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 60 ],
        "url" : "https:\/\/t.co\/zV7QBSANjq",
        "expanded_url" : "https:\/\/peoplescode.wordpress.com\/2016\/03\/29\/taste-the-translation\/",
        "display_url" : "peoplescode.wordpress.com\/2016\/03\/29\/tas\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "718772812396261378",
    "text" : "Tasting google translated recipes \uD83D\uDE06\uD83D\uDE02 https:\/\/t.co\/zV7QBSANjq",
    "id" : 718772812396261378,
    "created_at" : "2016-04-09 12:09:27 +0000",
    "user" : {
      "name" : "Maria Pia Montoro",
      "screen_name" : "WordLo",
      "protected" : false,
      "id_str" : "190569306",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/660652749881782272\/BB1P3zUR_normal.jpg",
      "id" : 190569306,
      "verified" : false
    }
  },
  "id" : 718796126053380096,
  "created_at" : "2016-04-09 13:42:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tanya Moodie",
      "screen_name" : "tanyamoodie",
      "indices" : [ 3, 15 ],
      "id_str" : "19867887",
      "id" : 19867887
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/jB6ESUlKIi",
      "expanded_url" : "http:\/\/polygraph.cool\/films\/index.html",
      "display_url" : "polygraph.cool\/films\/index.ht\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "718794987803119617",
  "text" : "RT @tanyamoodie: A must read- 'The Largest Ever Analysis of Film Dialogue by Gender: 2,000 scripts, 25,000 actors, 4 million lines'  https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/jB6ESUlKIi",
        "expanded_url" : "http:\/\/polygraph.cool\/films\/index.html",
        "display_url" : "polygraph.cool\/films\/index.ht\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "718685083780169728",
    "text" : "A must read- 'The Largest Ever Analysis of Film Dialogue by Gender: 2,000 scripts, 25,000 actors, 4 million lines'  https:\/\/t.co\/jB6ESUlKIi",
    "id" : 718685083780169728,
    "created_at" : "2016-04-09 06:20:51 +0000",
    "user" : {
      "name" : "Tanya Moodie",
      "screen_name" : "tanyamoodie",
      "protected" : false,
      "id_str" : "19867887",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/752055335951761408\/iF4OOxI-_normal.jpg",
      "id" : 19867887,
      "verified" : false
    }
  },
  "id" : 718794987803119617,
  "created_at" : "2016-04-09 13:37:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 10, 26 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "718179195323437056",
  "geo" : { },
  "id_str" : "718769628391022592",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava @getgreatenglish cheers!",
  "id" : 718769628391022592,
  "in_reply_to_status_id" : 718179195323437056,
  "created_at" : "2016-04-09 11:56:48 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Alcino Ferreira",
      "screen_name" : "alcino_ferreira",
      "indices" : [ 10, 26 ],
      "id_str" : "633930347",
      "id" : 633930347
    }, {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "indices" : [ 27, 37 ],
      "id_str" : "577931950",
      "id" : 577931950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "718179195323437056",
  "geo" : { },
  "id_str" : "718748796092592129",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava @alcino_ferreira @RudyLoock merci!",
  "id" : 718748796092592129,
  "in_reply_to_status_id" : 718179195323437056,
  "created_at" : "2016-04-09 10:34:01 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "TEFLAnneOKeeffe",
      "screen_name" : "TEFLclass",
      "indices" : [ 10, 20 ],
      "id_str" : "469244585",
      "id" : 469244585
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716378780248322048",
  "geo" : { },
  "id_str" : "718747457753059328",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava @TEFLclass thx for RT!",
  "id" : 718747457753059328,
  "in_reply_to_status_id" : 716378780248322048,
  "created_at" : "2016-04-09 10:28:42 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Curtis",
      "screen_name" : "markcurtis30",
      "indices" : [ 3, 16 ],
      "id_str" : "2278053312",
      "id" : 2278053312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/h1r3yWJUWT",
      "expanded_url" : "http:\/\/gu.com\/p\/4t8xh?CMP=Share_iOSApp_Other",
      "display_url" : "gu.com\/p\/4t8xh?CMP=Sh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "718746862979825664",
  "text" : "RT @markcurtis30: More Guardian hilarity: since we live in 'liberal democracies' it's 'harmful' to 'suspect the worst of our rulers' https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/h1r3yWJUWT",
        "expanded_url" : "http:\/\/gu.com\/p\/4t8xh?CMP=Share_iOSApp_Other",
        "display_url" : "gu.com\/p\/4t8xh?CMP=Sh\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "718710384581091328",
    "text" : "More Guardian hilarity: since we live in 'liberal democracies' it's 'harmful' to 'suspect the worst of our rulers' https:\/\/t.co\/h1r3yWJUWT",
    "id" : 718710384581091328,
    "created_at" : "2016-04-09 08:01:23 +0000",
    "user" : {
      "name" : "Mark Curtis",
      "screen_name" : "markcurtis30",
      "protected" : false,
      "id_str" : "2278053312",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/644110073963397120\/s-BUPkdk_normal.jpg",
      "id" : 2278053312,
      "verified" : false
    }
  },
  "id" : 718746862979825664,
  "created_at" : "2016-04-09 10:26:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane",
      "screen_name" : "Mentorjane4u",
      "indices" : [ 0, 13 ],
      "id_str" : "706959324963282944",
      "id" : 706959324963282944
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "718715394152886272",
  "geo" : { },
  "id_str" : "718716088297590784",
  "in_reply_to_user_id" : 706959324963282944,
  "text" : "@Mentorjane4u group work seems to be more problematic in \"content\" based subjects maybe less problematic in learning languages?",
  "id" : 718716088297590784,
  "in_reply_to_status_id" : 718715394152886272,
  "created_at" : "2016-04-09 08:24:03 +0000",
  "in_reply_to_screen_name" : "Mentorjane4u",
  "in_reply_to_user_id_str" : "706959324963282944",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/718715311231528960\/photo\/1",
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/6Z10HEIHQs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfljxEwWsAAmMm8.jpg",
      "id_str" : "718715310283599872",
      "id" : 718715310283599872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfljxEwWsAAmMm8.jpg",
      "sizes" : [ {
        "h" : 267,
        "resize" : "fit",
        "w" : 1361
      }, {
        "h" : 67,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 118,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 201,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/6Z10HEIHQs"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/ngrkoPwr3j",
      "expanded_url" : "http:\/\/cfgg.decontextualize.com\/gen.html?key=1s-uCFGAck3a7L-cfRUpfT2En92wcxxiXnN2g1S5Jjug",
      "display_url" : "cfgg.decontextualize.com\/gen.html?key=1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "718715311231528960",
  "text" : "Vive Game of Charlies https:\/\/t.co\/ngrkoPwr3j https:\/\/t.co\/6Z10HEIHQs",
  "id" : 718715311231528960,
  "created_at" : "2016-04-09 08:20:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    }, {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 123, 133 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/Hn7wANbf02",
      "expanded_url" : "http:\/\/www.medialens.org\/index.php\/alerts\/alert-archive\/2016\/816-last-chance-president.html",
      "display_url" : "medialens.org\/index.php\/aler\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "718713105786748928",
  "text" : "RT @johnwhilley: Sanders denounces corporate framing as climate crisis deepens. The real issues and identity politics, via @medialens https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Media Lens",
        "screen_name" : "medialens",
        "indices" : [ 106, 116 ],
        "id_str" : "6531902",
        "id" : 6531902
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/Hn7wANbf02",
        "expanded_url" : "http:\/\/www.medialens.org\/index.php\/alerts\/alert-archive\/2016\/816-last-chance-president.html",
        "display_url" : "medialens.org\/index.php\/aler\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "718698176132358144",
    "text" : "Sanders denounces corporate framing as climate crisis deepens. The real issues and identity politics, via @medialens https:\/\/t.co\/Hn7wANbf02",
    "id" : 718698176132358144,
    "created_at" : "2016-04-09 07:12:52 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 718713105786748928,
  "created_at" : "2016-04-09 08:12:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Natallia Novikava",
      "screen_name" : "Natashetta",
      "indices" : [ 0, 11 ],
      "id_str" : "56308635",
      "id" : 56308635
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "718710458639872001",
  "geo" : { },
  "id_str" : "718711829304909824",
  "in_reply_to_user_id" : 56308635,
  "text" : "@Natashetta thanks Natallia : )",
  "id" : 718711829304909824,
  "in_reply_to_status_id" : 718710458639872001,
  "created_at" : "2016-04-09 08:07:07 +0000",
  "in_reply_to_screen_name" : "Natashetta",
  "in_reply_to_user_id_str" : "56308635",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TEFLAnneOKeeffe",
      "screen_name" : "TEFLclass",
      "indices" : [ 0, 10 ],
      "id_str" : "469244585",
      "id" : 469244585
    }, {
      "name" : "Rachael TESOL",
      "screen_name" : "RachaelTESOL",
      "indices" : [ 11, 24 ],
      "id_str" : "537057787",
      "id" : 537057787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "718517633121914880",
  "geo" : { },
  "id_str" : "718710471759630338",
  "in_reply_to_user_id" : 469244585,
  "text" : "@TEFLclass @RachaelTESOL thks for RT Rachael",
  "id" : 718710471759630338,
  "in_reply_to_status_id" : 718517633121914880,
  "created_at" : "2016-04-09 08:01:44 +0000",
  "in_reply_to_screen_name" : "TEFLclass",
  "in_reply_to_user_id_str" : "469244585",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TEFLAnneOKeeffe",
      "screen_name" : "TEFLclass",
      "indices" : [ 0, 10 ],
      "id_str" : "469244585",
      "id" : 469244585
    }, {
      "name" : "Geraldine Mark",
      "screen_name" : "_GelMark",
      "indices" : [ 11, 20 ],
      "id_str" : "579727372",
      "id" : 579727372
    }, {
      "name" : "Cambridge ELT",
      "screen_name" : "CambridgeUPELT",
      "indices" : [ 21, 36 ],
      "id_str" : "73107903",
      "id" : 73107903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "718517633121914880",
  "geo" : { },
  "id_str" : "718710328981381120",
  "in_reply_to_user_id" : 469244585,
  "text" : "@TEFLclass @_GelMark @CambridgeUPELT thank you for taking part all the best for your talk : )",
  "id" : 718710328981381120,
  "in_reply_to_status_id" : 718517633121914880,
  "created_at" : "2016-04-09 08:01:10 +0000",
  "in_reply_to_screen_name" : "TEFLclass",
  "in_reply_to_user_id_str" : "469244585",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eily Murphy",
      "screen_name" : "eilymurphy",
      "indices" : [ 0, 11 ],
      "id_str" : "111091623",
      "id" : 111091623
    }, {
      "name" : "Ann Smith",
      "screen_name" : "AnnSmithESOL",
      "indices" : [ 12, 25 ],
      "id_str" : "718509029144797185",
      "id" : 718509029144797185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "718526071214370817",
  "geo" : { },
  "id_str" : "718710216892760064",
  "in_reply_to_user_id" : 111091623,
  "text" : "@eilymurphy @AnnSmithESOL cheers Eily : )",
  "id" : 718710216892760064,
  "in_reply_to_status_id" : 718526071214370817,
  "created_at" : "2016-04-09 08:00:43 +0000",
  "in_reply_to_screen_name" : "eilymurphy",
  "in_reply_to_user_id_str" : "111091623",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 65, 73 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/2CV94LIbiA",
      "expanded_url" : "https:\/\/youtu.be\/D2fSXp6N-vs",
      "display_url" : "youtu.be\/D2fSXp6N-vs"
    } ]
  },
  "geo" : { },
  "id_str" : "718490775370219520",
  "text" : "Cassetteboy vs The Snoopers' Charter https:\/\/t.co\/2CV94LIbiA via @YouTube",
  "id" : 718490775370219520,
  "created_at" : "2016-04-08 17:28:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/718484349268701184\/photo\/1",
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/JYgAQEnczd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfiRtThWwAAl_Xk.jpg",
      "id_str" : "718484348085911552",
      "id" : 718484348085911552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfiRtThWwAAl_Xk.jpg",
      "sizes" : [ {
        "h" : 107,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 61,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 182,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 246,
        "resize" : "fit",
        "w" : 1382
      } ],
      "display_url" : "pic.twitter.com\/JYgAQEnczd"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/ngrkoPwr3j",
      "expanded_url" : "http:\/\/cfgg.decontextualize.com\/gen.html?key=1s-uCFGAck3a7L-cfRUpfT2En92wcxxiXnN2g1S5Jjug",
      "display_url" : "cfgg.decontextualize.com\/gen.html?key=1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "718484349268701184",
  "text" : "Vive Game of Charlies https:\/\/t.co\/ngrkoPwr3j https:\/\/t.co\/JYgAQEnczd",
  "id" : 718484349268701184,
  "created_at" : "2016-04-08 17:03:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/718483760140980227\/photo\/1",
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/X9ebZzeDOn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfiRLB5WwAEHZQy.jpg",
      "id_str" : "718483759239184385",
      "id" : 718483759239184385,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfiRLB5WwAEHZQy.jpg",
      "sizes" : [ {
        "h" : 239,
        "resize" : "fit",
        "w" : 1393
      }, {
        "h" : 58,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 103,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 176,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/X9ebZzeDOn"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/ngrkoPwr3j",
      "expanded_url" : "http:\/\/cfgg.decontextualize.com\/gen.html?key=1s-uCFGAck3a7L-cfRUpfT2En92wcxxiXnN2g1S5Jjug",
      "display_url" : "cfgg.decontextualize.com\/gen.html?key=1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "718483760140980227",
  "text" : "Vive Game of Charlies https:\/\/t.co\/ngrkoPwr3j https:\/\/t.co\/X9ebZzeDOn",
  "id" : 718483760140980227,
  "created_at" : "2016-04-08 17:00:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "718474084544327680",
  "text" : "is there a bot that points out that 4 congruent circle venn diagrams make little sense?",
  "id" : 718474084544327680,
  "created_at" : "2016-04-08 16:22:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Matthew Ellman",
      "screen_name" : "MatthewEllman",
      "indices" : [ 10, 24 ],
      "id_str" : "394987109",
      "id" : 394987109
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "718179195323437056",
  "geo" : { },
  "id_str" : "718433882941628416",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava @MatthewEllman thanks Mat  : )",
  "id" : 718433882941628416,
  "in_reply_to_status_id" : 718179195323437056,
  "created_at" : "2016-04-08 13:42:40 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bethany Cagnol",
      "screen_name" : "bethcagnol",
      "indices" : [ 3, 14 ],
      "id_str" : "27641720",
      "id" : 27641720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/dQVg9HLnE7",
      "expanded_url" : "http:\/\/www.theguardian.com\/healthcare-network\/2016\/apr\/08\/english-language-requirements-foreign-doctors-not-fit-purpose",
      "display_url" : "theguardian.com\/healthcare-net\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "718397521635188736",
  "text" : "RT @bethcagnol: In today's Guardian, a thought-provoking article written by my good buddy, Ros Wright. https:\/\/t.co\/dQVg9HLnE7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/dQVg9HLnE7",
        "expanded_url" : "http:\/\/www.theguardian.com\/healthcare-network\/2016\/apr\/08\/english-language-requirements-foreign-doctors-not-fit-purpose",
        "display_url" : "theguardian.com\/healthcare-net\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "718387738404327425",
    "text" : "In today's Guardian, a thought-provoking article written by my good buddy, Ros Wright. https:\/\/t.co\/dQVg9HLnE7",
    "id" : 718387738404327425,
    "created_at" : "2016-04-08 10:39:18 +0000",
    "user" : {
      "name" : "Bethany Cagnol",
      "screen_name" : "bethcagnol",
      "protected" : false,
      "id_str" : "27641720",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/425969412265373696\/jdqAse11_normal.jpeg",
      "id" : 27641720,
      "verified" : false
    }
  },
  "id" : 718397521635188736,
  "created_at" : "2016-04-08 11:18:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Carr",
      "screen_name" : "MattCarr55",
      "indices" : [ 53, 64 ],
      "id_str" : "288409122",
      "id" : 288409122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/MYAsRI0ES9",
      "expanded_url" : "http:\/\/infernalmachine.co.uk\/labours-zionism-problem\/",
      "display_url" : "infernalmachine.co.uk\/labours-zionis\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "718391278388584448",
  "text" : "Labour's Zionism Problem https:\/\/t.co\/MYAsRI0ES9 via @MattCarr55",
  "id" : 718391278388584448,
  "created_at" : "2016-04-08 10:53:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    }, {
      "name" : "Ljiljana Havran",
      "screen_name" : "LjiljanaHavran",
      "indices" : [ 13, 28 ],
      "id_str" : "1395825290",
      "id" : 1395825290
    }, {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 29, 40 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "718384760503083009",
  "geo" : { },
  "id_str" : "718388212302016512",
  "in_reply_to_user_id" : 18602422,
  "text" : "@AnneHendler @LjiljanaHavran @kevchanwow thanks y'all!",
  "id" : 718388212302016512,
  "in_reply_to_status_id" : 718384760503083009,
  "created_at" : "2016-04-08 10:41:11 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "718312911870042112",
  "geo" : { },
  "id_str" : "718384760503083009",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler thanks Anne enjoy the w\/e :)",
  "id" : 718384760503083009,
  "in_reply_to_status_id" : 718312911870042112,
  "created_at" : "2016-04-08 10:27:28 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/718295860694630400\/photo\/1",
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/7psqZne3Qi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CffmR2WWwAASZpw.jpg",
      "id_str" : "718295859910328320",
      "id" : 718295859910328320,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CffmR2WWwAASZpw.jpg",
      "sizes" : [ {
        "h" : 55,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 166,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 97,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 224,
        "resize" : "fit",
        "w" : 1383
      } ],
      "display_url" : "pic.twitter.com\/7psqZne3Qi"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/ngrkoPwr3j",
      "expanded_url" : "http:\/\/cfgg.decontextualize.com\/gen.html?key=1s-uCFGAck3a7L-cfRUpfT2En92wcxxiXnN2g1S5Jjug",
      "display_url" : "cfgg.decontextualize.com\/gen.html?key=1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "718295860694630400",
  "text" : "Vive Game of Charlies https:\/\/t.co\/ngrkoPwr3j https:\/\/t.co\/7psqZne3Qi",
  "id" : 718295860694630400,
  "created_at" : "2016-04-08 04:34:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AllThingsLinguistic",
      "screen_name" : "AllThingsLing",
      "indices" : [ 3, 17 ],
      "id_str" : "857291268",
      "id" : 857291268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 124, 140 ],
      "url" : "https:\/\/t.co\/Qry0ho7Ufw",
      "expanded_url" : "https:\/\/tmblr.co\/ZuWOEv24fK6_Q",
      "display_url" : "tmblr.co\/ZuWOEv24fK6_Q"
    } ]
  },
  "geo" : { },
  "id_str" : "718292734302400517",
  "text" : "RT @AllThingsLing: Statistical Learning and the Qur\u2019an - A study about what people can learn from prolonged memorization... https:\/\/t.co\/Qr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/Qry0ho7Ufw",
        "expanded_url" : "https:\/\/tmblr.co\/ZuWOEv24fK6_Q",
        "display_url" : "tmblr.co\/ZuWOEv24fK6_Q"
      } ]
    },
    "geo" : { },
    "id_str" : "718204370874146816",
    "text" : "Statistical Learning and the Qur\u2019an - A study about what people can learn from prolonged memorization... https:\/\/t.co\/Qry0ho7Ufw",
    "id" : 718204370874146816,
    "created_at" : "2016-04-07 22:30:40 +0000",
    "user" : {
      "name" : "AllThingsLinguistic",
      "screen_name" : "AllThingsLing",
      "protected" : false,
      "id_str" : "857291268",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750400997206454273\/N0DmrmFi_normal.jpg",
      "id" : 857291268,
      "verified" : false
    }
  },
  "id" : 718292734302400517,
  "created_at" : "2016-04-08 04:21:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alyson Indrunas",
      "screen_name" : "AlysonIndrunas",
      "indices" : [ 3, 18 ],
      "id_str" : "1093690267",
      "id" : 1093690267
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/AlysonIndrunas\/status\/718288694986293250\/photo\/1",
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/HWEWHeH3PI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfffwwRWEAA6dal.jpg",
      "id_str" : "718288694273249280",
      "id" : 718288694273249280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfffwwRWEAA6dal.jpg",
      "sizes" : [ {
        "h" : 538,
        "resize" : "fit",
        "w" : 588
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 538,
        "resize" : "fit",
        "w" : 588
      }, {
        "h" : 538,
        "resize" : "fit",
        "w" : 588
      }, {
        "h" : 311,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/HWEWHeH3PI"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/3PmKku8VcF",
      "expanded_url" : "https:\/\/spokeandhub.wordpress.com\/2016\/04\/07\/robot-tasks-creative-brains\/",
      "display_url" : "spokeandhub.wordpress.com\/2016\/04\/07\/rob\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "718292507814203393",
  "text" : "RT @AlysonIndrunas: Robot Tasks &amp; Creative\u00A0Brains https:\/\/t.co\/3PmKku8VcF https:\/\/t.co\/HWEWHeH3PI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/AlysonIndrunas\/status\/718288694986293250\/photo\/1",
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/HWEWHeH3PI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CfffwwRWEAA6dal.jpg",
        "id_str" : "718288694273249280",
        "id" : 718288694273249280,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfffwwRWEAA6dal.jpg",
        "sizes" : [ {
          "h" : 538,
          "resize" : "fit",
          "w" : 588
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 538,
          "resize" : "fit",
          "w" : 588
        }, {
          "h" : 538,
          "resize" : "fit",
          "w" : 588
        }, {
          "h" : 311,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/HWEWHeH3PI"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 34, 57 ],
        "url" : "https:\/\/t.co\/3PmKku8VcF",
        "expanded_url" : "https:\/\/spokeandhub.wordpress.com\/2016\/04\/07\/robot-tasks-creative-brains\/",
        "display_url" : "spokeandhub.wordpress.com\/2016\/04\/07\/rob\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "718288694986293250",
    "text" : "Robot Tasks &amp; Creative\u00A0Brains https:\/\/t.co\/3PmKku8VcF https:\/\/t.co\/HWEWHeH3PI",
    "id" : 718288694986293250,
    "created_at" : "2016-04-08 04:05:44 +0000",
    "user" : {
      "name" : "Alyson Indrunas",
      "screen_name" : "AlysonIndrunas",
      "protected" : false,
      "id_str" : "1093690267",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/545985553003335680\/ReQIGX6A_normal.jpeg",
      "id" : 1093690267,
      "verified" : false
    }
  },
  "id" : 718292507814203393,
  "created_at" : "2016-04-08 04:20:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2730\u2728Adjowa Adjei\u2728\u2730",
      "screen_name" : "lovelyadjowa",
      "indices" : [ 3, 16 ],
      "id_str" : "2772155139",
      "id" : 2772155139
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/lovelyadjowa\/status\/718215990606213122\/photo\/1",
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/d5FsbQgkTO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfedohaW8AYjF-c.jpg",
      "id_str" : "718215985078136838",
      "id" : 718215985078136838,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfedohaW8AYjF-c.jpg",
      "sizes" : [ {
        "h" : 840,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 875,
        "resize" : "fit",
        "w" : 625
      }, {
        "h" : 476,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 875,
        "resize" : "fit",
        "w" : 625
      } ],
      "display_url" : "pic.twitter.com\/d5FsbQgkTO"
    } ],
    "hashtags" : [ {
      "text" : "CurseDavidCameron",
      "indices" : [ 51, 69 ]
    }, {
      "text" : "DavidCameron",
      "indices" : [ 70, 83 ]
    }, {
      "text" : "resigncameron",
      "indices" : [ 84, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "718219315414216706",
  "text" : "RT @lovelyadjowa: Gosh I'm feeling these curses... #CurseDavidCameron #DavidCameron #resigncameron https:\/\/t.co\/d5FsbQgkTO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/lovelyadjowa\/status\/718215990606213122\/photo\/1",
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/d5FsbQgkTO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CfedohaW8AYjF-c.jpg",
        "id_str" : "718215985078136838",
        "id" : 718215985078136838,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfedohaW8AYjF-c.jpg",
        "sizes" : [ {
          "h" : 840,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 875,
          "resize" : "fit",
          "w" : 625
        }, {
          "h" : 476,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 875,
          "resize" : "fit",
          "w" : 625
        } ],
        "display_url" : "pic.twitter.com\/d5FsbQgkTO"
      } ],
      "hashtags" : [ {
        "text" : "CurseDavidCameron",
        "indices" : [ 33, 51 ]
      }, {
        "text" : "DavidCameron",
        "indices" : [ 52, 65 ]
      }, {
        "text" : "resigncameron",
        "indices" : [ 66, 80 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "718215990606213122",
    "text" : "Gosh I'm feeling these curses... #CurseDavidCameron #DavidCameron #resigncameron https:\/\/t.co\/d5FsbQgkTO",
    "id" : 718215990606213122,
    "created_at" : "2016-04-07 23:16:50 +0000",
    "user" : {
      "name" : "\u2730\u2728Adjowa Adjei\u2728\u2730",
      "screen_name" : "lovelyadjowa",
      "protected" : false,
      "id_str" : "2772155139",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/626925167646765056\/eMWfvsgY_normal.jpg",
      "id" : 2772155139,
      "verified" : false
    }
  },
  "id" : 718219315414216706,
  "created_at" : "2016-04-07 23:30:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Adele Soracco",
      "screen_name" : "LauraSoracco",
      "indices" : [ 0, 13 ],
      "id_str" : "15663328",
      "id" : 15663328
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TESOL16",
      "indices" : [ 104, 112 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "718217458390286337",
  "geo" : { },
  "id_str" : "718218173212925952",
  "in_reply_to_user_id" : 15663328,
  "text" : "@LauraSoracco some are indeed oblivious to the obvious so thanks for this observation, hope u r rocking #TESOL16",
  "id" : 718218173212925952,
  "in_reply_to_status_id" : 718217458390286337,
  "created_at" : "2016-04-07 23:25:30 +0000",
  "in_reply_to_screen_name" : "LauraSoracco",
  "in_reply_to_user_id_str" : "15663328",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/718210110879842308\/photo\/1",
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/2t9E2P3BF4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfeYSgIW8AIU5FO.jpg",
      "id_str" : "718210109218942978",
      "id" : 718210109218942978,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfeYSgIW8AIU5FO.jpg",
      "sizes" : [ {
        "h" : 61,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 185,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 246,
        "resize" : "fit",
        "w" : 1364
      }, {
        "h" : 108,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/2t9E2P3BF4"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/ngrkoPwr3j",
      "expanded_url" : "http:\/\/cfgg.decontextualize.com\/gen.html?key=1s-uCFGAck3a7L-cfRUpfT2En92wcxxiXnN2g1S5Jjug",
      "display_url" : "cfgg.decontextualize.com\/gen.html?key=1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "718210110879842308",
  "text" : "Vive Game of Charlies https:\/\/t.co\/ngrkoPwr3j https:\/\/t.co\/2t9E2P3BF4",
  "id" : 718210110879842308,
  "created_at" : "2016-04-07 22:53:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ken Jennings",
      "screen_name" : "KenJennings",
      "indices" : [ 3, 15 ],
      "id_str" : "234270825",
      "id" : 234270825
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "718203289662263296",
  "text" : "RT @KenJennings: Email subjects that start with \"Fwd:\" are always better if you pronounce it as \"F-word.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "718135481477648384",
    "text" : "Email subjects that start with \"Fwd:\" are always better if you pronounce it as \"F-word.\"",
    "id" : 718135481477648384,
    "created_at" : "2016-04-07 17:56:55 +0000",
    "user" : {
      "name" : "Ken Jennings",
      "screen_name" : "KenJennings",
      "protected" : false,
      "id_str" : "234270825",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703278823450644485\/ggXqQ424_normal.jpg",
      "id" : 234270825,
      "verified" : true
    }
  },
  "id" : 718203289662263296,
  "created_at" : "2016-04-07 22:26:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/718200566678208512\/photo\/1",
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/QhsvjsdODD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfePm_uXIAAx5PF.jpg",
      "id_str" : "718200565692571648",
      "id" : 718200565692571648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfePm_uXIAAx5PF.jpg",
      "sizes" : [ {
        "h" : 231,
        "resize" : "fit",
        "w" : 1376
      }, {
        "h" : 57,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 101,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 172,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/QhsvjsdODD"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/ngrkoPwr3j",
      "expanded_url" : "http:\/\/cfgg.decontextualize.com\/gen.html?key=1s-uCFGAck3a7L-cfRUpfT2En92wcxxiXnN2g1S5Jjug",
      "display_url" : "cfgg.decontextualize.com\/gen.html?key=1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "718200566678208512",
  "text" : "Vive Game of Charlies https:\/\/t.co\/ngrkoPwr3j https:\/\/t.co\/QhsvjsdODD",
  "id" : 718200566678208512,
  "created_at" : "2016-04-07 22:15:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kath",
      "screen_name" : "KathyBurke",
      "indices" : [ 3, 14 ],
      "id_str" : "3315766473",
      "id" : 3315766473
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BBCQT",
      "indices" : [ 16, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "718199350879514624",
  "text" : "RT @KathyBurke: #BBCQT is shit. It's been shit for ages. We hate them all. They're all cunts. Even David.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BBCQT",
        "indices" : [ 0, 6 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "718197097921687552",
    "text" : "#BBCQT is shit. It's been shit for ages. We hate them all. They're all cunts. Even David.",
    "id" : 718197097921687552,
    "created_at" : "2016-04-07 22:01:46 +0000",
    "user" : {
      "name" : "kath",
      "screen_name" : "KathyBurke",
      "protected" : false,
      "id_str" : "3315766473",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/768008732303298560\/kfHX43-l_normal.jpg",
      "id" : 3315766473,
      "verified" : true
    }
  },
  "id" : 718199350879514624,
  "created_at" : "2016-04-07 22:10:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MarisaConstantinides",
      "screen_name" : "Marisa_C",
      "indices" : [ 0, 9 ],
      "id_str" : "18272500",
      "id" : 18272500
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "718198420784214016",
  "geo" : { },
  "id_str" : "718198635163488256",
  "in_reply_to_user_id" : 18272500,
  "text" : "@Marisa_C who knows?! i doubt it though : )",
  "id" : 718198635163488256,
  "in_reply_to_status_id" : 718198420784214016,
  "created_at" : "2016-04-07 22:07:52 +0000",
  "in_reply_to_screen_name" : "Marisa_C",
  "in_reply_to_user_id_str" : "18272500",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "wrestlingneoliberals",
      "screen_name" : "neolib_takedown",
      "indices" : [ 3, 19 ],
      "id_str" : "3437858853",
      "id" : 3437858853
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/neolib_takedown\/status\/718197039419494400\/photo\/1",
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/jU2oFEycpl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfeMZq7WEAAJ7mJ.jpg",
      "id_str" : "718197038236700672",
      "id" : 718197038236700672,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfeMZq7WEAAJ7mJ.jpg",
      "sizes" : [ {
        "h" : 500,
        "resize" : "fit",
        "w" : 833
      }, {
        "h" : 204,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 833
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/jU2oFEycpl"
    } ],
    "hashtags" : [ {
      "text" : "Crook",
      "indices" : [ 26, 32 ]
    }, {
      "text" : "Cameron",
      "indices" : [ 33, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "718198404669652992",
  "text" : "RT @neolib_takedown: Go - #Crook #Cameron - Go! You're my hero. https:\/\/t.co\/jU2oFEycpl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/neolib_takedown\/status\/718197039419494400\/photo\/1",
        "indices" : [ 43, 66 ],
        "url" : "https:\/\/t.co\/jU2oFEycpl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CfeMZq7WEAAJ7mJ.jpg",
        "id_str" : "718197038236700672",
        "id" : 718197038236700672,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfeMZq7WEAAJ7mJ.jpg",
        "sizes" : [ {
          "h" : 500,
          "resize" : "fit",
          "w" : 833
        }, {
          "h" : 204,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 833
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/jU2oFEycpl"
      } ],
      "hashtags" : [ {
        "text" : "Crook",
        "indices" : [ 5, 11 ]
      }, {
        "text" : "Cameron",
        "indices" : [ 12, 20 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "718197039419494400",
    "text" : "Go - #Crook #Cameron - Go! You're my hero. https:\/\/t.co\/jU2oFEycpl",
    "id" : 718197039419494400,
    "created_at" : "2016-04-07 22:01:32 +0000",
    "user" : {
      "name" : "wrestlingneoliberals",
      "screen_name" : "neolib_takedown",
      "protected" : false,
      "id_str" : "3437858853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/635797071396798464\/rD8NlTWp_normal.png",
      "id" : 3437858853,
      "verified" : false
    }
  },
  "id" : 718198404669652992,
  "created_at" : "2016-04-07 22:06:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MarisaConstantinides",
      "screen_name" : "Marisa_C",
      "indices" : [ 0, 9 ],
      "id_str" : "18272500",
      "id" : 18272500
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iatefl",
      "indices" : [ 31, 38 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "718197540525641730",
  "geo" : { },
  "id_str" : "718198164122116096",
  "in_reply_to_user_id" : 18272500,
  "text" : "@Marisa_C thanks Marisa, enjoy #iatefl : )",
  "id" : 718198164122116096,
  "in_reply_to_status_id" : 718197540525641730,
  "created_at" : "2016-04-07 22:06:00 +0000",
  "in_reply_to_screen_name" : "Marisa_C",
  "in_reply_to_user_id_str" : "18272500",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/718197824077328384\/photo\/1",
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/0HOdiO2lZX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfeNHXXWQAIJrOa.jpg",
      "id_str" : "718197823259426818",
      "id" : 718197823259426818,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfeNHXXWQAIJrOa.jpg",
      "sizes" : [ {
        "h" : 252,
        "resize" : "fit",
        "w" : 1387
      }, {
        "h" : 186,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 109,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 62,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/0HOdiO2lZX"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/ngrkoPwr3j",
      "expanded_url" : "http:\/\/cfgg.decontextualize.com\/gen.html?key=1s-uCFGAck3a7L-cfRUpfT2En92wcxxiXnN2g1S5Jjug",
      "display_url" : "cfgg.decontextualize.com\/gen.html?key=1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "718197824077328384",
  "text" : "Vive Game of Charlies https:\/\/t.co\/ngrkoPwr3j https:\/\/t.co\/0HOdiO2lZX",
  "id" : 718197824077328384,
  "created_at" : "2016-04-07 22:04:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 45, 53 ]
    }, {
      "text" : "esl",
      "indices" : [ 54, 58 ]
    }, {
      "text" : "tesol",
      "indices" : [ 59, 65 ]
    }, {
      "text" : "tefl",
      "indices" : [ 66, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/07eWtr80cr",
      "expanded_url" : "https:\/\/eflnotes.wordpress.com\/2016\/04\/07\/iatefl-2016-corpus-related-mini-interviews",
      "display_url" : "eflnotes.wordpress.com\/2016\/04\/07\/iat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "718179195323437056",
  "text" : "IATEFL 2016 - corpus related mini-interviews #eltchat #esl #tesol #tefl https:\/\/t.co\/07eWtr80cr",
  "id" : 718179195323437056,
  "created_at" : "2016-04-07 20:50:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JUST DIFFERENT",
      "screen_name" : "B0MESH3L",
      "indices" : [ 0, 9 ],
      "id_str" : "458592921",
      "id" : 458592921
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "718173849376976897",
  "geo" : { },
  "id_str" : "718175642467098624",
  "in_reply_to_user_id" : 458592921,
  "text" : "@B0MESH3L thanks for sharing : )",
  "id" : 718175642467098624,
  "in_reply_to_status_id" : 718173849376976897,
  "created_at" : "2016-04-07 20:36:30 +0000",
  "in_reply_to_screen_name" : "B0MESH3L",
  "in_reply_to_user_id_str" : "458592921",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Emersberger",
      "screen_name" : "rosendo_joe",
      "indices" : [ 3, 15 ],
      "id_str" : "3351345863",
      "id" : 3351345863
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/DzV4QqGICI",
      "expanded_url" : "http:\/\/www.timwise.org\/2016\/03\/racism-as-divide-and-conquer-from-the-1600s-to-donald-trump-tim-wise-presentation-to-the-california-federation-of-teachers-san-francisco-march-2016\/",
      "display_url" : "timwise.org\/2016\/03\/racism\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "718172042999296000",
  "text" : "RT @rosendo_joe: Tim Wise: Racism as divide and conquer from 1670 to D. Trump\nhttps:\/\/t.co\/DzV4QqGICI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/DzV4QqGICI",
        "expanded_url" : "http:\/\/www.timwise.org\/2016\/03\/racism-as-divide-and-conquer-from-the-1600s-to-donald-trump-tim-wise-presentation-to-the-california-federation-of-teachers-san-francisco-march-2016\/",
        "display_url" : "timwise.org\/2016\/03\/racism\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "718166637770354688",
    "text" : "Tim Wise: Racism as divide and conquer from 1670 to D. Trump\nhttps:\/\/t.co\/DzV4QqGICI",
    "id" : 718166637770354688,
    "created_at" : "2016-04-07 20:00:43 +0000",
    "user" : {
      "name" : "Joe Emersberger",
      "screen_name" : "rosendo_joe",
      "protected" : false,
      "id_str" : "3351345863",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/621112707522142209\/OGmLR1xt_normal.jpg",
      "id" : 3351345863,
      "verified" : false
    }
  },
  "id" : 718172042999296000,
  "created_at" : "2016-04-07 20:22:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sofiya Asher",
      "screen_name" : "sofiyaasher",
      "indices" : [ 0, 12 ],
      "id_str" : "2527700904",
      "id" : 2527700904
    }, {
      "name" : "bot",
      "screen_name" : "TESOL_IATEFL_50",
      "indices" : [ 13, 29 ],
      "id_str" : "710852790948642817",
      "id" : 710852790948642817
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "718102756226162689",
  "geo" : { },
  "id_str" : "718159376477982720",
  "in_reply_to_user_id" : 2527700904,
  "text" : "@sofiyaasher @TESOL_IATEFL_50 OK thks",
  "id" : 718159376477982720,
  "in_reply_to_status_id" : 718102756226162689,
  "created_at" : "2016-04-07 19:31:52 +0000",
  "in_reply_to_screen_name" : "sofiyaasher",
  "in_reply_to_user_id_str" : "2527700904",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CurseDavidCameron",
      "indices" : [ 98, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "718145074383753216",
  "text" : "RT @pchallinor: May you be fallen on by Eric Pickles and treated for your injuries by Jeremy Hunt #CurseDavidCameron",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CurseDavidCameron",
        "indices" : [ 82, 100 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "718143988067385348",
    "text" : "May you be fallen on by Eric Pickles and treated for your injuries by Jeremy Hunt #CurseDavidCameron",
    "id" : 718143988067385348,
    "created_at" : "2016-04-07 18:30:43 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 718145074383753216,
  "created_at" : "2016-04-07 18:35:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/718094244871860224\/photo\/1",
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/5wTD2Lf0hF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cfcu5n_WEAYGM2I.jpg",
      "id_str" : "718094233110974470",
      "id" : 718094233110974470,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cfcu5n_WEAYGM2I.jpg",
      "sizes" : [ {
        "h" : 1706,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/5wTD2Lf0hF"
    } ],
    "hashtags" : [ {
      "text" : "notforeveryone",
      "indices" : [ 41, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "718094244871860224",
  "text" : "recommended snack - banana &amp; pakoda, #notforeveryone https:\/\/t.co\/5wTD2Lf0hF",
  "id" : 718094244871860224,
  "created_at" : "2016-04-07 15:13:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Roy Douglas",
      "screen_name" : "scottroydouglas",
      "indices" : [ 0, 16 ],
      "id_str" : "1263168308",
      "id" : 1263168308
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/se102IJE2r",
      "expanded_url" : "https:\/\/plus.google.com\/+MuraNava\/posts\/eqhmbPmqT6B",
      "display_url" : "plus.google.com\/+MuraNava\/post\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "718074226482290689",
  "geo" : { },
  "id_str" : "718083999885864961",
  "in_reply_to_user_id" : 1263168308,
  "text" : "@scottroydouglas folks can get a bit more info about CARE from pdf linked in comments here https:\/\/t.co\/se102IJE2r",
  "id" : 718083999885864961,
  "in_reply_to_status_id" : 718074226482290689,
  "created_at" : "2016-04-07 14:32:21 +0000",
  "in_reply_to_screen_name" : "scottroydouglas",
  "in_reply_to_user_id_str" : "1263168308",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sofiya Asher",
      "screen_name" : "sofiyaasher",
      "indices" : [ 0, 12 ],
      "id_str" : "2527700904",
      "id" : 2527700904
    }, {
      "name" : "bot",
      "screen_name" : "TESOL_IATEFL_50",
      "indices" : [ 13, 29 ],
      "id_str" : "710852790948642817",
      "id" : 710852790948642817
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "718074703957606400",
  "geo" : { },
  "id_str" : "718081317175431169",
  "in_reply_to_user_id" : 2527700904,
  "text" : "@sofiyaasher @TESOL_IATEFL_50 hi is this handout and\/or slides from talk available anywhere?",
  "id" : 718081317175431169,
  "in_reply_to_status_id" : 718074703957606400,
  "created_at" : "2016-04-07 14:21:41 +0000",
  "in_reply_to_screen_name" : "sofiyaasher",
  "in_reply_to_user_id_str" : "2527700904",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anabel Fern\u00E1ndez",
      "screen_name" : "dimodeca",
      "indices" : [ 0, 9 ],
      "id_str" : "1235503316",
      "id" : 1235503316
    }, {
      "name" : "Tyler Schnoebelen",
      "screen_name" : "TSchnoebelen",
      "indices" : [ 82, 95 ],
      "id_str" : "14969147",
      "id" : 14969147
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/EgiU7nO4iE",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=HnSMT96uNcU&feature=youtu.be",
      "display_url" : "youtube.com\/watch?v=HnSMT9\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "718063015812329473",
  "geo" : { },
  "id_str" : "718064514969808897",
  "in_reply_to_user_id" : 1235503316,
  "text" : "@dimodeca this is a fab &amp; cute ex of mixing it up https:\/\/t.co\/EgiU7nO4iE h\/t @TSchnoebelen",
  "id" : 718064514969808897,
  "in_reply_to_status_id" : 718063015812329473,
  "created_at" : "2016-04-07 13:14:56 +0000",
  "in_reply_to_screen_name" : "dimodeca",
  "in_reply_to_user_id_str" : "1235503316",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "indices" : [ 3, 18 ],
      "id_str" : "27716419",
      "id" : 27716419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/fSTaTJPyCy",
      "expanded_url" : "http:\/\/www.craigmurray.org.uk\/archives\/2016\/04\/the-empire-strikes-back\/",
      "display_url" : "craigmurray.org.uk\/archives\/2016\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "718062890620751872",
  "text" : "RT @CraigMurrayOrg: The Empire Strikes Back - If you argue a case strongly on the internet you must expect to receive robust argument https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.craigmurray.org.uk\" rel=\"nofollow\"\u003ECraig Murray posting plugin\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/fSTaTJPyCy",
        "expanded_url" : "http:\/\/www.craigmurray.org.uk\/archives\/2016\/04\/the-empire-strikes-back\/",
        "display_url" : "craigmurray.org.uk\/archives\/2016\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "718059685241360384",
    "text" : "The Empire Strikes Back - If you argue a case strongly on the internet you must expect to receive robust argument https:\/\/t.co\/fSTaTJPyCy",
    "id" : 718059685241360384,
    "created_at" : "2016-04-07 12:55:44 +0000",
    "user" : {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "protected" : false,
      "id_str" : "27716419",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1388436826\/cm_normal.jpg",
      "id" : 27716419,
      "verified" : false
    }
  },
  "id" : 718062890620751872,
  "created_at" : "2016-04-07 13:08:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "718060781267345408",
  "geo" : { },
  "id_str" : "718062065504632832",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava guess would need more text to be more accurate",
  "id" : 718062065504632832,
  "in_reply_to_status_id" : 718060781267345408,
  "created_at" : "2016-04-07 13:05:12 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/718060781267345408\/photo\/1",
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/8eu4MRq5RJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfcQeaBXIAApUvC.jpg",
      "id_str" : "718060780156035072",
      "id" : 718060780156035072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfcQeaBXIAApUvC.jpg",
      "sizes" : [ {
        "h" : 365,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 487,
        "resize" : "fit",
        "w" : 454
      }, {
        "h" : 487,
        "resize" : "fit",
        "w" : 454
      }, {
        "h" : 487,
        "resize" : "fit",
        "w" : 454
      } ],
      "display_url" : "pic.twitter.com\/8eu4MRq5RJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/Vgyq8mdciq",
      "expanded_url" : "https:\/\/github.com\/travisbrady\/word2phrase",
      "display_url" : "github.com\/travisbrady\/wo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "718060781267345408",
  "text" : "top 2-word &amp; 3-word phrases in Hebdo screech using https:\/\/t.co\/Vgyq8mdciq https:\/\/t.co\/8eu4MRq5RJ",
  "id" : 718060781267345408,
  "created_at" : "2016-04-07 13:00:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Brown",
      "screen_name" : "Za_Maikeru",
      "indices" : [ 73, 84 ],
      "id_str" : "703598479944208384",
      "id" : 703598479944208384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/oZCRJd3mgy",
      "expanded_url" : "https:\/\/corpling4efl.wordpress.com\/2016\/04\/07\/skell-easy-to-use-for-teachers-and-students\/",
      "display_url" : "corpling4efl.wordpress.com\/2016\/04\/07\/ske\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "718028832201175040",
  "text" : "SkELL: Easy to use for teachers and students https:\/\/t.co\/oZCRJd3mgy via @Za_Maikeru",
  "id" : 718028832201175040,
  "created_at" : "2016-04-07 10:53:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Thomas",
      "screen_name" : "versatilepub",
      "indices" : [ 83, 96 ],
      "id_str" : "3243120760",
      "id" : 3243120760
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/XmNIfwNYJ0",
      "expanded_url" : "https:\/\/youtu.be\/xVzFXKn833Q?t=19m47s",
      "display_url" : "youtu.be\/xVzFXKn833Q?t=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "718026591553589249",
  "text" : "\"the Welsh think I built it\" [opera house] Zaha Hadid \nhttps:\/\/t.co\/XmNIfwNYJ0 h\/t @versatilepub",
  "id" : 718026591553589249,
  "created_at" : "2016-04-07 10:44:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Leedham",
      "screen_name" : "DiLeed",
      "indices" : [ 0, 7 ],
      "id_str" : "2335217159",
      "id" : 2335217159
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "718021110944645120",
  "geo" : { },
  "id_str" : "718021229429526529",
  "in_reply_to_user_id" : 2335217159,
  "text" : "@DiLeed sure yr welcome",
  "id" : 718021229429526529,
  "in_reply_to_status_id" : 718021110944645120,
  "created_at" : "2016-04-07 10:22:55 +0000",
  "in_reply_to_screen_name" : "DiLeed",
  "in_reply_to_user_id_str" : "2335217159",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/718020902034735104\/photo\/1",
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/eLSWeUz9u0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfbsNJaWsAAitL3.jpg",
      "id_str" : "718020901221085184",
      "id" : 718020901221085184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfbsNJaWsAAitL3.jpg",
      "sizes" : [ {
        "h" : 186,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 243,
        "resize" : "fit",
        "w" : 1335
      }, {
        "h" : 109,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 62,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/eLSWeUz9u0"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/ngrkoPwr3j",
      "expanded_url" : "http:\/\/cfgg.decontextualize.com\/gen.html?key=1s-uCFGAck3a7L-cfRUpfT2En92wcxxiXnN2g1S5Jjug",
      "display_url" : "cfgg.decontextualize.com\/gen.html?key=1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "718020902034735104",
  "text" : "Vive Game of Charlies https:\/\/t.co\/ngrkoPwr3j https:\/\/t.co\/eLSWeUz9u0",
  "id" : 718020902034735104,
  "created_at" : "2016-04-07 10:21:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AllThingsLinguistic",
      "screen_name" : "AllThingsLing",
      "indices" : [ 0, 14 ],
      "id_str" : "857291268",
      "id" : 857291268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/KHhq2TRwzt",
      "expanded_url" : "http:\/\/allthingslinguistic.com\/post\/142371927626\/diversity-in-linguistics",
      "display_url" : "allthingslinguistic.com\/post\/142371927\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "717841910430302208",
  "geo" : { },
  "id_str" : "718020499750711297",
  "in_reply_to_user_id" : 857291268,
  "text" : "@AllThingsLing https:\/\/t.co\/KHhq2TRwzt",
  "id" : 718020499750711297,
  "in_reply_to_status_id" : 717841910430302208,
  "created_at" : "2016-04-07 10:20:01 +0000",
  "in_reply_to_screen_name" : "AllThingsLing",
  "in_reply_to_user_id_str" : "857291268",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Leedham",
      "screen_name" : "DiLeed",
      "indices" : [ 0, 7 ],
      "id_str" : "2335217159",
      "id" : 2335217159
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/KHhq2TRwzt",
      "expanded_url" : "http:\/\/allthingslinguistic.com\/post\/142371927626\/diversity-in-linguistics",
      "display_url" : "allthingslinguistic.com\/post\/142371927\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "718019296832696320",
  "geo" : { },
  "id_str" : "718020421598187520",
  "in_reply_to_user_id" : 2335217159,
  "text" : "@DiLeed hehe : ) yes probems e.g. in linguistics https:\/\/t.co\/KHhq2TRwzt",
  "id" : 718020421598187520,
  "in_reply_to_status_id" : 718019296832696320,
  "created_at" : "2016-04-07 10:19:43 +0000",
  "in_reply_to_screen_name" : "DiLeed",
  "in_reply_to_user_id_str" : "2335217159",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 69, 85 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/TbNRwzzNPY",
      "expanded_url" : "https:\/\/mikeastbury.wordpress.com\/2016\/04\/06\/captioncompetition\/",
      "display_url" : "mikeastbury.wordpress.com\/2016\/04\/06\/cap\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "718018737752973312",
  "text" : "Caption competition (so\/such\/enough\/too) https:\/\/t.co\/TbNRwzzNPY via @wordpressdotcom",
  "id" : 718018737752973312,
  "created_at" : "2016-04-07 10:13:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Leedham",
      "screen_name" : "DiLeed",
      "indices" : [ 0, 7 ],
      "id_str" : "2335217159",
      "id" : 2335217159
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "718015482188718080",
  "geo" : { },
  "id_str" : "718017400579428352",
  "in_reply_to_user_id" : 2335217159,
  "text" : "@DiLeed in a lot of ways \"personality\" clashes do arise from \"culture\" clashes &amp; the dominant modern academic culture is \"western\"?",
  "id" : 718017400579428352,
  "in_reply_to_status_id" : 718015482188718080,
  "created_at" : "2016-04-07 10:07:43 +0000",
  "in_reply_to_screen_name" : "DiLeed",
  "in_reply_to_user_id_str" : "2335217159",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/718014809376178176\/photo\/1",
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/V7BrYtoKEe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfbmqgkXEAAftzv.jpg",
      "id_str" : "718014808583507968",
      "id" : 718014808583507968,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfbmqgkXEAAftzv.jpg",
      "sizes" : [ {
        "h" : 248,
        "resize" : "fit",
        "w" : 1295
      }, {
        "h" : 65,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 196,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 115,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/V7BrYtoKEe"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/ngrkoPwr3j",
      "expanded_url" : "http:\/\/cfgg.decontextualize.com\/gen.html?key=1s-uCFGAck3a7L-cfRUpfT2En92wcxxiXnN2g1S5Jjug",
      "display_url" : "cfgg.decontextualize.com\/gen.html?key=1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "718014809376178176",
  "text" : "Vive Game of Charlies https:\/\/t.co\/ngrkoPwr3j https:\/\/t.co\/V7BrYtoKEe",
  "id" : 718014809376178176,
  "created_at" : "2016-04-07 09:57:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EAPsteve",
      "screen_name" : "EAPstephen",
      "indices" : [ 0, 11 ],
      "id_str" : "2717005711",
      "id" : 2717005711
    }, {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 12, 23 ],
      "id_str" : "144663117",
      "id" : 144663117
    }, {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 24, 40 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "718013677186785280",
  "geo" : { },
  "id_str" : "718014388809150464",
  "in_reply_to_user_id" : 2717005711,
  "text" : "@EAPstephen @kevchanwow @getgreatenglish guess would need to try options out unless literature already recommends?",
  "id" : 718014388809150464,
  "in_reply_to_status_id" : 718013677186785280,
  "created_at" : "2016-04-07 09:55:45 +0000",
  "in_reply_to_screen_name" : "EAPstephen",
  "in_reply_to_user_id_str" : "2717005711",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EAPsteve",
      "screen_name" : "EAPstephen",
      "indices" : [ 0, 11 ],
      "id_str" : "2717005711",
      "id" : 2717005711
    }, {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 12, 23 ],
      "id_str" : "144663117",
      "id" : 144663117
    }, {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 24, 40 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "718008649151561728",
  "geo" : { },
  "id_str" : "718012466928689156",
  "in_reply_to_user_id" : 2717005711,
  "text" : "@EAPstephen @kevchanwow @getgreatenglish u can base assessmt on shared outcome more than varied input?",
  "id" : 718012466928689156,
  "in_reply_to_status_id" : 718008649151561728,
  "created_at" : "2016-04-07 09:48:06 +0000",
  "in_reply_to_screen_name" : "EAPstephen",
  "in_reply_to_user_id_str" : "2717005711",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "717668625524523008",
  "geo" : { },
  "id_str" : "718010940193705985",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow to what extent is the  educational culture bondedness of LA an issue worth evaluating?",
  "id" : 718010940193705985,
  "in_reply_to_status_id" : 717668625524523008,
  "created_at" : "2016-04-07 09:42:02 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/718007414675619840\/photo\/1",
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/qovF4GcnqW",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Cfbf0LAW4AEZnSz.jpg",
      "id_str" : "718007278012653569",
      "id" : 718007278012653569,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Cfbf0LAW4AEZnSz.jpg",
      "sizes" : [ {
        "h" : 180,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 180,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 180,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 180,
        "resize" : "fit",
        "w" : 320
      } ],
      "display_url" : "pic.twitter.com\/qovF4GcnqW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "718006348512759809",
  "geo" : { },
  "id_str" : "718007414675619840",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish word https:\/\/t.co\/qovF4GcnqW",
  "id" : 718007414675619840,
  "in_reply_to_status_id" : 718006348512759809,
  "created_at" : "2016-04-07 09:28:02 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "717888787070607361",
  "geo" : { },
  "id_str" : "718006155419783169",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish Excel has become overlooked productivity program in today's software landscape, dare I say the Cinderella of productivity?",
  "id" : 718006155419783169,
  "in_reply_to_status_id" : 717888787070607361,
  "created_at" : "2016-04-07 09:23:02 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcus Chown",
      "screen_name" : "marcuschown",
      "indices" : [ 3, 15 ],
      "id_str" : "38205414",
      "id" : 38205414
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/marcuschown\/status\/714143321803919360\/photo\/1",
      "indices" : [ 143, 144 ],
      "url" : "https:\/\/t.co\/d2FJu1G9uA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ceklhv2XEAEBkKP.jpg",
      "id_str" : "714143277625315329",
      "id" : 714143277625315329,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ceklhv2XEAEBkKP.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 350,
        "resize" : "fit",
        "w" : 570
      }, {
        "h" : 350,
        "resize" : "fit",
        "w" : 570
      }, {
        "h" : 209,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 350,
        "resize" : "fit",
        "w" : 570
      } ],
      "display_url" : "pic.twitter.com\/d2FJu1G9uA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "718004439454457857",
  "text" : "RT @marcuschown: If you're not careful, newspapers will have you hating people being oppressed &amp; loving people oppressing - Malcolm X https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/marcuschown\/status\/714143321803919360\/photo\/1",
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/d2FJu1G9uA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ceklhv2XEAEBkKP.jpg",
        "id_str" : "714143277625315329",
        "id" : 714143277625315329,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ceklhv2XEAEBkKP.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 350,
          "resize" : "fit",
          "w" : 570
        }, {
          "h" : 350,
          "resize" : "fit",
          "w" : 570
        }, {
          "h" : 209,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 350,
          "resize" : "fit",
          "w" : 570
        } ],
        "display_url" : "pic.twitter.com\/d2FJu1G9uA"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "717975440997097472",
    "text" : "If you're not careful, newspapers will have you hating people being oppressed &amp; loving people oppressing - Malcolm X https:\/\/t.co\/d2FJu1G9uA",
    "id" : 717975440997097472,
    "created_at" : "2016-04-07 07:20:59 +0000",
    "user" : {
      "name" : "Marcus Chown",
      "screen_name" : "marcuschown",
      "protected" : false,
      "id_str" : "38205414",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/681518625090580480\/BJUBjRiS_normal.jpg",
      "id" : 38205414,
      "verified" : false
    }
  },
  "id" : 718004439454457857,
  "created_at" : "2016-04-07 09:16:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AllThingsLinguistic",
      "screen_name" : "AllThingsLing",
      "indices" : [ 3, 17 ],
      "id_str" : "857291268",
      "id" : 857291268
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lingwiki",
      "indices" : [ 80, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/wg0hDBxJ3F",
      "expanded_url" : "https:\/\/tmblr.co\/ZuWOEv24c1pP",
      "display_url" : "tmblr.co\/ZuWOEv24c1pP"
    } ]
  },
  "geo" : { },
  "id_str" : "717857333427249152",
  "text" : "RT @AllThingsLing: Diversity in Linguistics: encouraging grad students, writing #lingwiki bios, and other things linguists can do https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "lingwiki",
        "indices" : [ 61, 70 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/wg0hDBxJ3F",
        "expanded_url" : "https:\/\/tmblr.co\/ZuWOEv24c1pP",
        "display_url" : "tmblr.co\/ZuWOEv24c1pP"
      } ]
    },
    "geo" : { },
    "id_str" : "717841910430302208",
    "text" : "Diversity in Linguistics: encouraging grad students, writing #lingwiki bios, and other things linguists can do https:\/\/t.co\/wg0hDBxJ3F",
    "id" : 717841910430302208,
    "created_at" : "2016-04-06 22:30:22 +0000",
    "user" : {
      "name" : "AllThingsLinguistic",
      "screen_name" : "AllThingsLing",
      "protected" : false,
      "id_str" : "857291268",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750400997206454273\/N0DmrmFi_normal.jpg",
      "id" : 857291268,
      "verified" : false
    }
  },
  "id" : 717857333427249152,
  "created_at" : "2016-04-06 23:31:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BRAVE Learning",
      "screen_name" : "BRAVE_Learning",
      "indices" : [ 0, 15 ],
      "id_str" : "222498082",
      "id" : 222498082
    }, {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 16, 28 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "717806252290662402",
  "geo" : { },
  "id_str" : "717849962994860032",
  "in_reply_to_user_id" : 222498082,
  "text" : "@BRAVE_Learning @AnneHendler thanks for sharing : )",
  "id" : 717849962994860032,
  "in_reply_to_status_id" : 717806252290662402,
  "created_at" : "2016-04-06 23:02:22 +0000",
  "in_reply_to_screen_name" : "BRAVE_Learning",
  "in_reply_to_user_id_str" : "222498082",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/QGPXXg9ufp",
      "expanded_url" : "https:\/\/twitter.com\/STWuk\/status\/717760144382287873",
      "display_url" : "twitter.com\/STWuk\/status\/7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "717849765153751041",
  "text" : "RT @medialens: 'A number of wrong arguments here seem to collide.' Indeed.  https:\/\/t.co\/QGPXXg9ufp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/QGPXXg9ufp",
        "expanded_url" : "https:\/\/twitter.com\/STWuk\/status\/717760144382287873",
        "display_url" : "twitter.com\/STWuk\/status\/7\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "717773628008493056",
    "text" : "'A number of wrong arguments here seem to collide.' Indeed.  https:\/\/t.co\/QGPXXg9ufp",
    "id" : 717773628008493056,
    "created_at" : "2016-04-06 17:59:03 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 717849765153751041,
  "created_at" : "2016-04-06 23:01:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/717847308038176768\/photo\/1",
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/RdvRnhg3Ym",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfZOUmwXIAEggyc.jpg",
      "id_str" : "717847306519912449",
      "id" : 717847306519912449,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfZOUmwXIAEggyc.jpg",
      "sizes" : [ {
        "h" : 263,
        "resize" : "fit",
        "w" : 1368
      }, {
        "h" : 65,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 197,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 115,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/RdvRnhg3Ym"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/ngrkoPwr3j",
      "expanded_url" : "http:\/\/cfgg.decontextualize.com\/gen.html?key=1s-uCFGAck3a7L-cfRUpfT2En92wcxxiXnN2g1S5Jjug",
      "display_url" : "cfgg.decontextualize.com\/gen.html?key=1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "717847308038176768",
  "text" : "Vive Game of Charlies https:\/\/t.co\/ngrkoPwr3j https:\/\/t.co\/RdvRnhg3Ym",
  "id" : 717847308038176768,
  "created_at" : "2016-04-06 22:51:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/717846410981416960\/photo\/1",
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/yUx0ZC4kh5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfZNgbTXIAAFz6J.jpg",
      "id_str" : "717846410092290048",
      "id" : 717846410092290048,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfZNgbTXIAAFz6J.jpg",
      "sizes" : [ {
        "h" : 116,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 198,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 269,
        "resize" : "fit",
        "w" : 1393
      }, {
        "h" : 66,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/yUx0ZC4kh5"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/ngrkoPwr3j",
      "expanded_url" : "http:\/\/cfgg.decontextualize.com\/gen.html?key=1s-uCFGAck3a7L-cfRUpfT2En92wcxxiXnN2g1S5Jjug",
      "display_url" : "cfgg.decontextualize.com\/gen.html?key=1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "717846410981416960",
  "text" : "Vive Game of Charlies https:\/\/t.co\/ngrkoPwr3j https:\/\/t.co\/yUx0ZC4kh5",
  "id" : 717846410981416960,
  "created_at" : "2016-04-06 22:48:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/717799500245573633\/photo\/1",
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/Tu2xsyaaKu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfYi13NWEAALmL8.jpg",
      "id_str" : "717799499360505856",
      "id" : 717799499360505856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfYi13NWEAALmL8.jpg",
      "sizes" : [ {
        "h" : 64,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 113,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 193,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 1352
      } ],
      "display_url" : "pic.twitter.com\/Tu2xsyaaKu"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/ngrkoPwr3j",
      "expanded_url" : "http:\/\/cfgg.decontextualize.com\/gen.html?key=1s-uCFGAck3a7L-cfRUpfT2En92wcxxiXnN2g1S5Jjug",
      "display_url" : "cfgg.decontextualize.com\/gen.html?key=1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "717799500245573633",
  "text" : "Vive Games of Charlies https:\/\/t.co\/ngrkoPwr3j https:\/\/t.co\/Tu2xsyaaKu",
  "id" : 717799500245573633,
  "created_at" : "2016-04-06 19:41:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vedrana Vojkovi\u0107",
      "screen_name" : "Ven_VVE",
      "indices" : [ 0, 8 ],
      "id_str" : "270839603",
      "id" : 270839603
    }, {
      "name" : "Helen Legge",
      "screen_name" : "ITLegge",
      "indices" : [ 9, 17 ],
      "id_str" : "2201561838",
      "id" : 2201561838
    }, {
      "name" : "EAPsteve",
      "screen_name" : "EAPstephen",
      "indices" : [ 18, 29 ],
      "id_str" : "2717005711",
      "id" : 2717005711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "717791975353745408",
  "geo" : { },
  "id_str" : "717797903046193152",
  "in_reply_to_user_id" : 270839603,
  "text" : "@Ven_VVE @ITLegge @EAPstephen when you're rushing to leave do you say \"have you got the confirmation\/ticket?\" : )",
  "id" : 717797903046193152,
  "in_reply_to_status_id" : 717791975353745408,
  "created_at" : "2016-04-06 19:35:30 +0000",
  "in_reply_to_screen_name" : "Ven_VVE",
  "in_reply_to_user_id_str" : "270839603",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/717791405637312512\/photo\/1",
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/4WdbDrvIqK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfYbeocW8AAgGPk.jpg",
      "id_str" : "717791403678560256",
      "id" : 717791403678560256,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfYbeocW8AAgGPk.jpg",
      "sizes" : [ {
        "h" : 164,
        "resize" : "fit",
        "w" : 514
      }, {
        "h" : 108,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 164,
        "resize" : "fit",
        "w" : 514
      }, {
        "h" : 164,
        "resize" : "fit",
        "w" : 514
      } ],
      "display_url" : "pic.twitter.com\/4WdbDrvIqK"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/ngrkoPwr3j",
      "expanded_url" : "http:\/\/cfgg.decontextualize.com\/gen.html?key=1s-uCFGAck3a7L-cfRUpfT2En92wcxxiXnN2g1S5Jjug",
      "display_url" : "cfgg.decontextualize.com\/gen.html?key=1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "717791405637312512",
  "text" : "Vive Game of Charlies https:\/\/t.co\/ngrkoPwr3j https:\/\/t.co\/4WdbDrvIqK",
  "id" : 717791405637312512,
  "created_at" : "2016-04-06 19:09:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/717788243782213633\/photo\/1",
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/eipZQwChDJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfYYmptWQAAmb82.jpg",
      "id_str" : "717788242922323968",
      "id" : 717788242922323968,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfYYmptWQAAmb82.jpg",
      "sizes" : [ {
        "h" : 178,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 228,
        "resize" : "fit",
        "w" : 1313
      }, {
        "h" : 104,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 59,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/eipZQwChDJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/ngrkoPwr3j",
      "expanded_url" : "http:\/\/cfgg.decontextualize.com\/gen.html?key=1s-uCFGAck3a7L-cfRUpfT2En92wcxxiXnN2g1S5Jjug",
      "display_url" : "cfgg.decontextualize.com\/gen.html?key=1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "717788243782213633",
  "text" : "Vive Game of Charlies https:\/\/t.co\/ngrkoPwr3j https:\/\/t.co\/eipZQwChDJ",
  "id" : 717788243782213633,
  "created_at" : "2016-04-06 18:57:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/717781197884157952\/photo\/1",
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/JmlkUwshJC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfYSMeXWEAAHtw0.jpg",
      "id_str" : "717781196130881536",
      "id" : 717781196130881536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfYSMeXWEAAHtw0.jpg",
      "sizes" : [ {
        "h" : 229,
        "resize" : "fit",
        "w" : 1370
      }, {
        "h" : 171,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 57,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 100,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/JmlkUwshJC"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/ngrkoPwr3j",
      "expanded_url" : "http:\/\/cfgg.decontextualize.com\/gen.html?key=1s-uCFGAck3a7L-cfRUpfT2En92wcxxiXnN2g1S5Jjug",
      "display_url" : "cfgg.decontextualize.com\/gen.html?key=1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "717781197884157952",
  "text" : "Vive Game of Charlies https:\/\/t.co\/ngrkoPwr3j https:\/\/t.co\/JmlkUwshJC",
  "id" : 717781197884157952,
  "created_at" : "2016-04-06 18:29:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helen Legge",
      "screen_name" : "ITLegge",
      "indices" : [ 0, 8 ],
      "id_str" : "2201561838",
      "id" : 2201561838
    }, {
      "name" : "Vedrana Vojkovi\u0107",
      "screen_name" : "Ven_VVE",
      "indices" : [ 9, 17 ],
      "id_str" : "270839603",
      "id" : 270839603
    }, {
      "name" : "EAPsteve",
      "screen_name" : "EAPstephen",
      "indices" : [ 18, 29 ],
      "id_str" : "2717005711",
      "id" : 2717005711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "717771363742785536",
  "geo" : { },
  "id_str" : "717771993660133376",
  "in_reply_to_user_id" : 2201561838,
  "text" : "@ITLegge @Ven_VVE @EAPstephen times a changin",
  "id" : 717771993660133376,
  "in_reply_to_status_id" : 717771363742785536,
  "created_at" : "2016-04-06 17:52:33 +0000",
  "in_reply_to_screen_name" : "ITLegge",
  "in_reply_to_user_id_str" : "2201561838",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/717762424875720704\/photo\/1",
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/fiM5RKNmkL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfYBHyzXIAUaEB3.jpg",
      "id_str" : "717762424020082693",
      "id" : 717762424020082693,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfYBHyzXIAUaEB3.jpg",
      "sizes" : [ {
        "h" : 187,
        "resize" : "fit",
        "w" : 1373
      }, {
        "h" : 46,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 139,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 82,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/fiM5RKNmkL"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/ngrkoPwr3j",
      "expanded_url" : "http:\/\/cfgg.decontextualize.com\/gen.html?key=1s-uCFGAck3a7L-cfRUpfT2En92wcxxiXnN2g1S5Jjug",
      "display_url" : "cfgg.decontextualize.com\/gen.html?key=1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "717762424875720704",
  "text" : "Vive Game of Thrones https:\/\/t.co\/ngrkoPwr3j https:\/\/t.co\/fiM5RKNmkL",
  "id" : 717762424875720704,
  "created_at" : "2016-04-06 17:14:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/717758087290089473\/photo\/1",
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/KsjbBny8nS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfX9LQaW4AAgbqJ.jpg",
      "id_str" : "717758085461368832",
      "id" : 717758085461368832,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfX9LQaW4AAgbqJ.jpg",
      "sizes" : [ {
        "h" : 51,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 90,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 208,
        "resize" : "fit",
        "w" : 1389
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 153,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/KsjbBny8nS"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/ngrkoPwr3j",
      "expanded_url" : "http:\/\/cfgg.decontextualize.com\/gen.html?key=1s-uCFGAck3a7L-cfRUpfT2En92wcxxiXnN2g1S5Jjug",
      "display_url" : "cfgg.decontextualize.com\/gen.html?key=1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "717758087290089473",
  "text" : "Game of Charlies https:\/\/t.co\/ngrkoPwr3j https:\/\/t.co\/KsjbBny8nS",
  "id" : 717758087290089473,
  "created_at" : "2016-04-06 16:57:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vedrana Vojkovi\u0107",
      "screen_name" : "Ven_VVE",
      "indices" : [ 0, 8 ],
      "id_str" : "270839603",
      "id" : 270839603
    }, {
      "name" : "Helen Legge",
      "screen_name" : "ITLegge",
      "indices" : [ 9, 17 ],
      "id_str" : "2201561838",
      "id" : 2201561838
    }, {
      "name" : "EAPsteve",
      "screen_name" : "EAPstephen",
      "indices" : [ 18, 29 ],
      "id_str" : "2717005711",
      "id" : 2717005711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "717752112063578113",
  "geo" : { },
  "id_str" : "717755474746216448",
  "in_reply_to_user_id" : 270839603,
  "text" : "@Ven_VVE @ITLegge @EAPstephen i guess ticket, pass is more used?",
  "id" : 717755474746216448,
  "in_reply_to_status_id" : 717752112063578113,
  "created_at" : "2016-04-06 16:46:55 +0000",
  "in_reply_to_screen_name" : "Ven_VVE",
  "in_reply_to_user_id_str" : "270839603",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/717750126412955648\/photo\/1",
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/5PRr0hLY1v",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfX177bWIAAIrDe.jpg",
      "id_str" : "717750125548937216",
      "id" : 717750125548937216,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfX177bWIAAIrDe.jpg",
      "sizes" : [ {
        "h" : 141,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 47,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 187,
        "resize" : "fit",
        "w" : 1361
      }, {
        "h" : 82,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/5PRr0hLY1v"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/ngrkoPwr3j",
      "expanded_url" : "http:\/\/cfgg.decontextualize.com\/gen.html?key=1s-uCFGAck3a7L-cfRUpfT2En92wcxxiXnN2g1S5Jjug",
      "display_url" : "cfgg.decontextualize.com\/gen.html?key=1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "717750126412955648",
  "text" : "Game of Charlies https:\/\/t.co\/ngrkoPwr3j https:\/\/t.co\/5PRr0hLY1v",
  "id" : 717750126412955648,
  "created_at" : "2016-04-06 16:25:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/717747918288060417\/photo\/1",
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/zr8tyQC8Qt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfXz7ZqWwAAjZBC.jpg",
      "id_str" : "717747917461831680",
      "id" : 717747917461831680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfXz7ZqWwAAjZBC.jpg",
      "sizes" : [ {
        "h" : 85,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 48,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 146,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 1342
      } ],
      "display_url" : "pic.twitter.com\/zr8tyQC8Qt"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/ngrkoPwr3j",
      "expanded_url" : "http:\/\/cfgg.decontextualize.com\/gen.html?key=1s-uCFGAck3a7L-cfRUpfT2En92wcxxiXnN2g1S5Jjug",
      "display_url" : "cfgg.decontextualize.com\/gen.html?key=1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "717747918288060417",
  "text" : "Vive Game of Charlies https:\/\/t.co\/ngrkoPwr3j https:\/\/t.co\/zr8tyQC8Qt",
  "id" : 717747918288060417,
  "created_at" : "2016-04-06 16:16:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helen Legge",
      "screen_name" : "ITLegge",
      "indices" : [ 0, 8 ],
      "id_str" : "2201561838",
      "id" : 2201561838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "717728370973401090",
  "geo" : { },
  "id_str" : "717730877728497664",
  "in_reply_to_user_id" : 2201561838,
  "text" : "@ITLegge what would be alternatives?",
  "id" : 717730877728497664,
  "in_reply_to_status_id" : 717728370973401090,
  "created_at" : "2016-04-06 15:09:10 +0000",
  "in_reply_to_screen_name" : "ITLegge",
  "in_reply_to_user_id_str" : "2201561838",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Jones",
      "screen_name" : "ELTResearch",
      "indices" : [ 0, 12 ],
      "id_str" : "3308043417",
      "id" : 3308043417
    }, {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 13, 24 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/hEka1RiIn9",
      "expanded_url" : "http:\/\/corpus.byu.edu\/glowbe\/?c=glowbe&q=46601986",
      "display_url" : "corpus.byu.edu\/glowbe\/?c=glow\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "717718957143298048",
  "geo" : { },
  "id_str" : "717719935141744640",
  "in_reply_to_user_id" : 3308043417,
  "text" : "@ELTResearch @lexicoloco there are 3 hits of soap in connection with Game of Thrones in Glowbe : ) https:\/\/t.co\/hEka1RiIn9",
  "id" : 717719935141744640,
  "in_reply_to_status_id" : 717718957143298048,
  "created_at" : "2016-04-06 14:25:41 +0000",
  "in_reply_to_screen_name" : "ELTResearch",
  "in_reply_to_user_id_str" : "3308043417",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Jones",
      "screen_name" : "ELTResearch",
      "indices" : [ 0, 12 ],
      "id_str" : "3308043417",
      "id" : 3308043417
    }, {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 13, 24 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "717716664360562689",
  "geo" : { },
  "id_str" : "717718428426059776",
  "in_reply_to_user_id" : 3308043417,
  "text" : "@ELTResearch @lexicoloco would also need separate cleaning related from TV, Glowbe gives many cleaning related, tv related about 90",
  "id" : 717718428426059776,
  "in_reply_to_status_id" : 717716664360562689,
  "created_at" : "2016-04-06 14:19:42 +0000",
  "in_reply_to_screen_name" : "ELTResearch",
  "in_reply_to_user_id_str" : "3308043417",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Jones",
      "screen_name" : "ELTResearch",
      "indices" : [ 0, 12 ],
      "id_str" : "3308043417",
      "id" : 3308043417
    }, {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 13, 24 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "717716664360562689",
  "geo" : { },
  "id_str" : "717717542362554369",
  "in_reply_to_user_id" : 3308043417,
  "text" : "@ELTResearch @lexicoloco yes though not many hits in Monco about 50",
  "id" : 717717542362554369,
  "in_reply_to_status_id" : 717716664360562689,
  "created_at" : "2016-04-06 14:16:11 +0000",
  "in_reply_to_screen_name" : "ELTResearch",
  "in_reply_to_user_id_str" : "3308043417",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "717715195888607232",
  "geo" : { },
  "id_str" : "717715856969637891",
  "in_reply_to_user_id" : 18602422,
  "text" : "@lexicoloco in COCA tv show more freq than soap opera; in BNC opposite",
  "id" : 717715856969637891,
  "in_reply_to_status_id" : 717715195888607232,
  "created_at" : "2016-04-06 14:09:29 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "717661927946760192",
  "geo" : { },
  "id_str" : "717715195888607232",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco tv collocates strongly with show &amp; series, no collocation with soap opera; and soap collocates strongly with opera and star",
  "id" : 717715195888607232,
  "in_reply_to_status_id" : 717661927946760192,
  "created_at" : "2016-04-06 14:06:51 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maha Alfahad",
      "screen_name" : "alfahadM1",
      "indices" : [ 0, 10 ],
      "id_str" : "395177979",
      "id" : 395177979
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716378780248322048",
  "geo" : { },
  "id_str" : "717704359883227136",
  "in_reply_to_user_id" : 18602422,
  "text" : "@alfahadM1 thanks for sharing : )",
  "id" : 717704359883227136,
  "in_reply_to_status_id" : 716378780248322048,
  "created_at" : "2016-04-06 13:23:48 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Magnus Nissel",
      "screen_name" : "u203d",
      "indices" : [ 0, 6 ],
      "id_str" : "533114985",
      "id" : 533114985
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "717661148049440768",
  "geo" : { },
  "id_str" : "717677787667161089",
  "in_reply_to_user_id" : 533114985,
  "text" : "@u203d one can unpublish an older edition I guess?",
  "id" : 717677787667161089,
  "in_reply_to_status_id" : 717661148049440768,
  "created_at" : "2016-04-06 11:38:13 +0000",
  "in_reply_to_screen_name" : "u203d",
  "in_reply_to_user_id_str" : "533114985",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "717661927946760192",
  "geo" : { },
  "id_str" : "717677390416232448",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco thx will have another look",
  "id" : 717677390416232448,
  "in_reply_to_status_id" : 717661927946760192,
  "created_at" : "2016-04-06 11:36:38 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helen Legge",
      "screen_name" : "ITLegge",
      "indices" : [ 0, 8 ],
      "id_str" : "2201561838",
      "id" : 2201561838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "717636816669655040",
  "geo" : { },
  "id_str" : "717651917292376064",
  "in_reply_to_user_id" : 2201561838,
  "text" : "@ITLegge that's surprising for \"plane ticket\"?",
  "id" : 717651917292376064,
  "in_reply_to_status_id" : 717636816669655040,
  "created_at" : "2016-04-06 09:55:25 +0000",
  "in_reply_to_screen_name" : "ITLegge",
  "in_reply_to_user_id_str" : "2201561838",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 3, 17 ],
      "id_str" : "25388528",
      "id" : 25388528
    }, {
      "name" : "Bill Fitzgerald",
      "screen_name" : "funnymonkey",
      "indices" : [ 20, 32 ],
      "id_str" : "12127972",
      "id" : 12127972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 124, 140 ],
      "url" : "https:\/\/t.co\/b6fJETsn9s",
      "expanded_url" : "https:\/\/funnymonkey.com\/2016\/terms-of-service-and-privacy-policies-at-characterlab",
      "display_url" : "funnymonkey.com\/2016\/terms-of-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "717651502370844672",
  "text" : "RT @audreywatters: .@funnymonkey takes a close look at the Terms of Service of Angela Duckworth\u2019s \u201Cgrit\u201D-promoting software https:\/\/t.co\/b6\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bill Fitzgerald",
        "screen_name" : "funnymonkey",
        "indices" : [ 1, 13 ],
        "id_str" : "12127972",
        "id" : 12127972
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/b6fJETsn9s",
        "expanded_url" : "https:\/\/funnymonkey.com\/2016\/terms-of-service-and-privacy-policies-at-characterlab",
        "display_url" : "funnymonkey.com\/2016\/terms-of-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "717013011953623041",
    "text" : ".@funnymonkey takes a close look at the Terms of Service of Angela Duckworth\u2019s \u201Cgrit\u201D-promoting software https:\/\/t.co\/b6fJETsn9s",
    "id" : 717013011953623041,
    "created_at" : "2016-04-04 15:36:38 +0000",
    "user" : {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "protected" : false,
      "id_str" : "25388528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711668009723498496\/pauFZsdv_normal.jpg",
      "id" : 25388528,
      "verified" : false
    }
  },
  "id" : 717651502370844672,
  "created_at" : "2016-04-06 09:53:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "717612960907202560",
  "text" : "Accounting for my cognitive bias &amp; city bias I can't recall seeing someone read Charlie hebdo on metro\/rer\/sncf",
  "id" : 717612960907202560,
  "created_at" : "2016-04-06 07:20:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josephkerski",
      "screen_name" : "josephkerski",
      "indices" : [ 3, 16 ],
      "id_str" : "18056084",
      "id" : 18056084
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/josephkerski\/status\/717557907538096128\/photo\/1",
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/kJBOmAxbIi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfVHHBCUkAAzxza.jpg",
      "id_str" : "717557901498290176",
      "id" : 717557901498290176,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfVHHBCUkAAzxza.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 453
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 453
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 453
      } ],
      "display_url" : "pic.twitter.com\/kJBOmAxbIi"
    } ],
    "hashtags" : [ {
      "text" : "geography",
      "indices" : [ 94, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "717598029541478401",
  "text" : "RT @josephkerski: Too cool\u2026 Photographs of the sun at the same time every day for 365 days.   #geography https:\/\/t.co\/kJBOmAxbIi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/josephkerski\/status\/717557907538096128\/photo\/1",
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/kJBOmAxbIi",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CfVHHBCUkAAzxza.jpg",
        "id_str" : "717557901498290176",
        "id" : 717557901498290176,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfVHHBCUkAAzxza.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 453
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 453
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 453
        } ],
        "display_url" : "pic.twitter.com\/kJBOmAxbIi"
      } ],
      "hashtags" : [ {
        "text" : "geography",
        "indices" : [ 76, 86 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "717557907538096128",
    "text" : "Too cool\u2026 Photographs of the sun at the same time every day for 365 days.   #geography https:\/\/t.co\/kJBOmAxbIi",
    "id" : 717557907538096128,
    "created_at" : "2016-04-06 03:41:51 +0000",
    "user" : {
      "name" : "josephkerski",
      "screen_name" : "josephkerski",
      "protected" : false,
      "id_str" : "18056084",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/716008883\/jjk_map_n_am_pointing_sm_normal.jpg",
      "id" : 18056084,
      "verified" : false
    }
  },
  "id" : 717598029541478401,
  "created_at" : "2016-04-06 06:21:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/717593430180933632\/photo\/1",
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/GSV2RUHw35",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfVna_WWQAAXWYR.jpg",
      "id_str" : "717593429014888448",
      "id" : 717593429014888448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfVna_WWQAAXWYR.jpg",
      "sizes" : [ {
        "h" : 82,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 189,
        "resize" : "fit",
        "w" : 784
      }, {
        "h" : 145,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 189,
        "resize" : "fit",
        "w" : 784
      } ],
      "display_url" : "pic.twitter.com\/GSV2RUHw35"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "717593430180933632",
  "text" : "99 problems son but an ebook ain't one : ) https:\/\/t.co\/GSV2RUHw35",
  "id" : 717593430180933632,
  "created_at" : "2016-04-06 06:03:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel O'Sullivan",
      "screen_name" : "danielanthonyos",
      "indices" : [ 3, 19 ],
      "id_str" : "2721042312",
      "id" : 2721042312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/JYRRJD1owJ",
      "expanded_url" : "https:\/\/twitter.com\/helenrazer\/status\/717523355943874562",
      "display_url" : "twitter.com\/helenrazer\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "717590380070494208",
  "text" : "RT @danielanthonyos: Brilliant - racist bigots should be 'passed wind upon' https:\/\/t.co\/JYRRJD1owJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 78 ],
        "url" : "https:\/\/t.co\/JYRRJD1owJ",
        "expanded_url" : "https:\/\/twitter.com\/helenrazer\/status\/717523355943874562",
        "display_url" : "twitter.com\/helenrazer\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "717588511197499392",
    "text" : "Brilliant - racist bigots should be 'passed wind upon' https:\/\/t.co\/JYRRJD1owJ",
    "id" : 717588511197499392,
    "created_at" : "2016-04-06 05:43:27 +0000",
    "user" : {
      "name" : "Daniel O'Sullivan",
      "screen_name" : "danielanthonyos",
      "protected" : false,
      "id_str" : "2721042312",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/498393134791786497\/wYBDVlep_normal.jpeg",
      "id" : 2721042312,
      "verified" : false
    }
  },
  "id" : 717590380070494208,
  "created_at" : "2016-04-06 05:50:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/717495709856055296\/photo\/1",
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/IBL5Ym1so1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfUOi6ZWAAIAQt9.jpg",
      "id_str" : "717495708589359106",
      "id" : 717495708589359106,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfUOi6ZWAAIAQt9.jpg",
      "sizes" : [ {
        "h" : 367,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 584,
        "resize" : "fit",
        "w" : 955
      }, {
        "h" : 584,
        "resize" : "fit",
        "w" : 955
      }, {
        "h" : 208,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/IBL5Ym1so1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "717495709856055296",
  "text" : "Hail Caesar! https:\/\/t.co\/IBL5Ym1so1",
  "id" : 717495709856055296,
  "created_at" : "2016-04-05 23:34:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Bourg",
      "screen_name" : "mchris4duke",
      "indices" : [ 3, 15 ],
      "id_str" : "14093339",
      "id" : 14093339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/Emyp2p2pJz",
      "expanded_url" : "https:\/\/twitter.com\/AP\/status\/717390869524045824",
      "display_url" : "twitter.com\/AP\/status\/7173\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "717462380200992768",
  "text" : "RT @mchris4duke: F*ck you mississippi https:\/\/t.co\/Emyp2p2pJz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 21, 44 ],
        "url" : "https:\/\/t.co\/Emyp2p2pJz",
        "expanded_url" : "https:\/\/twitter.com\/AP\/status\/717390869524045824",
        "display_url" : "twitter.com\/AP\/status\/7173\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "717392217187426304",
    "text" : "F*ck you mississippi https:\/\/t.co\/Emyp2p2pJz",
    "id" : 717392217187426304,
    "created_at" : "2016-04-05 16:43:27 +0000",
    "user" : {
      "name" : "Chris Bourg",
      "screen_name" : "mchris4duke",
      "protected" : false,
      "id_str" : "14093339",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/767025290400989184\/nxbrk0BI_normal.jpg",
      "id" : 14093339,
      "verified" : false
    }
  },
  "id" : 717462380200992768,
  "created_at" : "2016-04-05 21:22:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/cWIqesQy6Y",
      "expanded_url" : "http:\/\/cass.lancs.ac.uk\/wp-content\/uploads\/2013\/12\/CASS-Islam-final.pdf#7",
      "display_url" : "cass.lancs.ac.uk\/wp-content\/upl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "717457971719045124",
  "text" : "more \"evidence\" as to whether \"criticism\" of Islam are being silenced as reflected in UK press https:\/\/t.co\/cWIqesQy6Y less talking crap",
  "id" : 717457971719045124,
  "created_at" : "2016-04-05 21:04:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Emersberger",
      "screen_name" : "rosendo_joe",
      "indices" : [ 3, 15 ],
      "id_str" : "3351345863",
      "id" : 3351345863
    }, {
      "name" : "Sharmine Narwani",
      "screen_name" : "snarwani",
      "indices" : [ 18, 27 ],
      "id_str" : "48534642",
      "id" : 48534642
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/rosendo_joe\/status\/717452792391213057\/photo\/1",
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/RBx2qKtVg1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfTng0zWAAA9mab.jpg",
      "id_str" : "717452791774576640",
      "id" : 717452791774576640,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfTng0zWAAA9mab.jpg",
      "sizes" : [ {
        "h" : 384,
        "resize" : "fit",
        "w" : 496
      }, {
        "h" : 384,
        "resize" : "fit",
        "w" : 496
      }, {
        "h" : 384,
        "resize" : "fit",
        "w" : 496
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 263,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/RBx2qKtVg1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "717453143261519872",
  "text" : "RT @rosendo_joe: .@snarwani on Panama Papers https:\/\/t.co\/RBx2qKtVg1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sharmine Narwani",
        "screen_name" : "snarwani",
        "indices" : [ 1, 10 ],
        "id_str" : "48534642",
        "id" : 48534642
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/rosendo_joe\/status\/717452792391213057\/photo\/1",
        "indices" : [ 28, 51 ],
        "url" : "https:\/\/t.co\/RBx2qKtVg1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CfTng0zWAAA9mab.jpg",
        "id_str" : "717452791774576640",
        "id" : 717452791774576640,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfTng0zWAAA9mab.jpg",
        "sizes" : [ {
          "h" : 384,
          "resize" : "fit",
          "w" : 496
        }, {
          "h" : 384,
          "resize" : "fit",
          "w" : 496
        }, {
          "h" : 384,
          "resize" : "fit",
          "w" : 496
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 263,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/RBx2qKtVg1"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "717452792391213057",
    "text" : ".@snarwani on Panama Papers https:\/\/t.co\/RBx2qKtVg1",
    "id" : 717452792391213057,
    "created_at" : "2016-04-05 20:44:09 +0000",
    "user" : {
      "name" : "Joe Emersberger",
      "screen_name" : "rosendo_joe",
      "protected" : false,
      "id_str" : "3351345863",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/621112707522142209\/OGmLR1xt_normal.jpg",
      "id" : 3351345863,
      "verified" : false
    }
  },
  "id" : 717453143261519872,
  "created_at" : "2016-04-05 20:45:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/717450463382278146\/photo\/1",
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/LfobZFPTwz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfTlZPbW8AACs-w.jpg",
      "id_str" : "717450462459523072",
      "id" : 717450462459523072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfTlZPbW8AACs-w.jpg",
      "sizes" : [ {
        "h" : 202,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 115,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 376,
        "resize" : "fit",
        "w" : 1115
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 345,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/LfobZFPTwz"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "717450463382278146",
  "text" : "a coursebook showing its age as sts had no idea what a soap opera was, Monco corpus search reflects this https:\/\/t.co\/LfobZFPTwz",
  "id" : 717450463382278146,
  "created_at" : "2016-04-05 20:34:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Corbyn for PM",
      "screen_name" : "JeremyCorbyn4PM",
      "indices" : [ 3, 19 ],
      "id_str" : "3307929149",
      "id" : 3307929149
    }, {
      "name" : "Jeremy Corbyn MP",
      "screen_name" : "jeremycorbyn",
      "indices" : [ 42, 55 ],
      "id_str" : "117777690",
      "id" : 117777690
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/JeremyCorbyn4PM\/status\/717380236573323264\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/0Bc4456UeU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfSlhHLXEAEbrUu.jpg",
      "id_str" : "717380228939714561",
      "id" : 717380228939714561,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfSlhHLXEAEbrUu.jpg",
      "sizes" : [ {
        "h" : 724,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 724,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 424,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/0Bc4456UeU"
    } ],
    "hashtags" : [ {
      "text" : "panamapapers",
      "indices" : [ 96, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/E6o2G0vJbh",
      "expanded_url" : "http:\/\/www.independent.co.uk\/news\/uk\/home-news\/jeremy-corbyn-calls-for-investigation-into-david-cameron-s-family-over-panama-papers-link-a6969421.html",
      "display_url" : "independent.co.uk\/news\/uk\/home-n\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "717436400988192768",
  "text" : "RT @JeremyCorbyn4PM: RT if you agree with @jeremycorbyn: there needs to be an investigation re: #panamapapers https:\/\/t.co\/E6o2G0vJbh https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jeremy Corbyn MP",
        "screen_name" : "jeremycorbyn",
        "indices" : [ 21, 34 ],
        "id_str" : "117777690",
        "id" : 117777690
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/JeremyCorbyn4PM\/status\/717380236573323264\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/0Bc4456UeU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CfSlhHLXEAEbrUu.jpg",
        "id_str" : "717380228939714561",
        "id" : 717380228939714561,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfSlhHLXEAEbrUu.jpg",
        "sizes" : [ {
          "h" : 724,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 724,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 424,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 240,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/0Bc4456UeU"
      } ],
      "hashtags" : [ {
        "text" : "panamapapers",
        "indices" : [ 75, 88 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/E6o2G0vJbh",
        "expanded_url" : "http:\/\/www.independent.co.uk\/news\/uk\/home-news\/jeremy-corbyn-calls-for-investigation-into-david-cameron-s-family-over-panama-papers-link-a6969421.html",
        "display_url" : "independent.co.uk\/news\/uk\/home-n\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "717380236573323264",
    "text" : "RT if you agree with @jeremycorbyn: there needs to be an investigation re: #panamapapers https:\/\/t.co\/E6o2G0vJbh https:\/\/t.co\/0Bc4456UeU",
    "id" : 717380236573323264,
    "created_at" : "2016-04-05 15:55:51 +0000",
    "user" : {
      "name" : "Jeremy Corbyn for PM",
      "screen_name" : "JeremyCorbyn4PM",
      "protected" : false,
      "id_str" : "3307929149",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746982653350445056\/UHNiRVhu_normal.jpg",
      "id" : 3307929149,
      "verified" : false
    }
  },
  "id" : 717436400988192768,
  "created_at" : "2016-04-05 19:39:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Green",
      "screen_name" : "matthew_d_green",
      "indices" : [ 3, 19 ],
      "id_str" : "106234268",
      "id" : 106234268
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/matthew_d_green\/status\/717432106390065152\/photo\/1",
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/1xBw2KZQfM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfTUr1BWEAAdReF.jpg",
      "id_str" : "717432090090934272",
      "id" : 717432090090934272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfTUr1BWEAAdReF.jpg",
      "sizes" : [ {
        "h" : 231,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 663,
        "resize" : "fit",
        "w" : 974
      }, {
        "h" : 663,
        "resize" : "fit",
        "w" : 974
      }, {
        "h" : 408,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/1xBw2KZQfM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "717435396087484416",
  "text" : "RT @matthew_d_green: Every now and then I glance over to see what my security colleagues are working on. https:\/\/t.co\/1xBw2KZQfM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/matthew_d_green\/status\/717432106390065152\/photo\/1",
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/1xBw2KZQfM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CfTUr1BWEAAdReF.jpg",
        "id_str" : "717432090090934272",
        "id" : 717432090090934272,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfTUr1BWEAAdReF.jpg",
        "sizes" : [ {
          "h" : 231,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 663,
          "resize" : "fit",
          "w" : 974
        }, {
          "h" : 663,
          "resize" : "fit",
          "w" : 974
        }, {
          "h" : 408,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/1xBw2KZQfM"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "717432106390065152",
    "text" : "Every now and then I glance over to see what my security colleagues are working on. https:\/\/t.co\/1xBw2KZQfM",
    "id" : 717432106390065152,
    "created_at" : "2016-04-05 19:21:58 +0000",
    "user" : {
      "name" : "Matthew Green",
      "screen_name" : "matthew_d_green",
      "protected" : false,
      "id_str" : "106234268",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2070934284\/image_normal.jpg",
      "id" : 106234268,
      "verified" : false
    }
  },
  "id" : 717435396087484416,
  "created_at" : "2016-04-05 19:35:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/medialens\/status\/717357319391223809\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/sg3zr7NbtR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfSQrjCWAAAMc58.jpg",
      "id_str" : "717357318472597504",
      "id" : 717357318472597504,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfSQrjCWAAAMc58.jpg",
      "sizes" : [ {
        "h" : 730,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 428,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 766,
        "resize" : "fit",
        "w" : 1074
      }, {
        "h" : 242,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/sg3zr7NbtR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "717433349585969152",
  "text" : "RT @medialens: 'Cameron ducks question....sidesteps issue'. Yes, because the complicit media don't hold 'our' leaders to account. https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/medialens\/status\/717357319391223809\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/sg3zr7NbtR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CfSQrjCWAAAMc58.jpg",
        "id_str" : "717357318472597504",
        "id" : 717357318472597504,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfSQrjCWAAAMc58.jpg",
        "sizes" : [ {
          "h" : 730,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 428,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 766,
          "resize" : "fit",
          "w" : 1074
        }, {
          "h" : 242,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/sg3zr7NbtR"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "717357319391223809",
    "text" : "'Cameron ducks question....sidesteps issue'. Yes, because the complicit media don't hold 'our' leaders to account. https:\/\/t.co\/sg3zr7NbtR",
    "id" : 717357319391223809,
    "created_at" : "2016-04-05 14:24:47 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 717433349585969152,
  "created_at" : "2016-04-05 19:26:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jochen R.",
      "screen_name" : "JoschiFun2Code",
      "indices" : [ 0, 15 ],
      "id_str" : "2428512869",
      "id" : 2428512869
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "717323034412101632",
  "geo" : { },
  "id_str" : "717357081351860225",
  "in_reply_to_user_id" : 2428512869,
  "text" : "@JoschiFun2Code OK thx must be my institurion's network restrictions",
  "id" : 717357081351860225,
  "in_reply_to_status_id" : 717323034412101632,
  "created_at" : "2016-04-05 14:23:50 +0000",
  "in_reply_to_screen_name" : "JoschiFun2Code",
  "in_reply_to_user_id_str" : "2428512869",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Husler",
      "screen_name" : "HuslerGary",
      "indices" : [ 0, 11 ],
      "id_str" : "3621925274",
      "id" : 3621925274
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "717355099509555201",
  "geo" : { },
  "id_str" : "717355720149180416",
  "in_reply_to_user_id" : 3621925274,
  "text" : "@HuslerGary hi Gary I withdrew sometime ago",
  "id" : 717355720149180416,
  "in_reply_to_status_id" : 717355099509555201,
  "created_at" : "2016-04-05 14:18:26 +0000",
  "in_reply_to_screen_name" : "HuslerGary",
  "in_reply_to_user_id_str" : "3621925274",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jochen R.",
      "screen_name" : "JoschiFun2Code",
      "indices" : [ 0, 15 ],
      "id_str" : "2428512869",
      "id" : 2428512869
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "717319593656770564",
  "in_reply_to_user_id" : 2428512869,
  "text" : "@JoschiFun2Code hi have u had any reports about wsmirror not working under android 6 marshmellow? thx",
  "id" : 717319593656770564,
  "created_at" : "2016-04-05 11:54:52 +0000",
  "in_reply_to_screen_name" : "JoschiFun2Code",
  "in_reply_to_user_id_str" : "2428512869",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/aSqQ8nCwae",
      "expanded_url" : "https:\/\/twitter.com\/BryanAppleyard\/status\/717038872740368384",
      "display_url" : "twitter.com\/BryanAppleyard\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "717316396015869952",
  "text" : "RT @pchallinor: Still, given the context, two apostrophes out of four is better than one has a right to expect. https:\/\/t.co\/aSqQ8nCwae",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/aSqQ8nCwae",
        "expanded_url" : "https:\/\/twitter.com\/BryanAppleyard\/status\/717038872740368384",
        "display_url" : "twitter.com\/BryanAppleyard\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "717040051310485504",
    "text" : "Still, given the context, two apostrophes out of four is better than one has a right to expect. https:\/\/t.co\/aSqQ8nCwae",
    "id" : 717040051310485504,
    "created_at" : "2016-04-04 17:24:04 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 717316396015869952,
  "created_at" : "2016-04-05 11:42:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Servianski",
      "screen_name" : "AdamSerwer",
      "indices" : [ 3, 14 ],
      "id_str" : "16326882",
      "id" : 16326882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "717289389488021506",
  "text" : "RT @AdamSerwer: \"even the innocent are guilty\" is the basic logic of all terrorism, regardless of origin or ideology",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "716949640772456448",
    "geo" : { },
    "id_str" : "716949891554152449",
    "in_reply_to_user_id" : 16326882,
    "text" : "\"even the innocent are guilty\" is the basic logic of all terrorism, regardless of origin or ideology",
    "id" : 716949891554152449,
    "in_reply_to_status_id" : 716949640772456448,
    "created_at" : "2016-04-04 11:25:49 +0000",
    "in_reply_to_screen_name" : "AdamSerwer",
    "in_reply_to_user_id_str" : "16326882",
    "user" : {
      "name" : "Adam Servianski",
      "screen_name" : "AdamSerwer",
      "protected" : false,
      "id_str" : "16326882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/720310495253815296\/48viyxMH_normal.jpg",
      "id" : 16326882,
      "verified" : true
    }
  },
  "id" : 717289389488021506,
  "created_at" : "2016-04-05 09:54:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derek Keever",
      "screen_name" : "cadkyjo",
      "indices" : [ 0, 8 ],
      "id_str" : "105344574",
      "id" : 105344574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "717256653960192000",
  "geo" : { },
  "id_str" : "717259080746811392",
  "in_reply_to_user_id" : 105344574,
  "text" : "@cadkyjo specific def def? On the table?",
  "id" : 717259080746811392,
  "in_reply_to_status_id" : 717256653960192000,
  "created_at" : "2016-04-05 07:54:25 +0000",
  "in_reply_to_screen_name" : "cadkyjo",
  "in_reply_to_user_id_str" : "105344574",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derek Keever",
      "screen_name" : "cadkyjo",
      "indices" : [ 0, 8 ],
      "id_str" : "105344574",
      "id" : 105344574
    }, {
      "name" : "Scott Thornbury",
      "screen_name" : "thornburyscott",
      "indices" : [ 9, 24 ],
      "id_str" : "23090474",
      "id" : 23090474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "717255181876879360",
  "geo" : { },
  "id_str" : "717255617925218304",
  "in_reply_to_user_id" : 105344574,
  "text" : "@cadkyjo @thornburyscott if u read Scott's post might be clearer? Will clarify when I get chance",
  "id" : 717255617925218304,
  "in_reply_to_status_id" : 717255181876879360,
  "created_at" : "2016-04-05 07:40:39 +0000",
  "in_reply_to_screen_name" : "cadkyjo",
  "in_reply_to_user_id_str" : "105344574",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Leedham",
      "screen_name" : "DiLeed",
      "indices" : [ 3, 10 ],
      "id_str" : "2335217159",
      "id" : 2335217159
    }, {
      "name" : "School Equality",
      "screen_name" : "SchoolEquality",
      "indices" : [ 101, 116 ],
      "id_str" : "915312858",
      "id" : 915312858
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "https:\/\/t.co\/d9C3pzNe4L",
      "expanded_url" : "https:\/\/twitter.com\/bjpren\/status\/717251841348739073",
      "display_url" : "twitter.com\/bjpren\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "717255131033702400",
  "text" : "RT @DiLeed: Prevent has no secure evidence base to legitimise its pernicious impact. On the contrary @SchoolEquality  https:\/\/t.co\/d9C3pzNe\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "School Equality",
        "screen_name" : "SchoolEquality",
        "indices" : [ 89, 104 ],
        "id_str" : "915312858",
        "id" : 915312858
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/d9C3pzNe4L",
        "expanded_url" : "https:\/\/twitter.com\/bjpren\/status\/717251841348739073",
        "display_url" : "twitter.com\/bjpren\/status\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "717254470418231296",
    "text" : "Prevent has no secure evidence base to legitimise its pernicious impact. On the contrary @SchoolEquality  https:\/\/t.co\/d9C3pzNe4L",
    "id" : 717254470418231296,
    "created_at" : "2016-04-05 07:36:06 +0000",
    "user" : {
      "name" : "Diane Leedham",
      "screen_name" : "DiLeed",
      "protected" : false,
      "id_str" : "2335217159",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531591034740826112\/jFKHAmex_normal.jpeg",
      "id" : 2335217159,
      "verified" : false
    }
  },
  "id" : 717255131033702400,
  "created_at" : "2016-04-05 07:38:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "717238100255252480",
  "geo" : { },
  "id_str" : "717238574412902400",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl sorry Russ your \"style\" of debate is not conducive to a good faith discussion i am getting me coat",
  "id" : 717238574412902400,
  "in_reply_to_status_id" : 717238100255252480,
  "created_at" : "2016-04-05 06:32:56 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathon Owen",
      "screen_name" : "ArrantPedantry",
      "indices" : [ 82, 97 ],
      "id_str" : "348284120",
      "id" : 348284120
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/xNwxSGPRCo",
      "expanded_url" : "http:\/\/www.arrantpedantry.com\/2016\/04\/04\/aces-presentation-copyediting-and-corpus-linguistics\/",
      "display_url" : "arrantpedantry.com\/2016\/04\/04\/ace\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "717231434503733248",
  "text" : "ACES Presentation: Copyediting and Corpus Linguistics https:\/\/t.co\/xNwxSGPRCo via @ArrantPedantry",
  "id" : 717231434503733248,
  "created_at" : "2016-04-05 06:04:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "717216279426371584",
  "geo" : { },
  "id_str" : "717225111951122433",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl u are purposely being obtuse\/vexatious, it is difficult to have a difference when \"race\" as a concept has no meaning, \"racism\" does",
  "id" : 717225111951122433,
  "in_reply_to_status_id" : 717216279426371584,
  "created_at" : "2016-04-05 05:39:26 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derek Keever",
      "screen_name" : "cadkyjo",
      "indices" : [ 0, 8 ],
      "id_str" : "105344574",
      "id" : 105344574
    }, {
      "name" : "Scott Thornbury",
      "screen_name" : "thornburyscott",
      "indices" : [ 9, 24 ],
      "id_str" : "23090474",
      "id" : 23090474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "717219213899857920",
  "geo" : { },
  "id_str" : "717224186750623745",
  "in_reply_to_user_id" : 105344574,
  "text" : "@cadkyjo @thornburyscott hi the table or my prose? : )",
  "id" : 717224186750623745,
  "in_reply_to_status_id" : 717219213899857920,
  "created_at" : "2016-04-05 05:35:46 +0000",
  "in_reply_to_screen_name" : "cadkyjo",
  "in_reply_to_user_id_str" : "105344574",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Nafeez Ahmed",
      "screen_name" : "NafeezAhmed",
      "indices" : [ 59, 71 ],
      "id_str" : "110692399",
      "id" : 110692399
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/xzVJDTiotA",
      "expanded_url" : "https:\/\/medium.com\/insurge-intelligence\/the-astonishingly-crap-science-of-counter-extremism-65810f8ac8e6#.c2k4pflx0",
      "display_url" : "medium.com\/insurge-intell\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "717075098633707521",
  "text" : "\u201CThe Astonishingly Crap Science of \u2018Counter-Extremism\u2019\u201D by @NafeezAhmed https:\/\/t.co\/xzVJDTiotA",
  "id" : 717075098633707521,
  "created_at" : "2016-04-04 19:43:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Ding",
      "screen_name" : "alexanderding",
      "indices" : [ 0, 14 ],
      "id_str" : "118014141",
      "id" : 118014141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "717022012619759616",
  "geo" : { },
  "id_str" : "717056671751802881",
  "in_reply_to_user_id" : 118014141,
  "text" : "@alexanderding horses for courses i guess",
  "id" : 717056671751802881,
  "in_reply_to_status_id" : 717022012619759616,
  "created_at" : "2016-04-04 18:30:07 +0000",
  "in_reply_to_screen_name" : "alexanderding",
  "in_reply_to_user_id_str" : "118014141",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ahmed Abdul Kareem",
      "screen_name" : "ayhamahmed2000",
      "indices" : [ 0, 15 ],
      "id_str" : "593132304",
      "id" : 593132304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "717047565166985217",
  "geo" : { },
  "id_str" : "717048481676922881",
  "in_reply_to_user_id" : 18602422,
  "text" : "@ayhamahmed2000 u mentioned consequences earlier, for us chatting on Twitter none, for Muslims in Fr in such framing created by Hebdo?",
  "id" : 717048481676922881,
  "in_reply_to_status_id" : 717047565166985217,
  "created_at" : "2016-04-04 17:57:34 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ahmed Abdul Kareem",
      "screen_name" : "ayhamahmed2000",
      "indices" : [ 0, 15 ],
      "id_str" : "593132304",
      "id" : 593132304
    }, {
      "name" : "Ljiljana Havran",
      "screen_name" : "LjiljanaHavran",
      "indices" : [ 16, 31 ],
      "id_str" : "1395825290",
      "id" : 1395825290
    }, {
      "name" : "Steve Brown",
      "screen_name" : "sbrowntweets",
      "indices" : [ 32, 45 ],
      "id_str" : "885343459",
      "id" : 885343459
    }, {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 46, 52 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    }, {
      "name" : "Carol Goodey",
      "screen_name" : "carol_goodey",
      "indices" : [ 53, 66 ],
      "id_str" : "2814555865",
      "id" : 2814555865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "717045481835216899",
  "geo" : { },
  "id_str" : "717047565166985217",
  "in_reply_to_user_id" : 593132304,
  "text" : "@ayhamahmed2000 @LjiljanaHavran @sbrowntweets @ebefl @carol_goodey asking why only this religion in particular is instructive",
  "id" : 717047565166985217,
  "in_reply_to_status_id" : 717045481835216899,
  "created_at" : "2016-04-04 17:53:56 +0000",
  "in_reply_to_screen_name" : "ayhamahmed2000",
  "in_reply_to_user_id_str" : "593132304",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenn Greenwald",
      "screen_name" : "ggreenwald",
      "indices" : [ 3, 14 ],
      "id_str" : "16076032",
      "id" : 16076032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/P0qrejrnKm",
      "expanded_url" : "https:\/\/twitter.com\/AdamSerwer\/status\/716949640772456448",
      "display_url" : "twitter.com\/AdamSerwer\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "716995786580561920",
  "text" : "RT @ggreenwald: Precisely. Charlie Hebdo became a religion, and criticizing its content was forbidden. Until now. https:\/\/t.co\/P0qrejrnKm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/P0qrejrnKm",
        "expanded_url" : "https:\/\/twitter.com\/AdamSerwer\/status\/716949640772456448",
        "display_url" : "twitter.com\/AdamSerwer\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "716950870848626688",
    "text" : "Precisely. Charlie Hebdo became a religion, and criticizing its content was forbidden. Until now. https:\/\/t.co\/P0qrejrnKm",
    "id" : 716950870848626688,
    "created_at" : "2016-04-04 11:29:42 +0000",
    "user" : {
      "name" : "Glenn Greenwald",
      "screen_name" : "ggreenwald",
      "protected" : false,
      "id_str" : "16076032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/659383028771364869\/G9HHnjiI_normal.jpg",
      "id" : 16076032,
      "verified" : true
    }
  },
  "id" : 716995786580561920,
  "created_at" : "2016-04-04 14:28:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mehdi Hasan",
      "screen_name" : "mehdirhasan",
      "indices" : [ 3, 15 ],
      "id_str" : "130557513",
      "id" : 130557513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/u6CCNeSZAy",
      "expanded_url" : "https:\/\/twitter.com\/itvnews\/status\/713011832357789696",
      "display_url" : "twitter.com\/itvnews\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "716995228700381184",
  "text" : "RT @mehdirhasan: FYI - a European Christian guilty of genocide against European Muslims. But rightly no one's blaming all Christians. https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/u6CCNeSZAy",
        "expanded_url" : "https:\/\/twitter.com\/itvnews\/status\/713011832357789696",
        "display_url" : "twitter.com\/itvnews\/status\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "713013616950263813",
    "text" : "FYI - a European Christian guilty of genocide against European Muslims. But rightly no one's blaming all Christians. https:\/\/t.co\/u6CCNeSZAy",
    "id" : 713013616950263813,
    "created_at" : "2016-03-24 14:44:28 +0000",
    "user" : {
      "name" : "Mehdi Hasan",
      "screen_name" : "mehdirhasan",
      "protected" : false,
      "id_str" : "130557513",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/573936711564046336\/l1bb-IPm_normal.jpeg",
      "id" : 130557513,
      "verified" : true
    }
  },
  "id" : 716995228700381184,
  "created_at" : "2016-04-04 14:25:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/8jq3EZUhHk",
      "expanded_url" : "https:\/\/www.facebook.com\/permalink.php?story_fbid=10153616146902199&id=200401352198",
      "display_url" : "facebook.com\/permalink.php?\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "716993154386423808",
  "text" : "the mask of \"it's satire and you don't get it\" https:\/\/t.co\/8jq3EZUhHk",
  "id" : 716993154386423808,
  "created_at" : "2016-04-04 14:17:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/pdguflR1ey",
      "expanded_url" : "http:\/\/www.theguardian.com\/uk-news\/2016\/apr\/04\/suicide-attempts-uk-immigration-removal-centres-all-time-high-home-office-figures",
      "display_url" : "theguardian.com\/uk-news\/2016\/a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "716987575458799620",
  "text" : "RT @pchallinor: Government takes the welfare of detainees at wog disposal centres so seriously that suicides are at an all-time high https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/pdguflR1ey",
        "expanded_url" : "http:\/\/www.theguardian.com\/uk-news\/2016\/apr\/04\/suicide-attempts-uk-immigration-removal-centres-all-time-high-home-office-figures",
        "display_url" : "theguardian.com\/uk-news\/2016\/a\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "716987392763293696",
    "text" : "Government takes the welfare of detainees at wog disposal centres so seriously that suicides are at an all-time high https:\/\/t.co\/pdguflR1ey",
    "id" : 716987392763293696,
    "created_at" : "2016-04-04 13:54:50 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 716987575458799620,
  "created_at" : "2016-04-04 13:55:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Apps 4 EFL",
      "screen_name" : "apps4efl",
      "indices" : [ 3, 12 ],
      "id_str" : "2594237072",
      "id" : 2594237072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/1OllYqzXeN",
      "expanded_url" : "http:\/\/fb.me\/2J0OBOYUu",
      "display_url" : "fb.me\/2J0OBOYUu"
    } ]
  },
  "geo" : { },
  "id_str" : "716987435801055233",
  "text" : "RT @apps4efl: New app in conjunction with Oliver Rose: Error Spotter. Allows students to practice and improve their recognition... https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/1OllYqzXeN",
        "expanded_url" : "http:\/\/fb.me\/2J0OBOYUu",
        "display_url" : "fb.me\/2J0OBOYUu"
      } ]
    },
    "geo" : { },
    "id_str" : "716986565017346048",
    "text" : "New app in conjunction with Oliver Rose: Error Spotter. Allows students to practice and improve their recognition... https:\/\/t.co\/1OllYqzXeN",
    "id" : 716986565017346048,
    "created_at" : "2016-04-04 13:51:32 +0000",
    "user" : {
      "name" : "Apps 4 EFL",
      "screen_name" : "apps4efl",
      "protected" : false,
      "id_str" : "2594237072",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/652102680504963072\/peqnCRQT_normal.png",
      "id" : 2594237072,
      "verified" : false
    }
  },
  "id" : 716987435801055233,
  "created_at" : "2016-04-04 13:55:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716984590443872256",
  "geo" : { },
  "id_str" : "716985924505235460",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl so the parts  about non-ham making bakers, academics excusing religions, veiled women could well be excised?",
  "id" : 716985924505235460,
  "in_reply_to_status_id" : 716984590443872256,
  "created_at" : "2016-04-04 13:49:00 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/aNEkSQ0C91",
      "expanded_url" : "https:\/\/charliehebdo.fr\/en\/edito\/how-did-we-end-up-here\/",
      "display_url" : "charliehebdo.fr\/en\/edito\/how-d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "716985112156573696",
  "text" : "The recent Hebdo editorial [https:\/\/t.co\/aNEkSQ0C91]",
  "id" : 716985112156573696,
  "created_at" : "2016-04-04 13:45:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716983463283396609",
  "geo" : { },
  "id_str" : "716983894457913344",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl so you say",
  "id" : 716983894457913344,
  "in_reply_to_status_id" : 716983463283396609,
  "created_at" : "2016-04-04 13:40:56 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716983349055791104",
  "geo" : { },
  "id_str" : "716983825352495104",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl racism signifies\/marks out difference, Hebdo is marking out Islam",
  "id" : 716983825352495104,
  "in_reply_to_status_id" : 716983349055791104,
  "created_at" : "2016-04-04 13:40:39 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    }, {
      "name" : "Charlie Hebdo",
      "screen_name" : "Charlie_Hebdo_",
      "indices" : [ 7, 22 ],
      "id_str" : "65416867",
      "id" : 65416867
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716981544339050496",
  "geo" : { },
  "id_str" : "716981887630180352",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl @Charlie_Hebdo_ just responding in kind",
  "id" : 716981887630180352,
  "in_reply_to_status_id" : 716981544339050496,
  "created_at" : "2016-04-04 13:32:57 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/UKZF1pk0DU",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=bMo2uiRAf30",
      "display_url" : "youtube.com\/watch?v=bMo2ui\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "716981279758098432",
  "geo" : { },
  "id_str" : "716981816503230465",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl lordy get some wisdom from Hall https:\/\/t.co\/UKZF1pk0DU",
  "id" : 716981816503230465,
  "in_reply_to_status_id" : 716981279758098432,
  "created_at" : "2016-04-04 13:32:40 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716980984638529536",
  "geo" : { },
  "id_str" : "716981243045355520",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl not much dread if they continue pumping out racist crap",
  "id" : 716981243045355520,
  "in_reply_to_status_id" : 716980984638529536,
  "created_at" : "2016-04-04 13:30:23 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    }, {
      "name" : "Charlie Hebdo",
      "screen_name" : "Charlie_Hebdo_",
      "indices" : [ 7, 22 ],
      "id_str" : "65416867",
      "id" : 65416867
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716980362489032704",
  "geo" : { },
  "id_str" : "716980689778905088",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl @Charlie_Hebdo_ well they can turn the other cheek",
  "id" : 716980689778905088,
  "in_reply_to_status_id" : 716980362489032704,
  "created_at" : "2016-04-04 13:28:11 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716980247036628993",
  "geo" : { },
  "id_str" : "716980618240913408",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl i read it as a racist text",
  "id" : 716980618240913408,
  "in_reply_to_status_id" : 716980247036628993,
  "created_at" : "2016-04-04 13:27:54 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian James",
      "screen_name" : "ij64",
      "indices" : [ 0, 5 ],
      "id_str" : "13726222",
      "id" : 13726222
    }, {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 6, 12 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716979892294983680",
  "geo" : { },
  "id_str" : "716980286324609029",
  "in_reply_to_user_id" : 13726222,
  "text" : "@ij64 @ebefl but but they don't look Islamic...",
  "id" : 716980286324609029,
  "in_reply_to_status_id" : 716979892294983680,
  "created_at" : "2016-04-04 13:26:35 +0000",
  "in_reply_to_screen_name" : "ij64",
  "in_reply_to_user_id_str" : "13726222",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716979218052153344",
  "geo" : { },
  "id_str" : "716979568935112704",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl same to you",
  "id" : 716979568935112704,
  "in_reply_to_status_id" : 716979218052153344,
  "created_at" : "2016-04-04 13:23:44 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716978805672452096",
  "geo" : { },
  "id_str" : "716979501956276224",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl of course and how is it relevant to Hebdo text?",
  "id" : 716979501956276224,
  "in_reply_to_status_id" : 716978805672452096,
  "created_at" : "2016-04-04 13:23:28 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716978364310011904",
  "geo" : { },
  "id_str" : "716978770310201344",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl i argue that Hebdo text is encouraged by such pronouncements from gov ministers",
  "id" : 716978770310201344,
  "in_reply_to_status_id" : 716978364310011904,
  "created_at" : "2016-04-04 13:20:34 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716978102132469760",
  "geo" : { },
  "id_str" : "716978354503684098",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl they can be prosecuted for hate crimes",
  "id" : 716978354503684098,
  "in_reply_to_status_id" : 716978102132469760,
  "created_at" : "2016-04-04 13:18:55 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716976802539970565",
  "geo" : { },
  "id_str" : "716978064287264768",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl no the minister who resigned; this minister shows racist context hebdo editorial swims in",
  "id" : 716978064287264768,
  "in_reply_to_status_id" : 716976802539970565,
  "created_at" : "2016-04-04 13:17:45 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716977128336670722",
  "geo" : { },
  "id_str" : "716977243394871297",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl bollocks to that Russ",
  "id" : 716977243394871297,
  "in_reply_to_status_id" : 716977128336670722,
  "created_at" : "2016-04-04 13:14:30 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716976985508077569",
  "geo" : { },
  "id_str" : "716977148788154368",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl erm so what i have been saying is not what i think news to me",
  "id" : 716977148788154368,
  "in_reply_to_status_id" : 716976985508077569,
  "created_at" : "2016-04-04 13:14:07 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716976179614498816",
  "geo" : { },
  "id_str" : "716976475199696897",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl no you are putting words in my mouth, poor debate tactic",
  "id" : 716976475199696897,
  "in_reply_to_status_id" : 716976179614498816,
  "created_at" : "2016-04-04 13:11:27 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716975986844307456",
  "geo" : { },
  "id_str" : "716976171171323904",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl they portrayed her as a monkey",
  "id" : 716976171171323904,
  "in_reply_to_status_id" : 716975986844307456,
  "created_at" : "2016-04-04 13:10:14 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716975560027676672",
  "geo" : { },
  "id_str" : "716976069035827200",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl Racism does not equal \"race\" that is such an obvious point I find it surprising it needs to be spelt out",
  "id" : 716976069035827200,
  "in_reply_to_status_id" : 716975560027676672,
  "created_at" : "2016-04-04 13:09:50 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/716975679942836225\/photo\/1",
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/j12f0bPFyK",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CfM1kahW8AIlM6k.jpg",
      "id_str" : "716975665392840706",
      "id" : 716975665392840706,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CfM1kahW8AIlM6k.jpg",
      "sizes" : [ {
        "h" : 278,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 190,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 278,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 278,
        "resize" : "fit",
        "w" : 498
      } ],
      "display_url" : "pic.twitter.com\/j12f0bPFyK"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716975560027676672",
  "geo" : { },
  "id_str" : "716975679942836225",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl https:\/\/t.co\/j12f0bPFyK",
  "id" : 716975679942836225,
  "in_reply_to_status_id" : 716975560027676672,
  "created_at" : "2016-04-04 13:08:17 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716953930899578880",
  "geo" : { },
  "id_str" : "716975471049748480",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl  i'll sign up to \"I don't think we should respect homophobia\/Islamophobia\/sexism\/racism\/ageism when dressed up as religion\/satire\"",
  "id" : 716975471049748480,
  "in_reply_to_status_id" : 716953930899578880,
  "created_at" : "2016-04-04 13:07:27 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/UoQs578MLS",
      "expanded_url" : "http:\/\/www.france24.com\/en\/20160330-french-minister-muslim-women-who-wear-veils-like-pro-slavery-negroes?dlvrit=66745",
      "display_url" : "france24.com\/en\/20160330-fr\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "716950403859013632",
  "geo" : { },
  "id_str" : "716973673438117890",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl no i sent you before news about that minister re veils and slavery in US https:\/\/t.co\/UoQs578MLS",
  "id" : 716973673438117890,
  "in_reply_to_status_id" : 716950403859013632,
  "created_at" : "2016-04-04 13:00:19 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/KEYYqpIycG",
      "expanded_url" : "https:\/\/vimeo.com\/145816483#t=2576s",
      "display_url" : "vimeo.com\/145816483#t=25\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "716955707996770304",
  "geo" : { },
  "id_str" : "716971428235644928",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl might be useful https:\/\/t.co\/KEYYqpIycG",
  "id" : 716971428235644928,
  "in_reply_to_status_id" : 716955707996770304,
  "created_at" : "2016-04-04 12:51:23 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716955707996770304",
  "geo" : { },
  "id_str" : "716964852728729600",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl more context: recently a black woman minister resigned over racist dual nationality law",
  "id" : 716964852728729600,
  "in_reply_to_status_id" : 716955707996770304,
  "created_at" : "2016-04-04 12:25:16 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    }, {
      "name" : "The Guardian",
      "screen_name" : "guardian",
      "indices" : [ 7, 16 ],
      "id_str" : "87818409",
      "id" : 87818409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716955504778612736",
  "geo" : { },
  "id_str" : "716960656361189380",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl @guardian it shows limits of freedom of expression as it should be",
  "id" : 716960656361189380,
  "in_reply_to_status_id" : 716955504778612736,
  "created_at" : "2016-04-04 12:08:35 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716955361941569536",
  "geo" : { },
  "id_str" : "716960506020540416",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl initial discussion based on French publication",
  "id" : 716960506020540416,
  "in_reply_to_status_id" : 716955361941569536,
  "created_at" : "2016-04-04 12:07:59 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716953666842988545",
  "geo" : { },
  "id_str" : "716954534082387968",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl but it is happening so talk of freedom to critisize\/ridicule whatever is bogus",
  "id" : 716954534082387968,
  "in_reply_to_status_id" : 716953666842988545,
  "created_at" : "2016-04-04 11:44:15 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716952809992765440",
  "geo" : { },
  "id_str" : "716953118370635776",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl rubbish it's a loaded question and u know it",
  "id" : 716953118370635776,
  "in_reply_to_status_id" : 716952809992765440,
  "created_at" : "2016-04-04 11:38:38 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716952088140492801",
  "geo" : { },
  "id_str" : "716952978444431360",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl I disagree I argue that Hebdo editorial is a racist text",
  "id" : 716952978444431360,
  "in_reply_to_status_id" : 716952088140492801,
  "created_at" : "2016-04-04 11:38:05 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716951442872016897",
  "geo" : { },
  "id_str" : "716952360497627136",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl most well known dieudonne but many others",
  "id" : 716952360497627136,
  "in_reply_to_status_id" : 716951442872016897,
  "created_at" : "2016-04-04 11:35:37 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716951712167292928",
  "geo" : { },
  "id_str" : "716952184370409472",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl I have stopped beating my wife",
  "id" : 716952184370409472,
  "in_reply_to_status_id" : 716951712167292928,
  "created_at" : "2016-04-04 11:34:55 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716950798962450432",
  "geo" : { },
  "id_str" : "716951875019517952",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl what \"freedom\" are we losing?",
  "id" : 716951875019517952,
  "in_reply_to_status_id" : 716950798962450432,
  "created_at" : "2016-04-04 11:33:41 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716950693941231616",
  "geo" : { },
  "id_str" : "716951154664611840",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl you have more say in your own gov than some religious diaspora",
  "id" : 716951154664611840,
  "in_reply_to_status_id" : 716950693941231616,
  "created_at" : "2016-04-04 11:30:50 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    }, {
      "name" : "Ljiljana Havran",
      "screen_name" : "LjiljanaHavran",
      "indices" : [ 7, 22 ],
      "id_str" : "1395825290",
      "id" : 1395825290
    }, {
      "name" : "patrick",
      "screen_name" : "patrickamon",
      "indices" : [ 23, 35 ],
      "id_str" : "46382179",
      "id" : 46382179
    }, {
      "name" : "Steve Brown",
      "screen_name" : "sbrowntweets",
      "indices" : [ 36, 49 ],
      "id_str" : "885343459",
      "id" : 885343459
    }, {
      "name" : "Carol Goodey",
      "screen_name" : "carol_goodey",
      "indices" : [ 50, 63 ],
      "id_str" : "2814555865",
      "id" : 2814555865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716950496888664064",
  "geo" : { },
  "id_str" : "716950907737477120",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl @LjiljanaHavran @patrickamon @sbrowntweets @carol_goodey read up on prosecutions in France",
  "id" : 716950907737477120,
  "in_reply_to_status_id" : 716950496888664064,
  "created_at" : "2016-04-04 11:29:51 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    }, {
      "name" : "Carol Goodey",
      "screen_name" : "carol_goodey",
      "indices" : [ 7, 20 ],
      "id_str" : "2814555865",
      "id" : 2814555865
    }, {
      "name" : "Steve Brown",
      "screen_name" : "sbrowntweets",
      "indices" : [ 21, 34 ],
      "id_str" : "885343459",
      "id" : 885343459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716949593980813312",
  "geo" : { },
  "id_str" : "716950659208257536",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl @carol_goodey @sbrowntweets really? freedom of expression has always been a free for all?",
  "id" : 716950659208257536,
  "in_reply_to_status_id" : 716949593980813312,
  "created_at" : "2016-04-04 11:28:52 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    }, {
      "name" : "Steve Brown",
      "screen_name" : "sbrowntweets",
      "indices" : [ 7, 20 ],
      "id_str" : "885343459",
      "id" : 885343459
    }, {
      "name" : "Ljiljana Havran",
      "screen_name" : "LjiljanaHavran",
      "indices" : [ 21, 36 ],
      "id_str" : "1395825290",
      "id" : 1395825290
    }, {
      "name" : "Carol Goodey",
      "screen_name" : "carol_goodey",
      "indices" : [ 37, 50 ],
      "id_str" : "2814555865",
      "id" : 2814555865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716949369380012032",
  "geo" : { },
  "id_str" : "716950172178235392",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl @sbrowntweets @LjiljanaHavran @carol_goodey UK gov happily does biz with gov who do just that",
  "id" : 716950172178235392,
  "in_reply_to_status_id" : 716949369380012032,
  "created_at" : "2016-04-04 11:26:55 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ljiljana Havran",
      "screen_name" : "LjiljanaHavran",
      "indices" : [ 0, 15 ],
      "id_str" : "1395825290",
      "id" : 1395825290
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716944378296672261",
  "geo" : { },
  "id_str" : "716945393842577409",
  "in_reply_to_user_id" : 18602422,
  "text" : "@LjiljanaHavran and often the ridicule coming from other direction can mean criminal prosecution",
  "id" : 716945393842577409,
  "in_reply_to_status_id" : 716944378296672261,
  "created_at" : "2016-04-04 11:07:56 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ljiljana Havran",
      "screen_name" : "LjiljanaHavran",
      "indices" : [ 0, 15 ],
      "id_str" : "1395825290",
      "id" : 1395825290
    }, {
      "name" : "patrick",
      "screen_name" : "patrickamon",
      "indices" : [ 16, 28 ],
      "id_str" : "46382179",
      "id" : 46382179
    }, {
      "name" : "Steve Brown",
      "screen_name" : "sbrowntweets",
      "indices" : [ 29, 42 ],
      "id_str" : "885343459",
      "id" : 885343459
    }, {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 43, 49 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    }, {
      "name" : "Carol Goodey",
      "screen_name" : "carol_goodey",
      "indices" : [ 50, 63 ],
      "id_str" : "2814555865",
      "id" : 2814555865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716944211669565440",
  "geo" : { },
  "id_str" : "716944378296672261",
  "in_reply_to_user_id" : 1395825290,
  "text" : "@LjiljanaHavran @patrickamon @sbrowntweets @ebefl @carol_goodey sure that works both ways",
  "id" : 716944378296672261,
  "in_reply_to_status_id" : 716944211669565440,
  "created_at" : "2016-04-04 11:03:54 +0000",
  "in_reply_to_screen_name" : "LjiljanaHavran",
  "in_reply_to_user_id_str" : "1395825290",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ljiljana Havran",
      "screen_name" : "LjiljanaHavran",
      "indices" : [ 0, 15 ],
      "id_str" : "1395825290",
      "id" : 1395825290
    }, {
      "name" : "patrick",
      "screen_name" : "patrickamon",
      "indices" : [ 16, 28 ],
      "id_str" : "46382179",
      "id" : 46382179
    }, {
      "name" : "Steve Brown",
      "screen_name" : "sbrowntweets",
      "indices" : [ 29, 42 ],
      "id_str" : "885343459",
      "id" : 885343459
    }, {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 43, 49 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    }, {
      "name" : "Carol Goodey",
      "screen_name" : "carol_goodey",
      "indices" : [ 50, 63 ],
      "id_str" : "2814555865",
      "id" : 2814555865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716942141201756160",
  "geo" : { },
  "id_str" : "716943613125664768",
  "in_reply_to_user_id" : 1395825290,
  "text" : "@LjiljanaHavran @patrickamon @sbrowntweets @ebefl @carol_goodey remember context Hebdo &amp; establishment here on full \"othering\" fear drive",
  "id" : 716943613125664768,
  "in_reply_to_status_id" : 716942141201756160,
  "created_at" : "2016-04-04 11:00:52 +0000",
  "in_reply_to_screen_name" : "LjiljanaHavran",
  "in_reply_to_user_id_str" : "1395825290",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ljiljana Havran",
      "screen_name" : "LjiljanaHavran",
      "indices" : [ 0, 15 ],
      "id_str" : "1395825290",
      "id" : 1395825290
    }, {
      "name" : "patrick",
      "screen_name" : "patrickamon",
      "indices" : [ 16, 28 ],
      "id_str" : "46382179",
      "id" : 46382179
    }, {
      "name" : "Steve Brown",
      "screen_name" : "sbrowntweets",
      "indices" : [ 29, 42 ],
      "id_str" : "885343459",
      "id" : 885343459
    }, {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 43, 49 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    }, {
      "name" : "Carol Goodey",
      "screen_name" : "carol_goodey",
      "indices" : [ 50, 63 ],
      "id_str" : "2814555865",
      "id" : 2814555865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716942141201756160",
  "geo" : { },
  "id_str" : "716942566395101184",
  "in_reply_to_user_id" : 1395825290,
  "text" : "@LjiljanaHavran @patrickamon @sbrowntweets @ebefl @carol_goodey how do you draw the line? what are \"bad ideas\", \"dogmatic ideology\"?",
  "id" : 716942566395101184,
  "in_reply_to_status_id" : 716942141201756160,
  "created_at" : "2016-04-04 10:56:42 +0000",
  "in_reply_to_screen_name" : "LjiljanaHavran",
  "in_reply_to_user_id_str" : "1395825290",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Mrozek",
      "screen_name" : "EvilDragon1717",
      "indices" : [ 3, 18 ],
      "id_str" : "108433145",
      "id" : 108433145
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/EvilDragon1717\/status\/715898912201170944\/photo\/1",
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/kcgQ5oUZQY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ce9iRGsWIAU2iSH.jpg",
      "id_str" : "715898911769108485",
      "id" : 715898911769108485,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ce9iRGsWIAU2iSH.jpg",
      "sizes" : [ {
        "h" : 1224,
        "resize" : "fit",
        "w" : 1632
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/kcgQ5oUZQY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "716934894564278272",
  "text" : "RT @EvilDragon1717: Now with backside :) We're getting there :) https:\/\/t.co\/kcgQ5oUZQY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/klinkerapps.com\" rel=\"nofollow\"\u003ETalon (Classic)\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/EvilDragon1717\/status\/715898912201170944\/photo\/1",
        "indices" : [ 44, 67 ],
        "url" : "https:\/\/t.co\/kcgQ5oUZQY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ce9iRGsWIAU2iSH.jpg",
        "id_str" : "715898911769108485",
        "id" : 715898911769108485,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ce9iRGsWIAU2iSH.jpg",
        "sizes" : [ {
          "h" : 1224,
          "resize" : "fit",
          "w" : 1632
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/kcgQ5oUZQY"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "715898912201170944",
    "text" : "Now with backside :) We're getting there :) https:\/\/t.co\/kcgQ5oUZQY",
    "id" : 715898912201170944,
    "created_at" : "2016-04-01 13:49:36 +0000",
    "user" : {
      "name" : "Michael Mrozek",
      "screen_name" : "EvilDragon1717",
      "protected" : false,
      "id_str" : "108433145",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/657029458\/EDSprite_normal.gif",
      "id" : 108433145,
      "verified" : false
    }
  },
  "id" : 716934894564278272,
  "created_at" : "2016-04-04 10:26:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol Goodey",
      "screen_name" : "carol_goodey",
      "indices" : [ 0, 13 ],
      "id_str" : "2814555865",
      "id" : 2814555865
    }, {
      "name" : "Steve Brown",
      "screen_name" : "sbrowntweets",
      "indices" : [ 14, 27 ],
      "id_str" : "885343459",
      "id" : 885343459
    }, {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 28, 34 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716927399422627841",
  "geo" : { },
  "id_str" : "716928469238751232",
  "in_reply_to_user_id" : 2814555865,
  "text" : "@carol_goodey @sbrowntweets @ebefl in France the Hebdo focus is a dogwhistle, e.g. \"arabe du coin\", right wing talking point",
  "id" : 716928469238751232,
  "in_reply_to_status_id" : 716927399422627841,
  "created_at" : "2016-04-04 10:00:41 +0000",
  "in_reply_to_screen_name" : "carol_goodey",
  "in_reply_to_user_id_str" : "2814555865",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Brown",
      "screen_name" : "sbrowntweets",
      "indices" : [ 0, 13 ],
      "id_str" : "885343459",
      "id" : 885343459
    }, {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 14, 20 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/716904391584952320\/photo\/1",
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/6lZZzeEGvd",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CfL0uE2WIAQL2_R.jpg",
      "id_str" : "716904363118174212",
      "id" : 716904363118174212,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CfL0uE2WIAQL2_R.jpg",
      "sizes" : [ {
        "h" : 500,
        "resize" : "fit",
        "w" : 336
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 336
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 336
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 336
      } ],
      "display_url" : "pic.twitter.com\/6lZZzeEGvd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716894399481909248",
  "geo" : { },
  "id_str" : "716904391584952320",
  "in_reply_to_user_id" : 885343459,
  "text" : "@sbrowntweets @ebefl https:\/\/t.co\/6lZZzeEGvd",
  "id" : 716904391584952320,
  "in_reply_to_status_id" : 716894399481909248,
  "created_at" : "2016-04-04 08:25:01 +0000",
  "in_reply_to_screen_name" : "sbrowntweets",
  "in_reply_to_user_id_str" : "885343459",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    }, {
      "name" : "Steve Brown",
      "screen_name" : "sbrowntweets",
      "indices" : [ 7, 20 ],
      "id_str" : "885343459",
      "id" : 885343459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716772056206024704",
  "geo" : { },
  "id_str" : "716900309415698432",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl @sbrowntweets Hebdo got government money &amp; exploit\/use\/play\/stir racist talk; freedom of expression is not absolute",
  "id" : 716900309415698432,
  "in_reply_to_status_id" : 716772056206024704,
  "created_at" : "2016-04-04 08:08:47 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Brown",
      "screen_name" : "sbrowntweets",
      "indices" : [ 0, 13 ],
      "id_str" : "885343459",
      "id" : 885343459
    }, {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 14, 20 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716777729811685376",
  "geo" : { },
  "id_str" : "716898679064510464",
  "in_reply_to_user_id" : 885343459,
  "text" : "@sbrowntweets @ebefl a good example is Steven Fry who first criticised people for being offended &amp; then left Twitter because he was offended",
  "id" : 716898679064510464,
  "in_reply_to_status_id" : 716777729811685376,
  "created_at" : "2016-04-04 08:02:19 +0000",
  "in_reply_to_screen_name" : "sbrowntweets",
  "in_reply_to_user_id_str" : "885343459",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rodney Sampson",
      "screen_name" : "rodneysampson",
      "indices" : [ 98, 112 ],
      "id_str" : "9439062",
      "id" : 9439062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/IeI3XMJ7Sq",
      "expanded_url" : "https:\/\/storify.com\/rodneysampson\/adayinthelife",
      "display_url" : "storify.com\/rodneysampson\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "716894450119794688",
  "text" : "A day in the life of a young black male engineering \"coding\" student. https:\/\/t.co\/IeI3XMJ7Sq via @rodneysampson",
  "id" : 716894450119794688,
  "created_at" : "2016-04-04 07:45:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((David Traynier)))",
      "screen_name" : "DTraynier",
      "indices" : [ 3, 13 ],
      "id_str" : "317716198",
      "id" : 317716198
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "r4today",
      "indices" : [ 75, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "716885835635953664",
  "text" : "RT @DTraynier: So, that news again: premiums to go up to pay for flooding. #r4today",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "r4today",
        "indices" : [ 60, 68 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "716873998559215616",
    "text" : "So, that news again: premiums to go up to pay for flooding. #r4today",
    "id" : 716873998559215616,
    "created_at" : "2016-04-04 06:24:14 +0000",
    "user" : {
      "name" : "(((David Traynier)))",
      "screen_name" : "DTraynier",
      "protected" : false,
      "id_str" : "317716198",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727929911877480451\/fLuwL370_normal.jpg",
      "id" : 317716198,
      "verified" : false
    }
  },
  "id" : 716885835635953664,
  "created_at" : "2016-04-04 07:11:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716872723629281280",
  "geo" : { },
  "id_str" : "716873846083756032",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl why this focus on one religion do u ask yourself this?",
  "id" : 716873846083756032,
  "in_reply_to_status_id" : 716872723629281280,
  "created_at" : "2016-04-04 06:23:38 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716872520545263616",
  "geo" : { },
  "id_str" : "716873717402451968",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl lol Facebook",
  "id" : 716873717402451968,
  "in_reply_to_status_id" : 716872520545263616,
  "created_at" : "2016-04-04 06:23:07 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716871429648723968",
  "geo" : { },
  "id_str" : "716871589766250496",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl according to you",
  "id" : 716871589766250496,
  "in_reply_to_status_id" : 716871429648723968,
  "created_at" : "2016-04-04 06:14:40 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    }, {
      "name" : "Steve Brown",
      "screen_name" : "sbrowntweets",
      "indices" : [ 7, 20 ],
      "id_str" : "885343459",
      "id" : 885343459
    }, {
      "name" : "Ljiljana Havran",
      "screen_name" : "LjiljanaHavran",
      "indices" : [ 21, 36 ],
      "id_str" : "1395825290",
      "id" : 1395825290
    }, {
      "name" : "Carol Goodey",
      "screen_name" : "carol_goodey",
      "indices" : [ 37, 50 ],
      "id_str" : "2814555865",
      "id" : 2814555865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716869049985187840",
  "geo" : { },
  "id_str" : "716869803177287680",
  "in_reply_to_user_id" : 18602422,
  "text" : "@ebefl @sbrowntweets @LjiljanaHavran @carol_goodey all I hear is \"Islam arggh bad evil clash of civilizations regressiveleft\"",
  "id" : 716869803177287680,
  "in_reply_to_status_id" : 716869049985187840,
  "created_at" : "2016-04-04 06:07:34 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    }, {
      "name" : "Steve Brown",
      "screen_name" : "sbrowntweets",
      "indices" : [ 7, 20 ],
      "id_str" : "885343459",
      "id" : 885343459
    }, {
      "name" : "Ljiljana Havran",
      "screen_name" : "LjiljanaHavran",
      "indices" : [ 21, 36 ],
      "id_str" : "1395825290",
      "id" : 1395825290
    }, {
      "name" : "Carol Goodey",
      "screen_name" : "carol_goodey",
      "indices" : [ 37, 50 ],
      "id_str" : "2814555865",
      "id" : 2814555865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716868553346060288",
  "geo" : { },
  "id_str" : "716869049985187840",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl @sbrowntweets @LjiljanaHavran @carol_goodey you disagree this is more about (geo) politics than religion?",
  "id" : 716869049985187840,
  "in_reply_to_status_id" : 716868553346060288,
  "created_at" : "2016-04-04 06:04:34 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    }, {
      "name" : "Steve Brown",
      "screen_name" : "sbrowntweets",
      "indices" : [ 7, 20 ],
      "id_str" : "885343459",
      "id" : 885343459
    }, {
      "name" : "Ljiljana Havran",
      "screen_name" : "LjiljanaHavran",
      "indices" : [ 21, 36 ],
      "id_str" : "1395825290",
      "id" : 1395825290
    }, {
      "name" : "Carol Goodey",
      "screen_name" : "carol_goodey",
      "indices" : [ 37, 50 ],
      "id_str" : "2814555865",
      "id" : 2814555865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716868154694217728",
  "geo" : { },
  "id_str" : "716868735311736832",
  "in_reply_to_user_id" : 18602422,
  "text" : "@ebefl @sbrowntweets @LjiljanaHavran @carol_goodey Carol called you out yourname calling the left on anti-semitism u casually continue",
  "id" : 716868735311736832,
  "in_reply_to_status_id" : 716868154694217728,
  "created_at" : "2016-04-04 06:03:19 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    }, {
      "name" : "Steve Brown",
      "screen_name" : "sbrowntweets",
      "indices" : [ 7, 20 ],
      "id_str" : "885343459",
      "id" : 885343459
    }, {
      "name" : "Ljiljana Havran",
      "screen_name" : "LjiljanaHavran",
      "indices" : [ 21, 36 ],
      "id_str" : "1395825290",
      "id" : 1395825290
    }, {
      "name" : "Carol Goodey",
      "screen_name" : "carol_goodey",
      "indices" : [ 37, 50 ],
      "id_str" : "2814555865",
      "id" : 2814555865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716772626815979520",
  "geo" : { },
  "id_str" : "716868154694217728",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl @sbrowntweets @LjiljanaHavran @carol_goodey u sure like to name call don't you Russ?",
  "id" : 716868154694217728,
  "in_reply_to_status_id" : 716772626815979520,
  "created_at" : "2016-04-04 06:01:01 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Brown",
      "screen_name" : "sbrowntweets",
      "indices" : [ 0, 13 ],
      "id_str" : "885343459",
      "id" : 885343459
    }, {
      "name" : "Ljiljana Havran",
      "screen_name" : "LjiljanaHavran",
      "indices" : [ 14, 29 ],
      "id_str" : "1395825290",
      "id" : 1395825290
    }, {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 30, 36 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    }, {
      "name" : "Carol Goodey",
      "screen_name" : "carol_goodey",
      "indices" : [ 37, 50 ],
      "id_str" : "2814555865",
      "id" : 2814555865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716772169871671296",
  "geo" : { },
  "id_str" : "716868061375160320",
  "in_reply_to_user_id" : 885343459,
  "text" : "@sbrowntweets @LjiljanaHavran @ebefl @carol_goodey yeah as about as much to do with religion as Northern Ireland during the troubles",
  "id" : 716868061375160320,
  "in_reply_to_status_id" : 716772169871671296,
  "created_at" : "2016-04-04 06:00:39 +0000",
  "in_reply_to_screen_name" : "sbrowntweets",
  "in_reply_to_user_id_str" : "885343459",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ljiljana Havran",
      "screen_name" : "LjiljanaHavran",
      "indices" : [ 0, 15 ],
      "id_str" : "1395825290",
      "id" : 1395825290
    }, {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 16, 22 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716745431552761859",
  "geo" : { },
  "id_str" : "716745725024071681",
  "in_reply_to_user_id" : 1395825290,
  "text" : "@LjiljanaHavran @ebefl the white man's burden...",
  "id" : 716745725024071681,
  "in_reply_to_status_id" : 716745431552761859,
  "created_at" : "2016-04-03 21:54:31 +0000",
  "in_reply_to_screen_name" : "LjiljanaHavran",
  "in_reply_to_user_id_str" : "1395825290",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Brown",
      "screen_name" : "sbrowntweets",
      "indices" : [ 3, 16 ],
      "id_str" : "885343459",
      "id" : 885343459
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 18, 27 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 28, 34 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    }, {
      "name" : "Carol Goodey",
      "screen_name" : "carol_goodey",
      "indices" : [ 35, 48 ],
      "id_str" : "2814555865",
      "id" : 2814555865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "716745427366895616",
  "text" : "RT @sbrowntweets: @muranava @ebefl @carol_goodey or, not complaining that the baker stopped making ham sandwiches makes us complicit in ter\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mura Nava",
        "screen_name" : "muranava",
        "indices" : [ 0, 9 ],
        "id_str" : "18602422",
        "id" : 18602422
      }, {
        "name" : "Russ Mayne",
        "screen_name" : "ebefl",
        "indices" : [ 10, 16 ],
        "id_str" : "2228367554",
        "id" : 2228367554
      }, {
        "name" : "Carol Goodey",
        "screen_name" : "carol_goodey",
        "indices" : [ 17, 30 ],
        "id_str" : "2814555865",
        "id" : 2814555865
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "716718749798297601",
    "geo" : { },
    "id_str" : "716721432210894850",
    "in_reply_to_user_id" : 18602422,
    "text" : "@muranava @ebefl @carol_goodey or, not complaining that the baker stopped making ham sandwiches makes us complicit in terrorist atrocities?",
    "id" : 716721432210894850,
    "in_reply_to_status_id" : 716718749798297601,
    "created_at" : "2016-04-03 20:18:00 +0000",
    "in_reply_to_screen_name" : "muranava",
    "in_reply_to_user_id_str" : "18602422",
    "user" : {
      "name" : "Steve Brown",
      "screen_name" : "sbrowntweets",
      "protected" : false,
      "id_str" : "885343459",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746292888405934080\/tp1_ccBF_normal.jpg",
      "id" : 885343459,
      "verified" : false
    }
  },
  "id" : 716745427366895616,
  "created_at" : "2016-04-03 21:53:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Brown",
      "screen_name" : "sbrowntweets",
      "indices" : [ 3, 16 ],
      "id_str" : "885343459",
      "id" : 885343459
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 18, 27 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 28, 34 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    }, {
      "name" : "Carol Goodey",
      "screen_name" : "carol_goodey",
      "indices" : [ 35, 48 ],
      "id_str" : "2814555865",
      "id" : 2814555865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "716745414163173376",
  "text" : "RT @sbrowntweets: @muranava @ebefl @carol_goodey Seems to be saying that making sandwiches without ham is somehow connected to blowing up a\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mura Nava",
        "screen_name" : "muranava",
        "indices" : [ 0, 9 ],
        "id_str" : "18602422",
        "id" : 18602422
      }, {
        "name" : "Russ Mayne",
        "screen_name" : "ebefl",
        "indices" : [ 10, 16 ],
        "id_str" : "2228367554",
        "id" : 2228367554
      }, {
        "name" : "Carol Goodey",
        "screen_name" : "carol_goodey",
        "indices" : [ 17, 30 ],
        "id_str" : "2814555865",
        "id" : 2814555865
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "716718749798297601",
    "geo" : { },
    "id_str" : "716720682223214592",
    "in_reply_to_user_id" : 18602422,
    "text" : "@muranava @ebefl @carol_goodey Seems to be saying that making sandwiches without ham is somehow connected to blowing up an airport",
    "id" : 716720682223214592,
    "in_reply_to_status_id" : 716718749798297601,
    "created_at" : "2016-04-03 20:15:01 +0000",
    "in_reply_to_screen_name" : "muranava",
    "in_reply_to_user_id_str" : "18602422",
    "user" : {
      "name" : "Steve Brown",
      "screen_name" : "sbrowntweets",
      "protected" : false,
      "id_str" : "885343459",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746292888405934080\/tp1_ccBF_normal.jpg",
      "id" : 885343459,
      "verified" : false
    }
  },
  "id" : 716745414163173376,
  "created_at" : "2016-04-03 21:53:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ljiljana Havran",
      "screen_name" : "LjiljanaHavran",
      "indices" : [ 0, 15 ],
      "id_str" : "1395825290",
      "id" : 1395825290
    }, {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 16, 22 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716743133804044288",
  "geo" : { },
  "id_str" : "716743525988179968",
  "in_reply_to_user_id" : 1395825290,
  "text" : "@LjiljanaHavran @ebefl the \"freedom of speech\" rings hollow here in France where speech you don't like is prosecuted",
  "id" : 716743525988179968,
  "in_reply_to_status_id" : 716743133804044288,
  "created_at" : "2016-04-03 21:45:47 +0000",
  "in_reply_to_screen_name" : "LjiljanaHavran",
  "in_reply_to_user_id_str" : "1395825290",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ljiljana Havran",
      "screen_name" : "LjiljanaHavran",
      "indices" : [ 0, 15 ],
      "id_str" : "1395825290",
      "id" : 1395825290
    }, {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 16, 22 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716740982637727744",
  "geo" : { },
  "id_str" : "716742312152461312",
  "in_reply_to_user_id" : 1395825290,
  "text" : "@LjiljanaHavran @ebefl have u read it Ljiljana?",
  "id" : 716742312152461312,
  "in_reply_to_status_id" : 716740982637727744,
  "created_at" : "2016-04-03 21:40:58 +0000",
  "in_reply_to_screen_name" : "LjiljanaHavran",
  "in_reply_to_user_id_str" : "1395825290",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Venning",
      "screen_name" : "linkstoenglish",
      "indices" : [ 3, 18 ],
      "id_str" : "3083991707",
      "id" : 3083991707
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/7KjlmCeQKd",
      "expanded_url" : "http:\/\/www.fromoldbooks.org\/Grose-VulgarTongue\/w\/westminster-wedding.html",
      "display_url" : "fromoldbooks.org\/Grose-VulgarTo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "716735347791626240",
  "text" : "RT @linkstoenglish: Just stumbled upon an online version of Grose's 1811 Dictionary of the Vulgar Tongue. Marvellous to dip into! https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/7KjlmCeQKd",
        "expanded_url" : "http:\/\/www.fromoldbooks.org\/Grose-VulgarTongue\/w\/westminster-wedding.html",
        "display_url" : "fromoldbooks.org\/Grose-VulgarTo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "716734908517982209",
    "text" : "Just stumbled upon an online version of Grose's 1811 Dictionary of the Vulgar Tongue. Marvellous to dip into! https:\/\/t.co\/7KjlmCeQKd",
    "id" : 716734908517982209,
    "created_at" : "2016-04-03 21:11:33 +0000",
    "user" : {
      "name" : "Mark Venning",
      "screen_name" : "linkstoenglish",
      "protected" : false,
      "id_str" : "3083991707",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/575341765269458944\/MQ14AxmY_normal.jpeg",
      "id" : 3083991707,
      "verified" : false
    }
  },
  "id" : 716735347791626240,
  "created_at" : "2016-04-03 21:13:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Brown",
      "screen_name" : "sbrowntweets",
      "indices" : [ 0, 13 ],
      "id_str" : "885343459",
      "id" : 885343459
    }, {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 14, 20 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    }, {
      "name" : "Carol Goodey",
      "screen_name" : "carol_goodey",
      "indices" : [ 21, 34 ],
      "id_str" : "2814555865",
      "id" : 2814555865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716722256580362240",
  "geo" : { },
  "id_str" : "716722469663543299",
  "in_reply_to_user_id" : 885343459,
  "text" : "@sbrowntweets @ebefl @carol_goodey he'll be all night folks  : ) donations in the hat",
  "id" : 716722469663543299,
  "in_reply_to_status_id" : 716722256580362240,
  "created_at" : "2016-04-03 20:22:07 +0000",
  "in_reply_to_screen_name" : "sbrowntweets",
  "in_reply_to_user_id_str" : "885343459",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Brown",
      "screen_name" : "sbrowntweets",
      "indices" : [ 0, 13 ],
      "id_str" : "885343459",
      "id" : 885343459
    }, {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 14, 20 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    }, {
      "name" : "Carol Goodey",
      "screen_name" : "carol_goodey",
      "indices" : [ 21, 34 ],
      "id_str" : "2814555865",
      "id" : 2814555865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716720682223214592",
  "geo" : { },
  "id_str" : "716721595797127168",
  "in_reply_to_user_id" : 885343459,
  "text" : "@sbrowntweets @ebefl @carol_goodey maybe it is a zen meditation to focus on what is not there?",
  "id" : 716721595797127168,
  "in_reply_to_status_id" : 716720682223214592,
  "created_at" : "2016-04-03 20:18:39 +0000",
  "in_reply_to_screen_name" : "sbrowntweets",
  "in_reply_to_user_id_str" : "885343459",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Brown",
      "screen_name" : "sbrowntweets",
      "indices" : [ 0, 13 ],
      "id_str" : "885343459",
      "id" : 885343459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716718267994398720",
  "geo" : { },
  "id_str" : "716718749798297601",
  "in_reply_to_user_id" : 885343459,
  "text" : "@sbrowntweets true &amp; what is your understanding of that hebdo editorial?",
  "id" : 716718749798297601,
  "in_reply_to_status_id" : 716718267994398720,
  "created_at" : "2016-04-03 20:07:20 +0000",
  "in_reply_to_screen_name" : "sbrowntweets",
  "in_reply_to_user_id_str" : "885343459",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Szab\u00F3",
      "screen_name" : "RobertASzabo",
      "indices" : [ 0, 13 ],
      "id_str" : "145285777",
      "id" : 145285777
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716714237259866113",
  "geo" : { },
  "id_str" : "716718393861255168",
  "in_reply_to_user_id" : 145285777,
  "text" : "@RobertASzabo there was also millietant?  thing is if u r not \"punching up\" i don't really find it amusing",
  "id" : 716718393861255168,
  "in_reply_to_status_id" : 716714237259866113,
  "created_at" : "2016-04-03 20:05:55 +0000",
  "in_reply_to_screen_name" : "RobertASzabo",
  "in_reply_to_user_id_str" : "145285777",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Brown",
      "screen_name" : "sbrowntweets",
      "indices" : [ 0, 13 ],
      "id_str" : "885343459",
      "id" : 885343459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716714897640460292",
  "geo" : { },
  "id_str" : "716715704167358465",
  "in_reply_to_user_id" : 885343459,
  "text" : "@sbrowntweets it is no surprise since racist discourse follows it own rational that leaves +most+ cold",
  "id" : 716715704167358465,
  "in_reply_to_status_id" : 716714897640460292,
  "created_at" : "2016-04-03 19:55:14 +0000",
  "in_reply_to_screen_name" : "sbrowntweets",
  "in_reply_to_user_id_str" : "885343459",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Szab\u00F3",
      "screen_name" : "RobertASzabo",
      "indices" : [ 0, 13 ],
      "id_str" : "145285777",
      "id" : 145285777
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716712406282592256",
  "geo" : { },
  "id_str" : "716713919411302401",
  "in_reply_to_user_id" : 145285777,
  "text" : "@RobertASzabo oh yes thanks missed url in yr tweet for some reason",
  "id" : 716713919411302401,
  "in_reply_to_status_id" : 716712406282592256,
  "created_at" : "2016-04-03 19:48:08 +0000",
  "in_reply_to_screen_name" : "RobertASzabo",
  "in_reply_to_user_id_str" : "145285777",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Szab\u00F3",
      "screen_name" : "RobertASzabo",
      "indices" : [ 0, 13 ],
      "id_str" : "145285777",
      "id" : 145285777
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716712406282592256",
  "geo" : { },
  "id_str" : "716713739035222016",
  "in_reply_to_user_id" : 145285777,
  "text" : "@RobertASzabo u couldn't make it up cld you? - a \"satrical\" mag with gov funding; is Viz online?",
  "id" : 716713739035222016,
  "in_reply_to_status_id" : 716712406282592256,
  "created_at" : "2016-04-03 19:47:25 +0000",
  "in_reply_to_screen_name" : "RobertASzabo",
  "in_reply_to_user_id_str" : "145285777",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Szab\u00F3",
      "screen_name" : "RobertASzabo",
      "indices" : [ 0, 13 ],
      "id_str" : "145285777",
      "id" : 145285777
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716709379442143232",
  "geo" : { },
  "id_str" : "716709880367824896",
  "in_reply_to_user_id" : 145285777,
  "text" : "@RobertASzabo is it still going? anyway that comparison is highly debateable e.g. hebdo got money from gov as well as big names like google",
  "id" : 716709880367824896,
  "in_reply_to_status_id" : 716709379442143232,
  "created_at" : "2016-04-03 19:32:05 +0000",
  "in_reply_to_screen_name" : "RobertASzabo",
  "in_reply_to_user_id_str" : "145285777",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Szab\u00F3",
      "screen_name" : "RobertASzabo",
      "indices" : [ 0, 13 ],
      "id_str" : "145285777",
      "id" : 145285777
    }, {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 14, 20 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716700939990736896",
  "geo" : { },
  "id_str" : "716701745863344129",
  "in_reply_to_user_id" : 145285777,
  "text" : "@RobertASzabo @ebefl recently? no I remember that guy with the unfeasably large testicles : )",
  "id" : 716701745863344129,
  "in_reply_to_status_id" : 716700939990736896,
  "created_at" : "2016-04-03 18:59:46 +0000",
  "in_reply_to_screen_name" : "RobertASzabo",
  "in_reply_to_user_id_str" : "145285777",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Szab\u00F3",
      "screen_name" : "RobertASzabo",
      "indices" : [ 0, 13 ],
      "id_str" : "145285777",
      "id" : 145285777
    }, {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 14, 20 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716699630474551297",
  "geo" : { },
  "id_str" : "716700584552873984",
  "in_reply_to_user_id" : 145285777,
  "text" : "@RobertASzabo @ebefl Jonathan Freedland btw the convo started on racist Charlie hebdo editorial  how does Russ feel that is relevant?",
  "id" : 716700584552873984,
  "in_reply_to_status_id" : 716699630474551297,
  "created_at" : "2016-04-03 18:55:09 +0000",
  "in_reply_to_screen_name" : "RobertASzabo",
  "in_reply_to_user_id_str" : "145285777",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Jennifer MacDonald",
      "screen_name" : "JenMac_ESL",
      "indices" : [ 10, 21 ],
      "id_str" : "608800026",
      "id" : 608800026
    }, {
      "name" : "Melih",
      "screen_name" : "melihELT",
      "indices" : [ 22, 31 ],
      "id_str" : "2797763892",
      "id" : 2797763892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716378780248322048",
  "geo" : { },
  "id_str" : "716699839980036096",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava @JenMac_ESL @melihELT thanks for sharing folks",
  "id" : 716699839980036096,
  "in_reply_to_status_id" : 716378780248322048,
  "created_at" : "2016-04-03 18:52:12 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716693553074814976",
  "geo" : { },
  "id_str" : "716699363024744449",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl dunno reckon response matches the level of yr name calling re left and anti-semitism",
  "id" : 716699363024744449,
  "in_reply_to_status_id" : 716693553074814976,
  "created_at" : "2016-04-03 18:50:18 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Divya Madhavan",
      "screen_name" : "_divyamadhavan",
      "indices" : [ 39, 54 ],
      "id_str" : "408492806",
      "id" : 408492806
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/RiBGZjZDy0",
      "expanded_url" : "http:\/\/divyamadhavan.com\/2016\/04\/03\/the-hypnos\/",
      "display_url" : "divyamadhavan.com\/2016\/04\/03\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "716692645490388993",
  "text" : "The Hypnos https:\/\/t.co\/RiBGZjZDy0 via @_divyamadhavan",
  "id" : 716692645490388993,
  "created_at" : "2016-04-03 18:23:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716641243883827200",
  "geo" : { },
  "id_str" : "716680440984244224",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl that's right I don't read the torygraph",
  "id" : 716680440984244224,
  "in_reply_to_status_id" : 716641243883827200,
  "created_at" : "2016-04-03 17:35:07 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Parise",
      "screen_name" : "peterrenshu",
      "indices" : [ 0, 12 ],
      "id_str" : "631949549",
      "id" : 631949549
    }, {
      "name" : "Alexandria Hall",
      "screen_name" : "alxndghall",
      "indices" : [ 13, 24 ],
      "id_str" : "1656929592",
      "id" : 1656929592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716617808738541569",
  "geo" : { },
  "id_str" : "716619611647643648",
  "in_reply_to_user_id" : 631949549,
  "text" : "@peterrenshu @alxndghall a pleasure Peter : )",
  "id" : 716619611647643648,
  "in_reply_to_status_id" : 716617808738541569,
  "created_at" : "2016-04-03 13:33:24 +0000",
  "in_reply_to_screen_name" : "peterrenshu",
  "in_reply_to_user_id_str" : "631949549",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol Goodey",
      "screen_name" : "carol_goodey",
      "indices" : [ 0, 13 ],
      "id_str" : "2814555865",
      "id" : 2814555865
    }, {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 14, 20 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716607441237049344",
  "geo" : { },
  "id_str" : "716609093897728000",
  "in_reply_to_user_id" : 2814555865,
  "text" : "@carol_goodey @ebefl pssh nothing's too big for twitter : ) enjoy yr Sunday as well!",
  "id" : 716609093897728000,
  "in_reply_to_status_id" : 716607441237049344,
  "created_at" : "2016-04-03 12:51:36 +0000",
  "in_reply_to_screen_name" : "carol_goodey",
  "in_reply_to_user_id_str" : "2814555865",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/Vd6lEvsrKe",
      "expanded_url" : "http:\/\/www.theguardian.com\/politics\/2016\/apr\/02\/david-cameron-aid-libya-un-crisis",
      "display_url" : "theguardian.com\/politics\/2016\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "716608825416097792",
  "text" : "RT @pchallinor: Wog-bombing's just like restaurant-trashing. Throw a bit of money at them and forget it https:\/\/t.co\/Vd6lEvsrKe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/Vd6lEvsrKe",
        "expanded_url" : "http:\/\/www.theguardian.com\/politics\/2016\/apr\/02\/david-cameron-aid-libya-un-crisis",
        "display_url" : "theguardian.com\/politics\/2016\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "716608622776729600",
    "text" : "Wog-bombing's just like restaurant-trashing. Throw a bit of money at them and forget it https:\/\/t.co\/Vd6lEvsrKe",
    "id" : 716608622776729600,
    "created_at" : "2016-04-03 12:49:44 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 716608825416097792,
  "created_at" : "2016-04-03 12:50:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol Goodey",
      "screen_name" : "carol_goodey",
      "indices" : [ 0, 13 ],
      "id_str" : "2814555865",
      "id" : 2814555865
    }, {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 14, 20 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/716607638017015808\/photo\/1",
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/5tpOtx2Ue4",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CfHmtqGWQAEohbo.jpg",
      "id_str" : "716607487798034433",
      "id" : 716607487798034433,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CfHmtqGWQAEohbo.jpg",
      "sizes" : [ {
        "h" : 224,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 224,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 190,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 224,
        "resize" : "fit",
        "w" : 400
      } ],
      "display_url" : "pic.twitter.com\/5tpOtx2Ue4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716605452939825152",
  "geo" : { },
  "id_str" : "716607638017015808",
  "in_reply_to_user_id" : 2814555865,
  "text" : "@carol_goodey @ebefl re Russ's comment on Labour &amp; anti-semitism https:\/\/t.co\/5tpOtx2Ue4",
  "id" : 716607638017015808,
  "in_reply_to_status_id" : 716605452939825152,
  "created_at" : "2016-04-03 12:45:49 +0000",
  "in_reply_to_screen_name" : "carol_goodey",
  "in_reply_to_user_id_str" : "2814555865",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 66, 82 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/q0T5MW4D29",
      "expanded_url" : "https:\/\/eltnick.wordpress.com\/2016\/04\/01\/advertising-creativity-motivation\/",
      "display_url" : "eltnick.wordpress.com\/2016\/04\/01\/adv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "716607061837094912",
  "text" : "Advertising - Creativity - Motivation https:\/\/t.co\/q0T5MW4D29 via @wordpressdotcom",
  "id" : 716607061837094912,
  "created_at" : "2016-04-03 12:43:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    }, {
      "name" : "Carol Goodey",
      "screen_name" : "carol_goodey",
      "indices" : [ 7, 20 ],
      "id_str" : "2814555865",
      "id" : 2814555865
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/716603514823294976\/photo\/1",
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/q1weGNQQ16",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CfHjCHoWIAAU-BO.jpg",
      "id_str" : "716603441276133376",
      "id" : 716603441276133376,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CfHjCHoWIAAU-BO.jpg",
      "sizes" : [ {
        "h" : 534,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 363,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 534,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 534,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/q1weGNQQ16"
    } ],
    "hashtags" : [ {
      "text" : "disgustedoftunbridgwells",
      "indices" : [ 47, 72 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716599884330180608",
  "geo" : { },
  "id_str" : "716603514823294976",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl @carol_goodey i'm all for bringing back #disgustedoftunbridgwells https:\/\/t.co\/q1weGNQQ16",
  "id" : 716603514823294976,
  "in_reply_to_status_id" : 716599884330180608,
  "created_at" : "2016-04-03 12:29:26 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    }, {
      "name" : "Carol Goodey",
      "screen_name" : "carol_goodey",
      "indices" : [ 7, 20 ],
      "id_str" : "2814555865",
      "id" : 2814555865
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "regressiveleft",
      "indices" : [ 26, 41 ]
    }, {
      "text" : "PoliticallyCorrect",
      "indices" : [ 52, 71 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716599884330180608",
  "geo" : { },
  "id_str" : "716602251003957248",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl @carol_goodey does #regressiveleft mean that #PoliticallyCorrect is now retired? :\/",
  "id" : 716602251003957248,
  "in_reply_to_status_id" : 716599884330180608,
  "created_at" : "2016-04-03 12:24:25 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/UoQs578MLS",
      "expanded_url" : "http:\/\/www.france24.com\/en\/20160330-french-minister-muslim-women-who-wear-veils-like-pro-slavery-negroes?dlvrit=66745",
      "display_url" : "france24.com\/en\/20160330-fr\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "716599529064284160",
  "geo" : { },
  "id_str" : "716600746268033024",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl i don't think poster misread at all; consider charlie hebdo editorial with this context https:\/\/t.co\/UoQs578MLS",
  "id" : 716600746268033024,
  "in_reply_to_status_id" : 716599529064284160,
  "created_at" : "2016-04-03 12:18:26 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Scott Thornbury",
      "screen_name" : "thornburyscott",
      "indices" : [ 10, 25 ],
      "id_str" : "23090474",
      "id" : 23090474
    }, {
      "name" : "Road2English",
      "screen_name" : "DpEnglishMadrid",
      "indices" : [ 26, 42 ],
      "id_str" : "967120428",
      "id" : 967120428
    }, {
      "name" : "Ibrahim",
      "screen_name" : "Sirinne",
      "indices" : [ 43, 51 ],
      "id_str" : "61337075",
      "id" : 61337075
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716378780248322048",
  "geo" : { },
  "id_str" : "716593023627472896",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava @thornburyscott @DpEnglishMadrid @Sirinne thanks for the RTs folks : )",
  "id" : 716593023627472896,
  "in_reply_to_status_id" : 716378780248322048,
  "created_at" : "2016-04-03 11:47:45 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716586036445519872",
  "geo" : { },
  "id_str" : "716592436802400257",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl does the article mention \"the left\"? was your initial response to the article or the tweet comment on article?",
  "id" : 716592436802400257,
  "in_reply_to_status_id" : 716586036445519872,
  "created_at" : "2016-04-03 11:45:25 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/716550043839438848\/photo\/1",
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/rHpSItya3Z",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CfGycwQXEAElw8M.jpg",
      "id_str" : "716550022788222977",
      "id" : 716550022788222977,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CfGycwQXEAElw8M.jpg",
      "sizes" : [ {
        "h" : 294,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 294,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 294,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 250,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/rHpSItya3Z"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716547974348689408",
  "geo" : { },
  "id_str" : "716550043839438848",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish https:\/\/t.co\/rHpSItya3Z",
  "id" : 716550043839438848,
  "in_reply_to_status_id" : 716547974348689408,
  "created_at" : "2016-04-03 08:56:57 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Michael Brown",
      "screen_name" : "Za_Maikeru",
      "indices" : [ 10, 21 ],
      "id_str" : "703598479944208384",
      "id" : 703598479944208384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716378780248322048",
  "geo" : { },
  "id_str" : "716547307525816321",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava @Za_Maikeru thanks for RT : )",
  "id" : 716547307525816321,
  "in_reply_to_status_id" : 716378780248322048,
  "created_at" : "2016-04-03 08:46:05 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716544417801183232",
  "geo" : { },
  "id_str" : "716546728946765824",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish oh hey cheers Marc, that's a compliment right? : )",
  "id" : 716546728946765824,
  "in_reply_to_status_id" : 716544417801183232,
  "created_at" : "2016-04-03 08:43:47 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Alec Couros",
      "screen_name" : "courosa",
      "indices" : [ 3, 11 ],
      "id_str" : "739293",
      "id" : 739293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/kKcJLYl2LP",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=LSZPNwZex9s",
      "display_url" : "youtube.com\/watch?v=LSZPNw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "716543766363025408",
  "text" : "RT @courosa: \"Introducing the self-driving bicycle in the Netherlands\" https:\/\/t.co\/kKcJLYl2LP One of the better vids from April 1.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/kKcJLYl2LP",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=LSZPNwZex9s",
        "display_url" : "youtube.com\/watch?v=LSZPNw\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "716536839142830080",
    "text" : "\"Introducing the self-driving bicycle in the Netherlands\" https:\/\/t.co\/kKcJLYl2LP One of the better vids from April 1.",
    "id" : 716536839142830080,
    "created_at" : "2016-04-03 08:04:29 +0000",
    "user" : {
      "name" : "Dr. Alec Couros",
      "screen_name" : "courosa",
      "protected" : false,
      "id_str" : "739293",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/480186733221249027\/bzI2RIfo_normal.jpeg",
      "id" : 739293,
      "verified" : false
    }
  },
  "id" : 716543766363025408,
  "created_at" : "2016-04-03 08:32:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Whyte",
      "screen_name" : "eslwriter",
      "indices" : [ 3, 13 ],
      "id_str" : "187481025",
      "id" : 187481025
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/eslwriter\/status\/716502688750436352\/photo\/1",
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/wR8QNlXPWq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfGHZdLUUAI-bU9.jpg",
      "id_str" : "716502687127195650",
      "id" : 716502687127195650,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfGHZdLUUAI-bU9.jpg",
      "sizes" : [ {
        "h" : 536,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 3349,
        "resize" : "fit",
        "w" : 6400
      }, {
        "h" : 178,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 314,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/wR8QNlXPWq"
    } ],
    "hashtags" : [ {
      "text" : "ESL",
      "indices" : [ 21, 25 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/aqNa7Gt4xK",
      "expanded_url" : "http:\/\/bit.ly\/1V0gBlt",
      "display_url" : "bit.ly\/1V0gBlt"
    } ]
  },
  "geo" : { },
  "id_str" : "716541911302029313",
  "text" : "RT @eslwriter: Teach #ESL students correlation and causation, a 20 minute lesson.  https:\/\/t.co\/aqNa7Gt4xK https:\/\/t.co\/wR8QNlXPWq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/eslwriter\/status\/716502688750436352\/photo\/1",
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/wR8QNlXPWq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CfGHZdLUUAI-bU9.jpg",
        "id_str" : "716502687127195650",
        "id" : 716502687127195650,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfGHZdLUUAI-bU9.jpg",
        "sizes" : [ {
          "h" : 536,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 3349,
          "resize" : "fit",
          "w" : 6400
        }, {
          "h" : 178,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 314,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/wR8QNlXPWq"
      } ],
      "hashtags" : [ {
        "text" : "ESL",
        "indices" : [ 6, 10 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/aqNa7Gt4xK",
        "expanded_url" : "http:\/\/bit.ly\/1V0gBlt",
        "display_url" : "bit.ly\/1V0gBlt"
      } ]
    },
    "geo" : { },
    "id_str" : "716502688750436352",
    "text" : "Teach #ESL students correlation and causation, a 20 minute lesson.  https:\/\/t.co\/aqNa7Gt4xK https:\/\/t.co\/wR8QNlXPWq",
    "id" : 716502688750436352,
    "created_at" : "2016-04-03 05:48:47 +0000",
    "user" : {
      "name" : "Rob Whyte",
      "screen_name" : "eslwriter",
      "protected" : false,
      "id_str" : "187481025",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2682332531\/cd44653e5843c08c6938f41dc15668bc_normal.png",
      "id" : 187481025,
      "verified" : false
    }
  },
  "id" : 716541911302029313,
  "created_at" : "2016-04-03 08:24:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Brown",
      "screen_name" : "Za_Maikeru",
      "indices" : [ 78, 89 ],
      "id_str" : "703598479944208384",
      "id" : 703598479944208384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/0rY4uCGpoD",
      "expanded_url" : "https:\/\/corpling4efl.wordpress.com\/2016\/04\/03\/gently-introducing-teachers-to-corpus-linguistics\/",
      "display_url" : "corpling4efl.wordpress.com\/2016\/04\/03\/gen\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "716538199091376128",
  "text" : "Gently introducing teachers to Corpus Linguistics https:\/\/t.co\/0rY4uCGpoD via @Za_Maikeru",
  "id" : 716538199091376128,
  "created_at" : "2016-04-03 08:09:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716464571830165504",
  "geo" : { },
  "id_str" : "716534008121856001",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl hey Russ what do you take from it?",
  "id" : 716534008121856001,
  "in_reply_to_status_id" : 716464571830165504,
  "created_at" : "2016-04-03 07:53:14 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Necropolitan Elite",
      "screen_name" : "MediocreDave",
      "indices" : [ 3, 16 ],
      "id_str" : "141188735",
      "id" : 141188735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/EZG7iQlrx3",
      "expanded_url" : "https:\/\/charliehebdo.fr\/en\/edito\/how-did-we-end-up-here\/",
      "display_url" : "charliehebdo.fr\/en\/edito\/how-d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "716397542699835392",
  "text" : "RT @MediocreDave: Charlie Hebdo editorial calmly arguing that the visible presence of Muslims in public is a form of terrorism. https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/EZG7iQlrx3",
        "expanded_url" : "https:\/\/charliehebdo.fr\/en\/edito\/how-did-we-end-up-here\/",
        "display_url" : "charliehebdo.fr\/en\/edito\/how-d\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "716381288287117312",
    "text" : "Charlie Hebdo editorial calmly arguing that the visible presence of Muslims in public is a form of terrorism. https:\/\/t.co\/EZG7iQlrx3",
    "id" : 716381288287117312,
    "created_at" : "2016-04-02 21:46:23 +0000",
    "user" : {
      "name" : "Necropolitan Elite",
      "screen_name" : "MediocreDave",
      "protected" : false,
      "id_str" : "141188735",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/641920374255538176\/jo20t5hy_normal.jpg",
      "id" : 141188735,
      "verified" : false
    }
  },
  "id" : 716397542699835392,
  "created_at" : "2016-04-02 22:50:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AllThingsLinguistic",
      "screen_name" : "AllThingsLing",
      "indices" : [ 3, 17 ],
      "id_str" : "857291268",
      "id" : 857291268
    }, {
      "name" : "Arika Okrent",
      "screen_name" : "arikaokrent",
      "indices" : [ 105, 117 ],
      "id_str" : "47226743",
      "id" : 47226743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 140 ],
      "url" : "https:\/\/t.co\/7HLbEHAaqZ",
      "expanded_url" : "https:\/\/tmblr.co\/ZuWOEv24OOvgE",
      "display_url" : "tmblr.co\/ZuWOEv24OOvgE"
    } ]
  },
  "geo" : { },
  "id_str" : "716394819397009408",
  "text" : "RT @AllThingsLing: One generation\u2019s despised jargon is another generation\u2019s unremarkable vocab (video by @arikaokrent) https:\/\/t.co\/7HLbEHA\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Arika Okrent",
        "screen_name" : "arikaokrent",
        "indices" : [ 86, 98 ],
        "id_str" : "47226743",
        "id" : 47226743
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/7HLbEHAaqZ",
        "expanded_url" : "https:\/\/tmblr.co\/ZuWOEv24OOvgE",
        "display_url" : "tmblr.co\/ZuWOEv24OOvgE"
      } ]
    },
    "geo" : { },
    "id_str" : "716392352181518337",
    "text" : "One generation\u2019s despised jargon is another generation\u2019s unremarkable vocab (video by @arikaokrent) https:\/\/t.co\/7HLbEHAaqZ",
    "id" : 716392352181518337,
    "created_at" : "2016-04-02 22:30:21 +0000",
    "user" : {
      "name" : "AllThingsLinguistic",
      "screen_name" : "AllThingsLing",
      "protected" : false,
      "id_str" : "857291268",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750400997206454273\/N0DmrmFi_normal.jpg",
      "id" : 857291268,
      "verified" : false
    }
  },
  "id" : 716394819397009408,
  "created_at" : "2016-04-02 22:40:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/GPlQfedzr9",
      "expanded_url" : "https:\/\/boingboing.net\/2016\/04\/02\/four-days-in-and-the-bbc-hasn.html",
      "display_url" : "boingboing.net\/2016\/04\/02\/fou\u2026"
    }, {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/ysncupBJWU",
      "expanded_url" : "http:\/\/www.bbc.co.uk\/news\/blogs-trending-35944803",
      "display_url" : "bbc.co.uk\/news\/blogs-tre\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "716392111050997761",
  "text" : "RT @pchallinor: Biggest bribery scandal ever https:\/\/t.co\/GPlQfedzr9 BBC has better things to do https:\/\/t.co\/ysncupBJWU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 29, 52 ],
        "url" : "https:\/\/t.co\/GPlQfedzr9",
        "expanded_url" : "https:\/\/boingboing.net\/2016\/04\/02\/four-days-in-and-the-bbc-hasn.html",
        "display_url" : "boingboing.net\/2016\/04\/02\/fou\u2026"
      }, {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/ysncupBJWU",
        "expanded_url" : "http:\/\/www.bbc.co.uk\/news\/blogs-trending-35944803",
        "display_url" : "bbc.co.uk\/news\/blogs-tre\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "716389916876386304",
    "text" : "Biggest bribery scandal ever https:\/\/t.co\/GPlQfedzr9 BBC has better things to do https:\/\/t.co\/ysncupBJWU",
    "id" : 716389916876386304,
    "created_at" : "2016-04-02 22:20:40 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 716392111050997761,
  "created_at" : "2016-04-02 22:29:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/716378780248322048\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/d2Upy9oxel",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfEWtD6VAAAaBvk.jpg",
      "id_str" : "716378779128496128",
      "id" : 716378779128496128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfEWtD6VAAAaBvk.jpg",
      "sizes" : [ {
        "h" : 270,
        "resize" : "fit",
        "w" : 565
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 162,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 565
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 565
      } ],
      "display_url" : "pic.twitter.com\/d2Upy9oxel"
    } ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 41, 49 ]
    }, {
      "text" : "linguistics",
      "indices" : [ 50, 62 ]
    }, {
      "text" : "esl",
      "indices" : [ 63, 67 ]
    }, {
      "text" : "tesol",
      "indices" : [ 68, 74 ]
    }, {
      "text" : "efl",
      "indices" : [ 75, 79 ]
    }, {
      "text" : "tefl",
      "indices" : [ 80, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/Z3CCYf6F32",
      "expanded_url" : "https:\/\/eflnotes.wordpress.com\/2016\/04\/02\/a-an-the-definiteness-and-specificity\/",
      "display_url" : "eflnotes.wordpress.com\/2016\/04\/02\/a-a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "716378780248322048",
  "text" : "A, an, the, definiteness and specificity #eltchat #linguistics #esl #tesol #efl #tefl https:\/\/t.co\/Z3CCYf6F32 https:\/\/t.co\/d2Upy9oxel",
  "id" : 716378780248322048,
  "created_at" : "2016-04-02 21:36:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "https:\/\/t.co\/hfmSiWuGoI",
      "expanded_url" : "http:\/\/www.theguardian.com\/politics\/2016\/apr\/02\/jeremy-corbyn-mobbed-by-supporters-during-bristol-walkabout",
      "display_url" : "theguardian.com\/politics\/2016\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "716276136624398336",
  "text" : "RT @pchallinor: Demagogue Corbyn snubs bearers of truth to conduct fiendish psychological experiments on hapless proles https:\/\/t.co\/hfmSiW\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/hfmSiWuGoI",
        "expanded_url" : "http:\/\/www.theguardian.com\/politics\/2016\/apr\/02\/jeremy-corbyn-mobbed-by-supporters-during-bristol-walkabout",
        "display_url" : "theguardian.com\/politics\/2016\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "716275172471349248",
    "text" : "Demagogue Corbyn snubs bearers of truth to conduct fiendish psychological experiments on hapless proles https:\/\/t.co\/hfmSiWuGoI",
    "id" : 716275172471349248,
    "created_at" : "2016-04-02 14:44:43 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 716276136624398336,
  "created_at" : "2016-04-02 14:48:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "0PII",
      "screen_name" : "00pii",
      "indices" : [ 3, 9 ],
      "id_str" : "2305286370",
      "id" : 2305286370
    }, {
      "name" : "Google",
      "screen_name" : "google",
      "indices" : [ 28, 35 ],
      "id_str" : "20536157",
      "id" : 20536157
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "privacy",
      "indices" : [ 138, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/aOHD7Fd6eD",
      "expanded_url" : "http:\/\/www.zdnet.com\/article\/google-creates-smartphone-id-system-that-can-tell-its-you-just-from-your-nose\/",
      "display_url" : "zdnet.com\/article\/google\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "716257625483173889",
  "text" : "RT @00pii: Mu ha ha ha \uD83D\uDE02\uD83D\uDE02\uD83D\uDE02, @Google turns 'continuous video surveillance' into 'login convenience'.\n\nEvil genius.\n\nhttps:\/\/t.co\/aOHD7Fd6eD\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Google",
        "screen_name" : "google",
        "indices" : [ 17, 24 ],
        "id_str" : "20536157",
        "id" : 20536157
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "privacy",
        "indices" : [ 129, 137 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/aOHD7Fd6eD",
        "expanded_url" : "http:\/\/www.zdnet.com\/article\/google-creates-smartphone-id-system-that-can-tell-its-you-just-from-your-nose\/",
        "display_url" : "zdnet.com\/article\/google\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "716254087814193152",
    "text" : "Mu ha ha ha \uD83D\uDE02\uD83D\uDE02\uD83D\uDE02, @Google turns 'continuous video surveillance' into 'login convenience'.\n\nEvil genius.\n\nhttps:\/\/t.co\/aOHD7Fd6eD\n\n#privacy",
    "id" : 716254087814193152,
    "created_at" : "2016-04-02 13:20:56 +0000",
    "user" : {
      "name" : "0PII",
      "screen_name" : "00pii",
      "protected" : false,
      "id_str" : "2305286370",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/426062612367826946\/wHYL0WWd_normal.png",
      "id" : 2305286370,
      "verified" : false
    }
  },
  "id" : 716257625483173889,
  "created_at" : "2016-04-02 13:34:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Rachael TESOL",
      "screen_name" : "RachaelTESOL",
      "indices" : [ 10, 23 ],
      "id_str" : "537057787",
      "id" : 537057787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715536666203533312",
  "geo" : { },
  "id_str" : "716232835372285952",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava @RachaelTESOL thanks for sharing Rachael : ) got any good language trivia?",
  "id" : 716232835372285952,
  "in_reply_to_status_id" : 715536666203533312,
  "created_at" : "2016-04-02 11:56:29 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 39, 55 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/fNYw1FPJxQ",
      "expanded_url" : "https:\/\/thepostmodernguy.wordpress.com\/2016\/04\/02\/case-study\/",
      "display_url" : "thepostmodernguy.wordpress.com\/2016\/04\/02\/cas\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "716201992113233920",
  "text" : "Case study https:\/\/t.co\/fNYw1FPJxQ via @wordpressdotcom",
  "id" : 716201992113233920,
  "created_at" : "2016-04-02 09:53:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Ding",
      "screen_name" : "alexanderding",
      "indices" : [ 0, 14 ],
      "id_str" : "118014141",
      "id" : 118014141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "714522566073909248",
  "geo" : { },
  "id_str" : "716201751242780672",
  "in_reply_to_user_id" : 118014141,
  "text" : "@alexanderding i think i like the format this blog does, short interpretations of linking his experience to sociological theory?",
  "id" : 716201751242780672,
  "in_reply_to_status_id" : 714522566073909248,
  "created_at" : "2016-04-02 09:52:58 +0000",
  "in_reply_to_screen_name" : "alexanderding",
  "in_reply_to_user_id_str" : "118014141",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hana Tich\u00E1",
      "screen_name" : "HanaTicha",
      "indices" : [ 44, 54 ],
      "id_str" : "512296705",
      "id" : 512296705
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/DckT4upFAR",
      "expanded_url" : "https:\/\/hanatichaeltblog.wordpress.com\/2016\/04\/02\/anonymous-world\/",
      "display_url" : "hanatichaeltblog.wordpress.com\/2016\/04\/02\/ano\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "716200295114653696",
  "text" : "Anonymous world https:\/\/t.co\/DckT4upFAR via @HanaTicha",
  "id" : 716200295114653696,
  "created_at" : "2016-04-02 09:47:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELTjam",
      "screen_name" : "eltjam",
      "indices" : [ 3, 10 ],
      "id_str" : "1356363686",
      "id" : 1356363686
    }, {
      "name" : "Katie Nielson",
      "screen_name" : "KBNielson",
      "indices" : [ 83, 93 ],
      "id_str" : "818373565",
      "id" : 818373565
    }, {
      "name" : "Voxy",
      "screen_name" : "Voxy",
      "indices" : [ 94, 99 ],
      "id_str" : "3066791",
      "id" : 3066791
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/eltjam\/status\/710442803944357888\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/RT1KXFsktY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cdv_9zsUsAAMIlz.jpg",
      "id_str" : "710442803554201600",
      "id" : 710442803554201600,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cdv_9zsUsAAMIlz.jpg",
      "sizes" : [ {
        "h" : 271,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 271,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 181,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 271,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/RT1KXFsktY"
    } ],
    "hashtags" : [ {
      "text" : "language",
      "indices" : [ 53, 62 ]
    }, {
      "text" : "SLA",
      "indices" : [ 124, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/zE5cxPhl7T",
      "expanded_url" : "http:\/\/ow.ly\/ZBqtr",
      "display_url" : "ow.ly\/ZBqtr"
    } ]
  },
  "geo" : { },
  "id_str" : "716195821675495424",
  "text" : "RT @eltjam: Back in the classroom: new insights into #language learners challenges @KBNielson @Voxy https:\/\/t.co\/zE5cxPhl7T #SLA https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Katie Nielson",
        "screen_name" : "KBNielson",
        "indices" : [ 71, 81 ],
        "id_str" : "818373565",
        "id" : 818373565
      }, {
        "name" : "Voxy",
        "screen_name" : "Voxy",
        "indices" : [ 82, 87 ],
        "id_str" : "3066791",
        "id" : 3066791
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/eltjam\/status\/710442803944357888\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/RT1KXFsktY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cdv_9zsUsAAMIlz.jpg",
        "id_str" : "710442803554201600",
        "id" : 710442803554201600,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cdv_9zsUsAAMIlz.jpg",
        "sizes" : [ {
          "h" : 271,
          "resize" : "fit",
          "w" : 510
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 271,
          "resize" : "fit",
          "w" : 510
        }, {
          "h" : 181,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 271,
          "resize" : "fit",
          "w" : 510
        } ],
        "display_url" : "pic.twitter.com\/RT1KXFsktY"
      } ],
      "hashtags" : [ {
        "text" : "language",
        "indices" : [ 41, 50 ]
      }, {
        "text" : "SLA",
        "indices" : [ 112, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/zE5cxPhl7T",
        "expanded_url" : "http:\/\/ow.ly\/ZBqtr",
        "display_url" : "ow.ly\/ZBqtr"
      } ]
    },
    "geo" : { },
    "id_str" : "716192259054694400",
    "text" : "Back in the classroom: new insights into #language learners challenges @KBNielson @Voxy https:\/\/t.co\/zE5cxPhl7T #SLA https:\/\/t.co\/RT1KXFsktY",
    "id" : 716192259054694400,
    "created_at" : "2016-04-02 09:15:15 +0000",
    "user" : {
      "name" : "ELTjam",
      "screen_name" : "eltjam",
      "protected" : false,
      "id_str" : "1356363686",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700706017441554432\/vqyiSHTx_normal.png",
      "id" : 1356363686,
      "verified" : false
    }
  },
  "id" : 716195821675495424,
  "created_at" : "2016-04-02 09:29:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "teacherstories",
      "screen_name" : "bee_visible",
      "indices" : [ 3, 15 ],
      "id_str" : "3112144043",
      "id" : 3112144043
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/bee_visible\/status\/715844081625202688\/photo\/1",
      "indices" : [ 122, 140 ],
      "url" : "https:\/\/t.co\/4EC2wcOPb9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ce8wZfaWwAE7Xpx.jpg",
      "id_str" : "715844080262103041",
      "id" : 715844080262103041,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ce8wZfaWwAE7Xpx.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/4EC2wcOPb9"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/yE6DFdxE6G",
      "expanded_url" : "http:\/\/goo.gl\/chfpV6",
      "display_url" : "goo.gl\/chfpV6"
    } ]
  },
  "geo" : { },
  "id_str" : "716194773695070208",
  "text" : "RT @bee_visible: It's Spring! Teacher Story for April: 'Make the Most of Your Days' by Paul Walsh https:\/\/t.co\/yE6DFdxE6G https:\/\/t.co\/4EC2\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/bee_visible\/status\/715844081625202688\/photo\/1",
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/4EC2wcOPb9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ce8wZfaWwAE7Xpx.jpg",
        "id_str" : "715844080262103041",
        "id" : 715844080262103041,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ce8wZfaWwAE7Xpx.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1280,
          "resize" : "fit",
          "w" : 1920
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/4EC2wcOPb9"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/yE6DFdxE6G",
        "expanded_url" : "http:\/\/goo.gl\/chfpV6",
        "display_url" : "goo.gl\/chfpV6"
      } ]
    },
    "geo" : { },
    "id_str" : "715844081625202688",
    "text" : "It's Spring! Teacher Story for April: 'Make the Most of Your Days' by Paul Walsh https:\/\/t.co\/yE6DFdxE6G https:\/\/t.co\/4EC2wcOPb9",
    "id" : 715844081625202688,
    "created_at" : "2016-04-01 10:11:43 +0000",
    "user" : {
      "name" : "teacherstories",
      "screen_name" : "bee_visible",
      "protected" : false,
      "id_str" : "3112144043",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629055941850320901\/kumvict0_normal.png",
      "id" : 3112144043,
      "verified" : false
    }
  },
  "id" : 716194773695070208,
  "created_at" : "2016-04-02 09:25:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "wrestlingneoliberals",
      "screen_name" : "neolib_takedown",
      "indices" : [ 3, 19 ],
      "id_str" : "3437858853",
      "id" : 3437858853
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/neolib_takedown\/status\/716025466424008704\/photo\/1",
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/McubDO9F3W",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ce_VXfhWIAMAglr.jpg",
      "id_str" : "716025465350266883",
      "id" : 716025465350266883,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ce_VXfhWIAMAglr.jpg",
      "sizes" : [ {
        "h" : 233,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 411,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 411,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 411,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/McubDO9F3W"
    } ],
    "hashtags" : [ {
      "text" : "Neoliberalism",
      "indices" : [ 43, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/EtekYb6HC6",
      "expanded_url" : "https:\/\/goo.gl\/ZIcl0K",
      "display_url" : "goo.gl\/ZIcl0K"
    } ]
  },
  "geo" : { },
  "id_str" : "716193072405745664",
  "text" : "RT @neolib_takedown: Simon Springer: \"Fuck #Neoliberalism\" - https:\/\/t.co\/EtekYb6HC6 \n\n 'bout time. https:\/\/t.co\/McubDO9F3W",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/neolib_takedown\/status\/716025466424008704\/photo\/1",
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/McubDO9F3W",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ce_VXfhWIAMAglr.jpg",
        "id_str" : "716025465350266883",
        "id" : 716025465350266883,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ce_VXfhWIAMAglr.jpg",
        "sizes" : [ {
          "h" : 233,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 411,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 411,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 411,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/McubDO9F3W"
      } ],
      "hashtags" : [ {
        "text" : "Neoliberalism",
        "indices" : [ 22, 36 ]
      } ],
      "urls" : [ {
        "indices" : [ 40, 63 ],
        "url" : "https:\/\/t.co\/EtekYb6HC6",
        "expanded_url" : "https:\/\/goo.gl\/ZIcl0K",
        "display_url" : "goo.gl\/ZIcl0K"
      } ]
    },
    "geo" : { },
    "id_str" : "716025466424008704",
    "text" : "Simon Springer: \"Fuck #Neoliberalism\" - https:\/\/t.co\/EtekYb6HC6 \n\n 'bout time. https:\/\/t.co\/McubDO9F3W",
    "id" : 716025466424008704,
    "created_at" : "2016-04-01 22:12:28 +0000",
    "user" : {
      "name" : "wrestlingneoliberals",
      "screen_name" : "neolib_takedown",
      "protected" : false,
      "id_str" : "3437858853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/635797071396798464\/rD8NlTWp_normal.png",
      "id" : 3437858853,
      "verified" : false
    }
  },
  "id" : 716193072405745664,
  "created_at" : "2016-04-02 09:18:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shit Academics Say",
      "screen_name" : "AcademicsSay",
      "indices" : [ 0, 13 ],
      "id_str" : "1891806212",
      "id" : 1891806212
    }, {
      "name" : "Airtasker",
      "screen_name" : "Airtasker",
      "indices" : [ 14, 24 ],
      "id_str" : "364165400",
      "id" : 364165400
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716000882807193604",
  "geo" : { },
  "id_str" : "716002941556105217",
  "in_reply_to_user_id" : 1891806212,
  "text" : "@AcademicsSay @Airtasker such venn diagrams lack academic rigour :0",
  "id" : 716002941556105217,
  "in_reply_to_status_id" : 716000882807193604,
  "created_at" : "2016-04-01 20:42:58 +0000",
  "in_reply_to_screen_name" : "AcademicsSay",
  "in_reply_to_user_id_str" : "1891806212",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Prior",
      "screen_name" : "ConceptCzech",
      "indices" : [ 0, 13 ],
      "id_str" : "256015802",
      "id" : 256015802
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "716000773348454400",
  "geo" : { },
  "id_str" : "716001353420644352",
  "in_reply_to_user_id" : 256015802,
  "text" : "@ConceptCzech neat thx :)",
  "id" : 716001353420644352,
  "in_reply_to_status_id" : 716000773348454400,
  "created_at" : "2016-04-01 20:36:39 +0000",
  "in_reply_to_screen_name" : "ConceptCzech",
  "in_reply_to_user_id_str" : "256015802",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Clare",
      "screen_name" : "languageeteach",
      "indices" : [ 10, 25 ],
      "id_str" : "2163604968",
      "id" : 2163604968
    }, {
      "name" : "Chris Farrell",
      "screen_name" : "ChrisPatrickF",
      "indices" : [ 26, 40 ],
      "id_str" : "3165431237",
      "id" : 3165431237
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715536666203533312",
  "geo" : { },
  "id_str" : "716000916600700928",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava @languageeteach @ChrisPatrickF thanks folks really appreciate the RTs, have a godd w\/e!",
  "id" : 716000916600700928,
  "in_reply_to_status_id" : 715536666203533312,
  "created_at" : "2016-04-01 20:34:55 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Gemma",
      "screen_name" : "GemmaELT",
      "indices" : [ 10, 19 ],
      "id_str" : "3380674715",
      "id" : 3380674715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715536666203533312",
  "geo" : { },
  "id_str" : "715996817591283712",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava @GemmaELT molte grazie Gemma : )",
  "id" : 715996817591283712,
  "in_reply_to_status_id" : 715536666203533312,
  "created_at" : "2016-04-01 20:18:38 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 0, 15 ],
      "id_str" : "285614027",
      "id" : 285614027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715953315071332352",
  "geo" : { },
  "id_str" : "715994707281752065",
  "in_reply_to_user_id" : 285614027,
  "text" : "@AnthonyTeacher ok thx, i think i'll update that post with any interesting stuff i find",
  "id" : 715994707281752065,
  "in_reply_to_status_id" : 715953315071332352,
  "created_at" : "2016-04-01 20:10:15 +0000",
  "in_reply_to_screen_name" : "AnthonyTeacher",
  "in_reply_to_user_id_str" : "285614027",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hana Tich\u00E1",
      "screen_name" : "HanaTicha",
      "indices" : [ 0, 10 ],
      "id_str" : "512296705",
      "id" : 512296705
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715952792893054976",
  "geo" : { },
  "id_str" : "715993173143724032",
  "in_reply_to_user_id" : 512296705,
  "text" : "@HanaTicha thanks Hana enjoy the w\/e : )",
  "id" : 715993173143724032,
  "in_reply_to_status_id" : 715952792893054976,
  "created_at" : "2016-04-01 20:04:09 +0000",
  "in_reply_to_screen_name" : "HanaTicha",
  "in_reply_to_user_id_str" : "512296705",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/yMqRDfBImm",
      "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2016\/04\/keep-calm-and-save-money.html",
      "display_url" : "thecurmudgeonly.blogspot.co.uk\/2016\/04\/keep-c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "715919713906384896",
  "text" : "RT @pchallinor: New mudgeonry: Keep calm and save money https:\/\/t.co\/yMqRDfBImm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 63 ],
        "url" : "https:\/\/t.co\/yMqRDfBImm",
        "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2016\/04\/keep-calm-and-save-money.html",
        "display_url" : "thecurmudgeonly.blogspot.co.uk\/2016\/04\/keep-c\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "715918745198333953",
    "text" : "New mudgeonry: Keep calm and save money https:\/\/t.co\/yMqRDfBImm",
    "id" : 715918745198333953,
    "created_at" : "2016-04-01 15:08:24 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 715919713906384896,
  "created_at" : "2016-04-01 15:12:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexandria Hall",
      "screen_name" : "alxndghall",
      "indices" : [ 3, 14 ],
      "id_str" : "1656929592",
      "id" : 1656929592
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusMOOC",
      "indices" : [ 114, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/7uBhS1pGIu",
      "expanded_url" : "https:\/\/medium.com\/@alxndghall\/women-and-ownership-in-drake-lyrics-32f7fade1dd7#.doekh9562",
      "display_url" : "medium.com\/@alxndghall\/wo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "715909800215846912",
  "text" : "RT @alxndghall: I just published \u201CWomen and Ownership in Drake Lyrics\u201D - would appreciate any insight from fellow #corpusMOOC peeps! https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpusMOOC",
        "indices" : [ 98, 109 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/7uBhS1pGIu",
        "expanded_url" : "https:\/\/medium.com\/@alxndghall\/women-and-ownership-in-drake-lyrics-32f7fade1dd7#.doekh9562",
        "display_url" : "medium.com\/@alxndghall\/wo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "694669436045934592",
    "text" : "I just published \u201CWomen and Ownership in Drake Lyrics\u201D - would appreciate any insight from fellow #corpusMOOC peeps! https:\/\/t.co\/7uBhS1pGIu",
    "id" : 694669436045934592,
    "created_at" : "2016-02-02 23:51:14 +0000",
    "user" : {
      "name" : "Alexandria Hall",
      "screen_name" : "alxndghall",
      "protected" : false,
      "id_str" : "1656929592",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/695730006287253504\/CVIxnOtE_normal.jpg",
      "id" : 1656929592,
      "verified" : false
    }
  },
  "id" : 715909800215846912,
  "created_at" : "2016-04-01 14:32:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715803334209351681",
  "geo" : { },
  "id_str" : "715879002834132992",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler thanks Anne : ) hope you are well",
  "id" : 715879002834132992,
  "in_reply_to_status_id" : 715803334209351681,
  "created_at" : "2016-04-01 12:30:29 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eilidh Singh",
      "screen_name" : "EilidhSingh",
      "indices" : [ 0, 12 ],
      "id_str" : "612776274",
      "id" : 612776274
    }, {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "indices" : [ 13, 25 ],
      "id_str" : "192437743",
      "id" : 192437743
    }, {
      "name" : "Alex Bale",
      "screen_name" : "xelabale",
      "indices" : [ 26, 35 ],
      "id_str" : "594820645",
      "id" : 594820645
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/715688239110164481\/photo\/1",
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/cLq21qmxfr",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Ce6im_nW4AA_1n7.jpg",
      "id_str" : "715688181593726976",
      "id" : 715688181593726976,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Ce6im_nW4AA_1n7.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/cLq21qmxfr"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715673347384737792",
  "geo" : { },
  "id_str" : "715688239110164481",
  "in_reply_to_user_id" : 612776274,
  "text" : "@EilidhSingh @nathanghall @xelabale more like other other stuff... https:\/\/t.co\/cLq21qmxfr",
  "id" : 715688239110164481,
  "in_reply_to_status_id" : 715673347384737792,
  "created_at" : "2016-03-31 23:52:27 +0000",
  "in_reply_to_screen_name" : "EilidhSingh",
  "in_reply_to_user_id_str" : "612776274",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Galiza Contrainfo",
      "screen_name" : "gzcontrainfo",
      "indices" : [ 3, 16 ],
      "id_str" : "1443730357",
      "id" : 1443730357
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/gzcontrainfo\/status\/715617993619800064\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/zoHVIZtz57",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ce5iwnqWQAAfyQY.jpg",
      "id_str" : "715617978218332160",
      "id" : 715617978218332160,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ce5iwnqWQAAfyQY.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/zoHVIZtz57"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/gzcontrainfo\/status\/715617993619800064\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/zoHVIZtz57",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ce5iwnsW4AAgKz6.jpg",
      "id_str" : "715617978226761728",
      "id" : 715617978226761728,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ce5iwnsW4AAgKz6.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 529,
        "resize" : "fit",
        "w" : 940
      }, {
        "h" : 529,
        "resize" : "fit",
        "w" : 940
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/zoHVIZtz57"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/gzcontrainfo\/status\/715617993619800064\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/zoHVIZtz57",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ce5iwnrWEAI2ke-.jpg",
      "id_str" : "715617978222514178",
      "id" : 715617978222514178,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ce5iwnrWEAI2ke-.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 398,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/zoHVIZtz57"
    } ],
    "hashtags" : [ {
      "text" : "NuitDebout",
      "indices" : [ 122, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "715685744518496256",
  "text" : "RT @gzcontrainfo: Hoxe en Francia houbo 1folga xeral contra reforma laboral.Emoci\u00F3n por aquilo dParis \u00E9 m\u00E1xico,e pq agora #NuitDebout https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/gzcontrainfo\/status\/715617993619800064\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/zoHVIZtz57",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ce5iwnqWQAAfyQY.jpg",
        "id_str" : "715617978218332160",
        "id" : 715617978218332160,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ce5iwnqWQAAfyQY.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/zoHVIZtz57"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/gzcontrainfo\/status\/715617993619800064\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/zoHVIZtz57",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ce5iwnsW4AAgKz6.jpg",
        "id_str" : "715617978226761728",
        "id" : 715617978226761728,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ce5iwnsW4AAgKz6.jpg",
        "sizes" : [ {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 529,
          "resize" : "fit",
          "w" : 940
        }, {
          "h" : 529,
          "resize" : "fit",
          "w" : 940
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/zoHVIZtz57"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/gzcontrainfo\/status\/715617993619800064\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/zoHVIZtz57",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ce5iwnrWEAI2ke-.jpg",
        "id_str" : "715617978222514178",
        "id" : 715617978222514178,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ce5iwnrWEAI2ke-.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 398,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/zoHVIZtz57"
      } ],
      "hashtags" : [ {
        "text" : "NuitDebout",
        "indices" : [ 104, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "715617993619800064",
    "text" : "Hoxe en Francia houbo 1folga xeral contra reforma laboral.Emoci\u00F3n por aquilo dParis \u00E9 m\u00E1xico,e pq agora #NuitDebout https:\/\/t.co\/zoHVIZtz57",
    "id" : 715617993619800064,
    "created_at" : "2016-03-31 19:13:19 +0000",
    "user" : {
      "name" : "Galiza Contrainfo",
      "screen_name" : "gzcontrainfo",
      "protected" : false,
      "id_str" : "1443730357",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3686617419\/69592617839178d79a4552d447eaab4f_normal.jpeg",
      "id" : 1443730357,
      "verified" : false
    }
  },
  "id" : 715685744518496256,
  "created_at" : "2016-03-31 23:42:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charreando",
      "screen_name" : "vergman_",
      "indices" : [ 3, 12 ],
      "id_str" : "301193111",
      "id" : 301193111
    }, {
      "name" : "peoplewitness",
      "screen_name" : "PeopleWitness",
      "indices" : [ 68, 82 ],
      "id_str" : "484271579",
      "id" : 484271579
    }, {
      "name" : "WITNESS ES",
      "screen_name" : "witness_es",
      "indices" : [ 83, 94 ],
      "id_str" : "2912843536",
      "id" : 2912843536
    }, {
      "name" : "(((Occupy Wall St)))",
      "screen_name" : "OccupyWallStNYC",
      "indices" : [ 95, 111 ],
      "id_str" : "335972576",
      "id" : 335972576
    }, {
      "name" : "#OccupyLA",
      "screen_name" : "OccupyLA",
      "indices" : [ 112, 121 ],
      "id_str" : "377220892",
      "id" : 377220892
    }, {
      "name" : "#YoSoy132",
      "screen_name" : "Soy132MX",
      "indices" : [ 122, 131 ],
      "id_str" : "586102874",
      "id" : 586102874
    }, {
      "name" : "Blockupy",
      "screen_name" : "Blockupy",
      "indices" : [ 132, 140 ],
      "id_str" : "544317327",
      "id" : 544317327
    }, {
      "name" : "Umbrella Revolution",
      "screen_name" : "UmbrellaRev",
      "indices" : [ 139, 140 ],
      "id_str" : "2835465798",
      "id" : 2835465798
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NuitDebout",
      "indices" : [ 56, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/SccjWD0gnR",
      "expanded_url" : "http:\/\/bambuser.com\/v\/6187610?v=m",
      "display_url" : "bambuser.com\/v\/6187610?v=m"
    } ]
  },
  "geo" : { },
  "id_str" : "715684387820580864",
  "text" : "RT @vergman_: LIVE from France.\nhttps:\/\/t.co\/SccjWD0gnR\n#NuitDebout\n@PeopleWitness @witness_es @OccupyWallStNYC @OccupyLA @Soy132MX @Blocku\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "peoplewitness",
        "screen_name" : "PeopleWitness",
        "indices" : [ 54, 68 ],
        "id_str" : "484271579",
        "id" : 484271579
      }, {
        "name" : "WITNESS ES",
        "screen_name" : "witness_es",
        "indices" : [ 69, 80 ],
        "id_str" : "2912843536",
        "id" : 2912843536
      }, {
        "name" : "(((Occupy Wall St)))",
        "screen_name" : "OccupyWallStNYC",
        "indices" : [ 81, 97 ],
        "id_str" : "335972576",
        "id" : 335972576
      }, {
        "name" : "#OccupyLA",
        "screen_name" : "OccupyLA",
        "indices" : [ 98, 107 ],
        "id_str" : "377220892",
        "id" : 377220892
      }, {
        "name" : "#YoSoy132",
        "screen_name" : "Soy132MX",
        "indices" : [ 108, 117 ],
        "id_str" : "586102874",
        "id" : 586102874
      }, {
        "name" : "Blockupy",
        "screen_name" : "Blockupy",
        "indices" : [ 118, 127 ],
        "id_str" : "544317327",
        "id" : 544317327
      }, {
        "name" : "Umbrella Revolution",
        "screen_name" : "UmbrellaRev",
        "indices" : [ 128, 140 ],
        "id_str" : "2835465798",
        "id" : 2835465798
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NuitDebout",
        "indices" : [ 42, 53 ]
      } ],
      "urls" : [ {
        "indices" : [ 18, 41 ],
        "url" : "https:\/\/t.co\/SccjWD0gnR",
        "expanded_url" : "http:\/\/bambuser.com\/v\/6187610?v=m",
        "display_url" : "bambuser.com\/v\/6187610?v=m"
      } ]
    },
    "geo" : { },
    "id_str" : "715682999669547008",
    "text" : "LIVE from France.\nhttps:\/\/t.co\/SccjWD0gnR\n#NuitDebout\n@PeopleWitness @witness_es @OccupyWallStNYC @OccupyLA @Soy132MX @Blockupy @UmbrellaRev",
    "id" : 715682999669547008,
    "created_at" : "2016-03-31 23:31:38 +0000",
    "user" : {
      "name" : "Charreando",
      "screen_name" : "vergman_",
      "protected" : false,
      "id_str" : "301193111",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/649937200004661249\/KMpUqssl_normal.jpg",
      "id" : 301193111,
      "verified" : false
    }
  },
  "id" : 715684387820580864,
  "created_at" : "2016-03-31 23:37:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Guillaume Desagulier",
      "screen_name" : "gdlinguist",
      "indices" : [ 0, 11 ],
      "id_str" : "4901184795",
      "id" : 4901184795
    }, {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 12, 28 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    }, {
      "name" : "umasslinguistics",
      "screen_name" : "umasslinguistic",
      "indices" : [ 29, 45 ],
      "id_str" : "149239362",
      "id" : 149239362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/okvXGyXX8C",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=TY71XcBJXaA",
      "display_url" : "youtube.com\/watch?v=TY71Xc\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "715632766671523840",
  "geo" : { },
  "id_str" : "715675511679283201",
  "in_reply_to_user_id" : 4901184795,
  "text" : "@gdlinguist @getgreatenglish @umasslinguistic this series looks useful https:\/\/t.co\/okvXGyXX8C e.g. origin of word yankee",
  "id" : 715675511679283201,
  "in_reply_to_status_id" : 715632766671523840,
  "created_at" : "2016-03-31 23:01:53 +0000",
  "in_reply_to_screen_name" : "gdlinguist",
  "in_reply_to_user_id_str" : "4901184795",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "indices" : [ 0, 12 ],
      "id_str" : "192437743",
      "id" : 192437743
    }, {
      "name" : "Eilidh Singh",
      "screen_name" : "EilidhSingh",
      "indices" : [ 13, 25 ],
      "id_str" : "612776274",
      "id" : 612776274
    }, {
      "name" : "Alex Bale",
      "screen_name" : "xelabale",
      "indices" : [ 26, 35 ],
      "id_str" : "594820645",
      "id" : 594820645
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/715668738192896000\/photo\/1",
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/ktOQpwbaK3",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Ce6Q5B7WAAA5K_W.jpg",
      "id_str" : "715668700242771968",
      "id" : 715668700242771968,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Ce6Q5B7WAAA5K_W.jpg",
      "sizes" : [ {
        "h" : 234,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 234,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 160,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 234,
        "resize" : "fit",
        "w" : 498
      } ],
      "display_url" : "pic.twitter.com\/ktOQpwbaK3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "715666894821281793",
  "geo" : { },
  "id_str" : "715668738192896000",
  "in_reply_to_user_id" : 192437743,
  "text" : "@nathanghall @EilidhSingh @xelabale this thread is wierdly poetic https:\/\/t.co\/ktOQpwbaK3",
  "id" : 715668738192896000,
  "in_reply_to_status_id" : 715666894821281793,
  "created_at" : "2016-03-31 22:34:58 +0000",
  "in_reply_to_screen_name" : "nathanghall",
  "in_reply_to_user_id_str" : "192437743",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Guillaume Desagulier",
      "screen_name" : "gdlinguist",
      "indices" : [ 0, 11 ],
      "id_str" : "4901184795",
      "id" : 4901184795
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/715665543576088576\/photo\/1",
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/KHZjOHxlo4",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Ce6N80_WsAE-LGw.jpg",
      "id_str" : "715665466954526721",
      "id" : 715665466954526721,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Ce6N80_WsAE-LGw.jpg",
      "sizes" : [ {
        "h" : 360,
        "resize" : "fit",
        "w" : 356
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 356
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 356
      }, {
        "h" : 344,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/KHZjOHxlo4"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/sZbI4Xu28a",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=Q-B_ONJIEcE&feature=youtu.be&t=14m8s",
      "display_url" : "youtube.com\/watch?v=Q-B_ON\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "715632766671523840",
  "geo" : { },
  "id_str" : "715665543576088576",
  "in_reply_to_user_id" : 4901184795,
  "text" : "@gdlinguist &lt;&lt;brute force association&gt;&gt; https:\/\/t.co\/sZbI4Xu28a https:\/\/t.co\/KHZjOHxlo4",
  "id" : 715665543576088576,
  "in_reply_to_status_id" : 715632766671523840,
  "created_at" : "2016-03-31 22:22:16 +0000",
  "in_reply_to_screen_name" : "gdlinguist",
  "in_reply_to_user_id_str" : "4901184795",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hippoedtech",
      "screen_name" : "hippoedtech",
      "indices" : [ 0, 12 ],
      "id_str" : "713345621650980864",
      "id" : 713345621650980864
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/OXgbvtUSGO",
      "expanded_url" : "http:\/\/www.usefulscience.org\/",
      "display_url" : "usefulscience.org"
    } ]
  },
  "in_reply_to_status_id_str" : "715641282002071561",
  "geo" : { },
  "id_str" : "715660873860268032",
  "in_reply_to_user_id" : 18602422,
  "text" : "@hippoedtech this site could be useful with your activity https:\/\/t.co\/OXgbvtUSGO",
  "id" : 715660873860268032,
  "in_reply_to_status_id" : 715641282002071561,
  "created_at" : "2016-03-31 22:03:43 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
} ]