Grailbird.data.tweets_2013_09 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "384737122894086145",
  "geo" : { },
  "id_str" : "384745534533033984",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco ooh that would be great :) be happy to help out",
  "id" : 384745534533033984,
  "in_reply_to_status_id" : 384737122894086145,
  "created_at" : "2013-09-30 18:24:18 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 3, 14 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELT",
      "indices" : [ 34, 38 ]
    }, {
      "text" : "ELTChat",
      "indices" : [ 111, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "https:\/\/t.co\/KFhslmleQ4",
      "expanded_url" : "https:\/\/sites.google.com\/site\/sketchengineforeslteachers\/home",
      "display_url" : "sites.google.com\/site\/sketcheng\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384736493052252162",
  "text" : "RT @lexicoloco: Sketch Engine for #ELT teachers. A good guide to getting started with corpus in the classroom. #ELTChat https:\/\/t.co\/KFhslm\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELT",
        "indices" : [ 18, 22 ]
      }, {
        "text" : "ELTChat",
        "indices" : [ 95, 103 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/KFhslmleQ4",
        "expanded_url" : "https:\/\/sites.google.com\/site\/sketchengineforeslteachers\/home",
        "display_url" : "sites.google.com\/site\/sketcheng\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "384680612172296192",
    "text" : "Sketch Engine for #ELT teachers. A good guide to getting started with corpus in the classroom. #ELTChat https:\/\/t.co\/KFhslmleQ4",
    "id" : 384680612172296192,
    "created_at" : "2013-09-30 14:06:19 +0000",
    "user" : {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "protected" : false,
      "id_str" : "300734173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2403500097\/3nmx3kjaycyoc7irwe6s_normal.jpeg",
      "id" : 300734173,
      "verified" : false
    }
  },
  "id" : 384736493052252162,
  "created_at" : "2013-09-30 17:48:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "381825758680739840",
  "geo" : { },
  "id_str" : "384736408134381570",
  "in_reply_to_user_id" : 18602422,
  "text" : "@lexicoloco thanks for RT, and sounds like good trend u report about corpora and classrooms, will u blog about LCR2013 conf?",
  "id" : 384736408134381570,
  "in_reply_to_status_id" : 381825758680739840,
  "created_at" : "2013-09-30 17:48:02 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ken Lackman",
      "screen_name" : "kenlackman",
      "indices" : [ 3, 14 ],
      "id_str" : "114929243",
      "id" : 114929243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/RYdiSy56oU",
      "expanded_url" : "http:\/\/kenlackmanblog.com\/",
      "display_url" : "kenlackmanblog.com"
    } ]
  },
  "geo" : { },
  "id_str" : "384561501345832960",
  "text" : "RT @kenlackman: My monthly newsletter is now a blog! Don't take bad jokes, made-up words and general maluse of English. Fight back! http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/RYdiSy56oU",
        "expanded_url" : "http:\/\/kenlackmanblog.com\/",
        "display_url" : "kenlackmanblog.com"
      } ]
    },
    "geo" : { },
    "id_str" : "384513080773726208",
    "text" : "My monthly newsletter is now a blog! Don't take bad jokes, made-up words and general maluse of English. Fight back! http:\/\/t.co\/RYdiSy56oU",
    "id" : 384513080773726208,
    "created_at" : "2013-09-30 03:00:37 +0000",
    "user" : {
      "name" : "Ken Lackman",
      "screen_name" : "kenlackman",
      "protected" : false,
      "id_str" : "114929243",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/905973143\/28544_1453786830459_1406967041_31269075_7840251_n_normal.jpg",
      "id" : 114929243,
      "verified" : false
    }
  },
  "id" : 384561501345832960,
  "created_at" : "2013-09-30 06:13:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "4TUNE Teller App",
      "screen_name" : "4tunetellernet",
      "indices" : [ 0, 15 ],
      "id_str" : "467634146",
      "id" : 467634146
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/o8WyYxYwFI",
      "expanded_url" : "http:\/\/accessmaincomputerfile.net\/image\/1137935505",
      "display_url" : "accessmaincomputerfile.net\/image\/11379355\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "384436880382500864",
  "geo" : { },
  "id_str" : "384438364989968384",
  "in_reply_to_user_id" : 467634146,
  "text" : "@4tunetellernet lol! perhaps you need to say the magic words? :) http:\/\/t.co\/o8WyYxYwFI",
  "id" : 384438364989968384,
  "in_reply_to_status_id" : 384436880382500864,
  "created_at" : "2013-09-29 22:03:43 +0000",
  "in_reply_to_screen_name" : "4tunetellernet",
  "in_reply_to_user_id_str" : "467634146",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 70, 86 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/X2KdIZxafd",
      "expanded_url" : "http:\/\/wp.me\/pglsT-4iN",
      "display_url" : "wp.me\/pglsT-4iN"
    } ]
  },
  "geo" : { },
  "id_str" : "384409463274229760",
  "text" : "The writer automaton by Pierre Jaquet-Droz http:\/\/t.co\/X2KdIZxafd via @wordpressdotcom",
  "id" : 384409463274229760,
  "created_at" : "2013-09-29 20:08:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Whyte",
      "screen_name" : "eslwriter",
      "indices" : [ 3, 13 ],
      "id_str" : "187481025",
      "id" : 187481025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/aIbJtIFy9W",
      "expanded_url" : "http:\/\/www.scribd.com\/doc\/166002160\/ESL-Trivia-Challenge-Volume-1",
      "display_url" : "scribd.com\/doc\/166002160\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384267519537594368",
  "text" : "RT @eslwriter: ESL Trivia Challenge Volume 1. The classroom game that gets students talking and learning. http:\/\/t.co\/aIbJtIFy9W",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/aIbJtIFy9W",
        "expanded_url" : "http:\/\/www.scribd.com\/doc\/166002160\/ESL-Trivia-Challenge-Volume-1",
        "display_url" : "scribd.com\/doc\/166002160\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "384263802553778176",
    "text" : "ESL Trivia Challenge Volume 1. The classroom game that gets students talking and learning. http:\/\/t.co\/aIbJtIFy9W",
    "id" : 384263802553778176,
    "created_at" : "2013-09-29 10:30:04 +0000",
    "user" : {
      "name" : "Rob Whyte",
      "screen_name" : "eslwriter",
      "protected" : false,
      "id_str" : "187481025",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2682332531\/cd44653e5843c08c6938f41dc15668bc_normal.png",
      "id" : 187481025,
      "verified" : false
    }
  },
  "id" : 384267519537594368,
  "created_at" : "2013-09-29 10:44:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/I6A1DoxvGb",
      "expanded_url" : "http:\/\/eflnotes.wordpress.com\/my-english-language-teacher\/",
      "display_url" : "eflnotes.wordpress.com\/my-english-lan\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383975959059107840",
  "text" : "Just realized the reason my English teacher and I don't get along is because she's a crazy cat lady and I love dogs. http:\/\/t.co\/I6A1DoxvGb",
  "id" : 383975959059107840,
  "created_at" : "2013-09-28 15:26:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dale Coulter",
      "screen_name" : "dalecoulter",
      "indices" : [ 0, 12 ],
      "id_str" : "24046458",
      "id" : 24046458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "383929801310240768",
  "geo" : { },
  "id_str" : "383956077147992064",
  "in_reply_to_user_id" : 24046458,
  "text" : "@dalecoulter a pleasure, some things not thought about re simulations vs role plays thx",
  "id" : 383956077147992064,
  "in_reply_to_status_id" : 383929801310240768,
  "created_at" : "2013-09-28 14:07:17 +0000",
  "in_reply_to_screen_name" : "dalecoulter",
  "in_reply_to_user_id_str" : "24046458",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Willingham",
      "screen_name" : "DTWillingham",
      "indices" : [ 3, 16 ],
      "id_str" : "84619537",
      "id" : 84619537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/kOE6c8TzdU",
      "expanded_url" : "http:\/\/www.immagic.com\/eLibrary\/ARCHIVES\/GENERAL\/NBER_US\/N100611F.pdf",
      "display_url" : "immagic.com\/eLibrary\/ARCHI\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383919931835703296",
  "text" : "RT @DTWillingham: RCT claiming \"modest\" benefit to live lecture vs. internet video in college course http:\/\/t.co\/kOE6c8TzdU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/kOE6c8TzdU",
        "expanded_url" : "http:\/\/www.immagic.com\/eLibrary\/ARCHIVES\/GENERAL\/NBER_US\/N100611F.pdf",
        "display_url" : "immagic.com\/eLibrary\/ARCHI\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "383627411960524800",
    "text" : "RCT claiming \"modest\" benefit to live lecture vs. internet video in college course http:\/\/t.co\/kOE6c8TzdU",
    "id" : 383627411960524800,
    "created_at" : "2013-09-27 16:21:17 +0000",
    "user" : {
      "name" : "Daniel Willingham",
      "screen_name" : "DTWillingham",
      "protected" : false,
      "id_str" : "84619537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1815678310\/Daniel_Willingham_Color_lowres_normal.JPG",
      "id" : 84619537,
      "verified" : false
    }
  },
  "id" : 383919931835703296,
  "created_at" : "2013-09-28 11:43:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dale Coulter",
      "screen_name" : "dalecoulter",
      "indices" : [ 3, 15 ],
      "id_str" : "24046458",
      "id" : 24046458
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coaching",
      "indices" : [ 104, 113 ]
    }, {
      "text" : "elt",
      "indices" : [ 114, 118 ]
    }, {
      "text" : "businessenglish",
      "indices" : [ 119, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/pbCjSKuIVZ",
      "expanded_url" : "http:\/\/dalecoulter.wordpress.com\/2013\/09\/28\/effecting-simulations\/",
      "display_url" : "dalecoulter.wordpress.com\/2013\/09\/28\/eff\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383880720633962496",
  "text" : "RT @dalecoulter: http:\/\/t.co\/pbCjSKuIVZ Business trainers, take a look. Would appreciate your feedback! #coaching #elt #businessenglish",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "coaching",
        "indices" : [ 87, 96 ]
      }, {
        "text" : "elt",
        "indices" : [ 97, 101 ]
      }, {
        "text" : "businessenglish",
        "indices" : [ 102, 118 ]
      } ],
      "urls" : [ {
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/pbCjSKuIVZ",
        "expanded_url" : "http:\/\/dalecoulter.wordpress.com\/2013\/09\/28\/effecting-simulations\/",
        "display_url" : "dalecoulter.wordpress.com\/2013\/09\/28\/eff\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "383853012352897024",
    "text" : "http:\/\/t.co\/pbCjSKuIVZ Business trainers, take a look. Would appreciate your feedback! #coaching #elt #businessenglish",
    "id" : 383853012352897024,
    "created_at" : "2013-09-28 07:17:44 +0000",
    "user" : {
      "name" : "Dale Coulter",
      "screen_name" : "dalecoulter",
      "protected" : false,
      "id_str" : "24046458",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528209583752220673\/ZlqajEJk_normal.jpeg",
      "id" : 24046458,
      "verified" : false
    }
  },
  "id" : 383880720633962496,
  "created_at" : "2013-09-28 09:07:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "williamjturkel",
      "screen_name" : "williamjturkel",
      "indices" : [ 0, 15 ],
      "id_str" : "9280142",
      "id" : 9280142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "383763141554757632",
  "geo" : { },
  "id_str" : "383765645944307712",
  "in_reply_to_user_id" : 9280142,
  "text" : "@williamjturkel thanks! okay for beginners?",
  "id" : 383765645944307712,
  "in_reply_to_status_id" : 383763141554757632,
  "created_at" : "2013-09-28 01:30:34 +0000",
  "in_reply_to_screen_name" : "williamjturkel",
  "in_reply_to_user_id_str" : "9280142",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "williamjturkel",
      "screen_name" : "williamjturkel",
      "indices" : [ 0, 15 ],
      "id_str" : "9280142",
      "id" : 9280142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/LSr7ChGeLQ",
      "expanded_url" : "https:\/\/plus.google.com\/104940199413423400545\/posts\/TawexsWtgC4",
      "display_url" : "plus.google.com\/10494019941342\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383760769919111168",
  "in_reply_to_user_id" : 9280142,
  "text" : "@williamjturkel hi any chance u could give this a once over; written fr beginner regex users https:\/\/t.co\/LSr7ChGeLQ thanks in advance :)",
  "id" : 383760769919111168,
  "created_at" : "2013-09-28 01:11:12 +0000",
  "in_reply_to_screen_name" : "williamjturkel",
  "in_reply_to_user_id_str" : "9280142",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "indices" : [ 0, 12 ],
      "id_str" : "192437743",
      "id" : 192437743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "383691738646208512",
  "geo" : { },
  "id_str" : "383728389162418177",
  "in_reply_to_user_id" : 192437743,
  "text" : "@nathanghall yr welcome :) i liked yr takeaway points",
  "id" : 383728389162418177,
  "in_reply_to_status_id" : 383691738646208512,
  "created_at" : "2013-09-27 23:02:31 +0000",
  "in_reply_to_screen_name" : "nathanghall",
  "in_reply_to_user_id_str" : "192437743",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 89, 97 ]
    }, {
      "text" : "corpuslinguistics",
      "indices" : [ 98, 116 ]
    }, {
      "text" : "tefl",
      "indices" : [ 117, 122 ]
    }, {
      "text" : "tesol",
      "indices" : [ 123, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/LSr7ChGeLQ",
      "expanded_url" : "https:\/\/plus.google.com\/104940199413423400545\/posts\/TawexsWtgC4",
      "display_url" : "plus.google.com\/10494019941342\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383722704831926273",
  "text" : "Wrangling regular expressions and commandeering the command line https:\/\/t.co\/LSr7ChGeLQ #eltchat #corpuslinguistics #tefl #tesol",
  "id" : 383722704831926273,
  "created_at" : "2013-09-27 22:39:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wendell the Wizard",
      "screen_name" : "wendellwizard",
      "indices" : [ 3, 17 ],
      "id_str" : "1504673636",
      "id" : 1504673636
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wizardchat",
      "indices" : [ 122, 133 ]
    }, {
      "text" : "wizbiz",
      "indices" : [ 134, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383692468803211265",
  "text" : "RT @wendellwizard: Apparently the Menswear sign means Mens Wear and not Men Swear. I wish I had known that ahead of time. #wizardchat #wizb\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "wizardchat",
        "indices" : [ 103, 114 ]
      }, {
        "text" : "wizbiz",
        "indices" : [ 115, 122 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "383689567527632896",
    "text" : "Apparently the Menswear sign means Mens Wear and not Men Swear. I wish I had known that ahead of time. #wizardchat #wizbiz",
    "id" : 383689567527632896,
    "created_at" : "2013-09-27 20:28:16 +0000",
    "user" : {
      "name" : "Wendell the Wizard",
      "screen_name" : "wendellwizard",
      "protected" : false,
      "id_str" : "1504673636",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000771023514\/ef32eddcedcad7b5df806b35c7cf5142_normal.png",
      "id" : 1504673636,
      "verified" : false
    }
  },
  "id" : 383692468803211265,
  "created_at" : "2013-09-27 20:39:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "indices" : [ 37, 49 ],
      "id_str" : "192437743",
      "id" : 192437743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/QRcHl9NEpv",
      "expanded_url" : "http:\/\/wp.me\/p3xFPk-5c",
      "display_url" : "wp.me\/p3xFPk-5c"
    } ]
  },
  "geo" : { },
  "id_str" : "383687384270790656",
  "text" : "Lecturing http:\/\/t.co\/QRcHl9NEpv via @nathanghall",
  "id" : 383687384270790656,
  "created_at" : "2013-09-27 20:19:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "natiserhost197",
      "screen_name" : "esl_robert",
      "indices" : [ 0, 11 ],
      "id_str" : "2982357761",
      "id" : 2982357761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/5HVxk4F4IY",
      "expanded_url" : "https:\/\/plus.google.com\/communities\/101266284417587206243",
      "display_url" : "plus.google.com\/communities\/10\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "383656265924096000",
  "geo" : { },
  "id_str" : "383657233331933184",
  "in_reply_to_user_id" : 18526186,
  "text" : "@esl_robert glad to help :) please consider joining google+ corpus linguistics and lang teaching\/learning community https:\/\/t.co\/5HVxk4F4IY",
  "id" : 383657233331933184,
  "in_reply_to_status_id" : 383656265924096000,
  "created_at" : "2013-09-27 18:19:47 +0000",
  "in_reply_to_screen_name" : "RobertEPoole",
  "in_reply_to_user_id_str" : "18526186",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "natiserhost197",
      "screen_name" : "esl_robert",
      "indices" : [ 0, 11 ],
      "id_str" : "2982357761",
      "id" : 2982357761
    }, {
      "name" : "Paper Machines",
      "screen_name" : "PaperMachines",
      "indices" : [ 26, 40 ],
      "id_str" : "1160911620",
      "id" : 1160911620
    }, {
      "name" : "Zotero",
      "screen_name" : "zotero",
      "indices" : [ 51, 58 ],
      "id_str" : "9893772",
      "id" : 9893772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/VrmGJzUFhQ",
      "expanded_url" : "http:\/\/eflnotes.wordpress.com\/2013\/05\/21\/paper-machines-look-ma-no-concordance-lines\/",
      "display_url" : "eflnotes.wordpress.com\/2013\/05\/21\/pap\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "383641336118669315",
  "geo" : { },
  "id_str" : "383642965928734721",
  "in_reply_to_user_id" : 18526186,
  "text" : "@esl_robert i wrote about @PaperMachines addon for @zotero http:\/\/t.co\/VrmGJzUFhQ",
  "id" : 383642965928734721,
  "in_reply_to_status_id" : 383641336118669315,
  "created_at" : "2013-09-27 17:23:05 +0000",
  "in_reply_to_screen_name" : "RobertEPoole",
  "in_reply_to_user_id_str" : "18526186",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike S. Boyle",
      "screen_name" : "heyboyle",
      "indices" : [ 0, 9 ],
      "id_str" : "612840231",
      "id" : 612840231
    }, {
      "name" : "Jordi Mar\u00EDn Badenes",
      "screen_name" : "JordiMarinBa",
      "indices" : [ 10, 23 ],
      "id_str" : "228720772",
      "id" : 228720772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "383629005372403713",
  "geo" : { },
  "id_str" : "383630682636820480",
  "in_reply_to_user_id" : 612840231,
  "text" : "@heyboyle @JordiMarinBa u know if the recording be made available at some point?",
  "id" : 383630682636820480,
  "in_reply_to_status_id" : 383629005372403713,
  "created_at" : "2013-09-27 16:34:16 +0000",
  "in_reply_to_screen_name" : "heyboyle",
  "in_reply_to_user_id_str" : "612840231",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Patsko",
      "screen_name" : "lauraahaha",
      "indices" : [ 3, 14 ],
      "id_str" : "97957137",
      "id" : 97957137
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/o7wWib0nw3",
      "expanded_url" : "http:\/\/wp.me\/p2VnAo-7KsSw",
      "display_url" : "wp.me\/p2VnAo-7KsSw"
    } ]
  },
  "geo" : { },
  "id_str" : "383630434111737856",
  "text" : "RT @lauraahaha: IATEFL Poland presentation: Integrating pronunciation http:\/\/t.co\/o7wWib0nw3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 76 ],
        "url" : "http:\/\/t.co\/o7wWib0nw3",
        "expanded_url" : "http:\/\/wp.me\/p2VnAo-7KsSw",
        "display_url" : "wp.me\/p2VnAo-7KsSw"
      } ]
    },
    "geo" : { },
    "id_str" : "383627649358528512",
    "text" : "IATEFL Poland presentation: Integrating pronunciation http:\/\/t.co\/o7wWib0nw3",
    "id" : 383627649358528512,
    "created_at" : "2013-09-27 16:22:13 +0000",
    "user" : {
      "name" : "Laura Patsko",
      "screen_name" : "lauraahaha",
      "protected" : false,
      "id_str" : "97957137",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/659005852477714432\/xfuJsW6q_normal.jpg",
      "id" : 97957137,
      "verified" : false
    }
  },
  "id" : 383630434111737856,
  "created_at" : "2013-09-27 16:33:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bethany Cagnol",
      "screen_name" : "bethcagnol",
      "indices" : [ 0, 11 ],
      "id_str" : "27641720",
      "id" : 27641720
    }, {
      "name" : "Ela Wassell",
      "screen_name" : "elawassell",
      "indices" : [ 12, 23 ],
      "id_str" : "51157050",
      "id" : 51157050
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFLPL",
      "indices" : [ 40, 49 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "383605300441272320",
  "geo" : { },
  "id_str" : "383612912050270208",
  "in_reply_to_user_id" : 27641720,
  "text" : "@bethcagnol @elawassell good job ela :) #IATEFLPL",
  "id" : 383612912050270208,
  "in_reply_to_status_id" : 383605300441272320,
  "created_at" : "2013-09-27 15:23:40 +0000",
  "in_reply_to_screen_name" : "bethcagnol",
  "in_reply_to_user_id_str" : "27641720",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Yau",
      "screen_name" : "flowingdata",
      "indices" : [ 3, 15 ],
      "id_str" : "14109167",
      "id" : 14109167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/I0GlUi1uU6",
      "expanded_url" : "http:\/\/flowingdata.com\/2013\/09\/27\/science-fiction-starships-an-extensive-size-comparison\/",
      "display_url" : "flowingdata.com\/2013\/09\/27\/sci\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383611373504040960",
  "text" : "RT @flowingdata: Science fiction starships, an extensive size comparison http:\/\/t.co\/I0GlUi1uU6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/flowingdata.com\" rel=\"nofollow\"\u003EFlowingData\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/I0GlUi1uU6",
        "expanded_url" : "http:\/\/flowingdata.com\/2013\/09\/27\/science-fiction-starships-an-extensive-size-comparison\/",
        "display_url" : "flowingdata.com\/2013\/09\/27\/sci\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "383522739858202624",
    "text" : "Science fiction starships, an extensive size comparison http:\/\/t.co\/I0GlUi1uU6",
    "id" : 383522739858202624,
    "created_at" : "2013-09-27 09:25:21 +0000",
    "user" : {
      "name" : "Nathan Yau",
      "screen_name" : "flowingdata",
      "protected" : false,
      "id_str" : "14109167",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/585826994526355456\/R3tYT5Kj_normal.png",
      "id" : 14109167,
      "verified" : false
    }
  },
  "id" : 383611373504040960,
  "created_at" : "2013-09-27 15:17:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oliver Mason",
      "screen_name" : "ojmason",
      "indices" : [ 3, 11 ],
      "id_str" : "19781877",
      "id" : 19781877
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/ojmason\/status\/383244642818326528\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/e859ffjwcL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BVGO-NXCYAAhab_.png",
      "id_str" : "383244642692521984",
      "id" : 383244642692521984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BVGO-NXCYAAhab_.png",
      "sizes" : [ {
        "h" : 83,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 126,
        "resize" : "fit",
        "w" : 518
      }, {
        "h" : 126,
        "resize" : "fit",
        "w" : 518
      }, {
        "h" : 126,
        "resize" : "crop",
        "w" : 126
      }, {
        "h" : 126,
        "resize" : "fit",
        "w" : 518
      } ],
      "display_url" : "pic.twitter.com\/e859ffjwcL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383281330022125568",
  "text" : "RT @ojmason: Oh LinkedIn, you're so naughty. Or: even little words are very important, sometimes. (Almost SFW) http:\/\/t.co\/e859ffjwcL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ojmason\/status\/383244642818326528\/photo\/1",
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/e859ffjwcL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BVGO-NXCYAAhab_.png",
        "id_str" : "383244642692521984",
        "id" : 383244642692521984,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BVGO-NXCYAAhab_.png",
        "sizes" : [ {
          "h" : 83,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 126,
          "resize" : "fit",
          "w" : 518
        }, {
          "h" : 126,
          "resize" : "fit",
          "w" : 518
        }, {
          "h" : 126,
          "resize" : "crop",
          "w" : 126
        }, {
          "h" : 126,
          "resize" : "fit",
          "w" : 518
        } ],
        "display_url" : "pic.twitter.com\/e859ffjwcL"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "383244642818326528",
    "text" : "Oh LinkedIn, you're so naughty. Or: even little words are very important, sometimes. (Almost SFW) http:\/\/t.co\/e859ffjwcL",
    "id" : 383244642818326528,
    "created_at" : "2013-09-26 15:00:17 +0000",
    "user" : {
      "name" : "Oliver Mason",
      "screen_name" : "ojmason",
      "protected" : false,
      "id_str" : "19781877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/74227368\/Photo_30_normal.jpg",
      "id" : 19781877,
      "verified" : false
    }
  },
  "id" : 383281330022125568,
  "created_at" : "2013-09-26 17:26:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/I6A1DoxvGb",
      "expanded_url" : "http:\/\/eflnotes.wordpress.com\/my-english-language-teacher\/",
      "display_url" : "eflnotes.wordpress.com\/my-english-lan\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383211705527836672",
  "text" : "\"It could be\" Marque de fabrique de la prof d'anglais. http:\/\/t.co\/I6A1DoxvGb",
  "id" : 383211705527836672,
  "created_at" : "2013-09-26 12:49:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Howard",
      "screen_name" : "skattyadz",
      "indices" : [ 3, 13 ],
      "id_str" : "4675238256",
      "id" : 4675238256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/Fp5u0S9gbo",
      "expanded_url" : "http:\/\/gist.io\/6710863",
      "display_url" : "gist.io\/6710863"
    } ]
  },
  "geo" : { },
  "id_str" : "383176373608521728",
  "text" : "RT @skattyadz: I just wrote a quick explanation of how I understand the one-electron theory (trust me, it\u2019s fun) http:\/\/t.co\/Fp5u0S9gbo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/Fp5u0S9gbo",
        "expanded_url" : "http:\/\/gist.io\/6710863",
        "display_url" : "gist.io\/6710863"
      } ]
    },
    "geo" : { },
    "id_str" : "383131286157946880",
    "text" : "I just wrote a quick explanation of how I understand the one-electron theory (trust me, it\u2019s fun) http:\/\/t.co\/Fp5u0S9gbo",
    "id" : 383131286157946880,
    "created_at" : "2013-09-26 07:29:51 +0000",
    "user" : {
      "name" : "Adam Howard",
      "screen_name" : "codeincontext",
      "protected" : false,
      "id_str" : "22433482",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/592818482770751489\/h6WQ90X-_normal.jpg",
      "id" : 22433482,
      "verified" : false
    }
  },
  "id" : 383176373608521728,
  "created_at" : "2013-09-26 10:29:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Costas Gabrielatos",
      "screen_name" : "congabonga",
      "indices" : [ 0, 11 ],
      "id_str" : "187484412",
      "id" : 187484412
    }, {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 12, 23 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "383169196084846592",
  "geo" : { },
  "id_str" : "383170740159131648",
  "in_reply_to_user_id" : 187484412,
  "text" : "@congabonga @lexicoloco great :)",
  "id" : 383170740159131648,
  "in_reply_to_status_id" : 383169196084846592,
  "created_at" : "2013-09-26 10:06:38 +0000",
  "in_reply_to_screen_name" : "congabonga",
  "in_reply_to_user_id_str" : "187484412",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "383166691599204352",
  "geo" : { },
  "id_str" : "383170433798766592",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco thanks!",
  "id" : 383170433798766592,
  "in_reply_to_status_id" : 383166691599204352,
  "created_at" : "2013-09-26 10:05:25 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "383155475963187200",
  "geo" : { },
  "id_str" : "383156144983646208",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco look fwd to report, have fun :)",
  "id" : 383156144983646208,
  "in_reply_to_status_id" : 383155475963187200,
  "created_at" : "2013-09-26 09:08:38 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpuslinguistics",
      "indices" : [ 65, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "383155753428590592",
  "text" : "Q to corpus folk is there a easy way to compare 2 keyword lists? #corpuslinguistics",
  "id" : 383155753428590592,
  "created_at" : "2013-09-26 09:07:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/lSKM0QTVbF",
      "expanded_url" : "http:\/\/johnhilley.blogspot.co.uk\/2013\/09\/miliband-and-mesmerised-media-no-energy.html",
      "display_url" : "johnhilley.blogspot.co.uk\/2013\/09\/miliba\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382978019997929472",
  "text" : "RT @johnwhilley: Miliband and mesmerised media - no energy for real change  http:\/\/t.co\/lSKM0QTVbF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/lSKM0QTVbF",
        "expanded_url" : "http:\/\/johnhilley.blogspot.co.uk\/2013\/09\/miliband-and-mesmerised-media-no-energy.html",
        "display_url" : "johnhilley.blogspot.co.uk\/2013\/09\/miliba\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "382877635426000899",
    "text" : "Miliband and mesmerised media - no energy for real change  http:\/\/t.co\/lSKM0QTVbF",
    "id" : 382877635426000899,
    "created_at" : "2013-09-25 14:41:56 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 382978019997929472,
  "created_at" : "2013-09-25 21:20:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 0, 8 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "382960295301222400",
  "text" : "#eltchat here but lurking",
  "id" : 382960295301222400,
  "created_at" : "2013-09-25 20:10:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yolanda B. Schell",
      "screen_name" : "mattellman",
      "indices" : [ 0, 11 ],
      "id_str" : "725597315860434945",
      "id" : 725597315860434945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382937473506361344",
  "geo" : { },
  "id_str" : "382948254310100992",
  "in_reply_to_user_id" : 394987109,
  "text" : "@mattellman thanks for sharing matthew, hope to see u there :)",
  "id" : 382948254310100992,
  "in_reply_to_status_id" : 382937473506361344,
  "created_at" : "2013-09-25 19:22:33 +0000",
  "in_reply_to_screen_name" : "MatthewEllman",
  "in_reply_to_user_id_str" : "394987109",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "indices" : [ 29, 41 ],
      "id_str" : "849729062",
      "id" : 849729062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 136, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/P2d57aGiX7",
      "expanded_url" : "https:\/\/plus.google.com\/104940199413423400545\/posts\/gY6paiboKG2",
      "display_url" : "plus.google.com\/10494019941342\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382927734499848192",
  "text" : "while u r waiting for the UK @TonyMcEnery online corpora course-&gt;&gt; do a corpora course from a Spanish uni https:\/\/t.co\/P2d57aGiX7 #eltchat",
  "id" : 382927734499848192,
  "created_at" : "2013-09-25 18:01:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382860912853409794",
  "geo" : { },
  "id_str" : "382861706608656384",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin ha! :) in a nutshell, i c what u did there",
  "id" : 382861706608656384,
  "in_reply_to_status_id" : 382860912853409794,
  "created_at" : "2013-09-25 13:38:38 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/yFxbQEcPUy",
      "expanded_url" : "http:\/\/theteachingfactor.wordpress.com\/2013\/09\/25\/transition-graveyard-transitional-words-phrases\/",
      "display_url" : "theteachingfactor.wordpress.com\/2013\/09\/25\/tra\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "382845811983257601",
  "geo" : { },
  "id_str" : "382859801551581184",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin nice idea :) on a similar tip http:\/\/t.co\/yFxbQEcPUy",
  "id" : 382859801551581184,
  "in_reply_to_status_id" : 382845811983257601,
  "created_at" : "2013-09-25 13:31:04 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 3, 14 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/d4SJeeqR1Q",
      "expanded_url" : "http:\/\/bit.ly\/16HHAoD",
      "display_url" : "bit.ly\/16HHAoD"
    } ]
  },
  "geo" : { },
  "id_str" : "382804100888268801",
  "text" : "RT @tornhalves: The Ken Robinson \"revolution\" - all boardrooms, no barricades. What about democracy, Ken? http:\/\/t.co\/d4SJeeqR1Q",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/d4SJeeqR1Q",
        "expanded_url" : "http:\/\/bit.ly\/16HHAoD",
        "display_url" : "bit.ly\/16HHAoD"
      } ]
    },
    "geo" : { },
    "id_str" : "382801546099970048",
    "text" : "The Ken Robinson \"revolution\" - all boardrooms, no barricades. What about democracy, Ken? http:\/\/t.co\/d4SJeeqR1Q",
    "id" : 382801546099970048,
    "created_at" : "2013-09-25 09:39:35 +0000",
    "user" : {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "protected" : false,
      "id_str" : "87902543",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3059742703\/1d3c7a2052db17d29644fa0a49af6480_normal.jpeg",
      "id" : 87902543,
      "verified" : false
    }
  },
  "id" : 382804100888268801,
  "created_at" : "2013-09-25 09:49:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Seymour",
      "screen_name" : "leninology",
      "indices" : [ 0, 11 ],
      "id_str" : "15557246",
      "id" : 15557246
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382638156899966977",
  "geo" : { },
  "id_str" : "382758950090702848",
  "in_reply_to_user_id" : 15557246,
  "text" : "@leninology Seymour back on form, hitting it where it hurts :)",
  "id" : 382758950090702848,
  "in_reply_to_status_id" : 382638156899966977,
  "created_at" : "2013-09-25 06:50:19 +0000",
  "in_reply_to_screen_name" : "leninology",
  "in_reply_to_user_id_str" : "15557246",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Seymour",
      "screen_name" : "leninology",
      "indices" : [ 3, 14 ],
      "id_str" : "15557246",
      "id" : 15557246
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/BXsmspaUZN",
      "expanded_url" : "http:\/\/www.leninology.com\/2013\/09\/that-niqab-debate-in-full.html",
      "display_url" : "leninology.com\/2013\/09\/that-n\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382758147758096384",
  "text" : "RT @leninology: The 'niqab debate' in full. http:\/\/t.co\/BXsmspaUZN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 28, 50 ],
        "url" : "http:\/\/t.co\/BXsmspaUZN",
        "expanded_url" : "http:\/\/www.leninology.com\/2013\/09\/that-niqab-debate-in-full.html",
        "display_url" : "leninology.com\/2013\/09\/that-n\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "382638156899966977",
    "text" : "The 'niqab debate' in full. http:\/\/t.co\/BXsmspaUZN",
    "id" : 382638156899966977,
    "created_at" : "2013-09-24 22:50:20 +0000",
    "user" : {
      "name" : "Richard Seymour",
      "screen_name" : "leninology",
      "protected" : false,
      "id_str" : "15557246",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762344914583781377\/UDn8tMrp_normal.jpg",
      "id" : 15557246,
      "verified" : false
    }
  },
  "id" : 382758147758096384,
  "created_at" : "2013-09-25 06:47:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ellensclass",
      "screen_name" : "ellensclass",
      "indices" : [ 3, 15 ],
      "id_str" : "451058137",
      "id" : 451058137
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/jQHOpqKppp",
      "expanded_url" : "http:\/\/wp.me\/p3KAlG-am",
      "display_url" : "wp.me\/p3KAlG-am"
    } ]
  },
  "geo" : { },
  "id_str" : "382756439225159681",
  "text" : "RT @ellensclass: UN News Centre http:\/\/t.co\/jQHOpqKppp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 15, 37 ],
        "url" : "http:\/\/t.co\/jQHOpqKppp",
        "expanded_url" : "http:\/\/wp.me\/p3KAlG-am",
        "display_url" : "wp.me\/p3KAlG-am"
      } ]
    },
    "geo" : { },
    "id_str" : "382644047040761856",
    "text" : "UN News Centre http:\/\/t.co\/jQHOpqKppp",
    "id" : 382644047040761856,
    "created_at" : "2013-09-24 23:13:44 +0000",
    "user" : {
      "name" : "ellensclass",
      "screen_name" : "ellensclass",
      "protected" : false,
      "id_str" : "451058137",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1724689649\/NYThatWay_normal.jpg",
      "id" : 451058137,
      "verified" : false
    }
  },
  "id" : 382756439225159681,
  "created_at" : "2013-09-25 06:40:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/PGyP1unM5e",
      "expanded_url" : "http:\/\/quietlyamused.org\/blog\/2013\/09\/08\/a-great-language-update\/",
      "display_url" : "quietlyamused.org\/blog\/2013\/09\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382632779655024644",
  "text" : "A great language game update http:\/\/t.co\/PGyP1unM5e",
  "id" : 382632779655024644,
  "created_at" : "2013-09-24 22:28:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen Doll",
      "screen_name" : "thisisjendoll",
      "indices" : [ 0, 14 ],
      "id_str" : "46442771",
      "id" : 46442771
    }, {
      "name" : "Angus B Grieve-Smith",
      "screen_name" : "grvsmth",
      "indices" : [ 15, 23 ],
      "id_str" : "22381639",
      "id" : 22381639
    }, {
      "name" : "Gothamist",
      "screen_name" : "Gothamist",
      "indices" : [ 24, 34 ],
      "id_str" : "810424",
      "id" : 810424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382504921788317696",
  "geo" : { },
  "id_str" : "382618462708699136",
  "in_reply_to_user_id" : 46442771,
  "text" : "@thisisjendoll @grvsmth @Gothamist ye gods! that surely hearlds the coming burgedonne!",
  "id" : 382618462708699136,
  "in_reply_to_status_id" : 382504921788317696,
  "created_at" : "2013-09-24 21:32:04 +0000",
  "in_reply_to_screen_name" : "thisisjendoll",
  "in_reply_to_user_id_str" : "46442771",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Fogarty",
      "screen_name" : "fogarty22",
      "indices" : [ 0, 10 ],
      "id_str" : "261562133",
      "id" : 261562133
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382615055319441408",
  "geo" : { },
  "id_str" : "382615362933518337",
  "in_reply_to_user_id" : 261562133,
  "text" : "@fogarty22 ha! :) an aptly (mis)named product it seems",
  "id" : 382615362933518337,
  "in_reply_to_status_id" : 382615055319441408,
  "created_at" : "2013-09-24 21:19:45 +0000",
  "in_reply_to_screen_name" : "fogarty22",
  "in_reply_to_user_id_str" : "261562133",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Fogarty",
      "screen_name" : "fogarty22",
      "indices" : [ 0, 10 ],
      "id_str" : "261562133",
      "id" : 261562133
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/382614837873750016\/photo\/1",
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/DAINcB0i1N",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BU9SKvmCMAEgKAx.jpg",
      "id_str" : "382614837877944321",
      "id" : 382614837877944321,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BU9SKvmCMAEgKAx.jpg",
      "sizes" : [ {
        "h" : 363,
        "resize" : "fit",
        "w" : 454
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 363,
        "resize" : "fit",
        "w" : 454
      }, {
        "h" : 272,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 363,
        "resize" : "fit",
        "w" : 454
      } ],
      "display_url" : "pic.twitter.com\/DAINcB0i1N"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382613128540073984",
  "geo" : { },
  "id_str" : "382614837873750016",
  "in_reply_to_user_id" : 261562133,
  "text" : "@fogarty22 - sorry cld not resist :) http:\/\/t.co\/DAINcB0i1N",
  "id" : 382614837873750016,
  "in_reply_to_status_id" : 382613128540073984,
  "created_at" : "2013-09-24 21:17:40 +0000",
  "in_reply_to_screen_name" : "fogarty22",
  "in_reply_to_user_id_str" : "261562133",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 39, 55 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/Gws3ZHuv7V",
      "expanded_url" : "http:\/\/wp.me\/p3jU8R-3c",
      "display_url" : "wp.me\/p3jU8R-3c"
    } ]
  },
  "geo" : { },
  "id_str" : "382605557531549696",
  "text" : "Pilgrimages http:\/\/t.co\/Gws3ZHuv7V via @wordpressdotcom",
  "id" : 382605557531549696,
  "created_at" : "2013-09-24 20:40:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382586403181191168",
  "geo" : { },
  "id_str" : "382599149259984896",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco brill! hoping u can share your experiences of corpora with the group :)",
  "id" : 382599149259984896,
  "in_reply_to_status_id" : 382586403181191168,
  "created_at" : "2013-09-24 20:15:20 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 141 ],
      "url" : "https:\/\/t.co\/5HVxk4F4IY",
      "expanded_url" : "https:\/\/plus.google.com\/communities\/101266284417587206243",
      "display_url" : "plus.google.com\/communities\/10\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382584963805089792",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco thanks fr share diane :) if u use google+ please consider joining the CL &amp; lang teach\/learn community https:\/\/t.co\/5HVxk4F4IY",
  "id" : 382584963805089792,
  "created_at" : "2013-09-24 19:18:58 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 69, 77 ]
    }, {
      "text" : "tesol",
      "indices" : [ 78, 84 ]
    }, {
      "text" : "efl",
      "indices" : [ 85, 89 ]
    }, {
      "text" : "tefl",
      "indices" : [ 90, 95 ]
    }, {
      "text" : "corpuslinguistics",
      "indices" : [ 96, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/WGeTOs7TPA",
      "expanded_url" : "https:\/\/plus.google.com\/104940199413423400545\/posts\/9YMcBaGEPai",
      "display_url" : "plus.google.com\/10494019941342\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382563758658183169",
  "text" : "A snapshot of how I work with concordances - https:\/\/t.co\/WGeTOs7TPA #eltchat #tesol #efl #tefl #corpuslinguistics",
  "id" : 382563758658183169,
  "created_at" : "2013-09-24 17:54:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 104, 120 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/YUtllS2ls7",
      "expanded_url" : "http:\/\/wp.me\/pjaNC-12g",
      "display_url" : "wp.me\/pjaNC-12g"
    } ]
  },
  "geo" : { },
  "id_str" : "382541702306619393",
  "text" : "Oh, Wow! Creating a Buzz about Filler Words, Interjections, and Onomatopoeia http:\/\/t.co\/YUtllS2ls7 via @wordpressdotcom",
  "id" : 382541702306619393,
  "created_at" : "2013-09-24 16:27:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oxford ELT",
      "screen_name" : "OUPELTGlobal",
      "indices" : [ 0, 13 ],
      "id_str" : "74177226",
      "id" : 74177226
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382525037812523008",
  "geo" : { },
  "id_str" : "382539448157630464",
  "in_reply_to_user_id" : 74177226,
  "text" : "@OUPELTGlobal chrome os and chromebook glaring omission",
  "id" : 382539448157630464,
  "in_reply_to_status_id" : 382525037812523008,
  "created_at" : "2013-09-24 16:18:06 +0000",
  "in_reply_to_screen_name" : "OUPELTGlobal",
  "in_reply_to_user_id_str" : "74177226",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 91, 107 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/PQ3L9bmI20",
      "expanded_url" : "http:\/\/wp.me\/p32IOl-bZ",
      "display_url" : "wp.me\/p32IOl-bZ"
    } ]
  },
  "geo" : { },
  "id_str" : "382397857430372352",
  "text" : "Gizoogle: Amusing tribute or racist caricature? - NSFW (part 1) http:\/\/t.co\/PQ3L9bmI20 via @wordpressdotcom",
  "id" : 382397857430372352,
  "created_at" : "2013-09-24 06:55:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carissa Peck",
      "screen_name" : "eslcarissa",
      "indices" : [ 0, 11 ],
      "id_str" : "62313854",
      "id" : 62313854
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "382277015602073600",
  "geo" : { },
  "id_str" : "382391673617010688",
  "in_reply_to_user_id" : 62313854,
  "text" : "@eslcarissa sweet glowbe certainly rocks :)",
  "id" : 382391673617010688,
  "in_reply_to_status_id" : 382277015602073600,
  "created_at" : "2013-09-24 06:30:54 +0000",
  "in_reply_to_screen_name" : "eslcarissa",
  "in_reply_to_user_id_str" : "62313854",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Douglas S. Bigham",
      "screen_name" : "dsbigham",
      "indices" : [ 3, 12 ],
      "id_str" : "107616673",
      "id" : 107616673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/OxeAbVBzOF",
      "expanded_url" : "http:\/\/tmblr.co\/ZOhn7yvq_MZB",
      "display_url" : "tmblr.co\/ZOhn7yvq_MZB"
    } ]
  },
  "geo" : { },
  "id_str" : "382267205074690049",
  "text" : "RT @dsbigham: Come on, everybody! Let's go a-linguisting!\nEpisode 6a: Morphology\u2026 http:\/\/t.co\/OxeAbVBzOF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/OxeAbVBzOF",
        "expanded_url" : "http:\/\/tmblr.co\/ZOhn7yvq_MZB",
        "display_url" : "tmblr.co\/ZOhn7yvq_MZB"
      } ]
    },
    "geo" : { },
    "id_str" : "382255303817179136",
    "text" : "Come on, everybody! Let's go a-linguisting!\nEpisode 6a: Morphology\u2026 http:\/\/t.co\/OxeAbVBzOF",
    "id" : 382255303817179136,
    "created_at" : "2013-09-23 21:29:01 +0000",
    "user" : {
      "name" : "Douglas S. Bigham",
      "screen_name" : "dsbigham",
      "protected" : false,
      "id_str" : "107616673",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/474980696205688832\/ex_n4uVL_normal.jpeg",
      "id" : 107616673,
      "verified" : false
    }
  },
  "id" : 382267205074690049,
  "created_at" : "2013-09-23 22:16:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Pride",
      "screen_name" : "ThomasPride",
      "indices" : [ 3, 15 ],
      "id_str" : "385867551",
      "id" : 385867551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/Z8jJ3TtNta",
      "expanded_url" : "http:\/\/tompride.co.uk\/how-atos-is-taking-over-the-nhs-by-stealth-under-a-different-name",
      "display_url" : "tompride.co.uk\/how-atos-is-ta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382248461006929920",
  "text" : "RT @ThomasPride: How ATOS is taking over the NHS by stealth - under a different name: http:\/\/t.co\/Z8jJ3TtNta \u2026 \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/Z8jJ3TtNta",
        "expanded_url" : "http:\/\/tompride.co.uk\/how-atos-is-taking-over-the-nhs-by-stealth-under-a-different-name",
        "display_url" : "tompride.co.uk\/how-atos-is-ta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "382220421870788608",
    "text" : "How ATOS is taking over the NHS by stealth - under a different name: http:\/\/t.co\/Z8jJ3TtNta \u2026 \u2026",
    "id" : 382220421870788608,
    "created_at" : "2013-09-23 19:10:24 +0000",
    "user" : {
      "name" : "Tom Pride",
      "screen_name" : "ThomasPride",
      "protected" : false,
      "id_str" : "385867551",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1575665066\/tom-pride_normal.png",
      "id" : 385867551,
      "verified" : false
    }
  },
  "id" : 382248461006929920,
  "created_at" : "2013-09-23 21:01:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chia Suan Chong",
      "screen_name" : "chiasuan",
      "indices" : [ 0, 9 ],
      "id_str" : "71588589",
      "id" : 71588589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/k4U72OGVEO",
      "expanded_url" : "http:\/\/corpus2.byu.edu\/glowbe\/?c=glowbe&q=25310309",
      "display_url" : "corpus2.byu.edu\/glowbe\/?c=glow\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "382230682023768064",
  "geo" : { },
  "id_str" : "382231847876325376",
  "in_reply_to_user_id" : 71588589,
  "text" : "@chiasuan Glowbe give some info e.g. http:\/\/t.co\/k4U72OGVEO",
  "id" : 382231847876325376,
  "in_reply_to_status_id" : 382230682023768064,
  "created_at" : "2013-09-23 19:55:48 +0000",
  "in_reply_to_screen_name" : "chiasuan",
  "in_reply_to_user_id_str" : "71588589",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/I6A1DoxvGb",
      "expanded_url" : "http:\/\/eflnotes.wordpress.com\/my-english-language-teacher\/",
      "display_url" : "eflnotes.wordpress.com\/my-english-lan\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382114385516171265",
  "text" : "My English teacher wants me to talk with British accent http:\/\/t.co\/I6A1DoxvGb",
  "id" : 382114385516171265,
  "created_at" : "2013-09-23 12:09:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angus B Grieve-Smith",
      "screen_name" : "grvsmth",
      "indices" : [ 3, 11 ],
      "id_str" : "22381639",
      "id" : 22381639
    }, {
      "name" : "Emily Brewster",
      "screen_name" : "eabrewster",
      "indices" : [ 134, 144 ],
      "id_str" : "164707981",
      "id" : 164707981
    }, {
      "name" : "Stan Carey",
      "screen_name" : "StanCarey",
      "indices" : [ 143, 144 ],
      "id_str" : "34347535",
      "id" : 34347535
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/HnhmosNFOa",
      "expanded_url" : "http:\/\/grieve-smith.com\/blog\/2013\/09\/the-power-of-forgetfulness\/",
      "display_url" : "grieve-smith.com\/blog\/2013\/09\/t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "382063843389628416",
  "text" : "RT @grvsmth: New post: How did we get \"snuck?\" It's the power of forgetfulness! http:\/\/t.co\/HnhmosNFOa feat. Bybee &amp; Slobin 1982, @eabrewst\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Emily Brewster",
        "screen_name" : "eabrewster",
        "indices" : [ 121, 132 ],
        "id_str" : "164707981",
        "id" : 164707981
      }, {
        "name" : "Stan Carey",
        "screen_name" : "StanCarey",
        "indices" : [ 133, 143 ],
        "id_str" : "34347535",
        "id" : 34347535
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/HnhmosNFOa",
        "expanded_url" : "http:\/\/grieve-smith.com\/blog\/2013\/09\/the-power-of-forgetfulness\/",
        "display_url" : "grieve-smith.com\/blog\/2013\/09\/t\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "381983893634555904",
    "text" : "New post: How did we get \"snuck?\" It's the power of forgetfulness! http:\/\/t.co\/HnhmosNFOa feat. Bybee &amp; Slobin 1982, @eabrewster @StanCarey",
    "id" : 381983893634555904,
    "created_at" : "2013-09-23 03:30:31 +0000",
    "user" : {
      "name" : "Angus B Grieve-Smith",
      "screen_name" : "grvsmth",
      "protected" : false,
      "id_str" : "22381639",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/94827231\/portrait_normal.png",
      "id" : 22381639,
      "verified" : false
    }
  },
  "id" : 382063843389628416,
  "created_at" : "2013-09-23 08:48:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Corpuslinguistics",
      "indices" : [ 18, 36 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 98, 106 ]
    }, {
      "text" : "tesol",
      "indices" : [ 107, 113 ]
    }, {
      "text" : "efl",
      "indices" : [ 114, 118 ]
    }, {
      "text" : "esl",
      "indices" : [ 119, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/gnEFqIwmh8",
      "expanded_url" : "https:\/\/plus.google.com\/u\/0\/communities\/101266284417587206243",
      "display_url" : "plus.google.com\/u\/0\/communitie\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381825758680739840",
  "text" : "new Google+ group #Corpuslinguistics and language teaching &amp; learning https:\/\/t.co\/gnEFqIwmh8 #eltchat #tesol #efl #esl",
  "id" : 381825758680739840,
  "created_at" : "2013-09-22 17:02:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/I6A1DoxvGb",
      "expanded_url" : "http:\/\/eflnotes.wordpress.com\/my-english-language-teacher\/",
      "display_url" : "eflnotes.wordpress.com\/my-english-lan\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381761153409376257",
  "text" : "My english teacher needs an english teacher. http:\/\/t.co\/I6A1DoxvGb",
  "id" : 381761153409376257,
  "created_at" : "2013-09-22 12:45:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShareThis",
      "screen_name" : "ShareThis",
      "indices" : [ 75, 85 ],
      "id_str" : "14116807",
      "id" : 14116807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/lo90lMehRb",
      "expanded_url" : "http:\/\/www.jonathan-cook.net\/blog\/2013-09-21\/israeli-guns-pointed-at-diplomats-in-quarrel\/#sthash.Inin8XKm.uxfs",
      "display_url" : "jonathan-cook.net\/blog\/2013-09-2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381757392301481984",
  "text" : "Israeli guns pointed at diplomats in 'quarrel'  http:\/\/t.co\/lo90lMehRb via @sharethis",
  "id" : 381757392301481984,
  "created_at" : "2013-09-22 12:30:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041F\u0430\u043B\u044C\u0433\u043E\u0432a \u042E\u043B\u0438\u044F",
      "screen_name" : "andypeters10",
      "indices" : [ 0, 13 ],
      "id_str" : "2815424089",
      "id" : 2815424089
    }, {
      "name" : "Angus B Grieve-Smith",
      "screen_name" : "grvsmth",
      "indices" : [ 14, 22 ],
      "id_str" : "22381639",
      "id" : 22381639
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/381753720456753152\/photo\/1",
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/EoUuumzsoC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BUxC_HPCMAEM039.jpg",
      "id_str" : "381753720460947457",
      "id" : 381753720460947457,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BUxC_HPCMAEM039.jpg",
      "sizes" : [ {
        "h" : 179,
        "resize" : "fit",
        "w" : 181
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 179,
        "resize" : "fit",
        "w" : 181
      }, {
        "h" : 179,
        "resize" : "fit",
        "w" : 181
      }, {
        "h" : 179,
        "resize" : "fit",
        "w" : 181
      } ],
      "display_url" : "pic.twitter.com\/EoUuumzsoC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "381320151163224064",
  "geo" : { },
  "id_str" : "381753720456753152",
  "in_reply_to_user_id" : 217944609,
  "text" : "@andypeters10 @grvsmth Otto approves this joke http:\/\/t.co\/EoUuumzsoC",
  "id" : 381753720456753152,
  "in_reply_to_status_id" : 381320151163224064,
  "created_at" : "2013-09-22 12:15:54 +0000",
  "in_reply_to_screen_name" : "andy_p10",
  "in_reply_to_user_id_str" : "217944609",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Phipps",
      "screen_name" : "lousylinguist",
      "indices" : [ 3, 17 ],
      "id_str" : "48459936",
      "id" : 48459936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "381711474462162944",
  "text" : "RT @lousylinguist: \"extraordinary\" and \"extra ordinary\" mean the opposite. Hmmm...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "381509390324359168",
    "text" : "\"extraordinary\" and \"extra ordinary\" mean the opposite. Hmmm...",
    "id" : 381509390324359168,
    "created_at" : "2013-09-21 20:05:01 +0000",
    "user" : {
      "name" : "Christopher Phipps",
      "screen_name" : "lousylinguist",
      "protected" : false,
      "id_str" : "48459936",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750789987113660416\/2IPugaM9_normal.jpg",
      "id" : 48459936,
      "verified" : false
    }
  },
  "id" : 381711474462162944,
  "created_at" : "2013-09-22 09:28:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Brindle",
      "screen_name" : "AndrewBrindle2",
      "indices" : [ 35, 50 ],
      "id_str" : "358143205",
      "id" : 358143205
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/ae2XPrAox1",
      "expanded_url" : "http:\/\/tagcrowd.com\/",
      "display_url" : "tagcrowd.com"
    } ]
  },
  "geo" : { },
  "id_str" : "381707309740609537",
  "text" : "TagCrowd http:\/\/t.co\/ae2XPrAox1 HT @AndrewBrindle2 ; allows file upload and web page url works compared to wordle",
  "id" : 381707309740609537,
  "created_at" : "2013-09-22 09:11:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Bogost",
      "screen_name" : "ibogost",
      "indices" : [ 3, 11 ],
      "id_str" : "6825792",
      "id" : 6825792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/wefeFKZLIv",
      "expanded_url" : "http:\/\/writing-program.uchicago.edu\/toys\/randomsentence\/write-sentence.htm",
      "display_url" : "writing-program.uchicago.edu\/toys\/randomsen\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381426177438531585",
  "text" : "RT @ibogost: Write your own academic sentence. http:\/\/t.co\/wefeFKZLIv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 34, 56 ],
        "url" : "http:\/\/t.co\/wefeFKZLIv",
        "expanded_url" : "http:\/\/writing-program.uchicago.edu\/toys\/randomsentence\/write-sentence.htm",
        "display_url" : "writing-program.uchicago.edu\/toys\/randomsen\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "381423095661494272",
    "text" : "Write your own academic sentence. http:\/\/t.co\/wefeFKZLIv",
    "id" : 381423095661494272,
    "created_at" : "2013-09-21 14:22:07 +0000",
    "user" : {
      "name" : "Ian Bogost",
      "screen_name" : "ibogost",
      "protected" : false,
      "id_str" : "6825792",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/677930477752193025\/DUdmOVVK_normal.jpg",
      "id" : 6825792,
      "verified" : true
    }
  },
  "id" : 381426177438531585,
  "created_at" : "2013-09-21 14:34:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Akira Murakami",
      "screen_name" : "mrkm_a",
      "indices" : [ 1, 8 ],
      "id_str" : "116922669",
      "id" : 116922669
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "381353403248422912",
  "geo" : { },
  "id_str" : "381398361934290945",
  "in_reply_to_user_id" : 116922669,
  "text" : ".@mrkm_a nice to see Chanier calling out the non public domain, non reuse, non remix of corpus like ICLE",
  "id" : 381398361934290945,
  "in_reply_to_status_id" : 381353403248422912,
  "created_at" : "2013-09-21 12:43:50 +0000",
  "in_reply_to_screen_name" : "mrkm_a",
  "in_reply_to_user_id_str" : "116922669",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/PHgKH4JGsB",
      "expanded_url" : "http:\/\/twxplorer.knightlab.com\/",
      "display_url" : "twxplorer.knightlab.com"
    } ]
  },
  "geo" : { },
  "id_str" : "381150186380091392",
  "text" : "http:\/\/t.co\/PHgKH4JGsB - getting to be my fav new twitter tool",
  "id" : 381150186380091392,
  "created_at" : "2013-09-20 20:17:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "edulang",
      "screen_name" : "edulang",
      "indices" : [ 3, 11 ],
      "id_str" : "2877002950",
      "id" : 2877002950
    }, {
      "name" : "ELTNEWS Editor",
      "screen_name" : "elt_news",
      "indices" : [ 70, 79 ],
      "id_str" : "471725733",
      "id" : 471725733
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/PiopCAUurR",
      "expanded_url" : "http:\/\/www.eltnews.com\/news\/archives\/2013\/09\/can_english_students_discover_their_inner_tom_hanks.html",
      "display_url" : "eltnews.com\/news\/archives\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381105755849363456",
  "text" : "RT @Edulang: Can English students discover their inner Tom Hanks? by (@elt_news): http:\/\/t.co\/PiopCAUurR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ELTNEWS Editor",
        "screen_name" : "elt_news",
        "indices" : [ 57, 66 ],
        "id_str" : "471725733",
        "id" : 471725733
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/PiopCAUurR",
        "expanded_url" : "http:\/\/www.eltnews.com\/news\/archives\/2013\/09\/can_english_students_discover_their_inner_tom_hanks.html",
        "display_url" : "eltnews.com\/news\/archives\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "381103160007217153",
    "text" : "Can English students discover their inner Tom Hanks? by (@elt_news): http:\/\/t.co\/PiopCAUurR",
    "id" : 381103160007217153,
    "created_at" : "2013-09-20 17:10:48 +0000",
    "user" : {
      "name" : "WordTov",
      "screen_name" : "wordtov",
      "protected" : false,
      "id_str" : "236921161",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/612985595749617664\/YMxtQC1g_normal.png",
      "id" : 236921161,
      "verified" : false
    }
  },
  "id" : 381105755849363456,
  "created_at" : "2013-09-20 17:21:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/uFpBKJ1zJ7",
      "expanded_url" : "http:\/\/ow.ly\/p0C3L",
      "display_url" : "ow.ly\/p0C3L"
    } ]
  },
  "geo" : { },
  "id_str" : "381060786770046976",
  "text" : "RT @medialens: Media Alert: \u2018Damning Evidence\u2019 Becomes \u2018No Clear Evidence\u2019: Much-Delayed Report On Iraq Congenital Birth Defects http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/uFpBKJ1zJ7",
        "expanded_url" : "http:\/\/ow.ly\/p0C3L",
        "display_url" : "ow.ly\/p0C3L"
      } ]
    },
    "geo" : { },
    "id_str" : "380986507223261184",
    "text" : "Media Alert: \u2018Damning Evidence\u2019 Becomes \u2018No Clear Evidence\u2019: Much-Delayed Report On Iraq Congenital Birth Defects http:\/\/t.co\/uFpBKJ1zJ7",
    "id" : 380986507223261184,
    "created_at" : "2013-09-20 09:27:16 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 381060786770046976,
  "created_at" : "2013-09-20 14:22:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Bunyan",
      "screen_name" : "bunyanchris",
      "indices" : [ 0, 12 ],
      "id_str" : "237402639",
      "id" : 237402639
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "381053321794301952",
  "geo" : { },
  "id_str" : "381057903555141632",
  "in_reply_to_user_id" : 237402639,
  "text" : "@bunyanchris thanks have a great w\/e! \\0\/",
  "id" : 381057903555141632,
  "in_reply_to_status_id" : 381053321794301952,
  "created_at" : "2013-09-20 14:10:58 +0000",
  "in_reply_to_screen_name" : "bunyanchris",
  "in_reply_to_user_id_str" : "237402639",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/XK8M4AEbQM",
      "expanded_url" : "http:\/\/johnpilger.com\/articles\/in-an-age-of-realists-and-vigilantes-there-is-cause-for-optimism",
      "display_url" : "johnpilger.com\/articles\/in-an\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "381054780249894912",
  "text" : "In an age of 'realists' and vigilantes, there is cause for optimism - http:\/\/t.co\/XK8M4AEbQM",
  "id" : 381054780249894912,
  "created_at" : "2013-09-20 13:58:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Bunyan",
      "screen_name" : "bunyanchris",
      "indices" : [ 0, 12 ],
      "id_str" : "237402639",
      "id" : 237402639
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380947520882737152",
  "geo" : { },
  "id_str" : "380992592327888896",
  "in_reply_to_user_id" : 237402639,
  "text" : "@bunyanchris thanks v much for share chris :)",
  "id" : 380992592327888896,
  "in_reply_to_status_id" : 380947520882737152,
  "created_at" : "2013-09-20 09:51:27 +0000",
  "in_reply_to_screen_name" : "bunyanchris",
  "in_reply_to_user_id_str" : "237402639",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jo Sayers",
      "screen_name" : "jo_sayers",
      "indices" : [ 0, 10 ],
      "id_str" : "87176766",
      "id" : 87176766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380966294314418176",
  "geo" : { },
  "id_str" : "380992459523641345",
  "in_reply_to_user_id" : 87176766,
  "text" : "@jo_sayers cheers amigo , thanks for RT :)",
  "id" : 380992459523641345,
  "in_reply_to_status_id" : 380966294314418176,
  "created_at" : "2013-09-20 09:50:55 +0000",
  "in_reply_to_screen_name" : "jo_sayers",
  "in_reply_to_user_id_str" : "87176766",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 41, 57 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/D533ESjIBC",
      "expanded_url" : "http:\/\/wp.me\/p3jU8R-2Z",
      "display_url" : "wp.me\/p3jU8R-2Z"
    } ]
  },
  "geo" : { },
  "id_str" : "380913671867604992",
  "text" : "Instagrammar? http:\/\/t.co\/D533ESjIBC via @wordpressdotcom",
  "id" : 380913671867604992,
  "created_at" : "2013-09-20 04:37:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "indices" : [ 0, 11 ],
      "id_str" : "152051625",
      "id" : 152051625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380679091650711552",
  "geo" : { },
  "id_str" : "380822654099259392",
  "in_reply_to_user_id" : 152051625,
  "text" : "@heatherfro \"and will never be available to the general public\" hmm another walled corpus, great :\/",
  "id" : 380822654099259392,
  "in_reply_to_status_id" : 380679091650711552,
  "created_at" : "2013-09-19 22:36:10 +0000",
  "in_reply_to_screen_name" : "heatherfro",
  "in_reply_to_user_id_str" : "152051625",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 56, 64 ]
    }, {
      "text" : "esl",
      "indices" : [ 65, 69 ]
    }, {
      "text" : "tesol",
      "indices" : [ 70, 76 ]
    }, {
      "text" : "tefl",
      "indices" : [ 77, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/B0eaaUvmDC",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-Hf",
      "display_url" : "wp.me\/pgHyE-Hf"
    } ]
  },
  "geo" : { },
  "id_str" : "380814329710264320",
  "text" : "Counting countability - EFCAMDAT http:\/\/t.co\/B0eaaUvmDC #eltchat #esl #tesol #tefl",
  "id" : 380814329710264320,
  "created_at" : "2013-09-19 22:03:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Petrie",
      "screen_name" : "teflgeek",
      "indices" : [ 67, 76 ],
      "id_str" : "305260555",
      "id" : 305260555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/eH0nII8HJG",
      "expanded_url" : "http:\/\/wp.me\/p1kzD1-KY",
      "display_url" : "wp.me\/p1kzD1-KY"
    } ]
  },
  "geo" : { },
  "id_str" : "380665733161570304",
  "text" : "ELT Dissertations - A New Blog Project: http:\/\/t.co\/eH0nII8HJG via @teflgeek",
  "id" : 380665733161570304,
  "created_at" : "2013-09-19 12:12:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Bogost",
      "screen_name" : "ibogost",
      "indices" : [ 3, 11 ],
      "id_str" : "6825792",
      "id" : 6825792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380419222842515456",
  "text" : "RT @ibogost: \"Higher education has been failing to meet the needs of the workplace. That's obviously what higher education is for.\" \u2014Congre\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "380352069649317888",
    "text" : "\"Higher education has been failing to meet the needs of the workplace. That's obviously what higher education is for.\" \u2014Congresswoman Foxx",
    "id" : 380352069649317888,
    "created_at" : "2013-09-18 15:26:14 +0000",
    "user" : {
      "name" : "Ian Bogost",
      "screen_name" : "ibogost",
      "protected" : false,
      "id_str" : "6825792",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/677930477752193025\/DUdmOVVK_normal.jpg",
      "id" : 6825792,
      "verified" : true
    }
  },
  "id" : 380419222842515456,
  "created_at" : "2013-09-18 19:53:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Chesnut",
      "screen_name" : "MichaelChesnut2",
      "indices" : [ 0, 16 ],
      "id_str" : "820940430",
      "id" : 820940430
    }, {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 17, 33 ],
      "id_str" : "394053348",
      "id" : 394053348
    }, {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "indices" : [ 42, 54 ],
      "id_str" : "849729062",
      "id" : 849729062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380330632221446144",
  "geo" : { },
  "id_str" : "380374928291139584",
  "in_reply_to_user_id" : 820940430,
  "text" : "@MichaelChesnut2 @michaelegriffin it's by @TonyMcEnery so sure to be good :)",
  "id" : 380374928291139584,
  "in_reply_to_status_id" : 380330632221446144,
  "created_at" : "2013-09-18 16:57:04 +0000",
  "in_reply_to_screen_name" : "MichaelChesnut2",
  "in_reply_to_user_id_str" : "820940430",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/I6A1DoxvGb",
      "expanded_url" : "http:\/\/eflnotes.wordpress.com\/my-english-language-teacher\/",
      "display_url" : "eflnotes.wordpress.com\/my-english-lan\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380374588397322240",
  "text" : "Je dormais en Anglais la prof n'a pas vu je pense que c\u2019\u00E9tait parce que j'avais un stylos dans ma main. http:\/\/t.co\/I6A1DoxvGb",
  "id" : 380374588397322240,
  "created_at" : "2013-09-18 16:55:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 54, 62 ]
    }, {
      "text" : "tesol",
      "indices" : [ 63, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/28NIEFrZLl",
      "expanded_url" : "http:\/\/connect.gonzaga.edu\/hunter\/teaching-materials",
      "display_url" : "connect.gonzaga.edu\/hunter\/teachin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "380084694819168256",
  "text" : "some handy TED talk worksheets http:\/\/t.co\/28NIEFrZLl #eltchat #tesol",
  "id" : 380084694819168256,
  "created_at" : "2013-09-17 21:43:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "P\u00E9rez-Paredes",
      "screen_name" : "perezparedes",
      "indices" : [ 0, 13 ],
      "id_str" : "28528850",
      "id" : 28528850
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379921634368319488",
  "geo" : { },
  "id_str" : "380079659561402368",
  "in_reply_to_user_id" : 28528850,
  "text" : "@perezparedes sorry you lost me, \"feasibility scenario\"?",
  "id" : 380079659561402368,
  "in_reply_to_status_id" : 379921634368319488,
  "created_at" : "2013-09-17 21:23:47 +0000",
  "in_reply_to_screen_name" : "perezparedes",
  "in_reply_to_user_id_str" : "28528850",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monika Sobejko",
      "screen_name" : "SobejM",
      "indices" : [ 0, 7 ],
      "id_str" : "380504775",
      "id" : 380504775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/js4vLRGxBs",
      "expanded_url" : "http:\/\/www.uclouvain.be\/en-cecl-lcworld.html",
      "display_url" : "uclouvain.be\/en-cecl-lcworl\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "379958113589153794",
  "geo" : { },
  "id_str" : "380028839981621248",
  "in_reply_to_user_id" : 380504775,
  "text" : "@SobejM a pleasure, got those from this list http:\/\/t.co\/js4vLRGxBs",
  "id" : 380028839981621248,
  "in_reply_to_status_id" : 379958113589153794,
  "created_at" : "2013-09-17 18:01:50 +0000",
  "in_reply_to_screen_name" : "SobejM",
  "in_reply_to_user_id_str" : "380504775",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joshua Hartshorne",
      "screen_name" : "jkhartshorne",
      "indices" : [ 3, 16 ],
      "id_str" : "1450452834",
      "id" : 1450452834
    }, {
      "name" : "Scientific American",
      "screen_name" : "sciam",
      "indices" : [ 139, 140 ],
      "id_str" : "14647570",
      "id" : 14647570
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/1CnGarZydi",
      "expanded_url" : "http:\/\/www.scientificamerican.com\/article.cfm?id=how-to-understand-the-deep-structures-of-language&WT.mc_id=SA_sharetool_Twitter",
      "display_url" : "scientificamerican.com\/article.cfm?id\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379964545160060928",
  "text" : "RT @jkhartshorne: Me on Scientific American: How to Understand the Deep Structures of Language: Scientific American http:\/\/t.co\/1CnGarZydi \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Scientific American",
        "screen_name" : "sciam",
        "indices" : [ 125, 131 ],
        "id_str" : "14647570",
        "id" : 14647570
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/1CnGarZydi",
        "expanded_url" : "http:\/\/www.scientificamerican.com\/article.cfm?id=how-to-understand-the-deep-structures-of-language&WT.mc_id=SA_sharetool_Twitter",
        "display_url" : "scientificamerican.com\/article.cfm?id\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "379956771411857408",
    "text" : "Me on Scientific American: How to Understand the Deep Structures of Language: Scientific American http:\/\/t.co\/1CnGarZydi via @sciam",
    "id" : 379956771411857408,
    "created_at" : "2013-09-17 13:15:28 +0000",
    "user" : {
      "name" : "Joshua Hartshorne",
      "screen_name" : "jkhartshorne",
      "protected" : false,
      "id_str" : "1450452834",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3697272875\/0f1e1295e18b6edfdbd753d45ce11edd_normal.jpeg",
      "id" : 1450452834,
      "verified" : false
    }
  },
  "id" : 379964545160060928,
  "created_at" : "2013-09-17 13:46:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Freeman",
      "screen_name" : "SnoozeInBrief",
      "indices" : [ 68, 82 ],
      "id_str" : "82947233",
      "id" : 82947233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/3KyMURpcia",
      "expanded_url" : "http:\/\/wp.me\/p1l5Kr-4y",
      "display_url" : "wp.me\/p1l5Kr-4y"
    } ]
  },
  "geo" : { },
  "id_str" : "379948194571902976",
  "text" : "What the Unabomber taught us about usage http:\/\/t.co\/3KyMURpcia via @SnoozeInBrief",
  "id" : 379948194571902976,
  "created_at" : "2013-09-17 12:41:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monika Sobejko",
      "screen_name" : "SobejM",
      "indices" : [ 0, 7 ],
      "id_str" : "380504775",
      "id" : 380504775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/VNEoW4Wk1J",
      "expanded_url" : "http:\/\/ia.uni.lodz.pl\/plec\/tools",
      "display_url" : "ia.uni.lodz.pl\/plec\/tools"
    }, {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/bgA8q78Iqr",
      "expanded_url" : "http:\/\/ifa.amu.edu.pl\/~ifaconc\/",
      "display_url" : "ifa.amu.edu.pl\/~ifaconc\/"
    } ]
  },
  "in_reply_to_status_id_str" : "379922467168329728",
  "geo" : { },
  "id_str" : "379936448587116544",
  "in_reply_to_user_id" : 380504775,
  "text" : "@SobejM  348 scripts (\u00B128357 words) from: - 58 learners &gt;stats for Polish learners; u c these?http:\/\/t.co\/VNEoW4Wk1J; http:\/\/t.co\/bgA8q78Iqr",
  "id" : 379936448587116544,
  "in_reply_to_status_id" : 379922467168329728,
  "created_at" : "2013-09-17 11:54:42 +0000",
  "in_reply_to_screen_name" : "SobejM",
  "in_reply_to_user_id_str" : "380504775",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379907476931362816",
  "geo" : { },
  "id_str" : "379908229322387456",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco 272.25 \u20AC FFS; that's really encouraging teachers to use corpora :\/",
  "id" : 379908229322387456,
  "in_reply_to_status_id" : 379907476931362816,
  "created_at" : "2013-09-17 10:02:34 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379904309556547584",
  "geo" : { },
  "id_str" : "379906897035276288",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco if i were there i would corner Granger and get her to make  her learner corpora publicly accessible :)",
  "id" : 379906897035276288,
  "in_reply_to_status_id" : 379904309556547584,
  "created_at" : "2013-09-17 09:57:17 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicola Prentis",
      "screen_name" : "NicolaPrentis",
      "indices" : [ 3, 17 ],
      "id_str" : "810667033",
      "id" : 810667033
    }, {
      "name" : "Mike Dunphy",
      "screen_name" : "MikeDDunphy",
      "indices" : [ 31, 43 ],
      "id_str" : "205972974",
      "id" : 205972974
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SkillsforLife",
      "indices" : [ 63, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/UR7tOioqiw",
      "expanded_url" : "http:\/\/wp.me\/p1RJaO-aJ",
      "display_url" : "wp.me\/p1RJaO-aJ"
    } ]
  },
  "geo" : { },
  "id_str" : "379904377441361920",
  "text" : "RT @NicolaPrentis: Inspired by @MikeDDunphy and my forthcoming #SkillsforLife # book Echoing to show interest http:\/\/t.co\/UR7tOioqiw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mike Dunphy",
        "screen_name" : "MikeDDunphy",
        "indices" : [ 12, 24 ],
        "id_str" : "205972974",
        "id" : 205972974
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SkillsforLife",
        "indices" : [ 44, 58 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/UR7tOioqiw",
        "expanded_url" : "http:\/\/wp.me\/p1RJaO-aJ",
        "display_url" : "wp.me\/p1RJaO-aJ"
      } ]
    },
    "geo" : { },
    "id_str" : "379902410300612608",
    "text" : "Inspired by @MikeDDunphy and my forthcoming #SkillsforLife # book Echoing to show interest http:\/\/t.co\/UR7tOioqiw",
    "id" : 379902410300612608,
    "created_at" : "2013-09-17 09:39:27 +0000",
    "user" : {
      "name" : "Nicola Prentis",
      "screen_name" : "NicolaPrentis",
      "protected" : false,
      "id_str" : "810667033",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3046181441\/a51ef543c16ff30fdb8966f23237790d_normal.jpeg",
      "id" : 810667033,
      "verified" : false
    }
  },
  "id" : 379904377441361920,
  "created_at" : "2013-09-17 09:47:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379902041964810240",
  "geo" : { },
  "id_str" : "379902621470826496",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco no but maybe u will tweet it? :)",
  "id" : 379902621470826496,
  "in_reply_to_status_id" : 379902041964810240,
  "created_at" : "2013-09-17 09:40:17 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "P\u00E9rez-Paredes",
      "screen_name" : "perezparedes",
      "indices" : [ 0, 13 ],
      "id_str" : "28528850",
      "id" : 28528850
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379890080422191104",
  "geo" : { },
  "id_str" : "379895687686549504",
  "in_reply_to_user_id" : 28528850,
  "text" : "@perezparedes a big problem for lack of corpus in classroom-&gt; corpora walled gardens - even teachers interested in DDL face big obstacles :(",
  "id" : 379895687686549504,
  "in_reply_to_status_id" : 379890080422191104,
  "created_at" : "2013-09-17 09:12:44 +0000",
  "in_reply_to_screen_name" : "perezparedes",
  "in_reply_to_user_id_str" : "28528850",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monika Sobejko",
      "screen_name" : "SobejM",
      "indices" : [ 0, 7 ],
      "id_str" : "380504775",
      "id" : 380504775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379885520517484544",
  "geo" : { },
  "id_str" : "379893970345549825",
  "in_reply_to_user_id" : 380504775,
  "text" : "@SobejM great be interested to hear how you used it :)",
  "id" : 379893970345549825,
  "in_reply_to_status_id" : 379885520517484544,
  "created_at" : "2013-09-17 09:05:55 +0000",
  "in_reply_to_screen_name" : "SobejM",
  "in_reply_to_user_id_str" : "380504775",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "P\u00E9rez-Paredes",
      "screen_name" : "perezparedes",
      "indices" : [ 3, 16 ],
      "id_str" : "28528850",
      "id" : 28528850
    }, {
      "name" : "LinkedIn SlideShare",
      "screen_name" : "SlideShare",
      "indices" : [ 71, 82 ],
      "id_str" : "9676152",
      "id" : 9676152
    }, {
      "name" : "LinkedIn SlideShare",
      "screen_name" : "SlideShare",
      "indices" : [ 129, 140 ],
      "id_str" : "9676152",
      "id" : 9676152
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpuslinguistics",
      "indices" : [ 83, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/o68SnrSIiP",
      "expanded_url" : "http:\/\/www.slideshare.net\/perezparedes\/using-pedagogic-corpora-in-elt-26260637",
      "display_url" : "slideshare.net\/perezparedes\/u\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379893822999625728",
  "text" : "RT @perezparedes: My latest upload : Using pedagogic corpora in ELT on @slideshare #corpuslinguistics http:\/\/t.co\/o68SnrSIiP via @SlideShare",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "LinkedIn SlideShare",
        "screen_name" : "SlideShare",
        "indices" : [ 53, 64 ],
        "id_str" : "9676152",
        "id" : 9676152
      }, {
        "name" : "LinkedIn SlideShare",
        "screen_name" : "SlideShare",
        "indices" : [ 111, 122 ],
        "id_str" : "9676152",
        "id" : 9676152
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpuslinguistics",
        "indices" : [ 65, 83 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/o68SnrSIiP",
        "expanded_url" : "http:\/\/www.slideshare.net\/perezparedes\/using-pedagogic-corpora-in-elt-26260637",
        "display_url" : "slideshare.net\/perezparedes\/u\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "379890080422191104",
    "text" : "My latest upload : Using pedagogic corpora in ELT on @slideshare #corpuslinguistics http:\/\/t.co\/o68SnrSIiP via @SlideShare",
    "id" : 379890080422191104,
    "created_at" : "2013-09-17 08:50:27 +0000",
    "user" : {
      "name" : "P\u00E9rez-Paredes",
      "screen_name" : "perezparedes",
      "protected" : false,
      "id_str" : "28528850",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746249968139313153\/2-1yieTh_normal.jpg",
      "id" : 28528850,
      "verified" : false
    }
  },
  "id" : 379893822999625728,
  "created_at" : "2013-09-17 09:05:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pete Warden",
      "screen_name" : "petewarden",
      "indices" : [ 100, 111 ],
      "id_str" : "14642896",
      "id" : 14642896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/6q7VYsIoOG",
      "expanded_url" : "http:\/\/www.raspberrypi.org\/archives\/4824",
      "display_url" : "raspberrypi.org\/archives\/4824"
    } ]
  },
  "geo" : { },
  "id_str" : "379873334655066113",
  "text" : "Akkie, and the 101 things you can do with a CD-ROM drive's eject function http:\/\/t.co\/6q7VYsIoOG HT @petewarden",
  "id" : 379873334655066113,
  "created_at" : "2013-09-17 07:43:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379756288093073408",
  "geo" : { },
  "id_str" : "379868377776279552",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler there's some intriguing ones there! thanks for share on my last post; enjoyed reading yr conference report.",
  "id" : 379868377776279552,
  "in_reply_to_status_id" : 379756288093073408,
  "created_at" : "2013-09-17 07:24:13 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/A949b2PV2y",
      "expanded_url" : "http:\/\/xkcd.com\/1256\/",
      "display_url" : "xkcd.com\/1256\/"
    } ]
  },
  "geo" : { },
  "id_str" : "379730970502381568",
  "text" : "Questions found in google autocomplete http:\/\/t.co\/A949b2PV2y",
  "id" : 379730970502381568,
  "created_at" : "2013-09-16 22:18:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShareThis",
      "screen_name" : "ShareThis",
      "indices" : [ 37, 47 ],
      "id_str" : "14116807",
      "id" : 14116807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/ouG9FohoTA",
      "expanded_url" : "http:\/\/shar.es\/i8C6h",
      "display_url" : "shar.es\/i8C6h"
    } ]
  },
  "geo" : { },
  "id_str" : "379706070513356800",
  "text" : "All Mouth http:\/\/t.co\/ouG9FohoTA via @sharethis",
  "id" : 379706070513356800,
  "created_at" : "2013-09-16 20:39:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/I6A1DoxvGb",
      "expanded_url" : "http:\/\/eflnotes.wordpress.com\/my-english-language-teacher\/",
      "display_url" : "eflnotes.wordpress.com\/my-english-lan\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379702454545154048",
  "text" : "My english teacher is making us wright a love poem to our phones http:\/\/t.co\/I6A1DoxvGb",
  "id" : 379702454545154048,
  "created_at" : "2013-09-16 20:24:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monika Sobejko",
      "screen_name" : "SobejM",
      "indices" : [ 0, 7 ],
      "id_str" : "380504775",
      "id" : 380504775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "379695811715551232",
  "in_reply_to_user_id" : 380504775,
  "text" : "@SobejM thanks for sharing post monika :)",
  "id" : 379695811715551232,
  "created_at" : "2013-09-16 19:58:30 +0000",
  "in_reply_to_screen_name" : "SobejM",
  "in_reply_to_user_id_str" : "380504775",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clive Thompson",
      "screen_name" : "pomeranian99",
      "indices" : [ 3, 16 ],
      "id_str" : "661403",
      "id" : 661403
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/lgmEB5wzPZ",
      "expanded_url" : "http:\/\/www.square-bear.co.uk\/mitsuku\/chat.htm",
      "display_url" : "square-bear.co.uk\/mitsuku\/chat.h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379695393140781057",
  "text" : "RT @pomeranian99: Have a chat with Mitsuku, winner of this year's Loebner chatbot competition: http:\/\/t.co\/lgmEB5wzPZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/lgmEB5wzPZ",
        "expanded_url" : "http:\/\/www.square-bear.co.uk\/mitsuku\/chat.htm",
        "display_url" : "square-bear.co.uk\/mitsuku\/chat.h\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "379692804991352832",
    "text" : "Have a chat with Mitsuku, winner of this year's Loebner chatbot competition: http:\/\/t.co\/lgmEB5wzPZ",
    "id" : 379692804991352832,
    "created_at" : "2013-09-16 19:46:33 +0000",
    "user" : {
      "name" : "Clive Thompson",
      "screen_name" : "pomeranian99",
      "protected" : false,
      "id_str" : "661403",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000407595163\/163d76384315dfd651daa13e44b724e4_normal.jpeg",
      "id" : 661403,
      "verified" : false
    }
  },
  "id" : 379695393140781057,
  "created_at" : "2013-09-16 19:56:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 81, 89 ]
    }, {
      "text" : "efl",
      "indices" : [ 90, 94 ]
    }, {
      "text" : "tesol",
      "indices" : [ 95, 101 ]
    }, {
      "text" : "esl",
      "indices" : [ 102, 106 ]
    }, {
      "text" : "learnercorpora",
      "indices" : [ 107, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/qUkZO8ZuvY",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-GW",
      "display_url" : "wp.me\/pgHyE-GW"
    } ]
  },
  "geo" : { },
  "id_str" : "379650846272659456",
  "text" : "Getting learner data for vocabulary activities - EFCAMDAT http:\/\/t.co\/qUkZO8ZuvY #eltchat #efl #tesol #esl #learnercorpora",
  "id" : 379650846272659456,
  "created_at" : "2013-09-16 16:59:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yolanda B. Schell",
      "screen_name" : "mattellman",
      "indices" : [ 0, 11 ],
      "id_str" : "725597315860434945",
      "id" : 725597315860434945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/1G9WUcboZv",
      "expanded_url" : "http:\/\/itre.cis.upenn.edu\/~myl\/languagelog\/archives\/003507.html",
      "display_url" : "itre.cis.upenn.edu\/~myl\/languagel\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "379149010499407875",
  "geo" : { },
  "id_str" : "379229106706980864",
  "in_reply_to_user_id" : 394987109,
  "text" : "@mattellman @rebecca_standig It's always silly season in the (BBC) science section http:\/\/t.co\/1G9WUcboZv :0",
  "id" : 379229106706980864,
  "in_reply_to_status_id" : 379149010499407875,
  "created_at" : "2013-09-15 13:03:59 +0000",
  "in_reply_to_screen_name" : "MatthewEllman",
  "in_reply_to_user_id_str" : "394987109",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Register",
      "screen_name" : "TheRegister",
      "indices" : [ 3, 15 ],
      "id_str" : "78012548",
      "id" : 78012548
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obit",
      "indices" : [ 17, 22 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/4hXCHuWD6B",
      "expanded_url" : "http:\/\/reg.cx\/27UF",
      "display_url" : "reg.cx\/27UF"
    } ]
  },
  "geo" : { },
  "id_str" : "379189191059316736",
  "text" : "RT @theregister: #Obit Billionaire engineer Ray Dolby, 80, dies at home in San Francisco: The day the music died. Ray Dolby, the engi\u2026 http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/theregister.co.uk\/\" rel=\"nofollow\"\u003EVulture Central\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Obit",
        "indices" : [ 0, 5 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/4hXCHuWD6B",
        "expanded_url" : "http:\/\/reg.cx\/27UF",
        "display_url" : "reg.cx\/27UF"
      } ]
    },
    "geo" : { },
    "id_str" : "378657823259115520",
    "text" : "#Obit Billionaire engineer Ray Dolby, 80, dies at home in San Francisco: The day the music died. Ray Dolby, the engi\u2026 http:\/\/t.co\/4hXCHuWD6B",
    "id" : 378657823259115520,
    "created_at" : "2013-09-13 23:13:54 +0000",
    "user" : {
      "name" : "RegVulture",
      "screen_name" : "regvulture",
      "protected" : false,
      "id_str" : "381940039",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000641211038\/baad5b63e1d218692d68b03ae7a1057f_normal.png",
      "id" : 381940039,
      "verified" : false
    }
  },
  "id" : 379189191059316736,
  "created_at" : "2013-09-15 10:25:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "markwarschauer",
      "screen_name" : "markwarschauer",
      "indices" : [ 3, 18 ],
      "id_str" : "17316060",
      "id" : 17316060
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/muxuzgAy1r",
      "expanded_url" : "http:\/\/crookedtimber.org\/2013\/09\/10\/internet-intellectuals\/",
      "display_url" : "crookedtimber.org\/2013\/09\/10\/int\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379182820985290753",
  "text" : "RT @markwarschauer: Internet intellectuals http:\/\/t.co\/muxuzgAy1r",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 23, 45 ],
        "url" : "http:\/\/t.co\/muxuzgAy1r",
        "expanded_url" : "http:\/\/crookedtimber.org\/2013\/09\/10\/internet-intellectuals\/",
        "display_url" : "crookedtimber.org\/2013\/09\/10\/int\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "379161913545854977",
    "text" : "Internet intellectuals http:\/\/t.co\/muxuzgAy1r",
    "id" : 379161913545854977,
    "created_at" : "2013-09-15 08:36:59 +0000",
    "user" : {
      "name" : "markwarschauer",
      "screen_name" : "markwarschauer",
      "protected" : false,
      "id_str" : "17316060",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535141210432622592\/ZXqkNrhW_normal.jpeg",
      "id" : 17316060,
      "verified" : false
    }
  },
  "id" : 379182820985290753,
  "created_at" : "2013-09-15 10:00:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Digg",
      "screen_name" : "digg",
      "indices" : [ 75, 80 ],
      "id_str" : "15163466",
      "id" : 15163466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/3zF2ptPBQd",
      "expanded_url" : "http:\/\/elfaproject.wordpress.com\/2013\/09\/13\/when-in-rome-elf6-conference\/",
      "display_url" : "elfaproject.wordpress.com\/2013\/09\/13\/whe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379166901122764800",
  "text" : "When in Rome: thoughts from the ELF6 conference http:\/\/t.co\/3zF2ptPBQd via @Digg",
  "id" : 379166901122764800,
  "created_at" : "2013-09-15 08:56:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378992735920730112",
  "text" : "@leakygrammar \"Why bomb when it won't solve the direct problem, but might create other problems\" == \"systemic\" causation :\/",
  "id" : 378992735920730112,
  "created_at" : "2013-09-14 21:24:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Peterson",
      "screen_name" : "NetPeterson",
      "indices" : [ 3, 15 ],
      "id_str" : "1260571208",
      "id" : 1260571208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/EwmO74znSl",
      "expanded_url" : "http:\/\/tinyurl.com\/m4flo4u",
      "display_url" : "tinyurl.com\/m4flo4u"
    } ]
  },
  "geo" : { },
  "id_str" : "378841350130520064",
  "text" : "RT @NetPeterson: Denis Halliday, \"WHO Refuses to Publish Report on Cancers and Birth Defects in Iraq Caused by Depleted,\" 9\/13\/2013 http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/EwmO74znSl",
        "expanded_url" : "http:\/\/tinyurl.com\/m4flo4u",
        "display_url" : "tinyurl.com\/m4flo4u"
      } ]
    },
    "geo" : { },
    "id_str" : "378674747485077504",
    "text" : "Denis Halliday, \"WHO Refuses to Publish Report on Cancers and Birth Defects in Iraq Caused by Depleted,\" 9\/13\/2013 http:\/\/t.co\/EwmO74znSl",
    "id" : 378674747485077504,
    "created_at" : "2013-09-14 00:21:09 +0000",
    "user" : {
      "name" : "David Peterson",
      "screen_name" : "NetPeterson",
      "protected" : false,
      "id_str" : "1260571208",
      "profile_image_url_https" : "https:\/\/abs.twimg.com\/sticky\/default_profile_images\/default_profile_1_normal.png",
      "id" : 1260571208,
      "verified" : false
    }
  },
  "id" : 378841350130520064,
  "created_at" : "2013-09-14 11:23:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/F3LwqZBNNM",
      "expanded_url" : "http:\/\/www.jonathan-cook.net\/blog\/2013-09-14\/russell-brand-half-way-to-subversion\/",
      "display_url" : "jonathan-cook.net\/blog\/2013-09-1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378809287364997120",
  "text" : "Russel Brand:half way to subversion http:\/\/t.co\/F3LwqZBNNM",
  "id" : 378809287364997120,
  "created_at" : "2013-09-14 09:15:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Teju Cole",
      "screen_name" : "tejucole",
      "indices" : [ 3, 12 ],
      "id_str" : "83876527",
      "id" : 83876527
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 140 ],
      "url" : "http:\/\/t.co\/O7BHokiTG1",
      "expanded_url" : "http:\/\/www.latimes.com\/entertainment\/music\/posts\/la-et-ms-veterans-dreams-20130910,0,5918965.story",
      "display_url" : "latimes.com\/entertainment\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378538886080630784",
  "text" : "RT @tejucole: \"Holding It Down\" by Vijay Iyer and Mike Ladd: feverish dreamscapes of our mad wars. Highly recommended. http:\/\/t.co\/O7BHokiT\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/O7BHokiTG1",
        "expanded_url" : "http:\/\/www.latimes.com\/entertainment\/music\/posts\/la-et-ms-veterans-dreams-20130910,0,5918965.story",
        "display_url" : "latimes.com\/entertainment\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "378536910974484481",
    "text" : "\"Holding It Down\" by Vijay Iyer and Mike Ladd: feverish dreamscapes of our mad wars. Highly recommended. http:\/\/t.co\/O7BHokiTG1",
    "id" : 378536910974484481,
    "created_at" : "2013-09-13 15:13:27 +0000",
    "user" : {
      "name" : "Teju Cole",
      "screen_name" : "tejucole",
      "protected" : false,
      "id_str" : "83876527",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1731884703\/teju3_normal.jpg",
      "id" : 83876527,
      "verified" : true
    }
  },
  "id" : 378538886080630784,
  "created_at" : "2013-09-13 15:21:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((David Traynier)))",
      "screen_name" : "DTraynier",
      "indices" : [ 3, 13 ],
      "id_str" : "317716198",
      "id" : 317716198
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "r4today",
      "indices" : [ 15, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378537911102095360",
  "text" : "RT @DTraynier: #r4today journalist describes potential US bomb attacks on Syrians as \"a biffing\". 7\/7 attacks a bop on the nose, presumably.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/seesmic.com\/\" rel=\"nofollow\"\u003ESeesmic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "r4today",
        "indices" : [ 0, 8 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "378393413051510784",
    "text" : "#r4today journalist describes potential US bomb attacks on Syrians as \"a biffing\". 7\/7 attacks a bop on the nose, presumably.",
    "id" : 378393413051510784,
    "created_at" : "2013-09-13 05:43:14 +0000",
    "user" : {
      "name" : "(((David Traynier)))",
      "screen_name" : "DTraynier",
      "protected" : false,
      "id_str" : "317716198",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727929911877480451\/fLuwL370_normal.jpg",
      "id" : 317716198,
      "verified" : false
    }
  },
  "id" : 378537911102095360,
  "created_at" : "2013-09-13 15:17:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 10, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378500820054319104",
  "text" : "thanks to #eltchat for recommending Classrm Dynamics by J Hadfield; sts liked walking silly to shake the morning cobwebs :)",
  "id" : 378500820054319104,
  "created_at" : "2013-09-13 12:50:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "News Unspun",
      "screen_name" : "news_unspun",
      "indices" : [ 3, 15 ],
      "id_str" : "241288268",
      "id" : 241288268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378266888477753345",
  "text" : "RT @news_unspun: BBC's Mark Mardell describes presidents:\n\n1. Putin: \"bare-chested, horse-riding, tiger-hunting\"\n\n2. Obama: \" agonising and\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "378139399936303104",
    "text" : "BBC's Mark Mardell describes presidents:\n\n1. Putin: \"bare-chested, horse-riding, tiger-hunting\"\n\n2. Obama: \" agonising and reflective\"",
    "id" : 378139399936303104,
    "created_at" : "2013-09-12 12:53:53 +0000",
    "user" : {
      "name" : "News Unspun",
      "screen_name" : "news_unspun",
      "protected" : false,
      "id_str" : "241288268",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3176838178\/fa7f886ef014ca0437d5dc800dc9163e_normal.png",
      "id" : 241288268,
      "verified" : false
    }
  },
  "id" : 378266888477753345,
  "created_at" : "2013-09-12 21:20:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/I6A1DoxvGb",
      "expanded_url" : "http:\/\/eflnotes.wordpress.com\/my-english-language-teacher\/",
      "display_url" : "eflnotes.wordpress.com\/my-english-lan\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378091332603895809",
  "text" : "Je joue \u00E0 Candy crush avec le prof d'anglais \u270Chttp:\/\/t.co\/I6A1DoxvGb",
  "id" : 378091332603895809,
  "created_at" : "2013-09-12 09:42:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/TXodh3J8vG",
      "expanded_url" : "http:\/\/blasphemous.epouvantails.collectifs.net",
      "display_url" : "\u2026asphemous.epouvantails.collectifs.net"
    }, {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/fzS5e9K8zv",
      "expanded_url" : "http:\/\/members5.boardhost.com\/medialens\/msg\/1378966250.html",
      "display_url" : "members5.boardhost.com\/medialens\/msg\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378080172668239872",
  "text" : "interesting look at French media following USA 9\/11 http:\/\/t.co\/TXodh3J8vG HT http:\/\/t.co\/fzS5e9K8zv",
  "id" : 378080172668239872,
  "created_at" : "2013-09-12 08:58:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Patsko",
      "screen_name" : "lauraahaha",
      "indices" : [ 3, 14 ],
      "id_str" : "97957137",
      "id" : 97957137
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "elt",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/HhizjOly2V",
      "expanded_url" : "http:\/\/wordwanderer.org\/",
      "display_url" : "wordwanderer.org"
    } ]
  },
  "geo" : { },
  "id_str" : "377849201402462208",
  "text" : "RT @lauraahaha: Check out 'WordWanderer'- interesting new tool for exploring words' connections, concordances, etc. http:\/\/t.co\/HhizjOly2V \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "eltchat",
        "indices" : [ 123, 131 ]
      }, {
        "text" : "elt",
        "indices" : [ 132, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/HhizjOly2V",
        "expanded_url" : "http:\/\/wordwanderer.org\/",
        "display_url" : "wordwanderer.org"
      } ]
    },
    "geo" : { },
    "id_str" : "377847582103699457",
    "text" : "Check out 'WordWanderer'- interesting new tool for exploring words' connections, concordances, etc. http:\/\/t.co\/HhizjOly2V #eltchat #elt",
    "id" : 377847582103699457,
    "created_at" : "2013-09-11 17:34:18 +0000",
    "user" : {
      "name" : "Laura Patsko",
      "screen_name" : "lauraahaha",
      "protected" : false,
      "id_str" : "97957137",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/659005852477714432\/xfuJsW6q_normal.jpg",
      "id" : 97957137,
      "verified" : false
    }
  },
  "id" : 377849201402462208,
  "created_at" : "2013-09-11 17:40:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "News Unspun",
      "screen_name" : "news_unspun",
      "indices" : [ 3, 15 ],
      "id_str" : "241288268",
      "id" : 241288268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/B9HmUJHm18",
      "expanded_url" : "http:\/\/www.theguardian.com\/commentisfree\/2013\/sep\/11\/chile-1973-coup-britain-protecting",
      "display_url" : "theguardian.com\/commentisfree\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377805358602805248",
  "text" : "RT @news_unspun: When Pinochet overthrew Allende, 'democrats across the world were horrified. But not the British Foreign Office' http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/B9HmUJHm18",
        "expanded_url" : "http:\/\/www.theguardian.com\/commentisfree\/2013\/sep\/11\/chile-1973-coup-britain-protecting",
        "display_url" : "theguardian.com\/commentisfree\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "377747575186927617",
    "text" : "When Pinochet overthrew Allende, 'democrats across the world were horrified. But not the British Foreign Office' http:\/\/t.co\/B9HmUJHm18",
    "id" : 377747575186927617,
    "created_at" : "2013-09-11 10:56:54 +0000",
    "user" : {
      "name" : "News Unspun",
      "screen_name" : "news_unspun",
      "protected" : false,
      "id_str" : "241288268",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3176838178\/fa7f886ef014ca0437d5dc800dc9163e_normal.png",
      "id" : 241288268,
      "verified" : false
    }
  },
  "id" : 377805358602805248,
  "created_at" : "2013-09-11 14:46:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/erased4838853.com\" rel=\"nofollow\"\u003Eerased4838853\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemma Lunn",
      "screen_name" : "GemL1",
      "indices" : [ 3, 9 ],
      "id_str" : "486146568",
      "id" : 486146568
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 87, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/emIp8pzgDT",
      "expanded_url" : "http:\/\/www.ultimatecampresource.com\/site\/camp-activity\/people-to-people.html",
      "display_url" : "ultimatecampresource.com\/site\/camp-acti\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377762340718264321",
  "text" : "RT @GemL1 people to people is a fun ice breaker for YLs \/ teens http:\/\/t.co\/emIp8pzgDT #eltchat",
  "id" : 377762340718264321,
  "created_at" : "2013-09-11 11:55:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 130, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/mPcUGuyAV0",
      "expanded_url" : "http:\/\/www.tesoltraining.co.uk\/blog\/lesson-ideas\/efl-adult-elementary-lesson-lying-not-boring\/",
      "display_url" : "tesoltraining.co.uk\/blog\/lesson-id\u2026"
    }, {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/ndJiMHPkky",
      "expanded_url" : "http:\/\/bit.ly\/1d5ozRL",
      "display_url" : "bit.ly\/1d5ozRL"
    }, {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/5UcqGJTWSO",
      "expanded_url" : "http:\/\/bit.ly\/15cGuEk",
      "display_url" : "bit.ly\/15cGuEk"
    } ]
  },
  "geo" : { },
  "id_str" : "377757872618086400",
  "text" : "nice twist on lying game http:\/\/t.co\/mPcUGuyAV0 \u2026; warm-ups http:\/\/t.co\/ndJiMHPkky ; nice list 1st lessons http:\/\/t.co\/5UcqGJTWSO #eltchat",
  "id" : 377757872618086400,
  "created_at" : "2013-09-11 11:37:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/I6A1DoxvGb",
      "expanded_url" : "http:\/\/eflnotes.wordpress.com\/my-english-language-teacher\/",
      "display_url" : "eflnotes.wordpress.com\/my-english-lan\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377732830974853120",
  "text" : "I used who what where when why AND how, my language teacher will be so proud http:\/\/t.co\/I6A1DoxvGb",
  "id" : 377732830974853120,
  "created_at" : "2013-09-11 09:58:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BEBC",
      "screen_name" : "Books4English",
      "indices" : [ 4, 18 ],
      "id_str" : "181893496",
      "id" : 181893496
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Books4EnglishplagiarismBingo",
      "indices" : [ 104, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377721377563746304",
  "text" : "ooh @Books4English changed up their copy-stuff-from-net to copying-comments-on-net; its fun playing the #Books4EnglishplagiarismBingo :\/",
  "id" : 377721377563746304,
  "created_at" : "2013-09-11 09:12:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angus B Grieve-Smith",
      "screen_name" : "grvsmth",
      "indices" : [ 0, 8 ],
      "id_str" : "22381639",
      "id" : 22381639
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377538120448999424",
  "geo" : { },
  "id_str" : "377539425242054656",
  "in_reply_to_user_id" : 22381639,
  "text" : "@grvsmth trop fort!",
  "id" : 377539425242054656,
  "in_reply_to_status_id" : 377538120448999424,
  "created_at" : "2013-09-10 21:09:47 +0000",
  "in_reply_to_screen_name" : "grvsmth",
  "in_reply_to_user_id_str" : "22381639",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Weidenbaum",
      "screen_name" : "disquiet",
      "indices" : [ 3, 12 ],
      "id_str" : "6943192",
      "id" : 6943192
    }, {
      "name" : "Adam Howard",
      "screen_name" : "skattyadz",
      "indices" : [ 17, 27 ],
      "id_str" : "4675238256",
      "id" : 4675238256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377534609866498049",
  "text" : "RT @disquiet: RT @skattyadz: NSA: \u201CYo, Apple, how can we get everyone\u2019s fingerprints?\u201D Apple: \u201CDon\u2019t worry, mate. We got this\u201D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Adam Howard",
        "screen_name" : "skattyadz",
        "indices" : [ 3, 13 ],
        "id_str" : "4675238256",
        "id" : 4675238256
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "377498468748509184",
    "text" : "RT @skattyadz: NSA: \u201CYo, Apple, how can we get everyone\u2019s fingerprints?\u201D Apple: \u201CDon\u2019t worry, mate. We got this\u201D",
    "id" : 377498468748509184,
    "created_at" : "2013-09-10 18:27:03 +0000",
    "user" : {
      "name" : "Marc Weidenbaum",
      "screen_name" : "disquiet",
      "protected" : false,
      "id_str" : "6943192",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/692147298017632256\/l5mu9mbn_normal.jpg",
      "id" : 6943192,
      "verified" : false
    }
  },
  "id" : 377534609866498049,
  "created_at" : "2013-09-10 20:50:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Siva Vaidhyanathan",
      "screen_name" : "sivavaid",
      "indices" : [ 3, 12 ],
      "id_str" : "20406724",
      "id" : 20406724
    }, {
      "name" : "The Guardian",
      "screen_name" : "guardian",
      "indices" : [ 136, 140 ],
      "id_str" : "87818409",
      "id" : 87818409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/lgKfi0Bcw6",
      "expanded_url" : "http:\/\/gu.com\/p\/3tj67\/tw",
      "display_url" : "gu.com\/p\/3tj67\/tw"
    } ]
  },
  "geo" : { },
  "id_str" : "377516689081921536",
  "text" : "RT @sivavaid: The Clash: Audio Ammunition YouTube documentary includes unseen Joe Strummer interview footage http:\/\/t.co\/lgKfi0Bcw6 via @gu\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Guardian",
        "screen_name" : "guardian",
        "indices" : [ 122, 131 ],
        "id_str" : "87818409",
        "id" : 87818409
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/lgKfi0Bcw6",
        "expanded_url" : "http:\/\/gu.com\/p\/3tj67\/tw",
        "display_url" : "gu.com\/p\/3tj67\/tw"
      } ]
    },
    "geo" : { },
    "id_str" : "377501849080696832",
    "text" : "The Clash: Audio Ammunition YouTube documentary includes unseen Joe Strummer interview footage http:\/\/t.co\/lgKfi0Bcw6 via @guardian",
    "id" : 377501849080696832,
    "created_at" : "2013-09-10 18:40:29 +0000",
    "user" : {
      "name" : "Siva Vaidhyanathan",
      "screen_name" : "sivavaid",
      "protected" : false,
      "id_str" : "20406724",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/767792599050649600\/aaiFpS9e_normal.jpg",
      "id" : 20406724,
      "verified" : false
    }
  },
  "id" : 377516689081921536,
  "created_at" : "2013-09-10 19:39:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Sketchley",
      "screen_name" : "ELTExperiences",
      "indices" : [ 3, 18 ],
      "id_str" : "22779473",
      "id" : 22779473
    }, {
      "name" : "Bethany Cagnol",
      "screen_name" : "bethcagnol",
      "indices" : [ 84, 95 ],
      "id_str" : "27641720",
      "id" : 27641720
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELT",
      "indices" : [ 114, 118 ]
    }, {
      "text" : "France",
      "indices" : [ 122, 129 ]
    }, {
      "text" : "EFL",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/XghW1tvhCe",
      "expanded_url" : "http:\/\/www.eltexperiences.com\/2013\/09\/september-teacher-interview-bethany.html",
      "display_url" : "eltexperiences.com\/2013\/09\/septem\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377515789537927168",
  "text" : "RT @ELTExperiences: Have you read the latest teacher interview on my blog featuring @bethcagnol? Learn more about #ELT in #France: http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bethany Cagnol",
        "screen_name" : "bethcagnol",
        "indices" : [ 64, 75 ],
        "id_str" : "27641720",
        "id" : 27641720
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELT",
        "indices" : [ 94, 98 ]
      }, {
        "text" : "France",
        "indices" : [ 102, 109 ]
      }, {
        "text" : "EFL",
        "indices" : [ 134, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/XghW1tvhCe",
        "expanded_url" : "http:\/\/www.eltexperiences.com\/2013\/09\/september-teacher-interview-bethany.html",
        "display_url" : "eltexperiences.com\/2013\/09\/septem\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "377460028271128576",
    "text" : "Have you read the latest teacher interview on my blog featuring @bethcagnol? Learn more about #ELT in #France: http:\/\/t.co\/XghW1tvhCe #EFL",
    "id" : 377460028271128576,
    "created_at" : "2013-09-10 15:54:18 +0000",
    "user" : {
      "name" : "Martin Sketchley",
      "screen_name" : "ELTExperiences",
      "protected" : false,
      "id_str" : "22779473",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749341089686052865\/G472q6ik_normal.jpg",
      "id" : 22779473,
      "verified" : false
    }
  },
  "id" : 377515789537927168,
  "created_at" : "2013-09-10 19:35:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angus B Grieve-Smith",
      "screen_name" : "grvsmth",
      "indices" : [ 0, 8 ],
      "id_str" : "22381639",
      "id" : 22381639
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377479780561874944",
  "geo" : { },
  "id_str" : "377501893758431232",
  "in_reply_to_user_id" : 22381639,
  "text" : "@grvsmth cool il a fallu que je fasse de recherches pour decouvrir la signification de cette expression :)",
  "id" : 377501893758431232,
  "in_reply_to_status_id" : 377479780561874944,
  "created_at" : "2013-09-10 18:40:39 +0000",
  "in_reply_to_screen_name" : "grvsmth",
  "in_reply_to_user_id_str" : "22381639",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CU LingSoc",
      "screen_name" : "CULingSoc",
      "indices" : [ 3, 13 ],
      "id_str" : "588784946",
      "id" : 588784946
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/r20PeJ2vgs",
      "expanded_url" : "http:\/\/buff.ly\/1dL2vi5",
      "display_url" : "buff.ly\/1dL2vi5"
    } ]
  },
  "geo" : { },
  "id_str" : "377464772469342209",
  "text" : "RT @CULingSoc: Here's The Full Definition Of The Most Complex Word In The English Language http:\/\/t.co\/r20PeJ2vgs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/r20PeJ2vgs",
        "expanded_url" : "http:\/\/buff.ly\/1dL2vi5",
        "display_url" : "buff.ly\/1dL2vi5"
      } ]
    },
    "geo" : { },
    "id_str" : "377461630080385024",
    "text" : "Here's The Full Definition Of The Most Complex Word In The English Language http:\/\/t.co\/r20PeJ2vgs",
    "id" : 377461630080385024,
    "created_at" : "2013-09-10 16:00:40 +0000",
    "user" : {
      "name" : "CU LingSoc",
      "screen_name" : "CULingSoc",
      "protected" : false,
      "id_str" : "588784946",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2245221502\/LingSoc_Crest_normal.jpg",
      "id" : 588784946,
      "verified" : false
    }
  },
  "id" : 377464772469342209,
  "created_at" : "2013-09-10 16:13:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "net magazine",
      "screen_name" : "netmag",
      "indices" : [ 3, 10 ],
      "id_str" : "17648193",
      "id" : 17648193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 124, 140 ],
      "url" : "http:\/\/t.co\/tJFyTHPO3S",
      "expanded_url" : "http:\/\/ow.ly\/oHAfF",
      "display_url" : "ow.ly\/oHAfF"
    } ]
  },
  "geo" : { },
  "id_str" : "377458018159312897",
  "text" : "RT @netmag: In need of some web design inspiration? Check out the experimental site of designer and developer Adam Hartwig: http:\/\/t.co\/tJF\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/tJFyTHPO3S",
        "expanded_url" : "http:\/\/ow.ly\/oHAfF",
        "display_url" : "ow.ly\/oHAfF"
      } ]
    },
    "geo" : { },
    "id_str" : "377186122516144128",
    "text" : "In need of some web design inspiration? Check out the experimental site of designer and developer Adam Hartwig: http:\/\/t.co\/tJFyTHPO3S",
    "id" : 377186122516144128,
    "created_at" : "2013-09-09 21:45:54 +0000",
    "user" : {
      "name" : "net magazine",
      "screen_name" : "netmag",
      "protected" : false,
      "id_str" : "17648193",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000697523305\/d556bef753c6ac3933e9d5bf9f147418_normal.jpeg",
      "id" : 17648193,
      "verified" : false
    }
  },
  "id" : 377458018159312897,
  "created_at" : "2013-09-10 15:46:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/I6A1DoxvGb",
      "expanded_url" : "http:\/\/eflnotes.wordpress.com\/my-english-language-teacher\/",
      "display_url" : "eflnotes.wordpress.com\/my-english-lan\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377443740207415298",
  "text" : "Mon prof d'anglais il sort, un MacBook, un iPad et un iPhone.. Il est sponso chez Apple lui? http:\/\/t.co\/I6A1DoxvGb",
  "id" : 377443740207415298,
  "created_at" : "2013-09-10 14:49:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jo Sayers",
      "screen_name" : "jo_sayers",
      "indices" : [ 0, 10 ],
      "id_str" : "87176766",
      "id" : 87176766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377347520935903232",
  "geo" : { },
  "id_str" : "377348989172998144",
  "in_reply_to_user_id" : 87176766,
  "text" : "@jo_sayers hehe :) some gems out there, thanks for RT",
  "id" : 377348989172998144,
  "in_reply_to_status_id" : 377347520935903232,
  "created_at" : "2013-09-10 08:33:04 +0000",
  "in_reply_to_screen_name" : "jo_sayers",
  "in_reply_to_user_id_str" : "87176766",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELT Teacher 2 Writer",
      "screen_name" : "ELT_T2W",
      "indices" : [ 3, 11 ],
      "id_str" : "427697599",
      "id" : 427697599
    }, {
      "name" : "Onestopenglish",
      "screen_name" : "onestopenglish",
      "indices" : [ 98, 113 ],
      "id_str" : "21865822",
      "id" : 21865822
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELT",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 126, 140 ],
      "url" : "http:\/\/t.co\/nedYkVqMnC",
      "expanded_url" : "http:\/\/ow.ly\/oEJxz",
      "display_url" : "ow.ly\/oEJxz"
    } ]
  },
  "geo" : { },
  "id_str" : "377345667204542464",
  "text" : "RT @ELT_T2W: Read an extract from our ebook How To Write Vocabulary Presentations And Practice on @onestopenglish this month: http:\/\/t.co\/n\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Onestopenglish",
        "screen_name" : "onestopenglish",
        "indices" : [ 85, 100 ],
        "id_str" : "21865822",
        "id" : 21865822
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELT",
        "indices" : [ 136, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/nedYkVqMnC",
        "expanded_url" : "http:\/\/ow.ly\/oEJxz",
        "display_url" : "ow.ly\/oEJxz"
      } ]
    },
    "geo" : { },
    "id_str" : "376970999725826048",
    "text" : "Read an extract from our ebook How To Write Vocabulary Presentations And Practice on @onestopenglish this month: http:\/\/t.co\/nedYkVqMnC #ELT",
    "id" : 376970999725826048,
    "created_at" : "2013-09-09 07:31:04 +0000",
    "user" : {
      "name" : "ELT Teacher 2 Writer",
      "screen_name" : "ELT_T2W",
      "protected" : false,
      "id_str" : "427697599",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1675434441\/T2W_logo_normal.jpg",
      "id" : 427697599,
      "verified" : false
    }
  },
  "id" : 377345667204542464,
  "created_at" : "2013-09-10 08:19:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Keelty",
      "screen_name" : "keeltyc",
      "indices" : [ 3, 11 ],
      "id_str" : "20685759",
      "id" : 20685759
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/keeltyc\/status\/376808558475489282\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/qwH0HgUxrp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BTqxYysCUAAwiRp.jpg",
      "id_str" : "376808558320308224",
      "id" : 376808558320308224,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BTqxYysCUAAwiRp.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 451,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 128,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 385,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/qwH0HgUxrp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377343077536374784",
  "text" : "RT @keeltyc: Got thinking what Breaking Bad would look like in any other industrialized nation on Earth: http:\/\/t.co\/qwH0HgUxrp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/keeltyc\/status\/376808558475489282\/photo\/1",
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/qwH0HgUxrp",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BTqxYysCUAAwiRp.jpg",
        "id_str" : "376808558320308224",
        "id" : 376808558320308224,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BTqxYysCUAAwiRp.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 451,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 128,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 385,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/qwH0HgUxrp"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "376808558475489282",
    "text" : "Got thinking what Breaking Bad would look like in any other industrialized nation on Earth: http:\/\/t.co\/qwH0HgUxrp",
    "id" : 376808558475489282,
    "created_at" : "2013-09-08 20:45:35 +0000",
    "user" : {
      "name" : "Christopher Keelty",
      "screen_name" : "keeltyc",
      "protected" : false,
      "id_str" : "20685759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/757658373735276544\/xF1sTGT0_normal.jpg",
      "id" : 20685759,
      "verified" : false
    }
  },
  "id" : 377343077536374784,
  "created_at" : "2013-09-10 08:09:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/I6A1DoxvGb",
      "expanded_url" : "http:\/\/eflnotes.wordpress.com\/my-english-language-teacher\/",
      "display_url" : "eflnotes.wordpress.com\/my-english-lan\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377217274324611072",
  "text" : "My language teacher say she don't sin ... lol http:\/\/t.co\/I6A1DoxvGb",
  "id" : 377217274324611072,
  "created_at" : "2013-09-09 23:49:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angus B Grieve-Smith",
      "screen_name" : "grvsmth",
      "indices" : [ 0, 8 ],
      "id_str" : "22381639",
      "id" : 22381639
    }, {
      "name" : "AllThingsLinguistic",
      "screen_name" : "AllThingsLing",
      "indices" : [ 9, 23 ],
      "id_str" : "857291268",
      "id" : 857291268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377201948442628096",
  "geo" : { },
  "id_str" : "377207332477730816",
  "in_reply_to_user_id" : 22381639,
  "text" : "@grvsmth @AllThingsLing what about where elephant is not wearing but in the pyjamas at the same time that speaker is wearing them? tree 2?",
  "id" : 377207332477730816,
  "in_reply_to_status_id" : 377201948442628096,
  "created_at" : "2013-09-09 23:10:10 +0000",
  "in_reply_to_screen_name" : "grvsmth",
  "in_reply_to_user_id_str" : "22381639",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 73, 89 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/guqZ6SBSrV",
      "expanded_url" : "http:\/\/wp.me\/p67QB-15I",
      "display_url" : "wp.me\/p67QB-15I"
    } ]
  },
  "geo" : { },
  "id_str" : "377197969746845697",
  "text" : "What good is good grammar without good logic? http:\/\/t.co\/guqZ6SBSrV via @wordpressdotcom",
  "id" : 377197969746845697,
  "created_at" : "2013-09-09 22:32:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Brindle",
      "screen_name" : "AndrewBrindle2",
      "indices" : [ 73, 88 ],
      "id_str" : "358143205",
      "id" : 358143205
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/UHZC7VWGII",
      "expanded_url" : "http:\/\/wp.me\/p35kaI-1Y",
      "display_url" : "wp.me\/p35kaI-1Y"
    } ]
  },
  "geo" : { },
  "id_str" : "377111535056715776",
  "text" : "Analysing EDL Corpora Data Using WordWanderer http:\/\/t.co\/UHZC7VWGII via @AndrewBrindle2",
  "id" : 377111535056715776,
  "created_at" : "2013-09-09 16:49:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/baJRwDA4LD",
      "expanded_url" : "http:\/\/bit.ly\/18IkVdp",
      "display_url" : "bit.ly\/18IkVdp"
    } ]
  },
  "geo" : { },
  "id_str" : "377021209495339008",
  "text" : "Just had to read a descriptive article about some woman eating dogfood. Now I'm nauseous and hate my English teacher. http:\/\/t.co\/baJRwDA4LD",
  "id" : 377021209495339008,
  "created_at" : "2013-09-09 10:50:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    }, {
      "name" : "CreatEng Cafe",
      "screen_name" : "CreatEng",
      "indices" : [ 13, 22 ],
      "id_str" : "613877329",
      "id" : 613877329
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/4wIr9sUXzd",
      "expanded_url" : "http:\/\/corpus.mml.cam.ac.uk\/efcamdat\/index.php",
      "display_url" : "corpus.mml.cam.ac.uk\/efcamdat\/index\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "377004615943737345",
  "geo" : { },
  "id_str" : "377018735829057536",
  "in_reply_to_user_id" : 18602422,
  "text" : "@AnneHendler @CreatEng learners use \"boil\" &amp; 11 examples out of 64 uses of 'boil' is attempt at \"makes my blood boil\" http:\/\/t.co\/4wIr9sUXzd",
  "id" : 377018735829057536,
  "in_reply_to_status_id" : 377004615943737345,
  "created_at" : "2013-09-09 10:40:45 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    }, {
      "name" : "CreatEng Cafe",
      "screen_name" : "CreatEng",
      "indices" : [ 13, 22 ],
      "id_str" : "613877329",
      "id" : 613877329
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/IUDhtjwiH4",
      "expanded_url" : "http:\/\/corpus2.byu.edu\/glowbe\/?c=glowbe&q=25040595",
      "display_url" : "corpus2.byu.edu\/glowbe\/?c=glow\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "376996927977447424",
  "geo" : { },
  "id_str" : "377004615943737345",
  "in_reply_to_user_id" : 18602422,
  "text" : "@AnneHendler @CreatEng using GloWbE http:\/\/t.co\/IUDhtjwiH4, Canda, Singpre &amp; Philpines &gt; US use; Irlnd, Aus, NewZealnd, SthAfri &gt; Brtsh use",
  "id" : 377004615943737345,
  "in_reply_to_status_id" : 376996927977447424,
  "created_at" : "2013-09-09 09:44:39 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    }, {
      "name" : "CreatEng Cafe",
      "screen_name" : "CreatEng",
      "indices" : [ 13, 22 ],
      "id_str" : "613877329",
      "id" : 613877329
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/eF1WgbL0Te",
      "expanded_url" : "http:\/\/eflnotes.wordpress.com\/2013\/01\/02\/quick-cup-of-coca-bring-to-boil\/",
      "display_url" : "eflnotes.wordpress.com\/2013\/01\/02\/qui\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "376918213604306944",
  "geo" : { },
  "id_str" : "376996927977447424",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler @CreatEng http:\/\/t.co\/eF1WgbL0Te :)",
  "id" : 376996927977447424,
  "in_reply_to_status_id" : 376918213604306944,
  "created_at" : "2013-09-09 09:14:06 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/OUlL1PIRtU",
      "expanded_url" : "http:\/\/www.jonathan-cook.net\/blog\/2013-09-08\/propaganda-veiled-as-informed-commentary\/",
      "display_url" : "jonathan-cook.net\/blog\/2013-09-0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376792204536057857",
  "text" : "RT @johnwhilley: Great piece from J Cook: Propaganda veiled as informed commentary  http:\/\/t.co\/OUlL1PIRtU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/OUlL1PIRtU",
        "expanded_url" : "http:\/\/www.jonathan-cook.net\/blog\/2013-09-08\/propaganda-veiled-as-informed-commentary\/",
        "display_url" : "jonathan-cook.net\/blog\/2013-09-0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "376777958267957249",
    "text" : "Great piece from J Cook: Propaganda veiled as informed commentary  http:\/\/t.co\/OUlL1PIRtU",
    "id" : 376777958267957249,
    "created_at" : "2013-09-08 18:44:00 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 376792204536057857,
  "created_at" : "2013-09-08 19:40:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Alec Couros",
      "screen_name" : "courosa",
      "indices" : [ 3, 11 ],
      "id_str" : "739293",
      "id" : 739293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/8NTsjHu3QW",
      "expanded_url" : "http:\/\/pewinternet.org\/Reports\/2013\/Anonymity-online.aspx",
      "display_url" : "pewinternet.org\/Reports\/2013\/A\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376790996039634944",
  "text" : "RT @courosa: \"Anonymity, Privacy, and Security Online\" - survey results http:\/\/t.co\/8NTsjHu3QW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/8NTsjHu3QW",
        "expanded_url" : "http:\/\/pewinternet.org\/Reports\/2013\/Anonymity-online.aspx",
        "display_url" : "pewinternet.org\/Reports\/2013\/A\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "376731363598016514",
    "text" : "\"Anonymity, Privacy, and Security Online\" - survey results http:\/\/t.co\/8NTsjHu3QW",
    "id" : 376731363598016514,
    "created_at" : "2013-09-08 15:38:51 +0000",
    "user" : {
      "name" : "Dr. Alec Couros",
      "screen_name" : "courosa",
      "protected" : false,
      "id_str" : "739293",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/480186733221249027\/bzI2RIfo_normal.jpeg",
      "id" : 739293,
      "verified" : false
    }
  },
  "id" : 376790996039634944,
  "created_at" : "2013-09-08 19:35:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 3, 17 ],
      "id_str" : "25388528",
      "id" : 25388528
    }, {
      "name" : "Vim, Ph.D",
      "screen_name" : "Exhaust_Fumes",
      "indices" : [ 65, 79 ],
      "id_str" : "479673005",
      "id" : 479673005
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/Cbq8WMZlSe",
      "expanded_url" : "http:\/\/exhaustfumes.commons.mla.org\/2013\/09\/08\/what-professors-say\/",
      "display_url" : "exhaustfumes.commons.mla.org\/2013\/09\/08\/wha\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376790206537412608",
  "text" : "RT @audreywatters: What Professors Say http:\/\/t.co\/Cbq8WMZlSe by @Exhaust_Fumes (on classroom speech, performance, and students' \"my profes\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vim, Ph.D",
        "screen_name" : "Exhaust_Fumes",
        "indices" : [ 46, 60 ],
        "id_str" : "479673005",
        "id" : 479673005
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 20, 42 ],
        "url" : "http:\/\/t.co\/Cbq8WMZlSe",
        "expanded_url" : "http:\/\/exhaustfumes.commons.mla.org\/2013\/09\/08\/what-professors-say\/",
        "display_url" : "exhaustfumes.commons.mla.org\/2013\/09\/08\/wha\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "376787604404195328",
    "text" : "What Professors Say http:\/\/t.co\/Cbq8WMZlSe by @Exhaust_Fumes (on classroom speech, performance, and students' \"my professor\" tweets)",
    "id" : 376787604404195328,
    "created_at" : "2013-09-08 19:22:19 +0000",
    "user" : {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "protected" : false,
      "id_str" : "25388528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711668009723498496\/pauFZsdv_normal.jpg",
      "id" : 25388528,
      "verified" : false
    }
  },
  "id" : 376790206537412608,
  "created_at" : "2013-09-08 19:32:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/I6A1DoxvGb",
      "expanded_url" : "http:\/\/eflnotes.wordpress.com\/my-english-language-teacher\/",
      "display_url" : "eflnotes.wordpress.com\/my-english-lan\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376789194040803328",
  "text" : "[Still annoyed that my English teacher has put me in a seating plan with no one next to me] http:\/\/t.co\/I6A1DoxvGb",
  "id" : 376789194040803328,
  "created_at" : "2013-09-08 19:28:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Li-Shih Huang, PhD",
      "screen_name" : "AppLingProf",
      "indices" : [ 0, 12 ],
      "id_str" : "128714685",
      "id" : 128714685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376780460249989120",
  "geo" : { },
  "id_str" : "376782138080632832",
  "in_reply_to_user_id" : 128714685,
  "text" : "@AppLingProf is that a fish in your ear is a great read",
  "id" : 376782138080632832,
  "in_reply_to_status_id" : 376780460249989120,
  "created_at" : "2013-09-08 19:00:36 +0000",
  "in_reply_to_screen_name" : "AppLingProf",
  "in_reply_to_user_id_str" : "128714685",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    }, {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 17, 32 ],
      "id_str" : "285614027",
      "id" : 285614027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376730825032622080",
  "geo" : { },
  "id_str" : "376743107154305026",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin @AnthonyTeacher rofl, the real meaning of wtf!?",
  "id" : 376743107154305026,
  "in_reply_to_status_id" : 376730825032622080,
  "created_at" : "2013-09-08 16:25:30 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yolanda B. Schell",
      "screen_name" : "mattellman",
      "indices" : [ 0, 11 ],
      "id_str" : "725597315860434945",
      "id" : 725597315860434945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376655966411829248",
  "geo" : { },
  "id_str" : "376657967099035649",
  "in_reply_to_user_id" : 394987109,
  "text" : "@mattellman gonna give up for now, not even letting me browse Language Teaching journal",
  "id" : 376657967099035649,
  "in_reply_to_status_id" : 376655966411829248,
  "created_at" : "2013-09-08 10:47:11 +0000",
  "in_reply_to_screen_name" : "MatthewEllman",
  "in_reply_to_user_id_str" : "394987109",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yolanda B. Schell",
      "screen_name" : "mattellman",
      "indices" : [ 0, 11 ],
      "id_str" : "725597315860434945",
      "id" : 725597315860434945
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/376654460149170177\/photo\/1",
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/cv3FRS7CcT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BTolPGTCAAA3ryG.png",
      "id_str" : "376654460157558784",
      "id" : 376654460157558784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BTolPGTCAAA3ryG.png",
      "sizes" : [ {
        "h" : 900,
        "resize" : "fit",
        "w" : 1440
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 213,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/cv3FRS7CcT"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376653335241039872",
  "geo" : { },
  "id_str" : "376654460149170177",
  "in_reply_to_user_id" : 394987109,
  "text" : "@mattellman lol not seeing 3 boxes nevermind purple? i c this &gt; http:\/\/t.co\/cv3FRS7CcT",
  "id" : 376654460149170177,
  "in_reply_to_status_id" : 376653335241039872,
  "created_at" : "2013-09-08 10:33:16 +0000",
  "in_reply_to_screen_name" : "MatthewEllman",
  "in_reply_to_user_id_str" : "394987109",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yolanda B. Schell",
      "screen_name" : "mattellman",
      "indices" : [ 0, 11 ],
      "id_str" : "725597315860434945",
      "id" : 725597315860434945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376651159596834816",
  "geo" : { },
  "id_str" : "376652727394127872",
  "in_reply_to_user_id" : 394987109,
  "text" : "@mattellman sorry cant see link u r referring to  in that page?",
  "id" : 376652727394127872,
  "in_reply_to_status_id" : 376651159596834816,
  "created_at" : "2013-09-08 10:26:22 +0000",
  "in_reply_to_screen_name" : "MatthewEllman",
  "in_reply_to_user_id_str" : "394987109",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yolanda B. Schell",
      "screen_name" : "mattellman",
      "indices" : [ 0, 11 ],
      "id_str" : "725597315860434945",
      "id" : 725597315860434945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376648516484861952",
  "geo" : { },
  "id_str" : "376650238452178944",
  "in_reply_to_user_id" : 18602422,
  "text" : "@mattellman hmm registered and still can't see nowt :\/",
  "id" : 376650238452178944,
  "in_reply_to_status_id" : 376648516484861952,
  "created_at" : "2013-09-08 10:16:29 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yolanda B. Schell",
      "screen_name" : "mattellman",
      "indices" : [ 0, 11 ],
      "id_str" : "725597315860434945",
      "id" : 725597315860434945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376645423542181888",
  "geo" : { },
  "id_str" : "376648516484861952",
  "in_reply_to_user_id" : 394987109,
  "text" : "@mattellman do you have to have an account to see page?",
  "id" : 376648516484861952,
  "in_reply_to_status_id" : 376645423542181888,
  "created_at" : "2013-09-08 10:09:38 +0000",
  "in_reply_to_screen_name" : "MatthewEllman",
  "in_reply_to_user_id_str" : "394987109",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yolanda B. Schell",
      "screen_name" : "mattellman",
      "indices" : [ 0, 11 ],
      "id_str" : "725597315860434945",
      "id" : 725597315860434945
    }, {
      "name" : "CUP Linguistics",
      "screen_name" : "CambUP_LangLing",
      "indices" : [ 12, 28 ],
      "id_str" : "117051544",
      "id" : 117051544
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376641755350724609",
  "geo" : { },
  "id_str" : "376644324219318275",
  "in_reply_to_user_id" : 394987109,
  "text" : "@mattellman @CambUP_LangLing looks like that page is borked?",
  "id" : 376644324219318275,
  "in_reply_to_status_id" : 376641755350724609,
  "created_at" : "2013-09-08 09:52:59 +0000",
  "in_reply_to_screen_name" : "MatthewEllman",
  "in_reply_to_user_id_str" : "394987109",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 62, 78 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/Bk5MJLs8G0",
      "expanded_url" : "http:\/\/wp.me\/p1RBAA-aI",
      "display_url" : "wp.me\/p1RBAA-aI"
    } ]
  },
  "geo" : { },
  "id_str" : "376625987053559810",
  "text" : "Time to try a new publishing model http:\/\/t.co\/Bk5MJLs8G0 via @wordpressdotcom",
  "id" : 376625987053559810,
  "created_at" : "2013-09-08 08:40:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Wolff",
      "screen_name" : "billwolff",
      "indices" : [ 106, 116 ],
      "id_str" : "2493291",
      "id" : 2493291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/I6A1DoxvGb",
      "expanded_url" : "http:\/\/eflnotes.wordpress.com\/my-english-language-teacher\/",
      "display_url" : "eflnotes.wordpress.com\/my-english-lan\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376505596519800832",
  "text" : "my english teacher\/my language teacher\/my english language teacher - say what?! http:\/\/t.co\/I6A1DoxvGb HT @billwolff",
  "id" : 376505596519800832,
  "created_at" : "2013-09-08 00:41:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil C Ford",
      "screen_name" : "neilcford",
      "indices" : [ 0, 10 ],
      "id_str" : "170413092",
      "id" : 170413092
    }, {
      "name" : "Doug Belshaw",
      "screen_name" : "dajbelshaw",
      "indices" : [ 11, 22 ],
      "id_str" : "764365",
      "id" : 764365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376463966274596864",
  "geo" : { },
  "id_str" : "376470941464686592",
  "in_reply_to_user_id" : 170413092,
  "text" : "@neilcford @dajbelshaw usb sticks are writeable :0",
  "id" : 376470941464686592,
  "in_reply_to_status_id" : 376463966274596864,
  "created_at" : "2013-09-07 22:24:01 +0000",
  "in_reply_to_screen_name" : "neilcford",
  "in_reply_to_user_id_str" : "170413092",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Lee",
      "screen_name" : "desktopenglish",
      "indices" : [ 0, 15 ],
      "id_str" : "345925613",
      "id" : 345925613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376445424803913729",
  "geo" : { },
  "id_str" : "376448527645175808",
  "in_reply_to_user_id" : 345925613,
  "text" : "@desktopenglish certainly produced its fair share of nobs :0, and that Russian spokesperson frontrunner for 2013 diplomatic troll award :=)",
  "id" : 376448527645175808,
  "in_reply_to_status_id" : 376445424803913729,
  "created_at" : "2013-09-07 20:54:57 +0000",
  "in_reply_to_screen_name" : "desktopenglish",
  "in_reply_to_user_id_str" : "345925613",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Pride",
      "screen_name" : "ThomasPride",
      "indices" : [ 114, 126 ],
      "id_str" : "385867551",
      "id" : 385867551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/z8akrOmgft",
      "expanded_url" : "http:\/\/wp.me\/p1U04a-5eF",
      "display_url" : "wp.me\/p1U04a-5eF"
    } ]
  },
  "geo" : { },
  "id_str" : "376291487467593729",
  "text" : "Million of UK's lowest paid employees to be classed as 'not wretched enough', says DWP http:\/\/t.co\/z8akrOmgft via @ThomasPride",
  "id" : 376291487467593729,
  "created_at" : "2013-09-07 10:30:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "researched2013",
      "indices" : [ 57, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 123, 140 ],
      "url" : "https:\/\/t.co\/UupGsCjKoT",
      "expanded_url" : "https:\/\/new.livestream.com\/L4L\/education",
      "display_url" : "new.livestream.com\/L4L\/education"
    } ]
  },
  "geo" : { },
  "id_str" : "376285155016450048",
  "text" : "RT @researchED2013: Don't forget if you can't make it to #researched2013 you can follow us live streaming the keynotes at  https:\/\/t.co\/Uup\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "researched2013",
        "indices" : [ 37, 52 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/UupGsCjKoT",
        "expanded_url" : "https:\/\/new.livestream.com\/L4L\/education",
        "display_url" : "new.livestream.com\/L4L\/education"
      } ]
    },
    "geo" : { },
    "id_str" : "376117405459939328",
    "text" : "Don't forget if you can't make it to #researched2013 you can follow us live streaming the keynotes at  https:\/\/t.co\/UupGsCjKoT",
    "id" : 376117405459939328,
    "created_at" : "2013-09-06 22:59:12 +0000",
    "user" : {
      "name" : "researchED",
      "screen_name" : "researchED1",
      "protected" : false,
      "id_str" : "1289037060",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3452207574\/b7eaef9bcdf06ec1fbc881d50a3f920c_normal.png",
      "id" : 1289037060,
      "verified" : false
    }
  },
  "id" : 376285155016450048,
  "created_at" : "2013-09-07 10:05:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 79, 87 ]
    }, {
      "text" : "phonesinclass",
      "indices" : [ 88, 102 ]
    }, {
      "text" : "tesol",
      "indices" : [ 103, 109 ]
    }, {
      "text" : "tefl",
      "indices" : [ 110, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/hiGzSfxXSM",
      "expanded_url" : "http:\/\/dogmediaries.wordpress.com\/2013\/09\/06\/no-more-nomophobia-using-smartphones-in-the-class\/",
      "display_url" : "dogmediaries.wordpress.com\/2013\/09\/06\/no-\u2026"
    }, {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/E7uZJQeWEA",
      "expanded_url" : "http:\/\/giaklamata.blogspot.fr\/2013\/09\/why-smartphones-piss-me-off.html",
      "display_url" : "giaklamata.blogspot.fr\/2013\/09\/why-sm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376280784367144960",
  "text" : "Hanging on http:\/\/t.co\/hiGzSfxXSM or up the telephones? http:\/\/t.co\/E7uZJQeWEA #eltchat #phonesinclass #tesol #tefl",
  "id" : 376280784367144960,
  "created_at" : "2013-09-07 09:48:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Rayson",
      "screen_name" : "perayson",
      "indices" : [ 3, 12 ],
      "id_str" : "263108959",
      "id" : 263108959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/kL4sBLuC92",
      "expanded_url" : "http:\/\/bbc.in\/1dEn9An",
      "display_url" : "bbc.in\/1dEn9An"
    } ]
  },
  "geo" : { },
  "id_str" : "376278506079940608",
  "text" : "RT @perayson: BBC News - Jonathon Fletcher: forgotten father of the search engine http:\/\/t.co\/kL4sBLuC92",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/kL4sBLuC92",
        "expanded_url" : "http:\/\/bbc.in\/1dEn9An",
        "display_url" : "bbc.in\/1dEn9An"
      } ]
    },
    "geo" : { },
    "id_str" : "376228664897449984",
    "text" : "BBC News - Jonathon Fletcher: forgotten father of the search engine http:\/\/t.co\/kL4sBLuC92",
    "id" : 376228664897449984,
    "created_at" : "2013-09-07 06:21:18 +0000",
    "user" : {
      "name" : "Paul Rayson",
      "screen_name" : "perayson",
      "protected" : false,
      "id_str" : "263108959",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/490485533911445505\/BNOoOchF_normal.jpeg",
      "id" : 263108959,
      "verified" : false
    }
  },
  "id" : 376278506079940608,
  "created_at" : "2013-09-07 09:39:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "vaclav",
      "screen_name" : "vaclavbrezina",
      "indices" : [ 0, 14 ],
      "id_str" : "1201576646",
      "id" : 1201576646
    }, {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "indices" : [ 15, 27 ],
      "id_str" : "849729062",
      "id" : 849729062
    }, {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 28, 39 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376056109770891264",
  "geo" : { },
  "id_str" : "376062345589448704",
  "in_reply_to_user_id" : 1201576646,
  "text" : "@vaclavbrezina @TonyMcEnery @lexicoloco thnks, is there a ref for browne's paper?",
  "id" : 376062345589448704,
  "in_reply_to_status_id" : 376056109770891264,
  "created_at" : "2013-09-06 19:20:24 +0000",
  "in_reply_to_screen_name" : "vaclavbrezina",
  "in_reply_to_user_id_str" : "1201576646",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "indices" : [ 0, 12 ],
      "id_str" : "849729062",
      "id" : 849729062
    }, {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 13, 24 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376050580822982656",
  "geo" : { },
  "id_str" : "376052956530884608",
  "in_reply_to_user_id" : 849729062,
  "text" : "@TonyMcEnery @lexicoloco what are partial sequences?",
  "id" : 376052956530884608,
  "in_reply_to_status_id" : 376050580822982656,
  "created_at" : "2013-09-06 18:43:06 +0000",
  "in_reply_to_screen_name" : "TonyMcEnery",
  "in_reply_to_user_id_str" : "849729062",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George Lakoff",
      "screen_name" : "GeorgeLakoff",
      "indices" : [ 0, 13 ],
      "id_str" : "237637694",
      "id" : 237637694
    }, {
      "name" : "Angus B Grieve-Smith",
      "screen_name" : "grvsmth",
      "indices" : [ 14, 22 ],
      "id_str" : "22381639",
      "id" : 22381639
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376023816754831360",
  "geo" : { },
  "id_str" : "376051438448689152",
  "in_reply_to_user_id" : 237637694,
  "text" : "@georgelakoff @grvsmth is there a metaphor for Unrealistic-beliefs-in-good-faith-from-empires? :\/",
  "id" : 376051438448689152,
  "in_reply_to_status_id" : 376023816754831360,
  "created_at" : "2013-09-06 18:37:04 +0000",
  "in_reply_to_screen_name" : "GeorgeLakoff",
  "in_reply_to_user_id_str" : "237637694",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376046646938714112",
  "geo" : { },
  "id_str" : "376049874359173120",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson link broken, good name though :)",
  "id" : 376049874359173120,
  "in_reply_to_status_id" : 376046646938714112,
  "created_at" : "2013-09-06 18:30:51 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Yau",
      "screen_name" : "flowingdata",
      "indices" : [ 3, 15 ],
      "id_str" : "14109167",
      "id" : 14109167
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/flowingdata\/status\/376038372629696512\/photo\/1",
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/rFdy98IsJs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BTf06ElCQAEV7OJ.png",
      "id_str" : "376038372407394305",
      "id" : 376038372407394305,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BTf06ElCQAEV7OJ.png",
      "sizes" : [ {
        "h" : 917,
        "resize" : "fit",
        "w" : 717
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 917,
        "resize" : "fit",
        "w" : 717
      }, {
        "h" : 435,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 767,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/rFdy98IsJs"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "376047461896183808",
  "text" : "RT @flowingdata: You have to accept that student answers are beyond your understanding sometimes http:\/\/t.co\/rFdy98IsJs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/flowingdata\/status\/376038372629696512\/photo\/1",
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/rFdy98IsJs",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BTf06ElCQAEV7OJ.png",
        "id_str" : "376038372407394305",
        "id" : 376038372407394305,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BTf06ElCQAEV7OJ.png",
        "sizes" : [ {
          "h" : 917,
          "resize" : "fit",
          "w" : 717
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 917,
          "resize" : "fit",
          "w" : 717
        }, {
          "h" : 435,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 767,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/rFdy98IsJs"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "376038372629696512",
    "text" : "You have to accept that student answers are beyond your understanding sometimes http:\/\/t.co\/rFdy98IsJs",
    "id" : 376038372629696512,
    "created_at" : "2013-09-06 17:45:09 +0000",
    "user" : {
      "name" : "Nathan Yau",
      "screen_name" : "flowingdata",
      "protected" : false,
      "id_str" : "14109167",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/585826994526355456\/R3tYT5Kj_normal.png",
      "id" : 14109167,
      "verified" : false
    }
  },
  "id" : 376047461896183808,
  "created_at" : "2013-09-06 18:21:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    }, {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "indices" : [ 12, 28 ],
      "id_str" : "1326508478",
      "id" : 1326508478
    }, {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "indices" : [ 29, 41 ],
      "id_str" : "849729062",
      "id" : 849729062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376038916798693376",
  "geo" : { },
  "id_str" : "376043638490288128",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco @CorpusSocialSci @TonyMcEnery hmm still strange to exclude days\/months?",
  "id" : 376043638490288128,
  "in_reply_to_status_id" : 376038916798693376,
  "created_at" : "2013-09-06 18:06:04 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    }, {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "indices" : [ 12, 28 ],
      "id_str" : "1326508478",
      "id" : 1326508478
    }, {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "indices" : [ 29, 41 ],
      "id_str" : "849729062",
      "id" : 849729062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376038916798693376",
  "geo" : { },
  "id_str" : "376041177092337665",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco @CorpusSocialSci @TonyMcEnery another int diff lanc list - \"a lot\/lots of\", \"according to\", \"kind of\"; word class is useful also",
  "id" : 376041177092337665,
  "in_reply_to_status_id" : 376038916798693376,
  "created_at" : "2013-09-06 17:56:17 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "indices" : [ 0, 16 ],
      "id_str" : "1326508478",
      "id" : 1326508478
    }, {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "indices" : [ 17, 29 ],
      "id_str" : "849729062",
      "id" : 849729062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376026343487442944",
  "geo" : { },
  "id_str" : "376036412736286720",
  "in_reply_to_user_id" : 18602422,
  "text" : "@CorpusSocialSci @TonyMcEnery i mean the other list incl ~27mill spoken corpus (CEC) yet no days\/months in their list?",
  "id" : 376036412736286720,
  "in_reply_to_status_id" : 376026343487442944,
  "created_at" : "2013-09-06 17:37:21 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Patsko",
      "screen_name" : "lauraahaha",
      "indices" : [ 0, 11 ],
      "id_str" : "97957137",
      "id" : 97957137
    }, {
      "name" : "Natallia Novikava",
      "screen_name" : "Natashetta",
      "indices" : [ 12, 23 ],
      "id_str" : "56308635",
      "id" : 56308635
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "375931985535205376",
  "geo" : { },
  "id_str" : "376028263581118464",
  "in_reply_to_user_id" : 97957137,
  "text" : "@lauraahaha @Natashetta thks that works",
  "id" : 376028263581118464,
  "in_reply_to_status_id" : 375931985535205376,
  "created_at" : "2013-09-06 17:04:58 +0000",
  "in_reply_to_screen_name" : "lauraahaha",
  "in_reply_to_user_id_str" : "97957137",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "indices" : [ 0, 16 ],
      "id_str" : "1326508478",
      "id" : 1326508478
    }, {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "indices" : [ 17, 29 ],
      "id_str" : "849729062",
      "id" : 849729062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/LbrXo8FSaJ",
      "expanded_url" : "http:\/\/www.newgeneralservicelist.org\/",
      "display_url" : "newgeneralservicelist.org"
    } ]
  },
  "in_reply_to_status_id_str" : "375969096984035328",
  "geo" : { },
  "id_str" : "376026343487442944",
  "in_reply_to_user_id" : 1326508478,
  "text" : "@CorpusSocialSci @TonyMcEnery a qk comparison with  http:\/\/t.co\/LbrXo8FSaJ shws first list has days\/months  - due to written bias of corpus?",
  "id" : 376026343487442944,
  "in_reply_to_status_id" : 375969096984035328,
  "created_at" : "2013-09-06 16:57:21 +0000",
  "in_reply_to_screen_name" : "CorpusSocialSci",
  "in_reply_to_user_id_str" : "1326508478",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 57, 73 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/CsphiIASRS",
      "expanded_url" : "http:\/\/wp.me\/p2KE8s-3Py",
      "display_url" : "wp.me\/p2KE8s-3Py"
    } ]
  },
  "geo" : { },
  "id_str" : "375745150212780032",
  "text" : "Free PDF e-books from TESL-EJ http:\/\/t.co\/CsphiIASRS via @wordpressdotcom",
  "id" : 375745150212780032,
  "created_at" : "2013-09-05 22:19:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angus B Grieve-Smith",
      "screen_name" : "grvsmth",
      "indices" : [ 3, 11 ],
      "id_str" : "22381639",
      "id" : 22381639
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/3fACyAuTKu",
      "expanded_url" : "http:\/\/grieve-smith.com\/blog\/2013\/09\/on-advising-descriptively\/",
      "display_url" : "grieve-smith.com\/blog\/2013\/09\/o\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375665893960712192",
  "text" : "RT @grvsmth: New post: A descriptivist respects standards of good English? It all depends on your definition of \"descriptivist.\" http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/3fACyAuTKu",
        "expanded_url" : "http:\/\/grieve-smith.com\/blog\/2013\/09\/on-advising-descriptively\/",
        "display_url" : "grieve-smith.com\/blog\/2013\/09\/o\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "375648094584840192",
    "text" : "New post: A descriptivist respects standards of good English? It all depends on your definition of \"descriptivist.\" http:\/\/t.co\/3fACyAuTKu",
    "id" : 375648094584840192,
    "created_at" : "2013-09-05 15:54:19 +0000",
    "user" : {
      "name" : "Angus B Grieve-Smith",
      "screen_name" : "grvsmth",
      "protected" : false,
      "id_str" : "22381639",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/94827231\/portrait_normal.png",
      "id" : 22381639,
      "verified" : false
    }
  },
  "id" : 375665893960712192,
  "created_at" : "2013-09-05 17:05:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jo Sayers",
      "screen_name" : "jo_sayers",
      "indices" : [ 11, 21 ],
      "id_str" : "87176766",
      "id" : 87176766
    }, {
      "name" : "Shaunwilden",
      "screen_name" : "Shaunwilden",
      "indices" : [ 22, 34 ],
      "id_str" : "15350512",
      "id" : 15350512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375609483092688897",
  "text" : "@mikejhldn @jo_sayers @Shaunwilden tested logged in Google and logged out - works in both",
  "id" : 375609483092688897,
  "created_at" : "2013-09-05 13:20:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NPR's Code Switch",
      "screen_name" : "NPRCodeSwitch",
      "indices" : [ 3, 17 ],
      "id_str" : "1117836660",
      "id" : 1117836660
    }, {
      "name" : "Gene Demby",
      "screen_name" : "GeeDee215",
      "indices" : [ 22, 32 ],
      "id_str" : "87359651",
      "id" : 87359651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 124, 140 ],
      "url" : "http:\/\/t.co\/uT00IE9cdv",
      "expanded_url" : "http:\/\/bit.ly\/14tKtsp",
      "display_url" : "bit.ly\/14tKtsp"
    } ]
  },
  "geo" : { },
  "id_str" : "375609175067213824",
  "text" : "RT @NPRCodeSwitch: RT @GeeDee215: angry asian man: Aziz Ansari takes down racist, homophobic jokes at roast of James Franco http:\/\/t.co\/uT0\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gene Demby",
        "screen_name" : "GeeDee215",
        "indices" : [ 3, 13 ],
        "id_str" : "87359651",
        "id" : 87359651
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/uT00IE9cdv",
        "expanded_url" : "http:\/\/bit.ly\/14tKtsp",
        "display_url" : "bit.ly\/14tKtsp"
      } ]
    },
    "geo" : { },
    "id_str" : "375607631454277632",
    "text" : "RT @GeeDee215: angry asian man: Aziz Ansari takes down racist, homophobic jokes at roast of James Franco http:\/\/t.co\/uT00IE9cdv",
    "id" : 375607631454277632,
    "created_at" : "2013-09-05 13:13:32 +0000",
    "user" : {
      "name" : "NPR's Code Switch",
      "screen_name" : "NPRCodeSwitch",
      "protected" : false,
      "id_str" : "1117836660",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/735827859391062016\/Wubpu46s_normal.jpg",
      "id" : 1117836660,
      "verified" : true
    }
  },
  "id" : 375609175067213824,
  "created_at" : "2013-09-05 13:19:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375601445048815616",
  "text" : "@mikejhldn \/thumbs up\/",
  "id" : 375601445048815616,
  "created_at" : "2013-09-05 12:48:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Patsko",
      "screen_name" : "lauraahaha",
      "indices" : [ 0, 11 ],
      "id_str" : "97957137",
      "id" : 97957137
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "375579907189141504",
  "geo" : { },
  "id_str" : "375585721009971200",
  "in_reply_to_user_id" : 97957137,
  "text" : "@lauraahaha hi can't seem to load the prezi, is it just me?",
  "id" : 375585721009971200,
  "in_reply_to_status_id" : 375579907189141504,
  "created_at" : "2013-09-05 11:46:28 +0000",
  "in_reply_to_screen_name" : "lauraahaha",
  "in_reply_to_user_id_str" : "97957137",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Burr Settles",
      "screen_name" : "burrsettles",
      "indices" : [ 3, 15 ],
      "id_str" : "125822301",
      "id" : 125822301
    }, {
      "name" : "Head Squeeze",
      "screen_name" : "TheHeadSqueeze",
      "indices" : [ 77, 92 ],
      "id_str" : "960480703",
      "id" : 960480703
    }, {
      "name" : "Hannah Fry",
      "screen_name" : "FryRsquared",
      "indices" : [ 139, 140 ],
      "id_str" : "273375532",
      "id" : 273375532
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BBC",
      "indices" : [ 70, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/TgtcpCm5Q8",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=mF4q_K6YsjE",
      "display_url" : "youtube.com\/watch?v=mF4q_K\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375369160361902080",
  "text" : "RT @burrsettles: My Geek\/Nerd Twitter analysis got a sexy makeover on #BBC's @TheHeadSqueeze (segment ~3:00): http:\/\/t.co\/TgtcpCm5Q8 \u2014via @\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Head Squeeze",
        "screen_name" : "TheHeadSqueeze",
        "indices" : [ 60, 75 ],
        "id_str" : "960480703",
        "id" : 960480703
      }, {
        "name" : "Hannah Fry",
        "screen_name" : "FryRsquared",
        "indices" : [ 121, 133 ],
        "id_str" : "273375532",
        "id" : 273375532
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BBC",
        "indices" : [ 53, 57 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/TgtcpCm5Q8",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=mF4q_K6YsjE",
        "display_url" : "youtube.com\/watch?v=mF4q_K\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "375348667751755776",
    "text" : "My Geek\/Nerd Twitter analysis got a sexy makeover on #BBC's @TheHeadSqueeze (segment ~3:00): http:\/\/t.co\/TgtcpCm5Q8 \u2014via @FryRsquared",
    "id" : 375348667751755776,
    "created_at" : "2013-09-04 20:04:30 +0000",
    "user" : {
      "name" : "Burr Settles",
      "screen_name" : "burrsettles",
      "protected" : false,
      "id_str" : "125822301",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/588411093854396417\/iyM5tOYr_normal.jpg",
      "id" : 125822301,
      "verified" : false
    }
  },
  "id" : 375369160361902080,
  "created_at" : "2013-09-04 21:25:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pirate Box",
      "screen_name" : "Pirate_Box",
      "indices" : [ 0, 11 ],
      "id_str" : "528739483",
      "id" : 528739483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/HBeuk8boOu",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-9q",
      "display_url" : "wp.me\/pgHyE-9q"
    } ]
  },
  "geo" : { },
  "id_str" : "375363733456834561",
  "in_reply_to_user_id" : 528739483,
  "text" : "@Pirate_Box slu :) pour info pour l'utilisier PB en class voir http:\/\/t.co\/HBeuk8boOu",
  "id" : 375363733456834561,
  "created_at" : "2013-09-04 21:04:22 +0000",
  "in_reply_to_screen_name" : "Pirate_Box",
  "in_reply_to_user_id_str" : "528739483",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Rei",
      "screen_name" : "Charlesrei1",
      "indices" : [ 3, 15 ],
      "id_str" : "464454382",
      "id" : 464454382
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "besig",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/OaHuqha3Ey",
      "expanded_url" : "http:\/\/businessenglishideas.blogspot.de\/2013\/09\/i-only-have-one-lesson-plan.html",
      "display_url" : "businessenglishideas.blogspot.de\/2013\/09\/i-only\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375322694570770432",
  "text" : "RT @Charlesrei1: I apologize to the lesson plan seekers, I only have one lesson plan http:\/\/t.co\/OaHuqha3Ey is fits for every class I have.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "besig",
        "indices" : [ 123, 129 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/OaHuqha3Ey",
        "expanded_url" : "http:\/\/businessenglishideas.blogspot.de\/2013\/09\/i-only-have-one-lesson-plan.html",
        "display_url" : "businessenglishideas.blogspot.de\/2013\/09\/i-only\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "375312446983921664",
    "text" : "I apologize to the lesson plan seekers, I only have one lesson plan http:\/\/t.co\/OaHuqha3Ey is fits for every class I have. #besig",
    "id" : 375312446983921664,
    "created_at" : "2013-09-04 17:40:34 +0000",
    "user" : {
      "name" : "Charles Rei",
      "screen_name" : "Charlesrei1",
      "protected" : false,
      "id_str" : "464454382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461561508057468928\/BA8otRW0_normal.jpeg",
      "id" : 464454382,
      "verified" : false
    }
  },
  "id" : 375322694570770432,
  "created_at" : "2013-09-04 18:21:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Willingham",
      "screen_name" : "DTWillingham",
      "indices" : [ 3, 16 ],
      "id_str" : "84619537",
      "id" : 84619537
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "history",
      "indices" : [ 61, 69 ]
    }, {
      "text" : "UKEdchat",
      "indices" : [ 108, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/y76pmffv4P",
      "expanded_url" : "http:\/\/kindred.stanford.edu",
      "display_url" : "kindred.stanford.edu"
    } ]
  },
  "geo" : { },
  "id_str" : "375244549087440896",
  "text" : "RT @DTWillingham: How British elite are related. Teachers of #history, poss. useful? http:\/\/t.co\/y76pmffv4P #UKEdchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "history",
        "indices" : [ 43, 51 ]
      }, {
        "text" : "UKEdchat",
        "indices" : [ 90, 99 ]
      } ],
      "urls" : [ {
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/y76pmffv4P",
        "expanded_url" : "http:\/\/kindred.stanford.edu",
        "display_url" : "kindred.stanford.edu"
      } ]
    },
    "geo" : { },
    "id_str" : "375198622519795712",
    "text" : "How British elite are related. Teachers of #history, poss. useful? http:\/\/t.co\/y76pmffv4P #UKEdchat",
    "id" : 375198622519795712,
    "created_at" : "2013-09-04 10:08:17 +0000",
    "user" : {
      "name" : "Daniel Willingham",
      "screen_name" : "DTWillingham",
      "protected" : false,
      "id_str" : "84619537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1815678310\/Daniel_Willingham_Color_lowres_normal.JPG",
      "id" : 84619537,
      "verified" : false
    }
  },
  "id" : 375244549087440896,
  "created_at" : "2013-09-04 13:10:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Pride",
      "screen_name" : "ThomasPride",
      "indices" : [ 105, 117 ],
      "id_str" : "385867551",
      "id" : 385867551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/ymktXexBw4",
      "expanded_url" : "http:\/\/wp.me\/p1U04a-5dx",
      "display_url" : "wp.me\/p1U04a-5dx"
    } ]
  },
  "geo" : { },
  "id_str" : "375194935202283520",
  "text" : "Putin under pressure to drop Assad as evidence mounts Syrian President is gay http:\/\/t.co\/ymktXexBw4 via @ThomasPride",
  "id" : 375194935202283520,
  "created_at" : "2013-09-04 09:53:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Blond",
      "screen_name" : "BillsEnglish",
      "indices" : [ 0, 13 ],
      "id_str" : "1225932950",
      "id" : 1225932950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "375053013280239616",
  "geo" : { },
  "id_str" : "375053889420013568",
  "in_reply_to_user_id" : 1225932950,
  "text" : "@BillsEnglish ICEweb is good for getting online text not so for analysis like AntConc; thanks for RT :)",
  "id" : 375053889420013568,
  "in_reply_to_status_id" : 375053013280239616,
  "created_at" : "2013-09-04 00:33:10 +0000",
  "in_reply_to_screen_name" : "BillsEnglish",
  "in_reply_to_user_id_str" : "1225932950",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 81, 89 ]
    }, {
      "text" : "corpuslinguistics",
      "indices" : [ 90, 108 ]
    }, {
      "text" : "tefl",
      "indices" : [ 109, 114 ]
    }, {
      "text" : "esl",
      "indices" : [ 115, 119 ]
    }, {
      "text" : "efl",
      "indices" : [ 120, 124 ]
    }, {
      "text" : "tesol",
      "indices" : [ 125, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/enCM1X8qBQ",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-G2",
      "display_url" : "wp.me\/pgHyE-G2"
    } ]
  },
  "geo" : { },
  "id_str" : "375049310460604416",
  "text" : "screen shots avalanche! Building your own corpus - ICEweb http:\/\/t.co\/enCM1X8qBQ #eltchat #corpuslinguistics #tefl #esl #efl #tesol",
  "id" : 375049310460604416,
  "created_at" : "2013-09-04 00:14:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 78, 86 ]
    }, {
      "text" : "efl",
      "indices" : [ 87, 91 ]
    }, {
      "text" : "tefl",
      "indices" : [ 92, 97 ]
    }, {
      "text" : "tesol",
      "indices" : [ 98, 104 ]
    }, {
      "text" : "esl",
      "indices" : [ 105, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/WEXThg3bjP",
      "expanded_url" : "http:\/\/engineeringasaforeignlanguage.blogspot.com\/2013\/09\/news-articles-in-levels.html?spref=tw",
      "display_url" : "\u2026eeringasaforeignlanguage.blogspot.com\/2013\/09\/news-a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374945499419140097",
  "text" : "Teaching English to Engineers: News articles in levels http:\/\/t.co\/WEXThg3bjP #eltchat #efl #tefl #tesol #esl",
  "id" : 374945499419140097,
  "created_at" : "2013-09-03 17:22:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jersus Colmenares L.",
      "screen_name" : "jjcolmenaresl",
      "indices" : [ 59, 73 ],
      "id_str" : "195735983",
      "id" : 195735983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/g343aNFvj0",
      "expanded_url" : "http:\/\/www.hngn.com\/articles\/11460\/20130902\/automated-conversation-coach-m-t-researchers-create-software-simulates-real.htm",
      "display_url" : "hngn.com\/articles\/11460\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374938980610883584",
  "text" : "My Automated Conversation coach http:\/\/t.co\/g343aNFvj0 h\/t @jjcolmenaresl",
  "id" : 374938980610883584,
  "created_at" : "2013-09-03 16:56:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShareThis",
      "screen_name" : "ShareThis",
      "indices" : [ 60, 70 ],
      "id_str" : "14116807",
      "id" : 14116807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/73QJ7VG4li",
      "expanded_url" : "http:\/\/shar.es\/zPczK",
      "display_url" : "shar.es\/zPczK"
    } ]
  },
  "geo" : { },
  "id_str" : "374927585458667521",
  "text" : "English Words with Welsh Origins http:\/\/t.co\/73QJ7VG4li via @sharethis",
  "id" : 374927585458667521,
  "created_at" : "2013-09-03 16:11:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Timothy Tate",
      "screen_name" : "Timothy_Tate",
      "indices" : [ 0, 13 ],
      "id_str" : "1084531170",
      "id" : 1084531170
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374861576504754176",
  "geo" : { },
  "id_str" : "374866559665049600",
  "in_reply_to_user_id" : 1084531170,
  "text" : "@Timothy_Tate am sure that backdrop played a part  :)",
  "id" : 374866559665049600,
  "in_reply_to_status_id" : 374861576504754176,
  "created_at" : "2013-09-03 12:08:47 +0000",
  "in_reply_to_screen_name" : "Timothy_Tate",
  "in_reply_to_user_id_str" : "1084531170",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Willingham",
      "screen_name" : "DTWillingham",
      "indices" : [ 3, 16 ],
      "id_str" : "84619537",
      "id" : 84619537
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EdTech",
      "indices" : [ 130, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/mCXIo2WwI4",
      "expanded_url" : "http:\/\/www.sciencedirect.com\/science?_ob=GatewayURL&_method=citationSearch&_urlVersion=4&_origin=SDVIALERTHTML&_version=1&_piikey=S0272-7757%2813%2900103-9&md5=bdd47e25b5da7ec4b7e0c07e7e868611&alertKey=2013244",
      "display_url" : "sciencedirect.com\/science?_ob=Ga\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374857011193597952",
  "text" : "RT @DTWillingham: Online learning leads to worse outcomes (persistence and grades) in large college study. http:\/\/t.co\/mCXIo2WwI4 #EdTech",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EdTech",
        "indices" : [ 112, 119 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/mCXIo2WwI4",
        "expanded_url" : "http:\/\/www.sciencedirect.com\/science?_ob=GatewayURL&_method=citationSearch&_urlVersion=4&_origin=SDVIALERTHTML&_version=1&_piikey=S0272-7757%2813%2900103-9&md5=bdd47e25b5da7ec4b7e0c07e7e868611&alertKey=2013244",
        "display_url" : "sciencedirect.com\/science?_ob=Ga\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "374449535931531264",
    "text" : "Online learning leads to worse outcomes (persistence and grades) in large college study. http:\/\/t.co\/mCXIo2WwI4 #EdTech",
    "id" : 374449535931531264,
    "created_at" : "2013-09-02 08:31:40 +0000",
    "user" : {
      "name" : "Daniel Willingham",
      "screen_name" : "DTWillingham",
      "protected" : false,
      "id_str" : "84619537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1815678310\/Daniel_Willingham_Color_lowres_normal.JPG",
      "id" : 84619537,
      "verified" : false
    }
  },
  "id" : 374857011193597952,
  "created_at" : "2013-09-03 11:30:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angus B Grieve-Smith",
      "screen_name" : "grvsmth",
      "indices" : [ 0, 8 ],
      "id_str" : "22381639",
      "id" : 22381639
    }, {
      "name" : "Doghouse Diaries",
      "screen_name" : "WillRayRaf",
      "indices" : [ 9, 20 ],
      "id_str" : "36634285",
      "id" : 36634285
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/jCMT6kH1nd",
      "expanded_url" : "http:\/\/thedoghousediaries.com\/4786",
      "display_url" : "thedoghousediaries.com\/4786"
    } ]
  },
  "in_reply_to_status_id_str" : "374578448041533441",
  "geo" : { },
  "id_str" : "374581420032659456",
  "in_reply_to_user_id" : 22381639,
  "text" : "@grvsmth @WillRayRaf hehe, there's another funny blog related one http:\/\/t.co\/jCMT6kH1nd :)",
  "id" : 374581420032659456,
  "in_reply_to_status_id" : 374578448041533441,
  "created_at" : "2013-09-02 17:15:44 +0000",
  "in_reply_to_screen_name" : "grvsmth",
  "in_reply_to_user_id_str" : "22381639",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "indices" : [ 3, 14 ],
      "id_str" : "152051625",
      "id" : 152051625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 140 ],
      "url" : "http:\/\/t.co\/iqHEMMihro",
      "expanded_url" : "http:\/\/bit.ly\/15sOEuB",
      "display_url" : "bit.ly\/15sOEuB"
    } ]
  },
  "geo" : { },
  "id_str" : "374571115609210880",
  "text" : "RT @heatherfro: \"Texas Instruments unwittingly embedded a flexible programming environment into a ubiquitous technology\" http:\/\/t.co\/iqHEMM\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/iqHEMMihro",
        "expanded_url" : "http:\/\/bit.ly\/15sOEuB",
        "display_url" : "bit.ly\/15sOEuB"
      } ]
    },
    "geo" : { },
    "id_str" : "374558316799610880",
    "text" : "\"Texas Instruments unwittingly embedded a flexible programming environment into a ubiquitous technology\" http:\/\/t.co\/iqHEMMihro",
    "id" : 374558316799610880,
    "created_at" : "2013-09-02 15:43:56 +0000",
    "user" : {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "protected" : false,
      "id_str" : "152051625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/688767277022494720\/KMrzOBc1_normal.jpg",
      "id" : 152051625,
      "verified" : false
    }
  },
  "id" : 374571115609210880,
  "created_at" : "2013-09-02 16:34:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "john johnston",
      "screen_name" : "johnjohnston",
      "indices" : [ 0, 13 ],
      "id_str" : "7484192",
      "id" : 7484192
    }, {
      "name" : "Doug Belshaw",
      "screen_name" : "dajbelshaw",
      "indices" : [ 14, 25 ],
      "id_str" : "764365",
      "id" : 764365
    }, {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 26, 40 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374546892912611328",
  "geo" : { },
  "id_str" : "374547661409382400",
  "in_reply_to_user_id" : 7484192,
  "text" : "@johnjohnston @dajbelshaw @audreywatters piratebox is great, can be zero dollars if u use your existing phone :)",
  "id" : 374547661409382400,
  "in_reply_to_status_id" : 374546892912611328,
  "created_at" : "2013-09-02 15:01:35 +0000",
  "in_reply_to_screen_name" : "johnjohnston",
  "in_reply_to_user_id_str" : "7484192",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doug Belshaw",
      "screen_name" : "dajbelshaw",
      "indices" : [ 0, 11 ],
      "id_str" : "764365",
      "id" : 764365
    }, {
      "name" : "john johnston",
      "screen_name" : "johnjohnston",
      "indices" : [ 12, 25 ],
      "id_str" : "7484192",
      "id" : 7484192
    }, {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 26, 40 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/o00Uz35REd",
      "expanded_url" : "http:\/\/www.globalscaletechnologies.com\/p-57-smileplug.aspx",
      "display_url" : "globalscaletechnologies.com\/p-57-smileplug\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "374463259908132865",
  "geo" : { },
  "id_str" : "374546423267590145",
  "in_reply_to_user_id" : 764365,
  "text" : "@dajbelshaw @johnjohnston @audreywatters and not 30dollars :( http:\/\/t.co\/o00Uz35REd",
  "id" : 374546423267590145,
  "in_reply_to_status_id" : 374463259908132865,
  "created_at" : "2013-09-02 14:56:40 +0000",
  "in_reply_to_screen_name" : "dajbelshaw",
  "in_reply_to_user_id_str" : "764365",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Sound Book Site",
      "screen_name" : "sndbksite",
      "indices" : [ 11, 21 ],
      "id_str" : "1650800210",
      "id" : 1650800210
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "374531205535764480",
  "text" : "@mikejhldn @sndbksite it's like riding a bike :)",
  "id" : 374531205535764480,
  "created_at" : "2013-09-02 13:56:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe McVeigh",
      "screen_name" : "EvilJoeMcVeigh",
      "indices" : [ 3, 18 ],
      "id_str" : "1327355143",
      "id" : 1327355143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/jbVHwPPEDn",
      "expanded_url" : "http:\/\/www.nationalmemo.com\/where-labor-day-came-from-and-where-its-going\/",
      "display_url" : "nationalmemo.com\/where-labor-da\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374531114540359680",
  "text" : "RT @EvilJoeMcVeigh: I don't agree with the \"Webster's tells us\" part, but the \"Wal-marted\" neologism is pretty spot on. http:\/\/t.co\/jbVHwPP\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/jbVHwPPEDn",
        "expanded_url" : "http:\/\/www.nationalmemo.com\/where-labor-day-came-from-and-where-its-going\/",
        "display_url" : "nationalmemo.com\/where-labor-da\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "374528621459021824",
    "text" : "I don't agree with the \"Webster's tells us\" part, but the \"Wal-marted\" neologism is pretty spot on. http:\/\/t.co\/jbVHwPPEDn",
    "id" : 374528621459021824,
    "created_at" : "2013-09-02 13:45:56 +0000",
    "user" : {
      "name" : "Joe McVeigh",
      "screen_name" : "EvilJoeMcVeigh",
      "protected" : false,
      "id_str" : "1327355143",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/633574005530693632\/omOKH3tm_normal.png",
      "id" : 1327355143,
      "verified" : false
    }
  },
  "id" : 374531114540359680,
  "created_at" : "2013-09-02 13:55:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Sound Book Site",
      "screen_name" : "sndbksite",
      "indices" : [ 11, 21 ],
      "id_str" : "1650800210",
      "id" : 1650800210
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/b1yVgaE9VJ",
      "expanded_url" : "https:\/\/www.musicworks.ca\/diy\/how-make-binaural-microphones",
      "display_url" : "musicworks.ca\/diy\/how-make-b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374525325671026691",
  "text" : "@mikejhldn @sndbksite if u r comfortbale with soldering https:\/\/t.co\/b1yVgaE9VJ",
  "id" : 374525325671026691,
  "created_at" : "2013-09-02 13:32:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doghouse Diaries",
      "screen_name" : "WillRayRaf",
      "indices" : [ 86, 97 ],
      "id_str" : "36634285",
      "id" : 36634285
    }, {
      "name" : "ellensclass",
      "screen_name" : "ellensclass",
      "indices" : [ 102, 114 ],
      "id_str" : "451058137",
      "id" : 451058137
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/M4F3hGZkh4",
      "expanded_url" : "http:\/\/thedoghousediaries.com\/302",
      "display_url" : "thedoghousediaries.com\/302"
    } ]
  },
  "geo" : { },
  "id_str" : "374524525854982144",
  "text" : "Revealed: secret to increasing your blog posts comments :) http:\/\/t.co\/M4F3hGZkh4 v\/a @WillRayRaf h\/t @ellensclass",
  "id" : 374524525854982144,
  "created_at" : "2013-09-02 13:29:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Sound Book Site",
      "screen_name" : "sndbksite",
      "indices" : [ 0, 10 ],
      "id_str" : "1650800210",
      "id" : 1650800210
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374516151016882176",
  "geo" : { },
  "id_str" : "374517777454751744",
  "in_reply_to_user_id" : 1650800210,
  "text" : "@sndbksite @mikejhldn have u considered using binaural recordings for such sounds? makes a massive difference imo",
  "id" : 374517777454751744,
  "in_reply_to_status_id" : 374516151016882176,
  "created_at" : "2013-09-02 13:02:51 +0000",
  "in_reply_to_screen_name" : "sndbksite",
  "in_reply_to_user_id_str" : "1650800210",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicola Prentis",
      "screen_name" : "NicolaPrentis",
      "indices" : [ 0, 14 ],
      "id_str" : "810667033",
      "id" : 810667033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374513799509733376",
  "geo" : { },
  "id_str" : "374515131406766080",
  "in_reply_to_user_id" : 810667033,
  "text" : "@NicolaPrentis a few slight knocks on side of lid works :) top tip frm uncle of mine who used to work in packaging biz",
  "id" : 374515131406766080,
  "in_reply_to_status_id" : 374513799509733376,
  "created_at" : "2013-09-02 12:52:20 +0000",
  "in_reply_to_screen_name" : "NicolaPrentis",
  "in_reply_to_user_id_str" : "810667033",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "4TUNE Teller App",
      "screen_name" : "4tunetellernet",
      "indices" : [ 0, 15 ],
      "id_str" : "467634146",
      "id" : 467634146
    }, {
      "name" : "Indiegogo",
      "screen_name" : "Indiegogo",
      "indices" : [ 16, 26 ],
      "id_str" : "34732474",
      "id" : 34732474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374505943871942656",
  "geo" : { },
  "id_str" : "374506842639978496",
  "in_reply_to_user_id" : 467634146,
  "text" : "@4tunetellernet @Indiegogo a pleasure, looking fwd to the film :)",
  "id" : 374506842639978496,
  "in_reply_to_status_id" : 374505943871942656,
  "created_at" : "2013-09-02 12:19:23 +0000",
  "in_reply_to_screen_name" : "4tunetellernet",
  "in_reply_to_user_id_str" : "467634146",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Indiegogo",
      "screen_name" : "Indiegogo",
      "indices" : [ 111, 121 ],
      "id_str" : "34732474",
      "id" : 34732474
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "indiegogo",
      "indices" : [ 96, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/VeRvDEKa81",
      "expanded_url" : "http:\/\/igg.me\/p\/working-the-mike-lefevre-story\/cstw\/4622583",
      "display_url" : "igg.me\/p\/working-the-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374505423300075520",
  "text" : "If like supporting indie films support this &gt; The Mike Lefevre Story' http:\/\/t.co\/VeRvDEKa81 #indiegogo via @indiegogo",
  "id" : 374505423300075520,
  "created_at" : "2013-09-02 12:13:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 78, 86 ]
    }, {
      "text" : "esl",
      "indices" : [ 87, 91 ]
    }, {
      "text" : "efl",
      "indices" : [ 92, 96 ]
    }, {
      "text" : "tesol",
      "indices" : [ 97, 103 ]
    }, {
      "text" : "tefl",
      "indices" : [ 104, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/13rMHTM8G9",
      "expanded_url" : "http:\/\/www.cambridge.org\/grammarandbeyond\/communicative-activities",
      "display_url" : "cambridge.org\/grammarandbeyo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374497118196482048",
  "text" : "nice set of activities from a corpus based book series http:\/\/t.co\/13rMHTM8G9 #eltchat #esl #efl #tesol #tefl",
  "id" : 374497118196482048,
  "created_at" : "2013-09-02 11:40:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jack Askew",
      "screen_name" : "eslonlinejack",
      "indices" : [ 3, 17 ],
      "id_str" : "1513170398",
      "id" : 1513170398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/m8wJGg65HJ",
      "expanded_url" : "http:\/\/bit.ly\/1dyR2SE",
      "display_url" : "bit.ly\/1dyR2SE"
    } ]
  },
  "geo" : { },
  "id_str" : "374496838771949569",
  "text" : "RT @eslonlinejack: Want to be a successful online teacher? You'll need students; here is how to get them - http:\/\/t.co\/m8wJGg65HJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/m8wJGg65HJ",
        "expanded_url" : "http:\/\/bit.ly\/1dyR2SE",
        "display_url" : "bit.ly\/1dyR2SE"
      } ]
    },
    "geo" : { },
    "id_str" : "374492363898368000",
    "text" : "Want to be a successful online teacher? You'll need students; here is how to get them - http:\/\/t.co\/m8wJGg65HJ",
    "id" : 374492363898368000,
    "created_at" : "2013-09-02 11:21:51 +0000",
    "user" : {
      "name" : "Jack Askew",
      "screen_name" : "eslonlinejack",
      "protected" : false,
      "id_str" : "1513170398",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/484685723677638657\/aIA1Yymj_normal.png",
      "id" : 1513170398,
      "verified" : false
    }
  },
  "id" : 374496838771949569,
  "created_at" : "2013-09-02 11:39:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Blond",
      "screen_name" : "BillsEnglish",
      "indices" : [ 3, 16 ],
      "id_str" : "1225932950",
      "id" : 1225932950
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpus",
      "indices" : [ 78, 85 ]
    }, {
      "text" : "edtech",
      "indices" : [ 121, 128 ]
    }, {
      "text" : "esl",
      "indices" : [ 129, 133 ]
    }, {
      "text" : "ELT",
      "indices" : [ 134, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/gaodXs2lBE",
      "expanded_url" : "http:\/\/www.billsenglish.com\/1\/post\/2013\/09\/remember-the-breakfast-corpus-linguistics-and-challenging-teacher-intuition.html",
      "display_url" : "billsenglish.com\/1\/post\/2013\/09\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374483138933583872",
  "text" : "RT @BillsEnglish: New blog post about challenging a teacher's intuition using #corpus linguistics http:\/\/t.co\/gaodXs2lBE #edtech #esl #ELT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpus",
        "indices" : [ 60, 67 ]
      }, {
        "text" : "edtech",
        "indices" : [ 103, 110 ]
      }, {
        "text" : "esl",
        "indices" : [ 111, 115 ]
      }, {
        "text" : "ELT",
        "indices" : [ 116, 120 ]
      } ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/gaodXs2lBE",
        "expanded_url" : "http:\/\/www.billsenglish.com\/1\/post\/2013\/09\/remember-the-breakfast-corpus-linguistics-and-challenging-teacher-intuition.html",
        "display_url" : "billsenglish.com\/1\/post\/2013\/09\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "374258488681041921",
    "text" : "New blog post about challenging a teacher's intuition using #corpus linguistics http:\/\/t.co\/gaodXs2lBE #edtech #esl #ELT",
    "id" : 374258488681041921,
    "created_at" : "2013-09-01 19:52:31 +0000",
    "user" : {
      "name" : "Bill Blond",
      "screen_name" : "BillsEnglish",
      "protected" : false,
      "id_str" : "1225932950",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000178985604\/38c86f0ad86b16b49ddd21f7e3d0e4dd_normal.jpeg",
      "id" : 1225932950,
      "verified" : false
    }
  },
  "id" : 374483138933583872,
  "created_at" : "2013-09-02 10:45:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Akira Murakami",
      "screen_name" : "mrkm_a",
      "indices" : [ 3, 10 ],
      "id_str" : "116922669",
      "id" : 116922669
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 143, 144 ],
      "url" : "http:\/\/t.co\/iUsjqjAUUB",
      "expanded_url" : "http:\/\/applij.oxfordjournals.org\/content\/early\/2013\/08\/25\/applin.amt018.full",
      "display_url" : "applij.oxfordjournals.org\/content\/early\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374106307126501376",
  "text" : "RT @mrkm_a: Brezina, V. &amp; Gablasova, D. (in press). Is There a Core General Vocabulary? Introducing the New General Service List\nhttp:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/iUsjqjAUUB",
        "expanded_url" : "http:\/\/applij.oxfordjournals.org\/content\/early\/2013\/08\/25\/applin.amt018.full",
        "display_url" : "applij.oxfordjournals.org\/content\/early\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "373899201588899840",
    "text" : "Brezina, V. &amp; Gablasova, D. (in press). Is There a Core General Vocabulary? Introducing the New General Service List\nhttp:\/\/t.co\/iUsjqjAUUB",
    "id" : 373899201588899840,
    "created_at" : "2013-08-31 20:04:51 +0000",
    "user" : {
      "name" : "Akira Murakami",
      "screen_name" : "mrkm_a",
      "protected" : false,
      "id_str" : "116922669",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/491819353784860672\/LqdQ1Sye_normal.jpeg",
      "id" : 116922669,
      "verified" : false
    }
  },
  "id" : 374106307126501376,
  "created_at" : "2013-09-01 09:47:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
} ]