Grailbird.data.tweets_2012_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boing Boing",
      "screen_name" : "BoingBoing",
      "indices" : [ 79, 90 ],
      "id_str" : "5971922",
      "id" : 5971922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/LRVdxMH3",
      "expanded_url" : "http:\/\/www.technologyreview.com\/view\/428367\/crowd-quakes-were-a-key-factor-in-loveparade\/#comments",
      "display_url" : "technologyreview.com\/view\/428367\/cr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "219105690944413696",
  "text" : "Tragic and fascinating physics account of crowd deaths http:\/\/t.co\/LRVdxMH3 HT @boingboing",
  "id" : 219105690944413696,
  "created_at" : "2012-06-30 16:30:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth Anne",
      "screen_name" : "eannegrenoble",
      "indices" : [ 0, 14 ],
      "id_str" : "19869781",
      "id" : 19869781
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TiceAlpes",
      "indices" : [ 28, 38 ]
    }, {
      "text" : "ff",
      "indices" : [ 67, 70 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "218817746723553281",
  "geo" : { },
  "id_str" : "218990379549196289",
  "in_reply_to_user_id" : 19869781,
  "text" : "@eannegrenoble  sounds like #TiceAlpes went swimmingly, thanks for #ff",
  "id" : 218990379549196289,
  "in_reply_to_status_id" : 218817746723553281,
  "created_at" : "2012-06-30 08:52:29 +0000",
  "in_reply_to_screen_name" : "eannegrenoble",
  "in_reply_to_user_id_str" : "19869781",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Colleen Brown",
      "screen_name" : "c_brune",
      "indices" : [ 0, 8 ],
      "id_str" : "34247658",
      "id" : 34247658
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "218718318138368000",
  "geo" : { },
  "id_str" : "218784278165716992",
  "in_reply_to_user_id" : 34247658,
  "text" : "@c_brune yes he is , the book is written in a very accessible style, recommended",
  "id" : 218784278165716992,
  "in_reply_to_status_id" : 218718318138368000,
  "created_at" : "2012-06-29 19:13:31 +0000",
  "in_reply_to_screen_name" : "c_brune",
  "in_reply_to_user_id_str" : "34247658",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 0, 11 ],
      "id_str" : "282659955",
      "id" : 282659955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "218714358895755268",
  "geo" : { },
  "id_str" : "218714879186567169",
  "in_reply_to_user_id" : 282659955,
  "text" : "@teflerinha hehe post some over to france :)",
  "id" : 218714879186567169,
  "in_reply_to_status_id" : 218714358895755268,
  "created_at" : "2012-06-29 14:37:45 +0000",
  "in_reply_to_screen_name" : "teflerinha",
  "in_reply_to_user_id_str" : "282659955",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Colleen Brown",
      "screen_name" : "c_brune",
      "indices" : [ 0, 8 ],
      "id_str" : "34247658",
      "id" : 34247658
    }, {
      "name" : "American TESOL",
      "screen_name" : "tesol",
      "indices" : [ 9, 15 ],
      "id_str" : "17911244",
      "id" : 17911244
    }, {
      "name" : "John T. Spencer",
      "screen_name" : "JohnTSpencer",
      "indices" : [ 16, 29 ],
      "id_str" : "2285706270",
      "id" : 2285706270
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/bmntx3cc",
      "expanded_url" : "http:\/\/www.educationrethink.com\/search?q=a+sustainable+start",
      "display_url" : "educationrethink.com\/search?q=a+sus\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "218709896655409153",
  "geo" : { },
  "id_str" : "218714580862504961",
  "in_reply_to_user_id" : 34247658,
  "text" : "@c_brune @TESOL @johntspencer uses the sustainable metaphor in his free ebook http:\/\/t.co\/bmntx3cc, he focuses on Tchr Identity",
  "id" : 218714580862504961,
  "in_reply_to_status_id" : 218709896655409153,
  "created_at" : "2012-06-29 14:36:34 +0000",
  "in_reply_to_screen_name" : "c_brune",
  "in_reply_to_user_id_str" : "34247658",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 0, 11 ],
      "id_str" : "282659955",
      "id" : 282659955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "218712980202864640",
  "geo" : { },
  "id_str" : "218713599122735104",
  "in_reply_to_user_id" : 282659955,
  "text" : "@teflerinha ooh flakes not had those for yonks :)",
  "id" : 218713599122735104,
  "in_reply_to_status_id" : 218712980202864640,
  "created_at" : "2012-06-29 14:32:40 +0000",
  "in_reply_to_screen_name" : "teflerinha",
  "in_reply_to_user_id_str" : "282659955",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Colleen Brown",
      "screen_name" : "c_brune",
      "indices" : [ 0, 8 ],
      "id_str" : "34247658",
      "id" : 34247658
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218707320681672704",
  "in_reply_to_user_id" : 34247658,
  "text" : "@c_brune you have a DM, also did u get a chance to trial CPU wars?",
  "id" : 218707320681672704,
  "created_at" : "2012-06-29 14:07:43 +0000",
  "in_reply_to_screen_name" : "c_brune",
  "in_reply_to_user_id_str" : "34247658",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 51, 61 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http:\/\/t.co\/H6CfMtBt",
      "expanded_url" : "http:\/\/www.morningstaronline.co.uk\/news\/content\/view\/full\/120783",
      "display_url" : "morningstaronline.co.uk\/news\/content\/v\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "218703673214246912",
  "text" : "The art of milking the NHS http:\/\/t.co\/H6CfMtBt HT @medialens",
  "id" : 218703673214246912,
  "created_at" : "2012-06-29 13:53:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Seymour",
      "screen_name" : "leninology",
      "indices" : [ 0, 11 ],
      "id_str" : "15557246",
      "id" : 15557246
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "218618956787884032",
  "geo" : { },
  "id_str" : "218701192434434049",
  "in_reply_to_user_id" : 15557246,
  "text" : "@leninology too bad am sure your thoughts on this would be enlightening.",
  "id" : 218701192434434049,
  "in_reply_to_status_id" : 218618956787884032,
  "created_at" : "2012-06-29 13:43:22 +0000",
  "in_reply_to_screen_name" : "leninology",
  "in_reply_to_user_id_str" : "15557246",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/85zxUK7y",
      "expanded_url" : "http:\/\/bit.ly\/NH2hqI",
      "display_url" : "bit.ly\/NH2hqI"
    } ]
  },
  "geo" : { },
  "id_str" : "218434463733002241",
  "text" : "a jokery of liberal 'stand-ups' unwilling to stand up for those engaged in real radical work  http:\/\/t.co\/85zxUK7y",
  "id" : 218434463733002241,
  "created_at" : "2012-06-28 20:03:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth Anne",
      "screen_name" : "eannegrenoble",
      "indices" : [ 0, 14 ],
      "id_str" : "19869781",
      "id" : 19869781
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TiceAlpes",
      "indices" : [ 68, 78 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "218385805863952384",
  "geo" : { },
  "id_str" : "218432388693368833",
  "in_reply_to_user_id" : 19869781,
  "text" : "@eannegrenoble PLN -&gt;21st century sharing, learning and playing. #TiceAlpes",
  "id" : 218432388693368833,
  "in_reply_to_status_id" : 218385805863952384,
  "created_at" : "2012-06-28 19:55:14 +0000",
  "in_reply_to_screen_name" : "eannegrenoble",
  "in_reply_to_user_id_str" : "19869781",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anne Hodgson",
      "screen_name" : "annehodg",
      "indices" : [ 52, 61 ],
      "id_str" : "17589213",
      "id" : 17589213
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TiceAlpes",
      "indices" : [ 0, 10 ]
    } ],
    "urls" : [ {
      "indices" : [ 11, 31 ],
      "url" : "http:\/\/t.co\/xi0iPUcc",
      "expanded_url" : "http:\/\/euleap.ning.com",
      "display_url" : "euleap.ning.com"
    } ]
  },
  "geo" : { },
  "id_str" : "218431327953895425",
  "text" : "#TiceAlpes http:\/\/t.co\/xi0iPUcc have a good session @annehodg",
  "id" : 218431327953895425,
  "created_at" : "2012-06-28 19:51:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Seymour",
      "screen_name" : "leninology",
      "indices" : [ 0, 11 ],
      "id_str" : "15557246",
      "id" : 15557246
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218425599822270468",
  "in_reply_to_user_id" : 15557246,
  "text" : "@leninology wondering if u have been asked\/offered to write about assange for guardian?",
  "id" : 218425599822270468,
  "created_at" : "2012-06-28 19:28:15 +0000",
  "in_reply_to_screen_name" : "leninology",
  "in_reply_to_user_id_str" : "15557246",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "indices" : [ 56, 69 ],
      "id_str" : "1685397408",
      "id" : 1685397408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/b7YxW6sT",
      "expanded_url" : "http:\/\/www.mikejharrison.com\/2012\/06\/google-maps-language-plants\/",
      "display_url" : "mikejharrison.com\/2012\/06\/google\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "218405667080384512",
  "text" : "http:\/\/t.co\/b7YxW6sT google maps + language plants from @harrisonmike worth following link to phil bird post on more streetview activities",
  "id" : 218405667080384512,
  "created_at" : "2012-06-28 18:09:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boing Boing",
      "screen_name" : "BoingBoing",
      "indices" : [ 60, 71 ],
      "id_str" : "5971922",
      "id" : 5971922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/10x0FWCo",
      "expanded_url" : "http:\/\/www.johntedesco.net\/blog\/2012\/06\/21\/how-to-solve-impossible-problems-daniel-russells-awesome-google-search-techniques\/",
      "display_url" : "johntedesco.net\/blog\/2012\/06\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "218109476912381955",
  "text" : "some great Google search tips here: http:\/\/t.co\/10x0FWCo HT @boingboing",
  "id" : 218109476912381955,
  "created_at" : "2012-06-27 22:32:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/xfYcwtyB",
      "expanded_url" : "http:\/\/assange.rt.com\/",
      "display_url" : "assange.rt.com"
    } ]
  },
  "geo" : { },
  "id_str" : "217706366171758592",
  "text" : "http:\/\/t.co\/xfYcwtyB Assange, Ali and Chomsky converse",
  "id" : 217706366171758592,
  "created_at" : "2012-06-26 19:50:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brittany Petersen",
      "screen_name" : "britpetersen",
      "indices" : [ 0, 13 ],
      "id_str" : "252628294",
      "id" : 252628294
    }, {
      "name" : "Tom McGrath",
      "screen_name" : "TCMcG",
      "indices" : [ 14, 20 ],
      "id_str" : "12993232",
      "id" : 12993232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "217703064067514368",
  "geo" : { },
  "id_str" : "217704585106702336",
  "in_reply_to_user_id" : 252628294,
  "text" : "@britpetersen @TCMcG groovy jumper you rockin there.",
  "id" : 217704585106702336,
  "in_reply_to_status_id" : 217703064067514368,
  "created_at" : "2012-06-26 19:43:12 +0000",
  "in_reply_to_screen_name" : "britpetersen",
  "in_reply_to_user_id_str" : "252628294",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 0, 11 ],
      "id_str" : "282659955",
      "id" : 282659955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "217694306306240512",
  "geo" : { },
  "id_str" : "217701277294010370",
  "in_reply_to_user_id" : 282659955,
  "text" : "@teflerinha hehe, i remember on last day being late for her class after lunch at pub. was she presenting at the conference you went to?",
  "id" : 217701277294010370,
  "in_reply_to_status_id" : 217694306306240512,
  "created_at" : "2012-06-26 19:30:03 +0000",
  "in_reply_to_screen_name" : "teflerinha",
  "in_reply_to_user_id_str" : "282659955",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 0, 11 ],
      "id_str" : "282659955",
      "id" : 282659955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "217666815197843457",
  "geo" : { },
  "id_str" : "217678910203244544",
  "in_reply_to_user_id" : 282659955,
  "text" : "@teflerinha haha i would have been very very surprised if she had! loads of bods must have passed through there in that time.",
  "id" : 217678910203244544,
  "in_reply_to_status_id" : 217666815197843457,
  "created_at" : "2012-06-26 18:01:11 +0000",
  "in_reply_to_screen_name" : "teflerinha",
  "in_reply_to_user_id_str" : "282659955",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 74, 84 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/1VXC7Rmh",
      "expanded_url" : "http:\/\/ggdrafts.blogspot.com.br\/2012\/06\/responses-to-twitter-objections.html",
      "display_url" : "ggdrafts.blogspot.com.br\/2012\/06\/respon\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "217648068223451136",
  "text" : "Great Glenn Greenwald post on debating on twitter http:\/\/t.co\/1VXC7Rmh HT @medialens",
  "id" : 217648068223451136,
  "created_at" : "2012-06-26 15:58:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 0, 11 ],
      "id_str" : "282659955",
      "id" : 282659955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "217566430734974976",
  "geo" : { },
  "id_str" : "217635905874305024",
  "in_reply_to_user_id" : 282659955,
  "text" : "@teflerinha oooh wonder if she remembered me?",
  "id" : 217635905874305024,
  "in_reply_to_status_id" : 217566430734974976,
  "created_at" : "2012-06-26 15:10:18 +0000",
  "in_reply_to_screen_name" : "teflerinha",
  "in_reply_to_user_id_str" : "282659955",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Simpson",
      "screen_name" : "yearinthelifeof",
      "indices" : [ 3, 19 ],
      "id_str" : "78543378",
      "id" : 78543378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/TNQfp0JR",
      "expanded_url" : "http:\/\/bit.ly\/MqwdcI",
      "display_url" : "bit.ly\/MqwdcI"
    } ]
  },
  "geo" : { },
  "id_str" : "217612942739378176",
  "text" : "MT @yearinthelifeof TEFLTastic Alex: Exercise routines for TEFLers http:\/\/t.co\/TNQfp0JR&lt;--alex is on a lol roll :)",
  "id" : 217612942739378176,
  "created_at" : "2012-06-26 13:39:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http:\/\/t.co\/KoM4fLwF",
      "expanded_url" : "http:\/\/boingboing.net\/2012\/06\/24\/shakespearean-hokey-pokey.html",
      "display_url" : "boingboing.net\/2012\/06\/24\/sha\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "217249246573887488",
  "text" : "Shakespearean Hokey Pokey: http:\/\/t.co\/KoM4fLwF",
  "id" : 217249246573887488,
  "created_at" : "2012-06-25 13:33:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 3, 14 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "efl",
      "indices" : [ 86, 90 ]
    }, {
      "text" : "esol",
      "indices" : [ 91, 96 ]
    }, {
      "text" : "tefl",
      "indices" : [ 97, 102 ]
    }, {
      "text" : "elt",
      "indices" : [ 103, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/kkSL6ynj",
      "expanded_url" : "http:\/\/buff.ly\/Lq62E9",
      "display_url" : "buff.ly\/Lq62E9"
    } ]
  },
  "geo" : { },
  "id_str" : "216906775989989376",
  "text" : "MT @leoselivan: \"vertical\" &amp; \"horizontal\" word relationships http:\/\/t.co\/kkSL6ynj #efl #esol #tefl #elt&lt;-useful concepts for TOEIC class",
  "id" : 216906775989989376,
  "created_at" : "2012-06-24 14:52:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216642737204764672",
  "geo" : { },
  "id_str" : "216643372515995649",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan yes the corpus is limited, hoping the interface elements of netspeak are taken up by some of the better databases",
  "id" : 216643372515995649,
  "in_reply_to_status_id" : 216642737204764672,
  "created_at" : "2012-06-23 21:26:19 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216641858976227329",
  "geo" : { },
  "id_str" : "216642483873005570",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan look fwd to that one then :) that netspeak interface is the easiest i have seen so far on a concordancer",
  "id" : 216642483873005570,
  "in_reply_to_status_id" : 216641858976227329,
  "created_at" : "2012-06-23 21:22:47 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216639443266838529",
  "geo" : { },
  "id_str" : "216641528486035458",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan tools like netspeak are great to explore the horizontal axis",
  "id" : 216641528486035458,
  "in_reply_to_status_id" : 216639443266838529,
  "created_at" : "2012-06-23 21:19:00 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216615687148421122",
  "geo" : { },
  "id_str" : "216637323989880836",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan thanks learned some new terms :) typo? in the Paradigmatic para - Other two kinds of +syntagmatic+ relationship are",
  "id" : 216637323989880836,
  "in_reply_to_status_id" : 216615687148421122,
  "created_at" : "2012-06-23 21:02:17 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Halvorsen",
      "screen_name" : "ESHalvorsen",
      "indices" : [ 0, 12 ],
      "id_str" : "119829380",
      "id" : 119829380
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216466422170255360",
  "geo" : { },
  "id_str" : "216552211889651712",
  "in_reply_to_user_id" : 119829380,
  "text" : "@ESHalvorsen my current phone is 2nd hand :) peeps will give free a free ride for a while just because they have shaken up french market",
  "id" : 216552211889651712,
  "in_reply_to_status_id" : 216466422170255360,
  "created_at" : "2012-06-23 15:24:05 +0000",
  "in_reply_to_screen_name" : "ESHalvorsen",
  "in_reply_to_user_id_str" : "119829380",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Halvorsen",
      "screen_name" : "ESHalvorsen",
      "indices" : [ 0, 12 ],
      "id_str" : "119829380",
      "id" : 119829380
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "216260520012029955",
  "geo" : { },
  "id_str" : "216275638078812161",
  "in_reply_to_user_id" : 119829380,
  "text" : "@ESHalvorsen  hoping only temporary victims of their own success! still need to go much worse for me to get cancel 2E\/mnth  :)",
  "id" : 216275638078812161,
  "in_reply_to_status_id" : 216260520012029955,
  "created_at" : "2012-06-22 21:05:04 +0000",
  "in_reply_to_screen_name" : "ESHalvorsen",
  "in_reply_to_user_id_str" : "119829380",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chadsansing",
      "screen_name" : "chadsansing",
      "indices" : [ 3, 15 ],
      "id_str" : "76810409",
      "id" : 76810409
    }, {
      "name" : "Bethany Nowviskie",
      "screen_name" : "nowviskie",
      "indices" : [ 24, 34 ],
      "id_str" : "14221013",
      "id" : 14221013
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/uoZ1YGyj",
      "expanded_url" : "http:\/\/bit.ly\/NZ8GCm",
      "display_url" : "bit.ly\/NZ8GCm"
    }, {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/hwgp6Nmz",
      "expanded_url" : "http:\/\/bit.ly\/NMYixp",
      "display_url" : "bit.ly\/NMYixp"
    }, {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/DSa6OakE",
      "expanded_url" : "http:\/\/bit.ly\/Kg9kFI",
      "display_url" : "bit.ly\/Kg9kFI"
    } ]
  },
  "geo" : { },
  "id_str" : "216138604378980354",
  "text" : "MT @chadsansing: thanks @nowviskie fr http:\/\/t.co\/uoZ1YGyj, http:\/\/t.co\/hwgp6Nmz, http:\/\/t.co\/DSa6OakE kids hacking\/making&lt;-bkmk fr 8wk son",
  "id" : 216138604378980354,
  "created_at" : "2012-06-22 12:00:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 92, 102 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/k6kjQIIh",
      "expanded_url" : "http:\/\/twitter.com\/funnymarkbutler\/status\/216120367901704192\/photo\/1",
      "display_url" : "pic.twitter.com\/k6kjQIIh"
    } ]
  },
  "geo" : { },
  "id_str" : "216126587215691777",
  "text" : "RT @funnymarkbutler: Assange vs Zuckerberg. Oh, the irony. http:\/\/t.co\/k6kjQIIh HT gabriele @medialens",
  "id" : 216126587215691777,
  "created_at" : "2012-06-22 11:12:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephanie McIntosh",
      "screen_name" : "purple_steph",
      "indices" : [ 0, 13 ],
      "id_str" : "18678010",
      "id" : 18678010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "215918681346154496",
  "geo" : { },
  "id_str" : "215920107027841026",
  "in_reply_to_user_id" : 18678010,
  "text" : "@purple_steph amazing fail, another to add to the ignoble collection",
  "id" : 215920107027841026,
  "in_reply_to_status_id" : 215918681346154496,
  "created_at" : "2012-06-21 21:32:19 +0000",
  "in_reply_to_screen_name" : "purple_steph",
  "in_reply_to_user_id_str" : "18678010",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nagehan Tunar",
      "screen_name" : "stiiiv",
      "indices" : [ 3, 10 ],
      "id_str" : "799058600",
      "id" : 799058600
    }, {
      "name" : "Alex Ding",
      "screen_name" : "alexanderding",
      "indices" : [ 77, 91 ],
      "id_str" : "118014141",
      "id" : 118014141
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EAPchat",
      "indices" : [ 113, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/chc2GhFL",
      "expanded_url" : "http:\/\/j.mp\/LmfEj7",
      "display_url" : "j.mp\/LmfEj7"
    } ]
  },
  "geo" : { },
  "id_str" : "215919046804246529",
  "text" : "MT @stiiiv: \"reflective pract only transmissive pedagogy by back door?\" from @alexanderding http:\/\/t.co\/chc2GhFL #EAPchat&lt;-int criticisms",
  "id" : 215919046804246529,
  "created_at" : "2012-06-21 21:28:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 71, 81 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/g05jAStv",
      "expanded_url" : "http:\/\/youtu.be\/x-iT51XSTgE",
      "display_url" : "youtu.be\/x-iT51XSTgE"
    } ]
  },
  "geo" : { },
  "id_str" : "215731968254545920",
  "text" : "Daniel Ellsberg on why Wikileaks matters http:\/\/t.co\/g05jAStv HT margo @medialens",
  "id" : 215731968254545920,
  "created_at" : "2012-06-21 09:04:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/wsFcYwyW",
      "expanded_url" : "http:\/\/blog.hooktheory.com\/2012\/06\/06\/i-analyzed-the-chords-of-1300-popular-songs-for-patterns-this-is-what-i-found\/",
      "display_url" : "blog.hooktheory.com\/2012\/06\/06\/i-a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "215719598757117952",
  "text" : "if u r in france today  see if you recognise any of these chords http:\/\/t.co\/wsFcYwyW",
  "id" : 215719598757117952,
  "created_at" : "2012-06-21 08:15:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELTchat",
      "indices" : [ 0, 8 ]
    } ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http:\/\/t.co\/fqklb62n",
      "expanded_url" : "http:\/\/bit.ly\/M5Tpg5",
      "display_url" : "bit.ly\/M5Tpg5"
    } ]
  },
  "geo" : { },
  "id_str" : "215532147421872128",
  "text" : "#ELTchat podcast June 2012 http:\/\/t.co\/fqklb62n&lt;--30 mins well spent, top episode",
  "id" : 215532147421872128,
  "created_at" : "2012-06-20 19:50:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 60, 68 ]
    }, {
      "text" : "esl",
      "indices" : [ 69, 73 ]
    }, {
      "text" : "tesol",
      "indices" : [ 74, 80 ]
    }, {
      "text" : "efl",
      "indices" : [ 81, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/FCXk1J7F",
      "expanded_url" : "http:\/\/demandhighelt.wordpress.com\/observation-tasks\/",
      "display_url" : "demandhighelt.wordpress.com\/observation-ta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "215504340394328065",
  "text" : "http:\/\/t.co\/FCXk1J7F Demand High Teaching Observation Tasks #eltchat #esl #tesol #efl",
  "id" : 215504340394328065,
  "created_at" : "2012-06-20 18:00:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/lu8Lrka9",
      "expanded_url" : "http:\/\/members5.boardhost.com\/medialens\/msg\/1340202578.html",
      "display_url" : "members5.boardhost.com\/medialens\/msg\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "215494311796674560",
  "text" : "Jonathan Cook emails again on Assange - when 'the paltry tokens seem to fall silent' http:\/\/t.co\/lu8Lrka9",
  "id" : 215494311796674560,
  "created_at" : "2012-06-20 17:20:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/UoaVJ6pZ",
      "expanded_url" : "http:\/\/wp.me\/PgHyE-b",
      "display_url" : "wp.me\/PgHyE-b"
    } ]
  },
  "geo" : { },
  "id_str" : "215210612563783681",
  "text" : "new blog page Twitter ELT bookmarks http:\/\/t.co\/UoaVJ6pZ, one way to curate and list twitter favourites on free wordpress account",
  "id" : 215210612563783681,
  "created_at" : "2012-06-19 22:33:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Simpson",
      "screen_name" : "yearinthelifeof",
      "indices" : [ 3, 19 ],
      "id_str" : "78543378",
      "id" : 78543378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/7oNNcx7m",
      "expanded_url" : "http:\/\/bit.ly\/Lu9xdO",
      "display_url" : "bit.ly\/Lu9xdO"
    } ]
  },
  "geo" : { },
  "id_str" : "215022281838174208",
  "text" : "MT @yearinthelifeof: TEFLTastic Alex: Top Trumps for TEFLers http:\/\/t.co\/7oNNcx7m&lt;--hehe wonder who would win on batshit crazy?",
  "id" : 215022281838174208,
  "created_at" : "2012-06-19 10:04:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/4kxoClVU",
      "expanded_url" : "http:\/\/www.theatlantic.com\/business\/archive\/2012\/06\/forget-edison-this-is-how-historys-greatest-inventions-really-happened\/258525\/",
      "display_url" : "theatlantic.com\/business\/archi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "214872669206745088",
  "text" : "Nice jigsaw reading activity on inventions http:\/\/t.co\/4kxoClVU",
  "id" : 214872669206745088,
  "created_at" : "2012-06-19 00:10:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Novak",
      "screen_name" : "paleofuture",
      "indices" : [ 0, 12 ],
      "id_str" : "16877374",
      "id" : 16877374
    }, {
      "name" : "DARPA",
      "screen_name" : "DARPA",
      "indices" : [ 13, 19 ],
      "id_str" : "54645160",
      "id" : 54645160
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213701711968210945",
  "geo" : { },
  "id_str" : "213704219847442432",
  "in_reply_to_user_id" : 16877374,
  "text" : "@paleofuture @DARPA people in Afghanistan\/Pakistan bored and looking forward to new kinds of terror from the sky...",
  "id" : 213704219847442432,
  "in_reply_to_status_id" : 213701711968210945,
  "created_at" : "2012-06-15 18:47:11 +0000",
  "in_reply_to_screen_name" : "paleofuture",
  "in_reply_to_user_id_str" : "16877374",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Seymour",
      "screen_name" : "leninology",
      "indices" : [ 77, 88 ],
      "id_str" : "15557246",
      "id" : 15557246
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/TtMHHsmw",
      "expanded_url" : "http:\/\/www.guardian.co.uk\/commentisfree\/2012\/jun\/13\/spanish-miners-strike",
      "display_url" : "guardian.co.uk\/commentisfree\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "213618682755153920",
  "text" : "We Are Not Indignant, We Are Pissed Off To Our Balls http:\/\/t.co\/TtMHHsmw by @leninology",
  "id" : 213618682755153920,
  "created_at" : "2012-06-15 13:07:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "213603362254499841",
  "geo" : { },
  "id_str" : "213614901372006401",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow fire and alcohol! :)",
  "id" : 213614901372006401,
  "in_reply_to_status_id" : 213603362254499841,
  "created_at" : "2012-06-15 12:52:15 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/b4YBEDbi",
      "expanded_url" : "http:\/\/sumofus.org\/campaigns\/apple-uprising\/",
      "display_url" : "sumofus.org\/campaigns\/appl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "213393945223376896",
  "text" : "\"With Apple's outsized influence, it alone can affect change across the entire industry\" http:\/\/t.co\/b4YBEDbi &lt;--signed",
  "id" : 213393945223376896,
  "created_at" : "2012-06-14 22:14:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/q5OM7Oty",
      "expanded_url" : "http:\/\/bps-research-digest.blogspot.fr\/2012\/06\/there-are-two-kinds-of-bilingual-brain.html",
      "display_url" : "bps-research-digest.blogspot.fr\/2012\/06\/there-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "213227313909858304",
  "text" : "There are two kinds of bi-lingual brain http:\/\/t.co\/q5OM7Oty",
  "id" : 213227313909858304,
  "created_at" : "2012-06-14 11:12:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "212864580580421632",
  "text" : "water is cut to our building for works, remided plumbing is a much more sig tech than internet say!",
  "id" : 212864580580421632,
  "created_at" : "2012-06-13 11:10:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 0, 11 ],
      "id_str" : "282659955",
      "id" : 282659955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "212857552147460096",
  "geo" : { },
  "id_str" : "212859242326130688",
  "in_reply_to_user_id" : 282659955,
  "text" : "@teflerinha i do miss the midlands though, at times :) lived in brum, wolves and stoke :) u from solihull originally?",
  "id" : 212859242326130688,
  "in_reply_to_status_id" : 212857552147460096,
  "created_at" : "2012-06-13 10:49:32 +0000",
  "in_reply_to_screen_name" : "teflerinha",
  "in_reply_to_user_id_str" : "282659955",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 0, 11 ],
      "id_str" : "282659955",
      "id" : 282659955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "212853767866028032",
  "geo" : { },
  "id_str" : "212855550784966656",
  "in_reply_to_user_id" : 282659955,
  "text" : "@teflerinha i did it in 2006 and had to look up my old notes to remember names - Jo Bolton? Claire Finney?",
  "id" : 212855550784966656,
  "in_reply_to_status_id" : 212853767866028032,
  "created_at" : "2012-06-13 10:34:52 +0000",
  "in_reply_to_screen_name" : "teflerinha",
  "in_reply_to_user_id_str" : "282659955",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 0, 11 ],
      "id_str" : "282659955",
      "id" : 282659955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "212852135979782144",
  "geo" : { },
  "id_str" : "212853312406552576",
  "in_reply_to_user_id" : 282659955,
  "text" : "@teflerinha not going though i did do my celta there at brasshouse, and brum has its charms :) enjoy!",
  "id" : 212853312406552576,
  "in_reply_to_status_id" : 212852135979782144,
  "created_at" : "2012-06-13 10:25:58 +0000",
  "in_reply_to_screen_name" : "teflerinha",
  "in_reply_to_user_id_str" : "282659955",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John T. Spencer",
      "screen_name" : "JohnTSpencer",
      "indices" : [ 123, 136 ],
      "id_str" : "2285706270",
      "id" : 2285706270
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "212514819440513025",
  "text" : "crisis of id &amp; skewed belief system more damage to teacher than fail to breathe correctly or best procedures&lt;--from @johntspencer free ebook",
  "id" : 212514819440513025,
  "created_at" : "2012-06-12 12:00:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/bnp1jx7U",
      "expanded_url" : "http:\/\/www.eurotrib.com\/story\/2012\/6\/12\/5406\/34467",
      "display_url" : "eurotrib.com\/story\/2012\/6\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "212486197249966080",
  "text" : "Olympic Inoculation no6: Welcome to Hobbiton http:\/\/t.co\/bnp1jx7U",
  "id" : 212486197249966080,
  "created_at" : "2012-06-12 10:07:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/RCI6taH6",
      "expanded_url" : "http:\/\/www.chris-floyd.com\/component\/content\/article\/1-latest-news\/2251-unspeakable-things-the-liberals-clumsy-dance-across-obamas-killing-floor.html",
      "display_url" : "chris-floyd.com\/component\/cont\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "212476768144195585",
  "text" : "Unspeakable Things: The Liberals\u2019 Clumsy Dance Across Obama's Killing Floor\nhttp:\/\/t.co\/RCI6taH6",
  "id" : 212476768144195585,
  "created_at" : "2012-06-12 09:29:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maria Popova",
      "screen_name" : "brainpicker",
      "indices" : [ 3, 15 ],
      "id_str" : "9207632",
      "id" : 9207632
    }, {
      "name" : "Senseable City Lab",
      "screen_name" : "SenseableCity",
      "indices" : [ 88, 102 ],
      "id_str" : "146105775",
      "id" : 146105775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/CjTuzWQz",
      "expanded_url" : "http:\/\/j.mp\/MyQVUF",
      "display_url" : "j.mp\/MyQVUF"
    } ]
  },
  "geo" : { },
  "id_str" : "212315923086974976",
  "text" : "MT @brainpicker: animated visualizations of France's high-speed rail systems from MIT's @SenseableCity Lab http:\/\/t.co\/CjTuzWQz&lt;--very sweet",
  "id" : 212315923086974976,
  "created_at" : "2012-06-11 22:50:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nagehan Tunar",
      "screen_name" : "stiiiv",
      "indices" : [ 0, 7 ],
      "id_str" : "799058600",
      "id" : 799058600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "212307985744146433",
  "geo" : { },
  "id_str" : "212308962664648704",
  "in_reply_to_user_id" : 69068757,
  "text" : "@stiiiv CPD for sure masive payback,  but work in France so (recognition) jobwise don't see much return...",
  "id" : 212308962664648704,
  "in_reply_to_status_id" : 212307985744146433,
  "created_at" : "2012-06-11 22:22:55 +0000",
  "in_reply_to_screen_name" : "stiivkirk",
  "in_reply_to_user_id_str" : "69068757",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nagehan Tunar",
      "screen_name" : "stiiiv",
      "indices" : [ 0, 7 ],
      "id_str" : "799058600",
      "id" : 799058600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "212306078208245761",
  "geo" : { },
  "id_str" : "212307410877030400",
  "in_reply_to_user_id" : 69068757,
  "text" : "@stiiiv yeah MA looks good, but the fees r a challenge!",
  "id" : 212307410877030400,
  "in_reply_to_status_id" : 212306078208245761,
  "created_at" : "2012-06-11 22:16:45 +0000",
  "in_reply_to_screen_name" : "stiivkirk",
  "in_reply_to_user_id_str" : "69068757",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nagehan Tunar",
      "screen_name" : "stiiiv",
      "indices" : [ 0, 7 ],
      "id_str" : "799058600",
      "id" : 799058600
    }, {
      "name" : "Sandy Millin",
      "screen_name" : "sandymillin",
      "indices" : [ 8, 20 ],
      "id_str" : "144236944",
      "id" : 144236944
    }, {
      "name" : "Sue Annan",
      "screen_name" : "SueAnnan",
      "indices" : [ 37, 46 ],
      "id_str" : "136001411",
      "id" : 136001411
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/43GmWmRk",
      "expanded_url" : "http:\/\/sueannan.blogspot.fr\/2012\/06\/eltchat-summary-what-web-tools-sites.html",
      "display_url" : "sueannan.blogspot.fr\/2012\/06\/eltcha\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "212302325178572800",
  "geo" : { },
  "id_str" : "212304468845395969",
  "in_reply_to_user_id" : 69068757,
  "text" : "@stiiiv @sandymillin summary here by @SueAnnan http:\/\/t.co\/43GmWmRk",
  "id" : 212304468845395969,
  "in_reply_to_status_id" : 212302325178572800,
  "created_at" : "2012-06-11 22:05:04 +0000",
  "in_reply_to_screen_name" : "stiivkirk",
  "in_reply_to_user_id_str" : "69068757",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edtech",
      "indices" : [ 62, 69 ]
    }, {
      "text" : "YLsig",
      "indices" : [ 70, 76 ]
    }, {
      "text" : "YLeng",
      "indices" : [ 77, 83 ]
    }, {
      "text" : "Eltchat",
      "indices" : [ 84, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/w6FiUhKV",
      "expanded_url" : "http:\/\/gcompris.net\/-en-",
      "display_url" : "gcompris.net\/-en-"
    } ]
  },
  "geo" : { },
  "id_str" : "212229447833763841",
  "text" : "GCompris free ed software suite for kids http:\/\/t.co\/w6FiUhKV #edtech #YLsig #YLeng #Eltchat",
  "id" : 212229447833763841,
  "created_at" : "2012-06-11 17:06:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Ruelle",
      "screen_name" : "danrmitvn",
      "indices" : [ 0, 10 ],
      "id_str" : "125853393",
      "id" : 125853393
    }, {
      "name" : "Patrick Green \uF8FF ADE",
      "screen_name" : "pgreensoup",
      "indices" : [ 11, 22 ],
      "id_str" : "8871282",
      "id" : 8871282
    }, {
      "name" : "Richard Byrne",
      "screen_name" : "rmbyrne",
      "indices" : [ 23, 31 ],
      "id_str" : "11112092",
      "id" : 11112092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "212163126739742720",
  "geo" : { },
  "id_str" : "212213149611474945",
  "in_reply_to_user_id" : 125853393,
  "text" : "@danrmitvn @pgreensoup @rmbyrne yr welcome and thx for those other tools, tools with Ant FTW!",
  "id" : 212213149611474945,
  "in_reply_to_status_id" : 212163126739742720,
  "created_at" : "2012-06-11 16:02:12 +0000",
  "in_reply_to_screen_name" : "danrmitvn",
  "in_reply_to_user_id_str" : "125853393",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Moore",
      "screen_name" : "lexicojules",
      "indices" : [ 3, 15 ],
      "id_str" : "424320799",
      "id" : 424320799
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EAPchat",
      "indices" : [ 52, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/4888wrOA",
      "expanded_url" : "http:\/\/teachingeap.wordpress.com\/author\/julieanneking\/",
      "display_url" : "teachingeap.wordpress.com\/author\/juliean\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "212206378729750528",
  "text" : "MT @lexicojules: EAP blog with a post by Julie King #EAPchat http:\/\/t.co\/4888wrOA&lt;--thx new blog to follow , MA in EAP sounds interesting",
  "id" : 212206378729750528,
  "created_at" : "2012-06-11 15:35:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/LqYSaDM1",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=N6fKq68jJlI",
      "display_url" : "youtube.com\/watch?v=N6fKq6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "211783389299216384",
  "text" : "for the gents (maybe a ladies one on the way?) http:\/\/t.co\/LqYSaDM1",
  "id" : 211783389299216384,
  "created_at" : "2012-06-10 11:34:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vicky Loras",
      "screen_name" : "vickyloras",
      "indices" : [ 0, 11 ],
      "id_str" : "95957241",
      "id" : 95957241
    }, {
      "name" : "Eva Buyuksimkesyan",
      "screen_name" : "evab2001",
      "indices" : [ 12, 21 ],
      "id_str" : "73965155",
      "id" : 73965155
    }, {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 22, 33 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "211408237826805760",
  "geo" : { },
  "id_str" : "211413754922008576",
  "in_reply_to_user_id" : 95957241,
  "text" : "@vickyloras @evab2001 @leoselivan thx u tooo vicky enjoy!",
  "id" : 211413754922008576,
  "in_reply_to_status_id" : 211408237826805760,
  "created_at" : "2012-06-09 11:05:41 +0000",
  "in_reply_to_screen_name" : "vickyloras",
  "in_reply_to_user_id_str" : "95957241",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vicky Loras",
      "screen_name" : "vickyloras",
      "indices" : [ 3, 14 ],
      "id_str" : "95957241",
      "id" : 95957241
    }, {
      "name" : "Eva Buyuksimkesyan",
      "screen_name" : "evab2001",
      "indices" : [ 18, 27 ],
      "id_str" : "73965155",
      "id" : 73965155
    }, {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 72, 83 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "ShareThis",
      "screen_name" : "ShareThis",
      "indices" : [ 110, 120 ],
      "id_str" : "14116807",
      "id" : 14116807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/LLhXa6Bm",
      "expanded_url" : "http:\/\/shar.es\/qPVwM",
      "display_url" : "shar.es\/qPVwM"
    } ]
  },
  "geo" : { },
  "id_str" : "211393519422685185",
  "text" : "MT @vickyloras RT @evab2001  Lexical notebooks or vocabulary cards? (by @leoselivan) http:\/\/t.co\/LLhXa6Bm via @sharethis",
  "id" : 211393519422685185,
  "created_at" : "2012-06-09 09:45:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/ocMOgTyS",
      "expanded_url" : "http:\/\/www.c-s-p.org\/Flyers\/In-Praise-of-Cinematic-Bastardy1-4438-3782-2.htm",
      "display_url" : "c-s-p.org\/Flyers\/In-Prai\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "211384720251035648",
  "text" : "if u r into cinema, a small promotion for a book my wife has written a chapter in, http:\/\/t.co\/ocMOgTyS",
  "id" : 211384720251035648,
  "created_at" : "2012-06-09 09:10:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 54, 65 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/ccS3EsdO",
      "expanded_url" : "http:\/\/hughdellar.wordpress.com\/2012\/06\/08\/a-section-of-another-coursebook-based-lesson-in-some-detail\/",
      "display_url" : "hughdellar.wordpress.com\/2012\/06\/08\/a-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "211380107753959424",
  "text" : "an amazingly meaty classroom nuts and bolts post from @hughdellar http:\/\/t.co\/ccS3EsdO",
  "id" : 211380107753959424,
  "created_at" : "2012-06-09 08:51:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth Anne",
      "screen_name" : "eannegrenoble",
      "indices" : [ 0, 14 ],
      "id_str" : "19869781",
      "id" : 19869781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "210806513508425728",
  "geo" : { },
  "id_str" : "210825164156452865",
  "in_reply_to_user_id" : 19869781,
  "text" : "@eannegrenoble ah right okay thanks",
  "id" : 210825164156452865,
  "in_reply_to_status_id" : 210806513508425728,
  "created_at" : "2012-06-07 20:06:50 +0000",
  "in_reply_to_screen_name" : "eannegrenoble",
  "in_reply_to_user_id_str" : "19869781",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol Goodey",
      "screen_name" : "cgoodey",
      "indices" : [ 3, 11 ],
      "id_str" : "26606833",
      "id" : 26606833
    }, {
      "name" : "Jemma Gardner",
      "screen_name" : "jemjemgardner",
      "indices" : [ 15, 29 ],
      "id_str" : "79997086",
      "id" : 79997086
    }, {
      "name" : "Shelly Sanchez",
      "screen_name" : "ShellTerrell",
      "indices" : [ 36, 49 ],
      "id_str" : "29655018",
      "id" : 29655018
    }, {
      "name" : "Ian James",
      "screen_name" : "ij64",
      "indices" : [ 109, 114 ],
      "id_str" : "13726222",
      "id" : 13726222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/bE2SIUmy",
      "expanded_url" : "http:\/\/bit.ly\/K0pFmg",
      "display_url" : "bit.ly\/K0pFmg"
    } ]
  },
  "geo" : { },
  "id_str" : "210757487886995456",
  "text" : "RT @cgoodey RT @jemjemgardner &amp; @ShellTerrell: F*ck! The f*cking f*cker\u2019s f*cked! http:\/\/t.co\/bE2SIUmy ~ @ij64&lt;-tee hee",
  "id" : 210757487886995456,
  "created_at" : "2012-06-07 15:37:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Ruelle",
      "screen_name" : "danrmitvn",
      "indices" : [ 0, 10 ],
      "id_str" : "125853393",
      "id" : 125853393
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "210568712074444800",
  "geo" : { },
  "id_str" : "210753975258054659",
  "in_reply_to_user_id" : 125853393,
  "text" : "@danrmitvn ah be interested to read how you are doing this",
  "id" : 210753975258054659,
  "in_reply_to_status_id" : 210568712074444800,
  "created_at" : "2012-06-07 15:23:57 +0000",
  "in_reply_to_screen_name" : "danrmitvn",
  "in_reply_to_user_id_str" : "125853393",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maria Popova",
      "screen_name" : "brainpicker",
      "indices" : [ 0, 12 ],
      "id_str" : "9207632",
      "id" : 9207632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "210483849363324928",
  "geo" : { },
  "id_str" : "210752959477317632",
  "in_reply_to_user_id" : 9207632,
  "text" : "@brainpicker @SmithsonainMag hi if creativity is defined as something that is novel and useful, how can combinations explain useful part?",
  "id" : 210752959477317632,
  "in_reply_to_status_id" : 210483849363324928,
  "created_at" : "2012-06-07 15:19:55 +0000",
  "in_reply_to_screen_name" : "brainpicker",
  "in_reply_to_user_id_str" : "9207632",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "indices" : [ 0, 13 ],
      "id_str" : "1685397408",
      "id" : 1685397408
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "121tefl",
      "indices" : [ 105, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210699735194017792",
  "text" : "@harrisonmike find out what skill(s) they want to focus on, find out their interests, remix these two :) #121tefl",
  "id" : 210699735194017792,
  "created_at" : "2012-06-07 11:48:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Phelps",
      "screen_name" : "pterolaur",
      "indices" : [ 0, 10 ],
      "id_str" : "90093887",
      "id" : 90093887
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HIGNFY",
      "indices" : [ 20, 27 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "210499814926991360",
  "geo" : { },
  "id_str" : "210501285911330816",
  "in_reply_to_user_id" : 90093887,
  "text" : "@pterolaur not seen #HIGNFY for yonks, the thought of AC just galls me :(, hope u r enjoying yr hols :)",
  "id" : 210501285911330816,
  "in_reply_to_status_id" : 210499814926991360,
  "created_at" : "2012-06-06 22:39:52 +0000",
  "in_reply_to_screen_name" : "pterolaur",
  "in_reply_to_user_id_str" : "90093887",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Phelps",
      "screen_name" : "pterolaur",
      "indices" : [ 0, 10 ],
      "id_str" : "90093887",
      "id" : 90093887
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HIGNFY",
      "indices" : [ 30, 37 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "210496462193311744",
  "geo" : { },
  "id_str" : "210498267086204928",
  "in_reply_to_user_id" : 90093887,
  "text" : "@pterolaur 2 out 3 ain't bad, #HIGNFY with Alastair Campbell like university sarcasm ate itself, burping smugly whilst cribbing a thesis",
  "id" : 210498267086204928,
  "in_reply_to_status_id" : 210496462193311744,
  "created_at" : "2012-06-06 22:27:52 +0000",
  "in_reply_to_screen_name" : "pterolaur",
  "in_reply_to_user_id_str" : "90093887",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/1LQ1Y4iX",
      "expanded_url" : "http:\/\/members5.boardhost.com\/medialens\/msg\/1338993681.html",
      "display_url" : "members5.boardhost.com\/medialens\/msg\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "210494718742769665",
  "text" : "\"the genius of England\" hehe Starkey wot a nutter http:\/\/t.co\/1LQ1Y4iX",
  "id" : 210494718742769665,
  "created_at" : "2012-06-06 22:13:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "210478892010586115",
  "geo" : { },
  "id_str" : "210479345020567553",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt naturally u r THE point guy for EAP on twitter :)",
  "id" : 210479345020567553,
  "in_reply_to_status_id" : 210478892010586115,
  "created_at" : "2012-06-06 21:12:41 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth Anne",
      "screen_name" : "eannegrenoble",
      "indices" : [ 0, 14 ],
      "id_str" : "19869781",
      "id" : 19869781
    }, {
      "name" : "Sue Annan",
      "screen_name" : "SueAnnan",
      "indices" : [ 18, 27 ],
      "id_str" : "136001411",
      "id" : 136001411
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210478239485919233",
  "in_reply_to_user_id" : 19869781,
  "text" : "@eannegrenoble hi @SueAnnan mentioned a corpus u built for sts, is there any ref i can read on this? thx",
  "id" : 210478239485919233,
  "created_at" : "2012-06-06 21:08:17 +0000",
  "in_reply_to_screen_name" : "eannegrenoble",
  "in_reply_to_user_id_str" : "19869781",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sue Annan",
      "screen_name" : "SueAnnan",
      "indices" : [ 0, 9 ],
      "id_str" : "136001411",
      "id" : 136001411
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "210477698085175297",
  "geo" : { },
  "id_str" : "210477830780366848",
  "in_reply_to_user_id" : 136001411,
  "text" : "@SueAnnan ok will do thx again",
  "id" : 210477830780366848,
  "in_reply_to_status_id" : 210477698085175297,
  "created_at" : "2012-06-06 21:06:40 +0000",
  "in_reply_to_screen_name" : "SueAnnan",
  "in_reply_to_user_id_str" : "136001411",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sue Annan",
      "screen_name" : "SueAnnan",
      "indices" : [ 0, 9 ],
      "id_str" : "136001411",
      "id" : 136001411
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "210477379355820032",
  "geo" : { },
  "id_str" : "210477616296235008",
  "in_reply_to_user_id" : 136001411,
  "text" : "@SueAnnan ah great is there a link?",
  "id" : 210477616296235008,
  "in_reply_to_status_id" : 210477379355820032,
  "created_at" : "2012-06-06 21:05:48 +0000",
  "in_reply_to_screen_name" : "SueAnnan",
  "in_reply_to_user_id_str" : "136001411",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sue Annan",
      "screen_name" : "SueAnnan",
      "indices" : [ 0, 9 ],
      "id_str" : "136001411",
      "id" : 136001411
    }, {
      "name" : "Elizabeth Anne",
      "screen_name" : "eannegrenoble",
      "indices" : [ 10, 24 ],
      "id_str" : "19869781",
      "id" : 19869781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "210472523228381184",
  "geo" : { },
  "id_str" : "210477241392566273",
  "in_reply_to_user_id" : 136001411,
  "text" : "@SueAnnan @eannegrenoble sorry lost thread on this what was it in ref to? thx",
  "id" : 210477241392566273,
  "in_reply_to_status_id" : 210472523228381184,
  "created_at" : "2012-06-06 21:04:19 +0000",
  "in_reply_to_screen_name" : "SueAnnan",
  "in_reply_to_user_id_str" : "136001411",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 35, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210476635475025920",
  "text" : "cheers all and to mods \/clap clap\/ #eltchat",
  "id" : 210476635475025920,
  "created_at" : "2012-06-06 21:01:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 22, 30 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 81, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/HyVD8zHI",
      "expanded_url" : "http:\/\/fourc.ca\/vrt12\/",
      "display_url" : "fourc.ca\/vrt12\/"
    } ]
  },
  "geo" : { },
  "id_str" : "210474905693728768",
  "text" : "re using blogs in EAP @seburnt has posted http:\/\/t.co\/HyVD8zHI, focus on reading #eltchat",
  "id" : 210474905693728768,
  "created_at" : "2012-06-06 20:55:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Moore",
      "screen_name" : "lexicojules",
      "indices" : [ 0, 12 ],
      "id_str" : "424320799",
      "id" : 424320799
    }, {
      "name" : "Charles Rei",
      "screen_name" : "Charlesrei1",
      "indices" : [ 33, 45 ],
      "id_str" : "464454382",
      "id" : 464454382
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 81, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/bNPM7HeQ",
      "expanded_url" : "http:\/\/businessenglishideas.blogspot.de\/",
      "display_url" : "businessenglishideas.blogspot.de"
    } ]
  },
  "in_reply_to_status_id_str" : "210472673736802305",
  "geo" : { },
  "id_str" : "210473607871209472",
  "in_reply_to_user_id" : 424320799,
  "text" : "@lexicojules it can be depending @Charlesrei1 shows one way http:\/\/t.co\/bNPM7HeQ #eltchat",
  "id" : 210473607871209472,
  "in_reply_to_status_id" : 210472673736802305,
  "created_at" : "2012-06-06 20:49:53 +0000",
  "in_reply_to_screen_name" : "lexicojules",
  "in_reply_to_user_id_str" : "424320799",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 97, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/DYjkbh9L",
      "expanded_url" : "http:\/\/www.antlab.sci.waseda.ac.jp\/software.html",
      "display_url" : "antlab.sci.waseda.ac.jp\/software.html"
    } ]
  },
  "geo" : { },
  "id_str" : "210472390298312704",
  "text" : "for EAP or ESP it is worth making your own corpus using relvant tools e.g. http:\/\/t.co\/DYjkbh9L  #eltchat",
  "id" : 210472390298312704,
  "created_at" : "2012-06-06 20:45:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Moore",
      "screen_name" : "lexicojules",
      "indices" : [ 0, 12 ],
      "id_str" : "424320799",
      "id" : 424320799
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 82, 90 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "210469176370921472",
  "geo" : { },
  "id_str" : "210469771592998914",
  "in_reply_to_user_id" : 424320799,
  "text" : "@lexicojules enjoyed your recent talk, though only got through half of it so far! #eltchat",
  "id" : 210469771592998914,
  "in_reply_to_status_id" : 210469176370921472,
  "created_at" : "2012-06-06 20:34:38 +0000",
  "in_reply_to_screen_name" : "lexicojules",
  "in_reply_to_user_id_str" : "424320799",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clive Elsmore",
      "screen_name" : "CliveSir",
      "indices" : [ 0, 9 ],
      "id_str" : "100746717",
      "id" : 100746717
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 56, 64 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "210468409400500224",
  "geo" : { },
  "id_str" : "210469462472794112",
  "in_reply_to_user_id" : 100746717,
  "text" : "@CliveSir that Oxford EAP book by OUP looks pretty good #eltchat",
  "id" : 210469462472794112,
  "in_reply_to_status_id" : 210468409400500224,
  "created_at" : "2012-06-06 20:33:24 +0000",
  "in_reply_to_screen_name" : "CliveSir",
  "in_reply_to_user_id_str" : "100746717",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MarisaConstantinides",
      "screen_name" : "Marisa_C",
      "indices" : [ 0, 9 ],
      "id_str" : "18272500",
      "id" : 18272500
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 35, 43 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "210468156848865281",
  "geo" : { },
  "id_str" : "210468648031236096",
  "in_reply_to_user_id" : 18272500,
  "text" : "@Marisa_C grt, how did you use it? #eltchat",
  "id" : 210468648031236096,
  "in_reply_to_status_id" : 210468156848865281,
  "created_at" : "2012-06-06 20:30:10 +0000",
  "in_reply_to_screen_name" : "Marisa_C",
  "in_reply_to_user_id_str" : "18272500",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 73, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/oCxo5FJ4",
      "expanded_url" : "http:\/\/corpus.byu.edu\/coca\/",
      "display_url" : "corpus.byu.edu\/coca\/"
    } ]
  },
  "geo" : { },
  "id_str" : "210467892200873986",
  "text" : "if anyone has used the byu academic yet let me know http:\/\/t.co\/oCxo5FJ4 #eltchat",
  "id" : 210467892200873986,
  "created_at" : "2012-06-06 20:27:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Moore",
      "screen_name" : "lexicojules",
      "indices" : [ 3, 15 ],
      "id_str" : "424320799",
      "id" : 424320799
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 138, 146 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/tBw2ryFm",
      "expanded_url" : "http:\/\/the.sketchengine.co.uk\/open\/",
      "display_url" : "the.sketchengine.co.uk\/open\/"
    } ]
  },
  "geo" : { },
  "id_str" : "210467059237265408",
  "text" : "MT @lexicojules: Some  academic corpora include BAWE &amp; BASE - both good for checking NS student usage http:\/\/t.co\/tBw2ryFm&lt;--nice! #eltchat",
  "id" : 210467059237265408,
  "created_at" : "2012-06-06 20:23:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 18, 26 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 86, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/igM3uFPu",
      "expanded_url" : "http:\/\/fourc.ca\/eapchat_sum_mar\/",
      "display_url" : "fourc.ca\/eapchat_sum_ma\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "210466223660597248",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt hosted a #eapchat before and some rel tools listed here http:\/\/t.co\/igM3uFPu #eltchat",
  "id" : 210466223660597248,
  "created_at" : "2012-06-06 20:20:32 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naomi Epstein",
      "screen_name" : "naomishema",
      "indices" : [ 0, 11 ],
      "id_str" : "228469472",
      "id" : 228469472
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 59, 67 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "210464886021566464",
  "geo" : { },
  "id_str" : "210465320916365314",
  "in_reply_to_user_id" : 228469472,
  "text" : "@naomishema BAWE = British Academic Written English corpus #eltchat",
  "id" : 210465320916365314,
  "in_reply_to_status_id" : 210464886021566464,
  "created_at" : "2012-06-06 20:16:57 +0000",
  "in_reply_to_screen_name" : "naomishema",
  "in_reply_to_user_id_str" : "228469472",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 115, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 9, 29 ],
      "url" : "http:\/\/t.co\/Fe328xdS",
      "expanded_url" : "http:\/\/tinyurl.com\/83w9q3t",
      "display_url" : "tinyurl.com\/83w9q3t"
    }, {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/e9yDZQDr",
      "expanded_url" : "http:\/\/ota.ahds.ac.uk\/desc\/2539",
      "display_url" : "ota.ahds.ac.uk\/desc\/2539"
    } ]
  },
  "geo" : { },
  "id_str" : "210464803867725824",
  "text" : "this vid http:\/\/t.co\/Fe328xdS talks about BAWE for written work http:\/\/t.co\/e9yDZQDr but you need to get approval  #eltchat",
  "id" : 210464803867725824,
  "created_at" : "2012-06-06 20:14:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 56, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/oCxo5FJ4",
      "expanded_url" : "http:\/\/corpus.byu.edu\/coca\/",
      "display_url" : "corpus.byu.edu\/coca\/"
    } ]
  },
  "geo" : { },
  "id_str" : "210462232843264000",
  "text" : "the byu academic corpus looks good http:\/\/t.co\/oCxo5FJ4 #eltchat",
  "id" : 210462232843264000,
  "created_at" : "2012-06-06 20:04:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EDTECH HULK",
      "screen_name" : "EDTECHHULK",
      "indices" : [ 3, 14 ],
      "id_str" : "235000147",
      "id" : 235000147
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210402540083359745",
  "text" : "RT @EDTECHHULK: BE SURE CHANGE LINKEDIN PASSWORD! JUST IN CASE LINKEDIN EVER GOOD FOR ANYTHING!&lt;hehe",
  "id" : 210402540083359745,
  "created_at" : "2012-06-06 16:07:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AKIRA THE DON",
      "screen_name" : "akirathedon",
      "indices" : [ 57, 69 ],
      "id_str" : "18225967",
      "id" : 18225967
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "prometheus",
      "indices" : [ 88, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/jIV8TThC",
      "expanded_url" : "http:\/\/bit.ly\/JIUuHw",
      "display_url" : "bit.ly\/JIUuHw"
    } ]
  },
  "geo" : { },
  "id_str" : "210388358432690178",
  "text" : "'and shit Ripley replacement (let\u2019s call her \u201CShitley\u201D)' @akirathedon downs the lows of #prometheus http:\/\/t.co\/jIV8TThC",
  "id" : 210388358432690178,
  "created_at" : "2012-06-06 15:11:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#ELTchat",
      "screen_name" : "ELTchat",
      "indices" : [ 38, 46 ],
      "id_str" : "189578708",
      "id" : 189578708
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELTchat",
      "indices" : [ 8, 16 ]
    } ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http:\/\/t.co\/wHbXlIfW",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-9E",
      "display_url" : "wp.me\/pgHyE-9E"
    } ]
  },
  "geo" : { },
  "id_str" : "210378891011960832",
  "in_reply_to_user_id" : 189578708,
  "text" : "preview #ELTchat http:\/\/t.co\/wHbXlIfW\n@ELTchat , shame twitter does not embed animated gifs",
  "id" : 210378891011960832,
  "created_at" : "2012-06-06 14:33:30 +0000",
  "in_reply_to_screen_name" : "ELTchat",
  "in_reply_to_user_id_str" : "189578708",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elinda Gjondedaj",
      "screen_name" : "ElindaGjondedaj",
      "indices" : [ 3, 19 ],
      "id_str" : "72877592",
      "id" : 72877592
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iTunes",
      "indices" : [ 82, 89 ]
    }, {
      "text" : "ipaded",
      "indices" : [ 90, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/IWFiaon6",
      "expanded_url" : "http:\/\/itun.es\/isb5GB",
      "display_url" : "itun.es\/isb5GB"
    } ]
  },
  "geo" : { },
  "id_str" : "209942249839149056",
  "text" : "MT @ElindaGjondedaj: My first education app for iPad Spot it http:\/\/t.co\/IWFiaon6 #iTunes #ipaded&lt;--grt will u blog the development?",
  "id" : 209942249839149056,
  "created_at" : "2012-06-05 09:38:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/wsajTdUQ",
      "expanded_url" : "http:\/\/www.socialistworker.co.uk\/art.php?id=28601",
      "display_url" : "socialistworker.co.uk\/art.php?id=286\u2026"
    }, {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/xpZVQj4I",
      "expanded_url" : "http:\/\/le-nouveau-poireau-rouge.blogspot.fr\/",
      "display_url" : "le-nouveau-poireau-rouge.blogspot.fr"
    } ]
  },
  "geo" : { },
  "id_str" : "209760970707435520",
  "text" : "The Royal Tradition Invented http:\/\/t.co\/wsajTdUQ HT http:\/\/t.co\/xpZVQj4I",
  "id" : 209760970707435520,
  "created_at" : "2012-06-04 21:38:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http:\/\/t.co\/fXPu9wvU",
      "expanded_url" : "http:\/\/www.gamesmonitor.org.uk\/",
      "display_url" : "gamesmonitor.org.uk"
    } ]
  },
  "geo" : { },
  "id_str" : "209757713884909568",
  "text" : "Olympic Inoculation no5:http:\/\/t.co\/fXPu9wvU",
  "id" : 209757713884909568,
  "created_at" : "2012-06-04 21:25:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sophia Khan",
      "screen_name" : "SophiaKhan4",
      "indices" : [ 0, 12 ],
      "id_str" : "351390617",
      "id" : 351390617
    }, {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "indices" : [ 13, 26 ],
      "id_str" : "1685397408",
      "id" : 1685397408
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/209404205079859200\/photo\/1",
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/ro9i4diW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Auf0A9qCEAEtqFj.jpg",
      "id_str" : "209404205084053505",
      "id" : 209404205084053505,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Auf0A9qCEAEtqFj.jpg",
      "sizes" : [ {
        "h" : 288,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 408,
        "resize" : "fit",
        "w" : 850
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 163,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 408,
        "resize" : "fit",
        "w" : 850
      } ],
      "display_url" : "pic.twitter.com\/ro9i4diW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "209399289254907907",
  "geo" : { },
  "id_str" : "209404205079859200",
  "in_reply_to_user_id" : 351390617,
  "text" : "@SophiaKhan4 @harrisonmike table of verbs from that page is useful i think http:\/\/t.co\/ro9i4diW",
  "id" : 209404205079859200,
  "in_reply_to_status_id" : 209399289254907907,
  "created_at" : "2012-06-03 22:00:28 +0000",
  "in_reply_to_screen_name" : "SophiaKhan4",
  "in_reply_to_user_id_str" : "351390617",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sophia Khan",
      "screen_name" : "SophiaKhan4",
      "indices" : [ 0, 12 ],
      "id_str" : "351390617",
      "id" : 351390617
    }, {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "indices" : [ 13, 26 ],
      "id_str" : "1685397408",
      "id" : 1685397408
    }, {
      "name" : "Anthony Gaughan",
      "screen_name" : "AnthonyGaughan",
      "indices" : [ 27, 42 ],
      "id_str" : "245975798",
      "id" : 245975798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/pyqM0OmP",
      "expanded_url" : "http:\/\/www.edict.biz\/vlc\/funcgrammar\/verbal\/FINITE.HTM",
      "display_url" : "edict.biz\/vlc\/funcgramma\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "209384542790885378",
  "geo" : { },
  "id_str" : "209391642053058560",
  "in_reply_to_user_id" : 351390617,
  "text" : "@SophiaKhan4 @harrisonmike @anthonygaughan this any help from? http:\/\/t.co\/pyqM0OmP, finiteness--&gt;tense or modality (or polarity)",
  "id" : 209391642053058560,
  "in_reply_to_status_id" : 209384542790885378,
  "created_at" : "2012-06-03 21:10:32 +0000",
  "in_reply_to_screen_name" : "SophiaKhan4",
  "in_reply_to_user_id_str" : "351390617",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/sksT4P5I",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-9q",
      "display_url" : "wp.me\/pgHyE-9q"
    } ]
  },
  "geo" : { },
  "id_str" : "209365871662088192",
  "text" : "want to share files with student devices? no internet connection? no problem - http:\/\/t.co\/sksT4P5I",
  "id" : 209365871662088192,
  "created_at" : "2012-06-03 19:28:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephanie McIntosh",
      "screen_name" : "purple_steph",
      "indices" : [ 0, 13 ],
      "id_str" : "18678010",
      "id" : 18678010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "209296784231645184",
  "geo" : { },
  "id_str" : "209298468127252480",
  "in_reply_to_user_id" : 18678010,
  "text" : "@purple_steph yes and yes. the commercialisation of such an event is one thing the accompanying ideology another.",
  "id" : 209298468127252480,
  "in_reply_to_status_id" : 209296784231645184,
  "created_at" : "2012-06-03 15:00:18 +0000",
  "in_reply_to_screen_name" : "purple_steph",
  "in_reply_to_user_id_str" : "18678010",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephanie McIntosh",
      "screen_name" : "purple_steph",
      "indices" : [ 0, 13 ],
      "id_str" : "18678010",
      "id" : 18678010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/HZuXc08M",
      "expanded_url" : "http:\/\/www.scotsman.com\/news\/scottish-news\/top-stories\/unofficial-party-scuppered-by-police-as-scotland-in-two-minds-how-to-mark-a-controversial-anniversary-1-2335396",
      "display_url" : "scotsman.com\/news\/scottish-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "209293637081759747",
  "geo" : { },
  "id_str" : "209296098119004163",
  "in_reply_to_user_id" : 18678010,
  "text" : "@purple_steph u can get some anti-Jubilee sickbags in edinburgh http:\/\/t.co\/HZuXc08M",
  "id" : 209296098119004163,
  "in_reply_to_status_id" : 209293637081759747,
  "created_at" : "2012-06-03 14:50:52 +0000",
  "in_reply_to_screen_name" : "purple_steph",
  "in_reply_to_user_id_str" : "18678010",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Bradley",
      "screen_name" : "EAPteacher",
      "indices" : [ 0, 11 ],
      "id_str" : "1055709992",
      "id" : 1055709992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "209194074710880257",
  "geo" : { },
  "id_str" : "209204364148080640",
  "in_reply_to_user_id" : 20932918,
  "text" : "@eapteacher hi seems u need to add www to start of url for the manchester phrasebank link in your useful links page",
  "id" : 209204364148080640,
  "in_reply_to_status_id" : 209194074710880257,
  "created_at" : "2012-06-03 08:46:21 +0000",
  "in_reply_to_screen_name" : "blairteacher",
  "in_reply_to_user_id_str" : "20932918",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Bradley",
      "screen_name" : "EAPteacher",
      "indices" : [ 3, 14 ],
      "id_str" : "1055709992",
      "id" : 1055709992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/gO5KiIpp",
      "expanded_url" : "http:\/\/post.ly\/7bgEf",
      "display_url" : "post.ly\/7bgEf"
    } ]
  },
  "geo" : { },
  "id_str" : "209199248825270272",
  "text" : "RT @eapteacher: Dictation activities http:\/\/t.co\/gO5KiIpp&lt;--nice collection!",
  "id" : 209199248825270272,
  "created_at" : "2012-06-03 08:26:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "208911686336393216",
  "geo" : { },
  "id_str" : "209065779533053953",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow very good question, apart from formal stuff like HW and quizzes really stumped about informal assessment!",
  "id" : 209065779533053953,
  "in_reply_to_status_id" : 208911686336393216,
  "created_at" : "2012-06-02 23:35:40 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 3, 14 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208831046991609857",
  "text" : "MT @kevchanwow:pick a more reserved student keep track of 1st and last thing they say for a week. Instant lesson barometer &lt;--nice idea",
  "id" : 208831046991609857,
  "created_at" : "2012-06-02 08:02:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "indices" : [ 0, 13 ],
      "id_str" : "1685397408",
      "id" : 1685397408
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "prometheus",
      "indices" : [ 45, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208825920679706624",
  "text" : "@harrisonmike hoping not to be dissapointed! #prometheus",
  "id" : 208825920679706624,
  "created_at" : "2012-06-02 07:42:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TwitPic",
      "screen_name" : "TwitPic",
      "indices" : [ 56, 64 ],
      "id_str" : "12925072",
      "id" : 12925072
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "euref",
      "indices" : [ 24, 30 ]
    } ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/LO0b0Mhk",
      "expanded_url" : "http:\/\/twitpic.com\/9rjkab",
      "display_url" : "twitpic.com\/9rjkab"
    }, {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/ifMC1pqd",
      "expanded_url" : "http:\/\/eurotrib.com",
      "display_url" : "eurotrib.com"
    } ]
  },
  "geo" : { },
  "id_str" : "208682227981238272",
  "text" : "Spoilt vote of the day. #euref http:\/\/t.co\/LO0b0Mhk via @TwitPic HT http:\/\/t.co\/ifMC1pqd",
  "id" : 208682227981238272,
  "created_at" : "2012-06-01 22:11:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/sksT4P5I",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-9q",
      "display_url" : "wp.me\/pgHyE-9q"
    } ]
  },
  "geo" : { },
  "id_str" : "208675185941938176",
  "text" : "new blog post Piratebox, a way to share files in class http:\/\/t.co\/sksT4P5I&lt;-- note still needs tinkering!",
  "id" : 208675185941938176,
  "created_at" : "2012-06-01 21:43:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "indices" : [ 0, 13 ],
      "id_str" : "1685397408",
      "id" : 1685397408
    }, {
      "name" : "phil wade",
      "screen_name" : "phil3wade",
      "indices" : [ 14, 24 ],
      "id_str" : "248864761",
      "id" : 248864761
    }, {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 25, 36 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "Chia Suan Chong",
      "screen_name" : "chiasuan",
      "indices" : [ 37, 46 ],
      "id_str" : "71588589",
      "id" : 71588589
    }, {
      "name" : "Jason R. Levine",
      "screen_name" : "FluencyMC",
      "indices" : [ 61, 71 ],
      "id_str" : "212707934",
      "id" : 212707934
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208655704498774018",
  "text" : "@harrisonmike @phil3wade @leoselivan @chiasuan there is also @FluencyMC a lexical tweeter",
  "id" : 208655704498774018,
  "created_at" : "2012-06-01 20:26:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
} ]