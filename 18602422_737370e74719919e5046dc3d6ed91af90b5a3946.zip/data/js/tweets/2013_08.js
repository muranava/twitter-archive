Grailbird.data.tweets_2013_08 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "indices" : [ 3, 18 ],
      "id_str" : "27716419",
      "id" : 27716419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/Q0ms5gS4Y2",
      "expanded_url" : "http:\/\/bit.ly\/15eto5z",
      "display_url" : "bit.ly\/15eto5z"
    } ]
  },
  "geo" : { },
  "id_str" : "373736155507748864",
  "text" : "RT @CraigMurrayOrg: The Troodos Conundrum: \u00A0 The GCHQ listening post on Mount Troodos in Cyprus is arguably the most valued asset ... http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/Q0ms5gS4Y2",
        "expanded_url" : "http:\/\/bit.ly\/15eto5z",
        "display_url" : "bit.ly\/15eto5z"
      } ]
    },
    "geo" : { },
    "id_str" : "373719209676513280",
    "text" : "The Troodos Conundrum: \u00A0 The GCHQ listening post on Mount Troodos in Cyprus is arguably the most valued asset ... http:\/\/t.co\/Q0ms5gS4Y2",
    "id" : 373719209676513280,
    "created_at" : "2013-08-31 08:09:37 +0000",
    "user" : {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "protected" : false,
      "id_str" : "27716419",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1388436826\/cm_normal.jpg",
      "id" : 27716419,
      "verified" : false
    }
  },
  "id" : 373736155507748864,
  "created_at" : "2013-08-31 09:16:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bethany Cagnol",
      "screen_name" : "bethcagnol",
      "indices" : [ 0, 11 ],
      "id_str" : "27641720",
      "id" : 27641720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373447392806580224",
  "geo" : { },
  "id_str" : "373457072412561408",
  "in_reply_to_user_id" : 27641720,
  "text" : "@bethcagnol ah i see yes, not thought about that. guess they are becoming important maybe more so for certain fields than others?",
  "id" : 373457072412561408,
  "in_reply_to_status_id" : 373447392806580224,
  "created_at" : "2013-08-30 14:47:59 +0000",
  "in_reply_to_screen_name" : "bethcagnol",
  "in_reply_to_user_id_str" : "27641720",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chia Suan Chong",
      "screen_name" : "chiasuan",
      "indices" : [ 3, 12 ],
      "id_str" : "71588589",
      "id" : 71588589
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "efl",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 125, 140 ],
      "url" : "http:\/\/t.co\/jIMS5dmAYw",
      "expanded_url" : "http:\/\/www.etprofessional.com\/5_ways_to_use_the_corpora_for_classroom_activities_84418.aspx",
      "display_url" : "etprofessional.com\/5_ways_to_use_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "373456292758560769",
  "text" : "RT @chiasuan: While my last post looked at the basics of corpus use, this one suggests 5 corpora-based classroom activities.\nhttp:\/\/t.co\/jI\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "efl",
        "indices" : [ 134, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/jIMS5dmAYw",
        "expanded_url" : "http:\/\/www.etprofessional.com\/5_ways_to_use_the_corpora_for_classroom_activities_84418.aspx",
        "display_url" : "etprofessional.com\/5_ways_to_use_\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "373416311453671424",
    "text" : "While my last post looked at the basics of corpus use, this one suggests 5 corpora-based classroom activities.\nhttp:\/\/t.co\/jIMS5dmAYw #efl",
    "id" : 373416311453671424,
    "created_at" : "2013-08-30 12:06:01 +0000",
    "user" : {
      "name" : "Chia Suan Chong",
      "screen_name" : "chiasuan",
      "protected" : false,
      "id_str" : "71588589",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1672976345\/IMG_1047_normal.jpg",
      "id" : 71588589,
      "verified" : false
    }
  },
  "id" : 373456292758560769,
  "created_at" : "2013-08-30 14:44:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KELTChat",
      "indices" : [ 121, 130 ]
    }, {
      "text" : "TeachingEnglish",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/Cxt8CSnWBv",
      "expanded_url" : "http:\/\/www.alienteachers.com\/1\/post\/2013\/08\/just-how-useful-are-those-ns-expressions.html",
      "display_url" : "alienteachers.com\/1\/post\/2013\/08\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "373378342281428992",
  "text" : "RT @AlexSWalsh: New post on AlienTeachers - Just how useful are those Native Speaker Expressions? http:\/\/t.co\/Cxt8CSnWBv #KELTChat #Teachin\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "KELTChat",
        "indices" : [ 105, 114 ]
      }, {
        "text" : "TeachingEnglish",
        "indices" : [ 115, 131 ]
      } ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/Cxt8CSnWBv",
        "expanded_url" : "http:\/\/www.alienteachers.com\/1\/post\/2013\/08\/just-how-useful-are-those-ns-expressions.html",
        "display_url" : "alienteachers.com\/1\/post\/2013\/08\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "373345589854867456",
    "text" : "New post on AlienTeachers - Just how useful are those Native Speaker Expressions? http:\/\/t.co\/Cxt8CSnWBv #KELTChat #TeachingEnglish",
    "id" : 373345589854867456,
    "created_at" : "2013-08-30 07:24:59 +0000",
    "user" : {
      "name" : "Alex Walsh",
      "screen_name" : "AlexSRWalsh",
      "protected" : false,
      "id_str" : "228747458",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738934802355617793\/veV8228l_normal.jpg",
      "id" : 228747458,
      "verified" : false
    }
  },
  "id" : 373378342281428992,
  "created_at" : "2013-08-30 09:35:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesus Romero-Trillo",
      "screen_name" : "jromerotrillo",
      "indices" : [ 3, 17 ],
      "id_str" : "124584132",
      "id" : 124584132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/rqdlHJiZxu",
      "expanded_url" : "http:\/\/bit.ly\/1dsxuiE",
      "display_url" : "bit.ly\/1dsxuiE"
    } ]
  },
  "geo" : { },
  "id_str" : "373365235970629633",
  "text" : "RT @jromerotrillo: Jafaican it? No we\u2019re not | Mind your language http:\/\/t.co\/rqdlHJiZxu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 69 ],
        "url" : "http:\/\/t.co\/rqdlHJiZxu",
        "expanded_url" : "http:\/\/bit.ly\/1dsxuiE",
        "display_url" : "bit.ly\/1dsxuiE"
      } ]
    },
    "geo" : { },
    "id_str" : "373362727852707841",
    "text" : "Jafaican it? No we\u2019re not | Mind your language http:\/\/t.co\/rqdlHJiZxu",
    "id" : 373362727852707841,
    "created_at" : "2013-08-30 08:33:05 +0000",
    "user" : {
      "name" : "Jesus Romero-Trillo",
      "screen_name" : "jromerotrillo",
      "protected" : false,
      "id_str" : "124584132",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762172199222571008\/Y4n9__6n_normal.jpg",
      "id" : 124584132,
      "verified" : false
    }
  },
  "id" : 373365235970629633,
  "created_at" : "2013-08-30 08:43:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 3, 14 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "YOUmatter",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 140 ],
      "url" : "http:\/\/t.co\/5gS40KHKCa",
      "expanded_url" : "http:\/\/bit.ly\/189AVoD",
      "display_url" : "bit.ly\/189AVoD"
    } ]
  },
  "geo" : { },
  "id_str" : "373364676144271361",
  "text" : "RT @tornhalves: \"Widespread belief in \u2018raising self-esteem\u2019 as an all-purpose cure for  social problems is snake oil.\" http:\/\/t.co\/5gS40KHK\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "YOUmatter",
        "indices" : [ 126, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/5gS40KHKCa",
        "expanded_url" : "http:\/\/bit.ly\/189AVoD",
        "display_url" : "bit.ly\/189AVoD"
      } ]
    },
    "geo" : { },
    "id_str" : "373343081258426370",
    "text" : "\"Widespread belief in \u2018raising self-esteem\u2019 as an all-purpose cure for  social problems is snake oil.\" http:\/\/t.co\/5gS40KHKCa #YOUmatter",
    "id" : 373343081258426370,
    "created_at" : "2013-08-30 07:15:01 +0000",
    "user" : {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "protected" : false,
      "id_str" : "87902543",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3059742703\/1d3c7a2052db17d29644fa0a49af6480_normal.jpeg",
      "id" : 87902543,
      "verified" : false
    }
  },
  "id" : 373364676144271361,
  "created_at" : "2013-08-30 08:40:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Pride",
      "screen_name" : "ThomasPride",
      "indices" : [ 89, 101 ],
      "id_str" : "385867551",
      "id" : 385867551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/YJmO7HBqJR",
      "expanded_url" : "http:\/\/wp.me\/p1U04a-5bF",
      "display_url" : "wp.me\/p1U04a-5bF"
    } ]
  },
  "geo" : { },
  "id_str" : "373220095750721536",
  "text" : "Syria Attack Attacked After Syrian Attack on Syrians Attacked http:\/\/t.co\/YJmO7HBqJR via @ThomasPride",
  "id" : 373220095750721536,
  "created_at" : "2013-08-29 23:06:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 79, 87 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/sjhNrhubiW",
      "expanded_url" : "http:\/\/youtu.be\/QWU6tVxzO1I",
      "display_url" : "youtu.be\/QWU6tVxzO1I"
    } ]
  },
  "geo" : { },
  "id_str" : "373205513162334208",
  "text" : "Australian Election: A Game of Polls [RAP NEWS 20]: http:\/\/t.co\/sjhNrhubiW via @youtube &gt; ROFL",
  "id" : 373205513162334208,
  "created_at" : "2013-08-29 22:08:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jo Sayers",
      "screen_name" : "jo_sayers",
      "indices" : [ 0, 10 ],
      "id_str" : "87176766",
      "id" : 87176766
    }, {
      "name" : "\u041A\u0443\u043B\u0430\u043A\u043E\u0432a \u0421\u0432\u0435\u0442\u043B\u0430\u043D\u0430",
      "screen_name" : "HollieMcNish",
      "indices" : [ 11, 24 ],
      "id_str" : "2833761651",
      "id" : 2833761651
    }, {
      "name" : "FLO RIDA",
      "screen_name" : "official_flo",
      "indices" : [ 25, 38 ],
      "id_str" : "29547045",
      "id" : 29547045
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373174936979775488",
  "geo" : { },
  "id_str" : "373203660945104898",
  "in_reply_to_user_id" : 87176766,
  "text" : "@jo_sayers @HollieMcNish @official_flo yeh for sure he's got to own up to it as a subversive ode to Edward Snowden, Chelsea Manning et al :)",
  "id" : 373203660945104898,
  "in_reply_to_status_id" : 373174936979775488,
  "created_at" : "2013-08-29 22:01:01 +0000",
  "in_reply_to_screen_name" : "jo_sayers",
  "in_reply_to_user_id_str" : "87176766",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jo Sayers",
      "screen_name" : "jo_sayers",
      "indices" : [ 0, 10 ],
      "id_str" : "87176766",
      "id" : 87176766
    }, {
      "name" : "\u041A\u0443\u043B\u0430\u043A\u043E\u0432a \u0421\u0432\u0435\u0442\u043B\u0430\u043D\u0430",
      "screen_name" : "HollieMcNish",
      "indices" : [ 11, 24 ],
      "id_str" : "2833761651",
      "id" : 2833761651
    }, {
      "name" : "FLO RIDA",
      "screen_name" : "official_flo",
      "indices" : [ 25, 38 ],
      "id_str" : "29547045",
      "id" : 29547045
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373171727133458433",
  "geo" : { },
  "id_str" : "373173921408774144",
  "in_reply_to_user_id" : 87176766,
  "text" : "@jo_sayers @HollieMcNish @official_flo hehe that's a crisp on point diss :)",
  "id" : 373173921408774144,
  "in_reply_to_status_id" : 373171727133458433,
  "created_at" : "2013-08-29 20:02:50 +0000",
  "in_reply_to_screen_name" : "jo_sayers",
  "in_reply_to_user_id_str" : "87176766",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 3, 14 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KenRobinson",
      "indices" : [ 19, 31 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/0RTsd7cNMH",
      "expanded_url" : "http:\/\/bit.ly\/12IdAdK",
      "display_url" : "bit.ly\/12IdAdK"
    } ]
  },
  "geo" : { },
  "id_str" : "372860123980394496",
  "text" : "RT @tornhalves: Re #KenRobinson : Does finding your Element = learning to love the Iron Cage? http:\/\/t.co\/0RTsd7cNMH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "KenRobinson",
        "indices" : [ 3, 15 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/0RTsd7cNMH",
        "expanded_url" : "http:\/\/bit.ly\/12IdAdK",
        "display_url" : "bit.ly\/12IdAdK"
      } ]
    },
    "geo" : { },
    "id_str" : "372415729204617217",
    "text" : "Re #KenRobinson : Does finding your Element = learning to love the Iron Cage? http:\/\/t.co\/0RTsd7cNMH",
    "id" : 372415729204617217,
    "created_at" : "2013-08-27 17:50:03 +0000",
    "user" : {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "protected" : false,
      "id_str" : "87902543",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3059742703\/1d3c7a2052db17d29644fa0a49af6480_normal.jpeg",
      "id" : 87902543,
      "verified" : false
    }
  },
  "id" : 372860123980394496,
  "created_at" : "2013-08-28 23:15:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annette Porte",
      "screen_name" : "tinytexts",
      "indices" : [ 16, 26 ],
      "id_str" : "634655752",
      "id" : 634655752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372804372905721856",
  "text" : "top marks  \u2714 to @tinytexts for engaging some students of mine this week",
  "id" : 372804372905721856,
  "created_at" : "2013-08-28 19:34:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372800578851569664",
  "text" : "the twitter bluelines for linked convos r pretty freaky :)",
  "id" : 372800578851569664,
  "created_at" : "2013-08-28 19:19:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bethany Cagnol",
      "screen_name" : "bethcagnol",
      "indices" : [ 0, 11 ],
      "id_str" : "27641720",
      "id" : 27641720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372589194407067648",
  "geo" : { },
  "id_str" : "372641962936913920",
  "in_reply_to_user_id" : 27641720,
  "text" : "@bethcagnol sry i was being flippant; is there much difference btw paper CV and electronic? r u thinking of multimedia\/video CVs?",
  "id" : 372641962936913920,
  "in_reply_to_status_id" : 372589194407067648,
  "created_at" : "2013-08-28 08:49:01 +0000",
  "in_reply_to_screen_name" : "bethcagnol",
  "in_reply_to_user_id_str" : "27641720",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alfredo Zuloaga",
      "screen_name" : "AlfredoZuloaga",
      "indices" : [ 15, 30 ],
      "id_str" : "196169066",
      "id" : 196169066
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372480422170472448",
  "text" : "@Florentina__T @AlfredoZuloaga clicking w\/o thinking is a daily tradeof of netlife :\/",
  "id" : 372480422170472448,
  "created_at" : "2013-08-27 22:07:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Li-Shih Huang, PhD",
      "screen_name" : "AppLingProf",
      "indices" : [ 3, 15 ],
      "id_str" : "128714685",
      "id" : 128714685
    }, {
      "name" : "ExplorationsofStyle",
      "screen_name" : "explorstyle",
      "indices" : [ 143, 144 ],
      "id_str" : "356850668",
      "id" : 356850668
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/LwS7udNHSO",
      "expanded_url" : "http:\/\/bit.ly\/17hzzKa",
      "display_url" : "bit.ly\/17hzzKa"
    } ]
  },
  "geo" : { },
  "id_str" : "372477821492273153",
  "text" : "RT @AppLingProf: Lang learners as lang researchers -- \u201Clet Ss [explore &amp;] become investigators of academic language\" http:\/\/t.co\/LwS7udNHSO\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ExplorationsofStyle",
        "screen_name" : "explorstyle",
        "indices" : [ 131, 143 ],
        "id_str" : "356850668",
        "id" : 356850668
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/LwS7udNHSO",
        "expanded_url" : "http:\/\/bit.ly\/17hzzKa",
        "display_url" : "bit.ly\/17hzzKa"
      } ]
    },
    "geo" : { },
    "id_str" : "372475015964266496",
    "text" : "Lang learners as lang researchers -- \u201Clet Ss [explore &amp;] become investigators of academic language\" http:\/\/t.co\/LwS7udNHSO (HT @explorstyle)",
    "id" : 372475015964266496,
    "created_at" : "2013-08-27 21:45:38 +0000",
    "user" : {
      "name" : "Li-Shih Huang, PhD",
      "screen_name" : "AppLingProf",
      "protected" : false,
      "id_str" : "128714685",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/577224421611466752\/7ozjbHH5_normal.jpeg",
      "id" : 128714685,
      "verified" : false
    }
  },
  "id" : 372477821492273153,
  "created_at" : "2013-08-27 21:56:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bethany Cagnol",
      "screen_name" : "bethcagnol",
      "indices" : [ 0, 11 ],
      "id_str" : "27641720",
      "id" : 27641720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372466084773117952",
  "geo" : { },
  "id_str" : "372470919010070528",
  "in_reply_to_user_id" : 27641720,
  "text" : "@bethcagnol doubtful paperwork will die without a fight in France :)",
  "id" : 372470919010070528,
  "in_reply_to_status_id" : 372466084773117952,
  "created_at" : "2013-08-27 21:29:21 +0000",
  "in_reply_to_screen_name" : "bethcagnol",
  "in_reply_to_user_id_str" : "27641720",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alfredo Zuloaga",
      "screen_name" : "AlfredoZuloaga",
      "indices" : [ 0, 15 ],
      "id_str" : "196169066",
      "id" : 196169066
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/Qaln27k8En",
      "expanded_url" : "http:\/\/eflnotes.wordpress.com\/2012\/04\/01\/no-phishing-here\/",
      "display_url" : "eflnotes.wordpress.com\/2012\/04\/01\/no-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "372467360621273088",
  "geo" : { },
  "id_str" : "372470520970625025",
  "in_reply_to_user_id" : 196169066,
  "text" : "@AlfredoZuloaga @Florentina__T fyi wrote about general precautions one can take http:\/\/t.co\/Qaln27k8En",
  "id" : 372470520970625025,
  "in_reply_to_status_id" : 372467360621273088,
  "created_at" : "2013-08-27 21:27:47 +0000",
  "in_reply_to_screen_name" : "AlfredoZuloaga",
  "in_reply_to_user_id_str" : "196169066",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/5cz5c2cywI",
      "expanded_url" : "http:\/\/ow.ly\/oiFji",
      "display_url" : "ow.ly\/oiFji"
    } ]
  },
  "geo" : { },
  "id_str" : "372452260342542336",
  "text" : "RT @medialens: Latest Alert: Massacres That Matter - 'Responsibility To Protect' In Egypt, Libya And Syria - Part 1 http:\/\/t.co\/5cz5c2cywI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/5cz5c2cywI",
        "expanded_url" : "http:\/\/ow.ly\/oiFji",
        "display_url" : "ow.ly\/oiFji"
      } ]
    },
    "geo" : { },
    "id_str" : "372364028674203649",
    "text" : "Latest Alert: Massacres That Matter - 'Responsibility To Protect' In Egypt, Libya And Syria - Part 1 http:\/\/t.co\/5cz5c2cywI",
    "id" : 372364028674203649,
    "created_at" : "2013-08-27 14:24:37 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 372452260342542336,
  "created_at" : "2013-08-27 20:15:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/zdeHnL2grF",
      "expanded_url" : "http:\/\/lockyep.blogspot.com\/2013\/08\/usage-academic-research-differences-in.html?spref=tw",
      "display_url" : "lockyep.blogspot.com\/2013\/08\/usage-\u2026"
    }, {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/7eL3sYWEiI",
      "expanded_url" : "http:\/\/lockyep.blogspot.com\/2013\/08\/usage-academic-research-differences-in_27.html?spref=tw",
      "display_url" : "lockyep.blogspot.com\/2013\/08\/usage-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "372284592465510400",
  "text" : "Locky's English Playground: Differences In Similar Words - The corpus approach Part 1 http:\/\/t.co\/zdeHnL2grF Part 2 http:\/\/t.co\/7eL3sYWEiI",
  "id" : 372284592465510400,
  "created_at" : "2013-08-27 09:08:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angus B Grieve-Smith",
      "screen_name" : "grvsmth",
      "indices" : [ 0, 8 ],
      "id_str" : "22381639",
      "id" : 22381639
    }, {
      "name" : "\u0648\u0627\u0635\u0642\u0631\u0627\u0647",
      "screen_name" : "saqeram",
      "indices" : [ 9, 17 ],
      "id_str" : "26774872",
      "id" : 26774872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372120793192210432",
  "geo" : { },
  "id_str" : "372126317904273408",
  "in_reply_to_user_id" : 22381639,
  "text" : "@grvsmth @saqeram  woah just fnd out twitter lists can be 1000 woot much more useful than tags imo :)",
  "id" : 372126317904273408,
  "in_reply_to_status_id" : 372120793192210432,
  "created_at" : "2013-08-26 22:40:02 +0000",
  "in_reply_to_screen_name" : "grvsmth",
  "in_reply_to_user_id_str" : "22381639",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 38, 54 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/Sy09piJ7Fg",
      "expanded_url" : "http:\/\/wp.me\/p3xFPk-4i",
      "display_url" : "wp.me\/p3xFPk-4i"
    } ]
  },
  "geo" : { },
  "id_str" : "372121345015824384",
  "text" : "Commencing http:\/\/t.co\/Sy09piJ7Fg via @wordpressdotcom",
  "id" : 372121345015824384,
  "created_at" : "2013-08-26 22:20:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0648\u0627\u0635\u0642\u0631\u0627\u0647",
      "screen_name" : "saqeram",
      "indices" : [ 0, 8 ],
      "id_str" : "26774872",
      "id" : 26774872
    }, {
      "name" : "Angus B Grieve-Smith",
      "screen_name" : "grvsmth",
      "indices" : [ 9, 17 ],
      "id_str" : "22381639",
      "id" : 22381639
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "amirite",
      "indices" : [ 126, 134 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372106571846672384",
  "geo" : { },
  "id_str" : "372119349399547904",
  "in_reply_to_user_id" : 26774872,
  "text" : "@saqeram @grvsmth it's some super secret really-does-exist-we-dont-make-this-sht-up hashtag centrifuge churning the stuff out #amirite",
  "id" : 372119349399547904,
  "in_reply_to_status_id" : 372106571846672384,
  "created_at" : "2013-08-26 22:12:21 +0000",
  "in_reply_to_screen_name" : "saqeram",
  "in_reply_to_user_id_str" : "26774872",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Alexander",
      "screen_name" : "BryanAlexander",
      "indices" : [ 3, 18 ],
      "id_str" : "755991",
      "id" : 755991
    }, {
      "name" : "Jim Groom",
      "screen_name" : "jimgroom",
      "indices" : [ 78, 87 ],
      "id_str" : "3362981",
      "id" : 3362981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/PJGdbhkaAP",
      "expanded_url" : "http:\/\/omnireboot.com\/reviews\/network-of-blood\/",
      "display_url" : "omnireboot.com\/reviews\/networ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "372115756734885888",
  "text" : "RT @BryanAlexander: \"Videodrome is the best movie ever made about Facebook.\"  @jimgroom, your cassette is ready.   http:\/\/t.co\/PJGdbhkaAP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jim Groom",
        "screen_name" : "jimgroom",
        "indices" : [ 58, 67 ],
        "id_str" : "3362981",
        "id" : 3362981
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/PJGdbhkaAP",
        "expanded_url" : "http:\/\/omnireboot.com\/reviews\/network-of-blood\/",
        "display_url" : "omnireboot.com\/reviews\/networ\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "372065106470785025",
    "text" : "\"Videodrome is the best movie ever made about Facebook.\"  @jimgroom, your cassette is ready.   http:\/\/t.co\/PJGdbhkaAP",
    "id" : 372065106470785025,
    "created_at" : "2013-08-26 18:36:48 +0000",
    "user" : {
      "name" : "Bryan Alexander",
      "screen_name" : "BryanAlexander",
      "protected" : false,
      "id_str" : "755991",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/654391499686313986\/1Fx2eBCq_normal.jpg",
      "id" : 755991,
      "verified" : false
    }
  },
  "id" : 372115756734885888,
  "created_at" : "2013-08-26 21:58:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe McVeigh",
      "screen_name" : "EvilJoeMcVeigh",
      "indices" : [ 0, 15 ],
      "id_str" : "1327355143",
      "id" : 1327355143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372083635480186880",
  "geo" : { },
  "id_str" : "372111620480040960",
  "in_reply_to_user_id" : 1327355143,
  "text" : "@EvilJoeMcVeigh i aint never heard no-one never not say such things :\/",
  "id" : 372111620480040960,
  "in_reply_to_status_id" : 372083635480186880,
  "created_at" : "2013-08-26 21:41:38 +0000",
  "in_reply_to_screen_name" : "EvilJoeMcVeigh",
  "in_reply_to_user_id_str" : "1327355143",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Seymour",
      "screen_name" : "leninology",
      "indices" : [ 71, 82 ],
      "id_str" : "15557246",
      "id" : 15557246
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/JZTFGXcWxq",
      "expanded_url" : "http:\/\/www.leninology.com\/2013\/08\/3d-print-your-way-to-freedom.html",
      "display_url" : "leninology.com\/2013\/08\/3d-pri\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "371246631326191616",
  "text" : "LENIN'S TOMB: 3D print your way to freedom! http:\/\/t.co\/JZTFGXcWxq via @leninology",
  "id" : 371246631326191616,
  "created_at" : "2013-08-24 12:24:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "markwarschauer",
      "screen_name" : "markwarschauer",
      "indices" : [ 3, 18 ],
      "id_str" : "17316060",
      "id" : 17316060
    }, {
      "name" : "cliff manning",
      "screen_name" : "cliffmanning",
      "indices" : [ 25, 38 ],
      "id_str" : "137100677",
      "id" : 137100677
    }, {
      "name" : "Mark Dempster",
      "screen_name" : "mdcounselling",
      "indices" : [ 102, 116 ],
      "id_str" : "606971740",
      "id" : 606971740
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/cliffmanning\/status\/370923946494803969\/photo\/1",
      "indices" : [ 126, 140 ],
      "url" : "http:\/\/t.co\/C1eHRVO0QO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BSXJXTYCQAAKcjR.png",
      "id_str" : "370923946503192576",
      "id" : 370923946503192576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSXJXTYCQAAKcjR.png",
      "sizes" : [ {
        "h" : 665,
        "resize" : "fit",
        "w" : 715
      }, {
        "h" : 316,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 665,
        "resize" : "fit",
        "w" : 715
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 558,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/C1eHRVO0QO"
    } ],
    "hashtags" : [ {
      "text" : "edtech",
      "indices" : [ 118, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370968360302829568",
  "text" : "RT @markwarschauer: :-) \u201C@cliffmanning: The new Maslow's hierarchy of needs (in case you missed it by @mdcounselling) #edtech http:\/\/t.co\/C\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "cliff manning",
        "screen_name" : "cliffmanning",
        "indices" : [ 5, 18 ],
        "id_str" : "137100677",
        "id" : 137100677
      }, {
        "name" : "Mark Dempster",
        "screen_name" : "mdcounselling",
        "indices" : [ 82, 96 ],
        "id_str" : "606971740",
        "id" : 606971740
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/cliffmanning\/status\/370923946494803969\/photo\/1",
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/C1eHRVO0QO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BSXJXTYCQAAKcjR.png",
        "id_str" : "370923946503192576",
        "id" : 370923946503192576,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSXJXTYCQAAKcjR.png",
        "sizes" : [ {
          "h" : 665,
          "resize" : "fit",
          "w" : 715
        }, {
          "h" : 316,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 665,
          "resize" : "fit",
          "w" : 715
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 558,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/C1eHRVO0QO"
      } ],
      "hashtags" : [ {
        "text" : "edtech",
        "indices" : [ 98, 105 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "370923946494803969",
    "geo" : { },
    "id_str" : "370925467894697984",
    "in_reply_to_user_id" : 137100677,
    "text" : ":-) \u201C@cliffmanning: The new Maslow's hierarchy of needs (in case you missed it by @mdcounselling) #edtech http:\/\/t.co\/C1eHRVO0QO\u201D",
    "id" : 370925467894697984,
    "in_reply_to_status_id" : 370923946494803969,
    "created_at" : "2013-08-23 15:08:17 +0000",
    "in_reply_to_screen_name" : "cliffmanning",
    "in_reply_to_user_id_str" : "137100677",
    "user" : {
      "name" : "markwarschauer",
      "screen_name" : "markwarschauer",
      "protected" : false,
      "id_str" : "17316060",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535141210432622592\/ZXqkNrhW_normal.jpeg",
      "id" : 17316060,
      "verified" : false
    }
  },
  "id" : 370968360302829568,
  "created_at" : "2013-08-23 17:58:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ForeignPolicyJournal",
      "screen_name" : "ForPolJournal",
      "indices" : [ 80, 94 ],
      "id_str" : "40200634",
      "id" : 40200634
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/7jJY5VLLE0",
      "expanded_url" : "http:\/\/www.foreignpolicyjournal.com\/2013\/08\/21\/traveling-muslims-experience-the-miranda-treatment\/",
      "display_url" : "foreignpolicyjournal.com\/2013\/08\/21\/tra\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "370962085238165504",
  "text" : "Traveling Muslims Experience the 'Miranda' Treatment http:\/\/t.co\/7jJY5VLLE0 via @ForPolJournal",
  "id" : 370962085238165504,
  "created_at" : "2013-08-23 17:33:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Lee",
      "screen_name" : "desktopenglish",
      "indices" : [ 0, 15 ],
      "id_str" : "345925613",
      "id" : 345925613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/nNNffBFKfu",
      "expanded_url" : "http:\/\/www.lexiconcept.com\/portmanteau\/create\/",
      "display_url" : "lexiconcept.com\/portmanteau\/cr\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "370933565044690945",
  "geo" : { },
  "id_str" : "370957134285926400",
  "in_reply_to_user_id" : 345925613,
  "text" : "@desktopenglish among many portmanteaux creators this one is groovy http:\/\/t.co\/nNNffBFKfu",
  "id" : 370957134285926400,
  "in_reply_to_status_id" : 370933565044690945,
  "created_at" : "2013-08-23 17:14:07 +0000",
  "in_reply_to_screen_name" : "desktopenglish",
  "in_reply_to_user_id_str" : "345925613",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Li-Shih Huang, PhD",
      "screen_name" : "AppLingProf",
      "indices" : [ 0, 12 ],
      "id_str" : "128714685",
      "id" : 128714685
    }, {
      "name" : "Stephen Lee",
      "screen_name" : "desktopenglish",
      "indices" : [ 13, 28 ],
      "id_str" : "345925613",
      "id" : 345925613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/6CNre0jhnb",
      "expanded_url" : "http:\/\/eflnotes.wordpress.com\/2013\/07\/02\/just-the-word-alternatives-function-or-how-to-introduce-concordances-to-your-students\/",
      "display_url" : "eflnotes.wordpress.com\/2013\/07\/02\/jus\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "370931425563779073",
  "geo" : { },
  "id_str" : "370932767032221697",
  "in_reply_to_user_id" : 128714685,
  "text" : "@AppLingProf @desktopenglish fyi adapting JtW alternatives feature to a TOEIC ex http:\/\/t.co\/6CNre0jhnb",
  "id" : 370932767032221697,
  "in_reply_to_status_id" : 370931425563779073,
  "created_at" : "2013-08-23 15:37:17 +0000",
  "in_reply_to_screen_name" : "AppLingProf",
  "in_reply_to_user_id_str" : "128714685",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Tual",
      "screen_name" : "AngloFLE",
      "indices" : [ 3, 12 ],
      "id_str" : "109815398",
      "id" : 109815398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/zkGdef5XcW",
      "expanded_url" : "http:\/\/coerll.utexas.edu\/coerll\/languages",
      "display_url" : "coerll.utexas.edu\/coerll\/languag\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "370837616582590464",
  "text" : "RT @AngloFLE: OERs for many languages, worth exploring http:\/\/t.co\/zkGdef5XcW \nIncludes a great textbook for French Beginners",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/zkGdef5XcW",
        "expanded_url" : "http:\/\/coerll.utexas.edu\/coerll\/languages",
        "display_url" : "coerll.utexas.edu\/coerll\/languag\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "370823961073827840",
    "text" : "OERs for many languages, worth exploring http:\/\/t.co\/zkGdef5XcW \nIncludes a great textbook for French Beginners",
    "id" : 370823961073827840,
    "created_at" : "2013-08-23 08:24:56 +0000",
    "user" : {
      "name" : "David Tual",
      "screen_name" : "AngloFLE",
      "protected" : false,
      "id_str" : "109815398",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/665186877\/120px-Share.svg_normal.png",
      "id" : 109815398,
      "verified" : false
    }
  },
  "id" : 370837616582590464,
  "created_at" : "2013-08-23 09:19:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "COPEI",
      "screen_name" : "Copei_EC",
      "indices" : [ 0, 9 ],
      "id_str" : "572290959",
      "id" : 572290959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370826879680262144",
  "in_reply_to_user_id" : 572290959,
  "text" : "@Copei_EC thanks for RT :)",
  "id" : 370826879680262144,
  "created_at" : "2013-08-23 08:36:32 +0000",
  "in_reply_to_screen_name" : "Copei_EC",
  "in_reply_to_user_id_str" : "572290959",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott McLeod",
      "screen_name" : "mcleod",
      "indices" : [ 3, 10 ],
      "id_str" : "4132841",
      "id" : 4132841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/c1SdxWkJEs",
      "expanded_url" : "http:\/\/bit.ly\/17NprXG",
      "display_url" : "bit.ly\/17NprXG"
    } ]
  },
  "geo" : { },
  "id_str" : "370824904557355008",
  "text" : "RT @mcleod: India launches National Repository of Open Educational Resources http:\/\/t.co\/c1SdxWkJEs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/c1SdxWkJEs",
        "expanded_url" : "http:\/\/bit.ly\/17NprXG",
        "display_url" : "bit.ly\/17NprXG"
      } ]
    },
    "geo" : { },
    "id_str" : "370719585735286784",
    "text" : "India launches National Repository of Open Educational Resources http:\/\/t.co\/c1SdxWkJEs",
    "id" : 370719585735286784,
    "created_at" : "2013-08-23 01:30:11 +0000",
    "user" : {
      "name" : "Scott McLeod",
      "screen_name" : "mcleod",
      "protected" : false,
      "id_str" : "4132841",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528513398003077123\/U0fv_0fy_normal.jpeg",
      "id" : 4132841,
      "verified" : false
    }
  },
  "id" : 370824904557355008,
  "created_at" : "2013-08-23 08:28:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Brown",
      "screen_name" : "sbrowntweets",
      "indices" : [ 0, 13 ],
      "id_str" : "885343459",
      "id" : 885343459
    }, {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "indices" : [ 14, 26 ],
      "id_str" : "192437743",
      "id" : 192437743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370659719267889152",
  "geo" : { },
  "id_str" : "370660522074456065",
  "in_reply_to_user_id" : 885343459,
  "text" : "@sbrowntweets @nathanghall sorry ignore last tweet thought it was another russian site!",
  "id" : 370660522074456065,
  "in_reply_to_status_id" : 370659719267889152,
  "created_at" : "2013-08-22 21:35:29 +0000",
  "in_reply_to_screen_name" : "sbrowntweets",
  "in_reply_to_user_id_str" : "885343459",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Brown",
      "screen_name" : "sbrowntweets",
      "indices" : [ 0, 13 ],
      "id_str" : "885343459",
      "id" : 885343459
    }, {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "indices" : [ 14, 26 ],
      "id_str" : "192437743",
      "id" : 192437743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/y6UC47PLEd",
      "expanded_url" : "http:\/\/spbappo.com\/modules\/div\/cyo\/mining%20listening%20texts.pdf",
      "display_url" : "spbappo.com\/modules\/div\/cy\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "370656751906877440",
  "geo" : { },
  "id_str" : "370656976293736448",
  "in_reply_to_user_id" : 885343459,
  "text" : "@sbrowntweets @nathanghall http:\/\/t.co\/y6UC47PLEd",
  "id" : 370656976293736448,
  "in_reply_to_status_id" : 370656751906877440,
  "created_at" : "2013-08-22 21:21:24 +0000",
  "in_reply_to_screen_name" : "sbrowntweets",
  "in_reply_to_user_id_str" : "885343459",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angus B Grieve-Smith",
      "screen_name" : "grvsmth",
      "indices" : [ 0, 8 ],
      "id_str" : "22381639",
      "id" : 22381639
    }, {
      "name" : "Uri Horesh",
      "screen_name" : "urihoresh",
      "indices" : [ 9, 19 ],
      "id_str" : "15664454",
      "id" : 15664454
    }, {
      "name" : "VeryBritishProblems",
      "screen_name" : "SoVeryBritish",
      "indices" : [ 20, 34 ],
      "id_str" : "1023072078",
      "id" : 1023072078
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370638519745925121",
  "geo" : { },
  "id_str" : "370639716346892288",
  "in_reply_to_user_id" : 22381639,
  "text" : "@grvsmth @urihoresh @SoVeryBritish ah i c, though meanings overlap?&gt; disapproval, disappointment, frustration, impatience",
  "id" : 370639716346892288,
  "in_reply_to_status_id" : 370638519745925121,
  "created_at" : "2013-08-22 20:12:49 +0000",
  "in_reply_to_screen_name" : "grvsmth",
  "in_reply_to_user_id_str" : "22381639",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angus B Grieve-Smith",
      "screen_name" : "grvsmth",
      "indices" : [ 0, 8 ],
      "id_str" : "22381639",
      "id" : 22381639
    }, {
      "name" : "Uri Horesh",
      "screen_name" : "urihoresh",
      "indices" : [ 9, 19 ],
      "id_str" : "15664454",
      "id" : 15664454
    }, {
      "name" : "VeryBritishProblems",
      "screen_name" : "SoVeryBritish",
      "indices" : [ 20, 34 ],
      "id_str" : "1023072078",
      "id" : 1023072078
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370637038800093184",
  "geo" : { },
  "id_str" : "370638219232047104",
  "in_reply_to_user_id" : 22381639,
  "text" : "@grvsmth @urihoresh @SoVeryBritish possible origin for word tutting is from sucking teeth? like french tchiper?",
  "id" : 370638219232047104,
  "in_reply_to_status_id" : 370637038800093184,
  "created_at" : "2013-08-22 20:06:52 +0000",
  "in_reply_to_screen_name" : "grvsmth",
  "in_reply_to_user_id_str" : "22381639",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angus B Grieve-Smith",
      "screen_name" : "grvsmth",
      "indices" : [ 0, 8 ],
      "id_str" : "22381639",
      "id" : 22381639
    }, {
      "name" : "Uri Horesh",
      "screen_name" : "urihoresh",
      "indices" : [ 9, 19 ],
      "id_str" : "15664454",
      "id" : 15664454
    }, {
      "name" : "VeryBritishProblems",
      "screen_name" : "SoVeryBritish",
      "indices" : [ 20, 34 ],
      "id_str" : "1023072078",
      "id" : 1023072078
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/JFkYfu2oRc",
      "expanded_url" : "http:\/\/speechevents.wordpress.com\/2013\/05\/30\/sucking-teeth-2\/",
      "display_url" : "speechevents.wordpress.com\/2013\/05\/30\/suc\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "370632709351419904",
  "geo" : { },
  "id_str" : "370636094397640704",
  "in_reply_to_user_id" : 22381639,
  "text" : "@grvsmth @urihoresh @SoVeryBritish family resemblance to sucking teeth? e.g. http:\/\/t.co\/JFkYfu2oRc",
  "id" : 370636094397640704,
  "in_reply_to_status_id" : 370632709351419904,
  "created_at" : "2013-08-22 19:58:25 +0000",
  "in_reply_to_screen_name" : "grvsmth",
  "in_reply_to_user_id_str" : "22381639",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Lee",
      "screen_name" : "desktopenglish",
      "indices" : [ 0, 15 ],
      "id_str" : "345925613",
      "id" : 345925613
    }, {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 95, 109 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370628828361551872",
  "geo" : { },
  "id_str" : "370630377645158400",
  "in_reply_to_user_id" : 345925613,
  "text" : "@desktopenglish a shot at edtech company publicity most likely; also prob frm researching her (@audreywatters) teaching machines book?",
  "id" : 370630377645158400,
  "in_reply_to_status_id" : 370628828361551872,
  "created_at" : "2013-08-22 19:35:42 +0000",
  "in_reply_to_screen_name" : "desktopenglish",
  "in_reply_to_user_id_str" : "345925613",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 3, 17 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/audreywatters\/status\/370574352947085312\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/oVFVyWSnzX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BSSLaQkIAAAx88P.jpg",
      "id_str" : "370574352590569472",
      "id" : 370574352590569472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSSLaQkIAAAx88P.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/oVFVyWSnzX"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370626261623644161",
  "text" : "RT @audreywatters: \"With [insert tech fad here] the Underprivileged School Becomes the Privileged One\" http:\/\/t.co\/oVFVyWSnzX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/audreywatters\/status\/370574352947085312\/photo\/1",
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/oVFVyWSnzX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BSSLaQkIAAAx88P.jpg",
        "id_str" : "370574352590569472",
        "id" : 370574352590569472,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSSLaQkIAAAx88P.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/oVFVyWSnzX"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "370574352947085312",
    "text" : "\"With [insert tech fad here] the Underprivileged School Becomes the Privileged One\" http:\/\/t.co\/oVFVyWSnzX",
    "id" : 370574352947085312,
    "created_at" : "2013-08-22 15:53:05 +0000",
    "user" : {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "protected" : false,
      "id_str" : "25388528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711668009723498496\/pauFZsdv_normal.jpg",
      "id" : 25388528,
      "verified" : false
    }
  },
  "id" : 370626261623644161,
  "created_at" : "2013-08-22 19:19:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doug Belshaw",
      "screen_name" : "dajbelshaw",
      "indices" : [ 52, 63 ],
      "id_str" : "764365",
      "id" : 764365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/ci9IEqVpl4",
      "expanded_url" : "https:\/\/www.eff.org\/who-has-your-back-2013",
      "display_url" : "eff.org\/who-has-your-b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "370505548522729472",
  "text" : "Who has your back? 2013 https:\/\/t.co\/ci9IEqVpl4 h\/t @dajbelshaw",
  "id" : 370505548522729472,
  "created_at" : "2013-08-22 11:19:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Willingham",
      "screen_name" : "DTWillingham",
      "indices" : [ 3, 16 ],
      "id_str" : "84619537",
      "id" : 84619537
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EdChat",
      "indices" : [ 122, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/m9ytBWw7mL",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=DvOt2dRJ9Kg&list=PL2SOU6wwxB0tZFpj59fXV6Uf-ng1oJvLk&index=2",
      "display_url" : "youtube.com\/watch?v=DvOt2d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "370500289192660992",
  "text" : "RT @DTWillingham: Video of a talk I gave this Spring on critical thinking (it's about 15 min long) http:\/\/t.co\/m9ytBWw7mL #EdChat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EdChat",
        "indices" : [ 104, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/m9ytBWw7mL",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=DvOt2dRJ9Kg&list=PL2SOU6wwxB0tZFpj59fXV6Uf-ng1oJvLk&index=2",
        "display_url" : "youtube.com\/watch?v=DvOt2d\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "370185279497199616",
    "text" : "Video of a talk I gave this Spring on critical thinking (it's about 15 min long) http:\/\/t.co\/m9ytBWw7mL #EdChat",
    "id" : 370185279497199616,
    "created_at" : "2013-08-21 14:07:03 +0000",
    "user" : {
      "name" : "Daniel Willingham",
      "screen_name" : "DTWillingham",
      "protected" : false,
      "id_str" : "84619537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1815678310\/Daniel_Willingham_Color_lowres_normal.JPG",
      "id" : 84619537,
      "verified" : false
    }
  },
  "id" : 370500289192660992,
  "created_at" : "2013-08-22 10:58:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Magnus Nissel",
      "screen_name" : "u203d",
      "indices" : [ 3, 9 ],
      "id_str" : "533114985",
      "id" : 533114985
    }, {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "indices" : [ 10, 21 ],
      "id_str" : "152051625",
      "id" : 152051625
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "collectivenouns",
      "indices" : [ 57, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370494067806699521",
  "text" : "RT @u203d @heatherfro a concordance of corpus linguists? #collectivenouns",
  "id" : 370494067806699521,
  "created_at" : "2013-08-22 10:34:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/MRL42Lowcb",
      "expanded_url" : "http:\/\/tm.durusau.net\/?p=44872",
      "display_url" : "tm.durusau.net\/?p=44872"
    } ]
  },
  "geo" : { },
  "id_str" : "370491069948899328",
  "text" : "Groklaw goes dark http:\/\/t.co\/MRL42Lowcb",
  "id" : 370491069948899328,
  "created_at" : "2013-08-22 10:22:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/S8eUFwvpex",
      "expanded_url" : "http:\/\/wp.me\/p1o8M1-XO",
      "display_url" : "wp.me\/p1o8M1-XO"
    } ]
  },
  "geo" : { },
  "id_str" : "370486602310483968",
  "text" : "Fuck The Guardian: Part 1 http:\/\/t.co\/S8eUFwvpex via @ohtarzie",
  "id" : 370486602310483968,
  "created_at" : "2013-08-22 10:04:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pete Warden",
      "screen_name" : "petewarden",
      "indices" : [ 83, 94 ],
      "id_str" : "14642896",
      "id" : 14642896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/8PJUz2qakT",
      "expanded_url" : "http:\/\/blog.alinelerner.com\/lessons-from-a-years-worth-of-hiring-data\/#num-errors",
      "display_url" : "blog.alinelerner.com\/lessons-from-a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "370322868157952000",
  "text" : "going for a computer science job? triple check your CV! http:\/\/t.co\/8PJUz2qakT via @petewarden",
  "id" : 370322868157952000,
  "created_at" : "2013-08-21 23:13:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 0, 14 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/NZLhMkWgMM",
      "expanded_url" : "http:\/\/corpus.byu.edu\/coca\/?c=coca&q=24779718",
      "display_url" : "corpus.byu.edu\/coca\/?c=coca&q\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "369987658954866688",
  "geo" : { },
  "id_str" : "370132648603041792",
  "in_reply_to_user_id" : 25388528,
  "text" : "@audreywatters no idea about CCSS but COCA-BYU says plural http:\/\/t.co\/NZLhMkWgMM",
  "id" : 370132648603041792,
  "in_reply_to_status_id" : 369987658954866688,
  "created_at" : "2013-08-21 10:37:54 +0000",
  "in_reply_to_screen_name" : "audreywatters",
  "in_reply_to_user_id_str" : "25388528",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Brown",
      "screen_name" : "dBr_wn",
      "indices" : [ 0, 7 ],
      "id_str" : "704177088",
      "id" : 704177088
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370120716491837441",
  "geo" : { },
  "id_str" : "370121547496714240",
  "in_reply_to_user_id" : 704177088,
  "text" : "@dBr_wn i think your game concepts are much clearer and applicable to class :)",
  "id" : 370121547496714240,
  "in_reply_to_status_id" : 370120716491837441,
  "created_at" : "2013-08-21 09:53:48 +0000",
  "in_reply_to_screen_name" : "dBr_wn",
  "in_reply_to_user_id_str" : "704177088",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Brown",
      "screen_name" : "dBr_wn",
      "indices" : [ 0, 7 ],
      "id_str" : "704177088",
      "id" : 704177088
    }, {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 8, 24 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370117033976807425",
  "geo" : { },
  "id_str" : "370119444032274433",
  "in_reply_to_user_id" : 704177088,
  "text" : "@dBr_wn @wordpressdotcom unless i misread the writer does not really play with that instead just culls items from LS questionnaires no?",
  "id" : 370119444032274433,
  "in_reply_to_status_id" : 370117033976807425,
  "created_at" : "2013-08-21 09:45:26 +0000",
  "in_reply_to_screen_name" : "dBr_wn",
  "in_reply_to_user_id_str" : "704177088",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Brown",
      "screen_name" : "dBr_wn",
      "indices" : [ 0, 7 ],
      "id_str" : "704177088",
      "id" : 704177088
    }, {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 8, 24 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "370105663084437505",
  "geo" : { },
  "id_str" : "370115791821082624",
  "in_reply_to_user_id" : 704177088,
  "text" : "@dBr_wn @wordpressdotcom yikes left brain\/right brain, learning styles, avatar is least problematic in this text :\/",
  "id" : 370115791821082624,
  "in_reply_to_status_id" : 370105663084437505,
  "created_at" : "2013-08-21 09:30:55 +0000",
  "in_reply_to_screen_name" : "dBr_wn",
  "in_reply_to_user_id_str" : "704177088",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/PMYlpHdp1Y",
      "expanded_url" : "http:\/\/www.desktopenglish.net\/blog\/fumbling-conventionalism-and-mumbling-naturalism",
      "display_url" : "desktopenglish.net\/blog\/fumbling-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "369939268828798976",
  "text" : "Fumbling Conventionalism and Mumbling Naturalism: http:\/\/t.co\/PMYlpHdp1Y",
  "id" : 369939268828798976,
  "created_at" : "2013-08-20 21:49:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "teehee",
      "indices" : [ 33, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/KHgwJDkIfc",
      "expanded_url" : "http:\/\/giaklamata.blogspot.fr\/2013\/08\/signpost.html",
      "display_url" : "giaklamata.blogspot.fr\/2013\/08\/signpo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "369936865509384192",
  "text" : "Signposts http:\/\/t.co\/KHgwJDkIfc #teehee",
  "id" : 369936865509384192,
  "created_at" : "2013-08-20 21:39:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 3, 17 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369898896262066176",
  "text" : "RT @audreywatters: Because as Arthur C Clarke once said \"Any sufficiently advanced tech marketing is indistinguishable from magic.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "369886334527500288",
    "text" : "Because as Arthur C Clarke once said \"Any sufficiently advanced tech marketing is indistinguishable from magic.\"",
    "id" : 369886334527500288,
    "created_at" : "2013-08-20 18:19:08 +0000",
    "user" : {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "protected" : false,
      "id_str" : "25388528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711668009723498496\/pauFZsdv_normal.jpg",
      "id" : 25388528,
      "verified" : false
    }
  },
  "id" : 369898896262066176,
  "created_at" : "2013-08-20 19:09:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim George",
      "screen_name" : "oyajimbo",
      "indices" : [ 0, 9 ],
      "id_str" : "96103979",
      "id" : 96103979
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "COCA",
      "indices" : [ 46, 51 ]
    }, {
      "text" : "BYU",
      "indices" : [ 52, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/CgTTXnPkHJ",
      "expanded_url" : "http:\/\/tinysubversions.com\/gengen\/gen.html?key=0ArFW2BYaBgeidGVON1RTWEtVbEJual9PRDItMENiSGc",
      "display_url" : "tinysubversions.com\/gengen\/gen.htm\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "369874803827568641",
  "geo" : { },
  "id_str" : "369889373090615296",
  "in_reply_to_user_id" : 96103979,
  "text" : "@oyajimbo GCHQ says http:\/\/t.co\/CgTTXnPkHJ :) #COCA #BYU",
  "id" : 369889373090615296,
  "in_reply_to_status_id" : 369874803827568641,
  "created_at" : "2013-08-20 18:31:13 +0000",
  "in_reply_to_screen_name" : "oyajimbo",
  "in_reply_to_user_id_str" : "96103979",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenn Greenwald",
      "screen_name" : "ggreenwald",
      "indices" : [ 3, 14 ],
      "id_str" : "16076032",
      "id" : 16076032
    }, {
      "name" : "alan rusbridger",
      "screen_name" : "arusbridger",
      "indices" : [ 125, 137 ],
      "id_str" : "19534873",
      "id" : 19534873
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 143, 144 ],
      "url" : "http:\/\/t.co\/KCexzpb31M",
      "expanded_url" : "http:\/\/www.theguardian.com\/commentisfree\/2013\/aug\/19\/david-miranda-schedule7-danger-reporters?CMP=twt_gu",
      "display_url" : "theguardian.com\/commentisfree\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "369603940700012544",
  "text" : "RT @ggreenwald: UK Govt threatened GuardianUK with prior restraint, forced it to destroy its hard drives &amp; NSA files, by @arusbridger http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "alan rusbridger",
        "screen_name" : "arusbridger",
        "indices" : [ 109, 121 ],
        "id_str" : "19534873",
        "id" : 19534873
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/KCexzpb31M",
        "expanded_url" : "http:\/\/www.theguardian.com\/commentisfree\/2013\/aug\/19\/david-miranda-schedule7-danger-reporters?CMP=twt_gu",
        "display_url" : "theguardian.com\/commentisfree\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "369590814487244800",
    "text" : "UK Govt threatened GuardianUK with prior restraint, forced it to destroy its hard drives &amp; NSA files, by @arusbridger http:\/\/t.co\/KCexzpb31M",
    "id" : 369590814487244800,
    "created_at" : "2013-08-19 22:44:51 +0000",
    "user" : {
      "name" : "Glenn Greenwald",
      "screen_name" : "ggreenwald",
      "protected" : false,
      "id_str" : "16076032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/659383028771364869\/G9HHnjiI_normal.jpg",
      "id" : 16076032,
      "verified" : true
    }
  },
  "id" : 369603940700012544,
  "created_at" : "2013-08-19 23:37:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bren brennan",
      "screen_name" : "brenbrennan",
      "indices" : [ 3, 15 ],
      "id_str" : "39806371",
      "id" : 39806371
    }, {
      "name" : "Laura Patsko",
      "screen_name" : "lauraahaha",
      "indices" : [ 104, 115 ],
      "id_str" : "97957137",
      "id" : 97957137
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EFL",
      "indices" : [ 52, 56 ]
    }, {
      "text" : "ELT",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "TESOL",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "TEFL",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/rGOenFSmZc",
      "expanded_url" : "http:\/\/www.tesoltraining.co.uk\/blog\/lesson-ideas\/efl-adult-elementary-lesson-lying-not-boring\/",
      "display_url" : "tesoltraining.co.uk\/blog\/lesson-id\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "369566509799981057",
  "text" : "RT @brenbrennan: Avoid boring, simplistic lang with #EFL Adult beginners. Lying! Great lesson idea from @lauraahaha http:\/\/t.co\/rGOenFSmZc \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Laura Patsko",
        "screen_name" : "lauraahaha",
        "indices" : [ 87, 98 ],
        "id_str" : "97957137",
        "id" : 97957137
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EFL",
        "indices" : [ 35, 39 ]
      }, {
        "text" : "ELT",
        "indices" : [ 122, 126 ]
      }, {
        "text" : "TESOL",
        "indices" : [ 127, 133 ]
      }, {
        "text" : "TEFL",
        "indices" : [ 134, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/rGOenFSmZc",
        "expanded_url" : "http:\/\/www.tesoltraining.co.uk\/blog\/lesson-ideas\/efl-adult-elementary-lesson-lying-not-boring\/",
        "display_url" : "tesoltraining.co.uk\/blog\/lesson-id\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "369469001211973632",
    "text" : "Avoid boring, simplistic lang with #EFL Adult beginners. Lying! Great lesson idea from @lauraahaha http:\/\/t.co\/rGOenFSmZc #ELT #TESOL #TEFL",
    "id" : 369469001211973632,
    "created_at" : "2013-08-19 14:40:48 +0000",
    "user" : {
      "name" : "bren brennan",
      "screen_name" : "brenbrennan",
      "protected" : false,
      "id_str" : "39806371",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738534651850035201\/UwKCsS49_normal.jpg",
      "id" : 39806371,
      "verified" : false
    }
  },
  "id" : 369566509799981057,
  "created_at" : "2013-08-19 21:08:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Bogost",
      "screen_name" : "ibogost",
      "indices" : [ 0, 8 ],
      "id_str" : "6825792",
      "id" : 6825792
    }, {
      "name" : "David Graeber",
      "screen_name" : "davidgraeber",
      "indices" : [ 9, 22 ],
      "id_str" : "27288119",
      "id" : 27288119
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/EQwOydI5xL",
      "expanded_url" : "http:\/\/theanarchistlibrary.org\/library\/bob-black-the-abolition-of-work",
      "display_url" : "theanarchistlibrary.org\/library\/bob-bl\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "369531599592755200",
  "geo" : { },
  "id_str" : "369562424149430272",
  "in_reply_to_user_id" : 6825792,
  "text" : "@ibogost @davidgraeber The abolition of work, is a nice companion piece http:\/\/t.co\/EQwOydI5xL",
  "id" : 369562424149430272,
  "in_reply_to_status_id" : 369531599592755200,
  "created_at" : "2013-08-19 20:52:02 +0000",
  "in_reply_to_screen_name" : "ibogost",
  "in_reply_to_user_id_str" : "6825792",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boing Boing",
      "screen_name" : "BoingBoing",
      "indices" : [ 3, 14 ],
      "id_str" : "5971922",
      "id" : 5971922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/Kkeiof7PNM",
      "expanded_url" : "http:\/\/dlvr.it\/3qT76B",
      "display_url" : "dlvr.it\/3qT76B"
    } ]
  },
  "geo" : { },
  "id_str" : "369486021844414464",
  "text" : "RT @BoingBoing: Bullshit jobs: why we're not all working 4h days http:\/\/t.co\/Kkeiof7PNM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/dlvr.it\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/Kkeiof7PNM",
        "expanded_url" : "http:\/\/dlvr.it\/3qT76B",
        "display_url" : "dlvr.it\/3qT76B"
      } ]
    },
    "geo" : { },
    "id_str" : "369460504479014912",
    "text" : "Bullshit jobs: why we're not all working 4h days http:\/\/t.co\/Kkeiof7PNM",
    "id" : 369460504479014912,
    "created_at" : "2013-08-19 14:07:03 +0000",
    "user" : {
      "name" : "Boing Boing",
      "screen_name" : "BoingBoing",
      "protected" : false,
      "id_str" : "5971922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616924998226153472\/0EfZYjr2_normal.png",
      "id" : 5971922,
      "verified" : true
    }
  },
  "id" : 369486021844414464,
  "created_at" : "2013-08-19 15:48:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Sample",
      "screen_name" : "samplereality",
      "indices" : [ 0, 14 ],
      "id_str" : "8497292",
      "id" : 8497292
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "369437174497681408",
  "geo" : { },
  "id_str" : "369464569481003008",
  "in_reply_to_user_id" : 8497292,
  "text" : "@samplereality in this register of a tool for authorites, whom sounds appropriate",
  "id" : 369464569481003008,
  "in_reply_to_status_id" : 369437174497681408,
  "created_at" : "2013-08-19 14:23:12 +0000",
  "in_reply_to_screen_name" : "samplereality",
  "in_reply_to_user_id_str" : "8497292",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Spencer",
      "screen_name" : "edrethink",
      "indices" : [ 3, 13 ],
      "id_str" : "3057524486",
      "id" : 3057524486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/ccnQnNOLcf",
      "expanded_url" : "http:\/\/educationrethink.podomatic.com\/",
      "display_url" : "educationrethink.podomatic.com"
    } ]
  },
  "geo" : { },
  "id_str" : "369457326333243392",
  "text" : "RT @edrethink: I've been keeping a daily audio journal (mini podcast) on the reasons I love teaching: http:\/\/t.co\/ccnQnNOLcf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/ccnQnNOLcf",
        "expanded_url" : "http:\/\/educationrethink.podomatic.com\/",
        "display_url" : "educationrethink.podomatic.com"
      } ]
    },
    "geo" : { },
    "id_str" : "369445043804700675",
    "text" : "I've been keeping a daily audio journal (mini podcast) on the reasons I love teaching: http:\/\/t.co\/ccnQnNOLcf",
    "id" : 369445043804700675,
    "created_at" : "2013-08-19 13:05:37 +0000",
    "user" : {
      "name" : "John Spencer",
      "screen_name" : "spencerideas",
      "protected" : false,
      "id_str" : "18389166",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751913559160795136\/eU7NtYy4_normal.jpg",
      "id" : 18389166,
      "verified" : false
    }
  },
  "id" : 369457326333243392,
  "created_at" : "2013-08-19 13:54:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Language Rich Europe",
      "screen_name" : "LanguageRich",
      "indices" : [ 74, 87 ],
      "id_str" : "365441729",
      "id" : 365441729
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/tojnO81PV8",
      "expanded_url" : "http:\/\/www.language-rich.eu\/home\/country-profiles\/profiles-overview\/france.html",
      "display_url" : "language-rich.eu\/home\/country-p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "369434129936310272",
  "text" : "Language Rich Europe: Country Profiles: France http:\/\/t.co\/tojnO81PV8 via @LanguageRich",
  "id" : 369434129936310272,
  "created_at" : "2013-08-19 12:22:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DJM",
      "screen_name" : "visibletangible",
      "indices" : [ 0, 16 ],
      "id_str" : "296643011",
      "id" : 296643011
    }, {
      "name" : "Richard Badger",
      "screen_name" : "RichardBadger2",
      "indices" : [ 17, 32 ],
      "id_str" : "382586050",
      "id" : 382586050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369404834840977410",
  "in_reply_to_user_id" : 296643011,
  "text" : "@visibletangible @RichardBadger2 thanks for RT :)",
  "id" : 369404834840977410,
  "created_at" : "2013-08-19 10:25:50 +0000",
  "in_reply_to_screen_name" : "visibletangible",
  "in_reply_to_user_id_str" : "296643011",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "simon rees",
      "screen_name" : "simonw_rees",
      "indices" : [ 0, 12 ],
      "id_str" : "847818097",
      "id" : 847818097
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369220962601816065",
  "in_reply_to_user_id" : 847818097,
  "text" : "@simonw_rees thanks for RT :)",
  "id" : 369220962601816065,
  "created_at" : "2013-08-18 22:15:11 +0000",
  "in_reply_to_screen_name" : "simonw_rees",
  "in_reply_to_user_id_str" : "847818097",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Li-Shih Huang, PhD",
      "screen_name" : "AppLingProf",
      "indices" : [ 3, 15 ],
      "id_str" : "128714685",
      "id" : 128714685
    }, {
      "name" : "Adam Grant",
      "screen_name" : "AdamMGrant",
      "indices" : [ 20, 31 ],
      "id_str" : "1059273780",
      "id" : 1059273780
    }, {
      "name" : "Language Log",
      "screen_name" : "LanguageLog",
      "indices" : [ 100, 112 ],
      "id_str" : "20148973",
      "id" : 20148973
    }, {
      "name" : "Tara McAllister Byun",
      "screen_name" : "ByunLab",
      "indices" : [ 117, 125 ],
      "id_str" : "1583129935",
      "id" : 1583129935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 127, 140 ],
      "url" : "http:\/\/t.co\/UZ4y8IrLbZ",
      "expanded_url" : "http:\/\/bit.ly\/1eUx8Ok",
      "display_url" : "bit.ly\/1eUx8Ok"
    } ]
  },
  "geo" : { },
  "id_str" : "369213402578558976",
  "text" : "RT @AppLingProf: RT @AdamMGrant: Rethinking the fall of \"give\" and the rise of \"get\" in books, from @LanguageLog via @ByunLab: http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Adam Grant",
        "screen_name" : "AdamMGrant",
        "indices" : [ 3, 14 ],
        "id_str" : "1059273780",
        "id" : 1059273780
      }, {
        "name" : "Language Log",
        "screen_name" : "LanguageLog",
        "indices" : [ 83, 95 ],
        "id_str" : "20148973",
        "id" : 20148973
      }, {
        "name" : "Tara McAllister Byun",
        "screen_name" : "ByunLab",
        "indices" : [ 100, 108 ],
        "id_str" : "1583129935",
        "id" : 1583129935
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/UZ4y8IrLbZ",
        "expanded_url" : "http:\/\/bit.ly\/1eUx8Ok",
        "display_url" : "bit.ly\/1eUx8Ok"
      } ]
    },
    "geo" : { },
    "id_str" : "369159303577346048",
    "text" : "RT @AdamMGrant: Rethinking the fall of \"give\" and the rise of \"get\" in books, from @LanguageLog via @ByunLab: http:\/\/t.co\/UZ4y8IrLbZ",
    "id" : 369159303577346048,
    "created_at" : "2013-08-18 18:10:11 +0000",
    "user" : {
      "name" : "Li-Shih Huang, PhD",
      "screen_name" : "AppLingProf",
      "protected" : false,
      "id_str" : "128714685",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/577224421611466752\/7ozjbHH5_normal.jpeg",
      "id" : 128714685,
      "verified" : false
    }
  },
  "id" : 369213402578558976,
  "created_at" : "2013-08-18 21:45:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenn Greenwald",
      "screen_name" : "ggreenwald",
      "indices" : [ 3, 14 ],
      "id_str" : "16076032",
      "id" : 16076032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/g1NLCfA2aj",
      "expanded_url" : "http:\/\/www.theguardian.com\/commentisfree\/2013\/aug\/18\/david-miranda-detained-uk-nsa",
      "display_url" : "theguardian.com\/commentisfree\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "369188844484042752",
  "text" : "RT @ggreenwald: Detaining my partner: a failed attempt at intimidation  http:\/\/t.co\/g1NLCfA2aj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/g1NLCfA2aj",
        "expanded_url" : "http:\/\/www.theguardian.com\/commentisfree\/2013\/aug\/18\/david-miranda-detained-uk-nsa",
        "display_url" : "theguardian.com\/commentisfree\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "369168506270400514",
    "text" : "Detaining my partner: a failed attempt at intimidation  http:\/\/t.co\/g1NLCfA2aj",
    "id" : 369168506270400514,
    "created_at" : "2013-08-18 18:46:45 +0000",
    "user" : {
      "name" : "Glenn Greenwald",
      "screen_name" : "ggreenwald",
      "protected" : false,
      "id_str" : "16076032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/659383028771364869\/G9HHnjiI_normal.jpg",
      "id" : 16076032,
      "verified" : true
    }
  },
  "id" : 369188844484042752,
  "created_at" : "2013-08-18 20:07:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah KB",
      "screen_name" : "sarah_SKB",
      "indices" : [ 0, 10 ],
      "id_str" : "54518314",
      "id" : 54518314
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369187798634352640",
  "in_reply_to_user_id" : 54518314,
  "text" : "@sarah_SKB appreciate the RT :)",
  "id" : 369187798634352640,
  "created_at" : "2013-08-18 20:03:25 +0000",
  "in_reply_to_screen_name" : "sarah_SKB",
  "in_reply_to_user_id_str" : "54518314",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemma Lunn",
      "screen_name" : "GemL1",
      "indices" : [ 0, 6 ],
      "id_str" : "486146568",
      "id" : 486146568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "369163952321609728",
  "geo" : { },
  "id_str" : "369187709392154624",
  "in_reply_to_user_id" : 486146568,
  "text" : "@GemL1 thanks for sharing that post Gemma :)",
  "id" : 369187709392154624,
  "in_reply_to_status_id" : 369163952321609728,
  "created_at" : "2013-08-18 20:03:03 +0000",
  "in_reply_to_screen_name" : "GemL1",
  "in_reply_to_user_id_str" : "486146568",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Andrews",
      "screen_name" : "PatrickAndrews",
      "indices" : [ 0, 15 ],
      "id_str" : "29999737",
      "id" : 29999737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "369129203167285248",
  "geo" : { },
  "id_str" : "369130148542431232",
  "in_reply_to_user_id" : 29999737,
  "text" : "@PatrickAndrews thanks :) there are more corpora posts on blog for yr reading pleasure, tagged accordingly.",
  "id" : 369130148542431232,
  "in_reply_to_status_id" : 369129203167285248,
  "created_at" : "2013-08-18 16:14:20 +0000",
  "in_reply_to_screen_name" : "PatrickAndrews",
  "in_reply_to_user_id_str" : "29999737",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Andrews",
      "screen_name" : "PatrickAndrews",
      "indices" : [ 0, 15 ],
      "id_str" : "29999737",
      "id" : 29999737
    }, {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 16, 27 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369128765281939456",
  "in_reply_to_user_id" : 29999737,
  "text" : "@PatrickAndrews @lexicoloco thanks for Favs :)",
  "id" : 369128765281939456,
  "created_at" : "2013-08-18 16:08:50 +0000",
  "in_reply_to_screen_name" : "PatrickAndrews",
  "in_reply_to_user_id_str" : "29999737",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "natiserhost197",
      "screen_name" : "esl_robert",
      "indices" : [ 0, 11 ],
      "id_str" : "2982357761",
      "id" : 2982357761
    }, {
      "name" : "Scott Thornbury",
      "screen_name" : "thornburyscott",
      "indices" : [ 12, 27 ],
      "id_str" : "23090474",
      "id" : 23090474
    }, {
      "name" : "David Mearns",
      "screen_name" : "davidmearns",
      "indices" : [ 28, 40 ],
      "id_str" : "30931681",
      "id" : 30931681
    }, {
      "name" : "Monika Sobejko",
      "screen_name" : "SobejM",
      "indices" : [ 41, 48 ],
      "id_str" : "380504775",
      "id" : 380504775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369127984881364992",
  "in_reply_to_user_id" : 18526186,
  "text" : "@esl_robert @thornburyscott @davidmearns @SobejM many thanks for RT :)",
  "id" : 369127984881364992,
  "created_at" : "2013-08-18 16:05:44 +0000",
  "in_reply_to_screen_name" : "RobertEPoole",
  "in_reply_to_user_id_str" : "18526186",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chia Suan Chong",
      "screen_name" : "chiasuan",
      "indices" : [ 0, 9 ],
      "id_str" : "71588589",
      "id" : 71588589
    }, {
      "name" : "Phil Longwell",
      "screen_name" : "teacherphili",
      "indices" : [ 10, 23 ],
      "id_str" : "67863264",
      "id" : 67863264
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "369039526108213248",
  "geo" : { },
  "id_str" : "369127648041005056",
  "in_reply_to_user_id" : 71588589,
  "text" : "@chiasuan @teacherphili can be confusing between the interface used and the corpus used!",
  "id" : 369127648041005056,
  "in_reply_to_status_id" : 369039526108213248,
  "created_at" : "2013-08-18 16:04:24 +0000",
  "in_reply_to_screen_name" : "chiasuan",
  "in_reply_to_user_id_str" : "71588589",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol Goodey",
      "screen_name" : "cgoodey",
      "indices" : [ 0, 8 ],
      "id_str" : "26606833",
      "id" : 26606833
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "369034728793309184",
  "geo" : { },
  "id_str" : "369127088273367041",
  "in_reply_to_user_id" : 26606833,
  "text" : "@cgoodey thanks Carol :)",
  "id" : 369127088273367041,
  "in_reply_to_status_id" : 369034728793309184,
  "created_at" : "2013-08-18 16:02:10 +0000",
  "in_reply_to_screen_name" : "cgoodey",
  "in_reply_to_user_id_str" : "26606833",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yolanda B. Schell",
      "screen_name" : "mattellman",
      "indices" : [ 0, 11 ],
      "id_str" : "725597315860434945",
      "id" : 725597315860434945
    }, {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 38, 50 ],
      "id_str" : "525013404",
      "id" : 525013404
    }, {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 51, 67 ],
      "id_str" : "394053348",
      "id" : 394053348
    }, {
      "name" : "Evan Simpson",
      "screen_name" : "pevansimpson",
      "indices" : [ 68, 81 ],
      "id_str" : "230954247",
      "id" : 230954247
    }, {
      "name" : "T'is McF",
      "screen_name" : "jimi1999uk",
      "indices" : [ 82, 93 ],
      "id_str" : "432047198",
      "id" : 432047198
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368914518782382080",
  "geo" : { },
  "id_str" : "369126944173862913",
  "in_reply_to_user_id" : 394987109,
  "text" : "@mattellman cheers Matt for share and @AnneHendler @michaelegriffin @pevansimpson @jimi1999uk for RTs and favs :)",
  "id" : 369126944173862913,
  "in_reply_to_status_id" : 368914518782382080,
  "created_at" : "2013-08-18 16:01:36 +0000",
  "in_reply_to_screen_name" : "MatthewEllman",
  "in_reply_to_user_id_str" : "394987109",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 67, 75 ]
    }, {
      "text" : "tesol",
      "indices" : [ 76, 82 ]
    }, {
      "text" : "tefl",
      "indices" : [ 83, 88 ]
    }, {
      "text" : "elt",
      "indices" : [ 89, 93 ]
    }, {
      "text" : "efl",
      "indices" : [ 94, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/7HYTzrDoyb",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-Fx",
      "display_url" : "wp.me\/pgHyE-Fx"
    } ]
  },
  "geo" : { },
  "id_str" : "368786808315731968",
  "text" : "new post - No time for corpora? No worries! http:\/\/t.co\/7HYTzrDoyb #eltchat #tesol #tefl #elt #efl",
  "id" : 368786808315731968,
  "created_at" : "2013-08-17 17:30:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chia Suan Chong",
      "screen_name" : "chiasuan",
      "indices" : [ 3, 12 ],
      "id_str" : "71588589",
      "id" : 71588589
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "efl",
      "indices" : [ 131, 135 ]
    }, {
      "text" : "elt",
      "indices" : [ 136, 140 ]
    }, {
      "text" : "esl",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "edtech",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/8jpnp70h1V",
      "expanded_url" : "http:\/\/www.etprofessional.com\/5_ways_of_using_corpora_to_develop_learner_autonomy_83885.aspx",
      "display_url" : "etprofessional.com\/5_ways_of_usin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "368436254083268608",
  "text" : "RT @chiasuan: Do your learners know how to use a corpus to find out about a word? Here are some basic tips.\nhttp:\/\/t.co\/8jpnp70h1V #efl #el\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "efl",
        "indices" : [ 117, 121 ]
      }, {
        "text" : "elt",
        "indices" : [ 122, 126 ]
      }, {
        "text" : "esl",
        "indices" : [ 127, 131 ]
      }, {
        "text" : "edtech",
        "indices" : [ 132, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/8jpnp70h1V",
        "expanded_url" : "http:\/\/www.etprofessional.com\/5_ways_of_using_corpora_to_develop_learner_autonomy_83885.aspx",
        "display_url" : "etprofessional.com\/5_ways_of_usin\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "368421172490534912",
    "text" : "Do your learners know how to use a corpus to find out about a word? Here are some basic tips.\nhttp:\/\/t.co\/8jpnp70h1V #efl #elt #esl #edtech",
    "id" : 368421172490534912,
    "created_at" : "2013-08-16 17:17:07 +0000",
    "user" : {
      "name" : "Chia Suan Chong",
      "screen_name" : "chiasuan",
      "protected" : false,
      "id_str" : "71588589",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1672976345\/IMG_1047_normal.jpg",
      "id" : 71588589,
      "verified" : false
    }
  },
  "id" : 368436254083268608,
  "created_at" : "2013-08-16 18:17:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Li-Shih Huang, PhD",
      "screen_name" : "AppLingProf",
      "indices" : [ 3, 15 ],
      "id_str" : "128714685",
      "id" : 128714685
    }, {
      "name" : "Richard",
      "screen_name" : "rwpickard",
      "indices" : [ 20, 30 ],
      "id_str" : "17435582",
      "id" : 17435582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/NQZiw0a732",
      "expanded_url" : "http:\/\/ca.news.yahoo.com\/students-laptops-class-lowers-grades-canadian-study-180824252.html",
      "display_url" : "ca.news.yahoo.com\/students-lapto\u2026"
    }, {
      "indices" : [ 121, 140 ],
      "url" : "http:\/\/t.co\/Bvh7yyR6sQ",
      "expanded_url" : "http:\/\/goo.gl\/i9JzOW",
      "display_url" : "goo.gl\/i9JzOW"
    } ]
  },
  "geo" : { },
  "id_str" : "368287799490785280",
  "text" : "RT @AppLingProf: MT @rwpickard: Laptops in the classroom: friends or foes? http:\/\/t.co\/NQZiw0a732 | To access the study: http:\/\/t.co\/Bvh7yy\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Richard",
        "screen_name" : "rwpickard",
        "indices" : [ 3, 13 ],
        "id_str" : "17435582",
        "id" : 17435582
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/NQZiw0a732",
        "expanded_url" : "http:\/\/ca.news.yahoo.com\/students-laptops-class-lowers-grades-canadian-study-180824252.html",
        "display_url" : "ca.news.yahoo.com\/students-lapto\u2026"
      }, {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/Bvh7yyR6sQ",
        "expanded_url" : "http:\/\/goo.gl\/i9JzOW",
        "display_url" : "goo.gl\/i9JzOW"
      } ]
    },
    "geo" : { },
    "id_str" : "368244114606661632",
    "text" : "MT @rwpickard: Laptops in the classroom: friends or foes? http:\/\/t.co\/NQZiw0a732 | To access the study: http:\/\/t.co\/Bvh7yyR6sQ",
    "id" : 368244114606661632,
    "created_at" : "2013-08-16 05:33:33 +0000",
    "user" : {
      "name" : "Li-Shih Huang, PhD",
      "screen_name" : "AppLingProf",
      "protected" : false,
      "id_str" : "128714685",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/577224421611466752\/7ozjbHH5_normal.jpeg",
      "id" : 128714685,
      "verified" : false
    }
  },
  "id" : 368287799490785280,
  "created_at" : "2013-08-16 08:27:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Whiteside",
      "screen_name" : "nutrich",
      "indices" : [ 0, 8 ],
      "id_str" : "95495064",
      "id" : 95495064
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367634459786371072",
  "in_reply_to_user_id" : 95495064,
  "text" : "@nutrich thanks for RT :)",
  "id" : 367634459786371072,
  "created_at" : "2013-08-14 13:11:00 +0000",
  "in_reply_to_screen_name" : "nutrich",
  "in_reply_to_user_id_str" : "95495064",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bruno Andrade",
      "screen_name" : "BrunoELT",
      "indices" : [ 0, 9 ],
      "id_str" : "39409915",
      "id" : 39409915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "367631784596365312",
  "geo" : { },
  "id_str" : "367634279938805760",
  "in_reply_to_user_id" : 39409915,
  "text" : "@BrunoELT looks like still in beta so not really launched",
  "id" : 367634279938805760,
  "in_reply_to_status_id" : 367631784596365312,
  "created_at" : "2013-08-14 13:10:17 +0000",
  "in_reply_to_screen_name" : "BrunoELT",
  "in_reply_to_user_id_str" : "39409915",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenn Greenwald",
      "screen_name" : "ggreenwald",
      "indices" : [ 3, 14 ],
      "id_str" : "16076032",
      "id" : 16076032
    }, {
      "name" : "Democracy Now!",
      "screen_name" : "democracynow",
      "indices" : [ 22, 35 ],
      "id_str" : "16935292",
      "id" : 16935292
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/jRtk1myksh",
      "expanded_url" : "http:\/\/www.democracynow.org\/2013\/8\/13\/exclusive_owner_of_snowdens_email_service",
      "display_url" : "democracynow.org\/2013\/8\/13\/excl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "367613456423194624",
  "text" : "RT @ggreenwald: Great @DemocracyNow interview w\/owner of Lavabit-Snowden's email service- that closed itself to avoid govt monitoring http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Democracy Now!",
        "screen_name" : "democracynow",
        "indices" : [ 6, 19 ],
        "id_str" : "16935292",
        "id" : 16935292
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/jRtk1myksh",
        "expanded_url" : "http:\/\/www.democracynow.org\/2013\/8\/13\/exclusive_owner_of_snowdens_email_service",
        "display_url" : "democracynow.org\/2013\/8\/13\/excl\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "367317939822657536",
    "text" : "Great @DemocracyNow interview w\/owner of Lavabit-Snowden's email service- that closed itself to avoid govt monitoring http:\/\/t.co\/jRtk1myksh",
    "id" : 367317939822657536,
    "created_at" : "2013-08-13 16:13:15 +0000",
    "user" : {
      "name" : "Glenn Greenwald",
      "screen_name" : "ggreenwald",
      "protected" : false,
      "id_str" : "16076032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/659383028771364869\/G9HHnjiI_normal.jpg",
      "id" : 16076032,
      "verified" : true
    }
  },
  "id" : 367613456423194624,
  "created_at" : "2013-08-14 11:47:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "TESOL France",
      "screen_name" : "TESOLFrance",
      "indices" : [ 39, 51 ],
      "id_str" : "70341872",
      "id" : 70341872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "367570558340571136",
  "geo" : { },
  "id_str" : "367572136170242048",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan cheers leo, looking fwd to @TESOLFrance this november :)",
  "id" : 367572136170242048,
  "in_reply_to_status_id" : 367570558340571136,
  "created_at" : "2013-08-14 09:03:21 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "le_mac",
      "screen_name" : "le_mac",
      "indices" : [ 3, 10 ],
      "id_str" : "17064137",
      "id" : 17064137
    }, {
      "name" : "Timothy Tate",
      "screen_name" : "Timothy_Tate",
      "indices" : [ 12, 25 ],
      "id_str" : "1084531170",
      "id" : 1084531170
    }, {
      "name" : "Lauren Laverne",
      "screen_name" : "laurenlaverne",
      "indices" : [ 44, 58 ],
      "id_str" : "89486038",
      "id" : 89486038
    }, {
      "name" : "emma kennedy",
      "screen_name" : "EmmaK67",
      "indices" : [ 81, 89 ],
      "id_str" : "2665940365",
      "id" : 2665940365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/ouNQxdM0N2",
      "expanded_url" : "http:\/\/www.buzzfeed.com\/nataliemorin\/chinese-signs-that-got-seriously-lost-in-tranlsation",
      "display_url" : "buzzfeed.com\/nataliemorin\/c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "367570494368653312",
  "text" : "RT @le_mac: @Timothy_Tate you'll like this \"@laurenlaverne: *Coffee splutter* RT @EmmaK67: Signs that got lost in translation... http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Timothy Tate",
        "screen_name" : "Timothy_Tate",
        "indices" : [ 0, 13 ],
        "id_str" : "1084531170",
        "id" : 1084531170
      }, {
        "name" : "Lauren Laverne",
        "screen_name" : "laurenlaverne",
        "indices" : [ 32, 46 ],
        "id_str" : "89486038",
        "id" : 89486038
      }, {
        "name" : "emma kennedy",
        "screen_name" : "EmmaK67",
        "indices" : [ 69, 77 ],
        "id_str" : "2665940365",
        "id" : 2665940365
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/ouNQxdM0N2",
        "expanded_url" : "http:\/\/www.buzzfeed.com\/nataliemorin\/chinese-signs-that-got-seriously-lost-in-tranlsation",
        "display_url" : "buzzfeed.com\/nataliemorin\/c\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "367559719025901568",
    "in_reply_to_user_id" : 1084531170,
    "text" : "@Timothy_Tate you'll like this \"@laurenlaverne: *Coffee splutter* RT @EmmaK67: Signs that got lost in translation... http:\/\/t.co\/ouNQxdM0N2\"",
    "id" : 367559719025901568,
    "created_at" : "2013-08-14 08:14:00 +0000",
    "in_reply_to_screen_name" : "Timothy_Tate",
    "in_reply_to_user_id_str" : "1084531170",
    "user" : {
      "name" : "le_mac",
      "screen_name" : "le_mac",
      "protected" : false,
      "id_str" : "17064137",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/123452084\/green_wall_normal.jpg",
      "id" : 17064137,
      "verified" : false
    }
  },
  "id" : 367570494368653312,
  "created_at" : "2013-08-14 08:56:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "natiserhost197",
      "screen_name" : "esl_robert",
      "indices" : [ 3, 14 ],
      "id_str" : "2982357761",
      "id" : 2982357761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/Dd3kpdN2y5",
      "expanded_url" : "http:\/\/www.academicwords.info\/",
      "display_url" : "academicwords.info"
    } ]
  },
  "geo" : { },
  "id_str" : "367327328688275456",
  "text" : "RT @esl_robert: New academic word list from Davies and COCA at http:\/\/t.co\/Dd3kpdN2y5 and an article in App Ling explaining differences wit\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 69 ],
        "url" : "http:\/\/t.co\/Dd3kpdN2y5",
        "expanded_url" : "http:\/\/www.academicwords.info\/",
        "display_url" : "academicwords.info"
      } ]
    },
    "geo" : { },
    "id_str" : "367294360397692928",
    "text" : "New academic word list from Davies and COCA at http:\/\/t.co\/Dd3kpdN2y5 and an article in App Ling explaining differences with Coxhead.",
    "id" : 367294360397692928,
    "created_at" : "2013-08-13 14:39:34 +0000",
    "user" : {
      "name" : "Robert Poole",
      "screen_name" : "RobertEPoole",
      "protected" : false,
      "id_str" : "18526186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/586985086073069568\/UbAcX_I3_normal.jpg",
      "id" : 18526186,
      "verified" : false
    }
  },
  "id" : 367327328688275456,
  "created_at" : "2013-08-13 16:50:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Akira Murakami",
      "screen_name" : "mrkm_a",
      "indices" : [ 128, 135 ],
      "id_str" : "116922669",
      "id" : 116922669
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/s22klbXZtU",
      "expanded_url" : "http:\/\/sifnos.sfs.uni-tuebingen.de\/VIEW\/index.jsp?content=about",
      "display_url" : "sifnos.sfs.uni-tuebingen.de\/VIEW\/index.jsp\u2026"
    }, {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/IWMwAgePSn",
      "expanded_url" : "http:\/\/www.fif.tu-darmstadt.de\/media\/fif_forum_interdisziplinaere_forschung\/medien\/praesentationen\/workshops\/ukp___dipf_bildungsprozesse_09__07__2013_\/Meurers_-_Computational_Linguistics.pdf",
      "display_url" : "fif.tu-darmstadt.de\/media\/fif_foru\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "367233491030654976",
  "text" : "Visual Input Enhancement of the Web http:\/\/t.co\/s22klbXZtU nice tool read other int developments frm http:\/\/t.co\/IWMwAgePSn HT  @mrkm_a",
  "id" : 367233491030654976,
  "created_at" : "2013-08-13 10:37:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/Y1Fpgh1PwI",
      "expanded_url" : "http:\/\/members5.boardhost.com\/medialens\/msg\/1376324671.html",
      "display_url" : "members5.boardhost.com\/medialens\/msg\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "367229418445352960",
  "text" : "Palestinians at the proms http:\/\/t.co\/Y1Fpgh1PwI",
  "id" : 367229418445352960,
  "created_at" : "2013-08-13 10:21:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nic Subtirelu",
      "screen_name" : "linguisticpulse",
      "indices" : [ 3, 19 ],
      "id_str" : "1400748798",
      "id" : 1400748798
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "language",
      "indices" : [ 45, 54 ]
    }, {
      "text" : "English",
      "indices" : [ 108, 116 ]
    }, {
      "text" : "NCTE",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "TESOL",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "CCCC",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 140 ],
      "url" : "http:\/\/t.co\/oKDQNVsHEc",
      "expanded_url" : "http:\/\/bit.ly\/13fvAi6",
      "display_url" : "bit.ly\/13fvAi6"
    } ]
  },
  "geo" : { },
  "id_str" : "367059884438601728",
  "text" : "RT @linguisticpulse: Is respecting students' #language inherently at odds with 'rigor' in teaching academic #English? (http:\/\/t.co\/oKDQNVsH\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "language",
        "indices" : [ 24, 33 ]
      }, {
        "text" : "English",
        "indices" : [ 87, 95 ]
      }, {
        "text" : "NCTE",
        "indices" : [ 122, 127 ]
      }, {
        "text" : "TESOL",
        "indices" : [ 128, 134 ]
      }, {
        "text" : "CCCC",
        "indices" : [ 135, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/oKDQNVsHEc",
        "expanded_url" : "http:\/\/bit.ly\/13fvAi6",
        "display_url" : "bit.ly\/13fvAi6"
      } ]
    },
    "geo" : { },
    "id_str" : "367050982108045312",
    "text" : "Is respecting students' #language inherently at odds with 'rigor' in teaching academic #English? (http:\/\/t.co\/oKDQNVsHEc) #NCTE #TESOL #CCCC",
    "id" : 367050982108045312,
    "created_at" : "2013-08-12 22:32:28 +0000",
    "user" : {
      "name" : "Nic Subtirelu",
      "screen_name" : "linguisticpulse",
      "protected" : false,
      "id_str" : "1400748798",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3609632834\/4ae2ef11e9cffa43e820f3ef7e18b016_normal.jpeg",
      "id" : 1400748798,
      "verified" : false
    }
  },
  "id" : 367059884438601728,
  "created_at" : "2013-08-12 23:07:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyler Schnoebelen",
      "screen_name" : "TSchnoebelen",
      "indices" : [ 3, 16 ],
      "id_str" : "14969147",
      "id" : 14969147
    }, {
      "name" : "Jen Doll",
      "screen_name" : "thisisjendoll",
      "indices" : [ 131, 140 ],
      "id_str" : "46442771",
      "id" : 46442771
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/Ww5TNeqq6s",
      "expanded_url" : "http:\/\/idibon.com\/twitter-repeats\/",
      "display_url" : "idibon.com\/twitter-repeat\u2026"
    }, {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/ZKsFipoQuf",
      "expanded_url" : "http:\/\/ow.ly\/i\/2RirG",
      "display_url" : "ow.ly\/i\/2RirG"
    } ]
  },
  "geo" : { },
  "id_str" : "367049229971107840",
  "text" : "RT @TSchnoebelen: A census of laughter: the ha ha ha's and hee hee hee's of Twitter. http:\/\/t.co\/Ww5TNeqq6s http:\/\/t.co\/ZKsFipoQuf @thisisj\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jen Doll",
        "screen_name" : "thisisjendoll",
        "indices" : [ 113, 127 ],
        "id_str" : "46442771",
        "id" : 46442771
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/Ww5TNeqq6s",
        "expanded_url" : "http:\/\/idibon.com\/twitter-repeats\/",
        "display_url" : "idibon.com\/twitter-repeat\u2026"
      }, {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/ZKsFipoQuf",
        "expanded_url" : "http:\/\/ow.ly\/i\/2RirG",
        "display_url" : "ow.ly\/i\/2RirG"
      } ]
    },
    "geo" : { },
    "id_str" : "367007717103108097",
    "text" : "A census of laughter: the ha ha ha's and hee hee hee's of Twitter. http:\/\/t.co\/Ww5TNeqq6s http:\/\/t.co\/ZKsFipoQuf @thisisjendoll",
    "id" : 367007717103108097,
    "created_at" : "2013-08-12 19:40:33 +0000",
    "user" : {
      "name" : "Tyler Schnoebelen",
      "screen_name" : "TSchnoebelen",
      "protected" : false,
      "id_str" : "14969147",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/604427674203779072\/Y4t_NODB_normal.jpg",
      "id" : 14969147,
      "verified" : false
    }
  },
  "id" : 367049229971107840,
  "created_at" : "2013-08-12 22:25:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Willingham",
      "screen_name" : "DTWillingham",
      "indices" : [ 3, 16 ],
      "id_str" : "84619537",
      "id" : 84619537
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edchat",
      "indices" : [ 110, 117 ]
    }, {
      "text" : "UKedchat",
      "indices" : [ 118, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/5mYg0irUr3",
      "expanded_url" : "http:\/\/bit.ly\/13eKBRa",
      "display_url" : "bit.ly\/13eKBRa"
    } ]
  },
  "geo" : { },
  "id_str" : "366976884887666688",
  "text" : "RT @DTWillingham: Willingham blog: The subtle work of creating instructional materials http:\/\/t.co\/5mYg0irUr3 #edchat #UKedchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "edchat",
        "indices" : [ 92, 99 ]
      }, {
        "text" : "UKedchat",
        "indices" : [ 100, 109 ]
      } ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/5mYg0irUr3",
        "expanded_url" : "http:\/\/bit.ly\/13eKBRa",
        "display_url" : "bit.ly\/13eKBRa"
      } ]
    },
    "geo" : { },
    "id_str" : "366965227964739585",
    "text" : "Willingham blog: The subtle work of creating instructional materials http:\/\/t.co\/5mYg0irUr3 #edchat #UKedchat",
    "id" : 366965227964739585,
    "created_at" : "2013-08-12 16:51:42 +0000",
    "user" : {
      "name" : "Daniel Willingham",
      "screen_name" : "DTWillingham",
      "protected" : false,
      "id_str" : "84619537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1815678310\/Daniel_Willingham_Color_lowres_normal.JPG",
      "id" : 84619537,
      "verified" : false
    }
  },
  "id" : 366976884887666688,
  "created_at" : "2013-08-12 17:38:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yolanda B. Schell",
      "screen_name" : "mattellman",
      "indices" : [ 0, 11 ],
      "id_str" : "725597315860434945",
      "id" : 725597315860434945
    }, {
      "name" : "Mike S. Boyle",
      "screen_name" : "heyboyle",
      "indices" : [ 12, 21 ],
      "id_str" : "612840231",
      "id" : 612840231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366945315846230017",
  "in_reply_to_user_id" : 394987109,
  "text" : "@mattellman @heyboyle v much appreciate the RTs fellas :) have a good one",
  "id" : 366945315846230017,
  "created_at" : "2013-08-12 15:32:35 +0000",
  "in_reply_to_screen_name" : "MatthewEllman",
  "in_reply_to_user_id_str" : "394987109",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adi Rajan",
      "screen_name" : "adi_rajan",
      "indices" : [ 3, 13 ],
      "id_str" : "1011323449",
      "id" : 1011323449
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/jomYY1tXz3",
      "expanded_url" : "http:\/\/wp.me\/p3sNrs-4L",
      "display_url" : "wp.me\/p3sNrs-4L"
    } ]
  },
  "geo" : { },
  "id_str" : "366475288013570048",
  "text" : "RT @adi_rajan: Are you a river-wader or a bridge builder? | Living root bridges and professional development  http:\/\/t.co\/jomYY1tXz3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/jomYY1tXz3",
        "expanded_url" : "http:\/\/wp.me\/p3sNrs-4L",
        "display_url" : "wp.me\/p3sNrs-4L"
      } ]
    },
    "geo" : { },
    "id_str" : "366427650526429184",
    "text" : "Are you a river-wader or a bridge builder? | Living root bridges and professional development  http:\/\/t.co\/jomYY1tXz3",
    "id" : 366427650526429184,
    "created_at" : "2013-08-11 05:15:34 +0000",
    "user" : {
      "name" : "Adi Rajan",
      "screen_name" : "adi_rajan",
      "protected" : false,
      "id_str" : "1011323449",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/692989458682085381\/JzeJM-e1_normal.jpg",
      "id" : 1011323449,
      "verified" : false
    }
  },
  "id" : 366475288013570048,
  "created_at" : "2013-08-11 08:24:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/366230276680077312\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/2El4YcGykF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BRUcfwwCUAAYcGV.png",
      "id_str" : "366230276688465920",
      "id" : 366230276688465920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRUcfwwCUAAYcGV.png",
      "sizes" : [ {
        "h" : 900,
        "resize" : "fit",
        "w" : 1440
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 213,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/2El4YcGykF"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/4X1pxkcVjx",
      "expanded_url" : "http:\/\/excelramblings.blogspot.fr\/2013\/08\/what-does-google-autocomplete-show-all.html",
      "display_url" : "excelramblings.blogspot.fr\/2013\/08\/what-d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "366230276680077312",
  "text" : "French Google users think - English is fun\/cool\/good for you; play w\/ other queries using this http:\/\/t.co\/4X1pxkcVjx http:\/\/t.co\/2El4YcGykF",
  "id" : 366230276680077312,
  "created_at" : "2013-08-10 16:11:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Hawksey",
      "screen_name" : "mhawksey",
      "indices" : [ 3, 12 ],
      "id_str" : "13046992",
      "id" : 13046992
    }, {
      "name" : "Bruce McPherson",
      "screen_name" : "brucemcpherson",
      "indices" : [ 87, 102 ],
      "id_str" : "17517365",
      "id" : 17517365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/C6zAbeuZC5",
      "expanded_url" : "http:\/\/feedly.com\/k\/161bVCR",
      "display_url" : "feedly.com\/k\/161bVCR"
    } ]
  },
  "geo" : { },
  "id_str" : "366227559312130048",
  "text" : "RT @mhawksey: \"What does Google Autocomplete show all over the world ?\" nice hack from @brucemcpherson http:\/\/t.co\/C6zAbeuZC5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.feedly.com\" rel=\"nofollow\"\u003Efeedly\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bruce McPherson",
        "screen_name" : "brucemcpherson",
        "indices" : [ 73, 88 ],
        "id_str" : "17517365",
        "id" : 17517365
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/C6zAbeuZC5",
        "expanded_url" : "http:\/\/feedly.com\/k\/161bVCR",
        "display_url" : "feedly.com\/k\/161bVCR"
      } ]
    },
    "geo" : { },
    "id_str" : "366210042267058176",
    "text" : "\"What does Google Autocomplete show all over the world ?\" nice hack from @brucemcpherson http:\/\/t.co\/C6zAbeuZC5",
    "id" : 366210042267058176,
    "created_at" : "2013-08-10 14:50:52 +0000",
    "user" : {
      "name" : "Martin Hawksey",
      "screen_name" : "mhawksey",
      "protected" : false,
      "id_str" : "13046992",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2390851993\/xu6aptqy6a8rb2h2w5by_normal.jpeg",
      "id" : 13046992,
      "verified" : false
    }
  },
  "id" : 366227559312130048,
  "created_at" : "2013-08-10 16:00:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Phipps",
      "screen_name" : "lousylinguist",
      "indices" : [ 3, 17 ],
      "id_str" : "48459936",
      "id" : 48459936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/6IEYYMkg6Y",
      "expanded_url" : "http:\/\/www.newyorker.com\/archive\/1994\/07\/25\/1994_07_25_082_TNY_CARDS_000367745",
      "display_url" : "newyorker.com\/archive\/1994\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "366224091893604352",
  "text" : "RT @lousylinguist: \"I was very chalant, despite my efforts to appear gruntled and consolate.\" Cute story playing with unpaired words http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/6IEYYMkg6Y",
        "expanded_url" : "http:\/\/www.newyorker.com\/archive\/1994\/07\/25\/1994_07_25_082_TNY_CARDS_000367745",
        "display_url" : "newyorker.com\/archive\/1994\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "366209405890465792",
    "text" : "\"I was very chalant, despite my efforts to appear gruntled and consolate.\" Cute story playing with unpaired words http:\/\/t.co\/6IEYYMkg6Y",
    "id" : 366209405890465792,
    "created_at" : "2013-08-10 14:48:20 +0000",
    "user" : {
      "name" : "Christopher Phipps",
      "screen_name" : "lousylinguist",
      "protected" : false,
      "id_str" : "48459936",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750789987113660416\/2IPugaM9_normal.jpg",
      "id" : 48459936,
      "verified" : false
    }
  },
  "id" : 366224091893604352,
  "created_at" : "2013-08-10 15:46:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "natiserhost197",
      "screen_name" : "esl_robert",
      "indices" : [ 0, 11 ],
      "id_str" : "2982357761",
      "id" : 2982357761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366206200792104961",
  "geo" : { },
  "id_str" : "366206726971719680",
  "in_reply_to_user_id" : 18526186,
  "text" : "@esl_robert good luck, will you write it up later?",
  "id" : 366206726971719680,
  "in_reply_to_status_id" : 366206200792104961,
  "created_at" : "2013-08-10 14:37:42 +0000",
  "in_reply_to_screen_name" : "RobertEPoole",
  "in_reply_to_user_id_str" : "18526186",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 85, 93 ]
    }, {
      "text" : "tesol",
      "indices" : [ 94, 100 ]
    }, {
      "text" : "corpuslinguistics",
      "indices" : [ 101, 119 ]
    }, {
      "text" : "TOEIC",
      "indices" : [ 120, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/TpnlwFXmTp",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-Fd",
      "display_url" : "wp.me\/pgHyE-Fd"
    } ]
  },
  "geo" : { },
  "id_str" : "366198232331730944",
  "text" : "new blog post - Affixes, IntelliText and corpus use literacy http:\/\/t.co\/TpnlwFXmTp  #eltchat #tesol #corpuslinguistics #TOEIC",
  "id" : 366198232331730944,
  "created_at" : "2013-08-10 14:03:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 3, 11 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 122, 130 ]
    }, {
      "text" : "eapchat",
      "indices" : [ 131, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/w2kt2CyJEu",
      "expanded_url" : "http:\/\/fourc.ca\/fresh_prince\/",
      "display_url" : "fourc.ca\/fresh_prince\/"
    } ]
  },
  "geo" : { },
  "id_str" : "365889528961040385",
  "text" : "RT @seburnt: Now this is a story all about how... &gt; a Google Translate experiment with language http:\/\/t.co\/w2kt2CyJEu #eltchat #eapchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "eltchat",
        "indices" : [ 109, 117 ]
      }, {
        "text" : "eapchat",
        "indices" : [ 118, 126 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/w2kt2CyJEu",
        "expanded_url" : "http:\/\/fourc.ca\/fresh_prince\/",
        "display_url" : "fourc.ca\/fresh_prince\/"
      } ]
    },
    "geo" : { },
    "id_str" : "365884744828854272",
    "text" : "Now this is a story all about how... &gt; a Google Translate experiment with language http:\/\/t.co\/w2kt2CyJEu #eltchat #eapchat",
    "id" : 365884744828854272,
    "created_at" : "2013-08-09 17:18:15 +0000",
    "user" : {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "protected" : false,
      "id_str" : "20650366",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/743248377563971584\/9d9xlHlz_normal.jpg",
      "id" : 20650366,
      "verified" : false
    }
  },
  "id" : 365889528961040385,
  "created_at" : "2013-08-09 17:37:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 3, 11 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 122, 130 ]
    }, {
      "text" : "eapchat",
      "indices" : [ 131, 139 ]
    }, {
      "text" : "keltchat",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/uYf57bqIhh",
      "expanded_url" : "https:\/\/docs.google.com\/spreadsheet\/ccc?key=0Aixsh1aWiTKgdERKeG9VUkFzUmtQRC1BbkRueEx5X0E&usp=sharing",
      "display_url" : "docs.google.com\/spreadsheet\/cc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "365854356001669120",
  "text" : "RT @seburnt: Compiling a list of ELT-related Twitter chats for everyone. Please add yours here: https:\/\/t.co\/uYf57bqIhh \u2026 #eltchat #eapchat\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "eltchat",
        "indices" : [ 109, 117 ]
      }, {
        "text" : "eapchat",
        "indices" : [ 118, 126 ]
      }, {
        "text" : "keltchat",
        "indices" : [ 127, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/uYf57bqIhh",
        "expanded_url" : "https:\/\/docs.google.com\/spreadsheet\/ccc?key=0Aixsh1aWiTKgdERKeG9VUkFzUmtQRC1BbkRueEx5X0E&usp=sharing",
        "display_url" : "docs.google.com\/spreadsheet\/cc\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "365849257942597634",
    "text" : "Compiling a list of ELT-related Twitter chats for everyone. Please add yours here: https:\/\/t.co\/uYf57bqIhh \u2026 #eltchat #eapchat #keltchat",
    "id" : 365849257942597634,
    "created_at" : "2013-08-09 14:57:14 +0000",
    "user" : {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "protected" : false,
      "id_str" : "20650366",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/743248377563971584\/9d9xlHlz_normal.jpg",
      "id" : 20650366,
      "verified" : false
    }
  },
  "id" : 365854356001669120,
  "created_at" : "2013-08-09 15:17:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Open access MFL",
      "screen_name" : "YazikOpen",
      "indices" : [ 3, 13 ],
      "id_str" : "411834669",
      "id" : 411834669
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/RjginekKWz",
      "expanded_url" : "http:\/\/www.yazikopen.org.uk\/yazikopen\/top100June12",
      "display_url" : "yazikopen.org.uk\/yazikopen\/top1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "365852151156715520",
  "text" : "RT @YazikOpen: Top 100 cited open access publications in language teaching http:\/\/t.co\/RjginekKWz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/RjginekKWz",
        "expanded_url" : "http:\/\/www.yazikopen.org.uk\/yazikopen\/top100June12",
        "display_url" : "yazikopen.org.uk\/yazikopen\/top1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "365789837850185728",
    "text" : "Top 100 cited open access publications in language teaching http:\/\/t.co\/RjginekKWz",
    "id" : 365789837850185728,
    "created_at" : "2013-08-09 11:01:08 +0000",
    "user" : {
      "name" : "Open access MFL",
      "screen_name" : "YazikOpen",
      "protected" : false,
      "id_str" : "411834669",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1637661059\/yazik_with_slogan_normal.png",
      "id" : 411834669,
      "verified" : false
    }
  },
  "id" : 365852151156715520,
  "created_at" : "2013-08-09 15:08:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jack Askew",
      "screen_name" : "eslonlinejack",
      "indices" : [ 3, 17 ],
      "id_str" : "1513170398",
      "id" : 1513170398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 125, 140 ],
      "url" : "http:\/\/t.co\/6GfLVdXNfE",
      "expanded_url" : "http:\/\/bit.ly\/19PL8es",
      "display_url" : "bit.ly\/19PL8es"
    } ]
  },
  "geo" : { },
  "id_str" : "365482435875577856",
  "text" : "RT @eslonlinejack: If you want to teach online, you have to choose a good niche. There are some profitable niches out there! http:\/\/t.co\/6G\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/6GfLVdXNfE",
        "expanded_url" : "http:\/\/bit.ly\/19PL8es",
        "display_url" : "bit.ly\/19PL8es"
      } ]
    },
    "geo" : { },
    "id_str" : "365467559232929792",
    "text" : "If you want to teach online, you have to choose a good niche. There are some profitable niches out there! http:\/\/t.co\/6GfLVdXNfE",
    "id" : 365467559232929792,
    "created_at" : "2013-08-08 13:40:30 +0000",
    "user" : {
      "name" : "Jack Askew",
      "screen_name" : "eslonlinejack",
      "protected" : false,
      "id_str" : "1513170398",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/484685723677638657\/aIA1Yymj_normal.png",
      "id" : 1513170398,
      "verified" : false
    }
  },
  "id" : 365482435875577856,
  "created_at" : "2013-08-08 14:39:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Hawksey",
      "screen_name" : "mhawksey",
      "indices" : [ 3, 12 ],
      "id_str" : "13046992",
      "id" : 13046992
    }, {
      "name" : "Alan Levine",
      "screen_name" : "cogdog",
      "indices" : [ 96, 103 ],
      "id_str" : "740343",
      "id" : 740343
    }, {
      "name" : "Seb Schmoller",
      "screen_name" : "sebschmoller",
      "indices" : [ 132, 140 ],
      "id_str" : "41209095",
      "id" : 41209095
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ds106",
      "indices" : [ 34, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/EDSDeWQIia",
      "expanded_url" : "http:\/\/blogs.edweek.org\/edweek\/edtechresearcher\/2013\/08\/a_new_learning_environment_for_the_future_of_learning.html",
      "display_url" : "blogs.edweek.org\/edweek\/edtechr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "365396489993846784",
  "text" : "RT @mhawksey: Nice to see another #ds106\/FWP style course emerges (this one lovingly crafted by @cogdog) http:\/\/t.co\/EDSDeWQIia via @sebsch\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Alan Levine",
        "screen_name" : "cogdog",
        "indices" : [ 82, 89 ],
        "id_str" : "740343",
        "id" : 740343
      }, {
        "name" : "Seb Schmoller",
        "screen_name" : "sebschmoller",
        "indices" : [ 118, 131 ],
        "id_str" : "41209095",
        "id" : 41209095
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ds106",
        "indices" : [ 20, 26 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/EDSDeWQIia",
        "expanded_url" : "http:\/\/blogs.edweek.org\/edweek\/edtechresearcher\/2013\/08\/a_new_learning_environment_for_the_future_of_learning.html",
        "display_url" : "blogs.edweek.org\/edweek\/edtechr\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "365363968509886466",
    "text" : "Nice to see another #ds106\/FWP style course emerges (this one lovingly crafted by @cogdog) http:\/\/t.co\/EDSDeWQIia via @sebschmoller",
    "id" : 365363968509886466,
    "created_at" : "2013-08-08 06:48:52 +0000",
    "user" : {
      "name" : "Martin Hawksey",
      "screen_name" : "mhawksey",
      "protected" : false,
      "id_str" : "13046992",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2390851993\/xu6aptqy6a8rb2h2w5by_normal.jpeg",
      "id" : 13046992,
      "verified" : false
    }
  },
  "id" : 365396489993846784,
  "created_at" : "2013-08-08 08:58:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrea Wade",
      "screen_name" : "worldteacher",
      "indices" : [ 3, 16 ],
      "id_str" : "21180690",
      "id" : 21180690
    }, {
      "name" : "CamEngTeacher",
      "screen_name" : "CamEngTeacher",
      "indices" : [ 124, 138 ],
      "id_str" : "347137901",
      "id" : 347137901
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/qEV4v1C96r",
      "expanded_url" : "http:\/\/worldteacher-andrea.blogspot.com\/2013\/08\/corpora-and-advanced-level-problems-and.html?spref=tw",
      "display_url" : "worldteacher-andrea.blogspot.com\/2013\/08\/corpor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "363339415160360961",
  "text" : "RT @worldteacher: Just blogged: Corpora and the advanced level: problems and prosp... http:\/\/t.co\/qEV4v1C96r a summary of a @CamEngTeacher \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CamEngTeacher",
        "screen_name" : "CamEngTeacher",
        "indices" : [ 106, 120 ],
        "id_str" : "347137901",
        "id" : 347137901
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "eltchat",
        "indices" : [ 130, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/qEV4v1C96r",
        "expanded_url" : "http:\/\/worldteacher-andrea.blogspot.com\/2013\/08\/corpora-and-advanced-level-problems-and.html?spref=tw",
        "display_url" : "worldteacher-andrea.blogspot.com\/2013\/08\/corpor\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "363300215660359684",
    "text" : "Just blogged: Corpora and the advanced level: problems and prosp... http:\/\/t.co\/qEV4v1C96r a summary of a @CamEngTeacher webinar. #eltchat",
    "id" : 363300215660359684,
    "created_at" : "2013-08-02 14:08:15 +0000",
    "user" : {
      "name" : "Andrea Wade",
      "screen_name" : "worldteacher",
      "protected" : false,
      "id_str" : "21180690",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1129095622\/S7300602_normal.JPG",
      "id" : 21180690,
      "verified" : false
    }
  },
  "id" : 363339415160360961,
  "created_at" : "2013-08-02 16:44:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "natiserhost197",
      "screen_name" : "esl_robert",
      "indices" : [ 3, 14 ],
      "id_str" : "2982357761",
      "id" : 2982357761
    }, {
      "name" : "CALPER",
      "screen_name" : "CALPERPA",
      "indices" : [ 73, 82 ],
      "id_str" : "34639201",
      "id" : 34639201
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/uaZY4ej3qa",
      "expanded_url" : "http:\/\/bit.ly\/135OeU9",
      "display_url" : "bit.ly\/135OeU9"
    } ]
  },
  "geo" : { },
  "id_str" : "363073946339393537",
  "text" : "RT @esl_robert: A very useful corpus tutorial for language teachers from @CALPERPA . http:\/\/t.co\/uaZY4ej3qa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CALPER",
        "screen_name" : "CALPERPA",
        "indices" : [ 57, 66 ],
        "id_str" : "34639201",
        "id" : 34639201
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/uaZY4ej3qa",
        "expanded_url" : "http:\/\/bit.ly\/135OeU9",
        "display_url" : "bit.ly\/135OeU9"
      } ]
    },
    "geo" : { },
    "id_str" : "363025842529517568",
    "text" : "A very useful corpus tutorial for language teachers from @CALPERPA . http:\/\/t.co\/uaZY4ej3qa",
    "id" : 363025842529517568,
    "created_at" : "2013-08-01 19:58:00 +0000",
    "user" : {
      "name" : "Robert Poole",
      "screen_name" : "RobertEPoole",
      "protected" : false,
      "id_str" : "18526186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/586985086073069568\/UbAcX_I3_normal.jpg",
      "id" : 18526186,
      "verified" : false
    }
  },
  "id" : 363073946339393537,
  "created_at" : "2013-08-01 23:09:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "indices" : [ 0, 12 ],
      "id_str" : "192437743",
      "id" : 192437743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362670913541517313",
  "geo" : { },
  "id_str" : "362864807612919808",
  "in_reply_to_user_id" : 192437743,
  "text" : "@nathanghall that's a great primer, thanks.",
  "id" : 362864807612919808,
  "in_reply_to_status_id" : 362670913541517313,
  "created_at" : "2013-08-01 09:18:06 +0000",
  "in_reply_to_screen_name" : "nathanghall",
  "in_reply_to_user_id_str" : "192437743",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
} ]