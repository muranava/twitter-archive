Grailbird.data.tweets_2014_07 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 121, 137 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/tjHUTc4gXW",
      "expanded_url" : "http:\/\/wp.me\/p2CPYN-dB",
      "display_url" : "wp.me\/p2CPYN-dB"
    } ]
  },
  "geo" : { },
  "id_str" : "489531701152854017",
  "text" : "Ex-NYT editor Jill Abramson on how flak and 'anti-terrorism' help discipline corporate media. http:\/\/t.co\/tjHUTc4gXW via @wordpressdotcom",
  "id" : 489531701152854017,
  "created_at" : "2014-07-16 22:07:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BELTA Belgium",
      "screen_name" : "BELTABelgium",
      "indices" : [ 3, 16 ],
      "id_str" : "884934438",
      "id" : 884934438
    }, {
      "name" : "BELTA Belgium",
      "screen_name" : "BELTABelgium",
      "indices" : [ 35, 48 ],
      "id_str" : "884934438",
      "id" : 884934438
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TESLToronto",
      "indices" : [ 18, 30 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 115, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/T7ZG8Ucieo",
      "expanded_url" : "http:\/\/ow.ly\/zcBYa",
      "display_url" : "ow.ly\/zcBYa"
    } ]
  },
  "geo" : { },
  "id_str" : "489349407239061504",
  "text" : "RT @BELTABelgium: #TESLToronto and @BELTABelgium web conference programme is now available! http:\/\/t.co\/T7ZG8Ucieo #eltchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BELTA Belgium",
        "screen_name" : "BELTABelgium",
        "indices" : [ 17, 30 ],
        "id_str" : "884934438",
        "id" : 884934438
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TESLToronto",
        "indices" : [ 0, 12 ]
      }, {
        "text" : "eltchat",
        "indices" : [ 97, 105 ]
      } ],
      "urls" : [ {
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/T7ZG8Ucieo",
        "expanded_url" : "http:\/\/ow.ly\/zcBYa",
        "display_url" : "ow.ly\/zcBYa"
      } ]
    },
    "geo" : { },
    "id_str" : "489348952962383872",
    "text" : "#TESLToronto and @BELTABelgium web conference programme is now available! http:\/\/t.co\/T7ZG8Ucieo #eltchat",
    "id" : 489348952962383872,
    "created_at" : "2014-07-16 10:00:56 +0000",
    "user" : {
      "name" : "BELTA Belgium",
      "screen_name" : "BELTABelgium",
      "protected" : false,
      "id_str" : "884934438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3130800745\/d36391a9857692e6c2aab76d0033ade0_normal.png",
      "id" : 884934438,
      "verified" : false
    }
  },
  "id" : 489349407239061504,
  "created_at" : "2014-07-16 10:02:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/XevPpV6CvD",
      "expanded_url" : "http:\/\/tltcj.blogspot.fr\/2014\/07\/trends-of-language-teacher-cognition-in.html",
      "display_url" : "tltcj.blogspot.fr\/2014\/07\/trends\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "489115300185767939",
  "text" : "Trends of Language Teacher Cognition in Japan, free book http:\/\/t.co\/XevPpV6CvD",
  "id" : 489115300185767939,
  "created_at" : "2014-07-15 18:32:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Simpson",
      "screen_name" : "yearinthelifeof",
      "indices" : [ 0, 16 ],
      "id_str" : "78543378",
      "id" : 78543378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "489010204533850112",
  "geo" : { },
  "id_str" : "489010928009355264",
  "in_reply_to_user_id" : 78543378,
  "text" : "@yearinthelifeof good luck!",
  "id" : 489010928009355264,
  "in_reply_to_status_id" : 489010204533850112,
  "created_at" : "2014-07-15 11:37:45 +0000",
  "in_reply_to_screen_name" : "yearinthelifeof",
  "in_reply_to_user_id_str" : "78543378",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Simpson",
      "screen_name" : "yearinthelifeof",
      "indices" : [ 43, 59 ],
      "id_str" : "78543378",
      "id" : 78543378
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/489009452654141441\/photo\/1",
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/bgGbScuUYs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BslPgVICIAI709X.png",
      "id_str" : "489009451391655938",
      "id" : 489009451391655938,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BslPgVICIAI709X.png",
      "sizes" : [ {
        "h" : 383,
        "resize" : "fit",
        "w" : 443
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 443
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 443
      }, {
        "h" : 294,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/bgGbScuUYs"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "489002716509655040",
  "geo" : { },
  "id_str" : "489009452654141441",
  "in_reply_to_user_id" : 78543378,
  "text" : "is adam going into a new line of business? @yearinthelifeof :) http:\/\/t.co\/bgGbScuUYs",
  "id" : 489009452654141441,
  "in_reply_to_status_id" : 489002716509655040,
  "created_at" : "2014-07-15 11:31:53 +0000",
  "in_reply_to_screen_name" : "yearinthelifeof",
  "in_reply_to_user_id_str" : "78543378",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    }, {
      "name" : "Adam Beale",
      "screen_name" : "bealer81",
      "indices" : [ 7, 16 ],
      "id_str" : "238993337",
      "id" : 238993337
    }, {
      "name" : "Matthew Noble",
      "screen_name" : "NewbieCELTA",
      "indices" : [ 17, 29 ],
      "id_str" : "2311153903",
      "id" : 2311153903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "488794138922717184",
  "geo" : { },
  "id_str" : "488800289471094784",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl @bealer81 @NewbieCELTA agree content interesting but imo 30mins too long for a podcast and nice tune :)",
  "id" : 488800289471094784,
  "in_reply_to_status_id" : 488794138922717184,
  "created_at" : "2014-07-14 21:40:45 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Bogost",
      "screen_name" : "ibogost",
      "indices" : [ 0, 8 ],
      "id_str" : "6825792",
      "id" : 6825792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "488742110301290496",
  "geo" : { },
  "id_str" : "488778262425112576",
  "in_reply_to_user_id" : 6825792,
  "text" : "@ibogost ak bad investment memories :(",
  "id" : 488778262425112576,
  "in_reply_to_status_id" : 488742110301290496,
  "created_at" : "2014-07-14 20:13:13 +0000",
  "in_reply_to_screen_name" : "ibogost",
  "in_reply_to_user_id_str" : "6825792",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "488775900264419328",
  "geo" : { },
  "id_str" : "488777492183146496",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl linky?",
  "id" : 488777492183146496,
  "in_reply_to_status_id" : 488775900264419328,
  "created_at" : "2014-07-14 20:10:09 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George Chilton",
      "screen_name" : "designerlessons",
      "indices" : [ 3, 19 ],
      "id_str" : "432090149",
      "id" : 432090149
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELT",
      "indices" : [ 116, 120 ]
    }, {
      "text" : "keltchat",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "auselt",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 140 ],
      "url" : "http:\/\/t.co\/xJIPs7bucu",
      "expanded_url" : "http:\/\/ln.is\/es.surveymonkey.com\/e1sfM",
      "display_url" : "ln.is\/es.surveymonke\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "488777432997318656",
  "text" : "RT @designerlessons: We are carrying out a 5min survey which is intended to build a global picture of conditions in #ELT http:\/\/t.co\/xJIPs7\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELT",
        "indices" : [ 95, 99 ]
      }, {
        "text" : "keltchat",
        "indices" : [ 123, 132 ]
      }, {
        "text" : "auselt",
        "indices" : [ 133, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/xJIPs7bucu",
        "expanded_url" : "http:\/\/ln.is\/es.surveymonkey.com\/e1sfM",
        "display_url" : "ln.is\/es.surveymonke\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "488775091950735360",
    "text" : "We are carrying out a 5min survey which is intended to build a global picture of conditions in #ELT http:\/\/t.co\/xJIPs7bucu #keltchat #auselt",
    "id" : 488775091950735360,
    "created_at" : "2014-07-14 20:00:37 +0000",
    "user" : {
      "name" : "George Chilton",
      "screen_name" : "designerlessons",
      "protected" : false,
      "id_str" : "432090149",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/468158165914501121\/aHVWzkwG_normal.jpeg",
      "id" : 432090149,
      "verified" : false
    }
  },
  "id" : 488777432997318656,
  "created_at" : "2014-07-14 20:09:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Achilleas Kostoulas",
      "screen_name" : "AchilleasK",
      "indices" : [ 54, 65 ],
      "id_str" : "134191406",
      "id" : 134191406
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/CgFhCVS15x",
      "expanded_url" : "http:\/\/wp.me\/p2aFDK-Gj",
      "display_url" : "wp.me\/p2aFDK-Gj"
    } ]
  },
  "geo" : { },
  "id_str" : "488761979541008385",
  "text" : "BAAL LLT 2014: an overview http:\/\/t.co\/CgFhCVS15x via @AchilleasK",
  "id" : 488761979541008385,
  "created_at" : "2014-07-14 19:08:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "488651101580066817",
  "text" : "tchrs Fr new jobs list email teachingjobsinfrance-subscribe@yahoogroups.com to subscribe, teachingjobsinfrance@yahoogroups.com to list",
  "id" : 488651101580066817,
  "created_at" : "2014-07-14 11:47:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DesignSpark",
      "screen_name" : "DesignSparkRS",
      "indices" : [ 0, 14 ],
      "id_str" : "135486484",
      "id" : 135486484
    }, {
      "name" : "Magnus Nissel",
      "screen_name" : "u203d",
      "indices" : [ 15, 21 ],
      "id_str" : "533114985",
      "id" : 533114985
    }, {
      "name" : "Raspberry Pi",
      "screen_name" : "Raspberry_Pi",
      "indices" : [ 22, 35 ],
      "id_str" : "302666251",
      "id" : 302666251
    }, {
      "name" : "Tom Herbison MI0IOU",
      "screen_name" : "TomHerbison",
      "indices" : [ 36, 48 ],
      "id_str" : "718756606",
      "id" : 718756606
    }, {
      "name" : "\u266B Evil-Dragon \u266B",
      "screen_name" : "EvilDragon",
      "indices" : [ 129, 140 ],
      "id_str" : "18552931",
      "id" : 18552931
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpenPandora",
      "indices" : [ 73, 85 ]
    }, {
      "text" : "Pyra",
      "indices" : [ 96, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/6RdrQHYaXx",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=Yvm2AiM4F5Q",
      "display_url" : "youtube.com\/watch?v=Yvm2Ai\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "488589994056241152",
  "geo" : { },
  "id_str" : "488617762403930113",
  "in_reply_to_user_id" : 135486484,
  "text" : "@DesignSparkRS @u203d @Raspberry_Pi @TomHerbison checkout pcb design new #OpenPandora board the #Pyra https:\/\/t.co\/6RdrQHYaXx ht @EvilDragon",
  "id" : 488617762403930113,
  "in_reply_to_status_id" : 488589994056241152,
  "created_at" : "2014-07-14 09:35:27 +0000",
  "in_reply_to_screen_name" : "DesignSparkRS",
  "in_reply_to_user_id_str" : "135486484",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "488615786433757184",
  "text" : "tchrs France new jobs list email teachingjobsinfrance-subscribe@yahoogroups.com to subscribe, teachingjobsinfrance@yahoogroups.com to list",
  "id" : 488615786433757184,
  "created_at" : "2014-07-14 09:27:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricardo-M Jim\u00E9nez",
      "screen_name" : "Richardics",
      "indices" : [ 11, 22 ],
      "id_str" : "50282689",
      "id" : 50282689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/HbcXE2CtRl",
      "expanded_url" : "http:\/\/dictiome.blogspot.fr\/2014\/05\/dictiome-pronunciation-app.html",
      "display_url" : "dictiome.blogspot.fr\/2014\/05\/dictio\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "488258155827052544",
  "text" : "@_FTaylor_ @Richardics have a try of this http:\/\/t.co\/HbcXE2CtRl",
  "id" : 488258155827052544,
  "created_at" : "2014-07-13 09:46:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Edwards",
      "screen_name" : "EdLaur",
      "indices" : [ 0, 7 ],
      "id_str" : "1834826917",
      "id" : 1834826917
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "488087548393447429",
  "geo" : { },
  "id_str" : "488088297852637184",
  "in_reply_to_user_id" : 1834826917,
  "text" : "@EdLaur i think most of this was\/is dealing with so called \"passive\" lecture delivery which i think is a strawman argument",
  "id" : 488088297852637184,
  "in_reply_to_status_id" : 488087548393447429,
  "created_at" : "2014-07-12 22:31:33 +0000",
  "in_reply_to_screen_name" : "EdLaur",
  "in_reply_to_user_id_str" : "1834826917",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JackieGerstein Ed.D.",
      "screen_name" : "jackiegerstein",
      "indices" : [ 0, 15 ],
      "id_str" : "16005270",
      "id" : 16005270
    }, {
      "name" : "Laura Edwards",
      "screen_name" : "EdLaur",
      "indices" : [ 16, 23 ],
      "id_str" : "1834826917",
      "id" : 1834826917
    }, {
      "name" : "JoAnn Jacobs",
      "screen_name" : "JoAnnJacobs68",
      "indices" : [ 24, 38 ],
      "id_str" : "153586484",
      "id" : 153586484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/IoGeG7HCAz",
      "expanded_url" : "http:\/\/www.columbia.edu\/cu\/tat\/pdfs\/active%20learning.pdf",
      "display_url" : "columbia.edu\/cu\/tat\/pdfs\/ac\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "488023543356338176",
  "geo" : { },
  "id_str" : "488084908532043776",
  "in_reply_to_user_id" : 16005270,
  "text" : "@jackiegerstein @EdLaur @JoAnnJacobs68 not very recent citations apparently http:\/\/t.co\/IoGeG7HCAz",
  "id" : 488084908532043776,
  "in_reply_to_status_id" : 488023543356338176,
  "created_at" : "2014-07-12 22:18:05 +0000",
  "in_reply_to_screen_name" : "jackiegerstein",
  "in_reply_to_user_id_str" : "16005270",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob From Brockley",
      "screen_name" : "bobfrombrockley",
      "indices" : [ 0, 16 ],
      "id_str" : "221322848",
      "id" : 221322848
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "487927780882268160",
  "geo" : { },
  "id_str" : "487934455546249218",
  "in_reply_to_user_id" : 221322848,
  "text" : "@bobfrombrockley one person's murderous dictator is another person's lucarative military customer; yes limit obscene paychecks ceo's 1st",
  "id" : 487934455546249218,
  "in_reply_to_status_id" : 487927780882268160,
  "created_at" : "2014-07-12 12:20:14 +0000",
  "in_reply_to_screen_name" : "bobfrombrockley",
  "in_reply_to_user_id_str" : "221322848",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob From Brockley",
      "screen_name" : "bobfrombrockley",
      "indices" : [ 0, 16 ],
      "id_str" : "221322848",
      "id" : 221322848
    }, {
      "name" : "Daniel Allington",
      "screen_name" : "dr_d_allington",
      "indices" : [ 17, 32 ],
      "id_str" : "1287008022",
      "id" : 1287008022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "487865517316009984",
  "geo" : { },
  "id_str" : "487920964479352832",
  "in_reply_to_user_id" : 221322848,
  "text" : "@bobfrombrockley @dr_d_allington erm people work they get paid...",
  "id" : 487920964479352832,
  "in_reply_to_status_id" : 487865517316009984,
  "created_at" : "2014-07-12 11:26:37 +0000",
  "in_reply_to_screen_name" : "bobfrombrockley",
  "in_reply_to_user_id_str" : "221322848",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Canan Aktu\u011F",
      "screen_name" : "Jananstwit",
      "indices" : [ 0, 11 ],
      "id_str" : "179676661",
      "id" : 179676661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/hHOia2pA9r",
      "expanded_url" : "https:\/\/plus.google.com\/104940199413423400545\/posts\/eR7ZTgiejEP",
      "display_url" : "plus.google.com\/10494019941342\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "487907895816634369",
  "geo" : { },
  "id_str" : "487909717080301568",
  "in_reply_to_user_id" : 179676661,
  "text" : "@Jananstwit another media report confusing cambr corpus with cambr world cup corpus! for accurate details see https:\/\/t.co\/hHOia2pA9r",
  "id" : 487909717080301568,
  "in_reply_to_status_id" : 487907895816634369,
  "created_at" : "2014-07-12 10:41:56 +0000",
  "in_reply_to_screen_name" : "Jananstwit",
  "in_reply_to_user_id_str" : "179676661",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Adele Soracco",
      "screen_name" : "LauraSoracco",
      "indices" : [ 0, 13 ],
      "id_str" : "15663328",
      "id" : 15663328
    }, {
      "name" : "Mike S. Boyle",
      "screen_name" : "heyboyle",
      "indices" : [ 14, 23 ],
      "id_str" : "612840231",
      "id" : 612840231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "487843627482501120",
  "geo" : { },
  "id_str" : "487883488902012928",
  "in_reply_to_user_id" : 15663328,
  "text" : "@LauraSoracco @heyboyle zotero is an option, have tried diigo not bad",
  "id" : 487883488902012928,
  "in_reply_to_status_id" : 487843627482501120,
  "created_at" : "2014-07-12 08:57:42 +0000",
  "in_reply_to_screen_name" : "LauraSoracco",
  "in_reply_to_user_id_str" : "15663328",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LQ2OujnXCF",
      "expanded_url" : "http:\/\/tinyurl.com\/mqhp9kr",
      "display_url" : "tinyurl.com\/mqhp9kr"
    } ]
  },
  "geo" : { },
  "id_str" : "487731467993108480",
  "text" : "http:\/\/t.co\/LQ2OujnXCF -- Gaza Under Attack: Day 4",
  "id" : 487731467993108480,
  "created_at" : "2014-07-11 22:53:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Lavigne",
      "screen_name" : "sam_lavigne",
      "indices" : [ 0, 12 ],
      "id_str" : "6428702",
      "id" : 6428702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "487700698620899328",
  "geo" : { },
  "id_str" : "487702620585607168",
  "in_reply_to_user_id" : 6428702,
  "text" : "@sam_lavigne hi so that you can search say for 4 words before and 4 words after target word?",
  "id" : 487702620585607168,
  "in_reply_to_status_id" : 487700698620899328,
  "created_at" : "2014-07-11 20:59:00 +0000",
  "in_reply_to_screen_name" : "sam_lavigne",
  "in_reply_to_user_id_str" : "6428702",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Aisha Brown",
      "screen_name" : "amyaishab",
      "indices" : [ 0, 10 ],
      "id_str" : "900029641",
      "id" : 900029641
    }, {
      "name" : "KBarrs",
      "screen_name" : "corpusloanword",
      "indices" : [ 11, 26 ],
      "id_str" : "95419070",
      "id" : 95419070
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/FZ3AqAePOJ",
      "expanded_url" : "http:\/\/www.thegrammarlab.com\/?p=411",
      "display_url" : "thegrammarlab.com\/?p=411"
    } ]
  },
  "in_reply_to_status_id_str" : "487640680819601408",
  "geo" : { },
  "id_str" : "487643872504590337",
  "in_reply_to_user_id" : 900029641,
  "text" : "@amyaishab @corpusloanword i dont think they used tweets? could be a quick summer project using say these tips - http:\/\/t.co\/FZ3AqAePOJ",
  "id" : 487643872504590337,
  "in_reply_to_status_id" : 487640680819601408,
  "created_at" : "2014-07-11 17:05:33 +0000",
  "in_reply_to_screen_name" : "amyaishab",
  "in_reply_to_user_id_str" : "900029641",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KBarrs",
      "screen_name" : "corpusloanword",
      "indices" : [ 0, 15 ],
      "id_str" : "95419070",
      "id" : 95419070
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "487619168020094977",
  "geo" : { },
  "id_str" : "487634685028073472",
  "in_reply_to_user_id" : 95419070,
  "text" : "@corpusloanword yeah they (or cambridge PR) confused it with the cambridge corpus",
  "id" : 487634685028073472,
  "in_reply_to_status_id" : 487619168020094977,
  "created_at" : "2014-07-11 16:29:03 +0000",
  "in_reply_to_screen_name" : "corpusloanword",
  "in_reply_to_user_id_str" : "95419070",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Lavigne",
      "screen_name" : "sam_lavigne",
      "indices" : [ 0, 12 ],
      "id_str" : "6428702",
      "id" : 6428702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "487596778309836800",
  "in_reply_to_user_id" : 6428702,
  "text" : "@sam_lavigne hi re videogrep is it possible to add a word window similar to the padding time window?",
  "id" : 487596778309836800,
  "created_at" : "2014-07-11 13:58:25 +0000",
  "in_reply_to_screen_name" : "sam_lavigne",
  "in_reply_to_user_id_str" : "6428702",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\" rel=\"nofollow\"\u003EEchofon  Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beatrice Reed",
      "screen_name" : "BB_Reed",
      "indices" : [ 3, 11 ],
      "id_str" : "2502542837",
      "id" : 2502542837
    }, {
      "name" : "Slate",
      "screen_name" : "Slate",
      "indices" : [ 36, 42 ],
      "id_str" : "15164565",
      "id" : 15164565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/CmUmQ3IdG8",
      "expanded_url" : "http:\/\/slate.me\/1qNFAYJ",
      "display_url" : "slate.me\/1qNFAYJ"
    } ]
  },
  "geo" : { },
  "id_str" : "487521171353894912",
  "text" : "RT @BB_Reed: 'Preposition creep' RT\u201C@Slate: What's going on around \"around\"? New uses of old prepositions: http:\/\/t.co\/CmUmQ3IdG8\u201D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Slate",
        "screen_name" : "Slate",
        "indices" : [ 23, 29 ],
        "id_str" : "15164565",
        "id" : 15164565
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/CmUmQ3IdG8",
        "expanded_url" : "http:\/\/slate.me\/1qNFAYJ",
        "display_url" : "slate.me\/1qNFAYJ"
      } ]
    },
    "in_reply_to_status_id_str" : "487400312693882880",
    "geo" : { },
    "id_str" : "487512445318332416",
    "in_reply_to_user_id" : 15164565,
    "text" : "'Preposition creep' RT\u201C@Slate: What's going on around \"around\"? New uses of old prepositions: http:\/\/t.co\/CmUmQ3IdG8\u201D",
    "id" : 487512445318332416,
    "in_reply_to_status_id" : 487400312693882880,
    "created_at" : "2014-07-11 08:23:19 +0000",
    "in_reply_to_screen_name" : "Slate",
    "in_reply_to_user_id_str" : "15164565",
    "user" : {
      "name" : "Beatrice Reed",
      "screen_name" : "BB_Reed",
      "protected" : false,
      "id_str" : "2502542837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/580495049575763968\/nTERlTr9_normal.jpg",
      "id" : 2502542837,
      "verified" : false
    }
  },
  "id" : 487521171353894912,
  "created_at" : "2014-07-11 08:57:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\" rel=\"nofollow\"\u003EEchofon  Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KBarrs",
      "screen_name" : "corpusloanword",
      "indices" : [ 3, 18 ],
      "id_str" : "95419070",
      "id" : 95419070
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/74MRrStaDI",
      "expanded_url" : "http:\/\/bit.ly\/1mQQKMe",
      "display_url" : "bit.ly\/1mQQKMe"
    } ]
  },
  "in_reply_to_status_id_str" : "487417770380754944",
  "geo" : { },
  "id_str" : "487518382640861185",
  "in_reply_to_user_id" : 95419070,
  "text" : "Hi @corpusloanword a bit more detail about corpus here http:\/\/t.co\/74MRrStaDI",
  "id" : 487518382640861185,
  "in_reply_to_status_id" : 487417770380754944,
  "created_at" : "2014-07-11 08:46:54 +0000",
  "in_reply_to_screen_name" : "corpusloanword",
  "in_reply_to_user_id_str" : "95419070",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\" rel=\"nofollow\"\u003EEchofon  Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Adele Soracco",
      "screen_name" : "LauraSoracco",
      "indices" : [ 0, 13 ],
      "id_str" : "15663328",
      "id" : 15663328
    }, {
      "name" : "Mike S. Boyle",
      "screen_name" : "heyboyle",
      "indices" : [ 14, 23 ],
      "id_str" : "612840231",
      "id" : 612840231
    }, {
      "name" : "Martin Hawksey",
      "screen_name" : "mhawksey",
      "indices" : [ 24, 33 ],
      "id_str" : "13046992",
      "id" : 13046992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "487508147154976768",
  "geo" : { },
  "id_str" : "487516581090844672",
  "in_reply_to_user_id" : 15663328,
  "text" : "@LauraSoracco @heyboyle @mhawksey  yes also I have examples of them on my blog(favs) and twitter profile(archive)",
  "id" : 487516581090844672,
  "in_reply_to_status_id" : 487508147154976768,
  "created_at" : "2014-07-11 08:39:45 +0000",
  "in_reply_to_screen_name" : "LauraSoracco",
  "in_reply_to_user_id_str" : "15663328",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Adele Soracco",
      "screen_name" : "LauraSoracco",
      "indices" : [ 0, 13 ],
      "id_str" : "15663328",
      "id" : 15663328
    }, {
      "name" : "Mike S. Boyle",
      "screen_name" : "heyboyle",
      "indices" : [ 14, 23 ],
      "id_str" : "612840231",
      "id" : 612840231
    }, {
      "name" : "Martin Hawksey",
      "screen_name" : "mhawksey",
      "indices" : [ 70, 79 ],
      "id_str" : "13046992",
      "id" : 13046992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "487470631530024960",
  "geo" : { },
  "id_str" : "487502274776682496",
  "in_reply_to_user_id" : 15663328,
  "text" : "@LauraSoracco @heyboyle try twitter archive and favourites scripts by @mhawksey",
  "id" : 487502274776682496,
  "in_reply_to_status_id" : 487470631530024960,
  "created_at" : "2014-07-11 07:42:54 +0000",
  "in_reply_to_screen_name" : "LauraSoracco",
  "in_reply_to_user_id_str" : "15663328",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike S. Boyle",
      "screen_name" : "heyboyle",
      "indices" : [ 0, 9 ],
      "id_str" : "612840231",
      "id" : 612840231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "487333047339999232",
  "geo" : { },
  "id_str" : "487333308280614912",
  "in_reply_to_user_id" : 612840231,
  "text" : "@heyboyle vacationing :)",
  "id" : 487333308280614912,
  "in_reply_to_status_id" : 487333047339999232,
  "created_at" : "2014-07-10 20:31:29 +0000",
  "in_reply_to_screen_name" : "heyboyle",
  "in_reply_to_user_id_str" : "612840231",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike S. Boyle",
      "screen_name" : "heyboyle",
      "indices" : [ 0, 9 ],
      "id_str" : "612840231",
      "id" : 612840231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "487332364927111169",
  "in_reply_to_user_id" : 612840231,
  "text" : "@heyboyle hi mike you know any good places to visit 1hr or 2hrs from Shenzhen or pointers to where I could look? thanks!",
  "id" : 487332364927111169,
  "created_at" : "2014-07-10 20:27:44 +0000",
  "in_reply_to_screen_name" : "heyboyle",
  "in_reply_to_user_id_str" : "612840231",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Claire Dembry",
      "screen_name" : "ClaireDembry",
      "indices" : [ 0, 13 ],
      "id_str" : "2396240628",
      "id" : 2396240628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/hHOia2pA9r",
      "expanded_url" : "https:\/\/plus.google.com\/104940199413423400545\/posts\/eR7ZTgiejEP",
      "display_url" : "plus.google.com\/10494019941342\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "487322122700980224",
  "geo" : { },
  "id_str" : "487327121480900609",
  "in_reply_to_user_id" : 2396240628,
  "text" : "@ClaireDembry many thx for responses collated here https:\/\/t.co\/hHOia2pA9r anychance corpus be available for public? :)",
  "id" : 487327121480900609,
  "in_reply_to_status_id" : 487322122700980224,
  "created_at" : "2014-07-10 20:06:54 +0000",
  "in_reply_to_screen_name" : "ClaireDembry",
  "in_reply_to_user_id_str" : "2396240628",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Claire Dembry",
      "screen_name" : "ClaireDembry",
      "indices" : [ 0, 13 ],
      "id_str" : "2396240628",
      "id" : 2396240628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "487320152028229633",
  "geo" : { },
  "id_str" : "487320698625728512",
  "in_reply_to_user_id" : 2396240628,
  "text" : "@ClaireDembry are you planning to continue till end of world cup? how did you make the core URL list? and update it? thx!",
  "id" : 487320698625728512,
  "in_reply_to_status_id" : 487320152028229633,
  "created_at" : "2014-07-10 19:41:23 +0000",
  "in_reply_to_screen_name" : "ClaireDembry",
  "in_reply_to_user_id_str" : "2396240628",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Claire Dembry",
      "screen_name" : "ClaireDembry",
      "indices" : [ 0, 13 ],
      "id_str" : "2396240628",
      "id" : 2396240628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "487317786239447040",
  "geo" : { },
  "id_str" : "487319323221164033",
  "in_reply_to_user_id" : 2396240628,
  "text" : "@ClaireDembry thx, what was the sampling period? seed words?",
  "id" : 487319323221164033,
  "in_reply_to_status_id" : 487317786239447040,
  "created_at" : "2014-07-10 19:35:55 +0000",
  "in_reply_to_screen_name" : "ClaireDembry",
  "in_reply_to_user_id_str" : "2396240628",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Claire Dembry",
      "screen_name" : "ClaireDembry",
      "indices" : [ 0, 13 ],
      "id_str" : "2396240628",
      "id" : 2396240628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "487315355933884416",
  "geo" : { },
  "id_str" : "487316603282141185",
  "in_reply_to_user_id" : 2396240628,
  "text" : "@ClaireDembry neat, is there any more detail on this?",
  "id" : 487316603282141185,
  "in_reply_to_status_id" : 487315355933884416,
  "created_at" : "2014-07-10 19:25:06 +0000",
  "in_reply_to_screen_name" : "ClaireDembry",
  "in_reply_to_user_id_str" : "2396240628",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Claire Dembry",
      "screen_name" : "ClaireDembry",
      "indices" : [ 0, 13 ],
      "id_str" : "2396240628",
      "id" : 2396240628
    }, {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "indices" : [ 14, 26 ],
      "id_str" : "849729062",
      "id" : 849729062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "487244458883166211",
  "geo" : { },
  "id_str" : "487310714412224512",
  "in_reply_to_user_id" : 2396240628,
  "text" : "@ClaireDembry @TonyMcEnery \"The multi-billion word database\" a ref to Cambridge corpus not World Cup corpus?any more info on WC corpus?thx",
  "id" : 487310714412224512,
  "in_reply_to_status_id" : 487244458883166211,
  "created_at" : "2014-07-10 19:01:42 +0000",
  "in_reply_to_screen_name" : "ClaireDembry",
  "in_reply_to_user_id_str" : "2396240628",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    }, {
      "name" : "vaclav",
      "screen_name" : "vaclavbrezina",
      "indices" : [ 12, 26 ],
      "id_str" : "1201576646",
      "id" : 1201576646
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "487283971571859458",
  "geo" : { },
  "id_str" : "487288410466684929",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco @vaclavbrezina open access rules :)",
  "id" : 487288410466684929,
  "in_reply_to_status_id" : 487283971571859458,
  "created_at" : "2014-07-10 17:33:05 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "P\u00E9rez-Paredes",
      "screen_name" : "perezparedes",
      "indices" : [ 0, 13 ],
      "id_str" : "28528850",
      "id" : 28528850
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "487225796382445568",
  "geo" : { },
  "id_str" : "487226305188872194",
  "in_reply_to_user_id" : 28528850,
  "text" : "@perezparedes for antconc? or for tagant?",
  "id" : 487226305188872194,
  "in_reply_to_status_id" : 487225796382445568,
  "created_at" : "2014-07-10 13:26:18 +0000",
  "in_reply_to_screen_name" : "perezparedes",
  "in_reply_to_user_id_str" : "28528850",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "P\u00E9rez-Paredes",
      "screen_name" : "perezparedes",
      "indices" : [ 0, 13 ],
      "id_str" : "28528850",
      "id" : 28528850
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "487223140985360385",
  "geo" : { },
  "id_str" : "487225482979864576",
  "in_reply_to_user_id" : 28528850,
  "text" : "@perezparedes um what's the update?",
  "id" : 487225482979864576,
  "in_reply_to_status_id" : 487223140985360385,
  "created_at" : "2014-07-10 13:23:02 +0000",
  "in_reply_to_screen_name" : "perezparedes",
  "in_reply_to_user_id_str" : "28528850",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonny Geller",
      "screen_name" : "JonnyGeller",
      "indices" : [ 0, 12 ],
      "id_str" : "23052167",
      "id" : 23052167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/fajX93ijXS",
      "expanded_url" : "https:\/\/plus.google.com\/104940199413423400545\/posts\/HF8hWXAUZfh",
      "display_url" : "plus.google.com\/10494019941342\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "487219101157572608",
  "in_reply_to_user_id" : 23052167,
  "text" : "@JonnyGeller hi do you know how i can get an answer to this david lodge deaf sentence question? https:\/\/t.co\/fajX93ijXS thanks!",
  "id" : 487219101157572608,
  "created_at" : "2014-07-10 12:57:40 +0000",
  "in_reply_to_screen_name" : "JonnyGeller",
  "in_reply_to_user_id_str" : "23052167",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adi Rajan",
      "screen_name" : "adi_rajan",
      "indices" : [ 0, 10 ],
      "id_str" : "1011323449",
      "id" : 1011323449
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "487206498074767360",
  "geo" : { },
  "id_str" : "487209807221624832",
  "in_reply_to_user_id" : 1011323449,
  "text" : "@adi_rajan nlp--&gt;nulp, reclaim nlp for natural language processing :)",
  "id" : 487209807221624832,
  "in_reply_to_status_id" : 487206498074767360,
  "created_at" : "2014-07-10 12:20:44 +0000",
  "in_reply_to_screen_name" : "adi_rajan",
  "in_reply_to_user_id_str" : "1011323449",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "News Unspun",
      "screen_name" : "news_unspun",
      "indices" : [ 3, 15 ],
      "id_str" : "241288268",
      "id" : 241288268
    }, {
      "name" : "Owen Jones",
      "screen_name" : "OwenJones84",
      "indices" : [ 23, 35 ],
      "id_str" : "65045121",
      "id" : 65045121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/2Iw2K0R2uo",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=MLhbPvVHGvs",
      "display_url" : "youtube.com\/watch?v=MLhbPv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "487207663974236160",
  "text" : "RT @news_unspun: Watch @OwenJones84 telling the BBC how they covered a pro-cuts rally (2011) more than an anti-cuts march 100x as big https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Owen Jones",
        "screen_name" : "OwenJones84",
        "indices" : [ 6, 18 ],
        "id_str" : "65045121",
        "id" : 65045121
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/2Iw2K0R2uo",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=MLhbPvVHGvs",
        "display_url" : "youtube.com\/watch?v=MLhbPv\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "482863702035931136",
    "text" : "Watch @OwenJones84 telling the BBC how they covered a pro-cuts rally (2011) more than an anti-cuts march 100x as big https:\/\/t.co\/2Iw2K0R2uo",
    "id" : 482863702035931136,
    "created_at" : "2014-06-28 12:30:52 +0000",
    "user" : {
      "name" : "News Unspun",
      "screen_name" : "news_unspun",
      "protected" : false,
      "id_str" : "241288268",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3176838178\/fa7f886ef014ca0437d5dc800dc9163e_normal.png",
      "id" : 241288268,
      "verified" : false
    }
  },
  "id" : 487207663974236160,
  "created_at" : "2014-07-10 12:12:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpus",
      "indices" : [ 15, 22 ]
    }, {
      "text" : "corpuslinguistics",
      "indices" : [ 74, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/HacAUIm98R",
      "expanded_url" : "http:\/\/www.thegrammarlab.com\/?portfolio=michigan-corpus-of-upper-level-student-papers",
      "display_url" : "thegrammarlab.com\/?portfolio=mic\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "487184753037410304",
  "text" : "get the MICUSP #corpus in POS tagged versions from http:\/\/t.co\/HacAUIm98R #corpuslinguistics",
  "id" : 487184753037410304,
  "created_at" : "2014-07-10 10:41:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Caulfield",
      "screen_name" : "holden",
      "indices" : [ 3, 10 ],
      "id_str" : "1912681",
      "id" : 1912681
    }, {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 24, 38 ],
      "id_str" : "25388528",
      "id" : 25388528
    }, {
      "name" : "Dan Meyer",
      "screen_name" : "ddmeyer",
      "indices" : [ 43, 51 ],
      "id_str" : "7198542",
      "id" : 7198542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 140 ],
      "url" : "http:\/\/t.co\/ey0Narb7U5",
      "expanded_url" : "http:\/\/hapgood.us\/2014\/07\/09\/the-original-factory-education-was-a-personalized-learning-experiement\/",
      "display_url" : "hapgood.us\/2014\/07\/09\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "487182427417481216",
  "text" : "RT @holden: This is for @audreywatters and @ddmeyer The Original Factory Education Was a Personalized Learning Experiment http:\/\/t.co\/ey0Na\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Audrey Watters",
        "screen_name" : "audreywatters",
        "indices" : [ 12, 26 ],
        "id_str" : "25388528",
        "id" : 25388528
      }, {
        "name" : "Dan Meyer",
        "screen_name" : "ddmeyer",
        "indices" : [ 31, 39 ],
        "id_str" : "7198542",
        "id" : 7198542
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/ey0Narb7U5",
        "expanded_url" : "http:\/\/hapgood.us\/2014\/07\/09\/the-original-factory-education-was-a-personalized-learning-experiement\/",
        "display_url" : "hapgood.us\/2014\/07\/09\/the\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "487027336651358208",
    "text" : "This is for @audreywatters and @ddmeyer The Original Factory Education Was a Personalized Learning Experiment http:\/\/t.co\/ey0Narb7U5",
    "id" : 487027336651358208,
    "created_at" : "2014-07-10 00:15:40 +0000",
    "user" : {
      "name" : "Mike Caulfield",
      "screen_name" : "holden",
      "protected" : false,
      "id_str" : "1912681",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/752538301538545665\/mXNoIc4W_normal.jpg",
      "id" : 1912681,
      "verified" : false
    }
  },
  "id" : 487182427417481216,
  "created_at" : "2014-07-10 10:31:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kat Gupta",
      "screen_name" : "mixosaurus",
      "indices" : [ 0, 11 ],
      "id_str" : "21158543",
      "id" : 21158543
    }, {
      "name" : "Amy Aisha Brown",
      "screen_name" : "amyaishab",
      "indices" : [ 12, 22 ],
      "id_str" : "900029641",
      "id" : 900029641
    }, {
      "name" : "Dawn Knight",
      "screen_name" : "nottyknight",
      "indices" : [ 23, 35 ],
      "id_str" : "83570076",
      "id" : 83570076
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 130, 152 ],
      "url" : "http:\/\/t.co\/mEdHJA08N4",
      "expanded_url" : "http:\/\/www.thegrammarlab.com\/?portfolio=file-content-sort",
      "display_url" : "thegrammarlab.com\/?portfolio=fil\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "486556582705389569",
  "geo" : { },
  "id_str" : "486885043663814656",
  "in_reply_to_user_id" : 18602422,
  "text" : "@mixosaurus @amyaishab @nottyknight if u are on OSX this script could help e.g.search for &lt;sourceDesc&gt;&lt;recordingStmt&gt; http:\/\/t.co\/mEdHJA08N4",
  "id" : 486885043663814656,
  "in_reply_to_status_id" : 486556582705389569,
  "created_at" : "2014-07-09 14:50:14 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/LkZfd34SXN",
      "expanded_url" : "http:\/\/www.thegrammarlab.com\/?p=373",
      "display_url" : "thegrammarlab.com\/?p=373"
    } ]
  },
  "geo" : { },
  "id_str" : "486883141575909378",
  "text" : "What Counts as Good Writing in High School? http:\/\/t.co\/LkZfd34SXN",
  "id" : 486883141575909378,
  "created_at" : "2014-07-09 14:42:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hancock McDonald ELT",
      "screen_name" : "HancockMcDonald",
      "indices" : [ 3, 19 ],
      "id_str" : "552929354",
      "id" : 552929354
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELT",
      "indices" : [ 47, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/EpFdD3k3aY",
      "expanded_url" : "http:\/\/tinyurl.com\/m6hrtqj",
      "display_url" : "tinyurl.com\/m6hrtqj"
    } ]
  },
  "geo" : { },
  "id_str" : "486876299877961728",
  "text" : "RT @HancockMcDonald: Mark Hancock: An Atlas of #ELT in development here! http:\/\/t.co\/EpFdD3k3aY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELT",
        "indices" : [ 26, 30 ]
      } ],
      "urls" : [ {
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/EpFdD3k3aY",
        "expanded_url" : "http:\/\/tinyurl.com\/m6hrtqj",
        "display_url" : "tinyurl.com\/m6hrtqj"
      } ]
    },
    "geo" : { },
    "id_str" : "486874553285492736",
    "text" : "Mark Hancock: An Atlas of #ELT in development here! http:\/\/t.co\/EpFdD3k3aY",
    "id" : 486874553285492736,
    "created_at" : "2014-07-09 14:08:33 +0000",
    "user" : {
      "name" : "Hancock McDonald ELT",
      "screen_name" : "HancockMcDonald",
      "protected" : false,
      "id_str" : "552929354",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2158919436\/HM_portrait_normal.jpg",
      "id" : 552929354,
      "verified" : false
    }
  },
  "id" : 486876299877961728,
  "created_at" : "2014-07-09 14:15:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "videogrep",
      "indices" : [ 18, 28 ]
    }, {
      "text" : "language",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/pyuyWbVrI1",
      "expanded_url" : "https:\/\/plus.google.com\/+MuraNava\/posts\/KgXFoQneWWT",
      "display_url" : "plus.google.com\/+MuraNava\/post\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "486855812540018688",
  "text" : "quick examples of #videogrep tool for #language learning https:\/\/t.co\/pyuyWbVrI1",
  "id" : 486855812540018688,
  "created_at" : "2014-07-09 12:54:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    }, {
      "name" : "Jon Snow",
      "screen_name" : "jonsnowC4",
      "indices" : [ 112, 122 ],
      "id_str" : "128216887",
      "id" : 128216887
    }, {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 123, 133 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/8tDIeojZPH",
      "expanded_url" : "http:\/\/johnhilley.blogspot.co.uk\/2014\/07\/jon-snows-standard-but-not-very.html",
      "display_url" : "johnhilley.blogspot.co.uk\/2014\/07\/jon-sn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "486802030267482112",
  "text" : "RT @johnwhilley: Jon Snow's standard, but not very constructive, dismissal of Media Lens http:\/\/t.co\/8tDIeojZPH @jonsnowC4 @medialens",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jon Snow",
        "screen_name" : "jonsnowC4",
        "indices" : [ 95, 105 ],
        "id_str" : "128216887",
        "id" : 128216887
      }, {
        "name" : "Media Lens",
        "screen_name" : "medialens",
        "indices" : [ 106, 116 ],
        "id_str" : "6531902",
        "id" : 6531902
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/8tDIeojZPH",
        "expanded_url" : "http:\/\/johnhilley.blogspot.co.uk\/2014\/07\/jon-snows-standard-but-not-very.html",
        "display_url" : "johnhilley.blogspot.co.uk\/2014\/07\/jon-sn\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "486538379090472961",
    "text" : "Jon Snow's standard, but not very constructive, dismissal of Media Lens http:\/\/t.co\/8tDIeojZPH @jonsnowC4 @medialens",
    "id" : 486538379090472961,
    "created_at" : "2014-07-08 15:52:43 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 486802030267482112,
  "created_at" : "2014-07-09 09:20:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul McMc",
      "screen_name" : "panthersolo",
      "indices" : [ 3, 15 ],
      "id_str" : "2640591",
      "id" : 2640591
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "worldcup",
      "indices" : [ 26, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "486801140382978048",
  "text" : "RT @panthersolo: If BBC's #worldcup coverage was like their Israel\/Palestine coverage, today's headline would be 'German goal suffers Brazi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "worldcup",
        "indices" : [ 9, 18 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "486791447338033152",
    "text" : "If BBC's #worldcup coverage was like their Israel\/Palestine coverage, today's headline would be 'German goal suffers Brazilian onslaught'.",
    "id" : 486791447338033152,
    "created_at" : "2014-07-09 08:38:19 +0000",
    "user" : {
      "name" : "Paul McMc",
      "screen_name" : "panthersolo",
      "protected" : false,
      "id_str" : "2640591",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/454422589583020033\/7GdZH150_normal.jpeg",
      "id" : 2640591,
      "verified" : false
    }
  },
  "id" : 486801140382978048,
  "created_at" : "2014-07-09 09:16:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "486606906631680000",
  "text" : "what's german for samba? :0",
  "id" : 486606906631680000,
  "created_at" : "2014-07-08 20:25:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kat Gupta",
      "screen_name" : "mixosaurus",
      "indices" : [ 0, 11 ],
      "id_str" : "21158543",
      "id" : 21158543
    }, {
      "name" : "Amy Aisha Brown",
      "screen_name" : "amyaishab",
      "indices" : [ 12, 22 ],
      "id_str" : "900029641",
      "id" : 900029641
    }, {
      "name" : "Dawn Knight",
      "screen_name" : "nottyknight",
      "indices" : [ 23, 35 ],
      "id_str" : "83570076",
      "id" : 83570076
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "486535616092708864",
  "geo" : { },
  "id_str" : "486556582705389569",
  "in_reply_to_user_id" : 21158543,
  "text" : "@mixosaurus @amyaishab @nottyknight have u considered using source files to identify spoken then either manually or automatically sep them?",
  "id" : 486556582705389569,
  "in_reply_to_status_id" : 486535616092708864,
  "created_at" : "2014-07-08 17:05:03 +0000",
  "in_reply_to_screen_name" : "mixosaurus",
  "in_reply_to_user_id_str" : "21158543",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marek Kiczkowiak",
      "screen_name" : "MarekKiczkowiak",
      "indices" : [ 0, 16 ],
      "id_str" : "2561325079",
      "id" : 2561325079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "486179418680098816",
  "geo" : { },
  "id_str" : "486536584612020226",
  "in_reply_to_user_id" : 2561325079,
  "text" : "@MarekKiczkowiak a very tactfully constructed question as well",
  "id" : 486536584612020226,
  "in_reply_to_status_id" : 486179418680098816,
  "created_at" : "2014-07-08 15:45:35 +0000",
  "in_reply_to_screen_name" : "MarekKiczkowiak",
  "in_reply_to_user_id_str" : "2561325079",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\" rel=\"nofollow\"\u003EEchofon  Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AKIRA THE DON",
      "screen_name" : "akirathedon",
      "indices" : [ 3, 15 ],
      "id_str" : "18225967",
      "id" : 18225967
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 125, 140 ],
      "url" : "http:\/\/t.co\/soKtPWLmTz",
      "expanded_url" : "http:\/\/akirathedon.com\/blog\/where-old-people-go\/",
      "display_url" : "akirathedon.com\/blog\/where-old\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "486267661622734848",
  "text" : "RT @akirathedon: I wrote a blog about helping some old people who fell down in the road the other day. \"Where Old People Go\" http:\/\/t.co\/so\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/soKtPWLmTz",
        "expanded_url" : "http:\/\/akirathedon.com\/blog\/where-old-people-go\/",
        "display_url" : "akirathedon.com\/blog\/where-old\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "486248847283597312",
    "text" : "I wrote a blog about helping some old people who fell down in the road the other day. \"Where Old People Go\" http:\/\/t.co\/soKtPWLmTz",
    "id" : 486248847283597312,
    "created_at" : "2014-07-07 20:42:13 +0000",
    "user" : {
      "name" : "AKIRA THE DON",
      "screen_name" : "akirathedon",
      "protected" : false,
      "id_str" : "18225967",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/760238647706722304\/DYwlt1DW_normal.jpg",
      "id" : 18225967,
      "verified" : true
    }
  },
  "id" : 486267661622734848,
  "created_at" : "2014-07-07 21:56:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\" rel=\"nofollow\"\u003EEchofon  Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Levine",
      "screen_name" : "cogdog",
      "indices" : [ 3, 10 ],
      "id_str" : "740343",
      "id" : 740343
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thoughtvectors",
      "indices" : [ 22, 37 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/p85WAGDcLf",
      "expanded_url" : "http:\/\/www.explainxkcd.com\/wiki\/index.php\/Main_Page",
      "display_url" : "explainxkcd.com\/wiki\/index.php\u2026"
    }, {
      "indices" : [ 121, 140 ],
      "url" : "http:\/\/t.co\/1yRFPrNGOA",
      "expanded_url" : "http:\/\/www.explainxkcd.com\/wiki\/index.php\/1390",
      "display_url" : "explainxkcd.com\/wiki\/index.php\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "485915401159974913",
  "text" : "RT @cogdog: Holy meta #thoughtvectors A wiki for explaining xkcd comics http:\/\/t.co\/p85WAGDcLf  e. recently on FB ethics http:\/\/t.co\/1yRFPr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "thoughtvectors",
        "indices" : [ 10, 25 ]
      } ],
      "urls" : [ {
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/p85WAGDcLf",
        "expanded_url" : "http:\/\/www.explainxkcd.com\/wiki\/index.php\/Main_Page",
        "display_url" : "explainxkcd.com\/wiki\/index.php\u2026"
      }, {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/1yRFPrNGOA",
        "expanded_url" : "http:\/\/www.explainxkcd.com\/wiki\/index.php\/1390",
        "display_url" : "explainxkcd.com\/wiki\/index.php\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "485863629195984896",
    "text" : "Holy meta #thoughtvectors A wiki for explaining xkcd comics http:\/\/t.co\/p85WAGDcLf  e. recently on FB ethics http:\/\/t.co\/1yRFPrNGOA",
    "id" : 485863629195984896,
    "created_at" : "2014-07-06 19:11:30 +0000",
    "user" : {
      "name" : "Alan Levine",
      "screen_name" : "cogdog",
      "protected" : false,
      "id_str" : "740343",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/740063389527859201\/BN9buLB9_normal.jpg",
      "id" : 740343,
      "verified" : false
    }
  },
  "id" : 485915401159974913,
  "created_at" : "2014-07-06 22:37:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\" rel=\"nofollow\"\u003EEchofon  Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Taylor",
      "screen_name" : "theteacherjames",
      "indices" : [ 0, 16 ],
      "id_str" : "71746265",
      "id" : 71746265
    }, {
      "name" : "Marek Kiczkowiak",
      "screen_name" : "MarekKiczkowiak",
      "indices" : [ 17, 33 ],
      "id_str" : "2561325079",
      "id" : 2561325079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "485873837851299840",
  "geo" : { },
  "id_str" : "485909596897542144",
  "in_reply_to_user_id" : 71746265,
  "text" : "@theteacherjames @MarekKiczkowiak response to Q6 was a marvelous sidestep :0",
  "id" : 485909596897542144,
  "in_reply_to_status_id" : 485873837851299840,
  "created_at" : "2014-07-06 22:14:10 +0000",
  "in_reply_to_screen_name" : "theteacherjames",
  "in_reply_to_user_id_str" : "71746265",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\" rel=\"nofollow\"\u003EEchofon  Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Moravec",
      "screen_name" : "ProfessMoravec",
      "indices" : [ 3, 18 ],
      "id_str" : "369529173",
      "id" : 369529173
    }, {
      "name" : "Kat Gupta",
      "screen_name" : "mixosaurus",
      "indices" : [ 26, 37 ],
      "id_str" : "21158543",
      "id" : 21158543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/bUfVWE3fYp",
      "expanded_url" : "http:\/\/mixosaurus.co.uk\/2014\/07\/elliot-rodger-corpus-linguistics\/",
      "display_url" : "mixosaurus.co.uk\/2014\/07\/elliot\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "485436390801694720",
  "text" : "RT @ProfessMoravec: \u221A out @mixosaurus FAB To \u201Cwage a war against all women\u201D: Elliot Rodger, girls, women and corpus linguistics http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kat Gupta",
        "screen_name" : "mixosaurus",
        "indices" : [ 6, 17 ],
        "id_str" : "21158543",
        "id" : 21158543
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/bUfVWE3fYp",
        "expanded_url" : "http:\/\/mixosaurus.co.uk\/2014\/07\/elliot-rodger-corpus-linguistics\/",
        "display_url" : "mixosaurus.co.uk\/2014\/07\/elliot\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "485383373192720384",
    "text" : "\u221A out @mixosaurus FAB To \u201Cwage a war against all women\u201D: Elliot Rodger, girls, women and corpus linguistics http:\/\/t.co\/bUfVWE3fYp",
    "id" : 485383373192720384,
    "created_at" : "2014-07-05 11:23:08 +0000",
    "user" : {
      "name" : "Michelle Moravec",
      "screen_name" : "ProfessMoravec",
      "protected" : false,
      "id_str" : "369529173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751214483113013248\/qxxQX7mg_normal.jpg",
      "id" : 369529173,
      "verified" : false
    }
  },
  "id" : 485436390801694720,
  "created_at" : "2014-07-05 14:53:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\" rel=\"nofollow\"\u003EEchofon  Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "indices" : [ 3, 12 ],
      "id_str" : "167020390",
      "id" : 167020390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/be1nrfGM1S",
      "expanded_url" : "http:\/\/www.antlab.sci.waseda.ac.jp\/software.html",
      "display_url" : "antlab.sci.waseda.ac.jp\/software.html"
    } ]
  },
  "geo" : { },
  "id_str" : "485148793332305921",
  "text" : "RT @antlabjp: My freeware TagAnt POS tagger is now available for Macintosh OS X (all versions) as well as Windows. Get it here: http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/be1nrfGM1S",
        "expanded_url" : "http:\/\/www.antlab.sci.waseda.ac.jp\/software.html",
        "display_url" : "antlab.sci.waseda.ac.jp\/software.html"
      } ]
    },
    "geo" : { },
    "id_str" : "485147920782856192",
    "text" : "My freeware TagAnt POS tagger is now available for Macintosh OS X (all versions) as well as Windows. Get it here: http:\/\/t.co\/be1nrfGM1S",
    "id" : 485147920782856192,
    "created_at" : "2014-07-04 19:47:32 +0000",
    "user" : {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "protected" : false,
      "id_str" : "167020390",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/428183580821315584\/ocgCI7Er_normal.jpeg",
      "id" : 167020390,
      "verified" : false
    }
  },
  "id" : 485148793332305921,
  "created_at" : "2014-07-04 19:51:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\" rel=\"nofollow\"\u003EEchofon  Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "indices" : [ 3, 18 ],
      "id_str" : "27716419",
      "id" : 27716419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/XT3W2Q9NsB",
      "expanded_url" : "http:\/\/bit.ly\/1vEJPVH",
      "display_url" : "bit.ly\/1vEJPVH"
    } ]
  },
  "geo" : { },
  "id_str" : "485050798314123264",
  "text" : "RT @CraigMurrayOrg: People or War?: We could have built 120,000 new homes, desperately needed. Instead we spent the money on a blo... http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/XT3W2Q9NsB",
        "expanded_url" : "http:\/\/bit.ly\/1vEJPVH",
        "display_url" : "bit.ly\/1vEJPVH"
      } ]
    },
    "geo" : { },
    "id_str" : "484991894301077504",
    "text" : "People or War?: We could have built 120,000 new homes, desperately needed. Instead we spent the money on a blo... http:\/\/t.co\/XT3W2Q9NsB",
    "id" : 484991894301077504,
    "created_at" : "2014-07-04 09:27:32 +0000",
    "user" : {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "protected" : false,
      "id_str" : "27716419",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1388436826\/cm_normal.jpg",
      "id" : 27716419,
      "verified" : false
    }
  },
  "id" : 485050798314123264,
  "created_at" : "2014-07-04 13:21:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Rei",
      "screen_name" : "Charlesrei1",
      "indices" : [ 0, 12 ],
      "id_str" : "464454382",
      "id" : 464454382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/fNobTW8aQc",
      "expanded_url" : "https:\/\/plus.google.com\/u\/0\/communities\/101266284417587206243\/members",
      "display_url" : "plus.google.com\/u\/0\/communitie\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "484564312468766721",
  "geo" : { },
  "id_str" : "484601915578527744",
  "in_reply_to_user_id" : 464454382,
  "text" : "@Charlesrei1 hi you may be interested in checking out G+ CL community https:\/\/t.co\/fNobTW8aQc",
  "id" : 484601915578527744,
  "in_reply_to_status_id" : 484564312468766721,
  "created_at" : "2014-07-03 07:37:54 +0000",
  "in_reply_to_screen_name" : "Charlesrei1",
  "in_reply_to_user_id_str" : "464454382",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Rei",
      "screen_name" : "Charlesrei1",
      "indices" : [ 3, 15 ],
      "id_str" : "464454382",
      "id" : 464454382
    }, {
      "name" : "Olya Sergeeva",
      "screen_name" : "olyaelt",
      "indices" : [ 41, 49 ],
      "id_str" : "2176726134",
      "id" : 2176726134
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "besig",
      "indices" : [ 91, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/nqxKhYkAA4",
      "expanded_url" : "http:\/\/eltgeek.wordpress.com\/2014\/06\/12\/mining-professional-forums-to-supplement-a-business-english-course-some-examples-for-it\/",
      "display_url" : "eltgeek.wordpress.com\/2014\/06\/12\/min\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "484601432642158592",
  "text" : "RT @Charlesrei1: Some nice insights from @olyaelt's corpus analysis of IT chatter.  Great!\n#besig http:\/\/t.co\/nqxKhYkAA4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Olya Sergeeva",
        "screen_name" : "olyaelt",
        "indices" : [ 24, 32 ],
        "id_str" : "2176726134",
        "id" : 2176726134
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "besig",
        "indices" : [ 74, 80 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/nqxKhYkAA4",
        "expanded_url" : "http:\/\/eltgeek.wordpress.com\/2014\/06\/12\/mining-professional-forums-to-supplement-a-business-english-course-some-examples-for-it\/",
        "display_url" : "eltgeek.wordpress.com\/2014\/06\/12\/min\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "484564312468766721",
    "text" : "Some nice insights from @olyaelt's corpus analysis of IT chatter.  Great!\n#besig http:\/\/t.co\/nqxKhYkAA4",
    "id" : 484564312468766721,
    "created_at" : "2014-07-03 05:08:29 +0000",
    "user" : {
      "name" : "Charles Rei",
      "screen_name" : "Charlesrei1",
      "protected" : false,
      "id_str" : "464454382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461561508057468928\/BA8otRW0_normal.jpeg",
      "id" : 464454382,
      "verified" : false
    }
  },
  "id" : 484601432642158592,
  "created_at" : "2014-07-03 07:35:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George Wilson",
      "screen_name" : "GDW82",
      "indices" : [ 0, 6 ],
      "id_str" : "1531690604",
      "id" : 1531690604
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "484583404802166784",
  "geo" : { },
  "id_str" : "484600569576030208",
  "in_reply_to_user_id" : 1531690604,
  "text" : "@GDW82 fascinating! will u be blogging it?",
  "id" : 484600569576030208,
  "in_reply_to_status_id" : 484583404802166784,
  "created_at" : "2014-07-03 07:32:33 +0000",
  "in_reply_to_screen_name" : "GDW82",
  "in_reply_to_user_id_str" : "1531690604",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Transcendance",
      "indices" : [ 0, 14 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "484461933727588352",
  "text" : "#Transcendance film shows need to invent strong AI to make halfway decent cinema :\/",
  "id" : 484461933727588352,
  "created_at" : "2014-07-02 22:21:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "484444209517453312",
  "text" : "Dragons,\u201D she whispered. \u201CRemember our first microcredit program in prisons as well. Can you imagine such displacement, such loss?",
  "id" : 484444209517453312,
  "created_at" : "2014-07-02 21:11:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "484433251051008000",
  "text" : "he's almost seven billion individuals. And so, when I fell in love and work. And I had to find out the rules of this uncertainty",
  "id" : 484433251051008000,
  "created_at" : "2014-07-02 20:27:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "484431186451001344",
  "text" : "Grieve for your tribe. Only 10 percent faster on the other way. These are really simple, classic bait and switch",
  "id" : 484431186451001344,
  "created_at" : "2014-07-02 20:19:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Graham",
      "screen_name" : "onalifeglug",
      "indices" : [ 0, 12 ],
      "id_str" : "19516039",
      "id" : 19516039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "484420445496946688",
  "geo" : { },
  "id_str" : "484422425606897664",
  "in_reply_to_user_id" : 19516039,
  "text" : "@onalifeglug reminds of that joke what do u call a muso with no girlfriend? homeless",
  "id" : 484422425606897664,
  "in_reply_to_status_id" : 484420445496946688,
  "created_at" : "2014-07-02 19:44:41 +0000",
  "in_reply_to_screen_name" : "onalifeglug",
  "in_reply_to_user_id_str" : "19516039",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "World Cup Ball",
      "screen_name" : "IAmTheFIFABall",
      "indices" : [ 3, 18 ],
      "id_str" : "2553523830",
      "id" : 2553523830
    }, {
      "name" : "4TUNE Teller App",
      "screen_name" : "4tunetellernet",
      "indices" : [ 102, 117 ],
      "id_str" : "467634146",
      "id" : 467634146
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "interviews",
      "indices" : [ 34, 45 ]
    }, {
      "text" : "WorldCup",
      "indices" : [ 143, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 131, 144 ],
      "url" : "http:\/\/t.co\/csKdrlDP5y",
      "expanded_url" : "http:\/\/www.4tuneteller.net\/social-favs\/interviews\/iamthefifaball-interview\/",
      "display_url" : "4tuneteller.net\/social-favs\/in\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "484408716327153664",
  "text" : "RT @IAmTheFIFABall: Don't do many #interviews bcause no1 asks me &amp; I'm not gr8. But I scored 1 at @4tunetellernet take a look. http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "4TUNE Teller App",
        "screen_name" : "4tunetellernet",
        "indices" : [ 82, 97 ],
        "id_str" : "467634146",
        "id" : 467634146
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "interviews",
        "indices" : [ 14, 25 ]
      }, {
        "text" : "WorldCup",
        "indices" : [ 134, 143 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/csKdrlDP5y",
        "expanded_url" : "http:\/\/www.4tuneteller.net\/social-favs\/interviews\/iamthefifaball-interview\/",
        "display_url" : "4tuneteller.net\/social-favs\/in\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "484407179945189376",
    "text" : "Don't do many #interviews bcause no1 asks me &amp; I'm not gr8. But I scored 1 at @4tunetellernet take a look. http:\/\/t.co\/csKdrlDP5y #WorldCup",
    "id" : 484407179945189376,
    "created_at" : "2014-07-02 18:44:06 +0000",
    "user" : {
      "name" : "World Cup Ball",
      "screen_name" : "IAmTheFIFABall",
      "protected" : false,
      "id_str" : "2553523830",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/485062004348944385\/PbPYruqX_normal.jpeg",
      "id" : 2553523830,
      "verified" : false
    }
  },
  "id" : 484408716327153664,
  "created_at" : "2014-07-02 18:50:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 127, 140 ],
      "url" : "http:\/\/t.co\/ub8hN5NLjE",
      "expanded_url" : "http:\/\/ow.ly\/yHpIR",
      "display_url" : "ow.ly\/yHpIR"
    } ]
  },
  "geo" : { },
  "id_str" : "484365766532542464",
  "text" : "RT @medialens: Our latest alert: Some Deaths Really Matter - The Disproportionate Coverage of Israeli And Palestinian Killings http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/ub8hN5NLjE",
        "expanded_url" : "http:\/\/ow.ly\/yHpIR",
        "display_url" : "ow.ly\/yHpIR"
      } ]
    },
    "geo" : { },
    "id_str" : "484345341333213184",
    "text" : "Our latest alert: Some Deaths Really Matter - The Disproportionate Coverage of Israeli And Palestinian Killings http:\/\/t.co\/ub8hN5NLjE",
    "id" : 484345341333213184,
    "created_at" : "2014-07-02 14:38:22 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 484365766532542464,
  "created_at" : "2014-07-02 15:59:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "484326145845121024",
  "text" : "Facebook for the environment. People are inspired by the arms.Haggo shattered his right arm below his head and is circulated,",
  "id" : 484326145845121024,
  "created_at" : "2014-07-02 13:22:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/5xgbKIn9Gi",
      "expanded_url" : "http:\/\/librestats.com\/2014\/07\/01\/modern-applied-statistics-in-rlyeh\/",
      "display_url" : "librestats.com\/2014\/07\/01\/mod\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "484272717819289601",
  "text" : "last tweets from playing with mashing texts in R i'll stop for  now! http:\/\/t.co\/5xgbKIn9Gi",
  "id" : 484272717819289601,
  "created_at" : "2014-07-02 09:49:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "484272208773390336",
  "text" : "passing strange. \u201CSer Jorah, take this job in Hamburg, at an Enigma machine from the weak. Let him see it in the subway and reading",
  "id" : 484272208773390336,
  "created_at" : "2014-07-02 09:47:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "484272070868885504",
  "text" : "departments. East Europe, we can apply to cereals, that we can learn the kings and cowherds alike. I cannot answer the phone all day,",
  "id" : 484272070868885504,
  "created_at" : "2014-07-02 09:47:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "484271805730140160",
  "text" : "Conventional farmers use this picture there's cameras, there's pressure among the creed of Shaker-dom is that no woman is conning the man",
  "id" : 484271805730140160,
  "created_at" : "2014-07-02 09:46:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "484267402247798784",
  "text" : "about Dudley's promised yesterday, they've had a lot like Uncle Benjen. In the dream, and he sat the Iron Throne. \u201CKill all of them were",
  "id" : 484267402247798784,
  "created_at" : "2014-07-02 09:28:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "484267040396812288",
  "text" : "from Gryffindor! Yes, Weasley, called them all with hair as they looked into the sellsword\u2019s face. Almost, almost, Bronn lost his footing",
  "id" : 484267040396812288,
  "created_at" : "2014-07-02 09:27:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "484266179897606144",
  "text" : "maybe he'd wake Dudley up, just to ride with them.Gods, I was never alone. Khal Drogo spoke a few",
  "id" : 484266179897606144,
  "created_at" : "2014-07-02 09:23:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "484244601671540736",
  "geo" : { },
  "id_str" : "484246197184757760",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco happy birthday! Nice gift :)",
  "id" : 484246197184757760,
  "in_reply_to_status_id" : 484244601671540736,
  "created_at" : "2014-07-02 08:04:24 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corporate Watch",
      "screen_name" : "CorpWatchUK",
      "indices" : [ 58, 70 ],
      "id_str" : "124136234",
      "id" : 124136234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/fWGB3pX3FT",
      "expanded_url" : "http:\/\/www.corporatewatch.org\/news\/2014\/jul\/01\/ecostream-campaign-victorious",
      "display_url" : "corporatewatch.org\/news\/2014\/jul\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "484103341245358080",
  "text" : "Ecostream campaign victorious  http:\/\/t.co\/fWGB3pX3FT via @CorpWatchUK",
  "id" : 484103341245358080,
  "created_at" : "2014-07-01 22:36:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Betty Carlson",
      "screen_name" : "bcinfrance",
      "indices" : [ 0, 11 ],
      "id_str" : "15668651",
      "id" : 15668651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/7dIRLpKGwE",
      "expanded_url" : "http:\/\/lag10.net\/extra4",
      "display_url" : "lag10.net\/extra4"
    } ]
  },
  "in_reply_to_status_id_str" : "484075650052284417",
  "geo" : { },
  "id_str" : "484076842354507776",
  "in_reply_to_user_id" : 15668651,
  "text" : "@bcinfrance stream here http:\/\/t.co\/7dIRLpKGwE warning nsfw ads!",
  "id" : 484076842354507776,
  "in_reply_to_status_id" : 484075650052284417,
  "created_at" : "2014-07-01 20:51:27 +0000",
  "in_reply_to_screen_name" : "bcinfrance",
  "in_reply_to_user_id_str" : "15668651",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WNYC",
      "screen_name" : "WNYC",
      "indices" : [ 68, 73 ],
      "id_str" : "6576492",
      "id" : 6576492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/uTGmjylapW",
      "expanded_url" : "http:\/\/wnyc.org\/2Cen0",
      "display_url" : "wnyc.org\/2Cen0"
    } ]
  },
  "geo" : { },
  "id_str" : "484060780715732993",
  "text" : "Discussing F\u00FAtbol, and Slurs, in Spanish http:\/\/t.co\/uTGmjylapW via @WNYC",
  "id" : 484060780715732993,
  "created_at" : "2014-07-01 19:47:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "textivate",
      "screen_name" : "textivate",
      "indices" : [ 3, 13 ],
      "id_str" : "757151820",
      "id" : 757151820
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "langchat",
      "indices" : [ 117, 126 ]
    }, {
      "text" : "flteach",
      "indices" : [ 127, 135 ]
    }, {
      "text" : "mfltwitterati",
      "indices" : [ 136, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/gf9RsvirMv",
      "expanded_url" : "http:\/\/www.textivate.com\/frames.php?ext=djjjn1&res=sequence-djjjn1",
      "display_url" : "textivate.com\/frames.php?ext\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "484060105668038656",
  "text" : "RT @textivate: A homework sequence with parallel text!!: http:\/\/t.co\/gf9RsvirMv \n(Close the log-in box to have a go)\n#langchat #flteach #mf\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "langchat",
        "indices" : [ 102, 111 ]
      }, {
        "text" : "flteach",
        "indices" : [ 112, 120 ]
      }, {
        "text" : "mfltwitterati",
        "indices" : [ 121, 135 ]
      } ],
      "urls" : [ {
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/gf9RsvirMv",
        "expanded_url" : "http:\/\/www.textivate.com\/frames.php?ext=djjjn1&res=sequence-djjjn1",
        "display_url" : "textivate.com\/frames.php?ext\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "484038883156697088",
    "text" : "A homework sequence with parallel text!!: http:\/\/t.co\/gf9RsvirMv \n(Close the log-in box to have a go)\n#langchat #flteach #mfltwitterati",
    "id" : 484038883156697088,
    "created_at" : "2014-07-01 18:20:37 +0000",
    "user" : {
      "name" : "textivate",
      "screen_name" : "textivate",
      "protected" : false,
      "id_str" : "757151820",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616568320066764800\/rx5tLnzg_normal.png",
      "id" : 757151820,
      "verified" : false
    }
  },
  "id" : 484060105668038656,
  "created_at" : "2014-07-01 19:44:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annie Murphy Paul",
      "screen_name" : "anniemurphypaul",
      "indices" : [ 68, 84 ],
      "id_str" : "105810697",
      "id" : 105810697
    }, {
      "name" : "Slate",
      "screen_name" : "Slate",
      "indices" : [ 113, 119 ],
      "id_str" : "15164565",
      "id" : 15164565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/IZ8LG7wdDQ",
      "expanded_url" : "http:\/\/www.slate.com\/articles\/technology\/future_tense\/2014\/06\/neuman_celano_library_study_educational_technology_worsens_achievement_gaps.html",
      "display_url" : "slate.com\/articles\/techn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "484051071145213952",
  "text" : "Educational technology is making achievement gaps even bigger, says @anniemurphypaul. http:\/\/t.co\/IZ8LG7wdDQ via @slate",
  "id" : 484051071145213952,
  "created_at" : "2014-07-01 19:09:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "phil wade",
      "screen_name" : "phil3wade",
      "indices" : [ 3, 13 ],
      "id_str" : "248864761",
      "id" : 248864761
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELT",
      "indices" : [ 28, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "484048570220544000",
  "text" : "RT @phil3wade: Crowdsourced #ELT ebook project. Who is interested? U just need to write 1 page.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for  Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELT",
        "indices" : [ 13, 17 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "484037972065787905",
    "text" : "Crowdsourced #ELT ebook project. Who is interested? U just need to write 1 page.",
    "id" : 484037972065787905,
    "created_at" : "2014-07-01 18:17:00 +0000",
    "user" : {
      "name" : "phil wade",
      "screen_name" : "phil3wade",
      "protected" : false,
      "id_str" : "248864761",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/479671416564879360\/2K84fAum_normal.png",
      "id" : 248864761,
      "verified" : false
    }
  },
  "id" : 484048570220544000,
  "created_at" : "2014-07-01 18:59:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    }, {
      "name" : "Laura Adele Soracco",
      "screen_name" : "LauraSoracco",
      "indices" : [ 85, 98 ],
      "id_str" : "15663328",
      "id" : 15663328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "483934858977107968",
  "geo" : { },
  "id_str" : "483981019293683712",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin sure, yet to fill it in meself will do though, u collaborating with @LauraSoracco ?",
  "id" : 483981019293683712,
  "in_reply_to_status_id" : 483934858977107968,
  "created_at" : "2014-07-01 14:30:41 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 78, 94 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/EjH8RpEZ8P",
      "expanded_url" : "http:\/\/wp.me\/p3augf-es",
      "display_url" : "wp.me\/p3augf-es"
    } ]
  },
  "geo" : { },
  "id_str" : "483922148407255040",
  "text" : "Publishing in English as an academic lingua franca http:\/\/t.co\/EjH8RpEZ8P via @wordpressdotcom",
  "id" : 483922148407255040,
  "created_at" : "2014-07-01 10:36:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 3, 19 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 127, 140 ],
      "url" : "http:\/\/t.co\/3AXzYxfqMB",
      "expanded_url" : "http:\/\/tinyurl.com\/NSElTsurvey",
      "display_url" : "tinyurl.com\/NSElTsurvey"
    } ]
  },
  "geo" : { },
  "id_str" : "483921923001561088",
  "text" : "RT @michaelegriffin: I'd really appreciate it if ELTs could take a few minutes to take this survey on your use of the internet\nhttp:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/3AXzYxfqMB",
        "expanded_url" : "http:\/\/tinyurl.com\/NSElTsurvey",
        "display_url" : "tinyurl.com\/NSElTsurvey"
      } ]
    },
    "geo" : { },
    "id_str" : "483837003062968320",
    "text" : "I'd really appreciate it if ELTs could take a few minutes to take this survey on your use of the internet\nhttp:\/\/t.co\/3AXzYxfqMB",
    "id" : 483837003062968320,
    "created_at" : "2014-07-01 04:58:25 +0000",
    "user" : {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "protected" : false,
      "id_str" : "394053348",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766911330645315584\/il5gKyOJ_normal.jpg",
      "id" : 394053348,
      "verified" : false
    }
  },
  "id" : 483921923001561088,
  "created_at" : "2014-07-01 10:35:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
} ]