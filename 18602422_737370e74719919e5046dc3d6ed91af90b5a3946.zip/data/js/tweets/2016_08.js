Grailbird.data.tweets_2016_08 = 
[ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Smearspotting",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 140 ],
      "url" : "https:\/\/t.co\/o51e8k5xZE",
      "expanded_url" : "http:\/\/www.thecanary.co\/2016\/08\/24\/theres-crucial-detail-missing-medias-reporting-traingate-video\/",
      "display_url" : "thecanary.co\/2016\/08\/24\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "768494142364188672",
  "text" : "RT @johnwhilley: Reclaiming the railways and protecting the NHS. Fear of losing corporate riches behind Branson attack https:\/\/t.co\/o51e8k5\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Smearspotting",
        "indices" : [ 126, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/o51e8k5xZE",
        "expanded_url" : "http:\/\/www.thecanary.co\/2016\/08\/24\/theres-crucial-detail-missing-medias-reporting-traingate-video\/",
        "display_url" : "thecanary.co\/2016\/08\/24\/the\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "768492781765558272",
    "text" : "Reclaiming the railways and protecting the NHS. Fear of losing corporate riches behind Branson attack https:\/\/t.co\/o51e8k5xZE #Smearspotting",
    "id" : 768492781765558272,
    "created_at" : "2016-08-24 16:58:51 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 768494142364188672,
  "created_at" : "2016-08-24 17:04:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Parise",
      "screen_name" : "peterrenshu",
      "indices" : [ 0, 12 ],
      "id_str" : "631949549",
      "id" : 631949549
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "768400823084802048",
  "geo" : { },
  "id_str" : "768403200344981504",
  "in_reply_to_user_id" : 631949549,
  "text" : "@peterrenshu what is the tinkering?",
  "id" : 768403200344981504,
  "in_reply_to_status_id" : 768400823084802048,
  "created_at" : "2016-08-24 11:02:53 +0000",
  "in_reply_to_screen_name" : "peterrenshu",
  "in_reply_to_user_id_str" : "631949549",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "indices" : [ 0, 10 ],
      "id_str" : "577931950",
      "id" : 577931950
    }, {
      "name" : "The Open Mic",
      "screen_name" : "OpenMicXL8",
      "indices" : [ 11, 22 ],
      "id_str" : "3407519914",
      "id" : 3407519914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "768393447166402560",
  "geo" : { },
  "id_str" : "768398766613422080",
  "in_reply_to_user_id" : 577931950,
  "text" : "@RudyLoock @OpenMicXL8 pds : )",
  "id" : 768398766613422080,
  "in_reply_to_status_id" : 768393447166402560,
  "created_at" : "2016-08-24 10:45:16 +0000",
  "in_reply_to_screen_name" : "RudyLoock",
  "in_reply_to_user_id_str" : "577931950",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/0K9SgifJvo",
      "expanded_url" : "http:\/\/johnpilger.com\/articles\/provoking-nuclear-war-by-media",
      "display_url" : "johnpilger.com\/articles\/provo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "768390467792801792",
  "text" : "Provoking nuclear war by media - https:\/\/t.co\/0K9SgifJvo",
  "id" : 768390467792801792,
  "created_at" : "2016-08-24 10:12:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Open Mic",
      "screen_name" : "OpenMicXL8",
      "indices" : [ 3, 14 ],
      "id_str" : "3407519914",
      "id" : 3407519914
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpenMicStory",
      "indices" : [ 20, 33 ]
    }, {
      "text" : "xl8",
      "indices" : [ 128, 132 ]
    }, {
      "text" : "t9n",
      "indices" : [ 133, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/nBdVuhqB3a",
      "expanded_url" : "http:\/\/zpr.io\/PPY8c",
      "display_url" : "zpr.io\/PPY8c"
    } ]
  },
  "geo" : { },
  "id_str" : "768383835012825089",
  "text" : "RT @OpenMicXL8: New #OpenMicStory Monolingual reference electronic corpora in the translator\u2019s toolbox  https:\/\/t.co\/nBdVuhqB3a #xl8 #t9n @",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/zapier.com\/\" rel=\"nofollow\"\u003EZapier.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OpenMicStory",
        "indices" : [ 4, 17 ]
      }, {
        "text" : "xl8",
        "indices" : [ 112, 116 ]
      }, {
        "text" : "t9n",
        "indices" : [ 117, 121 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/nBdVuhqB3a",
        "expanded_url" : "http:\/\/zpr.io\/PPY8c",
        "display_url" : "zpr.io\/PPY8c"
      } ]
    },
    "geo" : { },
    "id_str" : "768335044712816640",
    "text" : "New #OpenMicStory Monolingual reference electronic corpora in the translator\u2019s toolbox  https:\/\/t.co\/nBdVuhqB3a #xl8 #t9n @",
    "id" : 768335044712816640,
    "created_at" : "2016-08-24 06:32:04 +0000",
    "user" : {
      "name" : "The Open Mic",
      "screen_name" : "OpenMicXL8",
      "protected" : false,
      "id_str" : "3407519914",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629699809499156480\/GWGfmm2j_normal.png",
      "id" : 3407519914,
      "verified" : false
    }
  },
  "id" : 768383835012825089,
  "created_at" : "2016-08-24 09:45:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/sx2eDOm7j6",
      "expanded_url" : "https:\/\/wikileaks.org\/clinton-emails\/emailid\/12659",
      "display_url" : "wikileaks.org\/clinton-emails\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "768324927053262848",
  "text" : "FRANCE'S CLIENT &amp; QADDAFI'S GOLD https:\/\/t.co\/sx2eDOm7j6",
  "id" : 768324927053262848,
  "created_at" : "2016-08-24 05:51:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bruno Andrade",
      "screen_name" : "BrunoELT",
      "indices" : [ 3, 12 ],
      "id_str" : "39409915",
      "id" : 39409915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/7oHsJOkcYM",
      "expanded_url" : "http:\/\/bit.ly\/2bgTcI9",
      "display_url" : "bit.ly\/2bgTcI9"
    } ]
  },
  "geo" : { },
  "id_str" : "768320140349964288",
  "text" : "RT @BrunoELT: A Domain of One's Own in a Post-Ownership Society: Maha Bali has written a blog post asking why we talk about... https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/7oHsJOkcYM",
        "expanded_url" : "http:\/\/bit.ly\/2bgTcI9",
        "display_url" : "bit.ly\/2bgTcI9"
      } ]
    },
    "geo" : { },
    "id_str" : "768308321472294912",
    "text" : "A Domain of One's Own in a Post-Ownership Society: Maha Bali has written a blog post asking why we talk about... https:\/\/t.co\/7oHsJOkcYM",
    "id" : 768308321472294912,
    "created_at" : "2016-08-24 04:45:52 +0000",
    "user" : {
      "name" : "Bruno Andrade",
      "screen_name" : "BrunoELT",
      "protected" : false,
      "id_str" : "39409915",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1780205071\/image_normal.jpg",
      "id" : 39409915,
      "verified" : false
    }
  },
  "id" : 768320140349964288,
  "created_at" : "2016-08-24 05:32:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susanna Forrest",
      "screen_name" : "Susanna_Forrest",
      "indices" : [ 3, 19 ],
      "id_str" : "67535820",
      "id" : 67535820
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 125, 140 ],
      "url" : "https:\/\/t.co\/w2Dx1Xj80l",
      "expanded_url" : "https:\/\/twitter.com\/carolinedehaas\/status\/768194024914112512",
      "display_url" : "twitter.com\/carolinedehaas\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "768319464463007744",
  "text" : "RT @Susanna_Forrest: It really is men with guns telling a woman to take her clothes off or else. Nothing more, nothing less. https:\/\/t.co\/w\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/w2Dx1Xj80l",
        "expanded_url" : "https:\/\/twitter.com\/carolinedehaas\/status\/768194024914112512",
        "display_url" : "twitter.com\/carolinedehaas\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "768197056150241280",
    "text" : "It really is men with guns telling a woman to take her clothes off or else. Nothing more, nothing less. https:\/\/t.co\/w2Dx1Xj80l",
    "id" : 768197056150241280,
    "created_at" : "2016-08-23 21:23:45 +0000",
    "user" : {
      "name" : "Susanna Forrest",
      "screen_name" : "Susanna_Forrest",
      "protected" : false,
      "id_str" : "67535820",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/722472076955750400\/xOWKG1Jj_normal.jpg",
      "id" : 67535820,
      "verified" : false
    }
  },
  "id" : 768319464463007744,
  "created_at" : "2016-08-24 05:30:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 134, 142 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/gv7sJK82pv",
      "expanded_url" : "https:\/\/youtu.be\/itCKXWS8SEU",
      "display_url" : "youtu.be\/itCKXWS8SEU"
    } ]
  },
  "geo" : { },
  "id_str" : "768189262315589632",
  "text" : "Branston...a pickle with no place on my plate : ) Singers &amp; Players &amp; Prince Far I - Virgin  1982 https:\/\/t.co\/gv7sJK82pv via @YouTube",
  "id" : 768189262315589632,
  "created_at" : "2016-08-23 20:52:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CEPR",
      "screen_name" : "ceprdc",
      "indices" : [ 3, 10 ],
      "id_str" : "73416019",
      "id" : 73416019
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StopTPP",
      "indices" : [ 96, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/SRvqE2F4iJ",
      "expanded_url" : "http:\/\/ow.ly\/AsDE303tAjf",
      "display_url" : "ow.ly\/AsDE303tAjf"
    } ]
  },
  "geo" : { },
  "id_str" : "767820573166673924",
  "text" : "RT @ceprdc: Obama\u2019s New Campaign for the TPP Could Drag Down Democrats  https:\/\/t.co\/SRvqE2F4iJ #StopTPP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "StopTPP",
        "indices" : [ 84, 92 ]
      } ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/SRvqE2F4iJ",
        "expanded_url" : "http:\/\/ow.ly\/AsDE303tAjf",
        "display_url" : "ow.ly\/AsDE303tAjf"
      } ]
    },
    "geo" : { },
    "id_str" : "767796009233678336",
    "text" : "Obama\u2019s New Campaign for the TPP Could Drag Down Democrats  https:\/\/t.co\/SRvqE2F4iJ #StopTPP",
    "id" : 767796009233678336,
    "created_at" : "2016-08-22 18:50:08 +0000",
    "user" : {
      "name" : "CEPR",
      "screen_name" : "ceprdc",
      "protected" : false,
      "id_str" : "73416019",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/717712993035927552\/uY5SWl46_normal.jpg",
      "id" : 73416019,
      "verified" : false
    }
  },
  "id" : 767820573166673924,
  "created_at" : "2016-08-22 20:27:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Business English",
      "screen_name" : "BusinessEngM",
      "indices" : [ 0, 13 ],
      "id_str" : "2851211921",
      "id" : 2851211921
    }, {
      "name" : "Matt Purland",
      "screen_name" : "englishbanana",
      "indices" : [ 14, 28 ],
      "id_str" : "1065987680",
      "id" : 1065987680
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "767649748153143296",
  "geo" : { },
  "id_str" : "767814526943264768",
  "in_reply_to_user_id" : 2851211921,
  "text" : "@BusinessEngM @englishbanana Feature article headline a nice example of prevalent language to describe a woman in a top job :\/",
  "id" : 767814526943264768,
  "in_reply_to_status_id" : 767649748153143296,
  "created_at" : "2016-08-22 20:03:43 +0000",
  "in_reply_to_screen_name" : "BusinessEngM",
  "in_reply_to_user_id_str" : "2851211921",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/grsPDDscb2",
      "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2016\/08\/bow-down-and-be-counted.html",
      "display_url" : "thecurmudgeonly.blogspot.co.uk\/2016\/08\/bow-do\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "767813751613644802",
  "text" : "RT @pchallinor: New mudgeonry: Bow down and be counted https:\/\/t.co\/grsPDDscb2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 62 ],
        "url" : "https:\/\/t.co\/grsPDDscb2",
        "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2016\/08\/bow-down-and-be-counted.html",
        "display_url" : "thecurmudgeonly.blogspot.co.uk\/2016\/08\/bow-do\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "767812083060731905",
    "text" : "New mudgeonry: Bow down and be counted https:\/\/t.co\/grsPDDscb2",
    "id" : 767812083060731905,
    "created_at" : "2016-08-22 19:54:00 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 767813751613644802,
  "created_at" : "2016-08-22 20:00:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TESOL France",
      "screen_name" : "TESOLFrance",
      "indices" : [ 3, 15 ],
      "id_str" : "70341872",
      "id" : 70341872
    }, {
      "name" : "Express Publishing",
      "screen_name" : "ExpressELT",
      "indices" : [ 79, 90 ],
      "id_str" : "540117048",
      "id" : 540117048
    }, {
      "name" : "ETS Global",
      "screen_name" : "ETSGlobal",
      "indices" : [ 91, 101 ],
      "id_str" : "538105836",
      "id" : 538105836
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TFColloquium16",
      "indices" : [ 17, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/FWtjlhKrWq",
      "expanded_url" : "http:\/\/www.tesol-france.org\/en\/pages\/101\/colloquium-2016.html",
      "display_url" : "tesol-france.org\/en\/pages\/101\/c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "767300084954431488",
  "text" : "RT @TESOLFrance: #TFColloquium16 schedule https:\/\/t.co\/FWtjlhKrWq Sponsored by @ExpressELT @ETSGlobal",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Express Publishing",
        "screen_name" : "ExpressELT",
        "indices" : [ 62, 73 ],
        "id_str" : "540117048",
        "id" : 540117048
      }, {
        "name" : "ETS Global",
        "screen_name" : "ETSGlobal",
        "indices" : [ 74, 84 ],
        "id_str" : "538105836",
        "id" : 538105836
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TFColloquium16",
        "indices" : [ 0, 15 ]
      } ],
      "urls" : [ {
        "indices" : [ 25, 48 ],
        "url" : "https:\/\/t.co\/FWtjlhKrWq",
        "expanded_url" : "http:\/\/www.tesol-france.org\/en\/pages\/101\/colloquium-2016.html",
        "display_url" : "tesol-france.org\/en\/pages\/101\/c\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "767136944912474112",
    "text" : "#TFColloquium16 schedule https:\/\/t.co\/FWtjlhKrWq Sponsored by @ExpressELT @ETSGlobal",
    "id" : 767136944912474112,
    "created_at" : "2016-08-20 23:11:15 +0000",
    "user" : {
      "name" : "TESOL France",
      "screen_name" : "TESOLFrance",
      "protected" : false,
      "id_str" : "70341872",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1789787647\/TESOL_France_logo_normal.jpg",
      "id" : 70341872,
      "verified" : false
    }
  },
  "id" : 767300084954431488,
  "created_at" : "2016-08-21 09:59:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/YO6SiEIQZM",
      "expanded_url" : "http:\/\/www.theguardian.com\/politics\/2016\/aug\/19\/momentum-drops-pledge-to-non-violence-from-code-of-ethics",
      "display_url" : "theguardian.com\/politics\/2016\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "767015473645023240",
  "text" : "RT @pchallinor: Momentum adopts resolution to hunt down, kill and eat defenceless right-wingers https:\/\/t.co\/YO6SiEIQZM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/YO6SiEIQZM",
        "expanded_url" : "http:\/\/www.theguardian.com\/politics\/2016\/aug\/19\/momentum-drops-pledge-to-non-violence-from-code-of-ethics",
        "display_url" : "theguardian.com\/politics\/2016\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "766990528651026432",
    "text" : "Momentum adopts resolution to hunt down, kill and eat defenceless right-wingers https:\/\/t.co\/YO6SiEIQZM",
    "id" : 766990528651026432,
    "created_at" : "2016-08-20 13:29:26 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 767015473645023240,
  "created_at" : "2016-08-20 15:08:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "((wendymacnaughton))",
      "screen_name" : "wendymac",
      "indices" : [ 3, 12 ],
      "id_str" : "8412262",
      "id" : 8412262
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/wendymac\/status\/766395183688593408\/photo\/1",
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/m9rEc7ktbC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqLIVrNVUAA5IRS.jpg",
      "id_str" : "766395161307860992",
      "id" : 766395161307860992,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqLIVrNVUAA5IRS.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      } ],
      "display_url" : "pic.twitter.com\/m9rEc7ktbC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "766975676691976192",
  "text" : "RT @wendymac: USA: Design Thinking! Design Thinking!\nJAPAN: Yeah, we just call that Thinking. https:\/\/t.co\/m9rEc7ktbC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/wendymac\/status\/766395183688593408\/photo\/1",
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/m9rEc7ktbC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqLIVrNVUAA5IRS.jpg",
        "id_str" : "766395161307860992",
        "id" : 766395161307860992,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqLIVrNVUAA5IRS.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        } ],
        "display_url" : "pic.twitter.com\/m9rEc7ktbC"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "766395183688593408",
    "text" : "USA: Design Thinking! Design Thinking!\nJAPAN: Yeah, we just call that Thinking. https:\/\/t.co\/m9rEc7ktbC",
    "id" : 766395183688593408,
    "created_at" : "2016-08-18 22:03:45 +0000",
    "user" : {
      "name" : "((wendymacnaughton))",
      "screen_name" : "wendymac",
      "protected" : false,
      "id_str" : "8412262",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/742037318484123648\/QHJJoivT_normal.jpg",
      "id" : 8412262,
      "verified" : false
    }
  },
  "id" : 766975676691976192,
  "created_at" : "2016-08-20 12:30:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Canary",
      "screen_name" : "TheCanarySays",
      "indices" : [ 3, 17 ],
      "id_str" : "3314289248",
      "id" : 3314289248
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/KX3glYB6Q2",
      "expanded_url" : "http:\/\/www.thecanary.co\/2016\/08\/19\/corbyn-just-dropped-truth-bomb-warmongering-establishment-now-arms\/",
      "display_url" : "thecanary.co\/2016\/08\/19\/cor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "766734743761195010",
  "text" : "RT @TheCanarySays: Corbyn just dropped a truth bomb on the warmongering elite, and now it\u2019s up in arms [OPINION] https:\/\/t.co\/KX3glYB6Q2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/KX3glYB6Q2",
        "expanded_url" : "http:\/\/www.thecanary.co\/2016\/08\/19\/corbyn-just-dropped-truth-bomb-warmongering-establishment-now-arms\/",
        "display_url" : "thecanary.co\/2016\/08\/19\/cor\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "766681610489962496",
    "text" : "Corbyn just dropped a truth bomb on the warmongering elite, and now it\u2019s up in arms [OPINION] https:\/\/t.co\/KX3glYB6Q2",
    "id" : 766681610489962496,
    "created_at" : "2016-08-19 17:01:54 +0000",
    "user" : {
      "name" : "The Canary",
      "screen_name" : "TheCanarySays",
      "protected" : false,
      "id_str" : "3314289248",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637635681968357377\/_sGzfrLH_normal.png",
      "id" : 3314289248,
      "verified" : false
    }
  },
  "id" : 766734743761195010,
  "created_at" : "2016-08-19 20:33:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Francisco_Ceron",
      "screen_name" : "_FranciscoCeron",
      "indices" : [ 3, 19 ],
      "id_str" : "168500305",
      "id" : 168500305
    }, {
      "name" : "Richard Seymour",
      "screen_name" : "leninology",
      "indices" : [ 33, 44 ],
      "id_str" : "15557246",
      "id" : 15557246
    }, {
      "name" : "VICE UK",
      "screen_name" : "VICEUK",
      "indices" : [ 139, 140 ],
      "id_str" : "15995155",
      "id" : 15995155
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 123, 140 ],
      "url" : "https:\/\/t.co\/3mDGR9zOKg",
      "expanded_url" : "http:\/\/www.vice.com\/en_uk\/read\/richard-seymour-education-policy-inequalty",
      "display_url" : "vice.com\/en_uk\/read\/ric\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "766663705966829569",
  "text" : "RT @_FranciscoCeron: *Nice piece @leninology* How Treating Students As Customers Turns the Idea of Meritocracy into a Joke https:\/\/t.co\/3mD\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Richard Seymour",
        "screen_name" : "leninology",
        "indices" : [ 12, 23 ],
        "id_str" : "15557246",
        "id" : 15557246
      }, {
        "name" : "VICE UK",
        "screen_name" : "VICEUK",
        "indices" : [ 130, 137 ],
        "id_str" : "15995155",
        "id" : 15995155
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/3mDGR9zOKg",
        "expanded_url" : "http:\/\/www.vice.com\/en_uk\/read\/richard-seymour-education-policy-inequalty",
        "display_url" : "vice.com\/en_uk\/read\/ric\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "766649896648802304",
    "text" : "*Nice piece @leninology* How Treating Students As Customers Turns the Idea of Meritocracy into a Joke https:\/\/t.co\/3mDGR9zOKg via @viceuk",
    "id" : 766649896648802304,
    "created_at" : "2016-08-19 14:55:53 +0000",
    "user" : {
      "name" : "Francisco_Ceron",
      "screen_name" : "_FranciscoCeron",
      "protected" : false,
      "id_str" : "168500305",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/513703309098487808\/s0keVCNw_normal.jpeg",
      "id" : 168500305,
      "verified" : false
    }
  },
  "id" : 766663705966829569,
  "created_at" : "2016-08-19 15:50:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bella Caledonia",
      "screen_name" : "bellacaledonia",
      "indices" : [ 3, 18 ],
      "id_str" : "103554348",
      "id" : 103554348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/lze0ofKQBF",
      "expanded_url" : "https:\/\/medium.com\/mosquito-ridge\/the-sound-of-blairite-silence-aed2ef726c8a#.ouaemuxsh",
      "display_url" : "medium.com\/mosquito-ridge\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "766654203490144256",
  "text" : "RT @bellacaledonia: Owen Smith has become the willing dupe of the Labour right https:\/\/t.co\/lze0ofKQBF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 82 ],
        "url" : "https:\/\/t.co\/lze0ofKQBF",
        "expanded_url" : "https:\/\/medium.com\/mosquito-ridge\/the-sound-of-blairite-silence-aed2ef726c8a#.ouaemuxsh",
        "display_url" : "medium.com\/mosquito-ridge\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "766648129789788161",
    "text" : "Owen Smith has become the willing dupe of the Labour right https:\/\/t.co\/lze0ofKQBF",
    "id" : 766648129789788161,
    "created_at" : "2016-08-19 14:48:52 +0000",
    "user" : {
      "name" : "Bella Caledonia",
      "screen_name" : "bellacaledonia",
      "protected" : false,
      "id_str" : "103554348",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/732831340194897925\/WGVyJGiO_normal.jpg",
      "id" : 103554348,
      "verified" : false
    }
  },
  "id" : 766654203490144256,
  "created_at" : "2016-08-19 15:13:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Leedham",
      "screen_name" : "DiLeed",
      "indices" : [ 0, 7 ],
      "id_str" : "2335217159",
      "id" : 2335217159
    }, {
      "name" : "Patrick Andrews",
      "screen_name" : "patrickelt",
      "indices" : [ 8, 19 ],
      "id_str" : "2292503990",
      "id" : 2292503990
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "766391873397219328",
  "geo" : { },
  "id_str" : "766404816004194304",
  "in_reply_to_user_id" : 2335217159,
  "text" : "@DiLeed @patrickelt yes you\/we r not his audience; people being fined are also not his audience",
  "id" : 766404816004194304,
  "in_reply_to_status_id" : 766391873397219328,
  "created_at" : "2016-08-18 22:42:01 +0000",
  "in_reply_to_screen_name" : "DiLeed",
  "in_reply_to_user_id_str" : "2335217159",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Andrews",
      "screen_name" : "patrickelt",
      "indices" : [ 0, 11 ],
      "id_str" : "2292503990",
      "id" : 2292503990
    }, {
      "name" : "Diane Leedham",
      "screen_name" : "DiLeed",
      "indices" : [ 12, 19 ],
      "id_str" : "2335217159",
      "id" : 2335217159
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "766376007976771584",
  "geo" : { },
  "id_str" : "766386141683671040",
  "in_reply_to_user_id" : 2292503990,
  "text" : "@patrickelt @DiLeed little doubt you are the audience mayor is wanting to be credulous :\/",
  "id" : 766386141683671040,
  "in_reply_to_status_id" : 766376007976771584,
  "created_at" : "2016-08-18 21:27:49 +0000",
  "in_reply_to_screen_name" : "patrickelt",
  "in_reply_to_user_id_str" : "2292503990",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELT ADVOCACY Ireland",
      "screen_name" : "ELTAdvocacy",
      "indices" : [ 0, 12 ],
      "id_str" : "712775553821048832",
      "id" : 712775553821048832
    }, {
      "name" : "IATEFL Head Office",
      "screen_name" : "iatefl",
      "indices" : [ 70, 77 ],
      "id_str" : "85042286",
      "id" : 85042286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "766371230685532160",
  "geo" : { },
  "id_str" : "766376913904492544",
  "in_reply_to_user_id" : 712775553821048832,
  "text" : "@ELTAdvocacy a fair description from what little impression i have of @iatefl",
  "id" : 766376913904492544,
  "in_reply_to_status_id" : 766371230685532160,
  "created_at" : "2016-08-18 20:51:09 +0000",
  "in_reply_to_screen_name" : "ELTAdvocacy",
  "in_reply_to_user_id_str" : "712775553821048832",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John X Williams",
      "screen_name" : "lexicoj0hn",
      "indices" : [ 0, 11 ],
      "id_str" : "4008981801",
      "id" : 4008981801
    }, {
      "name" : "CELFS Pre-sessional",
      "screen_name" : "CELFS_ps",
      "indices" : [ 12, 21 ],
      "id_str" : "3994180756",
      "id" : 3994180756
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "766374804018589696",
  "geo" : { },
  "id_str" : "766376438933118976",
  "in_reply_to_user_id" : 4008981801,
  "text" : "@lexicoj0hn @CELFS_ps good call though in fairness the post is titled \"EAP instruction\"",
  "id" : 766376438933118976,
  "in_reply_to_status_id" : 766374804018589696,
  "created_at" : "2016-08-18 20:49:16 +0000",
  "in_reply_to_screen_name" : "lexicoj0hn",
  "in_reply_to_user_id_str" : "4008981801",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "umasslinguistics",
      "screen_name" : "umasslinguistic",
      "indices" : [ 0, 16 ],
      "id_str" : "149239362",
      "id" : 149239362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "766355324446056448",
  "geo" : { },
  "id_str" : "766364757796478976",
  "in_reply_to_user_id" : 149239362,
  "text" : "@umasslinguistic that Tom Wolfe article though informative in a gossipy sense was more of an irritating style imo",
  "id" : 766364757796478976,
  "in_reply_to_status_id" : 766355324446056448,
  "created_at" : "2016-08-18 20:02:51 +0000",
  "in_reply_to_screen_name" : "umasslinguistic",
  "in_reply_to_user_id_str" : "149239362",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELT ADVOCACY Ireland",
      "screen_name" : "ELTAdvocacy",
      "indices" : [ 3, 15 ],
      "id_str" : "712775553821048832",
      "id" : 712775553821048832
    }, {
      "name" : "ShareThis",
      "screen_name" : "ShareThis",
      "indices" : [ 116, 126 ],
      "id_str" : "14116807",
      "id" : 14116807
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELT",
      "indices" : [ 127, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/xWw71hKTV7",
      "expanded_url" : "https:\/\/shar.es\/1wmpGy",
      "display_url" : "shar.es\/1wmpGy"
    } ]
  },
  "geo" : { },
  "id_str" : "766344292604448769",
  "text" : "RT @ELTAdvocacy: TESOL International Association Co-Signs Letter Condemning FBI Program https:\/\/t.co\/xWw71hKTV7 via @sharethis #ELT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ShareThis",
        "screen_name" : "ShareThis",
        "indices" : [ 99, 109 ],
        "id_str" : "14116807",
        "id" : 14116807
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELT",
        "indices" : [ 110, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/xWw71hKTV7",
        "expanded_url" : "https:\/\/shar.es\/1wmpGy",
        "display_url" : "shar.es\/1wmpGy"
      } ]
    },
    "geo" : { },
    "id_str" : "766334981744492544",
    "text" : "TESOL International Association Co-Signs Letter Condemning FBI Program https:\/\/t.co\/xWw71hKTV7 via @sharethis #ELT",
    "id" : 766334981744492544,
    "created_at" : "2016-08-18 18:04:32 +0000",
    "user" : {
      "name" : "ELT ADVOCACY Ireland",
      "screen_name" : "ELTAdvocacy",
      "protected" : false,
      "id_str" : "712775553821048832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747525513472774144\/x_EPorOI_normal.jpg",
      "id" : 712775553821048832,
      "verified" : false
    }
  },
  "id" : 766344292604448769,
  "created_at" : "2016-08-18 18:41:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELT ADVOCACY Ireland",
      "screen_name" : "ELTAdvocacy",
      "indices" : [ 0, 12 ],
      "id_str" : "712775553821048832",
      "id" : 712775553821048832
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iatefl",
      "indices" : [ 36, 43 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "766334981744492544",
  "geo" : { },
  "id_str" : "766344204612141056",
  "in_reply_to_user_id" : 712775553821048832,
  "text" : "@ELTAdvocacy good on them wonder if #iatefl have done anything similar for the prevent nonsense?",
  "id" : 766344204612141056,
  "in_reply_to_status_id" : 766334981744492544,
  "created_at" : "2016-08-18 18:41:11 +0000",
  "in_reply_to_screen_name" : "ELTAdvocacy",
  "in_reply_to_user_id_str" : "712775553821048832",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "M.K",
      "screen_name" : "usage_based",
      "indices" : [ 3, 15 ],
      "id_str" : "1479290418",
      "id" : 1479290418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/hZUfHgDT21",
      "expanded_url" : "https:\/\/sites.google.com\/site\/wordstatix\/",
      "display_url" : "sites.google.com\/site\/wordstati\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "766294431670689792",
  "text" : "RT @usage_based: WordStatix: A free multiplatform software to create concordances.\nhttps:\/\/t.co\/hZUfHgDT21",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/hZUfHgDT21",
        "expanded_url" : "https:\/\/sites.google.com\/site\/wordstatix\/",
        "display_url" : "sites.google.com\/site\/wordstati\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "766289095022686208",
    "text" : "WordStatix: A free multiplatform software to create concordances.\nhttps:\/\/t.co\/hZUfHgDT21",
    "id" : 766289095022686208,
    "created_at" : "2016-08-18 15:02:11 +0000",
    "user" : {
      "name" : "M.K",
      "screen_name" : "usage_based",
      "protected" : false,
      "id_str" : "1479290418",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/663653015962845184\/KI-fL-mX_normal.jpg",
      "id" : 1479290418,
      "verified" : false
    }
  },
  "id" : 766294431670689792,
  "created_at" : "2016-08-18 15:23:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    }, {
      "name" : "Jonathan Cook",
      "screen_name" : "Jonathan_K_Cook",
      "indices" : [ 57, 73 ],
      "id_str" : "2459644405",
      "id" : 2459644405
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/gw57RJGFMM",
      "expanded_url" : "http:\/\/mondoweiss.net\/2016\/07\/colonialism-apartheid-palestinian\/",
      "display_url" : "mondoweiss.net\/2016\/07\/coloni\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "766283864285319172",
  "text" : "RT @johnwhilley: Important new writing by Ilan Pappe and @Jonathan_K_Cook on truth of Israel as settler colonial and apartheid state https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jonathan Cook",
        "screen_name" : "Jonathan_K_Cook",
        "indices" : [ 40, 56 ],
        "id_str" : "2459644405",
        "id" : 2459644405
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/gw57RJGFMM",
        "expanded_url" : "http:\/\/mondoweiss.net\/2016\/07\/colonialism-apartheid-palestinian\/",
        "display_url" : "mondoweiss.net\/2016\/07\/coloni\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "766281929251516416",
    "text" : "Important new writing by Ilan Pappe and @Jonathan_K_Cook on truth of Israel as settler colonial and apartheid state https:\/\/t.co\/gw57RJGFMM",
    "id" : 766281929251516416,
    "created_at" : "2016-08-18 14:33:43 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 766283864285319172,
  "created_at" : "2016-08-18 14:41:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Englishlulu",
      "screen_name" : "englishlulu",
      "indices" : [ 3, 15 ],
      "id_str" : "240364967",
      "id" : 240364967
    }, {
      "name" : "James Theobald",
      "screen_name" : "JamesTheo",
      "indices" : [ 85, 95 ],
      "id_str" : "87903271",
      "id" : 87903271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/tL7c5NuQor",
      "expanded_url" : "https:\/\/othmarstrombone.wordpress.com\/2015\/08\/13\/jt-airlines-were-a-great-way-to-fall\/",
      "display_url" : "othmarstrombone.wordpress.com\/2015\/08\/13\/jt-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "766279130577006592",
  "text" : "RT @englishlulu: JT Airlines - We're a Great Way to Fall https:\/\/t.co\/tL7c5NuQor via @JamesTheo &gt;&gt; response to nonsense celebrity exam fail\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "James Theobald",
        "screen_name" : "JamesTheo",
        "indices" : [ 68, 78 ],
        "id_str" : "87903271",
        "id" : 87903271
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 63 ],
        "url" : "https:\/\/t.co\/tL7c5NuQor",
        "expanded_url" : "https:\/\/othmarstrombone.wordpress.com\/2015\/08\/13\/jt-airlines-were-a-great-way-to-fall\/",
        "display_url" : "othmarstrombone.wordpress.com\/2015\/08\/13\/jt-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "766249604992135168",
    "text" : "JT Airlines - We're a Great Way to Fall https:\/\/t.co\/tL7c5NuQor via @JamesTheo &gt;&gt; response to nonsense celebrity exam failures",
    "id" : 766249604992135168,
    "created_at" : "2016-08-18 12:25:16 +0000",
    "user" : {
      "name" : "Englishlulu",
      "screen_name" : "englishlulu",
      "protected" : false,
      "id_str" : "240364967",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/701110199751483397\/AGgtgvHv_normal.png",
      "id" : 240364967,
      "verified" : false
    }
  },
  "id" : 766279130577006592,
  "created_at" : "2016-08-18 14:22:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "debateclassproblems",
      "indices" : [ 97, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 141 ],
      "url" : "https:\/\/t.co\/cVenBOya8x",
      "expanded_url" : "https:\/\/twitter.com\/sam_kriss\/status\/765912194164875264",
      "display_url" : "twitter.com\/sam_kriss\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "766277117256531968",
  "text" : "only in formal debate do you have to give stupid &amp; boring ideas a hearing they don't deserve #debateclassproblems https:\/\/t.co\/cVenBOya8x",
  "id" : 766277117256531968,
  "created_at" : "2016-08-18 14:14:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Guillaume Desagulier",
      "screen_name" : "gdlinguist",
      "indices" : [ 0, 11 ],
      "id_str" : "4901184795",
      "id" : 4901184795
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "766242592363311106",
  "geo" : { },
  "id_str" : "766245005505794048",
  "in_reply_to_user_id" : 4901184795,
  "text" : "@gdlinguist et merde encore trop pres des velos \uD83D\uDE0B",
  "id" : 766245005505794048,
  "in_reply_to_status_id" : 766242592363311106,
  "created_at" : "2016-08-18 12:07:00 +0000",
  "in_reply_to_screen_name" : "gdlinguist",
  "in_reply_to_user_id_str" : "4901184795",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/5wJatLORCZ",
      "expanded_url" : "http:\/\/curmudgucation.blogspot.com\/2016\/08\/the-ledger-lab-rat-america.html",
      "display_url" : "curmudgucation.blogspot.com\/2016\/08\/the-le\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "766044623080923137",
  "text" : "CURMUDGUCATION: The Ledger: Lab Rat America: https:\/\/t.co\/5wJatLORCZ",
  "id" : 766044623080923137,
  "created_at" : "2016-08-17 22:50:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Spyrou",
      "screen_name" : "chrisspyrou",
      "indices" : [ 0, 12 ],
      "id_str" : "112771169",
      "id" : 112771169
    }, {
      "name" : "Diane Leedham",
      "screen_name" : "DiLeed",
      "indices" : [ 13, 20 ],
      "id_str" : "2335217159",
      "id" : 2335217159
    }, {
      "name" : ".",
      "screen_name" : "St2155",
      "indices" : [ 21, 28 ],
      "id_str" : "363696964",
      "id" : 363696964
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "765936551142359040",
  "geo" : { },
  "id_str" : "766037281253752832",
  "in_reply_to_user_id" : 112771169,
  "text" : "@chrisspyrou @DiLeed @St2155 a simple (internet) story for simple (internet) people? \uD83D\uDE00",
  "id" : 766037281253752832,
  "in_reply_to_status_id" : 765936551142359040,
  "created_at" : "2016-08-17 22:21:34 +0000",
  "in_reply_to_screen_name" : "chrisspyrou",
  "in_reply_to_user_id_str" : "112771169",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/50j7Whya3W",
      "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2016\/08\/the-finger-of-dictatorship.html",
      "display_url" : "thecurmudgeonly.blogspot.co.uk\/2016\/08\/the-fi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "765990939504611329",
  "text" : "RT @pchallinor: New mudgeonry: The finger of dictatorship https:\/\/t.co\/50j7Whya3W",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 65 ],
        "url" : "https:\/\/t.co\/50j7Whya3W",
        "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2016\/08\/the-finger-of-dictatorship.html",
        "display_url" : "thecurmudgeonly.blogspot.co.uk\/2016\/08\/the-fi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "765986521526759424",
    "text" : "New mudgeonry: The finger of dictatorship https:\/\/t.co\/50j7Whya3W",
    "id" : 765986521526759424,
    "created_at" : "2016-08-17 18:59:52 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 765990939504611329,
  "created_at" : "2016-08-17 19:17:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 104, 120 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/vxy1JvIDyo",
      "expanded_url" : "https:\/\/scatter.wordpress.com\/2016\/08\/17\/did-bros-cause-the-financial-crisis-hegemonic-masculinity-in-the-big-short\/",
      "display_url" : "scatter.wordpress.com\/2016\/08\/17\/did\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "765939129318342656",
  "text" : "did bros cause the financial crisis? hegemonic masculinity in the big short https:\/\/t.co\/vxy1JvIDyo via @wordpressdotcom",
  "id" : 765939129318342656,
  "created_at" : "2016-08-17 15:51:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Watson",
      "screen_name" : "SteveWatson10",
      "indices" : [ 81, 95 ],
      "id_str" : "135269213",
      "id" : 135269213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/0bbfkRHSd3",
      "expanded_url" : "https:\/\/sw10014.wordpress.com\/2016\/08\/17\/a-national-education-service-is-exactly-what-we-need\/",
      "display_url" : "sw10014.wordpress.com\/2016\/08\/17\/a-n\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "765848308812251136",
  "text" : "A National Education Service is exactly what we need https:\/\/t.co\/0bbfkRHSd3 via @SteveWatson10",
  "id" : 765848308812251136,
  "created_at" : "2016-08-17 09:50:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sean.",
      "screen_name" : "SeanMcElwee",
      "indices" : [ 3, 15 ],
      "id_str" : "318692762",
      "id" : 318692762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/lRJsJ72z5c",
      "expanded_url" : "https:\/\/twitter.com\/nytimes\/status\/765229583595606016",
      "display_url" : "twitter.com\/nytimes\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "765672290960941056",
  "text" : "RT @SeanMcElwee: for every problem there is a solution that is complex, market-based and far worse than the government just doing it https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/lRJsJ72z5c",
        "expanded_url" : "https:\/\/twitter.com\/nytimes\/status\/765229583595606016",
        "display_url" : "twitter.com\/nytimes\/status\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "765403861959999488",
    "text" : "for every problem there is a solution that is complex, market-based and far worse than the government just doing it https:\/\/t.co\/lRJsJ72z5c",
    "id" : 765403861959999488,
    "created_at" : "2016-08-16 04:24:35 +0000",
    "user" : {
      "name" : "sean.",
      "screen_name" : "SeanMcElwee",
      "protected" : false,
      "id_str" : "318692762",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/697656193737748480\/Hc-WgXJw_normal.jpg",
      "id" : 318692762,
      "verified" : false
    }
  },
  "id" : 765672290960941056,
  "created_at" : "2016-08-16 22:11:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Kern\u24C4h\u24B6n",
      "screen_name" : "dkernohan",
      "indices" : [ 3, 13 ],
      "id_str" : "12219232",
      "id" : 12219232
    }, {
      "name" : "Jonathan Rees",
      "screen_name" : "jhrees",
      "indices" : [ 32, 39 ],
      "id_str" : "227708559",
      "id" : 227708559
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/2XC7abLgo1",
      "expanded_url" : "https:\/\/www.routledge.com\/Education-Is-Not-an-App-The-future-of-university-teaching-in-the-internet\/Poritz-Rees\/p\/book\/9781138910416",
      "display_url" : "routledge.com\/Education-Is-N\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "765669352083513345",
  "text" : "RT @dkernohan: This forthcoming @jhrees book looks like a superb read for the legions of edtech malcontents https:\/\/t.co\/2XC7abLgo1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jonathan Rees",
        "screen_name" : "jhrees",
        "indices" : [ 17, 24 ],
        "id_str" : "227708559",
        "id" : 227708559
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/2XC7abLgo1",
        "expanded_url" : "https:\/\/www.routledge.com\/Education-Is-Not-an-App-The-future-of-university-teaching-in-the-internet\/Poritz-Rees\/p\/book\/9781138910416",
        "display_url" : "routledge.com\/Education-Is-N\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "765506774011183104",
    "text" : "This forthcoming @jhrees book looks like a superb read for the legions of edtech malcontents https:\/\/t.co\/2XC7abLgo1",
    "id" : 765506774011183104,
    "created_at" : "2016-08-16 11:13:32 +0000",
    "user" : {
      "name" : "David Kern\u24C4h\u24B6n",
      "screen_name" : "dkernohan",
      "protected" : false,
      "id_str" : "12219232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/757702202437804032\/4Xrm7IIe_normal.jpg",
      "id" : 12219232,
      "verified" : false
    }
  },
  "id" : 765669352083513345,
  "created_at" : "2016-08-16 21:59:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenny Lewin-Jones",
      "screen_name" : "JennyLewinJones",
      "indices" : [ 0, 16 ],
      "id_str" : "1484808264",
      "id" : 1484808264
    }, {
      "name" : "BBC News (UK)",
      "screen_name" : "BBCNews",
      "indices" : [ 17, 25 ],
      "id_str" : "612473",
      "id" : 612473
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "765606754067546112",
  "geo" : { },
  "id_str" : "765607657801670657",
  "in_reply_to_user_id" : 1484808264,
  "text" : "@JennyLewinJones @BBCNews they'll miss a trick if they don't go for \"should of\" as well \uD83E\uDD23",
  "id" : 765607657801670657,
  "in_reply_to_status_id" : 765606754067546112,
  "created_at" : "2016-08-16 17:54:24 +0000",
  "in_reply_to_screen_name" : "JennyLewinJones",
  "in_reply_to_user_id_str" : "1484808264",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jawairriya",
      "screen_name" : "DrJawairriya",
      "indices" : [ 3, 16 ],
      "id_str" : "2241634898",
      "id" : 2241634898
    }, {
      "name" : "Hend Amry",
      "screen_name" : "LibyaLiberty",
      "indices" : [ 123, 136 ],
      "id_str" : "254873869",
      "id" : 254873869
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "burkini",
      "indices" : [ 41, 49 ]
    }, {
      "text" : "French",
      "indices" : [ 78, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/Atzsj2sgWJ",
      "expanded_url" : "https:\/\/www.theguardian.com\/commentisfree\/2016\/aug\/15\/five-reasons-wear-burkini-annoy-french-cannes-mayor-muslim?CMP=share_btn_tw",
      "display_url" : "theguardian.com\/commentisfree\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "765574930993905664",
  "text" : "RT @DrJawairriya: Five reasons to wear a #burkini \u2013 and not just to annoy the #French | Remona Aly https:\/\/t.co\/Atzsj2sgWJ @LibyaLiberty Gr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hend Amry",
        "screen_name" : "LibyaLiberty",
        "indices" : [ 105, 118 ],
        "id_str" : "254873869",
        "id" : 254873869
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "burkini",
        "indices" : [ 23, 31 ]
      }, {
        "text" : "French",
        "indices" : [ 60, 67 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/Atzsj2sgWJ",
        "expanded_url" : "https:\/\/www.theguardian.com\/commentisfree\/2016\/aug\/15\/five-reasons-wear-burkini-annoy-french-cannes-mayor-muslim?CMP=share_btn_tw",
        "display_url" : "theguardian.com\/commentisfree\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "765193010565054465",
    "text" : "Five reasons to wear a #burkini \u2013 and not just to annoy the #French | Remona Aly https:\/\/t.co\/Atzsj2sgWJ @LibyaLiberty Great points Ramona!",
    "id" : 765193010565054465,
    "created_at" : "2016-08-15 14:26:44 +0000",
    "user" : {
      "name" : "Dr. Jawairriya",
      "screen_name" : "DrJawairriya",
      "protected" : false,
      "id_str" : "2241634898",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/413493377036853248\/HoQhdbFl_normal.jpeg",
      "id" : 2241634898,
      "verified" : false
    }
  },
  "id" : 765574930993905664,
  "created_at" : "2016-08-16 15:44:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Radical Assembly",
      "screen_name" : "RadicalAssembly",
      "indices" : [ 3, 19 ],
      "id_str" : "3331418085",
      "id" : 3331418085
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DalianAtkinson",
      "indices" : [ 52, 67 ]
    }, {
      "text" : "BlackLivesMatter",
      "indices" : [ 68, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/7Myh0zPavO",
      "expanded_url" : "http:\/\/www.rollingstone.com\/politics\/news\/policing-is-a-dirty-job-but-nobodys-gotta-do-it-6-ideas-for-a-cop-free-world-20141216",
      "display_url" : "rollingstone.com\/politics\/news\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "765282424502751233",
  "text" : "RT @RadicalAssembly: 6 ideas to replace the police \n#DalianAtkinson #BlackLivesMatter \n\nhttps:\/\/t.co\/7Myh0zPavO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DalianAtkinson",
        "indices" : [ 31, 46 ]
      }, {
        "text" : "BlackLivesMatter",
        "indices" : [ 47, 64 ]
      } ],
      "urls" : [ {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/7Myh0zPavO",
        "expanded_url" : "http:\/\/www.rollingstone.com\/politics\/news\/policing-is-a-dirty-job-but-nobodys-gotta-do-it-6-ideas-for-a-cop-free-world-20141216",
        "display_url" : "rollingstone.com\/politics\/news\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "765275654095077376",
    "text" : "6 ideas to replace the police \n#DalianAtkinson #BlackLivesMatter \n\nhttps:\/\/t.co\/7Myh0zPavO",
    "id" : 765275654095077376,
    "created_at" : "2016-08-15 19:55:08 +0000",
    "user" : {
      "name" : "Radical Assembly",
      "screen_name" : "RadicalAssembly",
      "protected" : false,
      "id_str" : "3331418085",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/612190100122935297\/kSsFQ3hk_normal.png",
      "id" : 3331418085,
      "verified" : false
    }
  },
  "id" : 765282424502751233,
  "created_at" : "2016-08-15 20:22:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/7Q7mMLH4Mu",
      "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2016\/08\/not-just-standing-by.html",
      "display_url" : "thecurmudgeonly.blogspot.co.uk\/2016\/08\/not-ju\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "765238698854187012",
  "text" : "RT @pchallinor: New mudgeonry: Not just standing by https:\/\/t.co\/7Q7mMLH4Mu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 36, 59 ],
        "url" : "https:\/\/t.co\/7Q7mMLH4Mu",
        "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2016\/08\/not-just-standing-by.html",
        "display_url" : "thecurmudgeonly.blogspot.co.uk\/2016\/08\/not-ju\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "765237399219740672",
    "text" : "New mudgeonry: Not just standing by https:\/\/t.co\/7Q7mMLH4Mu",
    "id" : 765237399219740672,
    "created_at" : "2016-08-15 17:23:08 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 765238698854187012,
  "created_at" : "2016-08-15 17:28:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Topple",
      "screen_name" : "MrTopple",
      "indices" : [ 3, 12 ],
      "id_str" : "59240990",
      "id" : 59240990
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/MrTopple\/status\/765221144265973760\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/dXvEak7bAW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cp6cRgbW8AEKAiE.jpg",
      "id_str" : "765220811275956225",
      "id" : 765220811275956225,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cp6cRgbW8AEKAiE.jpg",
      "sizes" : [ {
        "h" : 528,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 778
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 778
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 778
      } ],
      "display_url" : "pic.twitter.com\/dXvEak7bAW"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/YC6XNYCsjW",
      "expanded_url" : "http:\/\/www.thecanary.co\/2016\/08\/15\/tory-plan-stop-4-million-people-voting-next-general-election-exclusive\/",
      "display_url" : "thecanary.co\/2016\/08\/15\/tor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "765233512467357701",
  "text" : "RT @MrTopple: RIGHT:\n\nEXCLUSIVE: Tories planning to stop 4 million people voting\nhttps:\/\/t.co\/YC6XNYCsjW\n\nMy latest.\nREAD\/RT PLS. https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/MrTopple\/status\/765221144265973760\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/dXvEak7bAW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cp6cRgbW8AEKAiE.jpg",
        "id_str" : "765220811275956225",
        "id" : 765220811275956225,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cp6cRgbW8AEKAiE.jpg",
        "sizes" : [ {
          "h" : 528,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 604,
          "resize" : "fit",
          "w" : 778
        }, {
          "h" : 604,
          "resize" : "fit",
          "w" : 778
        }, {
          "h" : 604,
          "resize" : "fit",
          "w" : 778
        } ],
        "display_url" : "pic.twitter.com\/dXvEak7bAW"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/YC6XNYCsjW",
        "expanded_url" : "http:\/\/www.thecanary.co\/2016\/08\/15\/tory-plan-stop-4-million-people-voting-next-general-election-exclusive\/",
        "display_url" : "thecanary.co\/2016\/08\/15\/tor\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "765221144265973760",
    "text" : "RIGHT:\n\nEXCLUSIVE: Tories planning to stop 4 million people voting\nhttps:\/\/t.co\/YC6XNYCsjW\n\nMy latest.\nREAD\/RT PLS. https:\/\/t.co\/dXvEak7bAW",
    "id" : 765221144265973760,
    "created_at" : "2016-08-15 16:18:32 +0000",
    "user" : {
      "name" : "Steve Topple",
      "screen_name" : "MrTopple",
      "protected" : false,
      "id_str" : "59240990",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/760871390065098752\/EMGRszAL_normal.jpg",
      "id" : 59240990,
      "verified" : true
    }
  },
  "id" : 765233512467357701,
  "created_at" : "2016-08-15 17:07:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Corbyn for PM",
      "screen_name" : "JeremyCorbyn4PM",
      "indices" : [ 3, 19 ],
      "id_str" : "3307929149",
      "id" : 3307929149
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/JeremyCorbyn4PM\/status\/765190557341741056\/photo\/1",
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/8ywZj3rnGt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cp6AwFcWAAA2UgC.jpg",
      "id_str" : "765190550282698752",
      "id" : 765190550282698752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cp6AwFcWAAA2UgC.jpg",
      "sizes" : [ {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 945,
        "resize" : "fit",
        "w" : 1679
      }, {
        "h" : 945,
        "resize" : "fit",
        "w" : 1679
      } ],
      "display_url" : "pic.twitter.com\/8ywZj3rnGt"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "765227091226923009",
  "text" : "RT @JeremyCorbyn4PM: Wow! 84% of CLPs have endorsed Jeremy Corbyn for Labour leader. https:\/\/t.co\/8ywZj3rnGt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/JeremyCorbyn4PM\/status\/765190557341741056\/photo\/1",
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/8ywZj3rnGt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cp6AwFcWAAA2UgC.jpg",
        "id_str" : "765190550282698752",
        "id" : 765190550282698752,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cp6AwFcWAAA2UgC.jpg",
        "sizes" : [ {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 945,
          "resize" : "fit",
          "w" : 1679
        }, {
          "h" : 945,
          "resize" : "fit",
          "w" : 1679
        } ],
        "display_url" : "pic.twitter.com\/8ywZj3rnGt"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "765190557341741056",
    "text" : "Wow! 84% of CLPs have endorsed Jeremy Corbyn for Labour leader. https:\/\/t.co\/8ywZj3rnGt",
    "id" : 765190557341741056,
    "created_at" : "2016-08-15 14:17:00 +0000",
    "user" : {
      "name" : "Jeremy Corbyn for PM",
      "screen_name" : "JeremyCorbyn4PM",
      "protected" : false,
      "id_str" : "3307929149",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746982653350445056\/UHNiRVhu_normal.jpg",
      "id" : 3307929149,
      "verified" : false
    }
  },
  "id" : 765227091226923009,
  "created_at" : "2016-08-15 16:42:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CELFS Pre-sessional",
      "screen_name" : "CELFS_ps",
      "indices" : [ 69, 78 ],
      "id_str" : "3994180756",
      "id" : 3994180756
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/YpnaeDnGan",
      "expanded_url" : "https:\/\/celfspresessional.wordpress.com\/2016\/08\/15\/applying-corpus-tools-to-eap-instruction\/",
      "display_url" : "celfspresessional.wordpress.com\/2016\/08\/15\/app\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "765128779790450688",
  "text" : "Applying Corpus Tools to EAP Instruction https:\/\/t.co\/YpnaeDnGan via @CELFS_ps",
  "id" : 765128779790450688,
  "created_at" : "2016-08-15 10:11:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S'",
      "screen_name" : "Sher_han_",
      "indices" : [ 0, 10 ],
      "id_str" : "18523388",
      "id" : 18523388
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "764811141738557440",
  "geo" : { },
  "id_str" : "764869326910418944",
  "in_reply_to_user_id" : 18523388,
  "text" : "@Sher_han_ nice \uD83D\uDE03 where is it in 2017? Brum was this year",
  "id" : 764869326910418944,
  "in_reply_to_status_id" : 764811141738557440,
  "created_at" : "2016-08-14 17:00:32 +0000",
  "in_reply_to_screen_name" : "Sher_han_",
  "in_reply_to_user_id_str" : "18523388",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/rgqwlGyett",
      "expanded_url" : "http:\/\/www.dailymail.co.uk\/debate\/article-3739516\/Why-despise-Jeremy-Corbyn-Nazi-stormtroopers-Jewish-Labour-donor-MICHAEL-FOSTER.html",
      "display_url" : "dailymail.co.uk\/debate\/article\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "764809289026461696",
  "text" : "RT @johnwhilley: So where's all the calls for Michael Foster to be expelled from Labour after likening Corbyn supporters to Nazis? https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/rgqwlGyett",
        "expanded_url" : "http:\/\/www.dailymail.co.uk\/debate\/article-3739516\/Why-despise-Jeremy-Corbyn-Nazi-stormtroopers-Jewish-Labour-donor-MICHAEL-FOSTER.html",
        "display_url" : "dailymail.co.uk\/debate\/article\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "764805584126373888",
    "text" : "So where's all the calls for Michael Foster to be expelled from Labour after likening Corbyn supporters to Nazis? https:\/\/t.co\/rgqwlGyett",
    "id" : 764805584126373888,
    "created_at" : "2016-08-14 12:47:15 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 764809289026461696,
  "created_at" : "2016-08-14 13:01:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S'",
      "screen_name" : "Sher_han_",
      "indices" : [ 0, 10 ],
      "id_str" : "18523388",
      "id" : 18523388
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "764619404260827136",
  "geo" : { },
  "id_str" : "764804600448815104",
  "in_reply_to_user_id" : 18523388,
  "text" : "@Sher_han_ hi no i won't, r u going?",
  "id" : 764804600448815104,
  "in_reply_to_status_id" : 764619404260827136,
  "created_at" : "2016-08-14 12:43:20 +0000",
  "in_reply_to_screen_name" : "Sher_han_",
  "in_reply_to_user_id_str" : "18523388",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 98, 106 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/F3UcU3ykee",
      "expanded_url" : "https:\/\/youtu.be\/jS0JFEIX2Yg",
      "display_url" : "youtu.be\/jS0JFEIX2Yg"
    } ]
  },
  "geo" : { },
  "id_str" : "764565413762043904",
  "text" : "\"Owen Smith third in a 2 horse race\" : ) Galloway's continued rant... https:\/\/t.co\/F3UcU3ykee via @YouTube",
  "id" : 764565413762043904,
  "created_at" : "2016-08-13 20:52:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/bwPg1atUGG",
      "expanded_url" : "http:\/\/www.counterpunch.org\/2016\/08\/12\/tribute-to-fidel-castro-on-his-90th-birthday\/",
      "display_url" : "counterpunch.org\/2016\/08\/12\/tri\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "764485063203356673",
  "text" : "Tribute to Fidel Castro on His 90th Birthday https:\/\/t.co\/bwPg1atUGG",
  "id" : 764485063203356673,
  "created_at" : "2016-08-13 15:33:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Lowe",
      "screen_name" : "andylowe99",
      "indices" : [ 3, 14 ],
      "id_str" : "1089403591",
      "id" : 1089403591
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "books",
      "indices" : [ 77, 83 ]
    }, {
      "text" : "publishing",
      "indices" : [ 84, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/i9AaxVBvfs",
      "expanded_url" : "http:\/\/bit.ly\/1TdHoVA",
      "display_url" : "bit.ly\/1TdHoVA"
    } ]
  },
  "geo" : { },
  "id_str" : "764479277966458880",
  "text" : "RT @andylowe99: Rabai al-Madhoun wins International prize for Arabic fiction #books #publishing https:\/\/t.co\/i9AaxVBvfs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "books",
        "indices" : [ 61, 67 ]
      }, {
        "text" : "publishing",
        "indices" : [ 68, 79 ]
      } ],
      "urls" : [ {
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/i9AaxVBvfs",
        "expanded_url" : "http:\/\/bit.ly\/1TdHoVA",
        "display_url" : "bit.ly\/1TdHoVA"
      } ]
    },
    "geo" : { },
    "id_str" : "764477780125974528",
    "text" : "Rabai al-Madhoun wins International prize for Arabic fiction #books #publishing https:\/\/t.co\/i9AaxVBvfs",
    "id" : 764477780125974528,
    "created_at" : "2016-08-13 15:04:40 +0000",
    "user" : {
      "name" : "Andrew Lowe",
      "screen_name" : "andylowe99",
      "protected" : false,
      "id_str" : "1089403591",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/737638710666235904\/gM9HGW2S_normal.jpg",
      "id" : 1089403591,
      "verified" : false
    }
  },
  "id" : 764479277966458880,
  "created_at" : "2016-08-13 15:10:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Bastani",
      "screen_name" : "AaronBastani",
      "indices" : [ 3, 16 ],
      "id_str" : "63082578",
      "id" : 63082578
    }, {
      "name" : "Michael Walker",
      "screen_name" : "michaeljswalker",
      "indices" : [ 35, 51 ],
      "id_str" : "2721106954",
      "id" : 2721106954
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/novaramedia\/status\/764180528849358848\/video\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/zo79cL4LXg",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/764176730189864960\/pu\/img\/MBktcr6EhsSzJRfg.jpg",
      "id_str" : "764176730189864960",
      "id" : 764176730189864960,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/764176730189864960\/pu\/img\/MBktcr6EhsSzJRfg.jpg",
      "sizes" : [ {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/zo79cL4LXg"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "764475921441124353",
  "text" : "RT @AaronBastani: I think point by @michaeljswalker here is spot on. Intelligent left critics of Corbyn asking for the impossible https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Michael Walker",
        "screen_name" : "michaeljswalker",
        "indices" : [ 17, 33 ],
        "id_str" : "2721106954",
        "id" : 2721106954
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/novaramedia\/status\/764180528849358848\/video\/1",
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/zo79cL4LXg",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/764176730189864960\/pu\/img\/MBktcr6EhsSzJRfg.jpg",
        "id_str" : "764176730189864960",
        "id" : 764176730189864960,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/764176730189864960\/pu\/img\/MBktcr6EhsSzJRfg.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/zo79cL4LXg"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "764473560849145860",
    "text" : "I think point by @michaeljswalker here is spot on. Intelligent left critics of Corbyn asking for the impossible https:\/\/t.co\/zo79cL4LXg",
    "id" : 764473560849145860,
    "created_at" : "2016-08-13 14:47:54 +0000",
    "user" : {
      "name" : "Aaron Bastani",
      "screen_name" : "AaronBastani",
      "protected" : false,
      "id_str" : "63082578",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/607541942570872832\/8qjuXLFj_normal.jpg",
      "id" : 63082578,
      "verified" : false
    }
  },
  "id" : 764475921441124353,
  "created_at" : "2016-08-13 14:57:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "764464239188840448",
  "text" : "\"get in the sea\" interesting idiom",
  "id" : 764464239188840448,
  "created_at" : "2016-08-13 14:10:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Bastani",
      "screen_name" : "AaronBastani",
      "indices" : [ 3, 16 ],
      "id_str" : "63082578",
      "id" : 63082578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/pmdLKZparG",
      "expanded_url" : "https:\/\/twitter.com\/aaronbastani\/status\/764153523365900288",
      "display_url" : "twitter.com\/aaronbastani\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "764189048009293825",
  "text" : "RT @AaronBastani: This is difference between Miliband\/Corbyn leadership. Ed would mention in a speech weeks later, Trickett intervenes http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/pmdLKZparG",
        "expanded_url" : "https:\/\/twitter.com\/aaronbastani\/status\/764153523365900288",
        "display_url" : "twitter.com\/aaronbastani\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "764176598295834624",
    "text" : "This is difference between Miliband\/Corbyn leadership. Ed would mention in a speech weeks later, Trickett intervenes https:\/\/t.co\/pmdLKZparG",
    "id" : 764176598295834624,
    "created_at" : "2016-08-12 19:07:53 +0000",
    "user" : {
      "name" : "Aaron Bastani",
      "screen_name" : "AaronBastani",
      "protected" : false,
      "id_str" : "63082578",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/607541942570872832\/8qjuXLFj_normal.jpg",
      "id" : 63082578,
      "verified" : false
    }
  },
  "id" : 764189048009293825,
  "created_at" : "2016-08-12 19:57:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luiz Otavio Barros",
      "screen_name" : "luizotavioELT",
      "indices" : [ 0, 14 ],
      "id_str" : "54798894",
      "id" : 54798894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "764113715797131264",
  "geo" : { },
  "id_str" : "764114872233754624",
  "in_reply_to_user_id" : 54798894,
  "text" : "@luizotavioELT both i think? the terms in this area are somewhat confusing",
  "id" : 764114872233754624,
  "in_reply_to_status_id" : 764113715797131264,
  "created_at" : "2016-08-12 15:02:36 +0000",
  "in_reply_to_screen_name" : "luizotavioELT",
  "in_reply_to_user_id_str" : "54798894",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luiz Otavio Barros",
      "screen_name" : "luizotavioELT",
      "indices" : [ 0, 14 ],
      "id_str" : "54798894",
      "id" : 54798894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "764106519822622720",
  "geo" : { },
  "id_str" : "764112971152982018",
  "in_reply_to_user_id" : 54798894,
  "text" : "@luizotavioELT i think indirect input enhancement is also called input flood?",
  "id" : 764112971152982018,
  "in_reply_to_status_id" : 764106519822622720,
  "created_at" : "2016-08-12 14:55:03 +0000",
  "in_reply_to_screen_name" : "luizotavioELT",
  "in_reply_to_user_id_str" : "54798894",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luiz Otavio Barros",
      "screen_name" : "luizotavioELT",
      "indices" : [ 3, 17 ],
      "id_str" : "54798894",
      "id" : 54798894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/uSwXlOYSju",
      "expanded_url" : "http:\/\/www.richmondshare.com.br\/noticing-input-enhancement\/",
      "display_url" : "richmondshare.com.br\/noticing-input\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "764112522232356864",
  "text" : "RT @luizotavioELT: Two kinds of noticing tasks.\nMy first post on Richmond Share after a long hiatus.\nhttps:\/\/t.co\/uSwXlOYSju",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/uSwXlOYSju",
        "expanded_url" : "http:\/\/www.richmondshare.com.br\/noticing-input-enhancement\/",
        "display_url" : "richmondshare.com.br\/noticing-input\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "764106519822622720",
    "text" : "Two kinds of noticing tasks.\nMy first post on Richmond Share after a long hiatus.\nhttps:\/\/t.co\/uSwXlOYSju",
    "id" : 764106519822622720,
    "created_at" : "2016-08-12 14:29:25 +0000",
    "user" : {
      "name" : "Luiz Otavio Barros",
      "screen_name" : "luizotavioELT",
      "protected" : false,
      "id_str" : "54798894",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2993483640\/18c26077182489c6d9f18ff232617587_normal.jpeg",
      "id" : 54798894,
      "verified" : false
    }
  },
  "id" : 764112522232356864,
  "created_at" : "2016-08-12 14:53:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay P. Greene",
      "screen_name" : "jaypgreene",
      "indices" : [ 76, 87 ],
      "id_str" : "197463159",
      "id" : 197463159
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/Oc1xn6BGDs",
      "expanded_url" : "https:\/\/jaypgreene.com\/2016\/08\/12\/online-courses-may-not-be-the-way-of-the-future\/",
      "display_url" : "jaypgreene.com\/2016\/08\/12\/onl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "764110185690464256",
  "text" : "Online Courses May Not Be the Way of the Future https:\/\/t.co\/Oc1xn6BGDs via @jaypgreene",
  "id" : 764110185690464256,
  "created_at" : "2016-08-12 14:43:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/hsLuzBWCwU",
      "expanded_url" : "https:\/\/www.craigmurray.org.uk\/archives\/2016\/08\/dysfunctional-united-kingdom\/",
      "display_url" : "craigmurray.org.uk\/archives\/2016\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "764076832069001216",
  "text" : "RT @pchallinor: Britishness and the philanthropy of the chinless classes https:\/\/t.co\/hsLuzBWCwU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/hsLuzBWCwU",
        "expanded_url" : "https:\/\/www.craigmurray.org.uk\/archives\/2016\/08\/dysfunctional-united-kingdom\/",
        "display_url" : "craigmurray.org.uk\/archives\/2016\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "764050995471015936",
    "text" : "Britishness and the philanthropy of the chinless classes https:\/\/t.co\/hsLuzBWCwU",
    "id" : 764050995471015936,
    "created_at" : "2016-08-12 10:48:47 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 764076832069001216,
  "created_at" : "2016-08-12 12:31:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monika Bednarek",
      "screen_name" : "Corpusling",
      "indices" : [ 3, 14 ],
      "id_str" : "2208665992",
      "id" : 2208665992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/fcm4VVOn6J",
      "expanded_url" : "http:\/\/www.newsvaluesanalysis.com",
      "display_url" : "newsvaluesanalysis.com"
    }, {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/4Sxka5pY6q",
      "expanded_url" : "https:\/\/twitter.com\/jodie__martin\/status\/763981521153777668",
      "display_url" : "twitter.com\/jodie__martin\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "764039743873122304",
  "text" : "RT @Corpusling: Thanks for the tweet, Jodie, just missed an s: it's https:\/\/t.co\/fcm4VVOn6J https:\/\/t.co\/4Sxka5pY6q",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 75 ],
        "url" : "https:\/\/t.co\/fcm4VVOn6J",
        "expanded_url" : "http:\/\/www.newsvaluesanalysis.com",
        "display_url" : "newsvaluesanalysis.com"
      }, {
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/4Sxka5pY6q",
        "expanded_url" : "https:\/\/twitter.com\/jodie__martin\/status\/763981521153777668",
        "display_url" : "twitter.com\/jodie__martin\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "764035724744101888",
    "text" : "Thanks for the tweet, Jodie, just missed an s: it's https:\/\/t.co\/fcm4VVOn6J https:\/\/t.co\/4Sxka5pY6q",
    "id" : 764035724744101888,
    "created_at" : "2016-08-12 09:48:06 +0000",
    "user" : {
      "name" : "Monika Bednarek",
      "screen_name" : "Corpusling",
      "protected" : false,
      "id_str" : "2208665992",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/444356153636421634\/D70JwNc9_normal.jpeg",
      "id" : 2208665992,
      "verified" : false
    }
  },
  "id" : 764039743873122304,
  "created_at" : "2016-08-12 10:04:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/756GWCtryD",
      "expanded_url" : "http:\/\/www.dcscience.net\/2016\/08\/10\/cupping-bruises-for-the-gullible-and-other-myths-in-sport\/",
      "display_url" : "dcscience.net\/2016\/08\/10\/cup\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "763776122412818432",
  "text" : "Cupping: bruises for the gullible, and other myths in sport https:\/\/t.co\/756GWCtryD",
  "id" : 763776122412818432,
  "created_at" : "2016-08-11 16:36:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derek Bateman",
      "screen_name" : "DerekBateman2",
      "indices" : [ 3, 17 ],
      "id_str" : "1854262416",
      "id" : 1854262416
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "763487877598699521",
  "text" : "RT @DerekBateman2: Labour uses Labour rules to sue Labour. Court rules Labour rules no use. Overrules Labour. Labour rues use of Labour rul\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "762638307595546624",
    "text" : "Labour uses Labour rules to sue Labour. Court rules Labour rules no use. Overrules Labour. Labour rues use of Labour rules. Labour no use.",
    "id" : 762638307595546624,
    "created_at" : "2016-08-08 13:15:16 +0000",
    "user" : {
      "name" : "Derek Bateman",
      "screen_name" : "DerekBateman2",
      "protected" : false,
      "id_str" : "1854262416",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/436828358035247104\/kBMf7hW4_normal.jpeg",
      "id" : 1854262416,
      "verified" : false
    }
  },
  "id" : 763487877598699521,
  "created_at" : "2016-08-10 21:31:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 82, 98 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/0wQrZEFwBA",
      "expanded_url" : "https:\/\/literalminded.wordpress.com\/2016\/08\/09\/relative-clauses-complex-passives-and-rainbow-farts\/",
      "display_url" : "literalminded.wordpress.com\/2016\/08\/09\/rel\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "763310375848869888",
  "text" : "Relative Clauses, Complex Passives, and Rainbow Farts https:\/\/t.co\/0wQrZEFwBA via @wordpressdotcom",
  "id" : 763310375848869888,
  "created_at" : "2016-08-10 09:45:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 0, 9 ],
      "id_str" : "134211317",
      "id" : 134211317
    }, {
      "name" : "The Guardian",
      "screen_name" : "guardian",
      "indices" : [ 10, 19 ],
      "id_str" : "87818409",
      "id" : 87818409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "763064615043555328",
  "geo" : { },
  "id_str" : "763076679849893889",
  "in_reply_to_user_id" : 134211317,
  "text" : "@josipa74 @guardian he has a home in BBC comedy after politics methinks",
  "id" : 763076679849893889,
  "in_reply_to_status_id" : 763064615043555328,
  "created_at" : "2016-08-09 18:17:12 +0000",
  "in_reply_to_screen_name" : "josipa74",
  "in_reply_to_user_id_str" : "134211317",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 0, 9 ],
      "id_str" : "121063600",
      "id" : 121063600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "763071052809277440",
  "geo" : { },
  "id_str" : "763074805621002240",
  "in_reply_to_user_id" : 121063600,
  "text" : "@whyshona available on sci-hub use doi",
  "id" : 763074805621002240,
  "in_reply_to_status_id" : 763071052809277440,
  "created_at" : "2016-08-09 18:09:45 +0000",
  "in_reply_to_screen_name" : "whyshona",
  "in_reply_to_user_id_str" : "121063600",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "763073650140545024",
  "text" : "RT @pchallinor: Benedict XVI &amp; Emperor Akihito send joint message commiserating non-abdicator Elizabeth II on the fact that her successor i\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "763073052263481345",
    "text" : "Benedict XVI &amp; Emperor Akihito send joint message commiserating non-abdicator Elizabeth II on the fact that her successor is Prince Charles.",
    "id" : 763073052263481345,
    "created_at" : "2016-08-09 18:02:47 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 763073650140545024,
  "created_at" : "2016-08-09 18:05:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenn Greenwald",
      "screen_name" : "ggreenwald",
      "indices" : [ 3, 14 ],
      "id_str" : "16076032",
      "id" : 16076032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 125, 140 ],
      "url" : "https:\/\/t.co\/f7piYEskGv",
      "expanded_url" : "http:\/\/media.salon.com\/2016\/08\/state-dept-palestinian-bicycle.mp4",
      "display_url" : "media.salon.com\/2016\/08\/state-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "763073149600759812",
  "text" : "RT @ggreenwald: Amazing video of a State Dept spokesman talking about Israeli solider stealing a bike from a Palestinian kid https:\/\/t.co\/f\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/f7piYEskGv",
        "expanded_url" : "http:\/\/media.salon.com\/2016\/08\/state-dept-palestinian-bicycle.mp4",
        "display_url" : "media.salon.com\/2016\/08\/state-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "763051177370157056",
    "text" : "Amazing video of a State Dept spokesman talking about Israeli solider stealing a bike from a Palestinian kid https:\/\/t.co\/f7piYEskGv",
    "id" : 763051177370157056,
    "created_at" : "2016-08-09 16:35:52 +0000",
    "user" : {
      "name" : "Glenn Greenwald",
      "screen_name" : "ggreenwald",
      "protected" : false,
      "id_str" : "16076032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/659383028771364869\/G9HHnjiI_normal.jpg",
      "id" : 16076032,
      "verified" : true
    }
  },
  "id" : 763073149600759812,
  "created_at" : "2016-08-09 18:03:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/w3Fij6Rkzq",
      "expanded_url" : "https:\/\/twitter.com\/dji45\/status\/762610655270735872",
      "display_url" : "twitter.com\/dji45\/status\/7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "762612953782874113",
  "text" : "RT @pchallinor: Evil Trots in court entryism takeover horror https:\/\/t.co\/w3Fij6Rkzq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 68 ],
        "url" : "https:\/\/t.co\/w3Fij6Rkzq",
        "expanded_url" : "https:\/\/twitter.com\/dji45\/status\/762610655270735872",
        "display_url" : "twitter.com\/dji45\/status\/7\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "762611867458101248",
    "text" : "Evil Trots in court entryism takeover horror https:\/\/t.co\/w3Fij6Rkzq",
    "id" : 762611867458101248,
    "created_at" : "2016-08-08 11:30:12 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 762612953782874113,
  "created_at" : "2016-08-08 11:34:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 80, 96 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/QVVrvAoJgS",
      "expanded_url" : "https:\/\/eltgeek.wordpress.com\/2016\/08\/06\/malcolm-gladwell-on-steve-jobs-a-listening-lesson\/",
      "display_url" : "eltgeek.wordpress.com\/2016\/08\/06\/mal\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "761942168646868993",
  "text" : "Malcolm Gladwell on Steve Jobs - a listening lesson https:\/\/t.co\/QVVrvAoJgS via @wordpressdotcom",
  "id" : 761942168646868993,
  "created_at" : "2016-08-06 15:09:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer MacDonald",
      "screen_name" : "JenMac_ESL",
      "indices" : [ 0, 11 ],
      "id_str" : "608800026",
      "id" : 608800026
    }, {
      "name" : "Kinja",
      "screen_name" : "kinja",
      "indices" : [ 12, 18 ],
      "id_str" : "769573604",
      "id" : 769573604
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "761265907477934084",
  "geo" : { },
  "id_str" : "761268449205166085",
  "in_reply_to_user_id" : 608800026,
  "text" : "@JenMac_ESL @kinja a language steeped in resistance to those with armies &amp; navies",
  "id" : 761268449205166085,
  "in_reply_to_status_id" : 761265907477934084,
  "created_at" : "2016-08-04 18:31:56 +0000",
  "in_reply_to_screen_name" : "JenMac_ESL",
  "in_reply_to_user_id_str" : "608800026",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Emersberger",
      "screen_name" : "rosendo_joe",
      "indices" : [ 3, 15 ],
      "id_str" : "3351345863",
      "id" : 3351345863
    }, {
      "name" : "Reuters Top News",
      "screen_name" : "Reuters",
      "indices" : [ 103, 111 ],
      "id_str" : "1652541",
      "id" : 1652541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/JXjNT4HKKw",
      "expanded_url" : "http:\/\/reut.rs\/2aJzHeY",
      "display_url" : "reut.rs\/2aJzHeY"
    } ]
  },
  "geo" : { },
  "id_str" : "761265474655125504",
  "text" : "RT @rosendo_joe: Commentary: The real reason Washington calls Putin a thug https:\/\/t.co\/JXjNT4HKKw via @Reuters",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Reuters Top News",
        "screen_name" : "Reuters",
        "indices" : [ 86, 94 ],
        "id_str" : "1652541",
        "id" : 1652541
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/JXjNT4HKKw",
        "expanded_url" : "http:\/\/reut.rs\/2aJzHeY",
        "display_url" : "reut.rs\/2aJzHeY"
      } ]
    },
    "geo" : { },
    "id_str" : "761261727921106944",
    "text" : "Commentary: The real reason Washington calls Putin a thug https:\/\/t.co\/JXjNT4HKKw via @Reuters",
    "id" : 761261727921106944,
    "created_at" : "2016-08-04 18:05:14 +0000",
    "user" : {
      "name" : "Joe Emersberger",
      "screen_name" : "rosendo_joe",
      "protected" : false,
      "id_str" : "3351345863",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/621112707522142209\/OGmLR1xt_normal.jpg",
      "id" : 3351345863,
      "verified" : false
    }
  },
  "id" : 761265474655125504,
  "created_at" : "2016-08-04 18:20:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/5CFnvGCVTU",
      "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2016\/08\/flawed-intelligence.html",
      "display_url" : "thecurmudgeonly.blogspot.co.uk\/2016\/08\/flawed\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "761264641305636864",
  "text" : "RT @pchallinor: New mudgeonry: Flawed intelligence https:\/\/t.co\/5CFnvGCVTU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 58 ],
        "url" : "https:\/\/t.co\/5CFnvGCVTU",
        "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2016\/08\/flawed-intelligence.html",
        "display_url" : "thecurmudgeonly.blogspot.co.uk\/2016\/08\/flawed\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "761263379466096640",
    "text" : "New mudgeonry: Flawed intelligence https:\/\/t.co\/5CFnvGCVTU",
    "id" : 761263379466096640,
    "created_at" : "2016-08-04 18:11:47 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 761264641305636864,
  "created_at" : "2016-08-04 18:16:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ali Abunimah",
      "screen_name" : "AliAbunimah",
      "indices" : [ 3, 15 ],
      "id_str" : "16799023",
      "id" : 16799023
    }, {
      "name" : "World Vision",
      "screen_name" : "WorldVision",
      "indices" : [ 36, 48 ],
      "id_str" : "14086764",
      "id" : 14086764
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "https:\/\/t.co\/SPyFn5cBXV",
      "expanded_url" : "https:\/\/electronicintifada.net\/blogs\/ali-abunimah\/christian-charity-rejects-israeli-claim-funds-went-hamas",
      "display_url" : "electronicintifada.net\/blogs\/ali-abun\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "761263160913436672",
  "text" : "RT @AliAbunimah: Israel\u2019s attack on @WorldVision foreshadows all-out assault at humanitarian sector in Gaza. Ominous. https:\/\/t.co\/SPyFn5cB\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "World Vision",
        "screen_name" : "WorldVision",
        "indices" : [ 19, 31 ],
        "id_str" : "14086764",
        "id" : 14086764
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/SPyFn5cBXV",
        "expanded_url" : "https:\/\/electronicintifada.net\/blogs\/ali-abunimah\/christian-charity-rejects-israeli-claim-funds-went-hamas",
        "display_url" : "electronicintifada.net\/blogs\/ali-abun\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "761251121935577092",
    "text" : "Israel\u2019s attack on @WorldVision foreshadows all-out assault at humanitarian sector in Gaza. Ominous. https:\/\/t.co\/SPyFn5cBXV",
    "id" : 761251121935577092,
    "created_at" : "2016-08-04 17:23:05 +0000",
    "user" : {
      "name" : "Ali Abunimah",
      "screen_name" : "AliAbunimah",
      "protected" : false,
      "id_str" : "16799023",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/720233204544712705\/1zP1g9sh_normal.jpg",
      "id" : 16799023,
      "verified" : true
    }
  },
  "id" : 761263160913436672,
  "created_at" : "2016-08-04 18:10:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 0, 15 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "761250823187955712",
  "geo" : { },
  "id_str" : "761262711586119680",
  "in_reply_to_user_id" : 334332424,
  "text" : "@GeoffreyJordan u have a strange sense of humour Geoff u know this is pro-israeli satire?",
  "id" : 761262711586119680,
  "in_reply_to_status_id" : 761250823187955712,
  "created_at" : "2016-08-04 18:09:08 +0000",
  "in_reply_to_screen_name" : "GeoffreyJordan",
  "in_reply_to_user_id_str" : "334332424",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Kriss",
      "screen_name" : "sam_kriss",
      "indices" : [ 56, 66 ],
      "id_str" : "588771213",
      "id" : 588771213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/wjC4sagmjw",
      "expanded_url" : "https:\/\/samkriss.wordpress.com\/2016\/08\/04\/dan-hodges-lost-in-reality\/",
      "display_url" : "samkriss.wordpress.com\/2016\/08\/04\/dan\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "761238414360506368",
  "text" : "Dan Hodges, lost in reality https:\/\/t.co\/wjC4sagmjw via @sam_kriss",
  "id" : 761238414360506368,
  "created_at" : "2016-08-04 16:32:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELT ADVOCACY Ireland",
      "screen_name" : "ELTAdvocacy",
      "indices" : [ 0, 12 ],
      "id_str" : "712775553821048832",
      "id" : 712775553821048832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "761152725723873280",
  "geo" : { },
  "id_str" : "761167970966142981",
  "in_reply_to_user_id" : 712775553821048832,
  "text" : "@ELTAdvocacy  does this question to this article?",
  "id" : 761167970966142981,
  "in_reply_to_status_id" : 761152725723873280,
  "created_at" : "2016-08-04 11:52:40 +0000",
  "in_reply_to_screen_name" : "ELTAdvocacy",
  "in_reply_to_user_id_str" : "712775553821048832",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 0, 11 ],
      "id_str" : "14663837",
      "id" : 14663837
    }, {
      "name" : "The Independent",
      "screen_name" : "Independent",
      "indices" : [ 12, 24 ],
      "id_str" : "16973333",
      "id" : 16973333
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "761139888209223680",
  "geo" : { },
  "id_str" : "761142982871490560",
  "in_reply_to_user_id" : 14663837,
  "text" : "@pchallinor @Independent maybe Zack Snyder has been following the labour leadership races?",
  "id" : 761142982871490560,
  "in_reply_to_status_id" : 761139888209223680,
  "created_at" : "2016-08-04 10:13:23 +0000",
  "in_reply_to_screen_name" : "pchallinor",
  "in_reply_to_user_id_str" : "14663837",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/NfT7nAEEEl",
      "expanded_url" : "https:\/\/www.theguardian.com\/commentisfree\/2016\/aug\/03\/new-labour-brought-hope-jeremy-corbyn-has-brought-despair",
      "display_url" : "theguardian.com\/commentisfree\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "760797169578311680",
  "text" : "RT @pchallinor: AAAAAAAH ha ha ha ha ha ha ha ha ha aha aha ha ha ha ha ha ha ha ha ha ha ha aha oh stop it aha ha ha ha ha ha ha ha https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/NfT7nAEEEl",
        "expanded_url" : "https:\/\/www.theguardian.com\/commentisfree\/2016\/aug\/03\/new-labour-brought-hope-jeremy-corbyn-has-brought-despair",
        "display_url" : "theguardian.com\/commentisfree\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "760787765856505856",
    "text" : "AAAAAAAH ha ha ha ha ha ha ha ha ha aha aha ha ha ha ha ha ha ha ha ha ha ha aha oh stop it aha ha ha ha ha ha ha ha https:\/\/t.co\/NfT7nAEEEl",
    "id" : 760787765856505856,
    "created_at" : "2016-08-03 10:41:52 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 760797169578311680,
  "created_at" : "2016-08-03 11:19:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 123, 139 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/1AQJv3Vx1m",
      "expanded_url" : "https:\/\/corplinguistics.wordpress.com\/2016\/08\/03\/paul-ryan-dislikes-trump-almost-as-much-as-cruz-does-on-not-naming-names-at-the-conventions\/",
      "display_url" : "corplinguistics.wordpress.com\/2016\/08\/03\/pau\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "760770645491871744",
  "text" : "Paul Ryan dislikes Trump almost as much as Cruz does: On (not) naming names at the conventions https:\/\/t.co\/1AQJv3Vx1m via @wordpressdotcom",
  "id" : 760770645491871744,
  "created_at" : "2016-08-03 09:33:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "760465761374572544",
  "geo" : { },
  "id_str" : "760466168272551936",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish elt was carefree back than i guess \uD83D\uDE02",
  "id" : 760466168272551936,
  "in_reply_to_status_id" : 760465761374572544,
  "created_at" : "2016-08-02 13:23:57 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/760462150653607936\/photo\/1",
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/emigMDHc5h",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Co20RF4WcAASkGw.jpg",
      "id_str" : "760462117824786432",
      "id" : 760462117824786432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Co20RF4WcAASkGw.jpg",
      "sizes" : [ {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 674
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 382
      } ],
      "display_url" : "pic.twitter.com\/emigMDHc5h"
    } ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 14, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760462150653607936",
  "text" : "Holiday attic #elt find https:\/\/t.co\/emigMDHc5h",
  "id" : 760462150653607936,
  "created_at" : "2016-08-02 13:08:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 0, 15 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "760458073806934016",
  "geo" : { },
  "id_str" : "760460357739671552",
  "in_reply_to_user_id" : 334332424,
  "text" : "@GeoffreyJordan i find his polit writings excellent; his ling stuff too dense for me;",
  "id" : 760460357739671552,
  "in_reply_to_status_id" : 760458073806934016,
  "created_at" : "2016-08-02 13:00:52 +0000",
  "in_reply_to_screen_name" : "GeoffreyJordan",
  "in_reply_to_user_id_str" : "334332424",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Gianfranco Conti",
      "screen_name" : "gianfrancocont9",
      "indices" : [ 121, 137 ],
      "id_str" : "2347690794",
      "id" : 2347690794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/V2DI4AlDeb",
      "expanded_url" : "https:\/\/gianfrancoconti.wordpress.com\/2016\/08\/01\/the-skill-theory-principles-which-underpin-my-teaching-approach\/",
      "display_url" : "gianfrancoconti.wordpress.com\/2016\/08\/01\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "760459646142386176",
  "text" : "Why I teach the way I teach. The Skill-Theory principles which underpin my teaching approach https:\/\/t.co\/V2DI4AlDeb via @gianfrancocont9",
  "id" : 760459646142386176,
  "created_at" : "2016-08-02 12:58:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 0, 15 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "760448653836316672",
  "geo" : { },
  "id_str" : "760452490785587200",
  "in_reply_to_user_id" : 334332424,
  "text" : "@GeoffreyJordan his linguistics stuff or politics stuff?",
  "id" : 760452490785587200,
  "in_reply_to_status_id" : 760448653836316672,
  "created_at" : "2016-08-02 12:29:36 +0000",
  "in_reply_to_screen_name" : "GeoffreyJordan",
  "in_reply_to_user_id_str" : "334332424",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/0r8if8V8nS",
      "expanded_url" : "https:\/\/chomsky.info\/an-eight-point-brief-for-lev-lesser-evil-voting\/",
      "display_url" : "chomsky.info\/an-eight-point\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "760444315315347456",
  "text" : "An Eight Point Brief for LEV (Lesser Evil Voting) https:\/\/t.co\/0r8if8V8nS Halle &amp; Chomsky",
  "id" : 760444315315347456,
  "created_at" : "2016-08-02 11:57:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 124, 140 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/Hml4g1DVfZ",
      "expanded_url" : "https:\/\/corplinguistics.wordpress.com\/2016\/08\/01\/dnc-vs-rnc\/",
      "display_url" : "corplinguistics.wordpress.com\/2016\/08\/01\/dnc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "760396936721657856",
  "text" : "Failed vs. fighting: the linguistic differences between speeches at the RNC and the DNC conven\u2026 https:\/\/t.co\/Hml4g1DVfZ via @wordpressdotcom",
  "id" : 760396936721657856,
  "created_at" : "2016-08-02 08:48:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 140 ],
      "url" : "https:\/\/t.co\/oj5RlBYNHo",
      "expanded_url" : "https:\/\/www.theguardian.com\/uk-news\/2016\/aug\/01\/china-warns-uk-over-suspicious-approach-to-hinkley-point-deal",
      "display_url" : "theguardian.com\/uk-news\/2016\/a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "760071378125123584",
  "text" : "RT @pchallinor: But but but do the Heathen Chinee not realise that having left the EU we'll be so much bigger than them? https:\/\/t.co\/oj5Rl\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/oj5RlBYNHo",
        "expanded_url" : "https:\/\/www.theguardian.com\/uk-news\/2016\/aug\/01\/china-warns-uk-over-suspicious-approach-to-hinkley-point-deal",
        "display_url" : "theguardian.com\/uk-news\/2016\/a\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "760068491416395776",
    "text" : "But but but do the Heathen Chinee not realise that having left the EU we'll be so much bigger than them? https:\/\/t.co\/oj5RlBYNHo",
    "id" : 760068491416395776,
    "created_at" : "2016-08-01 11:03:44 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 760071378125123584,
  "created_at" : "2016-08-01 11:15:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Bastani",
      "screen_name" : "AaronBastani",
      "indices" : [ 3, 16 ],
      "id_str" : "63082578",
      "id" : 63082578
    }, {
      "name" : "Paul Mason",
      "screen_name" : "paulmasonnews",
      "indices" : [ 45, 59 ],
      "id_str" : "19811190",
      "id" : 19811190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/HnCN8R2Mwg",
      "expanded_url" : "https:\/\/medium.com\/mosquito-ridge\/labour-the-way-ahead-78d49d513a9f#.xsehxmh6m",
      "display_url" : "medium.com\/mosquito-ridge\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "759892037172809728",
  "text" : "RT @AaronBastani: \u201CLabour: The Way Ahead\u201D by @paulmasonnews https:\/\/t.co\/HnCN8R2Mwg if you read anything today make it this.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Paul Mason",
        "screen_name" : "paulmasonnews",
        "indices" : [ 27, 41 ],
        "id_str" : "19811190",
        "id" : 19811190
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 65 ],
        "url" : "https:\/\/t.co\/HnCN8R2Mwg",
        "expanded_url" : "https:\/\/medium.com\/mosquito-ridge\/labour-the-way-ahead-78d49d513a9f#.xsehxmh6m",
        "display_url" : "medium.com\/mosquito-ridge\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "759814373372071938",
    "text" : "\u201CLabour: The Way Ahead\u201D by @paulmasonnews https:\/\/t.co\/HnCN8R2Mwg if you read anything today make it this.",
    "id" : 759814373372071938,
    "created_at" : "2016-07-31 18:13:57 +0000",
    "user" : {
      "name" : "Aaron Bastani",
      "screen_name" : "AaronBastani",
      "protected" : false,
      "id_str" : "63082578",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/607541942570872832\/8qjuXLFj_normal.jpg",
      "id" : 63082578,
      "verified" : false
    }
  },
  "id" : 759892037172809728,
  "created_at" : "2016-07-31 23:22:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
} ]