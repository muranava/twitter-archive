Grailbird.data.tweets_2015_05 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike S. Boyle",
      "screen_name" : "heyboyle",
      "indices" : [ 0, 9 ],
      "id_str" : "612840231",
      "id" : 612840231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "605104450122993666",
  "geo" : { },
  "id_str" : "605109038402170880",
  "in_reply_to_user_id" : 612840231,
  "text" : "@heyboyle I think I spot strawman &amp; slippery slope :\/",
  "id" : 605109038402170880,
  "in_reply_to_status_id" : 605104450122993666,
  "created_at" : "2015-05-31 20:30:11 +0000",
  "in_reply_to_screen_name" : "heyboyle",
  "in_reply_to_user_id_str" : "612840231",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 3, 16 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "keltchat",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/29ERHElKzt",
      "expanded_url" : "https:\/\/rosebardeltdiary.wordpress.com\/2015\/05\/31\/implications-of-defending-cbs",
      "display_url" : "rosebardeltdiary.wordpress.com\/2015\/05\/31\/imp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "605078520667238400",
  "text" : "RT @rosemerebard: My new post: Implications of defending CBs - the social, political and economical aspects. https:\/\/t.co\/29ERHElKzt #keltc\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "keltchat",
        "indices" : [ 115, 124 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/29ERHElKzt",
        "expanded_url" : "https:\/\/rosebardeltdiary.wordpress.com\/2015\/05\/31\/implications-of-defending-cbs",
        "display_url" : "rosebardeltdiary.wordpress.com\/2015\/05\/31\/imp\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "605076677077659648",
    "text" : "My new post: Implications of defending CBs - the social, political and economical aspects. https:\/\/t.co\/29ERHElKzt #keltchat",
    "id" : 605076677077659648,
    "created_at" : "2015-05-31 18:21:36 +0000",
    "user" : {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "protected" : false,
      "id_str" : "88655243",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/706508144160145410\/pKzknb5H_normal.jpg",
      "id" : 88655243,
      "verified" : false
    }
  },
  "id" : 605078520667238400,
  "created_at" : "2015-05-31 18:28:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 40, 55 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/c5yht2VdwP",
      "expanded_url" : "http:\/\/wp.me\/p3qkCB-1jm",
      "display_url" : "wp.me\/p3qkCB-1jm"
    } ]
  },
  "geo" : { },
  "id_str" : "604730048936087552",
  "text" : "Logic Quiz 2 http:\/\/t.co\/c5yht2VdwP via @GeoffreyJordan",
  "id" : 604730048936087552,
  "created_at" : "2015-05-30 19:24:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "john johnston",
      "screen_name" : "johnjohnston",
      "indices" : [ 3, 16 ],
      "id_str" : "7484192",
      "id" : 7484192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/fDrPJqDvry",
      "expanded_url" : "http:\/\/johnjohnston.info\/106\/a-touch-of-don\/",
      "display_url" : "johnjohnston.info\/106\/a-touch-of\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "604593725491322880",
  "text" : "RT @johnjohnston: A Touch of Don new blog post http:\/\/t.co\/fDrPJqDvry",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 29, 51 ],
        "url" : "http:\/\/t.co\/fDrPJqDvry",
        "expanded_url" : "http:\/\/johnjohnston.info\/106\/a-touch-of-don\/",
        "display_url" : "johnjohnston.info\/106\/a-touch-of\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "604592522548137984",
    "text" : "A Touch of Don new blog post http:\/\/t.co\/fDrPJqDvry",
    "id" : 604592522548137984,
    "created_at" : "2015-05-30 10:17:44 +0000",
    "user" : {
      "name" : "john johnston",
      "screen_name" : "johnjohnston",
      "protected" : false,
      "id_str" : "7484192",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/764409646526427136\/wENlgXJ3_normal.jpg",
      "id" : 7484192,
      "verified" : false
    }
  },
  "id" : 604593725491322880,
  "created_at" : "2015-05-30 10:22:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 3, 16 ],
      "id_str" : "88655243",
      "id" : 88655243
    }, {
      "name" : "teachers_as_workers",
      "screen_name" : "taw_sig",
      "indices" : [ 139, 140 ],
      "id_str" : "3152637711",
      "id" : 3152637711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 123, 140 ],
      "url" : "https:\/\/t.co\/CTIGfhxrV2",
      "expanded_url" : "https:\/\/www.facebook.com\/rose.bard\/posts\/10205106117027269",
      "display_url" : "facebook.com\/rose.bard\/post\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "604557938993336320",
  "text" : "RT @rosemerebard: My personal manifesto! Kind of tired of people denying the obvious for the sake of political correctness https:\/\/t.co\/CTI\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "teachers_as_workers",
        "screen_name" : "taw_sig",
        "indices" : [ 129, 137 ],
        "id_str" : "3152637711",
        "id" : 3152637711
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/CTIGfhxrV2",
        "expanded_url" : "https:\/\/www.facebook.com\/rose.bard\/posts\/10205106117027269",
        "display_url" : "facebook.com\/rose.bard\/post\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "604266294448381952",
    "text" : "My personal manifesto! Kind of tired of people denying the obvious for the sake of political correctness https:\/\/t.co\/CTIGfhxrV2 @taw_sig",
    "id" : 604266294448381952,
    "created_at" : "2015-05-29 12:41:25 +0000",
    "user" : {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "protected" : false,
      "id_str" : "88655243",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/706508144160145410\/pKzknb5H_normal.jpg",
      "id" : 88655243,
      "verified" : false
    }
  },
  "id" : 604557938993336320,
  "created_at" : "2015-05-30 08:00:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Noble",
      "screen_name" : "NewbieCELTA",
      "indices" : [ 3, 15 ],
      "id_str" : "2311153903",
      "id" : 2311153903
    }, {
      "name" : "TEFL Equity",
      "screen_name" : "TeflEquity",
      "indices" : [ 26, 37 ],
      "id_str" : "3217729433",
      "id" : 3217729433
    }, {
      "name" : "teachers_as_workers",
      "screen_name" : "taw_sig",
      "indices" : [ 136, 140 ],
      "id_str" : "3152637711",
      "id" : 3152637711
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELTchat",
      "indices" : [ 105, 113 ]
    }, {
      "text" : "KELTchat",
      "indices" : [ 114, 123 ]
    }, {
      "text" : "ELTchinwag",
      "indices" : [ 124, 135 ]
    }, {
      "text" : "NNEST",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/pXSdIwABV0",
      "expanded_url" : "https:\/\/fluiditycall.wordpress.com\/",
      "display_url" : "fluiditycall.wordpress.com"
    } ]
  },
  "geo" : { },
  "id_str" : "604556037132304384",
  "text" : "RT @NewbieCELTA: thinking @TeflEquity may have seen this https:\/\/t.co\/pXSdIwABV0 but if not, there it is #ELTchat #KELTchat #ELTchinwag @ta\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TEFL Equity",
        "screen_name" : "TeflEquity",
        "indices" : [ 9, 20 ],
        "id_str" : "3217729433",
        "id" : 3217729433
      }, {
        "name" : "teachers_as_workers",
        "screen_name" : "taw_sig",
        "indices" : [ 119, 127 ],
        "id_str" : "3152637711",
        "id" : 3152637711
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELTchat",
        "indices" : [ 88, 96 ]
      }, {
        "text" : "KELTchat",
        "indices" : [ 97, 106 ]
      }, {
        "text" : "ELTchinwag",
        "indices" : [ 107, 118 ]
      }, {
        "text" : "NNEST",
        "indices" : [ 128, 134 ]
      } ],
      "urls" : [ {
        "indices" : [ 40, 63 ],
        "url" : "https:\/\/t.co\/pXSdIwABV0",
        "expanded_url" : "https:\/\/fluiditycall.wordpress.com\/",
        "display_url" : "fluiditycall.wordpress.com"
      } ]
    },
    "geo" : { },
    "id_str" : "604545838300303360",
    "text" : "thinking @TeflEquity may have seen this https:\/\/t.co\/pXSdIwABV0 but if not, there it is #ELTchat #KELTchat #ELTchinwag @taw_sig #NNEST",
    "id" : 604545838300303360,
    "created_at" : "2015-05-30 07:12:14 +0000",
    "user" : {
      "name" : "Matthew Noble",
      "screen_name" : "NewbieCELTA",
      "protected" : false,
      "id_str" : "2311153903",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/596701364119437312\/aGLFxLe0_normal.jpg",
      "id" : 2311153903,
      "verified" : false
    }
  },
  "id" : 604556037132304384,
  "created_at" : "2015-05-30 07:52:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/aLn4vRWpvQ",
      "expanded_url" : "https:\/\/zcomm.org\/zmagazine\/golden-silences-in-the-propaganda-system\/",
      "display_url" : "zcomm.org\/zmagazine\/gold\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "604552141731188736",
  "text" : "Golden Silences in the Propaganda System By Edward S. Herman https:\/\/t.co\/aLn4vRWpvQ",
  "id" : 604552141731188736,
  "created_at" : "2015-05-30 07:37:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Kirk",
      "screen_name" : "stiivkirk",
      "indices" : [ 0, 10 ],
      "id_str" : "69068757",
      "id" : 69068757
    }, {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 11, 19 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "604314699350429697",
  "geo" : { },
  "id_str" : "604314977198043136",
  "in_reply_to_user_id" : 69068757,
  "text" : "@stiivkirk @seburnt ooh nice :)",
  "id" : 604314977198043136,
  "in_reply_to_status_id" : 604314699350429697,
  "created_at" : "2015-05-29 15:54:52 +0000",
  "in_reply_to_screen_name" : "stiivkirk",
  "in_reply_to_user_id_str" : "69068757",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "604313285320658945",
  "geo" : { },
  "id_str" : "604313409560141825",
  "in_reply_to_user_id" : 18602422,
  "text" : "@getgreatenglish oops *Marc",
  "id" : 604313409560141825,
  "in_reply_to_status_id" : 604313285320658945,
  "created_at" : "2015-05-29 15:48:39 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "604275337371852801",
  "geo" : { },
  "id_str" : "604313285320658945",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish cheers Mark, yes this interface it very good, the only hiccup is server speed, have a good w\/e :)",
  "id" : 604313285320658945,
  "in_reply_to_status_id" : 604275337371852801,
  "created_at" : "2015-05-29 15:48:09 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/fui9m3GCph",
      "expanded_url" : "http:\/\/leps.isi.edu\/fst\/step-all.php",
      "display_url" : "leps.isi.edu\/fst\/step-all.p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "603913716086775808",
  "text" : "portmanteau generator http:\/\/t.co\/fui9m3GCph h\/t corporalist",
  "id" : 603913716086775808,
  "created_at" : "2015-05-28 13:20:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 3, 18 ],
      "id_str" : "334332424",
      "id" : 334332424
    }, {
      "name" : "British Council ELT",
      "screen_name" : "bceltons",
      "indices" : [ 20, 29 ],
      "id_str" : "110726613",
      "id" : 110726613
    }, {
      "name" : "Sue Lyon-Jones",
      "screen_name" : "esolcourses",
      "indices" : [ 30, 42 ],
      "id_str" : "34321100",
      "id" : 34321100
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603672322902511616",
  "text" : "RT @GeoffreyJordan: @bceltons @esolcourses Dear oh dear: \"a red carpet interviewer at the ELT Oscars\". You're all raving mad!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "British Council ELT",
        "screen_name" : "bceltons",
        "indices" : [ 0, 9 ],
        "id_str" : "110726613",
        "id" : 110726613
      }, {
        "name" : "Sue Lyon-Jones",
        "screen_name" : "esolcourses",
        "indices" : [ 10, 22 ],
        "id_str" : "34321100",
        "id" : 34321100
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "603489329898516481",
    "geo" : { },
    "id_str" : "603536641895112706",
    "in_reply_to_user_id" : 110726613,
    "text" : "@bceltons @esolcourses Dear oh dear: \"a red carpet interviewer at the ELT Oscars\". You're all raving mad!",
    "id" : 603536641895112706,
    "in_reply_to_status_id" : 603489329898516481,
    "created_at" : "2015-05-27 12:22:03 +0000",
    "in_reply_to_screen_name" : "bceltons",
    "in_reply_to_user_id_str" : "110726613",
    "user" : {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "protected" : false,
      "id_str" : "334332424",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/455317817537986561\/SD4wNKO3_normal.jpeg",
      "id" : 334332424,
      "verified" : false
    }
  },
  "id" : 603672322902511616,
  "created_at" : "2015-05-27 21:21:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dale Coulter",
      "screen_name" : "dalecoulter",
      "indices" : [ 0, 12 ],
      "id_str" : "24046458",
      "id" : 24046458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603625133236957184",
  "geo" : { },
  "id_str" : "603638137785622530",
  "in_reply_to_user_id" : 24046458,
  "text" : "@dalecoulter that's er specific :) what do u want to use them for?",
  "id" : 603638137785622530,
  "in_reply_to_status_id" : 603625133236957184,
  "created_at" : "2015-05-27 19:05:21 +0000",
  "in_reply_to_screen_name" : "dalecoulter",
  "in_reply_to_user_id_str" : "24046458",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dale Coulter",
      "screen_name" : "dalecoulter",
      "indices" : [ 0, 12 ],
      "id_str" : "24046458",
      "id" : 24046458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603589673362038786",
  "geo" : { },
  "id_str" : "603620754224189440",
  "in_reply_to_user_id" : 24046458,
  "text" : "@dalecoulter pleasure, u got a project\/s in mind?",
  "id" : 603620754224189440,
  "in_reply_to_status_id" : 603589673362038786,
  "created_at" : "2015-05-27 17:56:17 +0000",
  "in_reply_to_screen_name" : "dalecoulter",
  "in_reply_to_user_id_str" : "24046458",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dale Coulter",
      "screen_name" : "dalecoulter",
      "indices" : [ 0, 12 ],
      "id_str" : "24046458",
      "id" : 24046458
    }, {
      "name" : "Mike S. Boyle",
      "screen_name" : "heyboyle",
      "indices" : [ 64, 73 ],
      "id_str" : "612840231",
      "id" : 612840231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/6u1gBCDweK",
      "expanded_url" : "http:\/\/teachyourselftocode.com\/",
      "display_url" : "teachyourselftocode.com"
    } ]
  },
  "in_reply_to_status_id_str" : "603585930025377792",
  "geo" : { },
  "id_str" : "603589112566837250",
  "in_reply_to_user_id" : 24046458,
  "text" : "@dalecoulter hi have a look at this http:\/\/t.co\/6u1gBCDweK also @heyboyle has written a setup python\/nltk post",
  "id" : 603589112566837250,
  "in_reply_to_status_id" : 603585930025377792,
  "created_at" : "2015-05-27 15:50:33 +0000",
  "in_reply_to_screen_name" : "dalecoulter",
  "in_reply_to_user_id_str" : "24046458",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Cook",
      "screen_name" : "Jonathan_K_Cook",
      "indices" : [ 3, 19 ],
      "id_str" : "2459644405",
      "id" : 2459644405
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FIFA",
      "indices" : [ 55, 60 ]
    }, {
      "text" : "Israel",
      "indices" : [ 98, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/A6hT0kCyIn",
      "expanded_url" : "https:\/\/shar.es\/1rBBw9",
      "display_url" : "shar.es\/1rBBw9"
    } ]
  },
  "geo" : { },
  "id_str" : "603574722207547392",
  "text" : "RT @Jonathan_K_Cook: Coincidence? US orders arrests of #FIFA officials as world body mulls giving #Israel boot | Jonathan Cook's Blog https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FIFA",
        "indices" : [ 34, 39 ]
      }, {
        "text" : "Israel",
        "indices" : [ 77, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/A6hT0kCyIn",
        "expanded_url" : "https:\/\/shar.es\/1rBBw9",
        "display_url" : "shar.es\/1rBBw9"
      } ]
    },
    "geo" : { },
    "id_str" : "603546795873042432",
    "text" : "Coincidence? US orders arrests of #FIFA officials as world body mulls giving #Israel boot | Jonathan Cook's Blog https:\/\/t.co\/A6hT0kCyIn",
    "id" : 603546795873042432,
    "created_at" : "2015-05-27 13:02:24 +0000",
    "user" : {
      "name" : "Jonathan Cook",
      "screen_name" : "Jonathan_K_Cook",
      "protected" : false,
      "id_str" : "2459644405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458948119749619713\/8ed1EDoY_normal.jpeg",
      "id" : 2459644405,
      "verified" : false
    }
  },
  "id" : 603574722207547392,
  "created_at" : "2015-05-27 14:53:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603522379067879425",
  "geo" : { },
  "id_str" : "603522733138386944",
  "in_reply_to_user_id" : 44631065,
  "text" : "@HadaLitim ha no wrong wording a tweet &amp; run :) not actually tweeting and running :)",
  "id" : 603522733138386944,
  "in_reply_to_status_id" : 603522379067879425,
  "created_at" : "2015-05-27 11:26:47 +0000",
  "in_reply_to_screen_name" : "Hada_ELT",
  "in_reply_to_user_id_str" : "44631065",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenys Hanson",
      "screen_name" : "GlenysHanson",
      "indices" : [ 11, 24 ],
      "id_str" : "527238447",
      "id" : 527238447
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603521772982501376",
  "geo" : { },
  "id_str" : "603522196544323584",
  "in_reply_to_user_id" : 44631065,
  "text" : "@HadaLitim @GlenysHanson thx, tweeting &amp; running though, have a good chat :)",
  "id" : 603522196544323584,
  "in_reply_to_status_id" : 603521772982501376,
  "created_at" : "2015-05-27 11:24:39 +0000",
  "in_reply_to_screen_name" : "Hada_ELT",
  "in_reply_to_user_id_str" : "44631065",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenys Hanson",
      "screen_name" : "GlenysHanson",
      "indices" : [ 0, 13 ],
      "id_str" : "527238447",
      "id" : 527238447
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 84, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/79ZJElIeNJ",
      "expanded_url" : "http:\/\/reflectiveteachingreflectivelearning.com\/2015\/02\/05\/kaboom-the-explosive-team-review-game-with-an-added-twist\/",
      "display_url" : "\u2026lectiveteachingreflectivelearning.com\/2015\/02\/05\/kab\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "603517871726174208",
  "geo" : { },
  "id_str" : "603521611027849216",
  "in_reply_to_user_id" : 527238447,
  "text" : "@GlenysHanson (vocab) games are good for TOEIC e.g. this one http:\/\/t.co\/79ZJElIeNJ #eltchat",
  "id" : 603521611027849216,
  "in_reply_to_status_id" : 603517871726174208,
  "created_at" : "2015-05-27 11:22:19 +0000",
  "in_reply_to_screen_name" : "GlenysHanson",
  "in_reply_to_user_id_str" : "527238447",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sophia Khan",
      "screen_name" : "SophiaKhan4",
      "indices" : [ 0, 12 ],
      "id_str" : "351390617",
      "id" : 351390617
    }, {
      "name" : "Damien Munchip",
      "screen_name" : "chimponobo",
      "indices" : [ 13, 24 ],
      "id_str" : "327186537",
      "id" : 327186537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603502684805734400",
  "geo" : { },
  "id_str" : "603506994364993537",
  "in_reply_to_user_id" : 351390617,
  "text" : "@SophiaKhan4 @chimponobo can access it fine, maybe restart your browser?",
  "id" : 603506994364993537,
  "in_reply_to_status_id" : 603502684805734400,
  "created_at" : "2015-05-27 10:24:14 +0000",
  "in_reply_to_screen_name" : "SophiaKhan4",
  "in_reply_to_user_id_str" : "351390617",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 3, 12 ],
      "id_str" : "134211317",
      "id" : 134211317
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/josipa74\/status\/603496141439803392\/photo\/1",
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/iCEpHyH1cd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGAMitJWIAEKGym.jpg",
      "id_str" : "603496140441526273",
      "id" : 603496140441526273,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGAMitJWIAEKGym.jpg",
      "sizes" : [ {
        "h" : 313,
        "resize" : "fit",
        "w" : 489
      }, {
        "h" : 218,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 313,
        "resize" : "fit",
        "w" : 489
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 313,
        "resize" : "fit",
        "w" : 489
      } ],
      "display_url" : "pic.twitter.com\/iCEpHyH1cd"
    } ],
    "hashtags" : [ {
      "text" : "ELT",
      "indices" : [ 28, 32 ]
    }, {
      "text" : "tefl",
      "indices" : [ 49, 54 ]
    }, {
      "text" : "efl",
      "indices" : [ 55, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/p7gSuzxeH2",
      "expanded_url" : "http:\/\/goo.gl\/ZfdAo4",
      "display_url" : "goo.gl\/ZfdAo4"
    } ]
  },
  "geo" : { },
  "id_str" : "603497959720890368",
  "text" : "RT @josipa74: Schizophrenic #ELT Some questions. #tefl #efl http:\/\/t.co\/p7gSuzxeH2 http:\/\/t.co\/iCEpHyH1cd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/josipa74\/status\/603496141439803392\/photo\/1",
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/iCEpHyH1cd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGAMitJWIAEKGym.jpg",
        "id_str" : "603496140441526273",
        "id" : 603496140441526273,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGAMitJWIAEKGym.jpg",
        "sizes" : [ {
          "h" : 313,
          "resize" : "fit",
          "w" : 489
        }, {
          "h" : 218,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 313,
          "resize" : "fit",
          "w" : 489
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 313,
          "resize" : "fit",
          "w" : 489
        } ],
        "display_url" : "pic.twitter.com\/iCEpHyH1cd"
      } ],
      "hashtags" : [ {
        "text" : "ELT",
        "indices" : [ 14, 18 ]
      }, {
        "text" : "tefl",
        "indices" : [ 35, 40 ]
      }, {
        "text" : "efl",
        "indices" : [ 41, 45 ]
      } ],
      "urls" : [ {
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/p7gSuzxeH2",
        "expanded_url" : "http:\/\/goo.gl\/ZfdAo4",
        "display_url" : "goo.gl\/ZfdAo4"
      } ]
    },
    "geo" : { },
    "id_str" : "603496141439803392",
    "text" : "Schizophrenic #ELT Some questions. #tefl #efl http:\/\/t.co\/p7gSuzxeH2 http:\/\/t.co\/iCEpHyH1cd",
    "id" : 603496141439803392,
    "created_at" : "2015-05-27 09:41:07 +0000",
    "user" : {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "protected" : false,
      "id_str" : "134211317",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/526853654377021441\/MtEFhYIs_normal.jpeg",
      "id" : 134211317,
      "verified" : false
    }
  },
  "id" : 603497959720890368,
  "created_at" : "2015-05-27 09:48:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Gianfranco Conti",
      "screen_name" : "gianfrancocont9",
      "indices" : [ 122, 138 ],
      "id_str" : "2347690794",
      "id" : 2347690794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/X42xlMV55l",
      "expanded_url" : "http:\/\/wp.me\/p4E5tZ-7c",
      "display_url" : "wp.me\/p4E5tZ-7c"
    } ]
  },
  "geo" : { },
  "id_str" : "603487807479361536",
  "text" : "Of SAMR and SAMRitans \u2013 How the adoption of the SAMR model as a reference framework may be de\u2026 http:\/\/t.co\/X42xlMV55l via @gianfrancocont9",
  "id" : 603487807479361536,
  "created_at" : "2015-05-27 09:08:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/Rfs0vlh8gC",
      "expanded_url" : "https:\/\/www.academia.edu\/12620062\/Improving_Feedback_using_Text_Expansion_Software",
      "display_url" : "academia.edu\/12620062\/Impro\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "603476652212035584",
  "text" : "Improving Feedback using Text Expansion Software https:\/\/t.co\/Rfs0vlh8gC by Malcom Prentice",
  "id" : 603476652212035584,
  "created_at" : "2015-05-27 08:23:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenys Hanson",
      "screen_name" : "GlenysHanson",
      "indices" : [ 0, 13 ],
      "id_str" : "527238447",
      "id" : 527238447
    }, {
      "name" : "Elizabeth Anne",
      "screen_name" : "eannegrenoble",
      "indices" : [ 51, 65 ],
      "id_str" : "19869781",
      "id" : 19869781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603463896616312832",
  "geo" : { },
  "id_str" : "603465247417094144",
  "in_reply_to_user_id" : 527238447,
  "text" : "@GlenysHanson guess would need to trial it, it was @eannegrenoble btw who posted link",
  "id" : 603465247417094144,
  "in_reply_to_status_id" : 603463896616312832,
  "created_at" : "2015-05-27 07:38:21 +0000",
  "in_reply_to_screen_name" : "GlenysHanson",
  "in_reply_to_user_id_str" : "527238447",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Damien Munchip",
      "screen_name" : "chimponobo",
      "indices" : [ 3, 14 ],
      "id_str" : "327186537",
      "id" : 327186537
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/chimponobo\/status\/603373357346742272\/photo\/1",
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/9HUaDofkM3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CF-cWeqXIAE0djd.jpg",
      "id_str" : "603372785092730881",
      "id" : 603372785092730881,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CF-cWeqXIAE0djd.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/9HUaDofkM3"
    } ],
    "hashtags" : [ {
      "text" : "auselt",
      "indices" : [ 68, 75 ]
    }, {
      "text" : "TESOL",
      "indices" : [ 76, 82 ]
    }, {
      "text" : "EFL",
      "indices" : [ 83, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/hjAl7TuVN1",
      "expanded_url" : "http:\/\/www.tecsquared.com\/node\/92",
      "display_url" : "tecsquared.com\/node\/92"
    } ]
  },
  "geo" : { },
  "id_str" : "603460098053255168",
  "text" : "RT @chimponobo: Part 2: Death of a Classroom\nhttp:\/\/t.co\/hjAl7TuVN1 #auselt #TESOL #EFL http:\/\/t.co\/9HUaDofkM3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/chimponobo\/status\/603373357346742272\/photo\/1",
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/9HUaDofkM3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CF-cWeqXIAE0djd.jpg",
        "id_str" : "603372785092730881",
        "id" : 603372785092730881,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CF-cWeqXIAE0djd.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/9HUaDofkM3"
      } ],
      "hashtags" : [ {
        "text" : "auselt",
        "indices" : [ 52, 59 ]
      }, {
        "text" : "TESOL",
        "indices" : [ 60, 66 ]
      }, {
        "text" : "EFL",
        "indices" : [ 67, 71 ]
      } ],
      "urls" : [ {
        "indices" : [ 29, 51 ],
        "url" : "http:\/\/t.co\/hjAl7TuVN1",
        "expanded_url" : "http:\/\/www.tecsquared.com\/node\/92",
        "display_url" : "tecsquared.com\/node\/92"
      } ]
    },
    "geo" : { },
    "id_str" : "603373357346742272",
    "text" : "Part 2: Death of a Classroom\nhttp:\/\/t.co\/hjAl7TuVN1 #auselt #TESOL #EFL http:\/\/t.co\/9HUaDofkM3",
    "id" : 603373357346742272,
    "created_at" : "2015-05-27 01:33:13 +0000",
    "user" : {
      "name" : "Damien Munchip",
      "screen_name" : "chimponobo",
      "protected" : false,
      "id_str" : "327186537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703504370713780224\/Ffd779uj_normal.jpg",
      "id" : 327186537,
      "verified" : false
    }
  },
  "id" : 603460098053255168,
  "created_at" : "2015-05-27 07:17:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil Chappell",
      "screen_name" : "TESOLatMQ",
      "indices" : [ 0, 10 ],
      "id_str" : "326498171",
      "id" : 326498171
    }, {
      "name" : "Richard Ingold",
      "screen_name" : "RichardIngold",
      "indices" : [ 11, 25 ],
      "id_str" : "2561140580",
      "id" : 2561140580
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603322239811854336",
  "geo" : { },
  "id_str" : "603338317057392640",
  "in_reply_to_user_id" : 326498171,
  "text" : "@TESOLatMQ @RichardIngold open access?",
  "id" : 603338317057392640,
  "in_reply_to_status_id" : 603322239811854336,
  "created_at" : "2015-05-26 23:13:58 +0000",
  "in_reply_to_screen_name" : "TESOLatMQ",
  "in_reply_to_user_id_str" : "326498171",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Caines",
      "screen_name" : "cainesap",
      "indices" : [ 0, 9 ],
      "id_str" : "578898729",
      "id" : 578898729
    }, {
      "name" : "John Cooper",
      "screen_name" : "J0hnB0yC",
      "indices" : [ 35, 44 ],
      "id_str" : "1908471050",
      "id" : 1908471050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603329507462897664",
  "geo" : { },
  "id_str" : "603331618024067072",
  "in_reply_to_user_id" : 578898729,
  "text" : "@cainesap thanks for heads up and  @J0hnB0yC thanks for writing it :)",
  "id" : 603331618024067072,
  "in_reply_to_status_id" : 603329507462897664,
  "created_at" : "2015-05-26 22:47:21 +0000",
  "in_reply_to_screen_name" : "cainesap",
  "in_reply_to_user_id_str" : "578898729",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 3, 18 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/GeoffreyJordan\/status\/603327890814435329\/photo\/1",
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/7CUPGesUda",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CF9zhO2UgAAV3y8.jpg",
      "id_str" : "603327889849745408",
      "id" : 603327889849745408,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CF9zhO2UgAAV3y8.jpg",
      "sizes" : [ {
        "h" : 126,
        "resize" : "fit",
        "w" : 399
      }, {
        "h" : 107,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 126,
        "resize" : "fit",
        "w" : 399
      }, {
        "h" : 126,
        "resize" : "fit",
        "w" : 399
      }, {
        "h" : 126,
        "resize" : "crop",
        "w" : 126
      } ],
      "display_url" : "pic.twitter.com\/7CUPGesUda"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/Pw69uS6iba",
      "expanded_url" : "https:\/\/canlloparot.wordpress.com\/2015\/05\/26\/critical-thinking-a-few-thoughts",
      "display_url" : "canlloparot.wordpress.com\/2015\/05\/26\/cri\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "603331445281652736",
  "text" : "RT @GeoffreyJordan: Critical Thinking: A Few\u00A0Thoughts https:\/\/t.co\/Pw69uS6iba http:\/\/t.co\/7CUPGesUda",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/GeoffreyJordan\/status\/603327890814435329\/photo\/1",
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/7CUPGesUda",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CF9zhO2UgAAV3y8.jpg",
        "id_str" : "603327889849745408",
        "id" : 603327889849745408,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CF9zhO2UgAAV3y8.jpg",
        "sizes" : [ {
          "h" : 126,
          "resize" : "fit",
          "w" : 399
        }, {
          "h" : 107,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 126,
          "resize" : "fit",
          "w" : 399
        }, {
          "h" : 126,
          "resize" : "fit",
          "w" : 399
        }, {
          "h" : 126,
          "resize" : "crop",
          "w" : 126
        } ],
        "display_url" : "pic.twitter.com\/7CUPGesUda"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 34, 57 ],
        "url" : "https:\/\/t.co\/Pw69uS6iba",
        "expanded_url" : "https:\/\/canlloparot.wordpress.com\/2015\/05\/26\/critical-thinking-a-few-thoughts",
        "display_url" : "canlloparot.wordpress.com\/2015\/05\/26\/cri\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "603327890814435329",
    "text" : "Critical Thinking: A Few\u00A0Thoughts https:\/\/t.co\/Pw69uS6iba http:\/\/t.co\/7CUPGesUda",
    "id" : 603327890814435329,
    "created_at" : "2015-05-26 22:32:33 +0000",
    "user" : {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "protected" : false,
      "id_str" : "334332424",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/455317817537986561\/SD4wNKO3_normal.jpeg",
      "id" : 334332424,
      "verified" : false
    }
  },
  "id" : 603331445281652736,
  "created_at" : "2015-05-26 22:46:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cooper",
      "screen_name" : "J0hnB0yC",
      "indices" : [ 3, 12 ],
      "id_str" : "1908471050",
      "id" : 1908471050
    }, {
      "name" : "Andrew Caines",
      "screen_name" : "cainesap",
      "indices" : [ 14, 23 ],
      "id_str" : "578898729",
      "id" : 578898729
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/KAiIiwYjWu",
      "expanded_url" : "http:\/\/ow.ly\/NssiW",
      "display_url" : "ow.ly\/NssiW"
    } ]
  },
  "geo" : { },
  "id_str" : "603326365912432641",
  "text" : "RT @J0hnB0yC: @cainesap In memory of Adam Kilgarriff, you might like : a small tribute : http:\/\/t.co\/KAiIiwYjWu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Caines",
        "screen_name" : "cainesap",
        "indices" : [ 0, 9 ],
        "id_str" : "578898729",
        "id" : 578898729
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/KAiIiwYjWu",
        "expanded_url" : "http:\/\/ow.ly\/NssiW",
        "display_url" : "ow.ly\/NssiW"
      } ]
    },
    "in_reply_to_status_id_str" : "600390398834520064",
    "geo" : { },
    "id_str" : "603278649001910274",
    "in_reply_to_user_id" : 578898729,
    "text" : "@cainesap In memory of Adam Kilgarriff, you might like : a small tribute : http:\/\/t.co\/KAiIiwYjWu",
    "id" : 603278649001910274,
    "in_reply_to_status_id" : 600390398834520064,
    "created_at" : "2015-05-26 19:16:52 +0000",
    "in_reply_to_screen_name" : "cainesap",
    "in_reply_to_user_id_str" : "578898729",
    "user" : {
      "name" : "John Cooper",
      "screen_name" : "J0hnB0yC",
      "protected" : false,
      "id_str" : "1908471050",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000511185186\/721f04db7c6ab69f5347b18cf9f5170a_normal.jpeg",
      "id" : 1908471050,
      "verified" : false
    }
  },
  "id" : 603326365912432641,
  "created_at" : "2015-05-26 22:26:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 0, 15 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603281114749378562",
  "in_reply_to_user_id" : 334332424,
  "text" : "@GeoffreyJordan happy birthday :) sounds like a good one",
  "id" : 603281114749378562,
  "created_at" : "2015-05-26 19:26:40 +0000",
  "in_reply_to_screen_name" : "GeoffreyJordan",
  "in_reply_to_user_id_str" : "334332424",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vedrana Vojkovi\u0107",
      "screen_name" : "Ven_VVE",
      "indices" : [ 0, 8 ],
      "id_str" : "270839603",
      "id" : 270839603
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603123345945661440",
  "geo" : { },
  "id_str" : "603274463749251073",
  "in_reply_to_user_id" : 270839603,
  "text" : "@Ven_VVE thats nice to hear thanks :) might change it again soon though!",
  "id" : 603274463749251073,
  "in_reply_to_status_id" : 603123345945661440,
  "created_at" : "2015-05-26 19:00:15 +0000",
  "in_reply_to_screen_name" : "Ven_VVE",
  "in_reply_to_user_id_str" : "270839603",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/POZaUVNmgd",
      "expanded_url" : "http:\/\/readersupportednews.org\/news-section2\/318-66\/30365-focus-noam-chomsky-are-the-media-still-manufacturing-consent",
      "display_url" : "readersupportednews.org\/news-section2\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "602978449725255682",
  "text" : "FOCUS | Noam Chomsky: Are the Media Still 'Manufacturing Consent'? http:\/\/t.co\/POZaUVNmgd",
  "id" : 602978449725255682,
  "created_at" : "2015-05-25 23:23:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eily Murphy",
      "screen_name" : "eilymurphy",
      "indices" : [ 0, 11 ],
      "id_str" : "111091623",
      "id" : 111091623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602871048598589441",
  "in_reply_to_user_id" : 111091623,
  "text" : "@eilymurphy thanks for RT :)",
  "id" : 602871048598589441,
  "created_at" : "2015-05-25 16:17:13 +0000",
  "in_reply_to_screen_name" : "eilymurphy",
  "in_reply_to_user_id_str" : "111091623",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vedrana Vojkovi\u0107",
      "screen_name" : "Ven_VVE",
      "indices" : [ 0, 8 ],
      "id_str" : "270839603",
      "id" : 270839603
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "602756657597255680",
  "geo" : { },
  "id_str" : "602763944525180928",
  "in_reply_to_user_id" : 270839603,
  "text" : "@Ven_VVE thanks Vedrana :)",
  "id" : 602763944525180928,
  "in_reply_to_status_id" : 602756657597255680,
  "created_at" : "2015-05-25 09:11:37 +0000",
  "in_reply_to_screen_name" : "Ven_VVE",
  "in_reply_to_user_id_str" : "270839603",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LINGUIST List",
      "screen_name" : "linguistlist",
      "indices" : [ 0, 13 ],
      "id_str" : "104943598",
      "id" : 104943598
    }, {
      "name" : "David Harbinson",
      "screen_name" : "DavidHarbinson",
      "indices" : [ 14, 29 ],
      "id_str" : "853078675",
      "id" : 853078675
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "602741435612311552",
  "geo" : { },
  "id_str" : "602763164778897409",
  "in_reply_to_user_id" : 104943598,
  "text" : "@linguistlist @DavidHarbinson Linguistic Innovators Corpus; search variants of multi-cultural london english?",
  "id" : 602763164778897409,
  "in_reply_to_status_id" : 602741435612311552,
  "created_at" : "2015-05-25 09:08:31 +0000",
  "in_reply_to_screen_name" : "linguistlist",
  "in_reply_to_user_id_str" : "104943598",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted O'Neill (DB-\u7ADC\u725B)",
      "screen_name" : "gotanda",
      "indices" : [ 0, 8 ],
      "id_str" : "9875912",
      "id" : 9875912
    }, {
      "name" : "Scott Thornbury",
      "screen_name" : "thornburyscott",
      "indices" : [ 9, 24 ],
      "id_str" : "23090474",
      "id" : 23090474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "602724257227874304",
  "geo" : { },
  "id_str" : "602753642463105024",
  "in_reply_to_user_id" : 9875912,
  "text" : "@gotanda @thornburyscott these are true (hands on) hip-sters :)",
  "id" : 602753642463105024,
  "in_reply_to_status_id" : 602724257227874304,
  "created_at" : "2015-05-25 08:30:41 +0000",
  "in_reply_to_screen_name" : "gotanda",
  "in_reply_to_user_id_str" : "9875912",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "larry cuban",
      "screen_name" : "CubanLarry",
      "indices" : [ 74, 85 ],
      "id_str" : "2324494104",
      "id" : 2324494104
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/QLVvqRzWeF",
      "expanded_url" : "http:\/\/wp.me\/pBm7c-2rA",
      "display_url" : "wp.me\/pBm7c-2rA"
    } ]
  },
  "geo" : { },
  "id_str" : "602748426468630528",
  "text" : "A Plea to Ed Tech Entrepreneurs (Randy Weiner) http:\/\/t.co\/QLVvqRzWeF via @CubanLarry",
  "id" : 602748426468630528,
  "created_at" : "2015-05-25 08:09:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 0, 13 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602747281033580544",
  "in_reply_to_user_id" : 88655243,
  "text" : "@rosemerebard thanks for RTs Rose :)",
  "id" : 602747281033580544,
  "created_at" : "2015-05-25 08:05:24 +0000",
  "in_reply_to_screen_name" : "rosemerebard",
  "in_reply_to_user_id_str" : "88655243",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dayle Major",
      "screen_name" : "daylemajor",
      "indices" : [ 0, 11 ],
      "id_str" : "10052752",
      "id" : 10052752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "602725493859700737",
  "geo" : { },
  "id_str" : "602747095704064000",
  "in_reply_to_user_id" : 10052752,
  "text" : "@daylemajor thanks :)",
  "id" : 602747095704064000,
  "in_reply_to_status_id" : 602725493859700737,
  "created_at" : "2015-05-25 08:04:40 +0000",
  "in_reply_to_screen_name" : "daylemajor",
  "in_reply_to_user_id_str" : "10052752",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 52, 62 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/x3XtQ7jadd",
      "expanded_url" : "http:\/\/dissidentvoice.org\/2014\/10\/beyond-critical-thinking\/",
      "display_url" : "dissidentvoice.org\/2014\/10\/beyond\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "602746866443358208",
  "text" : "Beyond Critical Thinking http:\/\/t.co\/x3XtQ7jadd h\/t @medialens board",
  "id" : 602746866443358208,
  "created_at" : "2015-05-25 08:03:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Claire Hardaker",
      "screen_name" : "DrClaireH",
      "indices" : [ 3, 13 ],
      "id_str" : "237842162",
      "id" : 237842162
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/DrClaireH\/status\/602567338291003392\/photo\/1",
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/1pPhbUaHKv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFy_zF0W8AAfUhB.jpg",
      "id_str" : "602567334616821760",
      "id" : 602567334616821760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFy_zF0W8AAfUhB.jpg",
      "sizes" : [ {
        "h" : 167,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 250,
        "resize" : "fit",
        "w" : 509
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 250,
        "resize" : "fit",
        "w" : 509
      }, {
        "h" : 250,
        "resize" : "fit",
        "w" : 509
      } ],
      "display_url" : "pic.twitter.com\/1pPhbUaHKv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602568723279564800",
  "text" : "RT @DrClaireH: The proper etiquette for using \"I shit you not\" in formal academic writing: http:\/\/t.co\/1pPhbUaHKv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/DrClaireH\/status\/602567338291003392\/photo\/1",
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/1pPhbUaHKv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFy_zF0W8AAfUhB.jpg",
        "id_str" : "602567334616821760",
        "id" : 602567334616821760,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFy_zF0W8AAfUhB.jpg",
        "sizes" : [ {
          "h" : 167,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 250,
          "resize" : "fit",
          "w" : 509
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 250,
          "resize" : "fit",
          "w" : 509
        }, {
          "h" : 250,
          "resize" : "fit",
          "w" : 509
        } ],
        "display_url" : "pic.twitter.com\/1pPhbUaHKv"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "602567338291003392",
    "text" : "The proper etiquette for using \"I shit you not\" in formal academic writing: http:\/\/t.co\/1pPhbUaHKv",
    "id" : 602567338291003392,
    "created_at" : "2015-05-24 20:10:23 +0000",
    "user" : {
      "name" : "Dr Claire Hardaker",
      "screen_name" : "DrClaireH",
      "protected" : false,
      "id_str" : "237842162",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744470254177390592\/ZhYTy0JE_normal.jpg",
      "id" : 237842162,
      "verified" : false
    }
  },
  "id" : 602568723279564800,
  "created_at" : "2015-05-24 20:15:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 81, 92 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 93, 101 ]
    }, {
      "text" : "keltchat",
      "indices" : [ 102, 111 ]
    }, {
      "text" : "eltchinwag",
      "indices" : [ 112, 123 ]
    }, {
      "text" : "auselt",
      "indices" : [ 124, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/zd3wsW2WhN",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-X9",
      "display_url" : "wp.me\/pgHyE-X9"
    } ]
  },
  "geo" : { },
  "id_str" : "602541316833189888",
  "text" : "Skylight interview with Gill Francis &amp; Andy Dickinson http:\/\/t.co\/zd3wsW2WhN #corpusmooc #eltchat #keltchat #eltchinwag #auselt",
  "id" : 602541316833189888,
  "created_at" : "2015-05-24 18:26:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gert biesta",
      "screen_name" : "gbiesta",
      "indices" : [ 3, 11 ],
      "id_str" : "19742565",
      "id" : 19742565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/loCg8yl5Sy",
      "expanded_url" : "http:\/\/www.tandfonline.com\/doi\/full\/10.1080\/00131857.2015.1041442",
      "display_url" : "tandfonline.com\/doi\/full\/10.10\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "602498101161648128",
  "text" : "RT @gbiesta: new article just out (open access) \u201CThe Rediscovery of Teaching\u201D http:\/\/t.co\/loCg8yl5Sy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/loCg8yl5Sy",
        "expanded_url" : "http:\/\/www.tandfonline.com\/doi\/full\/10.1080\/00131857.2015.1041442",
        "display_url" : "tandfonline.com\/doi\/full\/10.10\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "600412604331380737",
    "text" : "new article just out (open access) \u201CThe Rediscovery of Teaching\u201D http:\/\/t.co\/loCg8yl5Sy",
    "id" : 600412604331380737,
    "created_at" : "2015-05-18 21:28:14 +0000",
    "user" : {
      "name" : "gert biesta",
      "screen_name" : "gbiesta",
      "protected" : false,
      "id_str" : "19742565",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/552792018749906945\/R4WKREy0_normal.jpeg",
      "id" : 19742565,
      "verified" : false
    }
  },
  "id" : 602498101161648128,
  "created_at" : "2015-05-24 15:35:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eily Murphy",
      "screen_name" : "eilymurphy",
      "indices" : [ 0, 11 ],
      "id_str" : "111091623",
      "id" : 111091623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "602406880883974144",
  "geo" : { },
  "id_str" : "602411171686260736",
  "in_reply_to_user_id" : 111091623,
  "text" : "@eilymurphy sure or pop some thoughts\/Qs on G+ CL site",
  "id" : 602411171686260736,
  "in_reply_to_status_id" : 602406880883974144,
  "created_at" : "2015-05-24 09:49:50 +0000",
  "in_reply_to_screen_name" : "eilymurphy",
  "in_reply_to_user_id_str" : "111091623",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eily Murphy",
      "screen_name" : "eilymurphy",
      "indices" : [ 3, 14 ],
      "id_str" : "111091623",
      "id" : 111091623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/OZOQcx5hdT",
      "expanded_url" : "http:\/\/bit.ly\/1Ke6kcN",
      "display_url" : "bit.ly\/1Ke6kcN"
    } ]
  },
  "geo" : { },
  "id_str" : "602401998118526976",
  "text" : "RT @eilymurphy: Getting into Academic Corpora | Jennifer MacDonald http:\/\/t.co\/OZOQcx5hdT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\" rel=\"nofollow\"\u003EEchofon  Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 73 ],
        "url" : "http:\/\/t.co\/OZOQcx5hdT",
        "expanded_url" : "http:\/\/bit.ly\/1Ke6kcN",
        "display_url" : "bit.ly\/1Ke6kcN"
      } ]
    },
    "geo" : { },
    "id_str" : "602395307813527552",
    "text" : "Getting into Academic Corpora | Jennifer MacDonald http:\/\/t.co\/OZOQcx5hdT",
    "id" : 602395307813527552,
    "created_at" : "2015-05-24 08:46:48 +0000",
    "user" : {
      "name" : "Eily Murphy",
      "screen_name" : "eilymurphy",
      "protected" : false,
      "id_str" : "111091623",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746422529405894656\/gSFQlPqA_normal.jpg",
      "id" : 111091623,
      "verified" : false
    }
  },
  "id" : 602401998118526976,
  "created_at" : "2015-05-24 09:13:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eily Murphy",
      "screen_name" : "eilymurphy",
      "indices" : [ 0, 11 ],
      "id_str" : "111091623",
      "id" : 111091623
    }, {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "indices" : [ 12, 24 ],
      "id_str" : "192437743",
      "id" : 192437743
    }, {
      "name" : "Jennifer MacDonald",
      "screen_name" : "JenMac_ESL",
      "indices" : [ 25, 36 ],
      "id_str" : "608800026",
      "id" : 608800026
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "602379313422405632",
  "geo" : { },
  "id_str" : "602401896838471682",
  "in_reply_to_user_id" : 111091623,
  "text" : "@eilymurphy @nathanghall @JenMac_ESL with 1-1 sts after only showing it once they got it, they only baulked at the concordance lines",
  "id" : 602401896838471682,
  "in_reply_to_status_id" : 602379313422405632,
  "created_at" : "2015-05-24 09:12:58 +0000",
  "in_reply_to_screen_name" : "eilymurphy",
  "in_reply_to_user_id_str" : "111091623",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "indices" : [ 0, 12 ],
      "id_str" : "192437743",
      "id" : 192437743
    }, {
      "name" : "Jennifer MacDonald",
      "screen_name" : "JenMac_ESL",
      "indices" : [ 13, 24 ],
      "id_str" : "608800026",
      "id" : 608800026
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/ZSUeNGlkq0",
      "expanded_url" : "http:\/\/flax.nzdl.org\/greenstone3\/flax",
      "display_url" : "flax.nzdl.org\/greenstone3\/fl\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "602219357507289088",
  "geo" : { },
  "id_str" : "602312039839735808",
  "in_reply_to_user_id" : 192437743,
  "text" : "@nathanghall @JenMac_ESL some attempts like flax lang learn system http:\/\/t.co\/ZSUeNGlkq0",
  "id" : 602312039839735808,
  "in_reply_to_status_id" : 602219357507289088,
  "created_at" : "2015-05-24 03:15:55 +0000",
  "in_reply_to_screen_name" : "nathanghall",
  "in_reply_to_user_id_str" : "192437743",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602212833418412032",
  "text" : "apparently hole in the wall guy wanted to put hole in the Tesolfr wallet :\/",
  "id" : 602212833418412032,
  "created_at" : "2015-05-23 20:41:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer MacDonald",
      "screen_name" : "JenMac_ESL",
      "indices" : [ 0, 11 ],
      "id_str" : "608800026",
      "id" : 608800026
    }, {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "indices" : [ 12, 24 ],
      "id_str" : "192437743",
      "id" : 192437743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/khdEIJaIc8",
      "expanded_url" : "http:\/\/www.skylight-to-english.co.uk\/skylight\/",
      "display_url" : "skylight-to-english.co.uk\/skylight\/"
    } ]
  },
  "in_reply_to_status_id_str" : "602209626055168000",
  "geo" : { },
  "id_str" : "602210017891250176",
  "in_reply_to_user_id" : 608800026,
  "text" : "@JenMac_ESL @nathanghall in terms of interface u could have a try of http:\/\/t.co\/khdEIJaIc8",
  "id" : 602210017891250176,
  "in_reply_to_status_id" : 602209626055168000,
  "created_at" : "2015-05-23 20:30:31 +0000",
  "in_reply_to_screen_name" : "JenMac_ESL",
  "in_reply_to_user_id_str" : "608800026",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "indices" : [ 0, 12 ],
      "id_str" : "192437743",
      "id" : 192437743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/KcU4Hh8VL3",
      "expanded_url" : "https:\/\/plus.google.com\/+MuraNava\/posts\/XvojJEv3c7Z",
      "display_url" : "plus.google.com\/+MuraNava\/post\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "602200717575593984",
  "geo" : { },
  "id_str" : "602205751503884288",
  "in_reply_to_user_id" : 192437743,
  "text" : "@nathanghall once possibility is corpus of graded readers e.g. https:\/\/t.co\/KcU4Hh8VL3",
  "id" : 602205751503884288,
  "in_reply_to_status_id" : 602200717575593984,
  "created_at" : "2015-05-23 20:13:34 +0000",
  "in_reply_to_screen_name" : "nathanghall",
  "in_reply_to_user_id_str" : "192437743",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "edutopia",
      "screen_name" : "edutopia",
      "indices" : [ 0, 9 ],
      "id_str" : "35415477",
      "id" : 35415477
    }, {
      "name" : "Helen Legge",
      "screen_name" : "ITLegge",
      "indices" : [ 10, 18 ],
      "id_str" : "2201561838",
      "id" : 2201561838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "602127558726045696",
  "geo" : { },
  "id_str" : "602181221821603841",
  "in_reply_to_user_id" : 35415477,
  "text" : "@edutopia @ITLegge though this \"purpose\" seems not understanding venn diagrams ; )",
  "id" : 602181221821603841,
  "in_reply_to_status_id" : 602127558726045696,
  "created_at" : "2015-05-23 18:36:05 +0000",
  "in_reply_to_screen_name" : "edutopia",
  "in_reply_to_user_id_str" : "35415477",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/QMMCDuaPDh",
      "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2015\/05\/never-in-albion.html",
      "display_url" : "thecurmudgeonly.blogspot.co.uk\/2015\/05\/never-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "602038394110287872",
  "text" : "RT @pchallinor: Never in Albion http:\/\/t.co\/QMMCDuaPDh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 16, 38 ],
        "url" : "http:\/\/t.co\/QMMCDuaPDh",
        "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2015\/05\/never-in-albion.html",
        "display_url" : "thecurmudgeonly.blogspot.co.uk\/2015\/05\/never-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "601698189390000128",
    "text" : "Never in Albion http:\/\/t.co\/QMMCDuaPDh",
    "id" : 601698189390000128,
    "created_at" : "2015-05-22 10:36:42 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 602038394110287872,
  "created_at" : "2015-05-23 09:08:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "602013419189850112",
  "geo" : { },
  "id_str" : "602027711142432768",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish i would say with my sts G Translate would be no 1 ref",
  "id" : 602027711142432768,
  "in_reply_to_status_id" : 602013419189850112,
  "created_at" : "2015-05-23 08:26:06 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Chesnut",
      "screen_name" : "MichaelChesnut2",
      "indices" : [ 0, 16 ],
      "id_str" : "820940430",
      "id" : 820940430
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/gnEFqIeLpA",
      "expanded_url" : "https:\/\/plus.google.com\/u\/0\/communities\/101266284417587206243",
      "display_url" : "plus.google.com\/u\/0\/communitie\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "601927384061751296",
  "geo" : { },
  "id_str" : "601928143855865856",
  "in_reply_to_user_id" : 820940430,
  "text" : "@MichaelChesnut2 a pleasure first shared on G+ CL community https:\/\/t.co\/gnEFqIeLpA :)",
  "id" : 601928143855865856,
  "in_reply_to_status_id" : 601927384061751296,
  "created_at" : "2015-05-23 01:50:27 +0000",
  "in_reply_to_screen_name" : "MichaelChesnut2",
  "in_reply_to_user_id_str" : "820940430",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Chesnut",
      "screen_name" : "MichaelChesnut2",
      "indices" : [ 0, 16 ],
      "id_str" : "820940430",
      "id" : 820940430
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/n37kE4yq0a",
      "expanded_url" : "https:\/\/www.sketchengine.co.uk\/documentation\/attachment\/wiki\/AK\/StrucBib\/RFLAapr_92015_submitted.docx?format=raw",
      "display_url" : "sketchengine.co.uk\/documentation\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "601922267195441152",
  "geo" : { },
  "id_str" : "601925207624962049",
  "in_reply_to_user_id" : 820940430,
  "text" : "@MichaelChesnut2 nice, there's some info on use here [doc] https:\/\/t.co\/n37kE4yq0a",
  "id" : 601925207624962049,
  "in_reply_to_status_id" : 601922267195441152,
  "created_at" : "2015-05-23 01:38:47 +0000",
  "in_reply_to_screen_name" : "MichaelChesnut2",
  "in_reply_to_user_id_str" : "820940430",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenys Hanson",
      "screen_name" : "GlenysHanson",
      "indices" : [ 0, 13 ],
      "id_str" : "527238447",
      "id" : 527238447
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "601896332782137344",
  "geo" : { },
  "id_str" : "601896648801918979",
  "in_reply_to_user_id" : 527238447,
  "text" : "@GlenysHanson good question, i guess bank is useful for not re-inventing wheel kind of things?",
  "id" : 601896648801918979,
  "in_reply_to_status_id" : 601896332782137344,
  "created_at" : "2015-05-22 23:45:18 +0000",
  "in_reply_to_screen_name" : "GlenysHanson",
  "in_reply_to_user_id_str" : "527238447",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 0, 15 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "601881277587914752",
  "geo" : { },
  "id_str" : "601890925430841345",
  "in_reply_to_user_id" : 334332424,
  "text" : "@GeoffreyJordan for sure Frankenberg-Garcia is one of my fav scholars at the moment :)",
  "id" : 601890925430841345,
  "in_reply_to_status_id" : 601881277587914752,
  "created_at" : "2015-05-22 23:22:33 +0000",
  "in_reply_to_screen_name" : "GeoffreyJordan",
  "in_reply_to_user_id_str" : "334332424",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Igor Brigadir",
      "screen_name" : "IgorBrigadir",
      "indices" : [ 3, 16 ],
      "id_str" : "495430242",
      "id" : 495430242
    }, {
      "name" : "Henk van Ess",
      "screen_name" : "henkvaness",
      "indices" : [ 57, 68 ],
      "id_str" : "15037033",
      "id" : 15037033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/Oq9X2htouO",
      "expanded_url" : "https:\/\/medium.com\/@henkvaness\/google-maps-on-steroids-d665e3285fc1",
      "display_url" : "medium.com\/@henkvaness\/go\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "601862693155381248",
  "text" : "RT @IgorBrigadir: More on Google Maps People search from @henkvaness https:\/\/t.co\/Oq9X2htouO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Henk van Ess",
        "screen_name" : "henkvaness",
        "indices" : [ 39, 50 ],
        "id_str" : "15037033",
        "id" : 15037033
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 74 ],
        "url" : "https:\/\/t.co\/Oq9X2htouO",
        "expanded_url" : "https:\/\/medium.com\/@henkvaness\/google-maps-on-steroids-d665e3285fc1",
        "display_url" : "medium.com\/@henkvaness\/go\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "601777166465015808",
    "geo" : { },
    "id_str" : "601778449221554178",
    "in_reply_to_user_id" : 495430242,
    "text" : "More on Google Maps People search from @henkvaness https:\/\/t.co\/Oq9X2htouO",
    "id" : 601778449221554178,
    "in_reply_to_status_id" : 601777166465015808,
    "created_at" : "2015-05-22 15:55:37 +0000",
    "in_reply_to_screen_name" : "IgorBrigadir",
    "in_reply_to_user_id_str" : "495430242",
    "user" : {
      "name" : "Igor Brigadir",
      "screen_name" : "IgorBrigadir",
      "protected" : false,
      "id_str" : "495430242",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2538946114\/xiveugt78rc97y1dasxf_normal.jpeg",
      "id" : 495430242,
      "verified" : false
    }
  },
  "id" : 601862693155381248,
  "created_at" : "2015-05-22 21:30:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601856304144089088",
  "text" : "hmm just found out websofsubstance Harry Web blog is no more :(",
  "id" : 601856304144089088,
  "created_at" : "2015-05-22 21:04:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "601721400584380417",
  "geo" : { },
  "id_str" : "601851957372911617",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish cheers Marc here's to a good w\/e :)",
  "id" : 601851957372911617,
  "in_reply_to_status_id" : 601721400584380417,
  "created_at" : "2015-05-22 20:47:43 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/YWS0SNKE20",
      "expanded_url" : "https:\/\/www.academia.edu\/3260837\/Beyond_L1-L2_Equivalents_Where_do_Users_of_English_as_a_Foreign_Language_Turn_for_Help",
      "display_url" : "academia.edu\/3260837\/Beyond\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "601851780918542336",
  "text" : "Beyond L1-L2 Equivalents: Where do Users of English as a Foreign Language Turn for Help? https:\/\/t.co\/YWS0SNKE20 by Ana Frankenberg-Garcia",
  "id" : 601851780918542336,
  "created_at" : "2015-05-22 20:47:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 3, 14 ],
      "id_str" : "88202140",
      "id" : 88202140
    }, {
      "name" : "Matthew Noble",
      "screen_name" : "NewbieCELTA",
      "indices" : [ 16, 28 ],
      "id_str" : "2311153903",
      "id" : 2311153903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/4cxPAuw4Ut",
      "expanded_url" : "https:\/\/youtu.be\/A7fIozmOGvw",
      "display_url" : "youtu.be\/A7fIozmOGvw"
    } ]
  },
  "geo" : { },
  "id_str" : "601296517924786176",
  "text" : "RT @hughdellar: @NewbieCELTA Thanks to you, this morning I made this video, talking through how we treat lesson goals and grammar: https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Matthew Noble",
        "screen_name" : "NewbieCELTA",
        "indices" : [ 0, 12 ],
        "id_str" : "2311153903",
        "id" : 2311153903
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/4cxPAuw4Ut",
        "expanded_url" : "https:\/\/youtu.be\/A7fIozmOGvw",
        "display_url" : "youtu.be\/A7fIozmOGvw"
      } ]
    },
    "in_reply_to_status_id_str" : "600556461979086848",
    "geo" : { },
    "id_str" : "601017003550310400",
    "in_reply_to_user_id" : 2311153903,
    "text" : "@NewbieCELTA Thanks to you, this morning I made this video, talking through how we treat lesson goals and grammar: https:\/\/t.co\/4cxPAuw4Ut",
    "id" : 601017003550310400,
    "in_reply_to_status_id" : 600556461979086848,
    "created_at" : "2015-05-20 13:29:54 +0000",
    "in_reply_to_screen_name" : "NewbieCELTA",
    "in_reply_to_user_id_str" : "2311153903",
    "user" : {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "protected" : false,
      "id_str" : "88202140",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2040881292\/Hugh_Dellar_photo_normal.jpg",
      "id" : 88202140,
      "verified" : false
    }
  },
  "id" : 601296517924786176,
  "created_at" : "2015-05-21 08:00:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 3, 18 ],
      "id_str" : "285614027",
      "id" : 285614027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/y3V3OJEOik",
      "expanded_url" : "http:\/\/ift.tt\/1IQz7Fq",
      "display_url" : "ift.tt\/1IQz7Fq"
    } ]
  },
  "geo" : { },
  "id_str" : "601282087619002368",
  "text" : "RT @AnthonyTeacher: My Favorite Coursebooks (or: Not All Coursebooks Are the Same) http:\/\/t.co\/y3V3OJEOik",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/y3V3OJEOik",
        "expanded_url" : "http:\/\/ift.tt\/1IQz7Fq",
        "display_url" : "ift.tt\/1IQz7Fq"
      } ]
    },
    "geo" : { },
    "id_str" : "601233783631712256",
    "text" : "My Favorite Coursebooks (or: Not All Coursebooks Are the Same) http:\/\/t.co\/y3V3OJEOik",
    "id" : 601233783631712256,
    "created_at" : "2015-05-21 03:51:19 +0000",
    "user" : {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "protected" : false,
      "id_str" : "285614027",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/412336845658132481\/Om5kKuMQ_normal.jpeg",
      "id" : 285614027,
      "verified" : false
    }
  },
  "id" : 601282087619002368,
  "created_at" : "2015-05-21 07:03:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "601022191115702272",
  "geo" : { },
  "id_str" : "601026091218776065",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan we swapped students between classrooms, used the full video versions as prepping them for a note-taking assessment",
  "id" : 601026091218776065,
  "in_reply_to_status_id" : 601022191115702272,
  "created_at" : "2015-05-20 14:06:01 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 0, 15 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "601007614324056065",
  "geo" : { },
  "id_str" : "601025693376507904",
  "in_reply_to_user_id" : 334332424,
  "text" : "@GeoffreyJordan erm i think probably looking through the teacher's answer book? :)",
  "id" : 601025693376507904,
  "in_reply_to_status_id" : 601007614324056065,
  "created_at" : "2015-05-20 14:04:26 +0000",
  "in_reply_to_screen_name" : "GeoffreyJordan",
  "in_reply_to_user_id_str" : "334332424",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/r87B5KQHrH",
      "expanded_url" : "http:\/\/members5.boardhost.com\/medialens\/msg\/1432116940.html",
      "display_url" : "members5.boardhost.com\/medialens\/msg\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "600976421796880384",
  "text" : "The Trojan Horse Hoax in Birmingham - direct from Tahir Alam, the man at the centre of the affair http:\/\/t.co\/r87B5KQHrH",
  "id" : 600976421796880384,
  "created_at" : "2015-05-20 10:48:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "P\u00E9rez-Paredes",
      "screen_name" : "perezparedes",
      "indices" : [ 3, 16 ],
      "id_str" : "28528850",
      "id" : 28528850
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/lE7LZLPtwu",
      "expanded_url" : "http:\/\/wp.me\/p5Qaaj-LU",
      "display_url" : "wp.me\/p5Qaaj-LU"
    } ]
  },
  "geo" : { },
  "id_str" : "600950114128105473",
  "text" : "RT @perezparedes: Adam Kilgarriff: a selection of papers and\u00A0talks http:\/\/t.co\/lE7LZLPtwu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/lE7LZLPtwu",
        "expanded_url" : "http:\/\/wp.me\/p5Qaaj-LU",
        "display_url" : "wp.me\/p5Qaaj-LU"
      } ]
    },
    "geo" : { },
    "id_str" : "600940461331591168",
    "text" : "Adam Kilgarriff: a selection of papers and\u00A0talks http:\/\/t.co\/lE7LZLPtwu",
    "id" : 600940461331591168,
    "created_at" : "2015-05-20 08:25:45 +0000",
    "user" : {
      "name" : "P\u00E9rez-Paredes",
      "screen_name" : "perezparedes",
      "protected" : false,
      "id_str" : "28528850",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746249968139313153\/2-1yieTh_normal.jpg",
      "id" : 28528850,
      "verified" : false
    }
  },
  "id" : 600950114128105473,
  "created_at" : "2015-05-20 09:04:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David McClure",
      "screen_name" : "clured",
      "indices" : [ 0, 7 ],
      "id_str" : "106574165",
      "id" : 106574165
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "600784381330870273",
  "geo" : { },
  "id_str" : "600787196715601920",
  "in_reply_to_user_id" : 106574165,
  "text" : "@clured ok thanks :)",
  "id" : 600787196715601920,
  "in_reply_to_status_id" : 600784381330870273,
  "created_at" : "2015-05-19 22:16:44 +0000",
  "in_reply_to_screen_name" : "clured",
  "in_reply_to_user_id_str" : "106574165",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David McClure",
      "screen_name" : "clured",
      "indices" : [ 0, 7 ],
      "id_str" : "106574165",
      "id" : 106574165
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "600773648635408384",
  "geo" : { },
  "id_str" : "600782466455052288",
  "in_reply_to_user_id" : 106574165,
  "text" : "@clured hi do u know any similar to Textplot for smaller texts that generate a gephi file? thanks",
  "id" : 600782466455052288,
  "in_reply_to_status_id" : 600773648635408384,
  "created_at" : "2015-05-19 21:57:56 +0000",
  "in_reply_to_screen_name" : "clured",
  "in_reply_to_user_id_str" : "106574165",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Thornbury",
      "screen_name" : "thornburyscott",
      "indices" : [ 0, 15 ],
      "id_str" : "23090474",
      "id" : 23090474
    }, {
      "name" : "Pam Kaur Gibbons",
      "screen_name" : "kaurgibbons",
      "indices" : [ 16, 28 ],
      "id_str" : "1219941942",
      "id" : 1219941942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/0650x7qZvK",
      "expanded_url" : "http:\/\/textexture.com\/",
      "display_url" : "textexture.com"
    } ]
  },
  "in_reply_to_status_id_str" : "600622082788065280",
  "geo" : { },
  "id_str" : "600732758864986113",
  "in_reply_to_user_id" : 23090474,
  "text" : "@thornburyscott @kaurgibbons there's a copy\/paste network vis that is simpler here http:\/\/t.co\/0650x7qZvK",
  "id" : 600732758864986113,
  "in_reply_to_status_id" : 600622082788065280,
  "created_at" : "2015-05-19 18:40:25 +0000",
  "in_reply_to_screen_name" : "thornburyscott",
  "in_reply_to_user_id_str" : "23090474",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Rei",
      "screen_name" : "Charlesrei1",
      "indices" : [ 0, 12 ],
      "id_str" : "464454382",
      "id" : 464454382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "600641939621466112",
  "geo" : { },
  "id_str" : "600731969505353729",
  "in_reply_to_user_id" : 464454382,
  "text" : "@Charlesrei1 great :)",
  "id" : 600731969505353729,
  "in_reply_to_status_id" : 600641939621466112,
  "created_at" : "2015-05-19 18:37:17 +0000",
  "in_reply_to_screen_name" : "Charlesrei1",
  "in_reply_to_user_id_str" : "464454382",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Thornbury",
      "screen_name" : "thornburyscott",
      "indices" : [ 0, 15 ],
      "id_str" : "23090474",
      "id" : 23090474
    }, {
      "name" : "Pam Kaur Gibbons",
      "screen_name" : "kaurgibbons",
      "indices" : [ 16, 28 ],
      "id_str" : "1219941942",
      "id" : 1219941942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "600622082788065280",
  "geo" : { },
  "id_str" : "600731899447881728",
  "in_reply_to_user_id" : 23090474,
  "text" : "@thornburyscott @kaurgibbons not much as Textplot prorgram was designed for long texts like novels",
  "id" : 600731899447881728,
  "in_reply_to_status_id" : 600622082788065280,
  "created_at" : "2015-05-19 18:37:00 +0000",
  "in_reply_to_screen_name" : "thornburyscott",
  "in_reply_to_user_id_str" : "23090474",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 0, 11 ],
      "id_str" : "282659955",
      "id" : 282659955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "600606938641125376",
  "geo" : { },
  "id_str" : "600608190850535425",
  "in_reply_to_user_id" : 282659955,
  "text" : "@teflerinha may the wifi gods be with you :)",
  "id" : 600608190850535425,
  "in_reply_to_status_id" : 600606938641125376,
  "created_at" : "2015-05-19 10:25:26 +0000",
  "in_reply_to_screen_name" : "teflerinha",
  "in_reply_to_user_id_str" : "282659955",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jo Sayers",
      "screen_name" : "jo_sayers",
      "indices" : [ 3, 13 ],
      "id_str" : "87176766",
      "id" : 87176766
    }, {
      "name" : "Jaime Miller",
      "screen_name" : "teachESLonline",
      "indices" : [ 50, 65 ],
      "id_str" : "1605400032",
      "id" : 1605400032
    }, {
      "name" : "Innovate ELT",
      "screen_name" : "InnovateELT",
      "indices" : [ 110, 122 ],
      "id_str" : "2890575449",
      "id" : 2890575449
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iELT15",
      "indices" : [ 29, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/HYKqzOBMAn",
      "expanded_url" : "https:\/\/teach.englishsuccessacademy.com\/from-innovate-elt-the-future-of-teaching-esl-online-or-how-to-freelance-successfully\/",
      "display_url" : "teach.englishsuccessacademy.com\/from-innovate-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "600588554096500736",
  "text" : "RT @jo_sayers: The excellent #iELT15 session from @teachESLonline now available here: https:\/\/t.co\/HYKqzOBMAn @InnovateELT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jaime Miller",
        "screen_name" : "teachESLonline",
        "indices" : [ 35, 50 ],
        "id_str" : "1605400032",
        "id" : 1605400032
      }, {
        "name" : "Innovate ELT",
        "screen_name" : "InnovateELT",
        "indices" : [ 95, 107 ],
        "id_str" : "2890575449",
        "id" : 2890575449
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "iELT15",
        "indices" : [ 14, 21 ]
      } ],
      "urls" : [ {
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/HYKqzOBMAn",
        "expanded_url" : "https:\/\/teach.englishsuccessacademy.com\/from-innovate-elt-the-future-of-teaching-esl-online-or-how-to-freelance-successfully\/",
        "display_url" : "teach.englishsuccessacademy.com\/from-innovate-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "600286302479765504",
    "text" : "The excellent #iELT15 session from @teachESLonline now available here: https:\/\/t.co\/HYKqzOBMAn @InnovateELT",
    "id" : 600286302479765504,
    "created_at" : "2015-05-18 13:06:21 +0000",
    "user" : {
      "name" : "Jo Sayers",
      "screen_name" : "jo_sayers",
      "protected" : false,
      "id_str" : "87176766",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/466896591480037376\/EssZHYa4_normal.jpeg",
      "id" : 87176766,
      "verified" : false
    }
  },
  "id" : 600588554096500736,
  "created_at" : "2015-05-19 09:07:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TEFLAnneOKeeffe",
      "screen_name" : "TEFLclass",
      "indices" : [ 0, 10 ],
      "id_str" : "469244585",
      "id" : 469244585
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600575337316151296",
  "in_reply_to_user_id" : 469244585,
  "text" : "@TEFLclass thx for RT Anne :)",
  "id" : 600575337316151296,
  "created_at" : "2015-05-19 08:14:53 +0000",
  "in_reply_to_screen_name" : "TEFLclass",
  "in_reply_to_user_id_str" : "469244585",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AllThingsLinguistic",
      "screen_name" : "AllThingsLing",
      "indices" : [ 3, 17 ],
      "id_str" : "857291268",
      "id" : 857291268
    }, {
      "name" : "Rachael Tatman",
      "screen_name" : "rctatman",
      "indices" : [ 45, 54 ],
      "id_str" : "101609102",
      "id" : 101609102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/IVCsYcOL9E",
      "expanded_url" : "http:\/\/tmblr.co\/ZuWOEv1l7VWc9",
      "display_url" : "tmblr.co\/ZuWOEv1l7VWc9"
    } ]
  },
  "geo" : { },
  "id_str" : "600572700915068928",
  "text" : "RT @AllThingsLing: Tweeting with an accent - @rctatman on looking for regional dialect vowel differences on twitter\u2026 http:\/\/t.co\/IVCsYcOL9E",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rachael Tatman",
        "screen_name" : "rctatman",
        "indices" : [ 26, 35 ],
        "id_str" : "101609102",
        "id" : 101609102
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/IVCsYcOL9E",
        "expanded_url" : "http:\/\/tmblr.co\/ZuWOEv1l7VWc9",
        "display_url" : "tmblr.co\/ZuWOEv1l7VWc9"
      } ]
    },
    "geo" : { },
    "id_str" : "600428213026889728",
    "text" : "Tweeting with an accent - @rctatman on looking for regional dialect vowel differences on twitter\u2026 http:\/\/t.co\/IVCsYcOL9E",
    "id" : 600428213026889728,
    "created_at" : "2015-05-18 22:30:16 +0000",
    "user" : {
      "name" : "AllThingsLinguistic",
      "screen_name" : "AllThingsLing",
      "protected" : false,
      "id_str" : "857291268",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750400997206454273\/N0DmrmFi_normal.jpg",
      "id" : 857291268,
      "verified" : false
    }
  },
  "id" : 600572700915068928,
  "created_at" : "2015-05-19 08:04:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pam Kaur Gibbons",
      "screen_name" : "kaurgibbons",
      "indices" : [ 0, 12 ],
      "id_str" : "1219941942",
      "id" : 1219941942
    }, {
      "name" : "Scott Thornbury",
      "screen_name" : "thornburyscott",
      "indices" : [ 13, 28 ],
      "id_str" : "23090474",
      "id" : 23090474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "600566995130720256",
  "geo" : { },
  "id_str" : "600572450951274496",
  "in_reply_to_user_id" : 1219941942,
  "text" : "@kaurgibbons @thornburyscott to collect blog comments there is an addon  called scraper for chorme web browser",
  "id" : 600572450951274496,
  "in_reply_to_status_id" : 600566995130720256,
  "created_at" : "2015-05-19 08:03:25 +0000",
  "in_reply_to_screen_name" : "kaurgibbons",
  "in_reply_to_user_id_str" : "1219941942",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pam Kaur Gibbons",
      "screen_name" : "kaurgibbons",
      "indices" : [ 0, 12 ],
      "id_str" : "1219941942",
      "id" : 1219941942
    }, {
      "name" : "Scott Thornbury",
      "screen_name" : "thornburyscott",
      "indices" : [ 13, 28 ],
      "id_str" : "23090474",
      "id" : 23090474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/Iehaq83Rib",
      "expanded_url" : "http:\/\/dclure.org\/tutorials\/textplot-refresh\/",
      "display_url" : "dclure.org\/tutorials\/text\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "600552771805384704",
  "geo" : { },
  "id_str" : "600566844618072064",
  "in_reply_to_user_id" : 1219941942,
  "text" : "@kaurgibbons @thornburyscott hi followed this http:\/\/t.co\/Iehaq83Rib",
  "id" : 600566844618072064,
  "in_reply_to_status_id" : 600552771805384704,
  "created_at" : "2015-05-19 07:41:08 +0000",
  "in_reply_to_screen_name" : "kaurgibbons",
  "in_reply_to_user_id_str" : "1219941942",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Thornbury",
      "screen_name" : "thornburyscott",
      "indices" : [ 23, 38 ],
      "id_str" : "23090474",
      "id" : 23090474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/juJFZ4TmDo",
      "expanded_url" : "https:\/\/drive.google.com\/open?id=0B7FW2BYaBgeiNy1odWhhQUR3Nkk&authuser=0",
      "display_url" : "drive.google.com\/open?id=0B7FW2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "600442340285775872",
  "text" : "a shape of comments to @thornburyscott P is for Power post; banana, hammock...? [pdf] https:\/\/t.co\/juJFZ4TmDo",
  "id" : 600442340285775872,
  "created_at" : "2015-05-18 23:26:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 9, 24 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/600432004446978048\/photo\/1",
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/A90pZva6Gg",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CFUpubUXIAExi_P.png",
      "id_str" : "600432002907709441",
      "id" : 600432002907709441,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CFUpubUXIAExi_P.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 281,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 281,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 281,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/A90pZva6Gg"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600432004446978048",
  "text" : "hi Geoff @GeoffreyJordan u may like, this re neutrality of coursebooks :) http:\/\/t.co\/A90pZva6Gg",
  "id" : 600432004446978048,
  "created_at" : "2015-05-18 22:45:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 62, 77 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/1lNN8x7WOJ",
      "expanded_url" : "http:\/\/wp.me\/p3qkCB-1iw",
      "display_url" : "wp.me\/p3qkCB-1iw"
    } ]
  },
  "geo" : { },
  "id_str" : "600383886120587266",
  "text" : "Challenging the Coursebook: Part 2 http:\/\/t.co\/1lNN8x7WOJ via @GeoffreyJordan",
  "id" : 600383886120587266,
  "created_at" : "2015-05-18 19:34:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emma Victoria Lay",
      "screen_name" : "EmmaVictoriaLay",
      "indices" : [ 3, 19 ],
      "id_str" : "1536287492",
      "id" : 1536287492
    }, {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 88, 104 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/j966XuoCGh",
      "expanded_url" : "http:\/\/wp.me\/p2jfML-5L",
      "display_url" : "wp.me\/p2jfML-5L"
    } ]
  },
  "geo" : { },
  "id_str" : "600383683179188224",
  "text" : "RT @EmmaVictoriaLay: An Exploration of a Negotiated Syllabus http:\/\/t.co\/j966XuoCGh via @wordpressdotcom",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "WordPress.com",
        "screen_name" : "wordpressdotcom",
        "indices" : [ 67, 83 ],
        "id_str" : "823905",
        "id" : 823905
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 62 ],
        "url" : "http:\/\/t.co\/j966XuoCGh",
        "expanded_url" : "http:\/\/wp.me\/p2jfML-5L",
        "display_url" : "wp.me\/p2jfML-5L"
      } ]
    },
    "geo" : { },
    "id_str" : "600326324310384640",
    "text" : "An Exploration of a Negotiated Syllabus http:\/\/t.co\/j966XuoCGh via @wordpressdotcom",
    "id" : 600326324310384640,
    "created_at" : "2015-05-18 15:45:23 +0000",
    "user" : {
      "name" : "Emma Victoria Lay",
      "screen_name" : "EmmaVictoriaLay",
      "protected" : false,
      "id_str" : "1536287492",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/694849292046077952\/cC7o9P7F_normal.jpg",
      "id" : 1536287492,
      "verified" : false
    }
  },
  "id" : 600383683179188224,
  "created_at" : "2015-05-18 19:33:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tesal Koksi Sangma",
      "screen_name" : "TesalKoksi",
      "indices" : [ 3, 14 ],
      "id_str" : "1559079607",
      "id" : 1559079607
    }, {
      "name" : "Tesal Koksi Sangma",
      "screen_name" : "TesalKoksi",
      "indices" : [ 116, 127 ],
      "id_str" : "1559079607",
      "id" : 1559079607
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/MWS5NpwhU7",
      "expanded_url" : "http:\/\/wp.me\/p5Ufqx-C",
      "display_url" : "wp.me\/p5Ufqx-C"
    } ]
  },
  "geo" : { },
  "id_str" : "600382012764061696",
  "text" : "RT @TesalKoksi: My new post &gt;&gt;&gt; The Truth About India: On NESTs Vs NNESTs Issue http:\/\/t.co\/MWS5NpwhU7 v\u00EDa @TesalKoksi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tesal Koksi Sangma",
        "screen_name" : "TesalKoksi",
        "indices" : [ 100, 111 ],
        "id_str" : "1559079607",
        "id" : 1559079607
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/MWS5NpwhU7",
        "expanded_url" : "http:\/\/wp.me\/p5Ufqx-C",
        "display_url" : "wp.me\/p5Ufqx-C"
      } ]
    },
    "geo" : { },
    "id_str" : "600358339361439744",
    "text" : "My new post &gt;&gt;&gt; The Truth About India: On NESTs Vs NNESTs Issue http:\/\/t.co\/MWS5NpwhU7 v\u00EDa @TesalKoksi",
    "id" : 600358339361439744,
    "created_at" : "2015-05-18 17:52:36 +0000",
    "user" : {
      "name" : "Tesal Koksi Sangma",
      "screen_name" : "TesalKoksi",
      "protected" : false,
      "id_str" : "1559079607",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/754294097939140608\/DAVljhdE_normal.jpg",
      "id" : 1559079607,
      "verified" : false
    }
  },
  "id" : 600382012764061696,
  "created_at" : "2015-05-18 19:26:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 0, 15 ],
      "id_str" : "285614027",
      "id" : 285614027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "600367669020401666",
  "geo" : { },
  "id_str" : "600381095192956928",
  "in_reply_to_user_id" : 285614027,
  "text" : "@AnthonyTeacher oh well let's hope some of those tools are still around then! :)",
  "id" : 600381095192956928,
  "in_reply_to_status_id" : 600367669020401666,
  "created_at" : "2015-05-18 19:23:02 +0000",
  "in_reply_to_screen_name" : "AnthonyTeacher",
  "in_reply_to_user_id_str" : "285614027",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "indices" : [ 3, 12 ],
      "id_str" : "167020390",
      "id" : 167020390
    }, {
      "name" : "Paul Baker",
      "screen_name" : "_paulbaker_",
      "indices" : [ 116, 128 ],
      "id_str" : "1026683874",
      "id" : 1026683874
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/YCX6UGDUC7",
      "expanded_url" : "http:\/\/www.laurenceanthony.net\/software\/protant\/",
      "display_url" : "laurenceanthony.net\/software\/prota\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "600380878892748800",
  "text" : "RT @antlabjp: Just released ProtAnt, a new tool for analyzing the prototypicality of texts. Developed together with @_paulbaker_ http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Paul Baker",
        "screen_name" : "_paulbaker_",
        "indices" : [ 102, 114 ],
        "id_str" : "1026683874",
        "id" : 1026683874
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/YCX6UGDUC7",
        "expanded_url" : "http:\/\/www.laurenceanthony.net\/software\/protant\/",
        "display_url" : "laurenceanthony.net\/software\/prota\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "599823932397527041",
    "text" : "Just released ProtAnt, a new tool for analyzing the prototypicality of texts. Developed together with @_paulbaker_ http:\/\/t.co\/YCX6UGDUC7",
    "id" : 599823932397527041,
    "created_at" : "2015-05-17 06:29:04 +0000",
    "user" : {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "protected" : false,
      "id_str" : "167020390",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/428183580821315584\/ocgCI7Er_normal.jpeg",
      "id" : 167020390,
      "verified" : false
    }
  },
  "id" : 600380878892748800,
  "created_at" : "2015-05-18 19:22:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kat Gupta",
      "screen_name" : "mixosaurus",
      "indices" : [ 3, 14 ],
      "id_str" : "21158543",
      "id" : 21158543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600357573800374273",
  "text" : "RT @mixosaurus: So, so sad to hear about the death of one of the kindest, warmest, most generous people in linguistics. Rest in peace, Adam\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "600327579472629760",
    "text" : "So, so sad to hear about the death of one of the kindest, warmest, most generous people in linguistics. Rest in peace, Adam Kilgarriff",
    "id" : 600327579472629760,
    "created_at" : "2015-05-18 15:50:23 +0000",
    "user" : {
      "name" : "Kat Gupta",
      "screen_name" : "mixosaurus",
      "protected" : false,
      "id_str" : "21158543",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/497125168477523970\/a60pRivO_normal.png",
      "id" : 21158543,
      "verified" : false
    }
  },
  "id" : 600357573800374273,
  "created_at" : "2015-05-18 17:49:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "indices" : [ 64, 76 ],
      "id_str" : "192437743",
      "id" : 192437743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/kXoVWLDGba",
      "expanded_url" : "http:\/\/wp.me\/p3cig0-tZ",
      "display_url" : "wp.me\/p3cig0-tZ"
    } ]
  },
  "geo" : { },
  "id_str" : "600356537404661760",
  "text" : "Divii: A searchable video dictionary http:\/\/t.co\/kXoVWLDGba via @nathanghall",
  "id" : 600356537404661760,
  "created_at" : "2015-05-18 17:45:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 0, 15 ],
      "id_str" : "285614027",
      "id" : 285614027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "599424617988493313",
  "geo" : { },
  "id_str" : "600298857076019200",
  "in_reply_to_user_id" : 285614027,
  "text" : "@AnthonyTeacher look fwd to any reports of this",
  "id" : 600298857076019200,
  "in_reply_to_status_id" : 599424617988493313,
  "created_at" : "2015-05-18 13:56:15 +0000",
  "in_reply_to_screen_name" : "AnthonyTeacher",
  "in_reply_to_user_id_str" : "285614027",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    }, {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "indices" : [ 17, 29 ],
      "id_str" : "192437743",
      "id" : 192437743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600279034090622976",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish @nathanghall thank you for sharing fellas :)",
  "id" : 600279034090622976,
  "created_at" : "2015-05-18 12:37:29 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 67, 75 ]
    }, {
      "text" : "keltchat",
      "indices" : [ 76, 85 ]
    }, {
      "text" : "eltchinwag",
      "indices" : [ 86, 97 ]
    }, {
      "text" : "auselt",
      "indices" : [ 98, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/UBFOt5SDMw",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-WV",
      "display_url" : "wp.me\/pgHyE-WV"
    } ]
  },
  "geo" : { },
  "id_str" : "600039547812978688",
  "text" : "Google\u2019s Custom Search Engine with keywords http:\/\/t.co\/UBFOt5SDMw #eltchat #keltchat #eltchinwag #auselt",
  "id" : 600039547812978688,
  "created_at" : "2015-05-17 20:45:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 0, 13 ],
      "id_str" : "88655243",
      "id" : 88655243
    }, {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 14, 29 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "599347462860632064",
  "geo" : { },
  "id_str" : "600014894675660802",
  "in_reply_to_user_id" : 88655243,
  "text" : "@rosemerebard @GeoffreyJordan :)",
  "id" : 600014894675660802,
  "in_reply_to_status_id" : 599347462860632064,
  "created_at" : "2015-05-17 19:07:53 +0000",
  "in_reply_to_screen_name" : "rosemerebard",
  "in_reply_to_user_id_str" : "88655243",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vicky Loras",
      "screen_name" : "vickyloras",
      "indices" : [ 0, 11 ],
      "id_str" : "95957241",
      "id" : 95957241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600008847118438400",
  "in_reply_to_user_id" : 95957241,
  "text" : "@vickyloras thx for RT :)",
  "id" : 600008847118438400,
  "created_at" : "2015-05-17 18:43:51 +0000",
  "in_reply_to_screen_name" : "vickyloras",
  "in_reply_to_user_id_str" : "95957241",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dayle Major",
      "screen_name" : "daylemajor",
      "indices" : [ 0, 11 ],
      "id_str" : "10052752",
      "id" : 10052752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "599504017958408192",
  "geo" : { },
  "id_str" : "600008741904322560",
  "in_reply_to_user_id" : 10052752,
  "text" : "@daylemajor thx for sharing :)",
  "id" : 600008741904322560,
  "in_reply_to_status_id" : 599504017958408192,
  "created_at" : "2015-05-17 18:43:26 +0000",
  "in_reply_to_screen_name" : "daylemajor",
  "in_reply_to_user_id_str" : "10052752",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heather Buchanan",
      "screen_name" : "HeatherBu2011",
      "indices" : [ 0, 14 ],
      "id_str" : "243323218",
      "id" : 243323218
    }, {
      "name" : "IATEFL Head Office",
      "screen_name" : "iatefl",
      "indices" : [ 15, 22 ],
      "id_str" : "85042286",
      "id" : 85042286
    }, {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 23, 38 ],
      "id_str" : "285614027",
      "id" : 285614027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600008572848734208",
  "in_reply_to_user_id" : 243323218,
  "text" : "@HeatherBu2011 @iatefl @AnthonyTeacher thanks for RTs :)",
  "id" : 600008572848734208,
  "created_at" : "2015-05-17 18:42:46 +0000",
  "in_reply_to_screen_name" : "HeatherBu2011",
  "in_reply_to_user_id_str" : "243323218",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 0, 9 ],
      "id_str" : "121063600",
      "id" : 121063600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "599938928699940864",
  "geo" : { },
  "id_str" : "600008005879488512",
  "in_reply_to_user_id" : 121063600,
  "text" : "@whyshona thx for share :)",
  "id" : 600008005879488512,
  "in_reply_to_status_id" : 599938928699940864,
  "created_at" : "2015-05-17 18:40:30 +0000",
  "in_reply_to_screen_name" : "whyshona",
  "in_reply_to_user_id_str" : "121063600",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "599426652909633536",
  "geo" : { },
  "id_str" : "600007826606546944",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin hi be interested in any feedback yr sts may have",
  "id" : 600007826606546944,
  "in_reply_to_status_id" : 599426652909633536,
  "created_at" : "2015-05-17 18:39:48 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "599329334126465024",
  "geo" : { },
  "id_str" : "600007491641057280",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan cheers Leo, a colleague and I used yr megabridges lesson recently",
  "id" : 600007491641057280,
  "in_reply_to_status_id" : 599329334126465024,
  "created_at" : "2015-05-17 18:38:28 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Guy L. Gonzalez",
      "screen_name" : "glecharles",
      "indices" : [ 3, 14 ],
      "id_str" : "15297709",
      "id" : 15297709
    }, {
      "name" : "Siva Vaidhyanathan",
      "screen_name" : "sivavaid",
      "indices" : [ 109, 118 ],
      "id_str" : "20406724",
      "id" : 20406724
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 140 ],
      "url" : "http:\/\/t.co\/Wzy6AI4Z2q",
      "expanded_url" : "http:\/\/ow.ly\/MXWaZ",
      "display_url" : "ow.ly\/MXWaZ"
    } ]
  },
  "geo" : { },
  "id_str" : "599165502460682241",
  "text" : "RT @glecharles: \"Innovation, esp. the disruptive kind, has become a religious concept, immune to criticism.\" @sivavaid http:\/\/t.co\/Wzy6AI4Z\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Siva Vaidhyanathan",
        "screen_name" : "sivavaid",
        "indices" : [ 93, 102 ],
        "id_str" : "20406724",
        "id" : 20406724
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/Wzy6AI4Z2q",
        "expanded_url" : "http:\/\/ow.ly\/MXWaZ",
        "display_url" : "ow.ly\/MXWaZ"
      } ]
    },
    "geo" : { },
    "id_str" : "598955741404405761",
    "text" : "\"Innovation, esp. the disruptive kind, has become a religious concept, immune to criticism.\" @sivavaid http:\/\/t.co\/Wzy6AI4Z2q (Amen!)",
    "id" : 598955741404405761,
    "created_at" : "2015-05-14 20:59:11 +0000",
    "user" : {
      "name" : "Guy L. Gonzalez",
      "screen_name" : "glecharles",
      "protected" : false,
      "id_str" : "15297709",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/734033949823897600\/r0fHPtTM_normal.jpg",
      "id" : 15297709,
      "verified" : false
    }
  },
  "id" : 599165502460682241,
  "created_at" : "2015-05-15 10:52:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    }, {
      "name" : "Hana Tich\u00E1",
      "screen_name" : "HanaTicha",
      "indices" : [ 17, 27 ],
      "id_str" : "512296705",
      "id" : 512296705
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "599162272682999808",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin @HanaTicha thanks for shares guys, have a good w\/e :)",
  "id" : 599162272682999808,
  "created_at" : "2015-05-15 10:39:52 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "4TUNE Teller App",
      "screen_name" : "4tunetellernet",
      "indices" : [ 0, 15 ],
      "id_str" : "467634146",
      "id" : 467634146
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/qw6OxXeZwJ",
      "expanded_url" : "https:\/\/twitter.com\/pomeranian99\/status\/598945962699161600",
      "display_url" : "twitter.com\/pomeranian99\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "599108653933821953",
  "in_reply_to_user_id" : 467634146,
  "text" : "@4tunetellernet https:\/\/t.co\/qw6OxXeZwJ",
  "id" : 599108653933821953,
  "created_at" : "2015-05-15 07:06:48 +0000",
  "in_reply_to_screen_name" : "4tunetellernet",
  "in_reply_to_user_id_str" : "467634146",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/7qlAPC4ILe",
      "expanded_url" : "http:\/\/www.eurotrib.com\/story\/2015\/5\/14\/23141\/3765",
      "display_url" : "eurotrib.com\/story\/2015\/5\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "598937844015595521",
  "text" : "The left alternative to the FN http:\/\/t.co\/7qlAPC4ILe",
  "id" : 598937844015595521,
  "created_at" : "2015-05-14 19:48:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Moravec",
      "screen_name" : "ProfessMoravec",
      "indices" : [ 0, 15 ],
      "id_str" : "369529173",
      "id" : 369529173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598889823043231745",
  "geo" : { },
  "id_str" : "598890018296434688",
  "in_reply_to_user_id" : 369529173,
  "text" : "@ProfessMoravec yr welcome, good luck!",
  "id" : 598890018296434688,
  "in_reply_to_status_id" : 598889823043231745,
  "created_at" : "2015-05-14 16:38:01 +0000",
  "in_reply_to_screen_name" : "ProfessMoravec",
  "in_reply_to_user_id_str" : "369529173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Moravec",
      "screen_name" : "ProfessMoravec",
      "indices" : [ 0, 15 ],
      "id_str" : "369529173",
      "id" : 369529173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598889328018903041",
  "geo" : { },
  "id_str" : "598889685730140160",
  "in_reply_to_user_id" : 369529173,
  "text" : "@ProfessMoravec could be osx issue can you scroll generally?",
  "id" : 598889685730140160,
  "in_reply_to_status_id" : 598889328018903041,
  "created_at" : "2015-05-14 16:36:42 +0000",
  "in_reply_to_screen_name" : "ProfessMoravec",
  "in_reply_to_user_id_str" : "369529173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Moravec",
      "screen_name" : "ProfessMoravec",
      "indices" : [ 0, 15 ],
      "id_str" : "369529173",
      "id" : 369529173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598887820686680064",
  "geo" : { },
  "id_str" : "598888373739200512",
  "in_reply_to_user_id" : 369529173,
  "text" : "@ProfessMoravec yes scroll down in sections box",
  "id" : 598888373739200512,
  "in_reply_to_status_id" : 598887820686680064,
  "created_at" : "2015-05-14 16:31:29 +0000",
  "in_reply_to_screen_name" : "ProfessMoravec",
  "in_reply_to_user_id_str" : "369529173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Moravec",
      "screen_name" : "ProfessMoravec",
      "indices" : [ 0, 15 ],
      "id_str" : "369529173",
      "id" : 369529173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598887054550794240",
  "geo" : { },
  "id_str" : "598887513999187968",
  "in_reply_to_user_id" : 369529173,
  "text" : "@ProfessMoravec are you looking at sections box on lefthand side?",
  "id" : 598887513999187968,
  "in_reply_to_status_id" : 598887054550794240,
  "created_at" : "2015-05-14 16:28:04 +0000",
  "in_reply_to_screen_name" : "ProfessMoravec",
  "in_reply_to_user_id_str" : "369529173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Moravec",
      "screen_name" : "ProfessMoravec",
      "indices" : [ 0, 15 ],
      "id_str" : "369529173",
      "id" : 369529173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598842241998823424",
  "geo" : { },
  "id_str" : "598886898833215488",
  "in_reply_to_user_id" : 369529173,
  "text" : "@ProfessMoravec scroll down?",
  "id" : 598886898833215488,
  "in_reply_to_status_id" : 598842241998823424,
  "created_at" : "2015-05-14 16:25:38 +0000",
  "in_reply_to_screen_name" : "ProfessMoravec",
  "in_reply_to_user_id_str" : "369529173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Geurin",
      "screen_name" : "DavidGeurin",
      "indices" : [ 3, 15 ],
      "id_str" : "350987862",
      "id" : 350987862
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/DavidGeurin\/status\/598784832215232512\/photo\/1",
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/6R0OqbRDz0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CE9PoHCVEAAFtyb.jpg",
      "id_str" : "598784825965744128",
      "id" : 598784825965744128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CE9PoHCVEAAFtyb.jpg",
      "sizes" : [ {
        "h" : 530,
        "resize" : "fit",
        "w" : 450
      }, {
        "h" : 530,
        "resize" : "fit",
        "w" : 450
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 530,
        "resize" : "fit",
        "w" : 450
      } ],
      "display_url" : "pic.twitter.com\/6R0OqbRDz0"
    } ],
    "hashtags" : [ {
      "text" : "bfc530",
      "indices" : [ 38, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598852516470730752",
  "text" : "RT @DavidGeurin: Some edu-humor here. #bfc530 http:\/\/t.co\/6R0OqbRDz0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/DavidGeurin\/status\/598784832215232512\/photo\/1",
        "indices" : [ 29, 51 ],
        "url" : "http:\/\/t.co\/6R0OqbRDz0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CE9PoHCVEAAFtyb.jpg",
        "id_str" : "598784825965744128",
        "id" : 598784825965744128,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CE9PoHCVEAAFtyb.jpg",
        "sizes" : [ {
          "h" : 530,
          "resize" : "fit",
          "w" : 450
        }, {
          "h" : 530,
          "resize" : "fit",
          "w" : 450
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 530,
          "resize" : "fit",
          "w" : 450
        } ],
        "display_url" : "pic.twitter.com\/6R0OqbRDz0"
      } ],
      "hashtags" : [ {
        "text" : "bfc530",
        "indices" : [ 21, 28 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "598784832215232512",
    "text" : "Some edu-humor here. #bfc530 http:\/\/t.co\/6R0OqbRDz0",
    "id" : 598784832215232512,
    "created_at" : "2015-05-14 09:40:03 +0000",
    "user" : {
      "name" : "David Geurin",
      "screen_name" : "DavidGeurin",
      "protected" : false,
      "id_str" : "350987862",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/448172107386867713\/h5UNUxnU_normal.jpeg",
      "id" : 350987862,
      "verified" : false
    }
  },
  "id" : 598852516470730752,
  "created_at" : "2015-05-14 14:09:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angelos Bollas",
      "screen_name" : "angelos_bollas",
      "indices" : [ 0, 15 ],
      "id_str" : "309578964",
      "id" : 309578964
    }, {
      "name" : "Jisc",
      "screen_name" : "Jisc",
      "indices" : [ 16, 21 ],
      "id_str" : "18829580",
      "id" : 18829580
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598815946984300544",
  "geo" : { },
  "id_str" : "598817238175580160",
  "in_reply_to_user_id" : 309578964,
  "text" : "@angelos_bollas @Jisc  my argument is that a lot of 'i don't do tech' is qualified on questionable pedagogical benefits",
  "id" : 598817238175580160,
  "in_reply_to_status_id" : 598815946984300544,
  "created_at" : "2015-05-14 11:48:49 +0000",
  "in_reply_to_screen_name" : "angelos_bollas",
  "in_reply_to_user_id_str" : "309578964",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angelos Bollas",
      "screen_name" : "angelos_bollas",
      "indices" : [ 0, 15 ],
      "id_str" : "309578964",
      "id" : 309578964
    }, {
      "name" : "Jisc",
      "screen_name" : "Jisc",
      "indices" : [ 120, 125 ],
      "id_str" : "18829580",
      "id" : 18829580
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598812924317192193",
  "geo" : { },
  "id_str" : "598815642712559616",
  "in_reply_to_user_id" : 309578964,
  "text" : "@angelos_bollas often the qualifications have merit &amp; if dig tech has not justified itself it is not tchrs fault as @Jisc is implying",
  "id" : 598815642712559616,
  "in_reply_to_status_id" : 598812924317192193,
  "created_at" : "2015-05-14 11:42:29 +0000",
  "in_reply_to_screen_name" : "angelos_bollas",
  "in_reply_to_user_id_str" : "309578964",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angelos Bollas",
      "screen_name" : "angelos_bollas",
      "indices" : [ 0, 15 ],
      "id_str" : "309578964",
      "id" : 309578964
    }, {
      "name" : "Jisc",
      "screen_name" : "Jisc",
      "indices" : [ 35, 40 ],
      "id_str" : "18829580",
      "id" : 18829580
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598810174426632192",
  "geo" : { },
  "id_str" : "598811830132277248",
  "in_reply_to_user_id" : 309578964,
  "text" : "@angelos_bollas re how much of the @Jisc premise is missing the qualifications i am sure teachers have when saying \"i don't do digital\"?",
  "id" : 598811830132277248,
  "in_reply_to_status_id" : 598810174426632192,
  "created_at" : "2015-05-14 11:27:20 +0000",
  "in_reply_to_screen_name" : "angelos_bollas",
  "in_reply_to_user_id_str" : "309578964",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angelos Bollas",
      "screen_name" : "angelos_bollas",
      "indices" : [ 0, 15 ],
      "id_str" : "309578964",
      "id" : 309578964
    }, {
      "name" : "Jisc",
      "screen_name" : "Jisc",
      "indices" : [ 16, 21 ],
      "id_str" : "18829580",
      "id" : 18829580
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/8ukr0ypIJT",
      "expanded_url" : "http:\/\/bit.ly\/1zAXGiu",
      "display_url" : "bit.ly\/1zAXGiu"
    } ]
  },
  "in_reply_to_status_id_str" : "598805339191058432",
  "geo" : { },
  "id_str" : "598808064603611136",
  "in_reply_to_user_id" : 309578964,
  "text" : "@angelos_bollas @Jisc  some student use of 'digital' to consider  http:\/\/t.co\/8ukr0ypIJT",
  "id" : 598808064603611136,
  "in_reply_to_status_id" : 598805339191058432,
  "created_at" : "2015-05-14 11:12:22 +0000",
  "in_reply_to_screen_name" : "angelos_bollas",
  "in_reply_to_user_id_str" : "309578964",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 57, 72 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/XmSRIWpruP",
      "expanded_url" : "http:\/\/wp.me\/p3qkCB-1i2",
      "display_url" : "wp.me\/p3qkCB-1i2"
    } ]
  },
  "geo" : { },
  "id_str" : "598635074838503424",
  "text" : "Dellar Defends the Coursebook http:\/\/t.co\/XmSRIWpruP via @GeoffreyJordan",
  "id" : 598635074838503424,
  "created_at" : "2015-05-13 23:44:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    }, {
      "name" : "George Chilton",
      "screen_name" : "designerlessons",
      "indices" : [ 7, 23 ],
      "id_str" : "432090149",
      "id" : 432090149
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598612602189705216",
  "geo" : { },
  "id_str" : "598624483814088704",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl @designerlessons let's call it nulp and leave nlp to natural language processing, who's with me?",
  "id" : 598624483814088704,
  "in_reply_to_status_id" : 598612602189705216,
  "created_at" : "2015-05-13 23:02:53 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/m7hTzCzWPP",
      "expanded_url" : "http:\/\/rgcl.wlv.ac.uk\/2015\/05\/05\/manifestospeak-what-can-linguistic-analysis-tell-us-about-politicians-and-their-attitudes\/",
      "display_url" : "rgcl.wlv.ac.uk\/2015\/05\/05\/man\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "598485283160662018",
  "text" : "Manifestospeak: What can linguistic analysis tell us about politicians and their attitudes? http:\/\/t.co\/m7hTzCzWPP ht Lex Studies Newsletter",
  "id" : 598485283160662018,
  "created_at" : "2015-05-13 13:49:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "grassrootsELT",
      "screen_name" : "roots2go",
      "indices" : [ 3, 12 ],
      "id_str" : "3177454779",
      "id" : 3177454779
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/roots2go\/status\/598429426758635520\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/E1quhP3wVs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CE4MWUeWYAAA3xs.jpg",
      "id_str" : "598429378079514624",
      "id" : 598429378079514624,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CE4MWUeWYAAA3xs.jpg",
      "sizes" : [ {
        "h" : 312,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 312,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 212,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 312,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/E1quhP3wVs"
    } ],
    "hashtags" : [ {
      "text" : "ELT",
      "indices" : [ 14, 18 ]
    }, {
      "text" : "ESL",
      "indices" : [ 21, 25 ]
    }, {
      "text" : "TEFL",
      "indices" : [ 114, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/NN7II2qB9H",
      "expanded_url" : "http:\/\/goo.gl\/QBW5yJ",
      "display_url" : "goo.gl\/QBW5yJ"
    } ]
  },
  "geo" : { },
  "id_str" : "598478778810167296",
  "text" : "RT @roots2go: #ELT \/ #ESL teachers! Join our G+ group and contribute to our future vision! http:\/\/t.co\/NN7II2qB9H #TEFL http:\/\/t.co\/E1quhP3\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/roots2go\/status\/598429426758635520\/photo\/1",
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/E1quhP3wVs",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CE4MWUeWYAAA3xs.jpg",
        "id_str" : "598429378079514624",
        "id" : 598429378079514624,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CE4MWUeWYAAA3xs.jpg",
        "sizes" : [ {
          "h" : 312,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 312,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 212,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 312,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/E1quhP3wVs"
      } ],
      "hashtags" : [ {
        "text" : "ELT",
        "indices" : [ 0, 4 ]
      }, {
        "text" : "ESL",
        "indices" : [ 7, 11 ]
      }, {
        "text" : "TEFL",
        "indices" : [ 100, 105 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/NN7II2qB9H",
        "expanded_url" : "http:\/\/goo.gl\/QBW5yJ",
        "display_url" : "goo.gl\/QBW5yJ"
      } ]
    },
    "geo" : { },
    "id_str" : "598429426758635520",
    "text" : "#ELT \/ #ESL teachers! Join our G+ group and contribute to our future vision! http:\/\/t.co\/NN7II2qB9H #TEFL http:\/\/t.co\/E1quhP3wVs",
    "id" : 598429426758635520,
    "created_at" : "2015-05-13 10:07:48 +0000",
    "user" : {
      "name" : "grassrootsELT",
      "screen_name" : "roots2go",
      "protected" : false,
      "id_str" : "3177454779",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/589194330847449088\/5hDjz97E_normal.png",
      "id" : 3177454779,
      "verified" : false
    }
  },
  "id" : 598478778810167296,
  "created_at" : "2015-05-13 13:23:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598469997258735617",
  "geo" : { },
  "id_str" : "598470565981204480",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson apparently in terms of data portability spamedin is not bad i have heard",
  "id" : 598470565981204480,
  "in_reply_to_status_id" : 598469997258735617,
  "created_at" : "2015-05-13 12:51:16 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/gReWgraPHE",
      "expanded_url" : "http:\/\/stopwar.org.uk\/news\/how-killing-children-in-gaza-helps-israel-s-arms-industry-sell-weapons#.VVM5Klv1gOM.twitter",
      "display_url" : "stopwar.org.uk\/news\/how-killi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "598453964804239360",
  "text" : "How killing children in Gaza helps Israel's arms industry sell weapons - Stop the War Coalition: http:\/\/t.co\/gReWgraPHE",
  "id" : 598453964804239360,
  "created_at" : "2015-05-13 11:45:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dale Coulter",
      "screen_name" : "dalecoulter",
      "indices" : [ 0, 12 ],
      "id_str" : "24046458",
      "id" : 24046458
    }, {
      "name" : "Adam Beale",
      "screen_name" : "bealer81",
      "indices" : [ 13, 22 ],
      "id_str" : "238993337",
      "id" : 238993337
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598441608640655360",
  "geo" : { },
  "id_str" : "598443312937308160",
  "in_reply_to_user_id" : 24046458,
  "text" : "@dalecoulter @bealer81 maybe",
  "id" : 598443312937308160,
  "in_reply_to_status_id" : 598441608640655360,
  "created_at" : "2015-05-13 11:02:59 +0000",
  "in_reply_to_screen_name" : "dalecoulter",
  "in_reply_to_user_id_str" : "24046458",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zhenya",
      "screen_name" : "ZhenyaDnipro",
      "indices" : [ 0, 13 ],
      "id_str" : "2248486418",
      "id" : 2248486418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598436627413860353",
  "geo" : { },
  "id_str" : "598440610010427392",
  "in_reply_to_user_id" : 2248486418,
  "text" : "@ZhenyaDnipro the topics are good, u get some very useful and interesting ones",
  "id" : 598440610010427392,
  "in_reply_to_status_id" : 598436627413860353,
  "created_at" : "2015-05-13 10:52:14 +0000",
  "in_reply_to_screen_name" : "ZhenyaDnipro",
  "in_reply_to_user_id_str" : "2248486418",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Candy van Olst",
      "screen_name" : "dingtonia",
      "indices" : [ 57, 67 ],
      "id_str" : "3171471195",
      "id" : 3171471195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/5nLi864QhP",
      "expanded_url" : "http:\/\/wp.me\/pYJvF-fA",
      "display_url" : "wp.me\/pYJvF-fA"
    } ]
  },
  "geo" : { },
  "id_str" : "598438618764546050",
  "text" : "Innovation and Crap Detection http:\/\/t.co\/5nLi864QhP via @dingtonia",
  "id" : 598438618764546050,
  "created_at" : "2015-05-13 10:44:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dale Coulter",
      "screen_name" : "dalecoulter",
      "indices" : [ 0, 12 ],
      "id_str" : "24046458",
      "id" : 24046458
    }, {
      "name" : "Adam Beale",
      "screen_name" : "bealer81",
      "indices" : [ 13, 22 ],
      "id_str" : "238993337",
      "id" : 238993337
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598437115047837696",
  "geo" : { },
  "id_str" : "598438000020869120",
  "in_reply_to_user_id" : 24046458,
  "text" : "@dalecoulter @bealer81 professional is not without its baggage...",
  "id" : 598438000020869120,
  "in_reply_to_status_id" : 598437115047837696,
  "created_at" : "2015-05-13 10:41:52 +0000",
  "in_reply_to_screen_name" : "dalecoulter",
  "in_reply_to_user_id_str" : "24046458",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dale Coulter",
      "screen_name" : "dalecoulter",
      "indices" : [ 0, 12 ],
      "id_str" : "24046458",
      "id" : 24046458
    }, {
      "name" : "Adam Beale",
      "screen_name" : "bealer81",
      "indices" : [ 13, 22 ],
      "id_str" : "238993337",
      "id" : 238993337
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598437115047837696",
  "geo" : { },
  "id_str" : "598437401867001856",
  "in_reply_to_user_id" : 24046458,
  "text" : "@dalecoulter @bealer81 no idea i guess part of the process for change could work could not",
  "id" : 598437401867001856,
  "in_reply_to_status_id" : 598437115047837696,
  "created_at" : "2015-05-13 10:39:29 +0000",
  "in_reply_to_screen_name" : "dalecoulter",
  "in_reply_to_user_id_str" : "24046458",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dale Coulter",
      "screen_name" : "dalecoulter",
      "indices" : [ 0, 12 ],
      "id_str" : "24046458",
      "id" : 24046458
    }, {
      "name" : "Adam Beale",
      "screen_name" : "bealer81",
      "indices" : [ 13, 22 ],
      "id_str" : "238993337",
      "id" : 238993337
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598436542491860992",
  "geo" : { },
  "id_str" : "598436832813195264",
  "in_reply_to_user_id" : 24046458,
  "text" : "@dalecoulter @bealer81 well the number was a rhetorical move though i don't think that exaggerated",
  "id" : 598436832813195264,
  "in_reply_to_status_id" : 598436542491860992,
  "created_at" : "2015-05-13 10:37:14 +0000",
  "in_reply_to_screen_name" : "dalecoulter",
  "in_reply_to_user_id_str" : "24046458",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dale Coulter",
      "screen_name" : "dalecoulter",
      "indices" : [ 0, 12 ],
      "id_str" : "24046458",
      "id" : 24046458
    }, {
      "name" : "Adam Beale",
      "screen_name" : "bealer81",
      "indices" : [ 13, 22 ],
      "id_str" : "238993337",
      "id" : 238993337
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/L9DTWHaaIg",
      "expanded_url" : "http:\/\/greetingsfellowalienatedsubjectoflatecapitalism.com\/#oddjobs",
      "display_url" : "\u2026walienatedsubjectoflatecapitalism.com\/#oddjobs"
    } ]
  },
  "in_reply_to_status_id_str" : "598435368720080896",
  "geo" : { },
  "id_str" : "598436613824315392",
  "in_reply_to_user_id" : 18602422,
  "text" : "@dalecoulter @bealer81 e.g. look at this for extreme (yet i think growing) version of tech sub-contracting http:\/\/t.co\/L9DTWHaaIg",
  "id" : 598436613824315392,
  "in_reply_to_status_id" : 598435368720080896,
  "created_at" : "2015-05-13 10:36:21 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dale Coulter",
      "screen_name" : "dalecoulter",
      "indices" : [ 0, 12 ],
      "id_str" : "24046458",
      "id" : 24046458
    }, {
      "name" : "Adam Beale",
      "screen_name" : "bealer81",
      "indices" : [ 13, 22 ],
      "id_str" : "238993337",
      "id" : 238993337
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598434674625613824",
  "geo" : { },
  "id_str" : "598435368720080896",
  "in_reply_to_user_id" : 24046458,
  "text" : "@dalecoulter @bealer81 for maybe &lt;1% in startups? sub-contracted tech work makes up majority i think",
  "id" : 598435368720080896,
  "in_reply_to_status_id" : 598434674625613824,
  "created_at" : "2015-05-13 10:31:24 +0000",
  "in_reply_to_screen_name" : "dalecoulter",
  "in_reply_to_user_id_str" : "24046458",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zhenya",
      "screen_name" : "ZhenyaDnipro",
      "indices" : [ 0, 13 ],
      "id_str" : "2248486418",
      "id" : 2248486418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/x7oYAJczSX",
      "expanded_url" : "http:\/\/elllo.org",
      "display_url" : "elllo.org"
    }, {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/24Zv50JpVc",
      "expanded_url" : "http:\/\/www.elllo.org\/english\/index_beginner.htm",
      "display_url" : "elllo.org\/english\/index_\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "598433344485859331",
  "geo" : { },
  "id_str" : "598434501207916544",
  "in_reply_to_user_id" : 2248486418,
  "text" : "@ZhenyaDnipro http:\/\/t.co\/x7oYAJczSX has beginner section http:\/\/t.co\/24Zv50JpVc",
  "id" : 598434501207916544,
  "in_reply_to_status_id" : 598433344485859331,
  "created_at" : "2015-05-13 10:27:58 +0000",
  "in_reply_to_screen_name" : "ZhenyaDnipro",
  "in_reply_to_user_id_str" : "2248486418",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Lavigne",
      "screen_name" : "sam_lavigne",
      "indices" : [ 0, 12 ],
      "id_str" : "6428702",
      "id" : 6428702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598433239414525952",
  "in_reply_to_user_id" : 6428702,
  "text" : "@sam_lavigne hi did u mention once u were going to put a franken option for videogrep?",
  "id" : 598433239414525952,
  "created_at" : "2015-05-13 10:22:57 +0000",
  "in_reply_to_screen_name" : "sam_lavigne",
  "in_reply_to_user_id_str" : "6428702",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Higher Education",
      "screen_name" : "GdnHigherEd",
      "indices" : [ 3, 15 ],
      "id_str" : "252124716",
      "id" : 252124716
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/k8y7Gz17NN",
      "expanded_url" : "http:\/\/gu.com\/p\/48a4z\/stw",
      "display_url" : "gu.com\/p\/48a4z\/stw"
    } ]
  },
  "geo" : { },
  "id_str" : "598431965403074560",
  "text" : "RT @GdnHigherEd: What we learned from occupying our university http:\/\/t.co\/k8y7Gz17NN via@gdnstudents",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/k8y7Gz17NN",
        "expanded_url" : "http:\/\/gu.com\/p\/48a4z\/stw",
        "display_url" : "gu.com\/p\/48a4z\/stw"
      } ]
    },
    "geo" : { },
    "id_str" : "598431097635110912",
    "text" : "What we learned from occupying our university http:\/\/t.co\/k8y7Gz17NN via@gdnstudents",
    "id" : 598431097635110912,
    "created_at" : "2015-05-13 10:14:26 +0000",
    "user" : {
      "name" : "Higher Education",
      "screen_name" : "GdnHigherEd",
      "protected" : false,
      "id_str" : "252124716",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/586191777872379904\/S_4p2ygz_normal.jpg",
      "id" : 252124716,
      "verified" : true
    }
  },
  "id" : 598431965403074560,
  "created_at" : "2015-05-13 10:17:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alberto Bruzos",
      "screen_name" : "abruzos",
      "indices" : [ 0, 8 ],
      "id_str" : "150242940",
      "id" : 150242940
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "597879449632268289",
  "geo" : { },
  "id_str" : "598419597906354177",
  "in_reply_to_user_id" : 150242940,
  "text" : "@abruzos the bullshit blizzard is particularly strong in corporate media today",
  "id" : 598419597906354177,
  "in_reply_to_status_id" : 597879449632268289,
  "created_at" : "2015-05-13 09:28:44 +0000",
  "in_reply_to_screen_name" : "abruzos",
  "in_reply_to_user_id_str" : "150242940",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "teachers_as_workers",
      "screen_name" : "taw_sig",
      "indices" : [ 3, 11 ],
      "id_str" : "3152637711",
      "id" : 3152637711
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/taw_sig\/status\/598401572951957504\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/dQioJCoEQn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CE3zDtXWgAIVCFr.png",
      "id_str" : "598401570552840194",
      "id" : 598401570552840194,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CE3zDtXWgAIVCFr.png",
      "sizes" : [ {
        "h" : 168,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 287,
        "resize" : "fit",
        "w" : 582
      }, {
        "h" : 287,
        "resize" : "fit",
        "w" : 582
      }, {
        "h" : 287,
        "resize" : "fit",
        "w" : 582
      } ],
      "display_url" : "pic.twitter.com\/dQioJCoEQn"
    } ],
    "hashtags" : [ {
      "text" : "ELT",
      "indices" : [ 13, 17 ]
    }, {
      "text" : "ESL",
      "indices" : [ 20, 24 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/UNqqIabdKh",
      "expanded_url" : "https:\/\/goo.gl\/QBW5yJ",
      "display_url" : "goo.gl\/QBW5yJ"
    } ]
  },
  "geo" : { },
  "id_str" : "598403030233575424",
  "text" : "RT @taw_sig: #ELT \/ #ESL teachers! Join our G+ group and contribute to our future vision! https:\/\/t.co\/UNqqIabdKh http:\/\/t.co\/dQioJCoEQn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/taw_sig\/status\/598401572951957504\/photo\/1",
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/dQioJCoEQn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CE3zDtXWgAIVCFr.png",
        "id_str" : "598401570552840194",
        "id" : 598401570552840194,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CE3zDtXWgAIVCFr.png",
        "sizes" : [ {
          "h" : 168,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 287,
          "resize" : "fit",
          "w" : 582
        }, {
          "h" : 287,
          "resize" : "fit",
          "w" : 582
        }, {
          "h" : 287,
          "resize" : "fit",
          "w" : 582
        } ],
        "display_url" : "pic.twitter.com\/dQioJCoEQn"
      } ],
      "hashtags" : [ {
        "text" : "ELT",
        "indices" : [ 0, 4 ]
      }, {
        "text" : "ESL",
        "indices" : [ 7, 11 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/UNqqIabdKh",
        "expanded_url" : "https:\/\/goo.gl\/QBW5yJ",
        "display_url" : "goo.gl\/QBW5yJ"
      } ]
    },
    "geo" : { },
    "id_str" : "598401572951957504",
    "text" : "#ELT \/ #ESL teachers! Join our G+ group and contribute to our future vision! https:\/\/t.co\/UNqqIabdKh http:\/\/t.co\/dQioJCoEQn",
    "id" : 598401572951957504,
    "created_at" : "2015-05-13 08:17:07 +0000",
    "user" : {
      "name" : "teachers_as_workers",
      "screen_name" : "taw_sig",
      "protected" : false,
      "id_str" : "3152637711",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/586464982428069888\/7tz5UtJi_normal.png",
      "id" : 3152637711,
      "verified" : false
    }
  },
  "id" : 598403030233575424,
  "created_at" : "2015-05-13 08:22:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 0, 10 ],
      "id_str" : "525274103",
      "id" : 525274103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598399739860619264",
  "geo" : { },
  "id_str" : "598399876628619266",
  "in_reply_to_user_id" : 525274103,
  "text" : "@ElkySmith oh ya gotta! make it a priority :)",
  "id" : 598399876628619266,
  "in_reply_to_status_id" : 598399739860619264,
  "created_at" : "2015-05-13 08:10:22 +0000",
  "in_reply_to_screen_name" : "ElkySmith",
  "in_reply_to_user_id_str" : "525274103",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 0, 10 ],
      "id_str" : "525274103",
      "id" : 525274103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598399290805850112",
  "geo" : { },
  "id_str" : "598399637725261824",
  "in_reply_to_user_id" : 525274103,
  "text" : "@ElkySmith do you watch Silicon Valley? great antidote to corporate edtech discourse",
  "id" : 598399637725261824,
  "in_reply_to_status_id" : 598399290805850112,
  "created_at" : "2015-05-13 08:09:26 +0000",
  "in_reply_to_screen_name" : "ElkySmith",
  "in_reply_to_user_id_str" : "525274103",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Huw Jarvis",
      "screen_name" : "TESOLacademic",
      "indices" : [ 0, 14 ],
      "id_str" : "43409552",
      "id" : 43409552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598239005650608128",
  "geo" : { },
  "id_str" : "598239325889929219",
  "in_reply_to_user_id" : 43409552,
  "text" : "@TESOLacademic um cause there are ELT bods there?",
  "id" : 598239325889929219,
  "in_reply_to_status_id" : 598239005650608128,
  "created_at" : "2015-05-12 21:32:24 +0000",
  "in_reply_to_screen_name" : "TESOLacademic",
  "in_reply_to_user_id_str" : "43409552",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Caines",
      "screen_name" : "cainesap",
      "indices" : [ 0, 9 ],
      "id_str" : "578898729",
      "id" : 578898729
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598237068658085888",
  "geo" : { },
  "id_str" : "598237983523872770",
  "in_reply_to_user_id" : 578898729,
  "text" : "@cainesap hi yes",
  "id" : 598237983523872770,
  "in_reply_to_status_id" : 598237068658085888,
  "created_at" : "2015-05-12 21:27:04 +0000",
  "in_reply_to_screen_name" : "cainesap",
  "in_reply_to_user_id_str" : "578898729",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Huw Jarvis",
      "screen_name" : "TESOLacademic",
      "indices" : [ 0, 14 ],
      "id_str" : "43409552",
      "id" : 43409552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598234175779565568",
  "geo" : { },
  "id_str" : "598237913852280832",
  "in_reply_to_user_id" : 43409552,
  "text" : "@TESOLacademic  do u mean as \"ideological\" as the other country reports?",
  "id" : 598237913852280832,
  "in_reply_to_status_id" : 598234175779565568,
  "created_at" : "2015-05-12 21:26:48 +0000",
  "in_reply_to_screen_name" : "TESOLacademic",
  "in_reply_to_user_id_str" : "43409552",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Phipps",
      "screen_name" : "lousylinguist",
      "indices" : [ 3, 17 ],
      "id_str" : "48459936",
      "id" : 48459936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/8wRrfnIoCN",
      "expanded_url" : "https:\/\/medium.com\/backchannel\/this-woman-makes-robots-and-no-one-is-going-to-stop-her-f58ac7f5cbbb",
      "display_url" : "medium.com\/backchannel\/th\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "598218850048614401",
  "text" : "RT @lousylinguist: \"Wise had written tutorials that made the software  accessible. She also founded and ran a large internship program\" htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/8wRrfnIoCN",
        "expanded_url" : "https:\/\/medium.com\/backchannel\/this-woman-makes-robots-and-no-one-is-going-to-stop-her-f58ac7f5cbbb",
        "display_url" : "medium.com\/backchannel\/th\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "598170008649342978",
    "text" : "\"Wise had written tutorials that made the software  accessible. She also founded and ran a large internship program\" https:\/\/t.co\/8wRrfnIoCN",
    "id" : 598170008649342978,
    "created_at" : "2015-05-12 16:56:58 +0000",
    "user" : {
      "name" : "Christopher Phipps",
      "screen_name" : "lousylinguist",
      "protected" : false,
      "id_str" : "48459936",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750789987113660416\/2IPugaM9_normal.jpg",
      "id" : 48459936,
      "verified" : false
    }
  },
  "id" : 598218850048614401,
  "created_at" : "2015-05-12 20:11:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Caines",
      "screen_name" : "cainesap",
      "indices" : [ 0, 9 ],
      "id_str" : "578898729",
      "id" : 578898729
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598147828955881472",
  "in_reply_to_user_id" : 578898729,
  "text" : "@cainesap hi fyi Andrew the Crowdee app is still incompatible with my phone",
  "id" : 598147828955881472,
  "created_at" : "2015-05-12 15:28:50 +0000",
  "in_reply_to_screen_name" : "cainesap",
  "in_reply_to_user_id_str" : "578898729",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 36, 47 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 48, 56 ]
    }, {
      "text" : "keltchat",
      "indices" : [ 57, 66 ]
    }, {
      "text" : "auselt",
      "indices" : [ 67, 74 ]
    }, {
      "text" : "eltchinwag",
      "indices" : [ 75, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/gY5AYyGU6s",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-WP",
      "display_url" : "wp.me\/pgHyE-WP"
    } ]
  },
  "geo" : { },
  "id_str" : "598146959795453952",
  "text" : "Corpus Linguistics Community News 5 #corpusmooc #eltchat #keltchat #auselt #eltchinwag http:\/\/t.co\/gY5AYyGU6s",
  "id" : 598146959795453952,
  "created_at" : "2015-05-12 15:25:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    }, {
      "name" : "BBC News (UK)",
      "screen_name" : "BBCNews",
      "indices" : [ 16, 24 ],
      "id_str" : "612473",
      "id" : 612473
    }, {
      "name" : "David Cameron",
      "screen_name" : "David_Cameron",
      "indices" : [ 82, 96 ],
      "id_str" : "103065157",
      "id" : 103065157
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/medialens\/status\/598089782657417216\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/jEhXeoOEBi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEzXfOCW0AALqeU.jpg",
      "id_str" : "598089781877329920",
      "id" : 598089781877329920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEzXfOCW0AALqeU.jpg",
      "sizes" : [ {
        "h" : 564,
        "resize" : "fit",
        "w" : 686
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 564,
        "resize" : "fit",
        "w" : 686
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 493,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/jEhXeoOEBi"
    } ],
    "hashtags" : [ {
      "text" : "Propaganda",
      "indices" : [ 98, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/KnUjveeWts",
      "expanded_url" : "http:\/\/www.medialens.org\/index.php\/alerts\/alert-archive\/2015\/792-unfree-elections-the-corporate-media-uk-general-election-and-predictable-outcomes.html",
      "display_url" : "medialens.org\/index.php\/aler\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "598119074640592896",
  "text" : "RT @medialens: .@BBCNews marked the Tories' return to power with a love letter to @David_Cameron  #Propaganda http:\/\/t.co\/KnUjveeWts http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BBC News (UK)",
        "screen_name" : "BBCNews",
        "indices" : [ 1, 9 ],
        "id_str" : "612473",
        "id" : 612473
      }, {
        "name" : "David Cameron",
        "screen_name" : "David_Cameron",
        "indices" : [ 67, 81 ],
        "id_str" : "103065157",
        "id" : 103065157
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/medialens\/status\/598089782657417216\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/jEhXeoOEBi",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CEzXfOCW0AALqeU.jpg",
        "id_str" : "598089781877329920",
        "id" : 598089781877329920,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEzXfOCW0AALqeU.jpg",
        "sizes" : [ {
          "h" : 564,
          "resize" : "fit",
          "w" : 686
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 564,
          "resize" : "fit",
          "w" : 686
        }, {
          "h" : 280,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 493,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/jEhXeoOEBi"
      } ],
      "hashtags" : [ {
        "text" : "Propaganda",
        "indices" : [ 83, 94 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/KnUjveeWts",
        "expanded_url" : "http:\/\/www.medialens.org\/index.php\/alerts\/alert-archive\/2015\/792-unfree-elections-the-corporate-media-uk-general-election-and-predictable-outcomes.html",
        "display_url" : "medialens.org\/index.php\/aler\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "598089782657417216",
    "text" : ".@BBCNews marked the Tories' return to power with a love letter to @David_Cameron  #Propaganda http:\/\/t.co\/KnUjveeWts http:\/\/t.co\/jEhXeoOEBi",
    "id" : 598089782657417216,
    "created_at" : "2015-05-12 11:38:10 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 598119074640592896,
  "created_at" : "2015-05-12 13:34:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/5uRR6NwtCq",
      "expanded_url" : "http:\/\/www.bbc.com\/future\/story\/20150429-how-to-learn-with-zero-effort",
      "display_url" : "bbc.com\/future\/story\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "598092376196980736",
  "text" : "How to supercharge the way you learn  http:\/\/t.co\/5uRR6NwtCq",
  "id" : 598092376196980736,
  "created_at" : "2015-05-12 11:48:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 0, 11 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598071826800054272",
  "geo" : { },
  "id_str" : "598080972727394304",
  "in_reply_to_user_id" : 87902543,
  "text" : "@tornhalves on a shallower note dunkin Dawkins is always a noble endeavour :)",
  "id" : 598080972727394304,
  "in_reply_to_status_id" : 598071826800054272,
  "created_at" : "2015-05-12 11:03:10 +0000",
  "in_reply_to_screen_name" : "tornhalves",
  "in_reply_to_user_id_str" : "87902543",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Damien Hall",
      "screen_name" : "hall_damien",
      "indices" : [ 3, 15 ],
      "id_str" : "125061212",
      "id" : 125061212
    }, {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "indices" : [ 92, 103 ],
      "id_str" : "152051625",
      "id" : 152051625
    }, {
      "name" : "Rachelle Vessey",
      "screen_name" : "RachelleVessey",
      "indices" : [ 104, 119 ],
      "id_str" : "342810819",
      "id" : 342810819
    }, {
      "name" : "Dawn Knight",
      "screen_name" : "nottyknight",
      "indices" : [ 120, 132 ],
      "id_str" : "83570076",
      "id" : 83570076
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/XHa6THYTDt",
      "expanded_url" : "https:\/\/twitter.com\/MassObsArchive\/status\/598035147045392384",
      "display_url" : "twitter.com\/MassObsArchive\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "598058425973665793",
  "text" : "RT @hall_damien: I'm tweeting this. Please do it too! Future corpus linguists'll thank you! @heatherfro @RachelleVessey @nottyknight https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "heather froehlich",
        "screen_name" : "heatherfro",
        "indices" : [ 75, 86 ],
        "id_str" : "152051625",
        "id" : 152051625
      }, {
        "name" : "Rachelle Vessey",
        "screen_name" : "RachelleVessey",
        "indices" : [ 87, 102 ],
        "id_str" : "342810819",
        "id" : 342810819
      }, {
        "name" : "Dawn Knight",
        "screen_name" : "nottyknight",
        "indices" : [ 103, 115 ],
        "id_str" : "83570076",
        "id" : 83570076
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/XHa6THYTDt",
        "expanded_url" : "https:\/\/twitter.com\/MassObsArchive\/status\/598035147045392384",
        "display_url" : "twitter.com\/MassObsArchive\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "598040266801545216",
    "text" : "I'm tweeting this. Please do it too! Future corpus linguists'll thank you! @heatherfro @RachelleVessey @nottyknight https:\/\/t.co\/XHa6THYTDt",
    "id" : 598040266801545216,
    "created_at" : "2015-05-12 08:21:25 +0000",
    "user" : {
      "name" : "Damien Hall",
      "screen_name" : "hall_damien",
      "protected" : false,
      "id_str" : "125061212",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1365859587\/358cd8da-c104-4e8e-a7e6-fbd44d2a3321_normal.png",
      "id" : 125061212,
      "verified" : false
    }
  },
  "id" : 598058425973665793,
  "created_at" : "2015-05-12 09:33:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 60, 71 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/dZiYF4K6Jl",
      "expanded_url" : "http:\/\/www.digitalcounterrevolution.co.uk\/2015\/richard-dawkins-the-god-delusion\/",
      "display_url" : "digitalcounterrevolution.co.uk\/2015\/richard-d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "597867682583728129",
  "text" : "Richard Dawkins: The God Delusion http:\/\/t.co\/dZiYF4K6Jl by @tornhalves",
  "id" : 597867682583728129,
  "created_at" : "2015-05-11 20:55:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RT",
      "screen_name" : "RT_com",
      "indices" : [ 3, 10 ],
      "id_str" : "64643056",
      "id" : 64643056
    }, {
      "name" : "Neil Clark",
      "screen_name" : "NeilClark66",
      "indices" : [ 71, 83 ],
      "id_str" : "728039605",
      "id" : 728039605
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/RT_com\/status\/597488661438009344\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/rq1pzG9KI7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEq0xQdUMAAZoRq.jpg",
      "id_str" : "597488658904526848",
      "id" : 597488658904526848,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEq0xQdUMAAZoRq.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 388,
        "resize" : "fit",
        "w" : 690
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 388,
        "resize" : "fit",
        "w" : 690
      } ],
      "display_url" : "pic.twitter.com\/rq1pzG9KI7"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/3LUQuylX7K",
      "expanded_url" : "http:\/\/on.rt.com\/zgo5sm",
      "display_url" : "on.rt.com\/zgo5sm"
    } ]
  },
  "geo" : { },
  "id_str" : "597641151177486336",
  "text" : "RT @RT_com: UK general election: Establishment wins again? (Op-Edge by @NeilClark66) http:\/\/t.co\/3LUQuylX7K http:\/\/t.co\/rq1pzG9KI7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Neil Clark",
        "screen_name" : "NeilClark66",
        "indices" : [ 59, 71 ],
        "id_str" : "728039605",
        "id" : 728039605
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/RT_com\/status\/597488661438009344\/photo\/1",
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/rq1pzG9KI7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CEq0xQdUMAAZoRq.jpg",
        "id_str" : "597488658904526848",
        "id" : 597488658904526848,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEq0xQdUMAAZoRq.jpg",
        "sizes" : [ {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 388,
          "resize" : "fit",
          "w" : 690
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 388,
          "resize" : "fit",
          "w" : 690
        } ],
        "display_url" : "pic.twitter.com\/rq1pzG9KI7"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/3LUQuylX7K",
        "expanded_url" : "http:\/\/on.rt.com\/zgo5sm",
        "display_url" : "on.rt.com\/zgo5sm"
      } ]
    },
    "geo" : { },
    "id_str" : "597488661438009344",
    "text" : "UK general election: Establishment wins again? (Op-Edge by @NeilClark66) http:\/\/t.co\/3LUQuylX7K http:\/\/t.co\/rq1pzG9KI7",
    "id" : 597488661438009344,
    "created_at" : "2015-05-10 19:49:32 +0000",
    "user" : {
      "name" : "RT",
      "screen_name" : "RT_com",
      "protected" : false,
      "id_str" : "64643056",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/675283352862089216\/GE1X4ASz_normal.png",
      "id" : 64643056,
      "verified" : true
    }
  },
  "id" : 597641151177486336,
  "created_at" : "2015-05-11 05:55:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 57, 72 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Presentation",
      "indices" : [ 17, 30 ]
    } ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/TI8i0B4vvd",
      "expanded_url" : "http:\/\/www.authorstream.com\/Presentation\/geoffjordan-2484135-cousebook-out3\/",
      "display_url" : "authorstream.com\/Presentation\/g\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "597636284895625217",
  "text" : "cousebook out3 - #Presentation http:\/\/t.co\/TI8i0B4vvd by @GeoffreyJordan",
  "id" : 597636284895625217,
  "created_at" : "2015-05-11 05:36:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Englicious - Grammar",
      "screen_name" : "EngliciousUCL",
      "indices" : [ 39, 53 ],
      "id_str" : "3187104424",
      "id" : 3187104424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/pOEM2tqy3Y",
      "expanded_url" : "http:\/\/wp.me\/p66Mp6-1O",
      "display_url" : "wp.me\/p66Mp6-1O"
    } ]
  },
  "geo" : { },
  "id_str" : "597482726506287104",
  "text" : "Determiners http:\/\/t.co\/pOEM2tqy3Y via @EngliciousUCL",
  "id" : 597482726506287104,
  "created_at" : "2015-05-10 19:25:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tekhnologic",
      "screen_name" : "tekhnologicblog",
      "indices" : [ 84, 100 ],
      "id_str" : "1486688384",
      "id" : 1486688384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/HP75giMmiq",
      "expanded_url" : "http:\/\/wp.me\/p577Go-fw",
      "display_url" : "wp.me\/p577Go-fw"
    } ]
  },
  "geo" : { },
  "id_str" : "597453781123596288",
  "text" : "Phrase Maze - turning vocabulary flashcards into a game. http:\/\/t.co\/HP75giMmiq via @tekhnologicblog",
  "id" : 597453781123596288,
  "created_at" : "2015-05-10 17:30:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luan Hanratty",
      "screen_name" : "TEFL101",
      "indices" : [ 0, 8 ],
      "id_str" : "228931788",
      "id" : 228931788
    }, {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 9, 22 ],
      "id_str" : "88655243",
      "id" : 88655243
    }, {
      "name" : "teachers_as_workers",
      "screen_name" : "taw_sig",
      "indices" : [ 23, 31 ],
      "id_str" : "3152637711",
      "id" : 3152637711
    }, {
      "name" : "Patrick Jackson",
      "screen_name" : "patjack67",
      "indices" : [ 43, 53 ],
      "id_str" : "19790204",
      "id" : 19790204
    }, {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 54, 69 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "597333299925749760",
  "geo" : { },
  "id_str" : "597343036721463296",
  "in_reply_to_user_id" : 228931788,
  "text" : "@TEFL101 @rosemerebard @taw_sig @HadaLitim @patjack67 @GeoffreyJordan also tradeoff btw effective material and portable material",
  "id" : 597343036721463296,
  "in_reply_to_status_id" : 597333299925749760,
  "created_at" : "2015-05-10 10:10:52 +0000",
  "in_reply_to_screen_name" : "TEFL101",
  "in_reply_to_user_id_str" : "228931788",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Lavigne",
      "screen_name" : "sam_lavigne",
      "indices" : [ 3, 15 ],
      "id_str" : "6428702",
      "id" : 6428702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/owxhi679wl",
      "expanded_url" : "http:\/\/greetingsfellowalienatedsubjectoflatecapitalism.com\/",
      "display_url" : "\u2026walienatedsubjectoflatecapitalism.com"
    } ]
  },
  "geo" : { },
  "id_str" : "597326843742658560",
  "text" : "RT @sam_lavigne: here's my ITP thesis project: \"Greetings, Fellow Aliented Subject of Late Capitalism\" http:\/\/t.co\/owxhi679wl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/owxhi679wl",
        "expanded_url" : "http:\/\/greetingsfellowalienatedsubjectoflatecapitalism.com\/",
        "display_url" : "\u2026walienatedsubjectoflatecapitalism.com"
      } ]
    },
    "geo" : { },
    "id_str" : "597168834714406912",
    "text" : "here's my ITP thesis project: \"Greetings, Fellow Aliented Subject of Late Capitalism\" http:\/\/t.co\/owxhi679wl",
    "id" : 597168834714406912,
    "created_at" : "2015-05-09 22:38:39 +0000",
    "user" : {
      "name" : "Sam Lavigne",
      "screen_name" : "sam_lavigne",
      "protected" : false,
      "id_str" : "6428702",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/453703393907712000\/-NTZsg_T_normal.jpeg",
      "id" : 6428702,
      "verified" : false
    }
  },
  "id" : 597326843742658560,
  "created_at" : "2015-05-10 09:06:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Igor Brigadir",
      "screen_name" : "IgorBrigadir",
      "indices" : [ 3, 16 ],
      "id_str" : "495430242",
      "id" : 495430242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/OF6yLxeFyt",
      "expanded_url" : "http:\/\/www.latimes.com\/science\/sciencenow\/la-sci-sn-pop-music-trends-20150505-story.html",
      "display_url" : "latimes.com\/science\/scienc\u2026"
    }, {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/X5Fz1NJ7je",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=OET8SVAGELA&t=3m51s",
      "display_url" : "youtube.com\/watch?v=OET8SV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "597092244714299392",
  "text" : "RT @IgorBrigadir: http:\/\/t.co\/OF6yLxeFyt\n\"\u2026one sampled note over and over, w. talk layered on it (hint - not music)\"\n\nI LOVE not music http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/OF6yLxeFyt",
        "expanded_url" : "http:\/\/www.latimes.com\/science\/sciencenow\/la-sci-sn-pop-music-trends-20150505-story.html",
        "display_url" : "latimes.com\/science\/scienc\u2026"
      }, {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/X5Fz1NJ7je",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=OET8SVAGELA&t=3m51s",
        "display_url" : "youtube.com\/watch?v=OET8SV\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "597081698443120640",
    "text" : "http:\/\/t.co\/OF6yLxeFyt\n\"\u2026one sampled note over and over, w. talk layered on it (hint - not music)\"\n\nI LOVE not music https:\/\/t.co\/X5Fz1NJ7je",
    "id" : 597081698443120640,
    "created_at" : "2015-05-09 16:52:24 +0000",
    "user" : {
      "name" : "Igor Brigadir",
      "screen_name" : "IgorBrigadir",
      "protected" : false,
      "id_str" : "495430242",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2538946114\/xiveugt78rc97y1dasxf_normal.jpeg",
      "id" : 495430242,
      "verified" : false
    }
  },
  "id" : 597092244714299392,
  "created_at" : "2015-05-09 17:34:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 63, 73 ],
      "id_str" : "525274103",
      "id" : 525274103
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ielt15",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/VPXHjgNNli",
      "expanded_url" : "https:\/\/elkysmith.typeform.com\/to\/sGKyvb",
      "display_url" : "elkysmith.typeform.com\/to\/sGKyvb"
    } ]
  },
  "geo" : { },
  "id_str" : "597085609069510658",
  "text" : "#ielt15 participants may be interested in this short survey by @ElkySmith on attitudes to edtech https:\/\/t.co\/VPXHjgNNli",
  "id" : 597085609069510658,
  "created_at" : "2015-05-09 17:07:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "teachers_as_workers",
      "screen_name" : "taw_sig",
      "indices" : [ 3, 11 ],
      "id_str" : "3152637711",
      "id" : 3152637711
    }, {
      "name" : "Mike S. Boyle",
      "screen_name" : "heyboyle",
      "indices" : [ 13, 22 ],
      "id_str" : "612840231",
      "id" : 612840231
    }, {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 23, 36 ],
      "id_str" : "88655243",
      "id" : 88655243
    }, {
      "name" : "Patrick Jackson",
      "screen_name" : "patjack67",
      "indices" : [ 48, 58 ],
      "id_str" : "19790204",
      "id" : 19790204
    }, {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 59, 74 ],
      "id_str" : "334332424",
      "id" : 334332424
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 75, 84 ],
      "id_str" : "18602422",
      "id" : 18602422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/cJD5wwLoc0",
      "expanded_url" : "http:\/\/www.irishtimes.com\/news\/ireland\/irish-news\/international-students-hold-protest-in-dublin-city-centre-1.2200513",
      "display_url" : "irishtimes.com\/news\/ireland\/i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "597064658487480320",
  "text" : "RT @taw_sig: @heyboyle @rosemerebard @HadaLitim @patjack67 @GeoffreyJordan @muranava http:\/\/t.co\/cJD5wwLoc0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mike S. Boyle",
        "screen_name" : "heyboyle",
        "indices" : [ 0, 9 ],
        "id_str" : "612840231",
        "id" : 612840231
      }, {
        "name" : "Rose Bard",
        "screen_name" : "rosemerebard",
        "indices" : [ 10, 23 ],
        "id_str" : "88655243",
        "id" : 88655243
      }, {
        "name" : "Patrick Jackson",
        "screen_name" : "patjack67",
        "indices" : [ 35, 45 ],
        "id_str" : "19790204",
        "id" : 19790204
      }, {
        "name" : "Geoffrey Jordan",
        "screen_name" : "GeoffreyJordan",
        "indices" : [ 46, 61 ],
        "id_str" : "334332424",
        "id" : 334332424
      }, {
        "name" : "Mura Nava",
        "screen_name" : "muranava",
        "indices" : [ 62, 71 ],
        "id_str" : "18602422",
        "id" : 18602422
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/cJD5wwLoc0",
        "expanded_url" : "http:\/\/www.irishtimes.com\/news\/ireland\/irish-news\/international-students-hold-protest-in-dublin-city-centre-1.2200513",
        "display_url" : "irishtimes.com\/news\/ireland\/i\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "597063436657422336",
    "geo" : { },
    "id_str" : "597063531553542144",
    "in_reply_to_user_id" : 612840231,
    "text" : "@heyboyle @rosemerebard @HadaLitim @patjack67 @GeoffreyJordan @muranava http:\/\/t.co\/cJD5wwLoc0",
    "id" : 597063531553542144,
    "in_reply_to_status_id" : 597063436657422336,
    "created_at" : "2015-05-09 15:40:13 +0000",
    "in_reply_to_screen_name" : "heyboyle",
    "in_reply_to_user_id_str" : "612840231",
    "user" : {
      "name" : "teachers_as_workers",
      "screen_name" : "taw_sig",
      "protected" : false,
      "id_str" : "3152637711",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/586464982428069888\/7tz5UtJi_normal.png",
      "id" : 3152637711,
      "verified" : false
    }
  },
  "id" : 597064658487480320,
  "created_at" : "2015-05-09 15:44:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenys Hanson",
      "screen_name" : "GlenysHanson",
      "indices" : [ 0, 13 ],
      "id_str" : "527238447",
      "id" : 527238447
    }, {
      "name" : "Liam T",
      "screen_name" : "Liam_ELT",
      "indices" : [ 14, 23 ],
      "id_str" : "3165901457",
      "id" : 3165901457
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "597026843892576256",
  "geo" : { },
  "id_str" : "597035589452615680",
  "in_reply_to_user_id" : 527238447,
  "text" : "@GlenysHanson @Liam_ELT @HadaLitim have u tried spoken section of COCA-BYU?",
  "id" : 597035589452615680,
  "in_reply_to_status_id" : 597026843892576256,
  "created_at" : "2015-05-09 13:49:11 +0000",
  "in_reply_to_screen_name" : "GlenysHanson",
  "in_reply_to_user_id_str" : "527238447",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jo Sayers",
      "screen_name" : "jo_sayers",
      "indices" : [ 0, 10 ],
      "id_str" : "87176766",
      "id" : 87176766
    }, {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 11, 22 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iELT15",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "597008541543727104",
  "geo" : { },
  "id_str" : "597010920825593856",
  "in_reply_to_user_id" : 300734173,
  "text" : "@jo_sayers @lexicoloco if innovation is from &amp; about community are enough of the ELT community being represented\/heard\/involved? #iELT15",
  "id" : 597010920825593856,
  "in_reply_to_status_id" : 597008541543727104,
  "created_at" : "2015-05-09 12:11:10 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jo Sayers",
      "screen_name" : "jo_sayers",
      "indices" : [ 0, 10 ],
      "id_str" : "87176766",
      "id" : 87176766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "597004024496431104",
  "geo" : { },
  "id_str" : "597006046624886785",
  "in_reply_to_user_id" : 87176766,
  "text" : "@jo_sayers give us a wave Jo :)",
  "id" : 597006046624886785,
  "in_reply_to_status_id" : 597004024496431104,
  "created_at" : "2015-05-09 11:51:48 +0000",
  "in_reply_to_screen_name" : "jo_sayers",
  "in_reply_to_user_id_str" : "87176766",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anna Varna",
      "screen_name" : "annabooklover",
      "indices" : [ 0, 14 ],
      "id_str" : "43068002",
      "id" : 43068002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "596996396424781824",
  "geo" : { },
  "id_str" : "596998585939529728",
  "in_reply_to_user_id" : 43068002,
  "text" : "@annabooklover how much of that is tongue in cheek? :)",
  "id" : 596998585939529728,
  "in_reply_to_status_id" : 596996396424781824,
  "created_at" : "2015-05-09 11:22:09 +0000",
  "in_reply_to_screen_name" : "annabooklover",
  "in_reply_to_user_id_str" : "43068002",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenys Hanson",
      "screen_name" : "GlenysHanson",
      "indices" : [ 0, 13 ],
      "id_str" : "527238447",
      "id" : 527238447
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "596976463032758272",
  "geo" : { },
  "id_str" : "596988317431889920",
  "in_reply_to_user_id" : 527238447,
  "text" : "@GlenysHanson wordlists - use with caution! :)",
  "id" : 596988317431889920,
  "in_reply_to_status_id" : 596976463032758272,
  "created_at" : "2015-05-09 10:41:21 +0000",
  "in_reply_to_screen_name" : "GlenysHanson",
  "in_reply_to_user_id_str" : "527238447",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anna Varna",
      "screen_name" : "annabooklover",
      "indices" : [ 0, 14 ],
      "id_str" : "43068002",
      "id" : 43068002
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iELT15",
      "indices" : [ 39, 46 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "596986878806663168",
  "geo" : { },
  "id_str" : "596987607936049152",
  "in_reply_to_user_id" : 43068002,
  "text" : "@annabooklover who is selling us that? #iELT15",
  "id" : 596987607936049152,
  "in_reply_to_status_id" : 596986878806663168,
  "created_at" : "2015-05-09 10:38:31 +0000",
  "in_reply_to_screen_name" : "annabooklover",
  "in_reply_to_user_id_str" : "43068002",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anna Varna",
      "screen_name" : "annabooklover",
      "indices" : [ 0, 14 ],
      "id_str" : "43068002",
      "id" : 43068002
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iELT15",
      "indices" : [ 100, 107 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "596985071342608385",
  "geo" : { },
  "id_str" : "596985933938991105",
  "in_reply_to_user_id" : 43068002,
  "text" : "@annabooklover maybe because the schtick being sold is offline limitations are greater than online? #iELT15",
  "id" : 596985933938991105,
  "in_reply_to_status_id" : 596985071342608385,
  "created_at" : "2015-05-09 10:31:52 +0000",
  "in_reply_to_screen_name" : "annabooklover",
  "in_reply_to_user_id_str" : "43068002",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Beale",
      "screen_name" : "bealer81",
      "indices" : [ 0, 9 ],
      "id_str" : "238993337",
      "id" : 238993337
    }, {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 10, 25 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iELT15",
      "indices" : [ 121, 128 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "596956444676771841",
  "geo" : { },
  "id_str" : "596958795273805824",
  "in_reply_to_user_id" : 238993337,
  "text" : "@bealer81 @GeoffreyJordan most if not all current \"innovation\" proponents purposely ignores or tries to rewrite the past #iELT15",
  "id" : 596958795273805824,
  "in_reply_to_status_id" : 596956444676771841,
  "created_at" : "2015-05-09 08:44:02 +0000",
  "in_reply_to_screen_name" : "bealer81",
  "in_reply_to_user_id_str" : "238993337",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Beale",
      "screen_name" : "bealer81",
      "indices" : [ 0, 9 ],
      "id_str" : "238993337",
      "id" : 238993337
    }, {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 10, 25 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "596951561718337537",
  "geo" : { },
  "id_str" : "596953471414317056",
  "in_reply_to_user_id" : 238993337,
  "text" : "@bealer81 @GeoffreyJordan what a slide :)",
  "id" : 596953471414317056,
  "in_reply_to_status_id" : 596951561718337537,
  "created_at" : "2015-05-09 08:22:53 +0000",
  "in_reply_to_screen_name" : "bealer81",
  "in_reply_to_user_id_str" : "238993337",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Beale",
      "screen_name" : "bealer81",
      "indices" : [ 3, 12 ],
      "id_str" : "238993337",
      "id" : 238993337
    }, {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 14, 29 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/bealer81\/status\/596951561718337537\/photo\/1",
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/JyiO5REIZz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEjMR7LWoAAZVfy.jpg",
      "id_str" : "596951558941745152",
      "id" : 596951558941745152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEjMR7LWoAAZVfy.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      } ],
      "display_url" : "pic.twitter.com\/JyiO5REIZz"
    } ],
    "hashtags" : [ {
      "text" : "iELT15",
      "indices" : [ 30, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596952446666170368",
  "text" : "RT @bealer81: @GeoffreyJordan #iELT15 http:\/\/t.co\/JyiO5REIZz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for Windows Phone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Geoffrey Jordan",
        "screen_name" : "GeoffreyJordan",
        "indices" : [ 0, 15 ],
        "id_str" : "334332424",
        "id" : 334332424
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/bealer81\/status\/596951561718337537\/photo\/1",
        "indices" : [ 24, 46 ],
        "url" : "http:\/\/t.co\/JyiO5REIZz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CEjMR7LWoAAZVfy.jpg",
        "id_str" : "596951558941745152",
        "id" : 596951558941745152,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEjMR7LWoAAZVfy.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        }, {
          "h" : 604,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        } ],
        "display_url" : "pic.twitter.com\/JyiO5REIZz"
      } ],
      "hashtags" : [ {
        "text" : "iELT15",
        "indices" : [ 16, 23 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "596951561718337537",
    "in_reply_to_user_id" : 334332424,
    "text" : "@GeoffreyJordan #iELT15 http:\/\/t.co\/JyiO5REIZz",
    "id" : 596951561718337537,
    "created_at" : "2015-05-09 08:15:17 +0000",
    "in_reply_to_screen_name" : "GeoffreyJordan",
    "in_reply_to_user_id_str" : "334332424",
    "user" : {
      "name" : "Adam Beale",
      "screen_name" : "bealer81",
      "protected" : false,
      "id_str" : "238993337",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/511530642450829312\/79xIjlRq_normal.jpeg",
      "id" : 238993337,
      "verified" : false
    }
  },
  "id" : 596952446666170368,
  "created_at" : "2015-05-09 08:18:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 92, 108 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/5RwQwtl60O",
      "expanded_url" : "http:\/\/wp.me\/p21lsm-1dm",
      "display_url" : "wp.me\/p21lsm-1dm"
    } ]
  },
  "geo" : { },
  "id_str" : "596946457539833856",
  "text" : "Self-studying for IELTS: a tip for improving your speaking score http:\/\/t.co\/5RwQwtl60O via @wordpressdotcom",
  "id" : 596946457539833856,
  "created_at" : "2015-05-09 07:55:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u0119drek St\u0119pie\u0144",
      "screen_name" : "studiomentals",
      "indices" : [ 0, 14 ],
      "id_str" : "1185386454",
      "id" : 1185386454
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iELT15",
      "indices" : [ 70, 77 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "596919287933247488",
  "geo" : { },
  "id_str" : "596942245548425216",
  "in_reply_to_user_id" : 1185386454,
  "text" : "@studiomentals r people still taking &amp; using that term seriously? #iELT15",
  "id" : 596942245548425216,
  "in_reply_to_status_id" : 596919287933247488,
  "created_at" : "2015-05-09 07:38:16 +0000",
  "in_reply_to_screen_name" : "studiomentals",
  "in_reply_to_user_id_str" : "1185386454",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/aw5QyR4NJ6",
      "expanded_url" : "http:\/\/www.jonathan-cook.net\/blog\/2015-05-08\/the-real-lessons-of-the-tory-victory\/",
      "display_url" : "jonathan-cook.net\/blog\/2015-05-0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "596818464414793728",
  "text" : "\"We are so imaginatively confined we cannot even see the narrow walls within which our minds are allowed to wander.\"  http:\/\/t.co\/aw5QyR4NJ6",
  "id" : 596818464414793728,
  "created_at" : "2015-05-08 23:26:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenys Hanson",
      "screen_name" : "GlenysHanson",
      "indices" : [ 0, 13 ],
      "id_str" : "527238447",
      "id" : 527238447
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "596804539539394563",
  "geo" : { },
  "id_str" : "596810224738181120",
  "in_reply_to_user_id" : 527238447,
  "text" : "@GlenysHanson coha shows decline for those 4 verbs you mention",
  "id" : 596810224738181120,
  "in_reply_to_status_id" : 596804539539394563,
  "created_at" : "2015-05-08 22:53:40 +0000",
  "in_reply_to_screen_name" : "GlenysHanson",
  "in_reply_to_user_id_str" : "527238447",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenys Hanson",
      "screen_name" : "GlenysHanson",
      "indices" : [ 0, 13 ],
      "id_str" : "527238447",
      "id" : 527238447
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/SWEa9NQIdR",
      "expanded_url" : "http:\/\/ieas.unideb.hu\/admin\/file_7142.pdf",
      "display_url" : "ieas.unideb.hu\/admin\/file_714\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "596804539539394563",
  "geo" : { },
  "id_str" : "596808662636695552",
  "in_reply_to_user_id" : 527238447,
  "text" : "@GlenysHanson @HadaLitim another list using more \"recent\" data http:\/\/t.co\/SWEa9NQIdR",
  "id" : 596808662636695552,
  "in_reply_to_status_id" : 596804539539394563,
  "created_at" : "2015-05-08 22:47:27 +0000",
  "in_reply_to_screen_name" : "GlenysHanson",
  "in_reply_to_user_id_str" : "527238447",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenys Hanson",
      "screen_name" : "GlenysHanson",
      "indices" : [ 0, 13 ],
      "id_str" : "527238447",
      "id" : 527238447
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "596804539539394563",
  "geo" : { },
  "id_str" : "596807857129005056",
  "in_reply_to_user_id" : 527238447,
  "text" : "@GlenysHanson @HadaLitim post says from brown and lob",
  "id" : 596807857129005056,
  "in_reply_to_status_id" : 596804539539394563,
  "created_at" : "2015-05-08 22:44:15 +0000",
  "in_reply_to_screen_name" : "GlenysHanson",
  "in_reply_to_user_id_str" : "527238447",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/LTa3zOebMR",
      "expanded_url" : "http:\/\/members5.boardhost.com\/medialens\/msg\/1431113748.html",
      "display_url" : "members5.boardhost.com\/medialens\/msg\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "596794844044890113",
  "text" : "The left did make gains http:\/\/t.co\/LTa3zOebMR",
  "id" : 596794844044890113,
  "created_at" : "2015-05-08 21:52:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "596788849705029632",
  "geo" : { },
  "id_str" : "596789729162620928",
  "in_reply_to_user_id" : 44631065,
  "text" : "@HadaLitim probably :)",
  "id" : 596789729162620928,
  "in_reply_to_status_id" : 596788849705029632,
  "created_at" : "2015-05-08 21:32:13 +0000",
  "in_reply_to_screen_name" : "Hada_ELT",
  "in_reply_to_user_id_str" : "44631065",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "596787153167757314",
  "geo" : { },
  "id_str" : "596788120890286080",
  "in_reply_to_user_id" : 44631065,
  "text" : "@HadaLitim yr welcome, something to share with sts if needed :)",
  "id" : 596788120890286080,
  "in_reply_to_status_id" : 596787153167757314,
  "created_at" : "2015-05-08 21:25:50 +0000",
  "in_reply_to_screen_name" : "Hada_ELT",
  "in_reply_to_user_id_str" : "44631065",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 63, 79 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/FpXGUWjmK5",
      "expanded_url" : "http:\/\/wp.me\/pVjnF-xf",
      "display_url" : "wp.me\/pVjnF-xf"
    } ]
  },
  "geo" : { },
  "id_str" : "596785497185374208",
  "text" : "But Why Are Irregulars \"Irregular?\" http:\/\/t.co\/FpXGUWjmK5 via @wordpressdotcom",
  "id" : 596785497185374208,
  "created_at" : "2015-05-08 21:15:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Nafeez Ahmed",
      "screen_name" : "NafeezAhmed",
      "indices" : [ 61, 73 ],
      "id_str" : "110692399",
      "id" : 110692399
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/fOYMbbYShP",
      "expanded_url" : "https:\/\/medium.com\/@NafeezAhmed\/how-big-money-and-big-brother-won-the-british-elections-2e8da57faac4?source=tw-lo_dnt_b800f487d5db-1431117073685",
      "display_url" : "medium.com\/@NafeezAhmed\/h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "596774393591812096",
  "text" : "\u201CHow Big Money and Big Brother won the British Elections\u201D by @NafeezAhmed https:\/\/t.co\/fOYMbbYShP",
  "id" : 596774393591812096,
  "created_at" : "2015-05-08 20:31:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KirstenCampbellHowes",
      "screen_name" : "campbellhowes",
      "indices" : [ 0, 14 ],
      "id_str" : "16646523",
      "id" : 16646523
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/596754218867908608\/photo\/1",
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/ESANckhVOn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEgYzIgWgAAuVkp.png",
      "id_str" : "596754217362161664",
      "id" : 596754217362161664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEgYzIgWgAAuVkp.png",
      "sizes" : [ {
        "h" : 174,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 384,
        "resize" : "fit",
        "w" : 752
      }, {
        "h" : 384,
        "resize" : "fit",
        "w" : 752
      }, {
        "h" : 306,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/ESANckhVOn"
    } ],
    "hashtags" : [ {
      "text" : "ielt15",
      "indices" : [ 64, 71 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "596745714958471169",
  "geo" : { },
  "id_str" : "596754218867908608",
  "in_reply_to_user_id" : 16646523,
  "text" : "@campbellhowes ignore the edtech haters, listen to these playas #ielt15 ;) http:\/\/t.co\/ESANckhVOn",
  "id" : 596754218867908608,
  "in_reply_to_status_id" : 596745714958471169,
  "created_at" : "2015-05-08 19:11:07 +0000",
  "in_reply_to_screen_name" : "campbellhowes",
  "in_reply_to_user_id_str" : "16646523",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bruno Andrade",
      "screen_name" : "BrunoELT",
      "indices" : [ 3, 12 ],
      "id_str" : "39409915",
      "id" : 39409915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/msEjg3hhI0",
      "expanded_url" : "http:\/\/bit.ly\/1cwcFpf",
      "display_url" : "bit.ly\/1cwcFpf"
    } ]
  },
  "geo" : { },
  "id_str" : "596748920102985728",
  "text" : "RT @BrunoELT: The Golden Lasso of Education Technology: This talk was delivered today at Davidson College at its Annual Teac... http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/msEjg3hhI0",
        "expanded_url" : "http:\/\/bit.ly\/1cwcFpf",
        "display_url" : "bit.ly\/1cwcFpf"
      } ]
    },
    "geo" : { },
    "id_str" : "596746764431990784",
    "text" : "The Golden Lasso of Education Technology: This talk was delivered today at Davidson College at its Annual Teac... http:\/\/t.co\/msEjg3hhI0",
    "id" : 596746764431990784,
    "created_at" : "2015-05-08 18:41:30 +0000",
    "user" : {
      "name" : "Bruno Andrade",
      "screen_name" : "BrunoELT",
      "protected" : false,
      "id_str" : "39409915",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1780205071\/image_normal.jpg",
      "id" : 39409915,
      "verified" : false
    }
  },
  "id" : 596748920102985728,
  "created_at" : "2015-05-08 18:50:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Sample",
      "screen_name" : "samplereality",
      "indices" : [ 3, 17 ],
      "id_str" : "8497292",
      "id" : 8497292
    }, {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 139, 140 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596744636225429505",
  "text" : "RT @samplereality: The \"golden lasso\" of education technology has bound our imaginations, constrained our vision about pedagogy and learnin\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.metrotwit.com\/\" rel=\"nofollow\"\u003EMetroTwit\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Audrey Watters",
        "screen_name" : "audreywatters",
        "indices" : [ 125, 139 ],
        "id_str" : "25388528",
        "id" : 25388528
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "596716412816719873",
    "text" : "The \"golden lasso\" of education technology has bound our imaginations, constrained our vision about pedagogy and learning. - @audreywatters",
    "id" : 596716412816719873,
    "created_at" : "2015-05-08 16:40:53 +0000",
    "user" : {
      "name" : "Mark Sample",
      "screen_name" : "samplereality",
      "protected" : false,
      "id_str" : "8497292",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000707852410\/a86167716ecb748acc89638ad165a162_normal.jpeg",
      "id" : 8497292,
      "verified" : false
    }
  },
  "id" : 596744636225429505,
  "created_at" : "2015-05-08 18:33:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    }, {
      "name" : "Sam Harris",
      "screen_name" : "SamHarrisOrg",
      "indices" : [ 41, 54 ],
      "id_str" : "116994659",
      "id" : 116994659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/ezR5O2XmSy",
      "expanded_url" : "http:\/\/www.salon.com\/2015\/05\/07\/scoring_the_noam_chomskysam_harris_debate_how_the_professor_knocked_out_the_atheist\/",
      "display_url" : "salon.com\/2015\/05\/07\/sco\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "596689987069960192",
  "text" : "RT @medialens: By engaging Noam Chomsky, @SamHarrisOrg only managed to reveal just how out of his league he is on crucial matters. http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sam Harris",
        "screen_name" : "SamHarrisOrg",
        "indices" : [ 26, 39 ],
        "id_str" : "116994659",
        "id" : 116994659
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/ezR5O2XmSy",
        "expanded_url" : "http:\/\/www.salon.com\/2015\/05\/07\/scoring_the_noam_chomskysam_harris_debate_how_the_professor_knocked_out_the_atheist\/",
        "display_url" : "salon.com\/2015\/05\/07\/sco\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "596685276589780992",
    "text" : "By engaging Noam Chomsky, @SamHarrisOrg only managed to reveal just how out of his league he is on crucial matters. http:\/\/t.co\/ezR5O2XmSy",
    "id" : 596685276589780992,
    "created_at" : "2015-05-08 14:37:10 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 596689987069960192,
  "created_at" : "2015-05-08 14:55:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Jackson",
      "screen_name" : "patjack67",
      "indices" : [ 0, 10 ],
      "id_str" : "19790204",
      "id" : 19790204
    }, {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 11, 24 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "596630857470861312",
  "geo" : { },
  "id_str" : "596632150318919680",
  "in_reply_to_user_id" : 19790204,
  "text" : "@patjack67 @rosemerebard i guess it is the money behind CBs and the lobbying for the education pie in many countries?",
  "id" : 596632150318919680,
  "in_reply_to_status_id" : 596630857470861312,
  "created_at" : "2015-05-08 11:06:04 +0000",
  "in_reply_to_screen_name" : "patjack67",
  "in_reply_to_user_id_str" : "19790204",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/596629959826907136\/photo\/1",
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/L05DFPa1u8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEenyV9WgAAz-Lb.png",
      "id_str" : "596629958979649536",
      "id" : 596629958979649536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEenyV9WgAAz-Lb.png",
      "sizes" : [ {
        "h" : 102,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 192,
        "resize" : "fit",
        "w" : 637
      }, {
        "h" : 181,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 192,
        "resize" : "fit",
        "w" : 637
      } ],
      "display_url" : "pic.twitter.com\/L05DFPa1u8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596629959826907136",
  "text" : "this is a depressing graph for Wales http:\/\/t.co\/L05DFPa1u8",
  "id" : 596629959826907136,
  "created_at" : "2015-05-08 10:57:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 123, 135 ],
      "id_str" : "223771625",
      "id" : 223771625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/lt3gxU9o2K",
      "expanded_url" : "http:\/\/johnhilley.blogspot.co.uk\/2015\/05\/scottish-labour-routed-bittersweet.html",
      "display_url" : "johnhilley.blogspot.co.uk\/2015\/05\/scotti\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "596624021883609088",
  "text" : "\"Miliband lifeboat was really just another pirate neoliberal ship...Take heart from its sinking\" http:\/\/t.co\/lt3gxU9o2K by @johnwhilley",
  "id" : 596624021883609088,
  "created_at" : "2015-05-08 10:33:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 62, 78 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/1Gd1GYzmgT",
      "expanded_url" : "http:\/\/wp.me\/p2CPYN-jN",
      "display_url" : "wp.me\/p2CPYN-jN"
    } ]
  },
  "geo" : { },
  "id_str" : "596619924337991680",
  "text" : "The horrific normalisation of war. http:\/\/t.co\/1Gd1GYzmgT via @wordpressdotcom",
  "id" : 596619924337991680,
  "created_at" : "2015-05-08 10:17:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Brown",
      "screen_name" : "sbrowntweets",
      "indices" : [ 0, 13 ],
      "id_str" : "885343459",
      "id" : 885343459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/EfPZHaL5Se",
      "expanded_url" : "https:\/\/weegingerdug.wordpress.com\/2015\/05\/07\/the-schadenfreude-live-blog\/",
      "display_url" : "weegingerdug.wordpress.com\/2015\/05\/07\/the\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "596556483967483906",
  "geo" : { },
  "id_str" : "596558449527382017",
  "in_reply_to_user_id" : 885343459,
  "text" : "@sbrowntweets some comfort reading https:\/\/t.co\/EfPZHaL5Se",
  "id" : 596558449527382017,
  "in_reply_to_status_id" : 596556483967483906,
  "created_at" : "2015-05-08 06:13:12 +0000",
  "in_reply_to_screen_name" : "sbrowntweets",
  "in_reply_to_user_id_str" : "885343459",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Brown",
      "screen_name" : "sbrowntweets",
      "indices" : [ 0, 13 ],
      "id_str" : "885343459",
      "id" : 885343459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "596555545630351360",
  "geo" : { },
  "id_str" : "596555859238506496",
  "in_reply_to_user_id" : 885343459,
  "text" : "@sbrowntweets what's the process for Scottish citizenship? :\/",
  "id" : 596555859238506496,
  "in_reply_to_status_id" : 596555545630351360,
  "created_at" : "2015-05-08 06:02:54 +0000",
  "in_reply_to_screen_name" : "sbrowntweets",
  "in_reply_to_user_id_str" : "885343459",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jo Sayers",
      "screen_name" : "jo_sayers",
      "indices" : [ 0, 10 ],
      "id_str" : "87176766",
      "id" : 87176766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "596550915387162624",
  "geo" : { },
  "id_str" : "596552528319361024",
  "in_reply_to_user_id" : 87176766,
  "text" : "@jo_sayers hope u have a  good one despite shitty results :\/",
  "id" : 596552528319361024,
  "in_reply_to_status_id" : 596550915387162624,
  "created_at" : "2015-05-08 05:49:40 +0000",
  "in_reply_to_screen_name" : "jo_sayers",
  "in_reply_to_user_id_str" : "87176766",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/596445938761236482\/photo\/1",
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/h7bfviGtAU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEcAa55WAAAOrKd.png",
      "id_str" : "596445937867816960",
      "id" : 596445937867816960,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEcAa55WAAAOrKd.png",
      "sizes" : [ {
        "h" : 174,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 384,
        "resize" : "fit",
        "w" : 752
      }, {
        "h" : 384,
        "resize" : "fit",
        "w" : 752
      }, {
        "h" : 306,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/h7bfviGtAU"
    } ],
    "hashtags" : [ {
      "text" : "SiliconValley",
      "indices" : [ 25, 39 ]
    }, {
      "text" : "roisic",
      "indices" : [ 71, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596445938761236482",
  "text" : "just been catching up on #SiliconValley &amp; this presented itself :) #roisic http:\/\/t.co\/h7bfviGtAU",
  "id" : 596445938761236482,
  "created_at" : "2015-05-07 22:46:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Lab",
      "screen_name" : "LexicalLab",
      "indices" : [ 0, 11 ],
      "id_str" : "857732892",
      "id" : 857732892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "596405793613815808",
  "geo" : { },
  "id_str" : "596418254542868480",
  "in_reply_to_user_id" : 857732892,
  "text" : "@LexicalLab glad u liked it :)",
  "id" : 596418254542868480,
  "in_reply_to_status_id" : 596405793613815808,
  "created_at" : "2015-05-07 20:56:07 +0000",
  "in_reply_to_screen_name" : "LexicalLab",
  "in_reply_to_user_id_str" : "857732892",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/rDhu1LADbD",
      "expanded_url" : "http:\/\/www.eurotrib.com\/story\/2015\/5\/1\/21233\/93821",
      "display_url" : "eurotrib.com\/story\/2015\/5\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "596397885173923840",
  "text" : "Footing the bill in Libya\n\nhttp:\/\/t.co\/rDhu1LADbD",
  "id" : 596397885173923840,
  "created_at" : "2015-05-07 19:35:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyler Schnoebelen",
      "screen_name" : "TSchnoebelen",
      "indices" : [ 3, 16 ],
      "id_str" : "14969147",
      "id" : 14969147
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/UI29nXxMv5",
      "expanded_url" : "http:\/\/ow.ly\/MCL6X",
      "display_url" : "ow.ly\/MCL6X"
    } ]
  },
  "geo" : { },
  "id_str" : "596395700298055680",
  "text" : "RT @TSchnoebelen: \"Ask me what nine times F is. It\u2019s fleventy-five.\" http:\/\/t.co\/UI29nXxMv5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 73 ],
        "url" : "http:\/\/t.co\/UI29nXxMv5",
        "expanded_url" : "http:\/\/ow.ly\/MCL6X",
        "display_url" : "ow.ly\/MCL6X"
      } ]
    },
    "geo" : { },
    "id_str" : "596347710149648384",
    "text" : "\"Ask me what nine times F is. It\u2019s fleventy-five.\" http:\/\/t.co\/UI29nXxMv5",
    "id" : 596347710149648384,
    "created_at" : "2015-05-07 16:15:48 +0000",
    "user" : {
      "name" : "Tyler Schnoebelen",
      "screen_name" : "TSchnoebelen",
      "protected" : false,
      "id_str" : "14969147",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/604427674203779072\/Y4t_NODB_normal.jpg",
      "id" : 14969147,
      "verified" : false
    }
  },
  "id" : 596395700298055680,
  "created_at" : "2015-05-07 19:26:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darius Kazemi",
      "screen_name" : "tinysubversions",
      "indices" : [ 3, 19 ],
      "id_str" : "14475298",
      "id" : 14475298
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "APIdaysBCN",
      "indices" : [ 128, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/PsG47knEJA",
      "expanded_url" : "http:\/\/nlp.lsi.upc.edu\/freeling\/demo\/demo.php",
      "display_url" : "nlp.lsi.upc.edu\/freeling\/demo\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "596322274254430208",
  "text" : "RT @tinysubversions: Learning about the FreeLing language analyzer -- there's a pretty cool demo online: http:\/\/t.co\/PsG47knEJA #APIdaysBCN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "APIdaysBCN",
        "indices" : [ 107, 118 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/PsG47knEJA",
        "expanded_url" : "http:\/\/nlp.lsi.upc.edu\/freeling\/demo\/demo.php",
        "display_url" : "nlp.lsi.upc.edu\/freeling\/demo\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "596274120058400768",
    "text" : "Learning about the FreeLing language analyzer -- there's a pretty cool demo online: http:\/\/t.co\/PsG47knEJA #APIdaysBCN",
    "id" : 596274120058400768,
    "created_at" : "2015-05-07 11:23:23 +0000",
    "user" : {
      "name" : "Darius Kazemi",
      "screen_name" : "tinysubversions",
      "protected" : false,
      "id_str" : "14475298",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723889712772059136\/4T8a46Sp_normal.jpg",
      "id" : 14475298,
      "verified" : false
    }
  },
  "id" : 596322274254430208,
  "created_at" : "2015-05-07 14:34:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpus",
      "indices" : [ 9, 16 ]
    } ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/Z976BFniPd",
      "expanded_url" : "https:\/\/github.com\/alvations\/Quotables",
      "display_url" : "github.com\/alvations\/Quot\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "596314591178657792",
  "text" : "a quotes #corpus https:\/\/t.co\/Z976BFniPd h\/t corporalist",
  "id" : 596314591178657792,
  "created_at" : "2015-05-07 14:04:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/596312291907411968\/photo\/1",
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/GqqxEusQZC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEaG3oUWEAA0rHx.png",
      "id_str" : "596312290946846720",
      "id" : 596312290946846720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEaG3oUWEAA0rHx.png",
      "sizes" : [ {
        "h" : 916,
        "resize" : "fit",
        "w" : 1600
      }, {
        "h" : 195,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 344,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 586,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/GqqxEusQZC"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/taLpAwPg7k",
      "expanded_url" : "https:\/\/www.facebook.com\/ads\/audience_insights",
      "display_url" : "facebook.com\/ads\/audience_i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "596312291907411968",
  "text" : "some interesting stats from FB https:\/\/t.co\/taLpAwPg7k gender for IATEFL\/TESOL; likes for TEFL http:\/\/t.co\/GqqxEusQZC",
  "id" : 596312291907411968,
  "created_at" : "2015-05-07 13:55:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "P\u00E9rez-Paredes",
      "screen_name" : "perezparedes",
      "indices" : [ 0, 13 ],
      "id_str" : "28528850",
      "id" : 28528850
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "596255245954654208",
  "geo" : { },
  "id_str" : "596272573043859456",
  "in_reply_to_user_id" : 28528850,
  "text" : "@perezparedes the formulation of issue by article shed no light imo",
  "id" : 596272573043859456,
  "in_reply_to_status_id" : 596255245954654208,
  "created_at" : "2015-05-07 11:17:14 +0000",
  "in_reply_to_screen_name" : "perezparedes",
  "in_reply_to_user_id_str" : "28528850",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vedrana Vojkovi\u0107",
      "screen_name" : "Ven_VVE",
      "indices" : [ 0, 8 ],
      "id_str" : "270839603",
      "id" : 270839603
    }, {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 9, 25 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "596237585648898048",
  "geo" : { },
  "id_str" : "596239303170220032",
  "in_reply_to_user_id" : 270839603,
  "text" : "@Ven_VVE @michaelegriffin not sure about modelling but experience in giving certainly helpful",
  "id" : 596239303170220032,
  "in_reply_to_status_id" : 596237585648898048,
  "created_at" : "2015-05-07 09:05:02 +0000",
  "in_reply_to_screen_name" : "Ven_VVE",
  "in_reply_to_user_id_str" : "270839603",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "P\u00E9rez-Paredes",
      "screen_name" : "perezparedes",
      "indices" : [ 0, 13 ],
      "id_str" : "28528850",
      "id" : 28528850
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "596229334857293826",
  "geo" : { },
  "id_str" : "596238922218401792",
  "in_reply_to_user_id" : 28528850,
  "text" : "@perezparedes ugh awful article, awful cliches :\/",
  "id" : 596238922218401792,
  "in_reply_to_status_id" : 596229334857293826,
  "created_at" : "2015-05-07 09:03:31 +0000",
  "in_reply_to_screen_name" : "perezparedes",
  "in_reply_to_user_id_str" : "28528850",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Bogost",
      "screen_name" : "ibogost",
      "indices" : [ 3, 11 ],
      "id_str" : "6825792",
      "id" : 6825792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596209650216861696",
  "text" : "RT @ibogost: Summary of the Internet:\n\n\"Hey! Look at me!\"\n\"No! Look at me!\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "596088828361723904",
    "text" : "Summary of the Internet:\n\n\"Hey! Look at me!\"\n\"No! Look at me!\"",
    "id" : 596088828361723904,
    "created_at" : "2015-05-06 23:07:06 +0000",
    "user" : {
      "name" : "Ian Bogost",
      "screen_name" : "ibogost",
      "protected" : false,
      "id_str" : "6825792",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/677930477752193025\/DUdmOVVK_normal.jpg",
      "id" : 6825792,
      "verified" : true
    }
  },
  "id" : 596209650216861696,
  "created_at" : "2015-05-07 07:07:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 3, 17 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/audreywatters\/status\/596138942660878337\/photo\/1",
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/IHGD5T1kKE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEXpNbNVAAAMXBv.jpg",
      "id_str" : "596138942547689472",
      "id" : 596138942547689472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEXpNbNVAAAMXBv.jpg",
      "sizes" : [ {
        "h" : 391,
        "resize" : "fit",
        "w" : 490
      }, {
        "h" : 271,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 391,
        "resize" : "fit",
        "w" : 490
      }, {
        "h" : 391,
        "resize" : "fit",
        "w" : 490
      } ],
      "display_url" : "pic.twitter.com\/IHGD5T1kKE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596207612619808768",
  "text" : "RT @audreywatters: WTF is this?! http:\/\/t.co\/IHGD5T1kKE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/audreywatters\/status\/596138942660878337\/photo\/1",
        "indices" : [ 14, 36 ],
        "url" : "http:\/\/t.co\/IHGD5T1kKE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CEXpNbNVAAAMXBv.jpg",
        "id_str" : "596138942547689472",
        "id" : 596138942547689472,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEXpNbNVAAAMXBv.jpg",
        "sizes" : [ {
          "h" : 391,
          "resize" : "fit",
          "w" : 490
        }, {
          "h" : 271,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 391,
          "resize" : "fit",
          "w" : 490
        }, {
          "h" : 391,
          "resize" : "fit",
          "w" : 490
        } ],
        "display_url" : "pic.twitter.com\/IHGD5T1kKE"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "596138942660878337",
    "text" : "WTF is this?! http:\/\/t.co\/IHGD5T1kKE",
    "id" : 596138942660878337,
    "created_at" : "2015-05-07 02:26:14 +0000",
    "user" : {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "protected" : false,
      "id_str" : "25388528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711668009723498496\/pauFZsdv_normal.jpg",
      "id" : 25388528,
      "verified" : false
    }
  },
  "id" : 596207612619808768,
  "created_at" : "2015-05-07 06:59:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "killingtime",
      "indices" : [ 51, 63 ]
    }, {
      "text" : "waitingforstudent",
      "indices" : [ 64, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/JAaC4EnjOj",
      "expanded_url" : "https:\/\/elt.makes.org\/popcorn\/30yv",
      "display_url" : "elt.makes.org\/popcorn\/30yv"
    } ]
  },
  "geo" : { },
  "id_str" : "596203263978004480",
  "text" : "Now with added Marvin Gaye https:\/\/t.co\/JAaC4EnjOj #killingtime #waitingforstudent",
  "id" : 596203263978004480,
  "created_at" : "2015-05-07 06:41:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 0, 10 ],
      "id_str" : "525274103",
      "id" : 525274103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/JAaC4EnjOj",
      "expanded_url" : "https:\/\/elt.makes.org\/popcorn\/30yv",
      "display_url" : "elt.makes.org\/popcorn\/30yv"
    } ]
  },
  "geo" : { },
  "id_str" : "596060764928086016",
  "in_reply_to_user_id" : 525274103,
  "text" : "@ElkySmith hi don't know if you've seen Oxford ebook demo lesson? here is my reaction to it https:\/\/t.co\/JAaC4EnjOj :)",
  "id" : 596060764928086016,
  "created_at" : "2015-05-06 21:15:35 +0000",
  "in_reply_to_screen_name" : "ElkySmith",
  "in_reply_to_user_id_str" : "525274103",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Political Reactions",
      "screen_name" : "PoliticalReacts",
      "indices" : [ 3, 19 ],
      "id_str" : "834085088",
      "id" : 834085088
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/PoliticalReactz\/status\/595313389435510785\/video\/1",
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/w0eGV2SxRZ",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/595313084153102336\/pu\/img\/wW7HzXmNnHX4NPWp.jpg",
      "id_str" : "595313084153102336",
      "id" : 595313084153102336,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/595313084153102336\/pu\/img\/wW7HzXmNnHX4NPWp.jpg",
      "sizes" : [ {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/w0eGV2SxRZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596059939807883264",
  "text" : "RT @PoliticalReacts: This is why we love the Internet http:\/\/t.co\/w0eGV2SxRZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/PoliticalReactz\/status\/595313389435510785\/video\/1",
        "indices" : [ 33, 55 ],
        "url" : "http:\/\/t.co\/w0eGV2SxRZ",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/595313084153102336\/pu\/img\/wW7HzXmNnHX4NPWp.jpg",
        "id_str" : "595313084153102336",
        "id" : 595313084153102336,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/595313084153102336\/pu\/img\/wW7HzXmNnHX4NPWp.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/w0eGV2SxRZ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "595322631928324096",
    "text" : "This is why we love the Internet http:\/\/t.co\/w0eGV2SxRZ",
    "id" : 595322631928324096,
    "created_at" : "2015-05-04 20:22:30 +0000",
    "user" : {
      "name" : "Political Reactions",
      "screen_name" : "PoliticalReacts",
      "protected" : false,
      "id_str" : "834085088",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/584068392602185728\/19BYcg3A_normal.png",
      "id" : 834085088,
      "verified" : false
    }
  },
  "id" : 596059939807883264,
  "created_at" : "2015-05-06 21:12:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/V7JBNUZSkp",
      "expanded_url" : "http:\/\/www.thenation.com\/blog\/206121\/game-done-changed-reconsidering-wire-amidst-baltimore-uprising",
      "display_url" : "thenation.com\/blog\/206121\/ga\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "596042691059785730",
  "text" : "\u2018The Game Done Changed\u2019: Reconsidering \u2018The Wire\u2019 Amidst the Baltimore Uprising | The Nation http:\/\/t.co\/V7JBNUZSkp",
  "id" : 596042691059785730,
  "created_at" : "2015-05-06 20:03:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenys Hanson",
      "screen_name" : "GlenysHanson",
      "indices" : [ 0, 13 ],
      "id_str" : "527238447",
      "id" : 527238447
    }, {
      "name" : "Laura Adele Soracco",
      "screen_name" : "LauraSoracco",
      "indices" : [ 14, 27 ],
      "id_str" : "15663328",
      "id" : 15663328
    }, {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 28, 34 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "596006397634052097",
  "geo" : { },
  "id_str" : "596014602615431169",
  "in_reply_to_user_id" : 527238447,
  "text" : "@GlenysHanson @LauraSoracco @ebefl that's a different question for sure",
  "id" : 596014602615431169,
  "in_reply_to_status_id" : 596006397634052097,
  "created_at" : "2015-05-06 18:12:09 +0000",
  "in_reply_to_screen_name" : "GlenysHanson",
  "in_reply_to_user_id_str" : "527238447",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donald Clark",
      "screen_name" : "DonaldClark",
      "indices" : [ 0, 12 ],
      "id_str" : "1632891",
      "id" : 1632891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "595993506562342912",
  "geo" : { },
  "id_str" : "595997199571517440",
  "in_reply_to_user_id" : 1632891,
  "text" : "@DonaldClark bonkers in your opinion, doc shows reforms separate from negotiation with \"donors\"",
  "id" : 595997199571517440,
  "in_reply_to_status_id" : 595993506562342912,
  "created_at" : "2015-05-06 17:03:00 +0000",
  "in_reply_to_screen_name" : "DonaldClark",
  "in_reply_to_user_id_str" : "1632891",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donald Clark",
      "screen_name" : "DonaldClark",
      "indices" : [ 0, 12 ],
      "id_str" : "1632891",
      "id" : 1632891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/NBSEP1exdV",
      "expanded_url" : "http:\/\/im.ft-static.com\/content\/images\/55b27a7e-d87c-11e4-ba53-00144feab7de.pdf",
      "display_url" : "im.ft-static.com\/content\/images\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "595989260962004992",
  "geo" : { },
  "id_str" : "595992618326188033",
  "in_reply_to_user_id" : 1632891,
  "text" : "@DonaldClark if it's a mistake at least it will be their mistake http:\/\/t.co\/NBSEP1exdV",
  "id" : 595992618326188033,
  "in_reply_to_status_id" : 595989260962004992,
  "created_at" : "2015-05-06 16:44:47 +0000",
  "in_reply_to_screen_name" : "DonaldClark",
  "in_reply_to_user_id_str" : "1632891",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donald Clark",
      "screen_name" : "DonaldClark",
      "indices" : [ 0, 12 ],
      "id_str" : "1632891",
      "id" : 1632891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "595981303792738304",
  "geo" : { },
  "id_str" : "595988180819693568",
  "in_reply_to_user_id" : 1632891,
  "text" : "@DonaldClark no doubt they see that differently",
  "id" : 595988180819693568,
  "in_reply_to_status_id" : 595981303792738304,
  "created_at" : "2015-05-06 16:27:09 +0000",
  "in_reply_to_screen_name" : "DonaldClark",
  "in_reply_to_user_id_str" : "1632891",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donald Clark",
      "screen_name" : "DonaldClark",
      "indices" : [ 0, 12 ],
      "id_str" : "1632891",
      "id" : 1632891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "595980275374522368",
  "geo" : { },
  "id_str" : "595980380500586496",
  "in_reply_to_user_id" : 1632891,
  "text" : "@DonaldClark that would be weird since they voted for it",
  "id" : 595980380500586496,
  "in_reply_to_status_id" : 595980275374522368,
  "created_at" : "2015-05-06 15:56:10 +0000",
  "in_reply_to_screen_name" : "DonaldClark",
  "in_reply_to_user_id_str" : "1632891",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donald Clark",
      "screen_name" : "DonaldClark",
      "indices" : [ 0, 12 ],
      "id_str" : "1632891",
      "id" : 1632891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "595968517096218624",
  "geo" : { },
  "id_str" : "595979960797503488",
  "in_reply_to_user_id" : 1632891,
  "text" : "@DonaldClark bonkers for who?",
  "id" : 595979960797503488,
  "in_reply_to_status_id" : 595968517096218624,
  "created_at" : "2015-05-06 15:54:30 +0000",
  "in_reply_to_screen_name" : "DonaldClark",
  "in_reply_to_user_id_str" : "1632891",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TEFL Commute",
      "screen_name" : "TEFLCommute",
      "indices" : [ 3, 15 ],
      "id_str" : "3092999387",
      "id" : 3092999387
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/TEFLCommute\/status\/595956437131624448\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/4g2TZNVmwC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEVDG1GWYAAWQ8-.png",
      "id_str" : "595956310308446208",
      "id" : 595956310308446208,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEVDG1GWYAAWQ8-.png",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1772,
        "resize" : "fit",
        "w" : 1772
      } ],
      "display_url" : "pic.twitter.com\/4g2TZNVmwC"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/9oBMatXRQ0",
      "expanded_url" : "http:\/\/www.teflcommute.com\/episode-2\/",
      "display_url" : "teflcommute.com\/episode-2\/"
    } ]
  },
  "geo" : { },
  "id_str" : "595960801523011584",
  "text" : "RT @TEFLCommute: Episode 2 of the TEFL Commute\u200B podcast is now available! In this episode we discuss stationery http:\/\/t.co\/9oBMatXRQ0 http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/TEFLCommute\/status\/595956437131624448\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/4g2TZNVmwC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CEVDG1GWYAAWQ8-.png",
        "id_str" : "595956310308446208",
        "id" : 595956310308446208,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEVDG1GWYAAWQ8-.png",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1772,
          "resize" : "fit",
          "w" : 1772
        } ],
        "display_url" : "pic.twitter.com\/4g2TZNVmwC"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/9oBMatXRQ0",
        "expanded_url" : "http:\/\/www.teflcommute.com\/episode-2\/",
        "display_url" : "teflcommute.com\/episode-2\/"
      } ]
    },
    "geo" : { },
    "id_str" : "595956437131624448",
    "text" : "Episode 2 of the TEFL Commute\u200B podcast is now available! In this episode we discuss stationery http:\/\/t.co\/9oBMatXRQ0 http:\/\/t.co\/4g2TZNVmwC",
    "id" : 595956437131624448,
    "created_at" : "2015-05-06 14:21:01 +0000",
    "user" : {
      "name" : "TEFL Commute",
      "screen_name" : "TEFLCommute",
      "protected" : false,
      "id_str" : "3092999387",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/577896034958884864\/j69L0FlU_normal.png",
      "id" : 3092999387,
      "verified" : false
    }
  },
  "id" : 595960801523011584,
  "created_at" : "2015-05-06 14:38:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 89, 100 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 101, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/EAzUIh4j7o",
      "expanded_url" : "http:\/\/yohasebe.com\/tcse\/",
      "display_url" : "yohasebe.com\/tcse\/"
    } ]
  },
  "geo" : { },
  "id_str" : "595960628294057985",
  "text" : "Ted Corpus Search Engine now has transcript synced to video, nice http:\/\/t.co\/EAzUIh4j7o #corpusmooc #eltchat",
  "id" : 595960628294057985,
  "created_at" : "2015-05-06 14:37:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Harbinson",
      "screen_name" : "DavidHarbinson",
      "indices" : [ 0, 15 ],
      "id_str" : "853078675",
      "id" : 853078675
    }, {
      "name" : "Kurzgesagt",
      "screen_name" : "Kurz_Gesagt",
      "indices" : [ 16, 28 ],
      "id_str" : "1603439773",
      "id" : 1603439773
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "595944467422576640",
  "geo" : { },
  "id_str" : "595952712526778368",
  "in_reply_to_user_id" : 853078675,
  "text" : "@DavidHarbinson @Kurz_Gesagt am partial to Pinker's ladder of evolution fallacy to explain this",
  "id" : 595952712526778368,
  "in_reply_to_status_id" : 595944467422576640,
  "created_at" : "2015-05-06 14:06:13 +0000",
  "in_reply_to_screen_name" : "DavidHarbinson",
  "in_reply_to_user_id_str" : "853078675",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 39, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/JAaC4EnjOj",
      "expanded_url" : "https:\/\/elt.makes.org\/popcorn\/30yv",
      "display_url" : "elt.makes.org\/popcorn\/30yv"
    } ]
  },
  "geo" : { },
  "id_str" : "595940583023222784",
  "text" : "ebook-tapeworm https:\/\/t.co\/JAaC4EnjOj #eltchat",
  "id" : 595940583023222784,
  "created_at" : "2015-05-06 13:18:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 0, 15 ],
      "id_str" : "285614027",
      "id" : 285614027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "595897718838460417",
  "geo" : { },
  "id_str" : "595916267611103233",
  "in_reply_to_user_id" : 285614027,
  "text" : "@AnthonyTeacher i guess yes more cog based. weak version would say not fundamental different.",
  "id" : 595916267611103233,
  "in_reply_to_status_id" : 595897718838460417,
  "created_at" : "2015-05-06 11:41:24 +0000",
  "in_reply_to_screen_name" : "AnthonyTeacher",
  "in_reply_to_user_id_str" : "285614027",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Garrett Munro",
      "screen_name" : "EdgeTech_ESL",
      "indices" : [ 0, 13 ],
      "id_str" : "2393613607",
      "id" : 2393613607
    }, {
      "name" : "TEFLninja",
      "screen_name" : "TEFLninja",
      "indices" : [ 14, 24 ],
      "id_str" : "3131267981",
      "id" : 3131267981
    }, {
      "name" : "PearsonELT",
      "screen_name" : "Pearson_ELT",
      "indices" : [ 25, 37 ],
      "id_str" : "63127949",
      "id" : 63127949
    }, {
      "name" : "Blunt Educator",
      "screen_name" : "BluntEducator",
      "indices" : [ 38, 52 ],
      "id_str" : "2160694559",
      "id" : 2160694559
    }, {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 122, 132 ],
      "id_str" : "525274103",
      "id" : 525274103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/VPXHjgNNli",
      "expanded_url" : "https:\/\/elkysmith.typeform.com\/to\/sGKyvb",
      "display_url" : "elkysmith.typeform.com\/to\/sGKyvb"
    } ]
  },
  "in_reply_to_status_id_str" : "595784755985129473",
  "geo" : { },
  "id_str" : "595883305385492481",
  "in_reply_to_user_id" : 2393613607,
  "text" : "@EdgeTech_ESL @TEFLninja @Pearson_ELT @BluntEducator u guys might be interested in this survey https:\/\/t.co\/VPXHjgNNli by @ElkySmith",
  "id" : 595883305385492481,
  "in_reply_to_status_id" : 595784755985129473,
  "created_at" : "2015-05-06 09:30:25 +0000",
  "in_reply_to_screen_name" : "EdgeTech_ESL",
  "in_reply_to_user_id_str" : "2393613607",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Achilleas Kostoulas",
      "screen_name" : "AchilleasK",
      "indices" : [ 3, 14 ],
      "id_str" : "134191406",
      "id" : 134191406
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/wkXBa7KdWQ",
      "expanded_url" : "http:\/\/wp.me\/p2aFDK-Xk",
      "display_url" : "wp.me\/p2aFDK-Xk"
    } ]
  },
  "geo" : { },
  "id_str" : "595873303501373440",
  "text" : "RT @AchilleasK: Using YouTube to communicate research http:\/\/t.co\/wkXBa7KdWQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 60 ],
        "url" : "http:\/\/t.co\/wkXBa7KdWQ",
        "expanded_url" : "http:\/\/wp.me\/p2aFDK-Xk",
        "display_url" : "wp.me\/p2aFDK-Xk"
      } ]
    },
    "geo" : { },
    "id_str" : "595871286015832064",
    "text" : "Using YouTube to communicate research http:\/\/t.co\/wkXBa7KdWQ",
    "id" : 595871286015832064,
    "created_at" : "2015-05-06 08:42:39 +0000",
    "user" : {
      "name" : "Achilleas Kostoulas",
      "screen_name" : "AchilleasK",
      "protected" : false,
      "id_str" : "134191406",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765621437826797569\/1o7CwbeK_normal.jpg",
      "id" : 134191406,
      "verified" : false
    }
  },
  "id" : 595873303501373440,
  "created_at" : "2015-05-06 08:50:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Lab",
      "screen_name" : "LexicalLab",
      "indices" : [ 0, 11 ],
      "id_str" : "857732892",
      "id" : 857732892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/ZDUoh2aPG6",
      "expanded_url" : "http:\/\/speechevents.wordpress.com\/2015\/05\/06\/define-and-conquer\/",
      "display_url" : "speechevents.wordpress.com\/2015\/05\/06\/def\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "595865938764894209",
  "geo" : { },
  "id_str" : "595869108580839424",
  "in_reply_to_user_id" : 857732892,
  "text" : "@LexicalLab that last line is an elephant in the room, i think you'll like this post - http:\/\/t.co\/ZDUoh2aPG6",
  "id" : 595869108580839424,
  "in_reply_to_status_id" : 595865938764894209,
  "created_at" : "2015-05-06 08:34:00 +0000",
  "in_reply_to_screen_name" : "LexicalLab",
  "in_reply_to_user_id_str" : "857732892",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 0, 10 ],
      "id_str" : "525274103",
      "id" : 525274103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "595863239449137152",
  "geo" : { },
  "id_str" : "595863744980393987",
  "in_reply_to_user_id" : 525274103,
  "text" : "@ElkySmith lol i think we don't yet need to fear our algorithmic overlords in this case",
  "id" : 595863744980393987,
  "in_reply_to_status_id" : 595863239449137152,
  "created_at" : "2015-05-06 08:12:42 +0000",
  "in_reply_to_screen_name" : "ElkySmith",
  "in_reply_to_user_id_str" : "525274103",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/yT1JR6tgI1",
      "expanded_url" : "http:\/\/multimedia.telesurtv.net\/v\/the-world-today-383071\/#.VUnMaKU3LcE.twitter",
      "display_url" : "multimedia.telesurtv.net\/v\/the-world-to\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "595863161905008641",
  "text" : "Video: The World Today - WHY SHOULD WE VOTE? http:\/\/t.co\/yT1JR6tgI1",
  "id" : 595863161905008641,
  "created_at" : "2015-05-06 08:10:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tekhnologic",
      "screen_name" : "tekhnologicblog",
      "indices" : [ 3, 19 ],
      "id_str" : "1486688384",
      "id" : 1486688384
    }, {
      "name" : "tekhnologic",
      "screen_name" : "tekhnologicblog",
      "indices" : [ 32, 48 ],
      "id_str" : "1486688384",
      "id" : 1486688384
    }, {
      "name" : "TEFL Equity",
      "screen_name" : "TeflEquity",
      "indices" : [ 98, 109 ],
      "id_str" : "3217729433",
      "id" : 3217729433
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/tekhnologicblog\/status\/595804473680916481\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/Bf25Cz87as",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CES5AscWEAIJ5W5.png",
      "id_str" : "595804472300933122",
      "id" : 595804472300933122,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CES5AscWEAIJ5W5.png",
      "sizes" : [ {
        "h" : 473,
        "resize" : "fit",
        "w" : 769
      }, {
        "h" : 473,
        "resize" : "fit",
        "w" : 769
      }, {
        "h" : 369,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 209,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Bf25Cz87as"
    } ],
    "hashtags" : [ {
      "text" : "TEA",
      "indices" : [ 128, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595863056359522304",
  "text" : "RT @tekhnologicblog: Yesterday, @tekhnologicblog added this badge to the site to show support for @TeflEquity. Thank you Marek. #TEA http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "tekhnologic",
        "screen_name" : "tekhnologicblog",
        "indices" : [ 11, 27 ],
        "id_str" : "1486688384",
        "id" : 1486688384
      }, {
        "name" : "TEFL Equity",
        "screen_name" : "TeflEquity",
        "indices" : [ 77, 88 ],
        "id_str" : "3217729433",
        "id" : 3217729433
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/tekhnologicblog\/status\/595804473680916481\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/Bf25Cz87as",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CES5AscWEAIJ5W5.png",
        "id_str" : "595804472300933122",
        "id" : 595804472300933122,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CES5AscWEAIJ5W5.png",
        "sizes" : [ {
          "h" : 473,
          "resize" : "fit",
          "w" : 769
        }, {
          "h" : 473,
          "resize" : "fit",
          "w" : 769
        }, {
          "h" : 369,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 209,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Bf25Cz87as"
      } ],
      "hashtags" : [ {
        "text" : "TEA",
        "indices" : [ 107, 111 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "595804473680916481",
    "text" : "Yesterday, @tekhnologicblog added this badge to the site to show support for @TeflEquity. Thank you Marek. #TEA http:\/\/t.co\/Bf25Cz87as",
    "id" : 595804473680916481,
    "created_at" : "2015-05-06 04:17:10 +0000",
    "user" : {
      "name" : "tekhnologic",
      "screen_name" : "tekhnologicblog",
      "protected" : false,
      "id_str" : "1486688384",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/688646674336448513\/zoC_aneo_normal.png",
      "id" : 1486688384,
      "verified" : false
    }
  },
  "id" : 595863056359522304,
  "created_at" : "2015-05-06 08:09:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 0, 10 ],
      "id_str" : "525274103",
      "id" : 525274103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "595862616058257408",
  "geo" : { },
  "id_str" : "595862792051240960",
  "in_reply_to_user_id" : 18602422,
  "text" : "@ElkySmith ha cool Fela Kuti :)",
  "id" : 595862792051240960,
  "in_reply_to_status_id" : 595862616058257408,
  "created_at" : "2015-05-06 08:08:54 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 0, 10 ],
      "id_str" : "525274103",
      "id" : 525274103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "595861093366370304",
  "geo" : { },
  "id_str" : "595862616058257408",
  "in_reply_to_user_id" : 525274103,
  "text" : "@ElkySmith that typeface is pretty neat oops not it is not! ;)",
  "id" : 595862616058257408,
  "in_reply_to_status_id" : 595861093366370304,
  "created_at" : "2015-05-06 08:08:12 +0000",
  "in_reply_to_screen_name" : "ElkySmith",
  "in_reply_to_user_id_str" : "525274103",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 3, 13 ],
      "id_str" : "525274103",
      "id" : 525274103
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AusELT",
      "indices" : [ 137, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/aAvQM7eVYV",
      "expanded_url" : "https:\/\/elkysmith.typeform.com\/to\/sGKyvb",
      "display_url" : "elkysmith.typeform.com\/to\/sGKyvb"
    } ]
  },
  "geo" : { },
  "id_str" : "595860780182065152",
  "text" : "RT @ElkySmith: ...To this end, I would be very grateful if you could spend about 17 mins completing this survey: https:\/\/t.co\/aAvQM7eVYV #A\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AusELT",
        "indices" : [ 122, 129 ]
      } ],
      "urls" : [ {
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/aAvQM7eVYV",
        "expanded_url" : "https:\/\/elkysmith.typeform.com\/to\/sGKyvb",
        "display_url" : "elkysmith.typeform.com\/to\/sGKyvb"
      } ]
    },
    "geo" : { },
    "id_str" : "595859742582378496",
    "text" : "...To this end, I would be very grateful if you could spend about 17 mins completing this survey: https:\/\/t.co\/aAvQM7eVYV #AusELT",
    "id" : 595859742582378496,
    "created_at" : "2015-05-06 07:56:47 +0000",
    "user" : {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "protected" : false,
      "id_str" : "525274103",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/690658566370263041\/qggTYEb3_normal.jpg",
      "id" : 525274103,
      "verified" : false
    }
  },
  "id" : 595860780182065152,
  "created_at" : "2015-05-06 08:00:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin",
      "screen_name" : "EasyESLGames",
      "indices" : [ 3, 16 ],
      "id_str" : "3020756736",
      "id" : 3020756736
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/EasyESLGames\/status\/595851286467223552\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/2NutlT5BCK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CETjlk0WoAEc18d.jpg",
      "id_str" : "595851285397676033",
      "id" : 595851285397676033,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CETjlk0WoAEc18d.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 400
      } ],
      "display_url" : "pic.twitter.com\/2NutlT5BCK"
    } ],
    "hashtags" : [ {
      "text" : "ESL",
      "indices" : [ 38, 42 ]
    }, {
      "text" : "EFL",
      "indices" : [ 43, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/WTOfI8Ix7Z",
      "expanded_url" : "http:\/\/www.easyeslgames.com\/easyesl-games-adult-resource-0",
      "display_url" : "easyeslgames.com\/easyesl-games-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "595854796520841217",
  "text" : "RT @EasyESLGames: A TED talk for your #ESL #EFL class. Erin McKean invites people to start make up new words.\nhttp:\/\/t.co\/WTOfI8Ix7Z\u2026\/ http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/EasyESLGames\/status\/595851286467223552\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/2NutlT5BCK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CETjlk0WoAEc18d.jpg",
        "id_str" : "595851285397676033",
        "id" : 595851285397676033,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CETjlk0WoAEc18d.jpg",
        "sizes" : [ {
          "h" : 300,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 400
        } ],
        "display_url" : "pic.twitter.com\/2NutlT5BCK"
      } ],
      "hashtags" : [ {
        "text" : "ESL",
        "indices" : [ 20, 24 ]
      }, {
        "text" : "EFL",
        "indices" : [ 25, 29 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/WTOfI8Ix7Z",
        "expanded_url" : "http:\/\/www.easyeslgames.com\/easyesl-games-adult-resource-0",
        "display_url" : "easyeslgames.com\/easyesl-games-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "595851286467223552",
    "text" : "A TED talk for your #ESL #EFL class. Erin McKean invites people to start make up new words.\nhttp:\/\/t.co\/WTOfI8Ix7Z\u2026\/ http:\/\/t.co\/2NutlT5BCK",
    "id" : 595851286467223552,
    "created_at" : "2015-05-06 07:23:11 +0000",
    "user" : {
      "name" : "Kevin",
      "screen_name" : "EasyESLGames",
      "protected" : false,
      "id_str" : "3020756736",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/687403808746528770\/OyImodLD_normal.jpg",
      "id" : 3020756736,
      "verified" : false
    }
  },
  "id" : 595854796520841217,
  "created_at" : "2015-05-06 07:37:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemma Lunn",
      "screen_name" : "GemL1",
      "indices" : [ 0, 6 ],
      "id_str" : "486146568",
      "id" : 486146568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "595848207759990784",
  "geo" : { },
  "id_str" : "595851355320918017",
  "in_reply_to_user_id" : 486146568,
  "text" : "@GemL1 cheers Gemma :)",
  "id" : 595851355320918017,
  "in_reply_to_status_id" : 595848207759990784,
  "created_at" : "2015-05-06 07:23:28 +0000",
  "in_reply_to_screen_name" : "GemL1",
  "in_reply_to_user_id_str" : "486146568",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Smith",
      "screen_name" : "PsychologyMarc",
      "indices" : [ 3, 18 ],
      "id_str" : "94139973",
      "id" : 94139973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/MPEtaZ04cJ",
      "expanded_url" : "http:\/\/www.theguardian.com\/science\/shortcuts\/2015\/may\/05\/win-argument-pseudo-scientific-neuro-gibberish-neuroscience",
      "display_url" : "theguardian.com\/science\/shortc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "595849878426779648",
  "text" : "RT @PsychologyMarc: How to win any argument: pseudo-scientific neuro-gibberish http:\/\/t.co\/MPEtaZ04cJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/MPEtaZ04cJ",
        "expanded_url" : "http:\/\/www.theguardian.com\/science\/shortcuts\/2015\/may\/05\/win-argument-pseudo-scientific-neuro-gibberish-neuroscience",
        "display_url" : "theguardian.com\/science\/shortc\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "595839971891744768",
    "text" : "How to win any argument: pseudo-scientific neuro-gibberish http:\/\/t.co\/MPEtaZ04cJ",
    "id" : 595839971891744768,
    "created_at" : "2015-05-06 06:38:14 +0000",
    "user" : {
      "name" : "Marc Smith",
      "screen_name" : "PsychologyMarc",
      "protected" : false,
      "id_str" : "94139973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/740602940898037761\/wxCbboIl_normal.jpg",
      "id" : 94139973,
      "verified" : false
    }
  },
  "id" : 595849878426779648,
  "created_at" : "2015-05-06 07:17:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Speech Events",
      "screen_name" : "SpeechEvents",
      "indices" : [ 46, 59 ],
      "id_str" : "1468444922",
      "id" : 1468444922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/FTZwckwEzi",
      "expanded_url" : "http:\/\/wp.me\/p3Amm5-bV",
      "display_url" : "wp.me\/p3Amm5-bV"
    } ]
  },
  "geo" : { },
  "id_str" : "595847976821628928",
  "text" : "Define and conquer http:\/\/t.co\/FTZwckwEzi via @speechevents",
  "id" : 595847976821628928,
  "created_at" : "2015-05-06 07:10:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EFL Magazine",
      "screen_name" : "eflmagazine",
      "indices" : [ 3, 15 ],
      "id_str" : "2879372766",
      "id" : 2879372766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/aKh5UQYkah",
      "expanded_url" : "http:\/\/buff.ly\/1JpFttH",
      "display_url" : "buff.ly\/1JpFttH"
    } ]
  },
  "geo" : { },
  "id_str" : "595844333552717825",
  "text" : "RT @eflmagazine: Newton, Beethoven, and Me - EFL Magazine http:\/\/t.co\/aKh5UQYkah",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/aKh5UQYkah",
        "expanded_url" : "http:\/\/buff.ly\/1JpFttH",
        "display_url" : "buff.ly\/1JpFttH"
      } ]
    },
    "geo" : { },
    "id_str" : "595800849970012160",
    "text" : "Newton, Beethoven, and Me - EFL Magazine http:\/\/t.co\/aKh5UQYkah",
    "id" : 595800849970012160,
    "created_at" : "2015-05-06 04:02:46 +0000",
    "user" : {
      "name" : "EFL Magazine",
      "screen_name" : "eflmagazine",
      "protected" : false,
      "id_str" : "2879372766",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/566909861871366144\/YQt7EAWR_normal.jpeg",
      "id" : 2879372766,
      "verified" : false
    }
  },
  "id" : 595844333552717825,
  "created_at" : "2015-05-06 06:55:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 0, 15 ],
      "id_str" : "285614027",
      "id" : 285614027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "595812036946358272",
  "geo" : { },
  "id_str" : "595842135246708736",
  "in_reply_to_user_id" : 285614027,
  "text" : "@AnthonyTeacher some of the bilingual studies r fascinating wrt weak version",
  "id" : 595842135246708736,
  "in_reply_to_status_id" : 595812036946358272,
  "created_at" : "2015-05-06 06:46:49 +0000",
  "in_reply_to_screen_name" : "AnthonyTeacher",
  "in_reply_to_user_id_str" : "285614027",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Adele Soracco",
      "screen_name" : "LauraSoracco",
      "indices" : [ 0, 13 ],
      "id_str" : "15663328",
      "id" : 15663328
    }, {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 14, 20 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/f1FYCmBViO",
      "expanded_url" : "http:\/\/journals.plos.org\/plosone\/article?id=10.1371\/journal.pone.0060912",
      "display_url" : "journals.plos.org\/plosone\/articl\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "595810139615133697",
  "geo" : { },
  "id_str" : "595841509607481344",
  "in_reply_to_user_id" : 15663328,
  "text" : "@LauraSoracco @ebefl this study shows support for that http:\/\/t.co\/f1FYCmBViO",
  "id" : 595841509607481344,
  "in_reply_to_status_id" : 595810139615133697,
  "created_at" : "2015-05-06 06:44:20 +0000",
  "in_reply_to_screen_name" : "LauraSoracco",
  "in_reply_to_user_id_str" : "15663328",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "indices" : [ 3, 13 ],
      "id_str" : "577931950",
      "id" : 577931950
    }, {
      "name" : "Slate",
      "screen_name" : "Slate",
      "indices" : [ 94, 100 ],
      "id_str" : "15164565",
      "id" : 15164565
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "languagecreativity",
      "indices" : [ 62, 81 ]
    }, {
      "text" : "feelingold",
      "indices" : [ 82, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/BTCTZDb5fn",
      "expanded_url" : "https:\/\/twitter.com\/slate\/status\/595792242855510016",
      "display_url" : "twitter.com\/slate\/status\/5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "595838192454086657",
  "text" : "RT @RudyLoock: Bitch, I had never noticed this proemial bitch #languagecreativity #feelingold @Slate  https:\/\/t.co\/BTCTZDb5fn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Slate",
        "screen_name" : "Slate",
        "indices" : [ 79, 85 ],
        "id_str" : "15164565",
        "id" : 15164565
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "languagecreativity",
        "indices" : [ 47, 66 ]
      }, {
        "text" : "feelingold",
        "indices" : [ 67, 78 ]
      } ],
      "urls" : [ {
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/BTCTZDb5fn",
        "expanded_url" : "https:\/\/twitter.com\/slate\/status\/595792242855510016",
        "display_url" : "twitter.com\/slate\/status\/5\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "595826555416379392",
    "text" : "Bitch, I had never noticed this proemial bitch #languagecreativity #feelingold @Slate  https:\/\/t.co\/BTCTZDb5fn",
    "id" : 595826555416379392,
    "created_at" : "2015-05-06 05:44:55 +0000",
    "user" : {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "protected" : false,
      "id_str" : "577931950",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2370874884\/qm10et5v1fyzwixh651s_normal.jpeg",
      "id" : 577931950,
      "verified" : false
    }
  },
  "id" : 595838192454086657,
  "created_at" : "2015-05-06 06:31:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Caulfield",
      "screen_name" : "holden",
      "indices" : [ 3, 10 ],
      "id_str" : "1912681",
      "id" : 1912681
    }, {
      "name" : "Bracken Mosbacker",
      "screen_name" : "brackenm",
      "indices" : [ 70, 79 ],
      "id_str" : "22522378",
      "id" : 22522378
    }, {
      "name" : "Brian Lamb",
      "screen_name" : "brlamb",
      "indices" : [ 80, 87 ],
      "id_str" : "745903",
      "id" : 745903
    }, {
      "name" : "David Wiley, PhD",
      "screen_name" : "opencontent",
      "indices" : [ 88, 100 ],
      "id_str" : "4514361",
      "id" : 4514361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/PAlETKbiKk",
      "expanded_url" : "http:\/\/hapgood.us\/2015\/05\/05\/the-oer-case-for-federated-wiki",
      "display_url" : "hapgood.us\/2015\/05\/05\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "595675316103819264",
  "text" : "RT @holden: The OER Case for Federated Wiki http:\/\/t.co\/PAlETKbiKk cc @brackenm @brlamb @opencontent",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bracken Mosbacker",
        "screen_name" : "brackenm",
        "indices" : [ 58, 67 ],
        "id_str" : "22522378",
        "id" : 22522378
      }, {
        "name" : "Brian Lamb",
        "screen_name" : "brlamb",
        "indices" : [ 68, 75 ],
        "id_str" : "745903",
        "id" : 745903
      }, {
        "name" : "David Wiley, PhD",
        "screen_name" : "opencontent",
        "indices" : [ 76, 88 ],
        "id_str" : "4514361",
        "id" : 4514361
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 32, 54 ],
        "url" : "http:\/\/t.co\/PAlETKbiKk",
        "expanded_url" : "http:\/\/hapgood.us\/2015\/05\/05\/the-oer-case-for-federated-wiki",
        "display_url" : "hapgood.us\/2015\/05\/05\/the\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "595653353356587010",
    "text" : "The OER Case for Federated Wiki http:\/\/t.co\/PAlETKbiKk cc @brackenm @brlamb @opencontent",
    "id" : 595653353356587010,
    "created_at" : "2015-05-05 18:16:40 +0000",
    "user" : {
      "name" : "Mike Caulfield",
      "screen_name" : "holden",
      "protected" : false,
      "id_str" : "1912681",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/752538301538545665\/mXNoIc4W_normal.jpg",
      "id" : 1912681,
      "verified" : false
    }
  },
  "id" : 595675316103819264,
  "created_at" : "2015-05-05 19:43:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenys Hanson",
      "screen_name" : "GlenysHanson",
      "indices" : [ 0, 13 ],
      "id_str" : "527238447",
      "id" : 527238447
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595643654343131137",
  "in_reply_to_user_id" : 527238447,
  "text" : "@GlenysHanson thx for RT :)",
  "id" : 595643654343131137,
  "created_at" : "2015-05-05 17:38:08 +0000",
  "in_reply_to_screen_name" : "GlenysHanson",
  "in_reply_to_user_id_str" : "527238447",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Prior",
      "screen_name" : "ConceptCzech",
      "indices" : [ 0, 13 ],
      "id_str" : "256015802",
      "id" : 256015802
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "595618558966652930",
  "geo" : { },
  "id_str" : "595619493688320001",
  "in_reply_to_user_id" : 256015802,
  "text" : "@ConceptCzech good luck!",
  "id" : 595619493688320001,
  "in_reply_to_status_id" : 595618558966652930,
  "created_at" : "2015-05-05 16:02:08 +0000",
  "in_reply_to_screen_name" : "ConceptCzech",
  "in_reply_to_user_id_str" : "256015802",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "election2015",
      "indices" : [ 64, 77 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 78, 86 ]
    }, {
      "text" : "eltchinwag",
      "indices" : [ 87, 98 ]
    }, {
      "text" : "keltchat",
      "indices" : [ 99, 108 ]
    }, {
      "text" : "auselt",
      "indices" : [ 109, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/sxqUGZikaa",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-WH",
      "display_url" : "wp.me\/pgHyE-WH"
    } ]
  },
  "geo" : { },
  "id_str" : "595618375981789184",
  "text" : "Labour and the Greens visit Paris or a debating rhetoric lesson #election2015 #eltchat #eltchinwag #keltchat #auselt http:\/\/t.co\/sxqUGZikaa",
  "id" : 595618375981789184,
  "created_at" : "2015-05-05 15:57:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Prior",
      "screen_name" : "ConceptCzech",
      "indices" : [ 0, 13 ],
      "id_str" : "256015802",
      "id" : 256015802
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "595611037744922624",
  "geo" : { },
  "id_str" : "595612686727131137",
  "in_reply_to_user_id" : 256015802,
  "text" : "@ConceptCzech private post?",
  "id" : 595612686727131137,
  "in_reply_to_status_id" : 595611037744922624,
  "created_at" : "2015-05-05 15:35:05 +0000",
  "in_reply_to_screen_name" : "ConceptCzech",
  "in_reply_to_user_id_str" : "256015802",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Rayson",
      "screen_name" : "perayson",
      "indices" : [ 3, 12 ],
      "id_str" : "263108959",
      "id" : 263108959
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GE2015",
      "indices" : [ 36, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 147, 148 ],
      "url" : "http:\/\/t.co\/MQSt5uMlsL",
      "expanded_url" : "http:\/\/ucrel.lancs.ac.uk\/wmatrix\/ukmanifestos2015\/",
      "display_url" : "ucrel.lancs.ac.uk\/wmatrix\/ukmani\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "595602949063233536",
  "text" : "RT @perayson: Finally, just for the #GE2015 manifesto geeks: downloadable word, POS &amp; SEM crosstabs for all 7 with LL &amp; dispersion http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GE2015",
        "indices" : [ 22, 29 ]
      } ],
      "urls" : [ {
        "indices" : [ 125, 147 ],
        "url" : "http:\/\/t.co\/MQSt5uMlsL",
        "expanded_url" : "http:\/\/ucrel.lancs.ac.uk\/wmatrix\/ukmanifestos2015\/",
        "display_url" : "ucrel.lancs.ac.uk\/wmatrix\/ukmani\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "595596198783885312",
    "text" : "Finally, just for the #GE2015 manifesto geeks: downloadable word, POS &amp; SEM crosstabs for all 7 with LL &amp; dispersion http:\/\/t.co\/MQSt5uMlsL",
    "id" : 595596198783885312,
    "created_at" : "2015-05-05 14:29:34 +0000",
    "user" : {
      "name" : "Paul Rayson",
      "screen_name" : "perayson",
      "protected" : false,
      "id_str" : "263108959",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/490485533911445505\/BNOoOchF_normal.jpeg",
      "id" : 263108959,
      "verified" : false
    }
  },
  "id" : 595602949063233536,
  "created_at" : "2015-05-05 14:56:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Prior",
      "screen_name" : "ConceptCzech",
      "indices" : [ 0, 13 ],
      "id_str" : "256015802",
      "id" : 256015802
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "595598277359308800",
  "geo" : { },
  "id_str" : "595602649992552448",
  "in_reply_to_user_id" : 256015802,
  "text" : "@ConceptCzech damn, can u not express deliver?",
  "id" : 595602649992552448,
  "in_reply_to_status_id" : 595598277359308800,
  "created_at" : "2015-05-05 14:55:12 +0000",
  "in_reply_to_screen_name" : "ConceptCzech",
  "in_reply_to_user_id_str" : "256015802",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Barber",
      "screen_name" : "BarberDaniel",
      "indices" : [ 3, 16 ],
      "id_str" : "294987157",
      "id" : 294987157
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "innovateelt",
      "indices" : [ 44, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/EF4SDeZYwL",
      "expanded_url" : "https:\/\/learnercoachingelt.wordpress.com\/",
      "display_url" : "learnercoachingelt.wordpress.com"
    } ]
  },
  "geo" : { },
  "id_str" : "595569798202929153",
  "text" : "RT @BarberDaniel: Lesson I'll b demo-ing at #innovateelt gets learners sharing techniques, both techie &amp; unplugged! https:\/\/t.co\/EF4SDeZYwL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "innovateelt",
        "indices" : [ 26, 38 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/EF4SDeZYwL",
        "expanded_url" : "https:\/\/learnercoachingelt.wordpress.com\/",
        "display_url" : "learnercoachingelt.wordpress.com"
      } ]
    },
    "geo" : { },
    "id_str" : "595566095551090688",
    "text" : "Lesson I'll b demo-ing at #innovateelt gets learners sharing techniques, both techie &amp; unplugged! https:\/\/t.co\/EF4SDeZYwL",
    "id" : 595566095551090688,
    "created_at" : "2015-05-05 12:29:56 +0000",
    "user" : {
      "name" : "Daniel Barber",
      "screen_name" : "BarberDaniel",
      "protected" : false,
      "id_str" : "294987157",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1631938639\/Dan_mug_shot_normal.jpg",
      "id" : 294987157,
      "verified" : false
    }
  },
  "id" : 595569798202929153,
  "created_at" : "2015-05-05 12:44:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robbie Love",
      "screen_name" : "lovermob",
      "indices" : [ 3, 12 ],
      "id_str" : "19469715",
      "id" : 19469715
    }, {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "indices" : [ 25, 37 ],
      "id_str" : "849729062",
      "id" : 849729062
    }, {
      "name" : "The Conversation",
      "screen_name" : "ConversationUK",
      "indices" : [ 48, 63 ],
      "id_str" : "1241258612",
      "id" : 1241258612
    }, {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "indices" : [ 87, 103 ],
      "id_str" : "1326508478",
      "id" : 1326508478
    }, {
      "name" : "Cambridge Uni Press",
      "screen_name" : "CambridgeUP",
      "indices" : [ 104, 116 ],
      "id_str" : "319110295",
      "id" : 319110295
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/dYyu0Y003G",
      "expanded_url" : "http:\/\/theconversation.com\/the-british-talk-about-cake-50-times-as-much-as-the-deficit-politicians-should-cotton-on-41050",
      "display_url" : "theconversation.com\/the-british-ta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "595568590037721089",
  "text" : "RT @lovermob: Article by @TonyMcEnery and me in @ConversationUK http:\/\/t.co\/dYyu0Y003G @CorpusSocialSci @CambridgeUP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tony McEnery",
        "screen_name" : "TonyMcEnery",
        "indices" : [ 11, 23 ],
        "id_str" : "849729062",
        "id" : 849729062
      }, {
        "name" : "The Conversation",
        "screen_name" : "ConversationUK",
        "indices" : [ 34, 49 ],
        "id_str" : "1241258612",
        "id" : 1241258612
      }, {
        "name" : "CASS",
        "screen_name" : "CorpusSocialSci",
        "indices" : [ 73, 89 ],
        "id_str" : "1326508478",
        "id" : 1326508478
      }, {
        "name" : "Cambridge Uni Press",
        "screen_name" : "CambridgeUP",
        "indices" : [ 90, 102 ],
        "id_str" : "319110295",
        "id" : 319110295
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 72 ],
        "url" : "http:\/\/t.co\/dYyu0Y003G",
        "expanded_url" : "http:\/\/theconversation.com\/the-british-talk-about-cake-50-times-as-much-as-the-deficit-politicians-should-cotton-on-41050",
        "display_url" : "theconversation.com\/the-british-ta\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "595477440086016000",
    "geo" : { },
    "id_str" : "595477996162719744",
    "in_reply_to_user_id" : 19469715,
    "text" : "Article by @TonyMcEnery and me in @ConversationUK http:\/\/t.co\/dYyu0Y003G @CorpusSocialSci @CambridgeUP",
    "id" : 595477996162719744,
    "in_reply_to_status_id" : 595477440086016000,
    "created_at" : "2015-05-05 06:39:52 +0000",
    "in_reply_to_screen_name" : "lovermob",
    "in_reply_to_user_id_str" : "19469715",
    "user" : {
      "name" : "Robbie Love",
      "screen_name" : "lovermob",
      "protected" : false,
      "id_str" : "19469715",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733371018056716288\/4lRj6knU_normal.jpg",
      "id" : 19469715,
      "verified" : false
    }
  },
  "id" : 595568590037721089,
  "created_at" : "2015-05-05 12:39:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Costas Gabrielatos",
      "screen_name" : "congabonga",
      "indices" : [ 3, 14 ],
      "id_str" : "187484412",
      "id" : 187484412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/RlAqwq862y",
      "expanded_url" : "http:\/\/www.newstatesman.com\/politics\/2015\/05\/owen-jones-if-tories-get-more-seats-labour-get-ready-very-british-coup",
      "display_url" : "newstatesman.com\/politics\/2015\/\u2026"
    }, {
      "indices" : [ 122, 140 ],
      "url" : "http:\/\/t.co\/K0JD2lDQNE",
      "expanded_url" : "http:\/\/www.danrebellato.co.uk\/spilledink\/2015\/5\/4\/a-very-british-coup",
      "display_url" : "danrebellato.co.uk\/spilledink\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "595568298642841600",
  "text" : "RT @congabonga: CDA this! UK elections: \u2018illegitimacy\u2019 discourses analysed via \u2018coup\u2019 discourses. http:\/\/t.co\/RlAqwq862y, http:\/\/t.co\/K0JD2\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/RlAqwq862y",
        "expanded_url" : "http:\/\/www.newstatesman.com\/politics\/2015\/05\/owen-jones-if-tories-get-more-seats-labour-get-ready-very-british-coup",
        "display_url" : "newstatesman.com\/politics\/2015\/\u2026"
      }, {
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/K0JD2lDQNE",
        "expanded_url" : "http:\/\/www.danrebellato.co.uk\/spilledink\/2015\/5\/4\/a-very-british-coup",
        "display_url" : "danrebellato.co.uk\/spilledink\/201\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "595549001870659584",
    "text" : "CDA this! UK elections: \u2018illegitimacy\u2019 discourses analysed via \u2018coup\u2019 discourses. http:\/\/t.co\/RlAqwq862y, http:\/\/t.co\/K0JD2lDQNE",
    "id" : 595549001870659584,
    "created_at" : "2015-05-05 11:22:01 +0000",
    "user" : {
      "name" : "Costas Gabrielatos",
      "screen_name" : "congabonga",
      "protected" : false,
      "id_str" : "187484412",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/603260667534127104\/FkSbeNEt_normal.jpg",
      "id" : 187484412,
      "verified" : false
    }
  },
  "id" : 595568298642841600,
  "created_at" : "2015-05-05 12:38:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rich Forest",
      "screen_name" : "rwforest",
      "indices" : [ 0, 9 ],
      "id_str" : "50735779",
      "id" : 50735779
    }, {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 10, 26 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    }, {
      "name" : "Alex Grevett",
      "screen_name" : "breathyvowel",
      "indices" : [ 27, 40 ],
      "id_str" : "237547177",
      "id" : 237547177
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595445895677747200",
  "in_reply_to_user_id" : 50735779,
  "text" : "@rwforest @getgreatenglish @breathyvowel many thanks for RTs :)",
  "id" : 595445895677747200,
  "created_at" : "2015-05-05 04:32:19 +0000",
  "in_reply_to_screen_name" : "rwforest",
  "in_reply_to_user_id_str" : "50735779",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Grevett",
      "screen_name" : "breathyvowel",
      "indices" : [ 0, 13 ],
      "id_str" : "237547177",
      "id" : 237547177
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "595398186589659137",
  "geo" : { },
  "id_str" : "595442901750050816",
  "in_reply_to_user_id" : 237547177,
  "text" : "@breathyvowel woah nice :) have u found other combinations?",
  "id" : 595442901750050816,
  "in_reply_to_status_id" : 595398186589659137,
  "created_at" : "2015-05-05 04:20:25 +0000",
  "in_reply_to_screen_name" : "breathyvowel",
  "in_reply_to_user_id_str" : "237547177",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anne O'Keeffe",
      "screen_name" : "Anne0Keeffe",
      "indices" : [ 0, 12 ],
      "id_str" : "310322075",
      "id" : 310322075
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595441737994268672",
  "in_reply_to_user_id" : 310322075,
  "text" : "@Anne0Keeffe hi, many thanks for 3 RTs! :)",
  "id" : 595441737994268672,
  "created_at" : "2015-05-05 04:15:47 +0000",
  "in_reply_to_screen_name" : "Anne0Keeffe",
  "in_reply_to_user_id_str" : "310322075",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Rayson",
      "screen_name" : "perayson",
      "indices" : [ 0, 9 ],
      "id_str" : "263108959",
      "id" : 263108959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "595360600043233280",
  "geo" : { },
  "id_str" : "595441622931869696",
  "in_reply_to_user_id" : 263108959,
  "text" : "@perayson hi i copy-pasted not converted then quick manual clean-up",
  "id" : 595441622931869696,
  "in_reply_to_status_id" : 595360600043233280,
  "created_at" : "2015-05-05 04:15:20 +0000",
  "in_reply_to_screen_name" : "perayson",
  "in_reply_to_user_id_str" : "263108959",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russell Brand",
      "screen_name" : "rustyrockets",
      "indices" : [ 91, 104 ],
      "id_str" : "19562228",
      "id" : 19562228
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/SLVbOO8ZeH",
      "expanded_url" : "http:\/\/www.truthdig.com\/report\/item\/make_the_rich_panic_20150503",
      "display_url" : "truthdig.com\/report\/item\/ma\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "595328850436952065",
  "text" : "Chris Hedges Make the Rich Panic http:\/\/t.co\/SLVbOO8ZeH an antidote to naivety of likes of @rustyrockets",
  "id" : 595328850436952065,
  "created_at" : "2015-05-04 20:47:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "M.K",
      "screen_name" : "usage_based",
      "indices" : [ 0, 12 ],
      "id_str" : "1479290418",
      "id" : 1479290418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "595292912260231168",
  "geo" : { },
  "id_str" : "595311620974313474",
  "in_reply_to_user_id" : 1479290418,
  "text" : "@usage_based congrats! any details of corpus?",
  "id" : 595311620974313474,
  "in_reply_to_status_id" : 595292912260231168,
  "created_at" : "2015-05-04 19:38:45 +0000",
  "in_reply_to_screen_name" : "usage_based",
  "in_reply_to_user_id_str" : "1479290418",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Igor Brigadir",
      "screen_name" : "IgorBrigadir",
      "indices" : [ 3, 16 ],
      "id_str" : "495430242",
      "id" : 495430242
    }, {
      "name" : "BBC News Labs",
      "screen_name" : "BBC_News_Labs",
      "indices" : [ 22, 36 ],
      "id_str" : "701022607",
      "id" : 701022607
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/IgorBrigadir\/status\/594923629659496448\/photo\/1",
      "indices" : [ 127, 140 ],
      "url" : "http:\/\/t.co\/O10Jtltd8D",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEGX42xXIAAl-zg.png",
      "id_str" : "594923628820635648",
      "id" : 594923628820635648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEGX42xXIAAl-zg.png",
      "sizes" : [ {
        "h" : 192,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 889,
        "resize" : "fit",
        "w" : 1577
      }, {
        "h" : 577,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/O10Jtltd8D"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/38BtmCD4vb",
      "expanded_url" : "http:\/\/wat.bbcnewslabs.co.uk\/",
      "display_url" : "wat.bbcnewslabs.co.uk"
    } ]
  },
  "geo" : { },
  "id_str" : "595246761012240384",
  "text" : "RT @IgorBrigadir: The @BBC_News_Labs WAT demo is great: http:\/\/t.co\/38BtmCD4vb - who's talking about what across news sources. http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BBC News Labs",
        "screen_name" : "BBC_News_Labs",
        "indices" : [ 4, 18 ],
        "id_str" : "701022607",
        "id" : 701022607
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/IgorBrigadir\/status\/594923629659496448\/photo\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/O10Jtltd8D",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CEGX42xXIAAl-zg.png",
        "id_str" : "594923628820635648",
        "id" : 594923628820635648,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEGX42xXIAAl-zg.png",
        "sizes" : [ {
          "h" : 192,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 889,
          "resize" : "fit",
          "w" : 1577
        }, {
          "h" : 577,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/O10Jtltd8D"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 60 ],
        "url" : "http:\/\/t.co\/38BtmCD4vb",
        "expanded_url" : "http:\/\/wat.bbcnewslabs.co.uk\/",
        "display_url" : "wat.bbcnewslabs.co.uk"
      } ]
    },
    "geo" : { },
    "id_str" : "594923629659496448",
    "text" : "The @BBC_News_Labs WAT demo is great: http:\/\/t.co\/38BtmCD4vb - who's talking about what across news sources. http:\/\/t.co\/O10Jtltd8D",
    "id" : 594923629659496448,
    "created_at" : "2015-05-03 17:57:01 +0000",
    "user" : {
      "name" : "Igor Brigadir",
      "screen_name" : "IgorBrigadir",
      "protected" : false,
      "id_str" : "495430242",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2538946114\/xiveugt78rc97y1dasxf_normal.jpeg",
      "id" : 495430242,
      "verified" : false
    }
  },
  "id" : 595246761012240384,
  "created_at" : "2015-05-04 15:21:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Igor Brigadir",
      "screen_name" : "IgorBrigadir",
      "indices" : [ 3, 16 ],
      "id_str" : "495430242",
      "id" : 495430242
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/IgorBrigadir\/status\/595218999383879681\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/2eC0vM237s",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEKkhkqWAAAnJTB.png",
      "id_str" : "595218997450244096",
      "id" : 595218997450244096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEKkhkqWAAAnJTB.png",
      "sizes" : [ {
        "h" : 506,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 518,
        "resize" : "fit",
        "w" : 614
      }, {
        "h" : 518,
        "resize" : "fit",
        "w" : 614
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 287,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/2eC0vM237s"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/sypRZegYaJ",
      "expanded_url" : "http:\/\/members.unine.ch\/martin.hilpert\/motion.html",
      "display_url" : "members.unine.ch\/martin.hilpert\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "595245451990949888",
  "text" : "RT @IgorBrigadir: These Linguistic Motion Charts are interesting: http:\/\/t.co\/sypRZegYaJ dynamic visualisation of word use over time: http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/IgorBrigadir\/status\/595218999383879681\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/2eC0vM237s",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CEKkhkqWAAAnJTB.png",
        "id_str" : "595218997450244096",
        "id" : 595218997450244096,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEKkhkqWAAAnJTB.png",
        "sizes" : [ {
          "h" : 506,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 518,
          "resize" : "fit",
          "w" : 614
        }, {
          "h" : 518,
          "resize" : "fit",
          "w" : 614
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 287,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/2eC0vM237s"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 70 ],
        "url" : "http:\/\/t.co\/sypRZegYaJ",
        "expanded_url" : "http:\/\/members.unine.ch\/martin.hilpert\/motion.html",
        "display_url" : "members.unine.ch\/martin.hilpert\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "595218999383879681",
    "text" : "These Linguistic Motion Charts are interesting: http:\/\/t.co\/sypRZegYaJ dynamic visualisation of word use over time: http:\/\/t.co\/2eC0vM237s",
    "id" : 595218999383879681,
    "created_at" : "2015-05-04 13:30:42 +0000",
    "user" : {
      "name" : "Igor Brigadir",
      "screen_name" : "IgorBrigadir",
      "protected" : false,
      "id_str" : "495430242",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2538946114\/xiveugt78rc97y1dasxf_normal.jpeg",
      "id" : 495430242,
      "verified" : false
    }
  },
  "id" : 595245451990949888,
  "created_at" : "2015-05-04 15:15:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Spencer",
      "screen_name" : "spencerideas",
      "indices" : [ 0, 13 ],
      "id_str" : "18389166",
      "id" : 18389166
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "594982745039745025",
  "geo" : { },
  "id_str" : "594983682835877888",
  "in_reply_to_user_id" : 18389166,
  "text" : "@spencerideas i guess if all close family agreed next best thing? absence of Dave Grohl was conspicuous",
  "id" : 594983682835877888,
  "in_reply_to_status_id" : 594982745039745025,
  "created_at" : "2015-05-03 21:55:38 +0000",
  "in_reply_to_screen_name" : "spencerideas",
  "in_reply_to_user_id_str" : "18389166",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Spencer",
      "screen_name" : "spencerideas",
      "indices" : [ 0, 13 ],
      "id_str" : "18389166",
      "id" : 18389166
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "594979706224574464",
  "geo" : { },
  "id_str" : "594980553688010752",
  "in_reply_to_user_id" : 18389166,
  "text" : "@spencerideas too long i thought but not bad, what mixed feeling do u have?",
  "id" : 594980553688010752,
  "in_reply_to_status_id" : 594979706224574464,
  "created_at" : "2015-05-03 21:43:12 +0000",
  "in_reply_to_screen_name" : "spencerideas",
  "in_reply_to_user_id_str" : "18389166",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicola Prentis",
      "screen_name" : "NicolaPrentis",
      "indices" : [ 3, 17 ],
      "id_str" : "810667033",
      "id" : 810667033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/tmxvPpDxIB",
      "expanded_url" : "http:\/\/wp.me\/p1RJaO-lep",
      "display_url" : "wp.me\/p1RJaO-lep"
    } ]
  },
  "geo" : { },
  "id_str" : "594847071674507264",
  "text" : "RT @NicolaPrentis: Is there discourse against women in\u00A0ELT? http:\/\/t.co\/tmxvPpDxIB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/tmxvPpDxIB",
        "expanded_url" : "http:\/\/wp.me\/p1RJaO-lep",
        "display_url" : "wp.me\/p1RJaO-lep"
      } ]
    },
    "geo" : { },
    "id_str" : "594814997164765185",
    "text" : "Is there discourse against women in\u00A0ELT? http:\/\/t.co\/tmxvPpDxIB",
    "id" : 594814997164765185,
    "created_at" : "2015-05-03 10:45:21 +0000",
    "user" : {
      "name" : "Nicola Prentis",
      "screen_name" : "NicolaPrentis",
      "protected" : false,
      "id_str" : "810667033",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3046181441\/a51ef543c16ff30fdb8966f23237790d_normal.jpeg",
      "id" : 810667033,
      "verified" : false
    }
  },
  "id" : 594847071674507264,
  "created_at" : "2015-05-03 12:52:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 48, 64 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/3IjjMVLWYs",
      "expanded_url" : "http:\/\/wp.me\/pJw7u-1iv",
      "display_url" : "wp.me\/pJw7u-1iv"
    } ]
  },
  "geo" : { },
  "id_str" : "594761733337649153",
  "text" : "G is for Granularity http:\/\/t.co\/3IjjMVLWYs via @wordpressdotcom",
  "id" : 594761733337649153,
  "created_at" : "2015-05-03 07:13:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Costas Gabrielatos",
      "screen_name" : "congabonga",
      "indices" : [ 0, 11 ],
      "id_str" : "187484412",
      "id" : 187484412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "594511672930344960",
  "geo" : { },
  "id_str" : "594513173027397632",
  "in_reply_to_user_id" : 187484412,
  "text" : "@congabonga i think it often happens when Twitter does some changes sure they will be back",
  "id" : 594513173027397632,
  "in_reply_to_status_id" : 594511672930344960,
  "created_at" : "2015-05-02 14:46:00 +0000",
  "in_reply_to_screen_name" : "congabonga",
  "in_reply_to_user_id_str" : "187484412",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 0, 13 ],
      "id_str" : "88655243",
      "id" : 88655243
    }, {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 14, 29 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/bAssl6FuwF",
      "expanded_url" : "http:\/\/ukmanifestos.englishup.me",
      "display_url" : "ukmanifestos.englishup.me"
    } ]
  },
  "geo" : { },
  "id_str" : "594510273131769856",
  "in_reply_to_user_id" : 88655243,
  "text" : "@rosemerebard @GeoffreyJordan thx for RTing http:\/\/t.co\/bAssl6FuwF if u spot anything interesting tweet back :)",
  "id" : 594510273131769856,
  "created_at" : "2015-05-02 14:34:29 +0000",
  "in_reply_to_screen_name" : "rosemerebard",
  "in_reply_to_user_id_str" : "88655243",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 3, 14 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594509945816494080",
  "text" : "RT @hughdellar: Nothing highlights the residual serf-like mentality of England's feudal system quite as much as a royal baby.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "594398431331889152",
    "text" : "Nothing highlights the residual serf-like mentality of England's feudal system quite as much as a royal baby.",
    "id" : 594398431331889152,
    "created_at" : "2015-05-02 07:10:04 +0000",
    "user" : {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "protected" : false,
      "id_str" : "88202140",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2040881292\/Hugh_Dellar_photo_normal.jpg",
      "id" : 88202140,
      "verified" : false
    }
  },
  "id" : 594509945816494080,
  "created_at" : "2015-05-02 14:33:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "4TUNE Teller App",
      "screen_name" : "4tunetellernet",
      "indices" : [ 0, 15 ],
      "id_str" : "467634146",
      "id" : 467634146
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "594249002641661953",
  "geo" : { },
  "id_str" : "594249729992691712",
  "in_reply_to_user_id" : 467634146,
  "text" : "@4tunetellernet enjoy :)",
  "id" : 594249729992691712,
  "in_reply_to_status_id" : 594249002641661953,
  "created_at" : "2015-05-01 21:19:10 +0000",
  "in_reply_to_screen_name" : "4tunetellernet",
  "in_reply_to_user_id_str" : "467634146",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "4TUNE Teller App",
      "screen_name" : "4tunetellernet",
      "indices" : [ 0, 15 ],
      "id_str" : "467634146",
      "id" : 467634146
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "594248634956382209",
  "geo" : { },
  "id_str" : "594248798005796865",
  "in_reply_to_user_id" : 467634146,
  "text" : "@4tunetellernet yep what u up to?",
  "id" : 594248798005796865,
  "in_reply_to_status_id" : 594248634956382209,
  "created_at" : "2015-05-01 21:15:28 +0000",
  "in_reply_to_screen_name" : "4tunetellernet",
  "in_reply_to_user_id_str" : "467634146",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "4TUNE Teller App",
      "screen_name" : "4tunetellernet",
      "indices" : [ 58, 73 ],
      "id_str" : "467634146",
      "id" : 467634146
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594246281859567617",
  "text" : "there goes my early night kurt cobain doc is available cc @4tunetellernet",
  "id" : 594246281859567617,
  "created_at" : "2015-05-01 21:05:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/594223577588699136\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/y5wbkYf1X6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CD8bMdNWYAESQ7u.png",
      "id_str" : "594223576649195521",
      "id" : 594223576649195521,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CD8bMdNWYAESQ7u.png",
      "sizes" : [ {
        "h" : 85,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 204,
        "resize" : "fit",
        "w" : 1432
      }, {
        "h" : 48,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 146,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/y5wbkYf1X6"
    } ],
    "hashtags" : [ {
      "text" : "ELECTION2015",
      "indices" : [ 32, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/bqH8G6R0fF",
      "expanded_url" : "http:\/\/ukmanifestos.englishup.me\/",
      "display_url" : "ukmanifestos.englishup.me"
    } ]
  },
  "geo" : { },
  "id_str" : "594223577588699136",
  "text" : "Both Conservatives &amp; Greens #ELECTION2015 manifestos use \"global\" but very differently http:\/\/t.co\/bqH8G6R0fF http:\/\/t.co\/y5wbkYf1X6",
  "id" : 594223577588699136,
  "created_at" : "2015-05-01 19:35:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "indices" : [ 3, 16 ],
      "id_str" : "1685397408",
      "id" : 1685397408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/UPBaw09bPv",
      "expanded_url" : "http:\/\/wp.me\/p15Ewi-3io",
      "display_url" : "wp.me\/p15Ewi-3io"
    } ]
  },
  "geo" : { },
  "id_str" : "594202977650536448",
  "text" : "RT @harrisonmike: On uncertainty http:\/\/t.co\/UPBaw09bPv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 15, 37 ],
        "url" : "http:\/\/t.co\/UPBaw09bPv",
        "expanded_url" : "http:\/\/wp.me\/p15Ewi-3io",
        "display_url" : "wp.me\/p15Ewi-3io"
      } ]
    },
    "geo" : { },
    "id_str" : "594187132853301248",
    "text" : "On uncertainty http:\/\/t.co\/UPBaw09bPv",
    "id" : 594187132853301248,
    "created_at" : "2015-05-01 17:10:26 +0000",
    "user" : {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "protected" : false,
      "id_str" : "1685397408",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/697937835127672832\/Z5BuTNo2_normal.jpg",
      "id" : 1685397408,
      "verified" : false
    }
  },
  "id" : 594202977650536448,
  "created_at" : "2015-05-01 18:13:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amin Neghavati",
      "screen_name" : "neghavati",
      "indices" : [ 0, 10 ],
      "id_str" : "2690477970",
      "id" : 2690477970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "594149104457949184",
  "geo" : { },
  "id_str" : "594196141937434624",
  "in_reply_to_user_id" : 2690477970,
  "text" : "@neghavati my pleasure lk fwd to other posts in series :)",
  "id" : 594196141937434624,
  "in_reply_to_status_id" : 594149104457949184,
  "created_at" : "2015-05-01 17:46:14 +0000",
  "in_reply_to_screen_name" : "neghavati",
  "in_reply_to_user_id_str" : "2690477970",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NPR's Code Switch",
      "screen_name" : "NPRCodeSwitch",
      "indices" : [ 0, 14 ],
      "id_str" : "1117836660",
      "id" : 1117836660
    }, {
      "name" : "Magnus Nissel",
      "screen_name" : "u203d",
      "indices" : [ 15, 21 ],
      "id_str" : "533114985",
      "id" : 533114985
    }, {
      "name" : "karenbates",
      "screen_name" : "karenbates",
      "indices" : [ 22, 33 ],
      "id_str" : "18499574",
      "id" : 18499574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/jHUJDirkkh",
      "expanded_url" : "https:\/\/firstlook.org\/theintercept\/2015\/04\/30\/cowardly-firing-australian-tv-journalists-highlights-west-religion\/",
      "display_url" : "firstlook.org\/theintercept\/2\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "593893206137434112",
  "geo" : { },
  "id_str" : "594102570269941760",
  "in_reply_to_user_id" : 1117836660,
  "text" : "@NPRCodeSwitch @u203d @karenbates read recently that NPR bans use of word torture to describe government torture https:\/\/t.co\/jHUJDirkkh",
  "id" : 594102570269941760,
  "in_reply_to_status_id" : 593893206137434112,
  "created_at" : "2015-05-01 11:34:25 +0000",
  "in_reply_to_screen_name" : "NPRCodeSwitch",
  "in_reply_to_user_id_str" : "1117836660",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/5yl1fLFeu6",
      "expanded_url" : "http:\/\/www.eurotrib.com\/story\/2015\/4\/29\/92249\/3495",
      "display_url" : "eurotrib.com\/story\/2015\/4\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "594099135063687168",
  "text" : "On SYRIZA, negotiations and compromise http:\/\/t.co\/5yl1fLFeu6",
  "id" : 594099135063687168,
  "created_at" : "2015-05-01 11:20:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenn Greenwald",
      "screen_name" : "ggreenwald",
      "indices" : [ 119, 130 ],
      "id_str" : "16076032",
      "id" : 16076032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/989Wqd024V",
      "expanded_url" : "http:\/\/interc.pt\/1GyRl9K",
      "display_url" : "interc.pt\/1GyRl9K"
    } ]
  },
  "geo" : { },
  "id_str" : "594088995019223040",
  "text" : "Cowardly Firing of Australian State-Funded TV Journalist Highlights the West\u2019s Real Religion http:\/\/t.co\/989Wqd024V by @ggreenwald",
  "id" : 594088995019223040,
  "created_at" : "2015-05-01 10:40:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Levine",
      "screen_name" : "cogdog",
      "indices" : [ 3, 10 ],
      "id_str" : "740343",
      "id" : 740343
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rhizo15",
      "indices" : [ 102, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/LNhLDpIkH4",
      "expanded_url" : "http:\/\/wp.me\/pf0PM-b0x",
      "display_url" : "wp.me\/pf0PM-b0x"
    } ]
  },
  "geo" : { },
  "id_str" : "594087086099144704",
  "text" : "RT @cogdog: CogDogBlogged: Propelling a Course By Something Other than Content http:\/\/t.co\/LNhLDpIkH4 #rhizo15",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sopresto.mailchimp.com\" rel=\"nofollow\"\u003ESocial Proxy by Mailchimp\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "rhizo15",
        "indices" : [ 90, 98 ]
      } ],
      "urls" : [ {
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/LNhLDpIkH4",
        "expanded_url" : "http:\/\/wp.me\/pf0PM-b0x",
        "display_url" : "wp.me\/pf0PM-b0x"
      } ]
    },
    "geo" : { },
    "id_str" : "594031583188758528",
    "text" : "CogDogBlogged: Propelling a Course By Something Other than Content http:\/\/t.co\/LNhLDpIkH4 #rhizo15",
    "id" : 594031583188758528,
    "created_at" : "2015-05-01 06:52:20 +0000",
    "user" : {
      "name" : "Alan Levine",
      "screen_name" : "cogdog",
      "protected" : false,
      "id_str" : "740343",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/740063389527859201\/BN9buLB9_normal.jpg",
      "id" : 740343,
      "verified" : false
    }
  },
  "id" : 594087086099144704,
  "created_at" : "2015-05-01 10:32:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Michael Riccioli",
      "screen_name" : "curvedway",
      "indices" : [ 0, 10 ],
      "id_str" : "124707247",
      "id" : 124707247
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594062585185574913",
  "in_reply_to_user_id" : 124707247,
  "text" : "@curvedway oh wanted to say i enjoyed 8 &amp; 9 of life hacks :)",
  "id" : 594062585185574913,
  "created_at" : "2015-05-01 08:55:32 +0000",
  "in_reply_to_screen_name" : "curvedway",
  "in_reply_to_user_id_str" : "124707247",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "indices" : [ 10, 20 ],
      "id_str" : "577931950",
      "id" : 577931950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "589010432515518465",
  "geo" : { },
  "id_str" : "594057830241607680",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava @RudyLoock there's some very interesting CL history in that paper",
  "id" : 594057830241607680,
  "in_reply_to_status_id" : 589010432515518465,
  "created_at" : "2015-05-01 08:36:38 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Rayson",
      "screen_name" : "perayson",
      "indices" : [ 0, 9 ],
      "id_str" : "263108959",
      "id" : 263108959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/XUivLm8GmO",
      "expanded_url" : "https:\/\/bop.unibe.ch\/linguistik-online\/article\/view\/1447\/2461",
      "display_url" : "bop.unibe.ch\/linguistik-onl\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "594051204029784064",
  "geo" : { },
  "id_str" : "594056520238833664",
  "in_reply_to_user_id" : 263108959,
  "text" : "@perayson yeah could also ask this guy for a copy of his corpus https:\/\/t.co\/XUivLm8GmO :)",
  "id" : 594056520238833664,
  "in_reply_to_status_id" : 594051204029784064,
  "created_at" : "2015-05-01 08:31:26 +0000",
  "in_reply_to_screen_name" : "perayson",
  "in_reply_to_user_id_str" : "263108959",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amin Neghavati",
      "screen_name" : "neghavati",
      "indices" : [ 3, 13 ],
      "id_str" : "2690477970",
      "id" : 2690477970
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL2015",
      "indices" : [ 15, 26 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/opyqUt1czo",
      "expanded_url" : "http:\/\/wp.me\/p5Krf8-3R",
      "display_url" : "wp.me\/p5Krf8-3R"
    } ]
  },
  "geo" : { },
  "id_str" : "594046985436602368",
  "text" : "RT @neghavati: #IATEFL2015 | Saeede Haghi | Trinity College London Language Examinations Scholarship Winner http:\/\/t.co\/opyqUt1czo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IATEFL2015",
        "indices" : [ 0, 11 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/opyqUt1czo",
        "expanded_url" : "http:\/\/wp.me\/p5Krf8-3R",
        "display_url" : "wp.me\/p5Krf8-3R"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 3.156949, 101.712303 ]
    },
    "id_str" : "594042530208976896",
    "text" : "#IATEFL2015 | Saeede Haghi | Trinity College London Language Examinations Scholarship Winner http:\/\/t.co\/opyqUt1czo",
    "id" : 594042530208976896,
    "created_at" : "2015-05-01 07:35:50 +0000",
    "user" : {
      "name" : "Amin Neghavati",
      "screen_name" : "neghavati",
      "protected" : false,
      "id_str" : "2690477970",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/755348991223541760\/_myJwSIY_normal.jpg",
      "id" : 2690477970,
      "verified" : false
    }
  },
  "id" : 594046985436602368,
  "created_at" : "2015-05-01 07:53:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "indices" : [ 3, 19 ],
      "id_str" : "1326508478",
      "id" : 1326508478
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GraphColl",
      "indices" : [ 99, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/ZX0iO3YVNr",
      "expanded_url" : "http:\/\/cass.lancs.ac.uk\/?p=1644",
      "display_url" : "cass.lancs.ac.uk\/?p=1644"
    } ]
  },
  "geo" : { },
  "id_str" : "594045923459780609",
  "text" : "RT @CorpusSocialSci: Elaine Boyd of the Trinity Lancaster Corpus in residence at CASS working with #GraphColl at 'The heart of the matter' \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GraphColl",
        "indices" : [ 78, 88 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/ZX0iO3YVNr",
        "expanded_url" : "http:\/\/cass.lancs.ac.uk\/?p=1644",
        "display_url" : "cass.lancs.ac.uk\/?p=1644"
      } ]
    },
    "geo" : { },
    "id_str" : "593777014760448000",
    "text" : "Elaine Boyd of the Trinity Lancaster Corpus in residence at CASS working with #GraphColl at 'The heart of the matter' http:\/\/t.co\/ZX0iO3YVNr",
    "id" : 593777014760448000,
    "created_at" : "2015-04-30 14:00:46 +0000",
    "user" : {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "protected" : false,
      "id_str" : "1326508478",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3493899777\/ced36fe15c32eb911cbe3d64377524dc_normal.jpeg",
      "id" : 1326508478,
      "verified" : false
    }
  },
  "id" : 594045923459780609,
  "created_at" : "2015-05-01 07:49:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sam kaislaniemi",
      "screen_name" : "samklai",
      "indices" : [ 0, 8 ],
      "id_str" : "16984834",
      "id" : 16984834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594045362333196289",
  "in_reply_to_user_id" : 16984834,
  "text" : "@samklai hi thx for RT :)",
  "id" : 594045362333196289,
  "created_at" : "2015-05-01 07:47:05 +0000",
  "in_reply_to_screen_name" : "samklai",
  "in_reply_to_user_id_str" : "16984834",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Rayson",
      "screen_name" : "perayson",
      "indices" : [ 0, 9 ],
      "id_str" : "263108959",
      "id" : 263108959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/n0yDXguFml",
      "expanded_url" : "http:\/\/www.politicsresources.net\/area\/uk\/man.htm",
      "display_url" : "politicsresources.net\/area\/uk\/man.htm"
    } ]
  },
  "in_reply_to_status_id_str" : "594040554230538241",
  "geo" : { },
  "id_str" : "594045064113999872",
  "in_reply_to_user_id" : 263108959,
  "text" : "@perayson great btw do u know this site? http:\/\/t.co\/n0yDXguFml",
  "id" : 594045064113999872,
  "in_reply_to_status_id" : 594040554230538241,
  "created_at" : "2015-05-01 07:45:54 +0000",
  "in_reply_to_screen_name" : "perayson",
  "in_reply_to_user_id_str" : "263108959",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0633\u0644\u0637\u0627\u0646 \u0627\u0644\u0645\u062C\u064A\u0648\u0644",
      "screen_name" : "Arabic_CL",
      "indices" : [ 0, 10 ],
      "id_str" : "469764795",
      "id" : 469764795
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594009192043778048",
  "in_reply_to_user_id" : 469764795,
  "text" : "@Arabic_CL thanks for RT :)",
  "id" : 594009192043778048,
  "created_at" : "2015-05-01 05:23:22 +0000",
  "in_reply_to_screen_name" : "Arabic_CL",
  "in_reply_to_user_id_str" : "469764795",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Rayson",
      "screen_name" : "perayson",
      "indices" : [ 0, 9 ],
      "id_str" : "263108959",
      "id" : 263108959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "593905575966171136",
  "in_reply_to_user_id" : 263108959,
  "text" : "@perayson thanks for RT, fyi for some reason the python script kept falling on your green2015 txt had to copy paste form pdf into new text",
  "id" : 593905575966171136,
  "created_at" : "2015-04-30 22:31:38 +0000",
  "in_reply_to_screen_name" : "perayson",
  "in_reply_to_user_id_str" : "263108959",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELECTION2015",
      "indices" : [ 53, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/bqH8G6R0fF",
      "expanded_url" : "http:\/\/ukmanifestos.englishup.me\/",
      "display_url" : "ukmanifestos.englishup.me"
    } ]
  },
  "geo" : { },
  "id_str" : "593902951715971073",
  "text" : "http:\/\/t.co\/bqH8G6R0fF updated with all main parties #ELECTION2015",
  "id" : 593902951715971073,
  "created_at" : "2015-04-30 22:21:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Deubelbeiss",
      "screen_name" : "ddeubel",
      "indices" : [ 0, 8 ],
      "id_str" : "52174903",
      "id" : 52174903
    }, {
      "name" : "Glenys Hanson",
      "screen_name" : "GlenysHanson",
      "indices" : [ 9, 22 ],
      "id_str" : "527238447",
      "id" : 527238447
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "593894629965107200",
  "geo" : { },
  "id_str" : "593901674831437824",
  "in_reply_to_user_id" : 52174903,
  "text" : "@ddeubel @GlenysHanson yr welcome Biesta is always a good read",
  "id" : 593901674831437824,
  "in_reply_to_status_id" : 593894629965107200,
  "created_at" : "2015-04-30 22:16:08 +0000",
  "in_reply_to_screen_name" : "ddeubel",
  "in_reply_to_user_id_str" : "52174903",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
} ]