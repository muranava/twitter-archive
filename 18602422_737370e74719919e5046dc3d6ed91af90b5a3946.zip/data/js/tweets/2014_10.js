Grailbird.data.tweets_2014_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Aisha Brown",
      "screen_name" : "amyaishab",
      "indices" : [ 0, 10 ],
      "id_str" : "900029641",
      "id" : 900029641
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "528152054041042944",
  "geo" : { },
  "id_str" : "528153145327624192",
  "in_reply_to_user_id" : 900029641,
  "text" : "@amyaishab there's some nice conceptualisations in the Lee paper that is linked in my chart that you could mine for such a chart :)",
  "id" : 528153145327624192,
  "in_reply_to_status_id" : 528152054041042944,
  "created_at" : "2014-10-31 11:54:57 +0000",
  "in_reply_to_screen_name" : "amyaishab",
  "in_reply_to_user_id_str" : "900029641",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/JOTKJKV8zT",
      "expanded_url" : "http:\/\/www.independent.co.uk\/voices\/comment\/if-you-think-russell-brands-new-book-is-confused-you-should-read-what-his-critics-have-to-say-about-it-9829224.html",
      "display_url" : "independent.co.uk\/voices\/comment\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "528140480572162051",
  "text" : "If you think Russell Brand\u2019s new book is confused, you should read what his critics have to say about it http:\/\/t.co\/JOTKJKV8zT",
  "id" : 528140480572162051,
  "created_at" : "2014-10-31 11:04:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 31, 42 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/vE8MqFpev0",
      "expanded_url" : "https:\/\/magic.piktochart.com\/output\/3291103-genreregister",
      "display_url" : "magic.piktochart.com\/output\/3291103\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "527953503499866113",
  "text" : "very simplified visual aid for #corpusmooc genre vs register https:\/\/t.co\/vE8MqFpev0",
  "id" : 527953503499866113,
  "created_at" : "2014-10-30 22:41:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 0, 9 ],
      "id_str" : "134211317",
      "id" : 134211317
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "piratebox",
      "indices" : [ 39, 49 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "527751786229403648",
  "geo" : { },
  "id_str" : "527903295692886016",
  "in_reply_to_user_id" : 134211317,
  "text" : "@josipa74 hi Paul you should check out #piratebox",
  "id" : 527903295692886016,
  "in_reply_to_status_id" : 527751786229403648,
  "created_at" : "2014-10-30 19:22:08 +0000",
  "in_reply_to_screen_name" : "josipa74",
  "in_reply_to_user_id_str" : "134211317",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Aisha Brown",
      "screen_name" : "amyaishab",
      "indices" : [ 0, 10 ],
      "id_str" : "900029641",
      "id" : 900029641
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "527902315815370752",
  "geo" : { },
  "id_str" : "527903018491322370",
  "in_reply_to_user_id" : 900029641,
  "text" : "@amyaishab nice what's your bit on?",
  "id" : 527903018491322370,
  "in_reply_to_status_id" : 527902315815370752,
  "created_at" : "2014-10-30 19:21:02 +0000",
  "in_reply_to_screen_name" : "amyaishab",
  "in_reply_to_user_id_str" : "900029641",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Lewis",
      "screen_name" : "mark3141592",
      "indices" : [ 0, 12 ],
      "id_str" : "1289627816",
      "id" : 1289627816
    }, {
      "name" : "Speech Events",
      "screen_name" : "SpeechEvents",
      "indices" : [ 13, 26 ],
      "id_str" : "1468444922",
      "id" : 1468444922
    }, {
      "name" : "Jojouxpo",
      "screen_name" : "joannaluz",
      "indices" : [ 27, 37 ],
      "id_str" : "32655386",
      "id" : 32655386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "527824782910558208",
  "geo" : { },
  "id_str" : "527853597825175552",
  "in_reply_to_user_id" : 1289627816,
  "text" : "@mark3141592 @SpeechEvents @joannaluz ok thx for info, the tweet was from your share button",
  "id" : 527853597825175552,
  "in_reply_to_status_id" : 527824782910558208,
  "created_at" : "2014-10-30 16:04:39 +0000",
  "in_reply_to_screen_name" : "mark3141592",
  "in_reply_to_user_id_str" : "1289627816",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hana Tich\u00E1",
      "screen_name" : "HanaTicha",
      "indices" : [ 3, 13 ],
      "id_str" : "512296705",
      "id" : 512296705
    }, {
      "name" : "Vedrana Vojkovi\u0107",
      "screen_name" : "Ven_VVE",
      "indices" : [ 15, 23 ],
      "id_str" : "270839603",
      "id" : 270839603
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/GmTuUn7HBD",
      "expanded_url" : "https:\/\/sites.google.com\/site\/sketchengineforeslteachers\/sketchengine",
      "display_url" : "sites.google.com\/site\/sketcheng\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "527780916538904576",
  "text" : "RT @HanaTicha: @Ven_VVE Thanks. Check out this project my two friends and I did at uni back in 2012 \nSketchEngine for ESL Teachers.\nhttps:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vedrana Vojkovi\u0107",
        "screen_name" : "Ven_VVE",
        "indices" : [ 0, 8 ],
        "id_str" : "270839603",
        "id" : 270839603
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/GmTuUn7HBD",
        "expanded_url" : "https:\/\/sites.google.com\/site\/sketchengineforeslteachers\/sketchengine",
        "display_url" : "sites.google.com\/site\/sketcheng\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "527467582282952704",
    "geo" : { },
    "id_str" : "527479938241544192",
    "in_reply_to_user_id" : 270839603,
    "text" : "@Ven_VVE Thanks. Check out this project my two friends and I did at uni back in 2012 \nSketchEngine for ESL Teachers.\nhttps:\/\/t.co\/GmTuUn7HBD",
    "id" : 527479938241544192,
    "in_reply_to_status_id" : 527467582282952704,
    "created_at" : "2014-10-29 15:19:52 +0000",
    "in_reply_to_screen_name" : "Ven_VVE",
    "in_reply_to_user_id_str" : "270839603",
    "user" : {
      "name" : "Hana Tich\u00E1",
      "screen_name" : "HanaTicha",
      "protected" : false,
      "id_str" : "512296705",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/699528253598494721\/HL9Np6Gu_normal.jpg",
      "id" : 512296705,
      "verified" : false
    }
  },
  "id" : 527780916538904576,
  "created_at" : "2014-10-30 11:15:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vedrana Vojkovi\u0107",
      "screen_name" : "Ven_VVE",
      "indices" : [ 3, 11 ],
      "id_str" : "270839603",
      "id" : 270839603
    }, {
      "name" : "Hana Tich\u00E1",
      "screen_name" : "HanaTicha",
      "indices" : [ 91, 101 ],
      "id_str" : "512296705",
      "id" : 512296705
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 36, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 143, 144 ],
      "url" : "http:\/\/t.co\/DdBBDCzhQ8",
      "expanded_url" : "http:\/\/how-i-see-it-now.blogspot.com\/2014\/08\/using-corpora-in-class-simple-way.html?spref=tw",
      "display_url" : "how-i-see-it-now.blogspot.com\/2014\/08\/using-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "527780902521569280",
  "text" : "RT @Ven_VVE: Just finishing wk 3 on #corpusmooc &amp; SketchEngine tutorial reminded me of @hanaticha's post on using corpora in class http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hana Tich\u00E1",
        "screen_name" : "HanaTicha",
        "indices" : [ 78, 88 ],
        "id_str" : "512296705",
        "id" : 512296705
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpusmooc",
        "indices" : [ 23, 34 ]
      } ],
      "urls" : [ {
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/DdBBDCzhQ8",
        "expanded_url" : "http:\/\/how-i-see-it-now.blogspot.com\/2014\/08\/using-corpora-in-class-simple-way.html?spref=tw",
        "display_url" : "how-i-see-it-now.blogspot.com\/2014\/08\/using-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "527467582282952704",
    "text" : "Just finishing wk 3 on #corpusmooc &amp; SketchEngine tutorial reminded me of @hanaticha's post on using corpora in class http:\/\/t.co\/DdBBDCzhQ8",
    "id" : 527467582282952704,
    "created_at" : "2014-10-29 14:30:46 +0000",
    "user" : {
      "name" : "Vedrana Vojkovi\u0107",
      "screen_name" : "Ven_VVE",
      "protected" : false,
      "id_str" : "270839603",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/551061595602681856\/KylACR1R_normal.jpeg",
      "id" : 270839603,
      "verified" : false
    }
  },
  "id" : 527780902521569280,
  "created_at" : "2014-10-30 11:15:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Lewis",
      "screen_name" : "mark3141592",
      "indices" : [ 71, 83 ],
      "id_str" : "1289627816",
      "id" : 1289627816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/KKIET8haUP",
      "expanded_url" : "http:\/\/wp.me\/p3Amm5-91",
      "display_url" : "wp.me\/p3Amm5-91"
    } ]
  },
  "geo" : { },
  "id_str" : "527717929790345216",
  "text" : "The Politics and Paper Trail of Translation http:\/\/t.co\/KKIET8haUP via @mark3141592",
  "id" : 527717929790345216,
  "created_at" : "2014-10-30 07:05:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Levine",
      "screen_name" : "cogdog",
      "indices" : [ 3, 10 ],
      "id_str" : "740343",
      "id" : 740343
    }, {
      "name" : "Bill Fitzgerald",
      "screen_name" : "funnymonkey",
      "indices" : [ 118, 130 ],
      "id_str" : "12127972",
      "id" : 12127972
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ccourses",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/CXeqarrzqy",
      "expanded_url" : "http:\/\/projects.aljazeera.com\/2014\/terms-of-service\/",
      "display_url" : "projects.aljazeera.com\/2014\/terms-of-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "527561373568749571",
  "text" : "RT @cogdog: To be read soon \"Terms of Service\" -a graphic novel: us in a world of big data http:\/\/t.co\/CXeqarrzqy h\/t @funnymonkey #ccourses",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bill Fitzgerald",
        "screen_name" : "funnymonkey",
        "indices" : [ 106, 118 ],
        "id_str" : "12127972",
        "id" : 12127972
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ccourses",
        "indices" : [ 119, 128 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/CXeqarrzqy",
        "expanded_url" : "http:\/\/projects.aljazeera.com\/2014\/terms-of-service\/",
        "display_url" : "projects.aljazeera.com\/2014\/terms-of-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "527524877519953920",
    "text" : "To be read soon \"Terms of Service\" -a graphic novel: us in a world of big data http:\/\/t.co\/CXeqarrzqy h\/t @funnymonkey #ccourses",
    "id" : 527524877519953920,
    "created_at" : "2014-10-29 18:18:26 +0000",
    "user" : {
      "name" : "Alan Levine",
      "screen_name" : "cogdog",
      "protected" : false,
      "id_str" : "740343",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/740063389527859201\/BN9buLB9_normal.jpg",
      "id" : 740343,
      "verified" : false
    }
  },
  "id" : 527561373568749571,
  "created_at" : "2014-10-29 20:43:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kat Gupta",
      "screen_name" : "mixosaurus",
      "indices" : [ 0, 11 ],
      "id_str" : "21158543",
      "id" : 21158543
    }, {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "indices" : [ 12, 21 ],
      "id_str" : "167020390",
      "id" : 167020390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "527492045930524672",
  "geo" : { },
  "id_str" : "527548269074071552",
  "in_reply_to_user_id" : 21158543,
  "text" : "@mixosaurus @antlabjp ant hill, ant farm :)",
  "id" : 527548269074071552,
  "in_reply_to_status_id" : 527492045930524672,
  "created_at" : "2014-10-29 19:51:23 +0000",
  "in_reply_to_screen_name" : "mixosaurus",
  "in_reply_to_user_id_str" : "21158543",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "indices" : [ 3, 19 ],
      "id_str" : "1326508478",
      "id" : 1326508478
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "esrcfestival",
      "indices" : [ 40, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/aprjPdXiPh",
      "expanded_url" : "http:\/\/cass.lancs.ac.uk\/?p=1476",
      "display_url" : "cass.lancs.ac.uk\/?p=1476"
    } ]
  },
  "geo" : { },
  "id_str" : "527458827546161152",
  "text" : "RT @CorpusSocialSci: Want to attend our #esrcfestival event on 4 Nov but you're not near London? Good news: we're livestreaming it! http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "esrcfestival",
        "indices" : [ 19, 32 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/aprjPdXiPh",
        "expanded_url" : "http:\/\/cass.lancs.ac.uk\/?p=1476",
        "display_url" : "cass.lancs.ac.uk\/?p=1476"
      } ]
    },
    "geo" : { },
    "id_str" : "527455647374528512",
    "text" : "Want to attend our #esrcfestival event on 4 Nov but you're not near London? Good news: we're livestreaming it! http:\/\/t.co\/aprjPdXiPh",
    "id" : 527455647374528512,
    "created_at" : "2014-10-29 13:43:20 +0000",
    "user" : {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "protected" : false,
      "id_str" : "1326508478",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3493899777\/ced36fe15c32eb911cbe3d64377524dc_normal.jpeg",
      "id" : 1326508478,
      "verified" : false
    }
  },
  "id" : 527458827546161152,
  "created_at" : "2014-10-29 13:55:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marek Kiczkowiak",
      "screen_name" : "MarekKiczkowiak",
      "indices" : [ 0, 16 ],
      "id_str" : "2561325079",
      "id" : 2561325079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "527168373218877440",
  "geo" : { },
  "id_str" : "527205208917811200",
  "in_reply_to_user_id" : 2561325079,
  "text" : "@MarekKiczkowiak ok great, i guess only comment is length maybe too long?",
  "id" : 527205208917811200,
  "in_reply_to_status_id" : 527168373218877440,
  "created_at" : "2014-10-28 21:08:11 +0000",
  "in_reply_to_screen_name" : "MarekKiczkowiak",
  "in_reply_to_user_id_str" : "2561325079",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Cook",
      "screen_name" : "Jonathan_K_Cook",
      "indices" : [ 3, 19 ],
      "id_str" : "2459644405",
      "id" : 2459644405
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/rDTLhiKI3w",
      "expanded_url" : "http:\/\/shar.es\/10WCbs",
      "display_url" : "shar.es\/10WCbs"
    } ]
  },
  "geo" : { },
  "id_str" : "527168689389699072",
  "text" : "RT @Jonathan_K_Cook: The media's language disappears Palestinians as much as Israel's actions | Jonathan Cook's Blog http:\/\/t.co\/rDTLhiKI3w",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/rDTLhiKI3w",
        "expanded_url" : "http:\/\/shar.es\/10WCbs",
        "display_url" : "shar.es\/10WCbs"
      } ]
    },
    "geo" : { },
    "id_str" : "527134712431513600",
    "text" : "The media's language disappears Palestinians as much as Israel's actions | Jonathan Cook's Blog http:\/\/t.co\/rDTLhiKI3w",
    "id" : 527134712431513600,
    "created_at" : "2014-10-28 16:28:03 +0000",
    "user" : {
      "name" : "Jonathan Cook",
      "screen_name" : "Jonathan_K_Cook",
      "protected" : false,
      "id_str" : "2459644405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458948119749619713\/8ed1EDoY_normal.jpeg",
      "id" : 2459644405,
      "verified" : false
    }
  },
  "id" : 527168689389699072,
  "created_at" : "2014-10-28 18:43:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "indices" : [ 68, 83 ],
      "id_str" : "27716419",
      "id" : 27716419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/Q7BgsS9vsH",
      "expanded_url" : "http:\/\/www.craigmurray.org.uk\/archives\/2014\/10\/growth-poppies-corpses-and-serendipity\/",
      "display_url" : "craigmurray.org.uk\/archives\/2014\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "527119991347220480",
  "text" : "Growth, Poppies, Corpses and Serendipity http:\/\/t.co\/Q7BgsS9vsH via @CraigMurrayOrg",
  "id" : 527119991347220480,
  "created_at" : "2014-10-28 15:29:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marek Kiczkowiak",
      "screen_name" : "MarekKiczkowiak",
      "indices" : [ 0, 16 ],
      "id_str" : "2561325079",
      "id" : 2561325079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "527068187234697216",
  "geo" : { },
  "id_str" : "527069480049180673",
  "in_reply_to_user_id" : 2561325079,
  "text" : "@MarekKiczkowiak it doesn't play in Firefox 33.0, Chrome 38.0.2125.111 but works in Safari 7.1",
  "id" : 527069480049180673,
  "in_reply_to_status_id" : 527068187234697216,
  "created_at" : "2014-10-28 12:08:51 +0000",
  "in_reply_to_screen_name" : "MarekKiczkowiak",
  "in_reply_to_user_id_str" : "2561325079",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marek Kiczkowiak",
      "screen_name" : "MarekKiczkowiak",
      "indices" : [ 0, 16 ],
      "id_str" : "2561325079",
      "id" : 2561325079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "527025920494686209",
  "geo" : { },
  "id_str" : "527067719657869312",
  "in_reply_to_user_id" : 2561325079,
  "text" : "@MarekKiczkowiak hi podcast seems borked (can't play)?",
  "id" : 527067719657869312,
  "in_reply_to_status_id" : 527025920494686209,
  "created_at" : "2014-10-28 12:01:51 +0000",
  "in_reply_to_screen_name" : "MarekKiczkowiak",
  "in_reply_to_user_id_str" : "2561325079",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BuzzFeed",
      "screen_name" : "BuzzFeed",
      "indices" : [ 103, 112 ],
      "id_str" : "5695632",
      "id" : 5695632
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "buzztesol",
      "indices" : [ 113, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/Ug6wwisP0l",
      "expanded_url" : "http:\/\/www.buzzfeed.com\/awesomer\/what-would-the-buzzfeed-post-about-you-be-called",
      "display_url" : "buzzfeed.com\/awesomer\/what-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "527047979098591232",
  "text" : "54 Fiercely Uncanny Facts About TESOL That You Won\u2019t Believe Actually Exist http:\/\/t.co\/Ug6wwisP0l via @buzzfeed #buzztesol",
  "id" : 527047979098591232,
  "created_at" : "2014-10-28 10:43:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Thornbury",
      "screen_name" : "thornburyscott",
      "indices" : [ 0, 15 ],
      "id_str" : "23090474",
      "id" : 23090474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "527031254685077504",
  "geo" : { },
  "id_str" : "527036220355117056",
  "in_reply_to_user_id" : 23090474,
  "text" : "@thornburyscott thanks some very nice visualisations as well :)",
  "id" : 527036220355117056,
  "in_reply_to_status_id" : 527031254685077504,
  "created_at" : "2014-10-28 09:56:41 +0000",
  "in_reply_to_screen_name" : "thornburyscott",
  "in_reply_to_user_id_str" : "23090474",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hana Tich\u00E1",
      "screen_name" : "HanaTicha",
      "indices" : [ 3, 13 ],
      "id_str" : "512296705",
      "id" : 512296705
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/viFsR89PWJ",
      "expanded_url" : "http:\/\/malingual.blogspot.com\/2014\/10\/try-this-it-works-no1-practice-makes.html?spref=tw",
      "display_url" : "malingual.blogspot.com\/2014\/10\/try-th\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "527029699437150208",
  "text" : "RT @HanaTicha: Evidence Based EFL: Try this it works! No.1: Practice makes perfect. http:\/\/t.co\/viFsR89PWJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/viFsR89PWJ",
        "expanded_url" : "http:\/\/malingual.blogspot.com\/2014\/10\/try-this-it-works-no1-practice-makes.html?spref=tw",
        "display_url" : "malingual.blogspot.com\/2014\/10\/try-th\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "527020396415971328",
    "text" : "Evidence Based EFL: Try this it works! No.1: Practice makes perfect. http:\/\/t.co\/viFsR89PWJ",
    "id" : 527020396415971328,
    "created_at" : "2014-10-28 08:53:48 +0000",
    "user" : {
      "name" : "Hana Tich\u00E1",
      "screen_name" : "HanaTicha",
      "protected" : false,
      "id_str" : "512296705",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/699528253598494721\/HL9Np6Gu_normal.jpg",
      "id" : 512296705,
      "verified" : false
    }
  },
  "id" : 527029699437150208,
  "created_at" : "2014-10-28 09:30:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "526711103653310465",
  "geo" : { },
  "id_str" : "526771470383730688",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish student has access to colleague desktop so can copy over cdrom into mp3 but good to know can ask publishers",
  "id" : 526771470383730688,
  "in_reply_to_status_id" : 526711103653310465,
  "created_at" : "2014-10-27 16:24:40 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephanie McIntosh",
      "screen_name" : "purple_steph",
      "indices" : [ 3, 16 ],
      "id_str" : "18678010",
      "id" : 18678010
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "idioms",
      "indices" : [ 65, 72 ]
    }, {
      "text" : "esl",
      "indices" : [ 117, 121 ]
    }, {
      "text" : "efl",
      "indices" : [ 122, 126 ]
    }, {
      "text" : "elt",
      "indices" : [ 127, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/u6SpAAMPW9",
      "expanded_url" : "https:\/\/www.surveymonkey.com\/r\/V58ZQPS",
      "display_url" : "surveymonkey.com\/r\/V58ZQPS"
    } ]
  },
  "geo" : { },
  "id_str" : "526762268567281664",
  "text" : "RT @purple_steph: Take 2! Please can you complete this survey on #idioms (it's very short!). https:\/\/t.co\/u6SpAAMPW9 #esl #efl #elt  Please\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "idioms",
        "indices" : [ 47, 54 ]
      }, {
        "text" : "esl",
        "indices" : [ 99, 103 ]
      }, {
        "text" : "efl",
        "indices" : [ 104, 108 ]
      }, {
        "text" : "elt",
        "indices" : [ 109, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/u6SpAAMPW9",
        "expanded_url" : "https:\/\/www.surveymonkey.com\/r\/V58ZQPS",
        "display_url" : "surveymonkey.com\/r\/V58ZQPS"
      } ]
    },
    "geo" : { },
    "id_str" : "526712373907030016",
    "text" : "Take 2! Please can you complete this survey on #idioms (it's very short!). https:\/\/t.co\/u6SpAAMPW9 #esl #efl #elt  Please RT.",
    "id" : 526712373907030016,
    "created_at" : "2014-10-27 12:29:50 +0000",
    "user" : {
      "name" : "Stephanie McIntosh",
      "screen_name" : "purple_steph",
      "protected" : false,
      "id_str" : "18678010",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1869709851\/IMG_2933_-_square_normal.jpg",
      "id" : 18678010,
      "verified" : false
    }
  },
  "id" : 526762268567281664,
  "created_at" : "2014-10-27 15:48:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tea Horvatic",
      "screen_name" : "teahorvatic",
      "indices" : [ 3, 15 ],
      "id_str" : "533125583",
      "id" : 533125583
    }, {
      "name" : "Tea Horvatic",
      "screen_name" : "teahorvatic",
      "indices" : [ 54, 66 ],
      "id_str" : "533125583",
      "id" : 533125583
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusMOOC",
      "indices" : [ 67, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/O1FhH5UyIX",
      "expanded_url" : "http:\/\/wp.me\/p2uWUJ-7T",
      "display_url" : "wp.me\/p2uWUJ-7T"
    } ]
  },
  "geo" : { },
  "id_str" : "526761405262077953",
  "text" : "RT @teahorvatic: Corpus Linguistics Week 1 summary by @teahorvatic #corpusMOOC http:\/\/t.co\/O1FhH5UyIX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tea Horvatic",
        "screen_name" : "teahorvatic",
        "indices" : [ 37, 49 ],
        "id_str" : "533125583",
        "id" : 533125583
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpusMOOC",
        "indices" : [ 50, 61 ]
      } ],
      "urls" : [ {
        "indices" : [ 62, 84 ],
        "url" : "http:\/\/t.co\/O1FhH5UyIX",
        "expanded_url" : "http:\/\/wp.me\/p2uWUJ-7T",
        "display_url" : "wp.me\/p2uWUJ-7T"
      } ]
    },
    "geo" : { },
    "id_str" : "526738568702480384",
    "text" : "Corpus Linguistics Week 1 summary by @teahorvatic #corpusMOOC http:\/\/t.co\/O1FhH5UyIX",
    "id" : 526738568702480384,
    "created_at" : "2014-10-27 14:13:55 +0000",
    "user" : {
      "name" : "Tea Horvatic",
      "screen_name" : "teahorvatic",
      "protected" : false,
      "id_str" : "533125583",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2363766953\/qFdM59R9_normal",
      "id" : 533125583,
      "verified" : false
    }
  },
  "id" : 526761405262077953,
  "created_at" : "2014-10-27 15:44:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Claire Dembry",
      "screen_name" : "ClaireDembry",
      "indices" : [ 3, 16 ],
      "id_str" : "2396240628",
      "id" : 2396240628
    }, {
      "name" : "Festival of Ideas",
      "screen_name" : "camideasfest",
      "indices" : [ 63, 76 ],
      "id_str" : "48672881",
      "id" : 48672881
    }, {
      "name" : "Robbie Love",
      "screen_name" : "lovermob",
      "indices" : [ 91, 100 ],
      "id_str" : "19469715",
      "id" : 19469715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/A4bvAZcyl5",
      "expanded_url" : "http:\/\/goo.gl\/K7OhdJ",
      "display_url" : "goo.gl\/K7OhdJ"
    } ]
  },
  "geo" : { },
  "id_str" : "526761191725862913",
  "text" : "RT @ClaireDembry: In Cambridge on Thurs? Why not come along to @camideasfest to see me and @lovermob talk about spoken English! http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Festival of Ideas",
        "screen_name" : "camideasfest",
        "indices" : [ 45, 58 ],
        "id_str" : "48672881",
        "id" : 48672881
      }, {
        "name" : "Robbie Love",
        "screen_name" : "lovermob",
        "indices" : [ 73, 82 ],
        "id_str" : "19469715",
        "id" : 19469715
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/A4bvAZcyl5",
        "expanded_url" : "http:\/\/goo.gl\/K7OhdJ",
        "display_url" : "goo.gl\/K7OhdJ"
      } ]
    },
    "geo" : { },
    "id_str" : "526734086585745408",
    "text" : "In Cambridge on Thurs? Why not come along to @camideasfest to see me and @lovermob talk about spoken English! http:\/\/t.co\/A4bvAZcyl5",
    "id" : 526734086585745408,
    "created_at" : "2014-10-27 13:56:07 +0000",
    "user" : {
      "name" : "Claire Dembry",
      "screen_name" : "ClaireDembry",
      "protected" : true,
      "id_str" : "2396240628",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/478990308630601728\/6zc6XHld_normal.jpeg",
      "id" : 2396240628,
      "verified" : false
    }
  },
  "id" : 526761191725862913,
  "created_at" : "2014-10-27 15:43:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "526709189498773504",
  "geo" : { },
  "id_str" : "526710329825583104",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish i ordered a book (though not a newly released 1) for a student but student did not have cdplayer for cdrom in book",
  "id" : 526710329825583104,
  "in_reply_to_status_id" : 526709189498773504,
  "created_at" : "2014-10-27 12:21:43 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "526694471262818304",
  "text" : "wow new ELT books still come with cdroms :\/ who has cdrom players these days?",
  "id" : 526694471262818304,
  "created_at" : "2014-10-27 11:18:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "M.K",
      "screen_name" : "usage_based",
      "indices" : [ 3, 15 ],
      "id_str" : "1479290418",
      "id" : 1479290418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/wRzLtXI7jo",
      "expanded_url" : "https:\/\/www.academia.edu\/8954043\/A_Comparison_of_Linguistic_Features_in_the_Academic_Writing_of_Advanced_English_Language_Learner_and_English_First_Language_University_Students",
      "display_url" : "academia.edu\/8954043\/A_Comp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "526688702253522944",
  "text" : "RT @usage_based: A Comparison of Linguistic Features in the Academic Writing of Advanced English Language Learner and English ....\nhttps:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/wRzLtXI7jo",
        "expanded_url" : "https:\/\/www.academia.edu\/8954043\/A_Comparison_of_Linguistic_Features_in_the_Academic_Writing_of_Advanced_English_Language_Learner_and_English_First_Language_University_Students",
        "display_url" : "academia.edu\/8954043\/A_Comp\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "526574859732541441",
    "text" : "A Comparison of Linguistic Features in the Academic Writing of Advanced English Language Learner and English ....\nhttps:\/\/t.co\/wRzLtXI7jo",
    "id" : 526574859732541441,
    "created_at" : "2014-10-27 03:23:24 +0000",
    "user" : {
      "name" : "M.K",
      "screen_name" : "usage_based",
      "protected" : false,
      "id_str" : "1479290418",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/663653015962845184\/KI-fL-mX_normal.jpg",
      "id" : 1479290418,
      "verified" : false
    }
  },
  "id" : 526688702253522944,
  "created_at" : "2014-10-27 10:55:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yutaka Ishii (\u77F3\u4E95\u96C4\u9686)",
      "screen_name" : "yishii_0207",
      "indices" : [ 3, 15 ],
      "id_str" : "171376048",
      "id" : 171376048
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/dASQIOLuJE",
      "expanded_url" : "http:\/\/www.corpora.phil.spbu.ru\/",
      "display_url" : "corpora.phil.spbu.ru"
    } ]
  },
  "geo" : { },
  "id_str" : "526687996276670465",
  "text" : "RT @yishii_0207: 2015\u5E746\u670822\u65E5\u304B\u308926\u65E5\u307E\u3067International Conference CORPORA 2015\u304C\u30ED\u30B7\u30A2\u3067\u884C\u308F\u308C\u308B\u3068\u306E\u3053\u3068\u3002\u30A6\u30A7\u30D6\u30B5\u30A4\u30C8\u304C\u30ED\u30B7\u30A2\u8A9E\u3067\u8AAD\u3081\u306A\u3044\u3051\u308C\u3069\u3002\n\nhttp:\/\/t.co\/dASQIOLuJE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/dASQIOLuJE",
        "expanded_url" : "http:\/\/www.corpora.phil.spbu.ru\/",
        "display_url" : "corpora.phil.spbu.ru"
      } ]
    },
    "geo" : { },
    "id_str" : "526659099258146817",
    "text" : "2015\u5E746\u670822\u65E5\u304B\u308926\u65E5\u307E\u3067International Conference CORPORA 2015\u304C\u30ED\u30B7\u30A2\u3067\u884C\u308F\u308C\u308B\u3068\u306E\u3053\u3068\u3002\u30A6\u30A7\u30D6\u30B5\u30A4\u30C8\u304C\u30ED\u30B7\u30A2\u8A9E\u3067\u8AAD\u3081\u306A\u3044\u3051\u308C\u3069\u3002\n\nhttp:\/\/t.co\/dASQIOLuJE",
    "id" : 526659099258146817,
    "created_at" : "2014-10-27 08:58:08 +0000",
    "user" : {
      "name" : "Yutaka Ishii (\u77F3\u4E95\u96C4\u9686)",
      "screen_name" : "yishii_0207",
      "protected" : false,
      "id_str" : "171376048",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1333995742\/CIMG2225_normal.JPG",
      "id" : 171376048,
      "verified" : false
    }
  },
  "id" : 526687996276670465,
  "created_at" : "2014-10-27 10:52:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah KB",
      "screen_name" : "sarah_SKB",
      "indices" : [ 0, 10 ],
      "id_str" : "54518314",
      "id" : 54518314
    }, {
      "name" : "Clare",
      "screen_name" : "languageeteach",
      "indices" : [ 11, 26 ],
      "id_str" : "2163604968",
      "id" : 2163604968
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/DGOJhEuLyo",
      "expanded_url" : "https:\/\/plus.google.com\/u\/0\/communities\/101266284417587206243",
      "display_url" : "plus.google.com\/u\/0\/communitie\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "526639310003781632",
  "geo" : { },
  "id_str" : "526642534731485184",
  "in_reply_to_user_id" : 54518314,
  "text" : "@sarah_SKB @languageeteach hi u could also check the G+ Corpus Linguistics community for more of that good stuff https:\/\/t.co\/DGOJhEuLyo :)",
  "id" : 526642534731485184,
  "in_reply_to_status_id" : 526639310003781632,
  "created_at" : "2014-10-27 07:52:19 +0000",
  "in_reply_to_screen_name" : "sarah_SKB",
  "in_reply_to_user_id_str" : "54518314",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Compassionate Lang",
      "screen_name" : "compassionlang",
      "indices" : [ 3, 18 ],
      "id_str" : "2798247866",
      "id" : 2798247866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/dlLxytqTNe",
      "expanded_url" : "http:\/\/compassionatelanguage.wordpress.com\/2014\/10\/26\/the-genderqueer-language-learner-is-neither-nor\/",
      "display_url" : "compassionatelanguage.wordpress.com\/2014\/10\/26\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "526638620351139840",
  "text" : "RT @compassionlang: New post! The Genderqueer Language Learner is neither nor: http:\/\/t.co\/dlLxytqTNe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/dlLxytqTNe",
        "expanded_url" : "http:\/\/compassionatelanguage.wordpress.com\/2014\/10\/26\/the-genderqueer-language-learner-is-neither-nor\/",
        "display_url" : "compassionatelanguage.wordpress.com\/2014\/10\/26\/the\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "526495406113689601",
    "text" : "New post! The Genderqueer Language Learner is neither nor: http:\/\/t.co\/dlLxytqTNe",
    "id" : 526495406113689601,
    "created_at" : "2014-10-26 22:07:41 +0000",
    "user" : {
      "name" : "Compassionate Lang",
      "screen_name" : "compassionlang",
      "protected" : false,
      "id_str" : "2798247866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/509022276952395776\/16R-fRW8_normal.jpeg",
      "id" : 2798247866,
      "verified" : false
    }
  },
  "id" : 526638620351139840,
  "created_at" : "2014-10-27 07:36:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jukka Tyrkk\u00F6",
      "screen_name" : "JukkaTee",
      "indices" : [ 0, 9 ],
      "id_str" : "375603578",
      "id" : 375603578
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 41, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/5WBJqlK0Ws",
      "expanded_url" : "https:\/\/googledrive.com\/host\/0B7FW2BYaBgeiczNDWTJpZFoyVkE\/search-regex-corpusmooc.mp3",
      "display_url" : "googledrive.com\/host\/0B7FW2BYa\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "526605096839573505",
  "geo" : { },
  "id_str" : "526634731023396864",
  "in_reply_to_user_id" : 375603578,
  "text" : "@JukkaTee indeed it is hard to stop that #corpusmooc beat https:\/\/t.co\/5WBJqlK0Ws :)",
  "id" : 526634731023396864,
  "in_reply_to_status_id" : 526605096839573505,
  "created_at" : "2014-10-27 07:21:18 +0000",
  "in_reply_to_screen_name" : "JukkaTee",
  "in_reply_to_user_id_str" : "375603578",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah KB",
      "screen_name" : "sarah_SKB",
      "indices" : [ 3, 13 ],
      "id_str" : "54518314",
      "id" : 54518314
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "efl",
      "indices" : [ 90, 94 ]
    }, {
      "text" : "elt",
      "indices" : [ 95, 99 ]
    }, {
      "text" : "esl",
      "indices" : [ 100, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/ySvMvLyTm7",
      "expanded_url" : "http:\/\/bit.ly\/1ttdDZl",
      "display_url" : "bit.ly\/1ttdDZl"
    } ]
  },
  "geo" : { },
  "id_str" : "526464182183796737",
  "text" : "RT @sarah_SKB: Integrating corpora with everyday language teaching http:\/\/t.co\/ySvMvLyTm7 #efl #elt #esl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "efl",
        "indices" : [ 75, 79 ]
      }, {
        "text" : "elt",
        "indices" : [ 80, 84 ]
      }, {
        "text" : "esl",
        "indices" : [ 85, 89 ]
      } ],
      "urls" : [ {
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/ySvMvLyTm7",
        "expanded_url" : "http:\/\/bit.ly\/1ttdDZl",
        "display_url" : "bit.ly\/1ttdDZl"
      } ]
    },
    "geo" : { },
    "id_str" : "526462673719164929",
    "text" : "Integrating corpora with everyday language teaching http:\/\/t.co\/ySvMvLyTm7 #efl #elt #esl",
    "id" : 526462673719164929,
    "created_at" : "2014-10-26 19:57:37 +0000",
    "user" : {
      "name" : "Sarah KB",
      "screen_name" : "sarah_SKB",
      "protected" : false,
      "id_str" : "54518314",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/588366145771675649\/KkEbcMKN_normal.jpg",
      "id" : 54518314,
      "verified" : false
    }
  },
  "id" : 526464182183796737,
  "created_at" : "2014-10-26 20:03:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evgeny Morozov",
      "screen_name" : "evgenymorozov",
      "indices" : [ 3, 17 ],
      "id_str" : "30331417",
      "id" : 30331417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/hqIfleYXgq",
      "expanded_url" : "http:\/\/www.theguardian.com\/commentisfree\/2014\/oct\/25\/darker-side-pay-per-laugh-innovations-silicon-valley",
      "display_url" : "theguardian.com\/commentisfree\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "526422768045527040",
  "text" : "RT @evgenymorozov: My latest: \"When Wall Street and Silicon Valley come together\" http:\/\/t.co\/hqIfleYXgq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/hqIfleYXgq",
        "expanded_url" : "http:\/\/www.theguardian.com\/commentisfree\/2014\/oct\/25\/darker-side-pay-per-laugh-innovations-silicon-valley",
        "display_url" : "theguardian.com\/commentisfree\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "526282296241164288",
    "text" : "My latest: \"When Wall Street and Silicon Valley come together\" http:\/\/t.co\/hqIfleYXgq",
    "id" : 526282296241164288,
    "created_at" : "2014-10-26 08:00:51 +0000",
    "user" : {
      "name" : "Evgeny Morozov",
      "screen_name" : "evgenymorozov",
      "protected" : false,
      "id_str" : "30331417",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/640536915477794816\/u9TxNsKI_normal.jpg",
      "id" : 30331417,
      "verified" : false
    }
  },
  "id" : 526422768045527040,
  "created_at" : "2014-10-26 17:19:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 110, 126 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/9G7XBv7BZs",
      "expanded_url" : "http:\/\/wp.me\/p21lsm-YT",
      "display_url" : "wp.me\/p21lsm-YT"
    } ]
  },
  "geo" : { },
  "id_str" : "526386640587984897",
  "text" : "My experiences teaching a listening course. A generic listening plan and some tips http:\/\/t.co\/9G7XBv7BZs via @wordpressdotcom",
  "id" : 526386640587984897,
  "created_at" : "2014-10-26 14:55:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tea Horvatic",
      "screen_name" : "teahorvatic",
      "indices" : [ 3, 15 ],
      "id_str" : "533125583",
      "id" : 533125583
    }, {
      "name" : "Tea Horvatic",
      "screen_name" : "teahorvatic",
      "indices" : [ 86, 98 ],
      "id_str" : "533125583",
      "id" : 533125583
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusMOOC",
      "indices" : [ 99, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/FtL6DAfNAi",
      "expanded_url" : "http:\/\/wp.me\/p2uWUJ-7P",
      "display_url" : "wp.me\/p2uWUJ-7P"
    } ]
  },
  "geo" : { },
  "id_str" : "526357704324165632",
  "text" : "RT @teahorvatic: Corpus Lingustics: Week 1, activity 1.12: http:\/\/t.co\/FtL6DAfNAi via @teahorvatic #corpusMOOC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tea Horvatic",
        "screen_name" : "teahorvatic",
        "indices" : [ 69, 81 ],
        "id_str" : "533125583",
        "id" : 533125583
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpusMOOC",
        "indices" : [ 82, 93 ]
      } ],
      "urls" : [ {
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/FtL6DAfNAi",
        "expanded_url" : "http:\/\/wp.me\/p2uWUJ-7P",
        "display_url" : "wp.me\/p2uWUJ-7P"
      } ]
    },
    "geo" : { },
    "id_str" : "526304820341112837",
    "text" : "Corpus Lingustics: Week 1, activity 1.12: http:\/\/t.co\/FtL6DAfNAi via @teahorvatic #corpusMOOC",
    "id" : 526304820341112837,
    "created_at" : "2014-10-26 09:30:22 +0000",
    "user" : {
      "name" : "Tea Horvatic",
      "screen_name" : "teahorvatic",
      "protected" : false,
      "id_str" : "533125583",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2363766953\/qFdM59R9_normal",
      "id" : 533125583,
      "verified" : false
    }
  },
  "id" : 526357704324165632,
  "created_at" : "2014-10-26 13:00:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bella Caledonia",
      "screen_name" : "bellacaledonia",
      "indices" : [ 79, 94 ],
      "id_str" : "103554348",
      "id" : 103554348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/JrSrTPzTNB",
      "expanded_url" : "http:\/\/wp.me\/p93oK-4sZ",
      "display_url" : "wp.me\/p93oK-4sZ"
    } ]
  },
  "geo" : { },
  "id_str" : "526351835779432449",
  "text" : "BBC Round 2: It Turns Out Peston Missed Out the Oil http:\/\/t.co\/JrSrTPzTNB via @bellacaledonia",
  "id" : 526351835779432449,
  "created_at" : "2014-10-26 12:37:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 28, 39 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/BrEL7AhJzk",
      "expanded_url" : "http:\/\/www.lknol.com\/Docs\/booklet.pdf",
      "display_url" : "lknol.com\/Docs\/booklet.p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "526345916304084992",
  "text" : "useful booklet to accompany #corpusmooc how to build a corpus optional videos http:\/\/t.co\/BrEL7AhJzk",
  "id" : 526345916304084992,
  "created_at" : "2014-10-26 12:13:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anne Hodgson",
      "screen_name" : "annehodg",
      "indices" : [ 0, 9 ],
      "id_str" : "17589213",
      "id" : 17589213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "526317957706547201",
  "geo" : { },
  "id_str" : "526319363214049280",
  "in_reply_to_user_id" : 17589213,
  "text" : "@annehodg congratulations Anne! :)",
  "id" : 526319363214049280,
  "in_reply_to_status_id" : 526317957706547201,
  "created_at" : "2014-10-26 10:28:09 +0000",
  "in_reply_to_screen_name" : "annehodg",
  "in_reply_to_user_id_str" : "17589213",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Cook",
      "screen_name" : "Jonathan_K_Cook",
      "indices" : [ 3, 19 ],
      "id_str" : "2459644405",
      "id" : 2459644405
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/6yYcMdPeP4",
      "expanded_url" : "http:\/\/shar.es\/10nuAF",
      "display_url" : "shar.es\/10nuAF"
    } ]
  },
  "geo" : { },
  "id_str" : "526313834995515392",
  "text" : "RT @Jonathan_K_Cook: Russell Brand's critics are asking the wrong question - mainly about their next iPhone \/ Jonathan Cook's Blog http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/6yYcMdPeP4",
        "expanded_url" : "http:\/\/shar.es\/10nuAF",
        "display_url" : "shar.es\/10nuAF"
      } ]
    },
    "geo" : { },
    "id_str" : "525924195486539776",
    "text" : "Russell Brand's critics are asking the wrong question - mainly about their next iPhone \/ Jonathan Cook's Blog http:\/\/t.co\/6yYcMdPeP4 via",
    "id" : 525924195486539776,
    "created_at" : "2014-10-25 08:17:54 +0000",
    "user" : {
      "name" : "Jonathan Cook",
      "screen_name" : "Jonathan_K_Cook",
      "protected" : false,
      "id_str" : "2459644405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458948119749619713\/8ed1EDoY_normal.jpeg",
      "id" : 2459644405,
      "verified" : false
    }
  },
  "id" : 526313834995515392,
  "created_at" : "2014-10-26 10:06:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "umasslinguistics",
      "screen_name" : "umasslinguistic",
      "indices" : [ 0, 16 ],
      "id_str" : "149239362",
      "id" : 149239362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/xscFBIGDm2",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Mat_%28Russian_profanity%29#cite_note-1",
      "display_url" : "en.wikipedia.org\/wiki\/Mat_%28Ru\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "526141244666544128",
  "geo" : { },
  "id_str" : "526148835996102656",
  "in_reply_to_user_id" : 149239362,
  "text" : "@umasslinguistic mat has been banned since 2003 http:\/\/t.co\/xscFBIGDm2",
  "id" : 526148835996102656,
  "in_reply_to_status_id" : 526141244666544128,
  "created_at" : "2014-10-25 23:10:32 +0000",
  "in_reply_to_screen_name" : "umasslinguistic",
  "in_reply_to_user_id_str" : "149239362",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Groom",
      "screen_name" : "jimgroom",
      "indices" : [ 0, 9 ],
      "id_str" : "3362981",
      "id" : 3362981
    }, {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 10, 20 ],
      "id_str" : "525274103",
      "id" : 525274103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "526111031303872512",
  "geo" : { },
  "id_str" : "526137182038532097",
  "in_reply_to_user_id" : 3362981,
  "text" : "@jimgroom @ElkySmith time seems to be doing a fine trade in teacher trolling :\/",
  "id" : 526137182038532097,
  "in_reply_to_status_id" : 526111031303872512,
  "created_at" : "2014-10-25 22:24:14 +0000",
  "in_reply_to_screen_name" : "jimgroom",
  "in_reply_to_user_id_str" : "3362981",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sachka Sandra Duval",
      "screen_name" : "RadioSachka",
      "indices" : [ 3, 15 ],
      "id_str" : "103894420",
      "id" : 103894420
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/RadioSachka\/status\/525713595922128896\/photo\/1",
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/pxMcXqhcrO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0u1ulDIIAEqpSs.png",
      "id_str" : "525713593342631937",
      "id" : 525713593342631937,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0u1ulDIIAEqpSs.png",
      "sizes" : [ {
        "h" : 820,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 873,
        "resize" : "fit",
        "w" : 639
      }, {
        "h" : 465,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 873,
        "resize" : "fit",
        "w" : 639
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/pxMcXqhcrO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "525950427548758017",
  "text" : "RT @RadioSachka: Hahaha this one is perfect http:\/\/t.co\/pxMcXqhcrO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/RadioSachka\/status\/525713595922128896\/photo\/1",
        "indices" : [ 27, 49 ],
        "url" : "http:\/\/t.co\/pxMcXqhcrO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B0u1ulDIIAEqpSs.png",
        "id_str" : "525713593342631937",
        "id" : 525713593342631937,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0u1ulDIIAEqpSs.png",
        "sizes" : [ {
          "h" : 820,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 873,
          "resize" : "fit",
          "w" : 639
        }, {
          "h" : 465,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 873,
          "resize" : "fit",
          "w" : 639
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/pxMcXqhcrO"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "525713595922128896",
    "text" : "Hahaha this one is perfect http:\/\/t.co\/pxMcXqhcrO",
    "id" : 525713595922128896,
    "created_at" : "2014-10-24 18:21:03 +0000",
    "user" : {
      "name" : "Sachka Sandra Duval",
      "screen_name" : "RadioSachka",
      "protected" : false,
      "id_str" : "103894420",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/522144327447752705\/VlMCGzvl_normal.jpeg",
      "id" : 103894420,
      "verified" : false
    }
  },
  "id" : 525950427548758017,
  "created_at" : "2014-10-25 10:02:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Raine",
      "screen_name" : "paul_sensei",
      "indices" : [ 0, 12 ],
      "id_str" : "176429301",
      "id" : 176429301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525840965848674304",
  "geo" : { },
  "id_str" : "525938239102672896",
  "in_reply_to_user_id" : 176429301,
  "text" : "@paul_sensei great thank you for a great tool :)",
  "id" : 525938239102672896,
  "in_reply_to_status_id" : 525840965848674304,
  "created_at" : "2014-10-25 09:13:42 +0000",
  "in_reply_to_screen_name" : "paul_sensei",
  "in_reply_to_user_id_str" : "176429301",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AllThingsLinguistic",
      "screen_name" : "AllThingsLing",
      "indices" : [ 3, 17 ],
      "id_str" : "857291268",
      "id" : 857291268
    }, {
      "name" : "Daniel Ginsberg",
      "screen_name" : "NemaVeze",
      "indices" : [ 116, 125 ],
      "id_str" : "15678875",
      "id" : 15678875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 127, 140 ],
      "url" : "http:\/\/t.co\/zVEtT9ypg8",
      "expanded_url" : "http:\/\/tmblr.co\/ZuWOEv1Txozck",
      "display_url" : "tmblr.co\/ZuWOEv1Txozck"
    } ]
  },
  "geo" : { },
  "id_str" : "525923907333681152",
  "text" : "RT @AllThingsLing: Looking Beyond English: Linguistic Inquiry for English Language Learners -Interesting paper from @NemaVeze\u2026 http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Daniel Ginsberg",
        "screen_name" : "NemaVeze",
        "indices" : [ 97, 106 ],
        "id_str" : "15678875",
        "id" : 15678875
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/zVEtT9ypg8",
        "expanded_url" : "http:\/\/tmblr.co\/ZuWOEv1Txozck",
        "display_url" : "tmblr.co\/ZuWOEv1Txozck"
      } ]
    },
    "geo" : { },
    "id_str" : "525776373613617152",
    "text" : "Looking Beyond English: Linguistic Inquiry for English Language Learners -Interesting paper from @NemaVeze\u2026 http:\/\/t.co\/zVEtT9ypg8",
    "id" : 525776373613617152,
    "created_at" : "2014-10-24 22:30:30 +0000",
    "user" : {
      "name" : "AllThingsLinguistic",
      "screen_name" : "AllThingsLing",
      "protected" : false,
      "id_str" : "857291268",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750400997206454273\/N0DmrmFi_normal.jpg",
      "id" : 857291268,
      "verified" : false
    }
  },
  "id" : 525923907333681152,
  "created_at" : "2014-10-25 08:16:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/x3mktPaLPB",
      "expanded_url" : "http:\/\/bit.ly\/1wwOe0x",
      "display_url" : "bit.ly\/1wwOe0x"
    } ]
  },
  "geo" : { },
  "id_str" : "525757331754086401",
  "text" : "Roxanne Dunbar-Ortiz: An Indigenous People's History of the United States (1\/3) http:\/\/t.co\/x3mktPaLPB",
  "id" : 525757331754086401,
  "created_at" : "2014-10-24 21:14:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Kern\u24C4h\u24B6n",
      "screen_name" : "dkernohan",
      "indices" : [ 3, 13 ],
      "id_str" : "12219232",
      "id" : 12219232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/Rt6kcTvpav",
      "expanded_url" : "http:\/\/ec.europa.eu\/budget\/mff\/resources\/index_en.cfm",
      "display_url" : "ec.europa.eu\/budget\/mff\/res\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "525709505263591424",
  "text" : "RT @dkernohan: Wonder if David Cameron has ever properly read this: http:\/\/t.co\/Rt6kcTvpav - he wouldn't be acting so surprised if he had.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 75 ],
        "url" : "http:\/\/t.co\/Rt6kcTvpav",
        "expanded_url" : "http:\/\/ec.europa.eu\/budget\/mff\/resources\/index_en.cfm",
        "display_url" : "ec.europa.eu\/budget\/mff\/res\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "525709051481837571",
    "text" : "Wonder if David Cameron has ever properly read this: http:\/\/t.co\/Rt6kcTvpav - he wouldn't be acting so surprised if he had.",
    "id" : 525709051481837571,
    "created_at" : "2014-10-24 18:02:59 +0000",
    "user" : {
      "name" : "David Kern\u24C4h\u24B6n",
      "screen_name" : "dkernohan",
      "protected" : false,
      "id_str" : "12219232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/757702202437804032\/4Xrm7IIe_normal.jpg",
      "id" : 12219232,
      "verified" : false
    }
  },
  "id" : 525709505263591424,
  "created_at" : "2014-10-24 18:04:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pitchfork",
      "screen_name" : "pitchfork",
      "indices" : [ 3, 13 ],
      "id_str" : "14089195",
      "id" : 14089195
    }, {
      "name" : "Follow @KillerMike",
      "screen_name" : "killermikegto",
      "indices" : [ 37, 51 ],
      "id_str" : "3301913202",
      "id" : 3301913202
    }, {
      "name" : "el-p",
      "screen_name" : "therealelp",
      "indices" : [ 63, 74 ],
      "id_str" : "20922014",
      "id" : 20922014
    }, {
      "name" : "Run The Jewels",
      "screen_name" : "runjewels",
      "indices" : [ 82, 92 ],
      "id_str" : "2252616702",
      "id" : 2252616702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 123, 140 ],
      "url" : "http:\/\/t.co\/fxRrRrU5VT",
      "expanded_url" : "http:\/\/p4k.in\/1vXfiWZ",
      "display_url" : "p4k.in\/1vXfiWZ"
    } ]
  },
  "geo" : { },
  "id_str" : "525708773294624768",
  "text" : "RT @pitchfork: Download Killer Mike (@KillerMikeGTO) and El-P (@therealelp)'s new @runjewels album RTJ2 for free right now http:\/\/t.co\/fxRr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Follow @KillerMike",
        "screen_name" : "killermikegto",
        "indices" : [ 22, 36 ],
        "id_str" : "3301913202",
        "id" : 3301913202
      }, {
        "name" : "el-p",
        "screen_name" : "therealelp",
        "indices" : [ 48, 59 ],
        "id_str" : "20922014",
        "id" : 20922014
      }, {
        "name" : "Run The Jewels",
        "screen_name" : "runjewels",
        "indices" : [ 67, 77 ],
        "id_str" : "2252616702",
        "id" : 2252616702
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/fxRrRrU5VT",
        "expanded_url" : "http:\/\/p4k.in\/1vXfiWZ",
        "display_url" : "p4k.in\/1vXfiWZ"
      } ]
    },
    "geo" : { },
    "id_str" : "525637591509794816",
    "text" : "Download Killer Mike (@KillerMikeGTO) and El-P (@therealelp)'s new @runjewels album RTJ2 for free right now http:\/\/t.co\/fxRrRrU5VT",
    "id" : 525637591509794816,
    "created_at" : "2014-10-24 13:19:02 +0000",
    "user" : {
      "name" : "Pitchfork",
      "screen_name" : "pitchfork",
      "protected" : false,
      "id_str" : "14089195",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615703473678585856\/6DxJO5o0_normal.jpg",
      "id" : 14089195,
      "verified" : true
    }
  },
  "id" : 525708773294624768,
  "created_at" : "2014-10-24 18:01:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 81, 96 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/dAakZv3M0g",
      "expanded_url" : "http:\/\/wp.me\/p3qkCB-101",
      "display_url" : "wp.me\/p3qkCB-101"
    } ]
  },
  "geo" : { },
  "id_str" : "525707824307773441",
  "text" : "A Closer Look at Task-Based Language Teaching  Part 2 http:\/\/t.co\/dAakZv3M0g via @GeoffreyJordan",
  "id" : 525707824307773441,
  "created_at" : "2014-10-24 17:58:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Moravec",
      "screen_name" : "ProfessMoravec",
      "indices" : [ 0, 15 ],
      "id_str" : "369529173",
      "id" : 369529173
    }, {
      "name" : "Open Knowledge Intl",
      "screen_name" : "OKFN",
      "indices" : [ 16, 21 ],
      "id_str" : "16143105",
      "id" : 16143105
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525706800885010432",
  "geo" : { },
  "id_str" : "525706974881918977",
  "in_reply_to_user_id" : 369529173,
  "text" : "@ProfessMoravec @OKFN is it the same issue?",
  "id" : 525706974881918977,
  "in_reply_to_status_id" : 525706800885010432,
  "created_at" : "2014-10-24 17:54:44 +0000",
  "in_reply_to_screen_name" : "ProfessMoravec",
  "in_reply_to_user_id_str" : "369529173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Moravec",
      "screen_name" : "ProfessMoravec",
      "indices" : [ 0, 15 ],
      "id_str" : "369529173",
      "id" : 369529173
    }, {
      "name" : "Open Knowledge Intl",
      "screen_name" : "OKFN",
      "indices" : [ 16, 21 ],
      "id_str" : "16143105",
      "id" : 16143105
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/rR8jFgh2hS",
      "expanded_url" : "https:\/\/github.com\/okfn\/timemapper\/issues",
      "display_url" : "github.com\/okfn\/timemappe\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "525705518380097536",
  "geo" : { },
  "id_str" : "525706543321579520",
  "in_reply_to_user_id" : 369529173,
  "text" : "@ProfessMoravec @OKFN maybe open issue here if not already there https:\/\/t.co\/rR8jFgh2hS ?",
  "id" : 525706543321579520,
  "in_reply_to_status_id" : 525705518380097536,
  "created_at" : "2014-10-24 17:53:01 +0000",
  "in_reply_to_screen_name" : "ProfessMoravec",
  "in_reply_to_user_id_str" : "369529173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Moravec",
      "screen_name" : "ProfessMoravec",
      "indices" : [ 0, 15 ],
      "id_str" : "369529173",
      "id" : 369529173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525704724650000384",
  "geo" : { },
  "id_str" : "525705334019878912",
  "in_reply_to_user_id" : 369529173,
  "text" : "@ProfessMoravec ah yes must be to do with google drive changes my old one works not tried any new ones",
  "id" : 525705334019878912,
  "in_reply_to_status_id" : 525704724650000384,
  "created_at" : "2014-10-24 17:48:13 +0000",
  "in_reply_to_screen_name" : "ProfessMoravec",
  "in_reply_to_user_id_str" : "369529173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Moravec",
      "screen_name" : "ProfessMoravec",
      "indices" : [ 0, 15 ],
      "id_str" : "369529173",
      "id" : 369529173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525703080436711426",
  "geo" : { },
  "id_str" : "525704536183562240",
  "in_reply_to_user_id" : 369529173,
  "text" : "@ProfessMoravec you can see on timemapper? you just can't update it is that it?",
  "id" : 525704536183562240,
  "in_reply_to_status_id" : 525703080436711426,
  "created_at" : "2014-10-24 17:45:03 +0000",
  "in_reply_to_screen_name" : "ProfessMoravec",
  "in_reply_to_user_id_str" : "369529173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Moravec",
      "screen_name" : "ProfessMoravec",
      "indices" : [ 0, 15 ],
      "id_str" : "369529173",
      "id" : 369529173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525702080116183040",
  "geo" : { },
  "id_str" : "525702318982168576",
  "in_reply_to_user_id" : 369529173,
  "text" : "@ProfessMoravec can u send me a link to one of your timemappers to check?",
  "id" : 525702318982168576,
  "in_reply_to_status_id" : 525702080116183040,
  "created_at" : "2014-10-24 17:36:14 +0000",
  "in_reply_to_screen_name" : "ProfessMoravec",
  "in_reply_to_user_id_str" : "369529173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Moravec",
      "screen_name" : "ProfessMoravec",
      "indices" : [ 0, 15 ],
      "id_str" : "369529173",
      "id" : 369529173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525701514430402560",
  "geo" : { },
  "id_str" : "525701991314751488",
  "in_reply_to_user_id" : 369529173,
  "text" : "@ProfessMoravec hmm maybe something related to way the chocolate factory changed drive recently?",
  "id" : 525701991314751488,
  "in_reply_to_status_id" : 525701514430402560,
  "created_at" : "2014-10-24 17:34:56 +0000",
  "in_reply_to_screen_name" : "ProfessMoravec",
  "in_reply_to_user_id_str" : "369529173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheLanguagePoint",
      "screen_name" : "Marie_Sanako",
      "indices" : [ 0, 13 ],
      "id_str" : "356176087",
      "id" : 356176087
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525690809342251008",
  "geo" : { },
  "id_str" : "525701579002118146",
  "in_reply_to_user_id" : 356176087,
  "text" : "@Marie_Sanako appreciate the share Marie, here's to a good w\/e :)",
  "id" : 525701579002118146,
  "in_reply_to_status_id" : 525690809342251008,
  "created_at" : "2014-10-24 17:33:18 +0000",
  "in_reply_to_screen_name" : "Marie_Sanako",
  "in_reply_to_user_id_str" : "356176087",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Moravec",
      "screen_name" : "ProfessMoravec",
      "indices" : [ 0, 15 ],
      "id_str" : "369529173",
      "id" : 369529173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525700429783384065",
  "geo" : { },
  "id_str" : "525701386273816576",
  "in_reply_to_user_id" : 369529173,
  "text" : "@ProfessMoravec hi  is working for me",
  "id" : 525701386273816576,
  "in_reply_to_status_id" : 525700429783384065,
  "created_at" : "2014-10-24 17:32:32 +0000",
  "in_reply_to_screen_name" : "ProfessMoravec",
  "in_reply_to_user_id_str" : "369529173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Occupy London",
      "screen_name" : "OccupyLondon",
      "indices" : [ 3, 16 ],
      "id_str" : "379481082",
      "id" : 379481082
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "occupydemocracy",
      "indices" : [ 110, 126 ]
    }, {
      "text" : "olsx",
      "indices" : [ 128, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/JKSE2AFj17",
      "expanded_url" : "http:\/\/occupydemocracy.org.uk\/712-2\/",
      "display_url" : "occupydemocracy.org.uk\/712-2\/"
    } ]
  },
  "geo" : { },
  "id_str" : "525665681380241408",
  "text" : "RT @OccupyLondon: We've compiled some of the many videos that are coming through of speakers, arrests, etc at #occupydemocracy  #olsx http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.GroupTweet.com\" rel=\"nofollow\"\u003EGroupTweet\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "occupydemocracy",
        "indices" : [ 92, 108 ]
      }, {
        "text" : "olsx",
        "indices" : [ 110, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/JKSE2AFj17",
        "expanded_url" : "http:\/\/occupydemocracy.org.uk\/712-2\/",
        "display_url" : "occupydemocracy.org.uk\/712-2\/"
      } ]
    },
    "geo" : { },
    "id_str" : "525648332216369152",
    "text" : "We've compiled some of the many videos that are coming through of speakers, arrests, etc at #occupydemocracy  #olsx http:\/\/t.co\/JKSE2AFj17",
    "id" : 525648332216369152,
    "created_at" : "2014-10-24 14:01:43 +0000",
    "user" : {
      "name" : "Occupy London",
      "screen_name" : "OccupyLondon",
      "protected" : false,
      "id_str" : "379481082",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2220521926\/occupy_london_sq_white_col_normal.jpg",
      "id" : 379481082,
      "verified" : false
    }
  },
  "id" : 525665681380241408,
  "created_at" : "2014-10-24 15:10:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MarisaConstantinides",
      "screen_name" : "Marisa_C",
      "indices" : [ 0, 9 ],
      "id_str" : "18272500",
      "id" : 18272500
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525654985112305665",
  "geo" : { },
  "id_str" : "525660145486143489",
  "in_reply_to_user_id" : 18272500,
  "text" : "@Marisa_C thanks for sharing Marisa :) have a good w\/e",
  "id" : 525660145486143489,
  "in_reply_to_status_id" : 525654985112305665,
  "created_at" : "2014-10-24 14:48:39 +0000",
  "in_reply_to_screen_name" : "Marisa_C",
  "in_reply_to_user_id_str" : "18272500",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 86, 94 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/ykpZKgQoFn",
      "expanded_url" : "http:\/\/youtu.be\/ALEaAAU3KAE",
      "display_url" : "youtu.be\/ALEaAAU3KAE"
    } ]
  },
  "geo" : { },
  "id_str" : "525659942108143617",
  "text" : "Ottawa Killings: Who Wins? Russell Brand The Trews (E174): http:\/\/t.co\/ykpZKgQoFn via @YouTube",
  "id" : 525659942108143617,
  "created_at" : "2014-10-24 14:47:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Raine",
      "screen_name" : "paul_sensei",
      "indices" : [ 0, 12 ],
      "id_str" : "176429301",
      "id" : 176429301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525624757358563328",
  "geo" : { },
  "id_str" : "525625148456841217",
  "in_reply_to_user_id" : 176429301,
  "text" : "@paul_sensei no error message, the play button appeared but it would not play audio",
  "id" : 525625148456841217,
  "in_reply_to_status_id" : 525624757358563328,
  "created_at" : "2014-10-24 12:29:35 +0000",
  "in_reply_to_screen_name" : "paul_sensei",
  "in_reply_to_user_id_str" : "176429301",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 19, 27 ]
    }, {
      "text" : "efl",
      "indices" : [ 28, 32 ]
    }, {
      "text" : "elt",
      "indices" : [ 33, 37 ]
    }, {
      "text" : "tefl",
      "indices" : [ 38, 43 ]
    }, {
      "text" : "esl",
      "indices" : [ 44, 48 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/Ups92AxSqU",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-Pv",
      "display_url" : "wp.me\/pgHyE-Pv"
    } ]
  },
  "geo" : { },
  "id_str" : "525622757141127168",
  "text" : "Videotelling notes #eltchat #efl #elt #tefl #esl http:\/\/t.co\/Ups92AxSqU",
  "id" : 525622757141127168,
  "created_at" : "2014-10-24 12:20:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Raine",
      "screen_name" : "paul_sensei",
      "indices" : [ 0, 12 ],
      "id_str" : "176429301",
      "id" : 176429301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "525506266480005120",
  "in_reply_to_user_id" : 176429301,
  "text" : "@paul_sensei though French misalignment sentence 14\/16",
  "id" : 525506266480005120,
  "created_at" : "2014-10-24 04:37:12 +0000",
  "in_reply_to_screen_name" : "paul_sensei",
  "in_reply_to_user_id_str" : "176429301",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Raine",
      "screen_name" : "paul_sensei",
      "indices" : [ 0, 12 ],
      "id_str" : "176429301",
      "id" : 176429301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "525505554685648896",
  "in_reply_to_user_id" : 176429301,
  "text" : "@paul_sensei another misalignment though French sentence 4\/16",
  "id" : 525505554685648896,
  "created_at" : "2014-10-24 04:34:22 +0000",
  "in_reply_to_screen_name" : "paul_sensei",
  "in_reply_to_user_id_str" : "176429301",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Raine",
      "screen_name" : "paul_sensei",
      "indices" : [ 0, 12 ],
      "id_str" : "176429301",
      "id" : 176429301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "525505306747748352",
  "in_reply_to_user_id" : 176429301,
  "text" : "@paul_sensei there is a misalignment in French using English 'though' sentence 3\/16",
  "id" : 525505306747748352,
  "created_at" : "2014-10-24 04:33:23 +0000",
  "in_reply_to_screen_name" : "paul_sensei",
  "in_reply_to_user_id_str" : "176429301",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Raine",
      "screen_name" : "paul_sensei",
      "indices" : [ 0, 12 ],
      "id_str" : "176429301",
      "id" : 176429301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "525504101074075648",
  "in_reply_to_user_id" : 176429301,
  "text" : "@paul_sensei hi my student used sentencebuilder liked it a lot though audio would not load?- iphone6",
  "id" : 525504101074075648,
  "created_at" : "2014-10-24 04:28:35 +0000",
  "in_reply_to_screen_name" : "paul_sensei",
  "in_reply_to_user_id_str" : "176429301",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Macmillan Dictionary",
      "screen_name" : "MacDictionary",
      "indices" : [ 78, 92 ],
      "id_str" : "23783700",
      "id" : 23783700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/lqrE3U8fth",
      "expanded_url" : "http:\/\/www.macmillandictionaryblog.com\/language-tip-of-the-week-conversation",
      "display_url" : "macmillandictionaryblog.com\/language-tip-o\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "525351004716290048",
  "text" : "Language tip of the week: conversation | Macmillan http:\/\/t.co\/lqrE3U8fth via @MacDictionary",
  "id" : 525351004716290048,
  "created_at" : "2014-10-23 18:20:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 89, 105 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/jeVuscIbev",
      "expanded_url" : "http:\/\/wp.me\/p2CPYN-gL",
      "display_url" : "wp.me\/p2CPYN-gL"
    } ]
  },
  "geo" : { },
  "id_str" : "525297787202580480",
  "text" : "At least 32 civilians killed by U.S.-led airstrikes in Syria. http:\/\/t.co\/jeVuscIbev via @wordpressdotcom",
  "id" : 525297787202580480,
  "created_at" : "2014-10-23 14:48:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/aY2e5sTbNO",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/International_variation_in_quotation_marks",
      "display_url" : "en.wikipedia.org\/wiki\/Internati\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "524982517171257345",
  "geo" : { },
  "id_str" : "524990630247014400",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan interesting variations worldwide http:\/\/t.co\/aY2e5sTbNO",
  "id" : 524990630247014400,
  "in_reply_to_status_id" : 524982517171257345,
  "created_at" : "2014-10-22 18:28:14 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IndyScot",
      "indices" : [ 80, 89 ]
    }, {
      "text" : "the45",
      "indices" : [ 90, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/6nJtTjcwrN",
      "expanded_url" : "http:\/\/johnhilley.blogspot.co.uk\/2014\/10\/owen-jones-poverty-referendum-and-his.html",
      "display_url" : "johnhilley.blogspot.co.uk\/2014\/10\/owen-j\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "524986249007095808",
  "text" : "RT @johnwhilley: Owen Jones, anti-establishment radical? http:\/\/t.co\/6nJtTjcwrN #IndyScot #the45",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IndyScot",
        "indices" : [ 63, 72 ]
      }, {
        "text" : "the45",
        "indices" : [ 73, 79 ]
      } ],
      "urls" : [ {
        "indices" : [ 40, 62 ],
        "url" : "http:\/\/t.co\/6nJtTjcwrN",
        "expanded_url" : "http:\/\/johnhilley.blogspot.co.uk\/2014\/10\/owen-jones-poverty-referendum-and-his.html",
        "display_url" : "johnhilley.blogspot.co.uk\/2014\/10\/owen-j\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "524981814394638336",
    "text" : "Owen Jones, anti-establishment radical? http:\/\/t.co\/6nJtTjcwrN #IndyScot #the45",
    "id" : 524981814394638336,
    "created_at" : "2014-10-22 17:53:12 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 524986249007095808,
  "created_at" : "2014-10-22 18:10:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "indices" : [ 0, 9 ],
      "id_str" : "167020390",
      "id" : 167020390
    }, {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "indices" : [ 10, 22 ],
      "id_str" : "849729062",
      "id" : 849729062
    }, {
      "name" : "Ricardo Nausa",
      "screen_name" : "R1c4rd0_N",
      "indices" : [ 23, 33 ],
      "id_str" : "35468421",
      "id" : 35468421
    }, {
      "name" : "FutureLearn",
      "screen_name" : "FutureLearn",
      "indices" : [ 53, 65 ],
      "id_str" : "999095640",
      "id" : 999095640
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "524855903187914752",
  "geo" : { },
  "id_str" : "524881343558451200",
  "in_reply_to_user_id" : 167020390,
  "text" : "@antlabjp @TonyMcEnery @R1c4rd0_N what software does @FutureLearn use for transcription?",
  "id" : 524881343558451200,
  "in_reply_to_status_id" : 524855903187914752,
  "created_at" : "2014-10-22 11:13:58 +0000",
  "in_reply_to_screen_name" : "antlabjp",
  "in_reply_to_user_id_str" : "167020390",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Raine",
      "screen_name" : "paul_sensei",
      "indices" : [ 0, 12 ],
      "id_str" : "176429301",
      "id" : 176429301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "524827801078095872",
  "geo" : { },
  "id_str" : "524878432703102977",
  "in_reply_to_user_id" : 176429301,
  "text" : "@paul_sensei nice cheers :)",
  "id" : 524878432703102977,
  "in_reply_to_status_id" : 524827801078095872,
  "created_at" : "2014-10-22 11:02:24 +0000",
  "in_reply_to_screen_name" : "paul_sensei",
  "in_reply_to_user_id_str" : "176429301",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bella Caledonia",
      "screen_name" : "bellacaledonia",
      "indices" : [ 52, 67 ],
      "id_str" : "103554348",
      "id" : 103554348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/UQg1qc0SVS",
      "expanded_url" : "http:\/\/wp.me\/p93oK-4sj",
      "display_url" : "wp.me\/p93oK-4sj"
    } ]
  },
  "geo" : { },
  "id_str" : "524650099259891712",
  "text" : "The Tarpaulin Revolution http:\/\/t.co\/UQg1qc0SVS via @bellacaledonia",
  "id" : 524650099259891712,
  "created_at" : "2014-10-21 19:55:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Apostolos K.",
      "screen_name" : "koutropoulos",
      "indices" : [ 3, 16 ],
      "id_str" : "17907414",
      "id" : 17907414
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "massiveteaching",
      "indices" : [ 38, 54 ]
    }, {
      "text" : "ccourses",
      "indices" : [ 130, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/lYPVRTv19h",
      "expanded_url" : "http:\/\/pocket.co\/s3AWR",
      "display_url" : "pocket.co\/s3AWR"
    } ]
  },
  "geo" : { },
  "id_str" : "524642968645677056",
  "text" : "RT @koutropoulos: interesting post on #massiveteaching - Erosion of thick legitimacy by Coursera http:\/\/t.co\/lYPVRTv19h must read #ccourses",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "massiveteaching",
        "indices" : [ 20, 36 ]
      }, {
        "text" : "ccourses",
        "indices" : [ 112, 121 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/lYPVRTv19h",
        "expanded_url" : "http:\/\/pocket.co\/s3AWR",
        "display_url" : "pocket.co\/s3AWR"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 42.3892247, -71.0767674 ]
    },
    "id_str" : "524533241207066625",
    "text" : "interesting post on #massiveteaching - Erosion of thick legitimacy by Coursera http:\/\/t.co\/lYPVRTv19h must read #ccourses",
    "id" : 524533241207066625,
    "created_at" : "2014-10-21 12:10:44 +0000",
    "user" : {
      "name" : "Apostolos K.",
      "screen_name" : "koutropoulos",
      "protected" : false,
      "id_str" : "17907414",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1476171910\/2_normal.png",
      "id" : 17907414,
      "verified" : false
    }
  },
  "id" : 524642968645677056,
  "created_at" : "2014-10-21 19:26:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Lavigne",
      "screen_name" : "sam_lavigne",
      "indices" : [ 3, 15 ],
      "id_str" : "6428702",
      "id" : 6428702
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/sam_lavigne\/status\/524610210292563968\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/0oKJyTCwzN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0fKNJgCEAAvYMJ.jpg",
      "id_str" : "524610208849334272",
      "id" : 524610208849334272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0fKNJgCEAAvYMJ.jpg",
      "sizes" : [ {
        "h" : 1448,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 481,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 849,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1448
      } ],
      "display_url" : "pic.twitter.com\/0oKJyTCwzN"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/6YJ5mU0gE0",
      "expanded_url" : "http:\/\/stupidhackathon.com",
      "display_url" : "stupidhackathon.com"
    } ]
  },
  "geo" : { },
  "id_str" : "524612437702873088",
  "text" : "RT @sam_lavigne: Stupid Shit No One Needs &amp; Terrible Ideas Hackathon is back: Nov 15, NYC. http:\/\/t.co\/6YJ5mU0gE0 http:\/\/t.co\/0oKJyTCwzN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/sam_lavigne\/status\/524610210292563968\/photo\/1",
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/0oKJyTCwzN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B0fKNJgCEAAvYMJ.jpg",
        "id_str" : "524610208849334272",
        "id" : 524610208849334272,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0fKNJgCEAAvYMJ.jpg",
        "sizes" : [ {
          "h" : 1448,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 481,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 849,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1448
        } ],
        "display_url" : "pic.twitter.com\/0oKJyTCwzN"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/6YJ5mU0gE0",
        "expanded_url" : "http:\/\/stupidhackathon.com",
        "display_url" : "stupidhackathon.com"
      } ]
    },
    "geo" : { },
    "id_str" : "524610210292563968",
    "text" : "Stupid Shit No One Needs &amp; Terrible Ideas Hackathon is back: Nov 15, NYC. http:\/\/t.co\/6YJ5mU0gE0 http:\/\/t.co\/0oKJyTCwzN",
    "id" : 524610210292563968,
    "created_at" : "2014-10-21 17:16:35 +0000",
    "user" : {
      "name" : "Sam Lavigne",
      "screen_name" : "sam_lavigne",
      "protected" : false,
      "id_str" : "6428702",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/453703393907712000\/-NTZsg_T_normal.jpeg",
      "id" : 6428702,
      "verified" : false
    }
  },
  "id" : 524612437702873088,
  "created_at" : "2014-10-21 17:25:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Raine",
      "screen_name" : "paul_sensei",
      "indices" : [ 0, 12 ],
      "id_str" : "176429301",
      "id" : 176429301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "524576338204585984",
  "geo" : { },
  "id_str" : "524607751352516608",
  "in_reply_to_user_id" : 176429301,
  "text" : "@paul_sensei ooh very nice, is it possible to search by part of speech?",
  "id" : 524607751352516608,
  "in_reply_to_status_id" : 524576338204585984,
  "created_at" : "2014-10-21 17:06:49 +0000",
  "in_reply_to_screen_name" : "paul_sensei",
  "in_reply_to_user_id_str" : "176429301",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Raine",
      "screen_name" : "paul_sensei",
      "indices" : [ 3, 15 ],
      "id_str" : "176429301",
      "id" : 176429301
    }, {
      "name" : "Tatoeba.org",
      "screen_name" : "tatoeba_org",
      "indices" : [ 116, 128 ],
      "id_str" : "29761676",
      "id" : 29761676
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "langchat",
      "indices" : [ 129, 138 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "efl",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/yjcsOjeA6p",
      "expanded_url" : "http:\/\/sentencebuilder.apps4efl.com",
      "display_url" : "sentencebuilder.apps4efl.com"
    } ]
  },
  "geo" : { },
  "id_str" : "524606131243847680",
  "text" : "RT @paul_sensei: New English learning app (http:\/\/t.co\/yjcsOjeA6p) utilizes vast database of example sentences from @tatoeba_org #langchat \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tatoeba.org",
        "screen_name" : "tatoeba_org",
        "indices" : [ 99, 111 ],
        "id_str" : "29761676",
        "id" : 29761676
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "langchat",
        "indices" : [ 112, 121 ]
      }, {
        "text" : "eltchat",
        "indices" : [ 122, 130 ]
      }, {
        "text" : "efl",
        "indices" : [ 131, 135 ]
      } ],
      "urls" : [ {
        "indices" : [ 26, 48 ],
        "url" : "http:\/\/t.co\/yjcsOjeA6p",
        "expanded_url" : "http:\/\/sentencebuilder.apps4efl.com",
        "display_url" : "sentencebuilder.apps4efl.com"
      } ]
    },
    "geo" : { },
    "id_str" : "524576338204585984",
    "text" : "New English learning app (http:\/\/t.co\/yjcsOjeA6p) utilizes vast database of example sentences from @tatoeba_org #langchat #eltchat #efl",
    "id" : 524576338204585984,
    "created_at" : "2014-10-21 15:01:59 +0000",
    "user" : {
      "name" : "Paul Raine",
      "screen_name" : "paul_sensei",
      "protected" : false,
      "id_str" : "176429301",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666950419248259073\/T7XVTUac_normal.jpg",
      "id" : 176429301,
      "verified" : false
    }
  },
  "id" : 524606131243847680,
  "created_at" : "2014-10-21 17:00:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer MacDonald",
      "screen_name" : "JenMac_ESL",
      "indices" : [ 0, 11 ],
      "id_str" : "608800026",
      "id" : 608800026
    }, {
      "name" : "Carol Goodey",
      "screen_name" : "carol_goodey",
      "indices" : [ 12, 25 ],
      "id_str" : "2814555865",
      "id" : 2814555865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/X3SHqAs5aE",
      "expanded_url" : "http:\/\/taiwanonymous.blogspot.fr\/2008\/08\/usage-of-sentence-initial-besides-in.html",
      "display_url" : "taiwanonymous.blogspot.fr\/2008\/08\/usage-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "524534674367205377",
  "geo" : { },
  "id_str" : "524549396265185280",
  "in_reply_to_user_id" : 608800026,
  "text" : "@JenMac_ESL @carol_goodey a related post here http:\/\/t.co\/X3SHqAs5aE",
  "id" : 524549396265185280,
  "in_reply_to_status_id" : 524534674367205377,
  "created_at" : "2014-10-21 13:14:56 +0000",
  "in_reply_to_screen_name" : "JenMac_ESL",
  "in_reply_to_user_id_str" : "608800026",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer MacDonald",
      "screen_name" : "JenMac_ESL",
      "indices" : [ 3, 14 ],
      "id_str" : "608800026",
      "id" : 608800026
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/iwB8g47Owk",
      "expanded_url" : "http:\/\/lexicoblog.blogspot.ca\/2014\/10\/besides-dodgy-discourse-marker.html",
      "display_url" : "lexicoblog.blogspot.ca\/2014\/10\/beside\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "524544113128263681",
  "text" : "RT @JenMac_ESL: This is EXACTLY how I feel about \"Besides,\". Not as straightforward to use as books portray it and as many Ss think. http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/iwB8g47Owk",
        "expanded_url" : "http:\/\/lexicoblog.blogspot.ca\/2014\/10\/besides-dodgy-discourse-marker.html",
        "display_url" : "lexicoblog.blogspot.ca\/2014\/10\/beside\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "524534674367205377",
    "text" : "This is EXACTLY how I feel about \"Besides,\". Not as straightforward to use as books portray it and as many Ss think. http:\/\/t.co\/iwB8g47Owk",
    "id" : 524534674367205377,
    "created_at" : "2014-10-21 12:16:26 +0000",
    "user" : {
      "name" : "Jennifer MacDonald",
      "screen_name" : "JenMac_ESL",
      "protected" : false,
      "id_str" : "608800026",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/450682476781129728\/SBKeLuvN_normal.jpeg",
      "id" : 608800026,
      "verified" : false
    }
  },
  "id" : 524544113128263681,
  "created_at" : "2014-10-21 12:53:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alannah Fitzgerald",
      "screen_name" : "AlannahFitz",
      "indices" : [ 0, 12 ],
      "id_str" : "223613160",
      "id" : 223613160
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "524467470778638336",
  "geo" : { },
  "id_str" : "524536339904348161",
  "in_reply_to_user_id" : 223613160,
  "text" : "@AlannahFitz thanks looked at it none the wiser!? have contacted flax team in nz.",
  "id" : 524536339904348161,
  "in_reply_to_status_id" : 524467470778638336,
  "created_at" : "2014-10-21 12:23:03 +0000",
  "in_reply_to_screen_name" : "AlannahFitz",
  "in_reply_to_user_id_str" : "223613160",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alannah Fitzgerald",
      "screen_name" : "AlannahFitz",
      "indices" : [ 0, 12 ],
      "id_str" : "223613160",
      "id" : 223613160
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "524307958901927936",
  "geo" : { },
  "id_str" : "524316218589597696",
  "in_reply_to_user_id" : 223613160,
  "text" : "@AlannahFitz okay ta",
  "id" : 524316218589597696,
  "in_reply_to_status_id" : 524307958901927936,
  "created_at" : "2014-10-20 21:48:22 +0000",
  "in_reply_to_screen_name" : "AlannahFitz",
  "in_reply_to_user_id_str" : "223613160",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Duygu \u00C7andarl\u0131",
      "screen_name" : "duygucandarli",
      "indices" : [ 3, 17 ],
      "id_str" : "48839094",
      "id" : 48839094
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/7MrPRvL3Fa",
      "expanded_url" : "http:\/\/www.newscientist.com\/article\/mg22429911.000-why-language-is-neither-an-instinct-nor-innate.html",
      "display_url" : "newscientist.com\/article\/mg2242\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "524316052230909952",
  "text" : "RT @duygucandarli: From 'language-as-instinct' to 'language-as-use' - Why language is neither an instinct nor innate: http:\/\/t.co\/7MrPRvL3Fa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/7MrPRvL3Fa",
        "expanded_url" : "http:\/\/www.newscientist.com\/article\/mg22429911.000-why-language-is-neither-an-instinct-nor-innate.html",
        "display_url" : "newscientist.com\/article\/mg2242\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "524311564262707200",
    "text" : "From 'language-as-instinct' to 'language-as-use' - Why language is neither an instinct nor innate: http:\/\/t.co\/7MrPRvL3Fa",
    "id" : 524311564262707200,
    "created_at" : "2014-10-20 21:29:52 +0000",
    "user" : {
      "name" : "Duygu \u00C7andarl\u0131",
      "screen_name" : "duygucandarli",
      "protected" : false,
      "id_str" : "48839094",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/473607105765576704\/DIiO0Cy7_normal.jpeg",
      "id" : 48839094,
      "verified" : false
    }
  },
  "id" : 524316052230909952,
  "created_at" : "2014-10-20 21:47:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/3QinIQj8Pe",
      "expanded_url" : "http:\/\/www.theguardian.com\/us-news\/2014\/oct\/20\/suspected-nazi-war-criminals-us-social-security-benefits",
      "display_url" : "theguardian.com\/us-news\/2014\/o\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "524293976858566656",
  "text" : "RT @pchallinor: I bet most of them weren't even CIA spooks or nuclear physicists http:\/\/t.co\/3QinIQj8Pe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/3QinIQj8Pe",
        "expanded_url" : "http:\/\/www.theguardian.com\/us-news\/2014\/oct\/20\/suspected-nazi-war-criminals-us-social-security-benefits",
        "display_url" : "theguardian.com\/us-news\/2014\/o\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "524216544092753920",
    "text" : "I bet most of them weren't even CIA spooks or nuclear physicists http:\/\/t.co\/3QinIQj8Pe",
    "id" : 524216544092753920,
    "created_at" : "2014-10-20 15:12:18 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 524293976858566656,
  "created_at" : "2014-10-20 20:19:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 140 ],
      "url" : "http:\/\/t.co\/gZu8w3p0uv",
      "expanded_url" : "http:\/\/www.dailykos.com\/story\/2014\/10\/19\/1337677\/--Israeli-Settler-Ran-Over-Two-Palestinian-Girls",
      "display_url" : "dailykos.com\/story\/2014\/10\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "524292199773913089",
  "text" : "RT @johnwhilley: RIP little Enas Shawkat. Why are these terrorist-settler murders not being widely reported by the BBC?  http:\/\/t.co\/gZu8w3\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/gZu8w3p0uv",
        "expanded_url" : "http:\/\/www.dailykos.com\/story\/2014\/10\/19\/1337677\/--Israeli-Settler-Ran-Over-Two-Palestinian-Girls",
        "display_url" : "dailykos.com\/story\/2014\/10\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "524275235311603712",
    "text" : "RIP little Enas Shawkat. Why are these terrorist-settler murders not being widely reported by the BBC?  http:\/\/t.co\/gZu8w3p0uv",
    "id" : 524275235311603712,
    "created_at" : "2014-10-20 19:05:31 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 524292199773913089,
  "created_at" : "2014-10-20 20:12:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jonathan frandzone",
      "screen_name" : "NotAllBhas",
      "indices" : [ 0, 11 ],
      "id_str" : "513493043",
      "id" : 513493043
    }, {
      "name" : "Graham",
      "screen_name" : "onalifeglug",
      "indices" : [ 12, 24 ],
      "id_str" : "19516039",
      "id" : 19516039
    }, {
      "name" : "Jareer Kassis",
      "screen_name" : "JareerKassis",
      "indices" : [ 25, 38 ],
      "id_str" : "306896118",
      "id" : 306896118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "524277157829550080",
  "geo" : { },
  "id_str" : "524286268205580289",
  "in_reply_to_user_id" : 513493043,
  "text" : "@NotAllBhas @onalifeglug @JareerKassis do people still take Dawkins seriously? only thing interesting about him is his wife ex Doctor Who :)",
  "id" : 524286268205580289,
  "in_reply_to_status_id" : 524277157829550080,
  "created_at" : "2014-10-20 19:49:21 +0000",
  "in_reply_to_screen_name" : "NotAllBhas",
  "in_reply_to_user_id_str" : "513493043",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Bex Lewis",
      "screen_name" : "drbexl",
      "indices" : [ 3, 10 ],
      "id_str" : "17446633",
      "id" : 17446633
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CORPUSMOOC",
      "indices" : [ 12, 23 ]
    } ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/Um2Cx2XxRc",
      "expanded_url" : "http:\/\/wp.me\/p39dN1-1C2",
      "display_url" : "wp.me\/p39dN1-1C2"
    } ]
  },
  "geo" : { },
  "id_str" : "524257739279990785",
  "text" : "RT @drbexl: #CORPUSMOOC Week 4\u00A0Notes http:\/\/t.co\/Um2Cx2XxRc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CORPUSMOOC",
        "indices" : [ 0, 11 ]
      } ],
      "urls" : [ {
        "indices" : [ 25, 47 ],
        "url" : "http:\/\/t.co\/Um2Cx2XxRc",
        "expanded_url" : "http:\/\/wp.me\/p39dN1-1C2",
        "display_url" : "wp.me\/p39dN1-1C2"
      } ]
    },
    "geo" : { },
    "id_str" : "524226950923943936",
    "text" : "#CORPUSMOOC Week 4\u00A0Notes http:\/\/t.co\/Um2Cx2XxRc",
    "id" : 524226950923943936,
    "created_at" : "2014-10-20 15:53:39 +0000",
    "user" : {
      "name" : "Dr Bex Lewis",
      "screen_name" : "drbexl",
      "protected" : false,
      "id_str" : "17446633",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733719568460480517\/-1BSbv9u_normal.jpg",
      "id" : 17446633,
      "verified" : false
    }
  },
  "id" : 524257739279990785,
  "created_at" : "2014-10-20 17:55:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alannah Fitzgerald",
      "screen_name" : "AlannahFitz",
      "indices" : [ 0, 12 ],
      "id_str" : "223613160",
      "id" : 223613160
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "524242656919306240",
  "in_reply_to_user_id" : 223613160,
  "text" : "@AlannahFitz hi any info on whether one can add own collection in stand alone flax? thx",
  "id" : 524242656919306240,
  "created_at" : "2014-10-20 16:56:04 +0000",
  "in_reply_to_screen_name" : "AlannahFitz",
  "in_reply_to_user_id_str" : "223613160",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 77, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/ueBY2DSbqP",
      "expanded_url" : "https:\/\/www.futurelearn.com\/courses\/corpus-linguistics-2014-q3\/steps\/14833\/comments\/2244814",
      "display_url" : "futurelearn.com\/courses\/corpus\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "524219566285914113",
  "text" : "\"Bring your corpora to the slaughter\" &amp; other Iron Maiden songs put in a #corpusmooc appearance https:\/\/t.co\/ueBY2DSbqP :)",
  "id" : 524219566285914113,
  "created_at" : "2014-10-20 15:24:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "i_narrator",
      "screen_name" : "i_narrator",
      "indices" : [ 0, 11 ],
      "id_str" : "281361233",
      "id" : 281361233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "524171235563802627",
  "geo" : { },
  "id_str" : "524174905588592640",
  "in_reply_to_user_id" : 281361233,
  "text" : "@i_narrator ooh very nice thx though server seems to be bugging?",
  "id" : 524174905588592640,
  "in_reply_to_status_id" : 524171235563802627,
  "created_at" : "2014-10-20 12:26:50 +0000",
  "in_reply_to_screen_name" : "i_narrator",
  "in_reply_to_user_id_str" : "281361233",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 109, 117 ]
    }, {
      "text" : "elt",
      "indices" : [ 118, 122 ]
    }, {
      "text" : "ESL",
      "indices" : [ 123, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/cEAyWdyh6m",
      "expanded_url" : "http:\/\/www.englicious.org\/node\/411",
      "display_url" : "englicious.org\/node\/411"
    } ]
  },
  "geo" : { },
  "id_str" : "524094704934453248",
  "text" : "Englicious, grammar for schools http:\/\/t.co\/cEAyWdyh6m seems neat site though only free so far till end 2014 #eltchat #elt #ESL",
  "id" : 524094704934453248,
  "created_at" : "2014-10-20 07:08:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "indices" : [ 3, 12 ],
      "id_str" : "167020390",
      "id" : 167020390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 123, 140 ],
      "url" : "http:\/\/t.co\/tdQR7xrchy",
      "expanded_url" : "http:\/\/www.laurenceanthony.net\/software.html#encodeant",
      "display_url" : "laurenceanthony.net\/software.html#\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "524079189713248256",
  "text" : "RT @antlabjp: Another new tool from AntLab! EncodeAnt is a freeware tool for detecting and converting character encodings.\nhttp:\/\/t.co\/tdQR\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/tdQR7xrchy",
        "expanded_url" : "http:\/\/www.laurenceanthony.net\/software.html#encodeant",
        "display_url" : "laurenceanthony.net\/software.html#\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "524030928650530816",
    "text" : "Another new tool from AntLab! EncodeAnt is a freeware tool for detecting and converting character encodings.\nhttp:\/\/t.co\/tdQR7xrchy",
    "id" : 524030928650530816,
    "created_at" : "2014-10-20 02:54:44 +0000",
    "user" : {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "protected" : false,
      "id_str" : "167020390",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/428183580821315584\/ocgCI7Er_normal.jpeg",
      "id" : 167020390,
      "verified" : false
    }
  },
  "id" : 524079189713248256,
  "created_at" : "2014-10-20 06:06:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Bex Lewis",
      "screen_name" : "drbexl",
      "indices" : [ 3, 10 ],
      "id_str" : "17446633",
      "id" : 17446633
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CORPUSMOOC",
      "indices" : [ 12, 23 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/t8V2Zm6kkt",
      "expanded_url" : "http:\/\/wp.me\/p39dN1-1BJ",
      "display_url" : "wp.me\/p39dN1-1BJ"
    } ]
  },
  "geo" : { },
  "id_str" : "524010792535224320",
  "text" : "RT @drbexl: #CORPUSMOOC \u2013 Corpus Linguistics Week\u00A03 http:\/\/t.co\/t8V2Zm6kkt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CORPUSMOOC",
        "indices" : [ 0, 11 ]
      } ],
      "urls" : [ {
        "indices" : [ 40, 62 ],
        "url" : "http:\/\/t.co\/t8V2Zm6kkt",
        "expanded_url" : "http:\/\/wp.me\/p39dN1-1BJ",
        "display_url" : "wp.me\/p39dN1-1BJ"
      } ]
    },
    "geo" : { },
    "id_str" : "523930571513135105",
    "text" : "#CORPUSMOOC \u2013 Corpus Linguistics Week\u00A03 http:\/\/t.co\/t8V2Zm6kkt",
    "id" : 523930571513135105,
    "created_at" : "2014-10-19 20:15:57 +0000",
    "user" : {
      "name" : "Dr Bex Lewis",
      "screen_name" : "drbexl",
      "protected" : false,
      "id_str" : "17446633",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733719568460480517\/-1BSbv9u_normal.jpg",
      "id" : 17446633,
      "verified" : false
    }
  },
  "id" : 524010792535224320,
  "created_at" : "2014-10-20 01:34:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Claire Hardaker",
      "screen_name" : "DrClaireH",
      "indices" : [ 3, 13 ],
      "id_str" : "237842162",
      "id" : 237842162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 125, 140 ],
      "url" : "http:\/\/t.co\/v5aM5rgRuq",
      "expanded_url" : "http:\/\/wp.lancs.ac.uk\/drclaireh\/2014\/10\/19\/chris-grayling-and-the-cyber-mob-crackdown\/",
      "display_url" : "wp.lancs.ac.uk\/drclaireh\/2014\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "523958760566689793",
  "text" : "RT @DrClaireH: Chris Grayling's cyber-mob crackdown: how does this jive with the CPS guidelines on prosecuting online abuse? http:\/\/t.co\/v5\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/v5aM5rgRuq",
        "expanded_url" : "http:\/\/wp.lancs.ac.uk\/drclaireh\/2014\/10\/19\/chris-grayling-and-the-cyber-mob-crackdown\/",
        "display_url" : "wp.lancs.ac.uk\/drclaireh\/2014\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "523841828412735488",
    "text" : "Chris Grayling's cyber-mob crackdown: how does this jive with the CPS guidelines on prosecuting online abuse? http:\/\/t.co\/v5aM5rgRuq",
    "id" : 523841828412735488,
    "created_at" : "2014-10-19 14:23:19 +0000",
    "user" : {
      "name" : "Dr Claire Hardaker",
      "screen_name" : "DrClaireH",
      "protected" : false,
      "id_str" : "237842162",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744470254177390592\/ZhYTy0JE_normal.jpg",
      "id" : 237842162,
      "verified" : false
    }
  },
  "id" : 523958760566689793,
  "created_at" : "2014-10-19 22:07:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShareThis",
      "screen_name" : "ShareThis",
      "indices" : [ 63, 73 ],
      "id_str" : "14116807",
      "id" : 14116807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/NWIG3OXqEA",
      "expanded_url" : "http:\/\/shar.es\/1mIXWW",
      "display_url" : "shar.es\/1mIXWW"
    } ]
  },
  "geo" : { },
  "id_str" : "523950334972948480",
  "text" : "When the Ayatollah Said No to Nukes http:\/\/t.co\/NWIG3OXqEA via @sharethis",
  "id" : 523950334972948480,
  "created_at" : "2014-10-19 21:34:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 2, 13 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/ql1wTM1Lwq",
      "expanded_url" : "https:\/\/magic.piktochart.com\/output\/3140351-untitled-infographic",
      "display_url" : "magic.piktochart.com\/output\/3140351\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "523843255184916480",
  "text" : "a #corpusmooc visual aid for tokens, types, lemmas, word families https:\/\/t.co\/ql1wTM1Lwq",
  "id" : 523843255184916480,
  "created_at" : "2014-10-19 14:28:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/HaZAVyr4cm",
      "expanded_url" : "http:\/\/www.informationclearinghouse.info\/article40010.htm",
      "display_url" : "informationclearinghouse.info\/article40010.h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "523831923341545472",
  "text" : "My Grandson Doesn't Kill Children\nWhat Happens When You Talk With Americans About Drone Murders http:\/\/t.co\/HaZAVyr4cm",
  "id" : 523831923341545472,
  "created_at" : "2014-10-19 13:43:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 44, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "523801412161896449",
  "text" : "must.resist.commenting. on i'm alright jack #corpusmooc participant :\/",
  "id" : 523801412161896449,
  "created_at" : "2014-10-19 11:42:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "indices" : [ 3, 12 ],
      "id_str" : "167020390",
      "id" : 167020390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/fUQfIpmwMi",
      "expanded_url" : "http:\/\/www.laurenceanthony.net\/software.html#segmentant",
      "display_url" : "laurenceanthony.net\/software.html#\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "523794776521703424",
  "text" : "RT @antlabjp: I've just released SegmentAnt: a freeware tool for segmenting (tokenizing) Japanese and Chinese texts. Get it here: \nhttp:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/fUQfIpmwMi",
        "expanded_url" : "http:\/\/www.laurenceanthony.net\/software.html#segmentant",
        "display_url" : "laurenceanthony.net\/software.html#\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "523291667592654849",
    "text" : "I've just released SegmentAnt: a freeware tool for segmenting (tokenizing) Japanese and Chinese texts. Get it here: \nhttp:\/\/t.co\/fUQfIpmwMi",
    "id" : 523291667592654849,
    "created_at" : "2014-10-18 01:57:10 +0000",
    "user" : {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "protected" : false,
      "id_str" : "167020390",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/428183580821315584\/ocgCI7Er_normal.jpeg",
      "id" : 167020390,
      "verified" : false
    }
  },
  "id" : 523794776521703424,
  "created_at" : "2014-10-19 11:16:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alannah Fitzgerald",
      "screen_name" : "AlannahFitz",
      "indices" : [ 0, 12 ],
      "id_str" : "223613160",
      "id" : 223613160
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "523792427279470592",
  "in_reply_to_user_id" : 223613160,
  "text" : "@AlannahFitz hi i setup standalone flax but can't see add own collection? is that possible in standalone version? thx",
  "id" : 523792427279470592,
  "created_at" : "2014-10-19 11:07:00 +0000",
  "in_reply_to_screen_name" : "AlannahFitz",
  "in_reply_to_user_id_str" : "223613160",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alannah Fitzgerald",
      "screen_name" : "AlannahFitz",
      "indices" : [ 0, 12 ],
      "id_str" : "223613160",
      "id" : 223613160
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/LRNo1j5Wo3",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=1g1cPRFp61c&feature=youtu.be&a",
      "display_url" : "youtube.com\/watch?v=1g1cPR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "523787523458613248",
  "in_reply_to_user_id" : 223613160,
  "text" : "@AlannahFitz hi u may want to obscure email adds from 2:30-2:41 https:\/\/t.co\/LRNo1j5Wo3",
  "id" : 523787523458613248,
  "created_at" : "2014-10-19 10:47:31 +0000",
  "in_reply_to_screen_name" : "AlannahFitz",
  "in_reply_to_user_id_str" : "223613160",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Rago",
      "screen_name" : "tesolwar",
      "indices" : [ 83, 92 ],
      "id_str" : "234781682",
      "id" : 234781682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/7GerqEBZn2",
      "expanded_url" : "http:\/\/wp.me\/p4rk3Q-4i",
      "display_url" : "wp.me\/p4rk3Q-4i"
    } ]
  },
  "geo" : { },
  "id_str" : "523770183488245761",
  "text" : "Classroom Interactions: from post-grad to middle school http:\/\/t.co\/7GerqEBZn2 via @tesolwar",
  "id" : 523770183488245761,
  "created_at" : "2014-10-19 09:38:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Occupy London",
      "screen_name" : "OccupyLondon",
      "indices" : [ 3, 16 ],
      "id_str" : "379481082",
      "id" : 379481082
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Petercoville\/status\/523748331886231552\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/O5C2yoXiiD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0S6VIqIgAAUVyX.jpg",
      "id_str" : "523748328946040832",
      "id" : 523748328946040832,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0S6VIqIgAAUVyX.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/O5C2yoXiiD"
    } ],
    "hashtags" : [ {
      "text" : "occupydemocracy",
      "indices" : [ 49, 65 ]
    }, {
      "text" : "olsx",
      "indices" : [ 126, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "523756604517515265",
  "text" : "RT @OccupyLondon: Real democracy breaking out at #occupydemocracy in Parliament Square y'day! Get down there today if you can #olsx http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.GroupTweet.com\" rel=\"nofollow\"\u003EGroupTweet\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Petercoville\/status\/523748331886231552\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/O5C2yoXiiD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B0S6VIqIgAAUVyX.jpg",
        "id_str" : "523748328946040832",
        "id" : 523748328946040832,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0S6VIqIgAAUVyX.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/O5C2yoXiiD"
      } ],
      "hashtags" : [ {
        "text" : "occupydemocracy",
        "indices" : [ 31, 47 ]
      }, {
        "text" : "olsx",
        "indices" : [ 108, 113 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "523748337561112576",
    "text" : "Real democracy breaking out at #occupydemocracy in Parliament Square y'day! Get down there today if you can #olsx http:\/\/t.co\/O5C2yoXiiD",
    "id" : 523748337561112576,
    "created_at" : "2014-10-19 08:11:49 +0000",
    "user" : {
      "name" : "Occupy London",
      "screen_name" : "OccupyLondon",
      "protected" : false,
      "id_str" : "379481082",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2220521926\/occupy_london_sq_white_col_normal.jpg",
      "id" : 379481082,
      "verified" : false
    }
  },
  "id" : 523756604517515265,
  "created_at" : "2014-10-19 08:44:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alannah Fitzgerald",
      "screen_name" : "AlannahFitz",
      "indices" : [ 3, 15 ],
      "id_str" : "223613160",
      "id" : 223613160
    }, {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 85, 93 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/RztXPjFoAR",
      "expanded_url" : "http:\/\/youtu.be\/VZp5WvdHpnM?a",
      "display_url" : "youtu.be\/VZp5WvdHpnM?a"
    } ]
  },
  "geo" : { },
  "id_str" : "523751026273562624",
  "text" : "RT @AlannahFitz: English for Specific Purposes in FLAX 2: http:\/\/t.co\/RztXPjFoAR via @YouTube",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ 68, 76 ],
        "id_str" : "10228272",
        "id" : 10228272
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/RztXPjFoAR",
        "expanded_url" : "http:\/\/youtu.be\/VZp5WvdHpnM?a",
        "display_url" : "youtu.be\/VZp5WvdHpnM?a"
      } ]
    },
    "geo" : { },
    "id_str" : "523603108383821824",
    "text" : "English for Specific Purposes in FLAX 2: http:\/\/t.co\/RztXPjFoAR via @YouTube",
    "id" : 523603108383821824,
    "created_at" : "2014-10-18 22:34:43 +0000",
    "user" : {
      "name" : "Alannah Fitzgerald",
      "screen_name" : "AlannahFitz",
      "protected" : false,
      "id_str" : "223613160",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2645381550\/e07d3b354efdac11bce2725cbc44e94e_normal.png",
      "id" : 223613160,
      "verified" : false
    }
  },
  "id" : 523751026273562624,
  "created_at" : "2014-10-19 08:22:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alannah Fitzgerald",
      "screen_name" : "AlannahFitz",
      "indices" : [ 3, 15 ],
      "id_str" : "223613160",
      "id" : 223613160
    }, {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 85, 93 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/1rHvriRN2Z",
      "expanded_url" : "http:\/\/youtu.be\/_nbcq9Uuxqo?a",
      "display_url" : "youtu.be\/_nbcq9Uuxqo?a"
    } ]
  },
  "geo" : { },
  "id_str" : "523751007537606656",
  "text" : "RT @AlannahFitz: English for Specific Purposes in FLAX 3: http:\/\/t.co\/1rHvriRN2Z via @YouTube",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ 68, 76 ],
        "id_str" : "10228272",
        "id" : 10228272
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/1rHvriRN2Z",
        "expanded_url" : "http:\/\/youtu.be\/_nbcq9Uuxqo?a",
        "display_url" : "youtu.be\/_nbcq9Uuxqo?a"
      } ]
    },
    "geo" : { },
    "id_str" : "523590202455912448",
    "text" : "English for Specific Purposes in FLAX 3: http:\/\/t.co\/1rHvriRN2Z via @YouTube",
    "id" : 523590202455912448,
    "created_at" : "2014-10-18 21:43:26 +0000",
    "user" : {
      "name" : "Alannah Fitzgerald",
      "screen_name" : "AlannahFitz",
      "protected" : false,
      "id_str" : "223613160",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2645381550\/e07d3b354efdac11bce2725cbc44e94e_normal.png",
      "id" : 223613160,
      "verified" : false
    }
  },
  "id" : 523751007537606656,
  "created_at" : "2014-10-19 08:22:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alannah Fitzgerald",
      "screen_name" : "AlannahFitz",
      "indices" : [ 3, 15 ],
      "id_str" : "223613160",
      "id" : 223613160
    }, {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 72, 80 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/4MG5TX6plY",
      "expanded_url" : "http:\/\/youtu.be\/YK8J9M7VU8c?a",
      "display_url" : "youtu.be\/YK8J9M7VU8c?a"
    } ]
  },
  "geo" : { },
  "id_str" : "523588942701285377",
  "text" : "RT @AlannahFitz: BAWE Collections in FLAX 1: http:\/\/t.co\/4MG5TX6plY via @YouTube",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ 55, 63 ],
        "id_str" : "10228272",
        "id" : 10228272
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 28, 50 ],
        "url" : "http:\/\/t.co\/4MG5TX6plY",
        "expanded_url" : "http:\/\/youtu.be\/YK8J9M7VU8c?a",
        "display_url" : "youtu.be\/YK8J9M7VU8c?a"
      } ]
    },
    "geo" : { },
    "id_str" : "523578000474796032",
    "text" : "BAWE Collections in FLAX 1: http:\/\/t.co\/4MG5TX6plY via @YouTube",
    "id" : 523578000474796032,
    "created_at" : "2014-10-18 20:54:57 +0000",
    "user" : {
      "name" : "Alannah Fitzgerald",
      "screen_name" : "AlannahFitz",
      "protected" : false,
      "id_str" : "223613160",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2645381550\/e07d3b354efdac11bce2725cbc44e94e_normal.png",
      "id" : 223613160,
      "verified" : false
    }
  },
  "id" : 523588942701285377,
  "created_at" : "2014-10-18 21:38:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alannah Fitzgerald",
      "screen_name" : "AlannahFitz",
      "indices" : [ 3, 15 ],
      "id_str" : "223613160",
      "id" : 223613160
    }, {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 72, 80 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/cOjbSo1iea",
      "expanded_url" : "http:\/\/youtu.be\/nTSxOO3Lwx8?a",
      "display_url" : "youtu.be\/nTSxOO3Lwx8?a"
    } ]
  },
  "geo" : { },
  "id_str" : "523574809968799744",
  "text" : "RT @AlannahFitz: BAWE Collections in FLAX 2: http:\/\/t.co\/cOjbSo1iea via @YouTube",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ 55, 63 ],
        "id_str" : "10228272",
        "id" : 10228272
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 28, 50 ],
        "url" : "http:\/\/t.co\/cOjbSo1iea",
        "expanded_url" : "http:\/\/youtu.be\/nTSxOO3Lwx8?a",
        "display_url" : "youtu.be\/nTSxOO3Lwx8?a"
      } ]
    },
    "geo" : { },
    "id_str" : "523565613310955520",
    "text" : "BAWE Collections in FLAX 2: http:\/\/t.co\/cOjbSo1iea via @YouTube",
    "id" : 523565613310955520,
    "created_at" : "2014-10-18 20:05:44 +0000",
    "user" : {
      "name" : "Alannah Fitzgerald",
      "screen_name" : "AlannahFitz",
      "protected" : false,
      "id_str" : "223613160",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2645381550\/e07d3b354efdac11bce2725cbc44e94e_normal.png",
      "id" : 223613160,
      "verified" : false
    }
  },
  "id" : 523574809968799744,
  "created_at" : "2014-10-18 20:42:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Gillmor",
      "screen_name" : "dangillmor",
      "indices" : [ 0, 11 ],
      "id_str" : "6267962",
      "id" : 6267962
    }, {
      "name" : "Magnus Nissel",
      "screen_name" : "u203d",
      "indices" : [ 12, 18 ],
      "id_str" : "533114985",
      "id" : 533114985
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/nGdGtrkRfW",
      "expanded_url" : "http:\/\/scripting.com\/2014\/10\/17\/twittersTimelineIsChanging.html",
      "display_url" : "scripting.com\/2014\/10\/17\/twi\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "523549865310044160",
  "geo" : { },
  "id_str" : "523553186008010752",
  "in_reply_to_user_id" : 6267962,
  "text" : "@dangillmor @u203d dave winer's take http:\/\/t.co\/nGdGtrkRfW",
  "id" : 523553186008010752,
  "in_reply_to_status_id" : 523549865310044160,
  "created_at" : "2014-10-18 19:16:21 +0000",
  "in_reply_to_screen_name" : "dangillmor",
  "in_reply_to_user_id_str" : "6267962",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alannah Fitzgerald",
      "screen_name" : "AlannahFitz",
      "indices" : [ 3, 15 ],
      "id_str" : "223613160",
      "id" : 223613160
    }, {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 92, 100 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/uwNKYy9htA",
      "expanded_url" : "http:\/\/youtu.be\/1g1cPRFp61c?a",
      "display_url" : "youtu.be\/1g1cPRFp61c?a"
    } ]
  },
  "geo" : { },
  "id_str" : "523539708178358272",
  "text" : "RT @AlannahFitz: Do-It-Yourself FLAX Collections 1: Development: http:\/\/t.co\/uwNKYy9htA via @YouTube",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ 75, 83 ],
        "id_str" : "10228272",
        "id" : 10228272
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 70 ],
        "url" : "http:\/\/t.co\/uwNKYy9htA",
        "expanded_url" : "http:\/\/youtu.be\/1g1cPRFp61c?a",
        "display_url" : "youtu.be\/1g1cPRFp61c?a"
      } ]
    },
    "geo" : { },
    "id_str" : "523534036468117504",
    "text" : "Do-It-Yourself FLAX Collections 1: Development: http:\/\/t.co\/uwNKYy9htA via @YouTube",
    "id" : 523534036468117504,
    "created_at" : "2014-10-18 18:00:15 +0000",
    "user" : {
      "name" : "Alannah Fitzgerald",
      "screen_name" : "AlannahFitz",
      "protected" : false,
      "id_str" : "223613160",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2645381550\/e07d3b354efdac11bce2725cbc44e94e_normal.png",
      "id" : 223613160,
      "verified" : false
    }
  },
  "id" : 523539708178358272,
  "created_at" : "2014-10-18 18:22:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Guardian",
      "screen_name" : "guardian",
      "indices" : [ 87, 96 ],
      "id_str" : "87818409",
      "id" : 87818409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/2KMaGbQALZ",
      "expanded_url" : "http:\/\/gu.com\/p\/42aeh\/tw",
      "display_url" : "gu.com\/p\/42aeh\/tw"
    } ]
  },
  "geo" : { },
  "id_str" : "523510863957749760",
  "text" : "Happy 20th anniversary to Dave Winer \u2013 inventor of the blog http:\/\/t.co\/2KMaGbQALZ via @guardian",
  "id" : 523510863957749760,
  "created_at" : "2014-10-18 16:28:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alannah Fitzgerald",
      "screen_name" : "AlannahFitz",
      "indices" : [ 3, 15 ],
      "id_str" : "223613160",
      "id" : 223613160
    }, {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 91, 99 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/mKqe1zwTL3",
      "expanded_url" : "http:\/\/youtu.be\/HY8OtJg-vhY?a",
      "display_url" : "youtu.be\/HY8OtJg-vhY?a"
    } ]
  },
  "geo" : { },
  "id_str" : "523509503283974145",
  "text" : "RT @AlannahFitz: Do-It-Yourself FLAX Collections 2: Activities: http:\/\/t.co\/mKqe1zwTL3 via @YouTube",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ 74, 82 ],
        "id_str" : "10228272",
        "id" : 10228272
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 69 ],
        "url" : "http:\/\/t.co\/mKqe1zwTL3",
        "expanded_url" : "http:\/\/youtu.be\/HY8OtJg-vhY?a",
        "display_url" : "youtu.be\/HY8OtJg-vhY?a"
      } ]
    },
    "geo" : { },
    "id_str" : "523503913215868928",
    "text" : "Do-It-Yourself FLAX Collections 2: Activities: http:\/\/t.co\/mKqe1zwTL3 via @YouTube",
    "id" : 523503913215868928,
    "created_at" : "2014-10-18 16:00:33 +0000",
    "user" : {
      "name" : "Alannah Fitzgerald",
      "screen_name" : "AlannahFitz",
      "protected" : false,
      "id_str" : "223613160",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2645381550\/e07d3b354efdac11bce2725cbc44e94e_normal.png",
      "id" : 223613160,
      "verified" : false
    }
  },
  "id" : 523509503283974145,
  "created_at" : "2014-10-18 16:22:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tmrkn",
      "screen_name" : "tam07pb915",
      "indices" : [ 0, 11 ],
      "id_str" : "297494886",
      "id" : 297494886
    }, {
      "name" : "i_narrator",
      "screen_name" : "i_narrator",
      "indices" : [ 12, 23 ],
      "id_str" : "281361233",
      "id" : 281361233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/NZUQSGS8io",
      "expanded_url" : "http:\/\/www.tesisenred.net\/bitstream\/handle\/10803\/52083\/DJLS_DISSERTATION.pdf?sequence=1",
      "display_url" : "tesisenred.net\/bitstream\/hand\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "522941202119659520",
  "geo" : { },
  "id_str" : "523503068760244224",
  "in_reply_to_user_id" : 297494886,
  "text" : "@tam07pb915 @i_narrator hi you can get her thesis here http:\/\/t.co\/NZUQSGS8io",
  "id" : 523503068760244224,
  "in_reply_to_status_id" : 522941202119659520,
  "created_at" : "2014-10-18 15:57:12 +0000",
  "in_reply_to_screen_name" : "tam07pb915",
  "in_reply_to_user_id_str" : "297494886",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bella Caledonia",
      "screen_name" : "bellacaledonia",
      "indices" : [ 3, 18 ],
      "id_str" : "103554348",
      "id" : 103554348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/AmoTMj4Gmb",
      "expanded_url" : "http:\/\/www.newyorker.com\/tech\/elements\/spain-politics-via-reddit",
      "display_url" : "newyorker.com\/tech\/elements\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "523192291792793602",
  "text" : "RT @bellacaledonia: How Podemos Uses Reddit Politics   http:\/\/t.co\/AmoTMj4Gmb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 57 ],
        "url" : "http:\/\/t.co\/AmoTMj4Gmb",
        "expanded_url" : "http:\/\/www.newyorker.com\/tech\/elements\/spain-politics-via-reddit",
        "display_url" : "newyorker.com\/tech\/elements\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "523189982400241665",
    "text" : "How Podemos Uses Reddit Politics   http:\/\/t.co\/AmoTMj4Gmb",
    "id" : 523189982400241665,
    "created_at" : "2014-10-17 19:13:06 +0000",
    "user" : {
      "name" : "Bella Caledonia",
      "screen_name" : "bellacaledonia",
      "protected" : false,
      "id_str" : "103554348",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/732831340194897925\/WGVyJGiO_normal.jpg",
      "id" : 103554348,
      "verified" : false
    }
  },
  "id" : 523192291792793602,
  "created_at" : "2014-10-17 19:22:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShareThis",
      "screen_name" : "ShareThis",
      "indices" : [ 88, 98 ],
      "id_str" : "14116807",
      "id" : 14116807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/wQUghlQHQ3",
      "expanded_url" : "http:\/\/shar.es\/1mkrEc",
      "display_url" : "shar.es\/1mkrEc"
    } ]
  },
  "geo" : { },
  "id_str" : "523175509589389312",
  "text" : "Britain\u2019s complicity in \u2018beyond description\u2019 bombing of Gaza http:\/\/t.co\/wQUghlQHQ3 via @sharethis",
  "id" : 523175509589389312,
  "created_at" : "2014-10-17 18:15:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Harbinson",
      "screen_name" : "DavidHarbinson",
      "indices" : [ 0, 15 ],
      "id_str" : "853078675",
      "id" : 853078675
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "523169315005005824",
  "geo" : { },
  "id_str" : "523170080423960576",
  "in_reply_to_user_id" : 853078675,
  "text" : "@DavidHarbinson around wrexham area",
  "id" : 523170080423960576,
  "in_reply_to_status_id" : 523169315005005824,
  "created_at" : "2014-10-17 17:54:01 +0000",
  "in_reply_to_screen_name" : "DavidHarbinson",
  "in_reply_to_user_id_str" : "853078675",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Harbinson",
      "screen_name" : "DavidHarbinson",
      "indices" : [ 0, 15 ],
      "id_str" : "853078675",
      "id" : 853078675
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "523145418645860352",
  "geo" : { },
  "id_str" : "523169058452422656",
  "in_reply_to_user_id" : 853078675,
  "text" : "@DavidHarbinson nice post, can identify with identity issues, grew up in N Wales :)",
  "id" : 523169058452422656,
  "in_reply_to_status_id" : 523145418645860352,
  "created_at" : "2014-10-17 17:49:58 +0000",
  "in_reply_to_screen_name" : "DavidHarbinson",
  "in_reply_to_user_id_str" : "853078675",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alannah Fitzgerald",
      "screen_name" : "AlannahFitz",
      "indices" : [ 3, 15 ],
      "id_str" : "223613160",
      "id" : 223613160
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/AlannahFitz\/status\/523162013569011712\/photo\/1",
      "indices" : [ 143, 144 ],
      "url" : "http:\/\/t.co\/WVrSVtjH2Y",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0KlFE4CcAEPN5h.jpg",
      "id_str" : "523162013355110401",
      "id" : 523162013355110401,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0KlFE4CcAEPN5h.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/WVrSVtjH2Y"
    } ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 97, 105 ]
    }, {
      "text" : "corp",
      "indices" : [ 106, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/wephMmwu1F",
      "expanded_url" : "http:\/\/fplus.me\/p\/a5Wp\/541c5fc9",
      "display_url" : "fplus.me\/p\/a5Wp\/541c5fc9"
    } ]
  },
  "geo" : { },
  "id_str" : "523168667832709120",
  "text" : "RT @AlannahFitz: FLAX: Flexible Language Acquisition with Open &amp; Linked Data-Driven Learning #eltchat #corp... http:\/\/t.co\/wephMmwu1F http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/friendsplus.me\" rel=\"nofollow\"\u003EFriends Me\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/AlannahFitz\/status\/523162013569011712\/photo\/1",
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/WVrSVtjH2Y",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B0KlFE4CcAEPN5h.jpg",
        "id_str" : "523162013355110401",
        "id" : 523162013355110401,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0KlFE4CcAEPN5h.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/WVrSVtjH2Y"
      } ],
      "hashtags" : [ {
        "text" : "eltchat",
        "indices" : [ 80, 88 ]
      }, {
        "text" : "corp",
        "indices" : [ 89, 94 ]
      } ],
      "urls" : [ {
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/wephMmwu1F",
        "expanded_url" : "http:\/\/fplus.me\/p\/a5Wp\/541c5fc9",
        "display_url" : "fplus.me\/p\/a5Wp\/541c5fc9"
      } ]
    },
    "geo" : { },
    "id_str" : "523162013569011712",
    "text" : "FLAX: Flexible Language Acquisition with Open &amp; Linked Data-Driven Learning #eltchat #corp... http:\/\/t.co\/wephMmwu1F http:\/\/t.co\/WVrSVtjH2Y",
    "id" : 523162013569011712,
    "created_at" : "2014-10-17 17:21:58 +0000",
    "user" : {
      "name" : "Alannah Fitzgerald",
      "screen_name" : "AlannahFitz",
      "protected" : false,
      "id_str" : "223613160",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2645381550\/e07d3b354efdac11bce2725cbc44e94e_normal.png",
      "id" : 223613160,
      "verified" : false
    }
  },
  "id" : 523168667832709120,
  "created_at" : "2014-10-17 17:48:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Harbinson",
      "screen_name" : "DavidHarbinson",
      "indices" : [ 64, 79 ],
      "id_str" : "853078675",
      "id" : 853078675
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/bltXvVl9Jp",
      "expanded_url" : "http:\/\/davidharbinson.com\/where-am-i-from-an-identity-crisis\/",
      "display_url" : "davidharbinson.com\/where-am-i-fro\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "523066480393334784",
  "text" : "Where am I from? An identity crisis? http:\/\/t.co\/bltXvVl9Jp via @DavidHarbinson",
  "id" : 523066480393334784,
  "created_at" : "2014-10-17 11:02:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELF Pron",
      "screen_name" : "ELF_Pron",
      "indices" : [ 3, 12 ],
      "id_str" : "2222993041",
      "id" : 2222993041
    }, {
      "name" : "Laura Patsko",
      "screen_name" : "lauraahaha",
      "indices" : [ 65, 76 ],
      "id_str" : "97957137",
      "id" : 97957137
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELF7",
      "indices" : [ 14, 19 ]
    }, {
      "text" : "elf",
      "indices" : [ 101, 105 ]
    }, {
      "text" : "elt",
      "indices" : [ 106, 110 ]
    }, {
      "text" : "efl",
      "indices" : [ 111, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/g8Kt2ZlQj5",
      "expanded_url" : "http:\/\/wp.me\/p3RMIO-aY",
      "display_url" : "wp.me\/p3RMIO-aY"
    } ]
  },
  "geo" : { },
  "id_str" : "523065231980130304",
  "text" : "RT @ELF_Pron: #ELF7 conference videos - including ELF Pron's own @lauraahaha! http:\/\/t.co\/g8Kt2ZlQj5 #elf #elt #efl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Laura Patsko",
        "screen_name" : "lauraahaha",
        "indices" : [ 51, 62 ],
        "id_str" : "97957137",
        "id" : 97957137
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELF7",
        "indices" : [ 0, 5 ]
      }, {
        "text" : "elf",
        "indices" : [ 87, 91 ]
      }, {
        "text" : "elt",
        "indices" : [ 92, 96 ]
      }, {
        "text" : "efl",
        "indices" : [ 97, 101 ]
      } ],
      "urls" : [ {
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/g8Kt2ZlQj5",
        "expanded_url" : "http:\/\/wp.me\/p3RMIO-aY",
        "display_url" : "wp.me\/p3RMIO-aY"
      } ]
    },
    "geo" : { },
    "id_str" : "523034707932377088",
    "text" : "#ELF7 conference videos - including ELF Pron's own @lauraahaha! http:\/\/t.co\/g8Kt2ZlQj5 #elf #elt #efl",
    "id" : 523034707932377088,
    "created_at" : "2014-10-17 08:56:06 +0000",
    "user" : {
      "name" : "ELF Pron",
      "screen_name" : "ELF_Pron",
      "protected" : false,
      "id_str" : "2222993041",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000810319252\/5d68e01ce8657e7d2936912db7c4b601_normal.png",
      "id" : 2222993041,
      "verified" : false
    }
  },
  "id" : 523065231980130304,
  "created_at" : "2014-10-17 10:57:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 12, 23 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/5agjEPk9zg",
      "expanded_url" : "https:\/\/www.futurelearn.com\/courses\/corpus-linguistics-2014-q3\/steps\/14802\/progress?page=1#comment_2192650",
      "display_url" : "futurelearn.com\/courses\/corpus\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "522966579190185984",
  "text" : "interesting #corpusmooc fact claws tagger can identify multi-word units as ditto tags https:\/\/t.co\/5agjEPk9zg",
  "id" : 522966579190185984,
  "created_at" : "2014-10-17 04:25:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amit Agarwal",
      "screen_name" : "labnol",
      "indices" : [ 3, 10 ],
      "id_str" : "724473",
      "id" : 724473
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/labnol\/status\/522730198123311105\/photo\/1",
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/Stfspl1oQt",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/B0EcVtECIAId-fX.png",
      "id_str" : "522730190951030786",
      "id" : 522730190951030786,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/B0EcVtECIAId-fX.png",
      "sizes" : [ {
        "h" : 296,
        "resize" : "fit",
        "w" : 656
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 296,
        "resize" : "fit",
        "w" : 656
      }, {
        "h" : 271,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 153,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Stfspl1oQt"
    } ],
    "hashtags" : [ {
      "text" : "GIF",
      "indices" : [ 61, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/gV1FofrhII",
      "expanded_url" : "http:\/\/labnol.org\/?p=28698",
      "display_url" : "labnol.org\/?p=28698"
    } ]
  },
  "geo" : { },
  "id_str" : "522861329083015168",
  "text" : "RT @labnol: Quick demo of multilingual chat in Google Sheets #GIF http:\/\/t.co\/gV1FofrhII http:\/\/t.co\/Stfspl1oQt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/labnol\/status\/522730198123311105\/photo\/1",
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/Stfspl1oQt",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/B0EcVtECIAId-fX.png",
        "id_str" : "522730190951030786",
        "id" : 522730190951030786,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/B0EcVtECIAId-fX.png",
        "sizes" : [ {
          "h" : 296,
          "resize" : "fit",
          "w" : 656
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 296,
          "resize" : "fit",
          "w" : 656
        }, {
          "h" : 271,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 153,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Stfspl1oQt"
      } ],
      "hashtags" : [ {
        "text" : "GIF",
        "indices" : [ 49, 53 ]
      } ],
      "urls" : [ {
        "indices" : [ 54, 76 ],
        "url" : "http:\/\/t.co\/gV1FofrhII",
        "expanded_url" : "http:\/\/labnol.org\/?p=28698",
        "display_url" : "labnol.org\/?p=28698"
      } ]
    },
    "in_reply_to_status_id_str" : "522722217214611456",
    "geo" : { },
    "id_str" : "522730198123311105",
    "in_reply_to_user_id" : 724473,
    "text" : "Quick demo of multilingual chat in Google Sheets #GIF http:\/\/t.co\/gV1FofrhII http:\/\/t.co\/Stfspl1oQt",
    "id" : 522730198123311105,
    "in_reply_to_status_id" : 522722217214611456,
    "created_at" : "2014-10-16 12:46:05 +0000",
    "in_reply_to_screen_name" : "labnol",
    "in_reply_to_user_id_str" : "724473",
    "user" : {
      "name" : "Amit Agarwal",
      "screen_name" : "labnol",
      "protected" : false,
      "id_str" : "724473",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/641572075321229312\/3f_9iwzr_normal.jpg",
      "id" : 724473,
      "verified" : true
    }
  },
  "id" : 522861329083015168,
  "created_at" : "2014-10-16 21:27:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "indices" : [ 3, 19 ],
      "id_str" : "1326508478",
      "id" : 1326508478
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/oaG4Tek69l",
      "expanded_url" : "http:\/\/cass.lancs.ac.uk\/?p=1455",
      "display_url" : "cass.lancs.ac.uk\/?p=1455"
    } ]
  },
  "geo" : { },
  "id_str" : "522773952729710592",
  "text" : "RT @CorpusSocialSci: New blog providing more insights from our audio transcribers, \"A Journey into Transcription, Part 3: Clarity\" http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/oaG4Tek69l",
        "expanded_url" : "http:\/\/cass.lancs.ac.uk\/?p=1455",
        "display_url" : "cass.lancs.ac.uk\/?p=1455"
      } ]
    },
    "geo" : { },
    "id_str" : "522701133605654530",
    "text" : "New blog providing more insights from our audio transcribers, \"A Journey into Transcription, Part 3: Clarity\" http:\/\/t.co\/oaG4Tek69l",
    "id" : 522701133605654530,
    "created_at" : "2014-10-16 10:50:36 +0000",
    "user" : {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "protected" : false,
      "id_str" : "1326508478",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3493899777\/ced36fe15c32eb911cbe3d64377524dc_normal.jpeg",
      "id" : 1326508478,
      "verified" : false
    }
  },
  "id" : 522773952729710592,
  "created_at" : "2014-10-16 15:39:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paul braddock",
      "screen_name" : "bcnpaul1",
      "indices" : [ 3, 12 ],
      "id_str" : "130975050",
      "id" : 130975050
    }, {
      "name" : "Luke Meddings",
      "screen_name" : "LukeMeddings",
      "indices" : [ 66, 79 ],
      "id_str" : "39718253",
      "id" : 39718253
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/nDSm0fMAlP",
      "expanded_url" : "http:\/\/lukemeddings.com\/2014\/10\/someone-to-watch-over-me\/",
      "display_url" : "lukemeddings.com\/2014\/10\/someon\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "522692532921462784",
  "text" : "RT @bcnpaul1: 'Someone to watch over me' an interesting read from @LukeMeddings http:\/\/t.co\/nDSm0fMAlP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Luke Meddings",
        "screen_name" : "LukeMeddings",
        "indices" : [ 52, 65 ],
        "id_str" : "39718253",
        "id" : 39718253
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 88 ],
        "url" : "http:\/\/t.co\/nDSm0fMAlP",
        "expanded_url" : "http:\/\/lukemeddings.com\/2014\/10\/someone-to-watch-over-me\/",
        "display_url" : "lukemeddings.com\/2014\/10\/someon\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "522688320149921792",
    "text" : "'Someone to watch over me' an interesting read from @LukeMeddings http:\/\/t.co\/nDSm0fMAlP",
    "id" : 522688320149921792,
    "created_at" : "2014-10-16 09:59:41 +0000",
    "user" : {
      "name" : "paul braddock",
      "screen_name" : "bcnpaul1",
      "protected" : false,
      "id_str" : "130975050",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/537231504334540800\/NqpmAh0J_normal.jpeg",
      "id" : 130975050,
      "verified" : false
    }
  },
  "id" : 522692532921462784,
  "created_at" : "2014-10-16 10:16:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Hardie",
      "screen_name" : "HardieResearch",
      "indices" : [ 3, 18 ],
      "id_str" : "970452764",
      "id" : 970452764
    }, {
      "name" : "(((David Futrelle)))",
      "screen_name" : "DavidFutrelle",
      "indices" : [ 68, 82 ],
      "id_str" : "348174495",
      "id" : 348174495
    }, {
      "name" : "Forensic Linguistics",
      "screen_name" : "FORGE_LU",
      "indices" : [ 128, 137 ],
      "id_str" : "2211139201",
      "id" : 2211139201
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/fyyTD1kbNz",
      "expanded_url" : "http:\/\/wehuntedthemammoth.com\/2014\/10\/15\/the-threats-that-shut-down-anita-sarkeesians-talk-come-from-someone-who-seems-to-be-deeply-steeped-in-the-misogynstic-mens-rights-subculture\/",
      "display_url" : "wehuntedthemammoth.com\/2014\/10\/15\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "522621458238148608",
  "text" : "RT @HardieResearch: \"where does the language of hatred...come from?\"@DavidFutrelle applies forensic linguistics to webcorpus cc @FORGE_LU h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "(((David Futrelle)))",
        "screen_name" : "DavidFutrelle",
        "indices" : [ 48, 62 ],
        "id_str" : "348174495",
        "id" : 348174495
      }, {
        "name" : "Forensic Linguistics",
        "screen_name" : "FORGE_LU",
        "indices" : [ 108, 117 ],
        "id_str" : "2211139201",
        "id" : 2211139201
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/fyyTD1kbNz",
        "expanded_url" : "http:\/\/wehuntedthemammoth.com\/2014\/10\/15\/the-threats-that-shut-down-anita-sarkeesians-talk-come-from-someone-who-seems-to-be-deeply-steeped-in-the-misogynstic-mens-rights-subculture\/",
        "display_url" : "wehuntedthemammoth.com\/2014\/10\/15\/the\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "522554820495155200",
    "text" : "\"where does the language of hatred...come from?\"@DavidFutrelle applies forensic linguistics to webcorpus cc @FORGE_LU http:\/\/t.co\/fyyTD1kbNz",
    "id" : 522554820495155200,
    "created_at" : "2014-10-16 01:09:12 +0000",
    "user" : {
      "name" : "Andrew Hardie",
      "screen_name" : "HardieResearch",
      "protected" : false,
      "id_str" : "970452764",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2895091886\/5274f8f34de87999703c0f92adfdf465_normal.jpeg",
      "id" : 970452764,
      "verified" : false
    }
  },
  "id" : 522621458238148608,
  "created_at" : "2014-10-16 05:34:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 40, 56 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/WsjW7j7r1y",
      "expanded_url" : "http:\/\/wp.me\/pBWu-1Cj",
      "display_url" : "wp.me\/pBWu-1Cj"
    } ]
  },
  "geo" : { },
  "id_str" : "522239089878122497",
  "text" : "Tense Travel http:\/\/t.co\/WsjW7j7r1y via @wordpressdotcom",
  "id" : 522239089878122497,
  "created_at" : "2014-10-15 04:14:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil Tubman",
      "screen_name" : "philtubman",
      "indices" : [ 0, 11 ],
      "id_str" : "32418010",
      "id" : 32418010
    }, {
      "name" : "FutureLearn",
      "screen_name" : "FutureLearn",
      "indices" : [ 12, 24 ],
      "id_str" : "999095640",
      "id" : 999095640
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "522106812343283713",
  "geo" : { },
  "id_str" : "522130606474657792",
  "in_reply_to_user_id" : 32418010,
  "text" : "@philtubman @FutureLearn okay thought not even getting 100 on page getting 50, sure saw paging feature a few times before?",
  "id" : 522130606474657792,
  "in_reply_to_status_id" : 522106812343283713,
  "created_at" : "2014-10-14 21:03:31 +0000",
  "in_reply_to_screen_name" : "philtubman",
  "in_reply_to_user_id_str" : "32418010",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FOCUS Project",
      "screen_name" : "FOCUS_projectDU",
      "indices" : [ 3, 19 ],
      "id_str" : "835675381",
      "id" : 835675381
    }, {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 100, 116 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/vo9V8lalmE",
      "expanded_url" : "http:\/\/wp.me\/p2I5hp-3g",
      "display_url" : "wp.me\/p2I5hp-3g"
    } ]
  },
  "geo" : { },
  "id_str" : "521767932930830336",
  "text" : "RT @FOCUS_projectDU: Using FOCUS tool to improve academic writing skills http:\/\/t.co\/vo9V8lalmE via @wordpressdotcom",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "WordPress.com",
        "screen_name" : "wordpressdotcom",
        "indices" : [ 79, 95 ],
        "id_str" : "823905",
        "id" : 823905
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/vo9V8lalmE",
        "expanded_url" : "http:\/\/wp.me\/p2I5hp-3g",
        "display_url" : "wp.me\/p2I5hp-3g"
      } ]
    },
    "geo" : { },
    "id_str" : "521481895767322624",
    "text" : "Using FOCUS tool to improve academic writing skills http:\/\/t.co\/vo9V8lalmE via @wordpressdotcom",
    "id" : 521481895767322624,
    "created_at" : "2014-10-13 02:05:47 +0000",
    "user" : {
      "name" : "FOCUS Project",
      "screen_name" : "FOCUS_projectDU",
      "protected" : false,
      "id_str" : "835675381",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459714720799281152\/-kWJAQxJ_normal.png",
      "id" : 835675381,
      "verified" : false
    }
  },
  "id" : 521767932930830336,
  "created_at" : "2014-10-13 21:02:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/JfXzNEZgjn",
      "expanded_url" : "http:\/\/eveningharold.com\/2014\/10\/13\/bbc-to-launch-its-own-nigel-farage-channel\/",
      "display_url" : "eveningharold.com\/2014\/10\/13\/bbc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "521745547250503680",
  "text" : "BBC to launch its own Nigel Farage channel http:\/\/t.co\/JfXzNEZgjn",
  "id" : 521745547250503680,
  "created_at" : "2014-10-13 19:33:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Cook",
      "screen_name" : "idc74",
      "indices" : [ 0, 6 ],
      "id_str" : "290521216",
      "id" : 290521216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "521743470034440192",
  "geo" : { },
  "id_str" : "521743919978405888",
  "in_reply_to_user_id" : 290521216,
  "text" : "@idc74 yes and thank the stars there's only one of him :)",
  "id" : 521743919978405888,
  "in_reply_to_status_id" : 521743470034440192,
  "created_at" : "2014-10-13 19:26:58 +0000",
  "in_reply_to_screen_name" : "idc74",
  "in_reply_to_user_id_str" : "290521216",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Cook",
      "screen_name" : "idc74",
      "indices" : [ 0, 6 ],
      "id_str" : "290521216",
      "id" : 290521216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "521740829250318336",
  "geo" : { },
  "id_str" : "521742080004325376",
  "in_reply_to_user_id" : 290521216,
  "text" : "@idc74 that's 5% less doctors\/nurses to train i suppose :\/",
  "id" : 521742080004325376,
  "in_reply_to_status_id" : 521740829250318336,
  "created_at" : "2014-10-13 19:19:40 +0000",
  "in_reply_to_screen_name" : "idc74",
  "in_reply_to_user_id_str" : "290521216",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "indices" : [ 3, 18 ],
      "id_str" : "27716419",
      "id" : 27716419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/CPUTevlByd",
      "expanded_url" : "http:\/\/bit.ly\/1wty6dY",
      "display_url" : "bit.ly\/1wty6dY"
    } ]
  },
  "geo" : { },
  "id_str" : "521697126460706816",
  "text" : "RT @CraigMurrayOrg: New post: Neo-Con Speed Dating http:\/\/t.co\/CPUTevlByd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.craigmurray.org.uk\" rel=\"nofollow\"\u003ECraig Murray posting plugin\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 31, 53 ],
        "url" : "http:\/\/t.co\/CPUTevlByd",
        "expanded_url" : "http:\/\/bit.ly\/1wty6dY",
        "display_url" : "bit.ly\/1wty6dY"
      } ]
    },
    "geo" : { },
    "id_str" : "521694905526001665",
    "text" : "New post: Neo-Con Speed Dating http:\/\/t.co\/CPUTevlByd",
    "id" : 521694905526001665,
    "created_at" : "2014-10-13 16:12:12 +0000",
    "user" : {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "protected" : false,
      "id_str" : "27716419",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1388436826\/cm_normal.jpg",
      "id" : 27716419,
      "verified" : false
    }
  },
  "id" : 521697126460706816,
  "created_at" : "2014-10-13 16:21:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil Tubman",
      "screen_name" : "philtubman",
      "indices" : [ 0, 11 ],
      "id_str" : "32418010",
      "id" : 32418010
    }, {
      "name" : "FutureLearn",
      "screen_name" : "FutureLearn",
      "indices" : [ 34, 46 ],
      "id_str" : "999095640",
      "id" : 999095640
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "521680063088328704",
  "in_reply_to_user_id" : 32418010,
  "text" : "@philtubman hi phil do u know why @FutureLearn activity feed is not showing previous pages? thx",
  "id" : 521680063088328704,
  "created_at" : "2014-10-13 15:13:14 +0000",
  "in_reply_to_screen_name" : "philtubman",
  "in_reply_to_user_id_str" : "32418010",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kathy Fagan",
      "screen_name" : "eslkathy",
      "indices" : [ 3, 12 ],
      "id_str" : "303849696",
      "id" : 303849696
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusMOOC",
      "indices" : [ 31, 42 ]
    }, {
      "text" : "ESL",
      "indices" : [ 109, 113 ]
    }, {
      "text" : "EFL",
      "indices" : [ 114, 118 ]
    }, {
      "text" : "ELT",
      "indices" : [ 119, 123 ]
    }, {
      "text" : "linguistics",
      "indices" : [ 124, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/7mB8xJAYaC",
      "expanded_url" : "http:\/\/ow.ly\/CDseF",
      "display_url" : "ow.ly\/CDseF"
    } ]
  },
  "geo" : { },
  "id_str" : "521679359078567936",
  "text" : "RT @eslkathy: Love the way the #corpusMOOC (in progress) is organized!  Details here: http:\/\/t.co\/7mB8xJAYaC #ESL #EFL #ELT #linguistics",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpusMOOC",
        "indices" : [ 17, 28 ]
      }, {
        "text" : "ESL",
        "indices" : [ 95, 99 ]
      }, {
        "text" : "EFL",
        "indices" : [ 100, 104 ]
      }, {
        "text" : "ELT",
        "indices" : [ 105, 109 ]
      }, {
        "text" : "linguistics",
        "indices" : [ 110, 122 ]
      } ],
      "urls" : [ {
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/7mB8xJAYaC",
        "expanded_url" : "http:\/\/ow.ly\/CDseF",
        "display_url" : "ow.ly\/CDseF"
      } ]
    },
    "geo" : { },
    "id_str" : "521357568837697536",
    "text" : "Love the way the #corpusMOOC (in progress) is organized!  Details here: http:\/\/t.co\/7mB8xJAYaC #ESL #EFL #ELT #linguistics",
    "id" : 521357568837697536,
    "created_at" : "2014-10-12 17:51:45 +0000",
    "user" : {
      "name" : "Kathy Fagan",
      "screen_name" : "eslkathy",
      "protected" : false,
      "id_str" : "303849696",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1365916776\/eslkathy1_normal.jpg",
      "id" : 303849696,
      "verified" : false
    }
  },
  "id" : 521679359078567936,
  "created_at" : "2014-10-13 15:10:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kat Gupta",
      "screen_name" : "mixosaurus",
      "indices" : [ 3, 14 ],
      "id_str" : "21158543",
      "id" : 21158543
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CorpusMOOC",
      "indices" : [ 19, 30 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/Asm9hchcyv",
      "expanded_url" : "http:\/\/mixosaurus.co.uk\/2014\/10\/getting-the-most-out-of-corpusmooc\/",
      "display_url" : "mixosaurus.co.uk\/2014\/10\/gettin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "521679036318502912",
  "text" : "RT @mixosaurus: Hi #CorpusMOOC-ers! I wrote up some tips on getting the most out of the course - hope these help you: http:\/\/t.co\/Asm9hchcyv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CorpusMOOC",
        "indices" : [ 3, 14 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/Asm9hchcyv",
        "expanded_url" : "http:\/\/mixosaurus.co.uk\/2014\/10\/getting-the-most-out-of-corpusmooc\/",
        "display_url" : "mixosaurus.co.uk\/2014\/10\/gettin\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "521647978877308929",
    "text" : "Hi #CorpusMOOC-ers! I wrote up some tips on getting the most out of the course - hope these help you: http:\/\/t.co\/Asm9hchcyv",
    "id" : 521647978877308929,
    "created_at" : "2014-10-13 13:05:44 +0000",
    "user" : {
      "name" : "Kat Gupta",
      "screen_name" : "mixosaurus",
      "protected" : false,
      "id_str" : "21158543",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/497125168477523970\/a60pRivO_normal.png",
      "id" : 21158543,
      "verified" : false
    }
  },
  "id" : 521679036318502912,
  "created_at" : "2014-10-13 15:09:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Spencer",
      "screen_name" : "edrethink",
      "indices" : [ 3, 13 ],
      "id_str" : "3057524486",
      "id" : 3057524486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 126, 140 ],
      "url" : "http:\/\/t.co\/sKDIygH3Oh",
      "expanded_url" : "http:\/\/blogs.edweek.org\/teachers\/teaching_now\/2014\/10\/wrong_diagnosis_wrong_prescription_for_understaffing.html",
      "display_url" : "blogs.edweek.org\/teachers\/teach\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "521678079987818498",
  "text" : "RT @edrethink: Nobody wants to admit this, but the real reason teachers are leaving is that they're overworked and underpaid: http:\/\/t.co\/s\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/sKDIygH3Oh",
        "expanded_url" : "http:\/\/blogs.edweek.org\/teachers\/teaching_now\/2014\/10\/wrong_diagnosis_wrong_prescription_for_understaffing.html",
        "display_url" : "blogs.edweek.org\/teachers\/teach\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "521664371777224704",
    "text" : "Nobody wants to admit this, but the real reason teachers are leaving is that they're overworked and underpaid: http:\/\/t.co\/sKDIygH3Oh",
    "id" : 521664371777224704,
    "created_at" : "2014-10-13 14:10:52 +0000",
    "user" : {
      "name" : "John Spencer",
      "screen_name" : "spencerideas",
      "protected" : false,
      "id_str" : "18389166",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751913559160795136\/eU7NtYy4_normal.jpg",
      "id" : 18389166,
      "verified" : false
    }
  },
  "id" : 521678079987818498,
  "created_at" : "2014-10-13 15:05:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "521589480835125248",
  "geo" : { },
  "id_str" : "521591978245767168",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish hehe, youtube is becoming the new electronic babysitter taking over TV, 21stcentury guilt-leaden parenting :\/",
  "id" : 521591978245767168,
  "in_reply_to_status_id" : 521589480835125248,
  "created_at" : "2014-10-13 09:23:12 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 83, 98 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/JrSGpc1Dio",
      "expanded_url" : "http:\/\/wp.me\/p3qkCB-ZA",
      "display_url" : "wp.me\/p3qkCB-ZA"
    } ]
  },
  "geo" : { },
  "id_str" : "521588217837928448",
  "text" : "A Closer Look at Task-Based Language Teaching. Part 1.  http:\/\/t.co\/JrSGpc1Dio via @GeoffreyJordan",
  "id" : 521588217837928448,
  "created_at" : "2014-10-13 09:08:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "521581534282002433",
  "geo" : { },
  "id_str" : "521583449875185664",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl depends i am always amazed at the millions of hits for say transport related videos that my 2 yr old demands to watch...",
  "id" : 521583449875185664,
  "in_reply_to_status_id" : 521581534282002433,
  "created_at" : "2014-10-13 08:49:19 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shanthi Streat",
      "screen_name" : "ShanthiStreat",
      "indices" : [ 0, 14 ],
      "id_str" : "2159433601",
      "id" : 2159433601
    }, {
      "name" : "Vipula Sharma",
      "screen_name" : "VipulaSharma1",
      "indices" : [ 15, 29 ],
      "id_str" : "2204959478",
      "id" : 2204959478
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpus",
      "indices" : [ 46, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/sZ01SPHAtI",
      "expanded_url" : "http:\/\/corpus.byu.edu\/coca\/?c=coca&q=33662920",
      "display_url" : "corpus.byu.edu\/coca\/?c=coca&q\u2026"
    }, {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/tEUQNFSe8V",
      "expanded_url" : "http:\/\/corpus.byu.edu\/coca\/?c=coca&q=33662944",
      "display_url" : "corpus.byu.edu\/coca\/?c=coca&q\u2026"
    }, {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/4tKer0VJSR",
      "expanded_url" : "http:\/\/corpus.byu.edu\/coca\/?c=coca&q=33662967",
      "display_url" : "corpus.byu.edu\/coca\/?c=coca&q\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "521573752560050177",
  "geo" : { },
  "id_str" : "521580141043257344",
  "in_reply_to_user_id" : 2159433601,
  "text" : "@ShanthiStreat @VipulaSharma1 worth comparing #corpus frequencies http:\/\/t.co\/sZ01SPHAtI, http:\/\/t.co\/tEUQNFSe8V, http:\/\/t.co\/4tKer0VJSR",
  "id" : 521580141043257344,
  "in_reply_to_status_id" : 521573752560050177,
  "created_at" : "2014-10-13 08:36:10 +0000",
  "in_reply_to_screen_name" : "ShanthiStreat",
  "in_reply_to_user_id_str" : "2159433601",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Terry Elliott",
      "screen_name" : "telliowkuwp",
      "indices" : [ 0, 12 ],
      "id_str" : "326772515",
      "id" : 326772515
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ccourses",
      "indices" : [ 130, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/kPjNR0QwX7",
      "expanded_url" : "http:\/\/educationaltechnology.ca\/couros\/2482",
      "display_url" : "educationaltechnology.ca\/couros\/2482"
    } ]
  },
  "in_reply_to_status_id_str" : "521296960448262145",
  "geo" : { },
  "id_str" : "521561320815337472",
  "in_reply_to_user_id" : 326772515,
  "text" : "@telliowkuwp need healthy skepticism to wit connected educator meets realities of corporate connected tech http:\/\/t.co\/kPjNR0QwX7 #ccourses",
  "id" : 521561320815337472,
  "in_reply_to_status_id" : 521296960448262145,
  "created_at" : "2014-10-13 07:21:23 +0000",
  "in_reply_to_screen_name" : "telliowkuwp",
  "in_reply_to_user_id_str" : "326772515",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bret Victor",
      "screen_name" : "worrydream",
      "indices" : [ 3, 14 ],
      "id_str" : "255617445",
      "id" : 255617445
    }, {
      "name" : "Glench",
      "screen_name" : "Glench",
      "indices" : [ 123, 130 ],
      "id_str" : "14439652",
      "id" : 14439652
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/worrydream\/status\/507226062619566080\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/Gk1z34eZEf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BwoHan-CUAAtz77.jpg",
      "id_str" : "507226062019776512",
      "id" : 507226062019776512,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwoHan-CUAAtz77.jpg",
      "sizes" : [ {
        "h" : 382,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 382,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 382,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 216,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Gk1z34eZEf"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/m6fE78QpFd",
      "expanded_url" : "http:\/\/glench.com\/EyesOnThePrize\/",
      "display_url" : "glench.com\/EyesOnThePrize\/"
    } ]
  },
  "geo" : { },
  "id_str" : "521432332541382656",
  "text" : "RT @worrydream: Eyes on the Prize: a beautifully-done \"active video\". Watch+read+browse+explore. http:\/\/t.co\/m6fE78QpFd by @glench http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Glench",
        "screen_name" : "Glench",
        "indices" : [ 107, 114 ],
        "id_str" : "14439652",
        "id" : 14439652
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/worrydream\/status\/507226062619566080\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/Gk1z34eZEf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BwoHan-CUAAtz77.jpg",
        "id_str" : "507226062019776512",
        "id" : 507226062019776512,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwoHan-CUAAtz77.jpg",
        "sizes" : [ {
          "h" : 382,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 382,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 382,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 216,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Gk1z34eZEf"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/m6fE78QpFd",
        "expanded_url" : "http:\/\/glench.com\/EyesOnThePrize\/",
        "display_url" : "glench.com\/EyesOnThePrize\/"
      } ]
    },
    "geo" : { },
    "id_str" : "507226062619566080",
    "text" : "Eyes on the Prize: a beautifully-done \"active video\". Watch+read+browse+explore. http:\/\/t.co\/m6fE78QpFd by @glench http:\/\/t.co\/Gk1z34eZEf",
    "id" : 507226062619566080,
    "created_at" : "2014-09-03 17:58:11 +0000",
    "user" : {
      "name" : "Bret Victor",
      "screen_name" : "worrydream",
      "protected" : false,
      "id_str" : "255617445",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/767981637623685120\/7WgbPNE9_normal.jpg",
      "id" : 255617445,
      "verified" : false
    }
  },
  "id" : 521432332541382656,
  "created_at" : "2014-10-12 22:48:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alannah Fitzgerald",
      "screen_name" : "AlannahFitz",
      "indices" : [ 0, 12 ],
      "id_str" : "223613160",
      "id" : 223613160
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/l3diyqslbX",
      "expanded_url" : "http:\/\/flax.nzdl.org\/greenstone3\/flax?a=fp&sa=downloads",
      "display_url" : "flax.nzdl.org\/greenstone3\/fl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "521308384663199744",
  "in_reply_to_user_id" : 223613160,
  "text" : "@AlannahFitz hi are these d\/l sizes right as i am trying mac &amp; it is saying 2.9GB http:\/\/t.co\/l3diyqslbX",
  "id" : 521308384663199744,
  "created_at" : "2014-10-12 14:36:19 +0000",
  "in_reply_to_screen_name" : "AlannahFitz",
  "in_reply_to_user_id_str" : "223613160",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 3, 13 ],
      "id_str" : "525274103",
      "id" : 525274103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/vMEYjXskAM",
      "expanded_url" : "http:\/\/thoughtmaybe.com\/all-watched-over-by-machines-of-loving-grace\/",
      "display_url" : "thoughtmaybe.com\/all-watched-ov\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "521232674388983808",
  "text" : "RT @ElkySmith: Fascinating doco on history of computers and ideology - for anyone who doubts the two are intertwined. http:\/\/t.co\/vMEYjXskAM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/vMEYjXskAM",
        "expanded_url" : "http:\/\/thoughtmaybe.com\/all-watched-over-by-machines-of-loving-grace\/",
        "display_url" : "thoughtmaybe.com\/all-watched-ov\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "521232016813989889",
    "text" : "Fascinating doco on history of computers and ideology - for anyone who doubts the two are intertwined. http:\/\/t.co\/vMEYjXskAM",
    "id" : 521232016813989889,
    "created_at" : "2014-10-12 09:32:51 +0000",
    "user" : {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "protected" : false,
      "id_str" : "525274103",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/690658566370263041\/qggTYEb3_normal.jpg",
      "id" : 525274103,
      "verified" : false
    }
  },
  "id" : 521232674388983808,
  "created_at" : "2014-10-12 09:35:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShareThis",
      "screen_name" : "ShareThis",
      "indices" : [ 114, 124 ],
      "id_str" : "14116807",
      "id" : 14116807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/oPtHziTXB2",
      "expanded_url" : "http:\/\/shar.es\/1muKjk",
      "display_url" : "shar.es\/1muKjk"
    } ]
  },
  "geo" : { },
  "id_str" : "521231285918789632",
  "text" : "Democracy and Education in the 21st Century and Beyond: An Interview With Noam Chomsky http:\/\/t.co\/oPtHziTXB2 via @sharethis",
  "id" : 521231285918789632,
  "created_at" : "2014-10-12 09:29:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Popular Resistance",
      "screen_name" : "PopResistance",
      "indices" : [ 71, 85 ],
      "id_str" : "312755256",
      "id" : 312755256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/wda1OdpEPk",
      "expanded_url" : "http:\/\/www.popularresistance.org\/ebola-us-sends-troops-cuba-sends-doctors\/",
      "display_url" : "popularresistance.org\/ebola-us-sends\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "520862385360232448",
  "text" : "Ebola: US Sends Troops, Cuba Sends Doctors  http:\/\/t.co\/wda1OdpEPk via @PopResistance",
  "id" : 520862385360232448,
  "created_at" : "2014-10-11 09:04:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "indices" : [ 0, 9 ],
      "id_str" : "167020390",
      "id" : 167020390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "520710057252880384",
  "geo" : { },
  "id_str" : "520710871153397760",
  "in_reply_to_user_id" : 167020390,
  "text" : "@antlabjp nope",
  "id" : 520710871153397760,
  "in_reply_to_status_id" : 520710057252880384,
  "created_at" : "2014-10-10 23:02:00 +0000",
  "in_reply_to_screen_name" : "antlabjp",
  "in_reply_to_user_id_str" : "167020390",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "indices" : [ 0, 9 ],
      "id_str" : "167020390",
      "id" : 167020390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "520708218369347585",
  "geo" : { },
  "id_str" : "520709104571273217",
  "in_reply_to_user_id" : 167020390,
  "text" : "@antlabjp ah paywall :\/",
  "id" : 520709104571273217,
  "in_reply_to_status_id" : 520708218369347585,
  "created_at" : "2014-10-10 22:54:59 +0000",
  "in_reply_to_screen_name" : "antlabjp",
  "in_reply_to_user_id_str" : "167020390",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "indices" : [ 0, 9 ],
      "id_str" : "167020390",
      "id" : 167020390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/lsT8RpAxcR",
      "expanded_url" : "http:\/\/www.laurenceanthony.net\/software\/antmover100\/README_antmover1.0.txt",
      "display_url" : "laurenceanthony.net\/software\/antmo\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "520705525185781761",
  "geo" : { },
  "id_str" : "520706669723275265",
  "in_reply_to_user_id" : 167020390,
  "text" : "@antlabjp this one http:\/\/t.co\/lsT8RpAxcR",
  "id" : 520706669723275265,
  "in_reply_to_status_id" : 520705525185781761,
  "created_at" : "2014-10-10 22:45:18 +0000",
  "in_reply_to_screen_name" : "antlabjp",
  "in_reply_to_user_id_str" : "167020390",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "indices" : [ 0, 9 ],
      "id_str" : "167020390",
      "id" : 167020390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/gZv6hpFFFY",
      "expanded_url" : "http:\/\/antpc1.ice.ous.ac.jp\/Abs&Sums\/cilfe2003\/cilfe_abs_2003.htm",
      "display_url" : "antpc1.ice.ous.ac.jp\/Abs&Sums\/cilfe\u2026"
    }, {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/myTqzQhZ9P",
      "expanded_url" : "http:\/\/antpc1.ice.ous.ac.jp\/Abs&Sums\/cilfe2003\/Cilfe_Pres_2003.files\/frame.htm",
      "display_url" : "antpc1.ice.ous.ac.jp\/Abs&Sums\/cilfe\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "520700419425992704",
  "geo" : { },
  "id_str" : "520704736564379650",
  "in_reply_to_user_id" : 167020390,
  "text" : "@antlabjp hi these ones http:\/\/t.co\/gZv6hpFFFY, http:\/\/t.co\/myTqzQhZ9P thx",
  "id" : 520704736564379650,
  "in_reply_to_status_id" : 520700419425992704,
  "created_at" : "2014-10-10 22:37:38 +0000",
  "in_reply_to_screen_name" : "antlabjp",
  "in_reply_to_user_id_str" : "167020390",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "indices" : [ 40, 55 ],
      "id_str" : "27716419",
      "id" : 27716419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/pY4mJESRAx",
      "expanded_url" : "http:\/\/www.craigmurray.org.uk\/archives\/2014\/10\/an-ugly-mood\/",
      "display_url" : "craigmurray.org.uk\/archives\/2014\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "520670301332316160",
  "text" : "An Ugly Mood http:\/\/t.co\/pY4mJESRAx via @CraigMurrayOrg",
  "id" : 520670301332316160,
  "created_at" : "2014-10-10 20:20:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/2FiuIIYw6x",
      "expanded_url" : "http:\/\/members5.boardhost.com\/medialens\/msg\/1412962962.html",
      "display_url" : "members5.boardhost.com\/medialens\/msg\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "520669590104588288",
  "text" : "Snowmail: Taking the piss out of Kim Jong-un...short email to Guru-Murthy http:\/\/t.co\/2FiuIIYw6x",
  "id" : 520669590104588288,
  "created_at" : "2014-10-10 20:17:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Bex Lewis",
      "screen_name" : "drbexl",
      "indices" : [ 3, 10 ],
      "id_str" : "17446633",
      "id" : 17446633
    }, {
      "name" : "Dr Bex Lewis",
      "screen_name" : "drbexl",
      "indices" : [ 44, 51 ],
      "id_str" : "17446633",
      "id" : 17446633
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CORPUSMOOC",
      "indices" : [ 12, 23 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/9qx9yg4BOW",
      "expanded_url" : "http:\/\/wp.me\/p39dN1-1Br",
      "display_url" : "wp.me\/p39dN1-1Br"
    } ]
  },
  "geo" : { },
  "id_str" : "520668648181354496",
  "text" : "RT @drbexl: #CORPUSMOOC : Week 2 Notes from\u00A0@drbexl http:\/\/t.co\/9qx9yg4BOW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dr Bex Lewis",
        "screen_name" : "drbexl",
        "indices" : [ 32, 39 ],
        "id_str" : "17446633",
        "id" : 17446633
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CORPUSMOOC",
        "indices" : [ 0, 11 ]
      } ],
      "urls" : [ {
        "indices" : [ 40, 62 ],
        "url" : "http:\/\/t.co\/9qx9yg4BOW",
        "expanded_url" : "http:\/\/wp.me\/p39dN1-1Br",
        "display_url" : "wp.me\/p39dN1-1Br"
      } ]
    },
    "geo" : { },
    "id_str" : "520662096959119360",
    "text" : "#CORPUSMOOC : Week 2 Notes from\u00A0@drbexl http:\/\/t.co\/9qx9yg4BOW",
    "id" : 520662096959119360,
    "created_at" : "2014-10-10 19:48:12 +0000",
    "user" : {
      "name" : "Dr Bex Lewis",
      "screen_name" : "drbexl",
      "protected" : false,
      "id_str" : "17446633",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733719568460480517\/-1BSbv9u_normal.jpg",
      "id" : 17446633,
      "verified" : false
    }
  },
  "id" : 520668648181354496,
  "created_at" : "2014-10-10 20:14:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((David Traynier)))",
      "screen_name" : "DTraynier",
      "indices" : [ 3, 13 ],
      "id_str" : "317716198",
      "id" : 317716198
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "520666946891943937",
  "text" : "RT @DTraynier: What sort of 'advanced' society is it, where so many people wish away five days of the week to get to the remaining two?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/seesmic.com\/\" rel=\"nofollow\"\u003ESeesmic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "520611013956468737",
    "text" : "What sort of 'advanced' society is it, where so many people wish away five days of the week to get to the remaining two?",
    "id" : 520611013956468737,
    "created_at" : "2014-10-10 16:25:12 +0000",
    "user" : {
      "name" : "(((David Traynier)))",
      "screen_name" : "DTraynier",
      "protected" : false,
      "id_str" : "317716198",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727929911877480451\/fLuwL370_normal.jpg",
      "id" : 317716198,
      "verified" : false
    }
  },
  "id" : 520666946891943937,
  "created_at" : "2014-10-10 20:07:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "indices" : [ 0, 9 ],
      "id_str" : "167020390",
      "id" : 167020390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "520638613986766848",
  "in_reply_to_user_id" : 167020390,
  "text" : "@antlabjp hi trying to read more about antmover but links in readme are dead?",
  "id" : 520638613986766848,
  "created_at" : "2014-10-10 18:14:53 +0000",
  "in_reply_to_screen_name" : "antlabjp",
  "in_reply_to_user_id_str" : "167020390",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CP MacLochlainn",
      "screen_name" : "CPMacL2008",
      "indices" : [ 3, 14 ],
      "id_str" : "733617661",
      "id" : 733617661
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/CPMacL2008\/status\/520507551432335360\/photo\/1",
      "indices" : [ 126, 140 ],
      "url" : "http:\/\/t.co\/gbfnfXBVBA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bzk225GIAAAyBGC.jpg",
      "id_str" : "520507548605349888",
      "id" : 520507548605349888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bzk225GIAAAyBGC.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 681,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1362,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/gbfnfXBVBA"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/O8VxdspcdI",
      "expanded_url" : "http:\/\/bitly.com\/1BScARV",
      "display_url" : "bitly.com\/1BScARV"
    } ]
  },
  "geo" : { },
  "id_str" : "520631367563247616",
  "text" : "RT @CPMacL2008: Tony Blair and Henry Kissinger. And their Epic Crimes against Humanity, by John Pilger http:\/\/t.co\/O8VxdspcdI http:\/\/t.co\/g\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/CPMacL2008\/status\/520507551432335360\/photo\/1",
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/gbfnfXBVBA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bzk225GIAAAyBGC.jpg",
        "id_str" : "520507548605349888",
        "id" : 520507548605349888,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bzk225GIAAAyBGC.jpg",
        "sizes" : [ {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 681,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1362,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/gbfnfXBVBA"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/O8VxdspcdI",
        "expanded_url" : "http:\/\/bitly.com\/1BScARV",
        "display_url" : "bitly.com\/1BScARV"
      } ]
    },
    "geo" : { },
    "id_str" : "520507551432335360",
    "text" : "Tony Blair and Henry Kissinger. And their Epic Crimes against Humanity, by John Pilger http:\/\/t.co\/O8VxdspcdI http:\/\/t.co\/gbfnfXBVBA",
    "id" : 520507551432335360,
    "created_at" : "2014-10-10 09:34:05 +0000",
    "user" : {
      "name" : "CP MacLochlainn",
      "screen_name" : "CPMacL2008",
      "protected" : false,
      "id_str" : "733617661",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000304978111\/63fba6721445c3d5b93a8e390735abae_normal.jpeg",
      "id" : 733617661,
      "verified" : false
    }
  },
  "id" : 520631367563247616,
  "created_at" : "2014-10-10 17:46:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marsha Dowie",
      "screen_name" : "Marsha_LD",
      "indices" : [ 3, 13 ],
      "id_str" : "128983075",
      "id" : 128983075
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CorpusMOOC",
      "indices" : [ 41, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/y1XF9K5b3D",
      "expanded_url" : "http:\/\/marshasgraduateblog.wordpress.com\/2014\/10\/09\/corpus-mooc-week-1\/",
      "display_url" : "marshasgraduateblog.wordpress.com\/2014\/10\/09\/cor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "520615937318604800",
  "text" : "RT @Marsha_LD: Finishing off this week's #CorpusMOOC materials. Meanwhile, a blog on what I learnt in week 1: http:\/\/t.co\/y1XF9K5b3D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CorpusMOOC",
        "indices" : [ 26, 37 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/y1XF9K5b3D",
        "expanded_url" : "http:\/\/marshasgraduateblog.wordpress.com\/2014\/10\/09\/corpus-mooc-week-1\/",
        "display_url" : "marshasgraduateblog.wordpress.com\/2014\/10\/09\/cor\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "520608395511230464",
    "text" : "Finishing off this week's #CorpusMOOC materials. Meanwhile, a blog on what I learnt in week 1: http:\/\/t.co\/y1XF9K5b3D",
    "id" : 520608395511230464,
    "created_at" : "2014-10-10 16:14:48 +0000",
    "user" : {
      "name" : "Marsha Dowie",
      "screen_name" : "Marsha_LD",
      "protected" : false,
      "id_str" : "128983075",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/768509076246564864\/zqtiMhAR_normal.jpg",
      "id" : 128983075,
      "verified" : false
    }
  },
  "id" : 520615937318604800,
  "created_at" : "2014-10-10 16:44:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RealGrammar",
      "indices" : [ 0, 12 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 36, 44 ]
    }, {
      "text" : "elt",
      "indices" : [ 45, 49 ]
    }, {
      "text" : "corpusmooc",
      "indices" : [ 54, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/z7UCdOwWHu",
      "expanded_url" : "http:\/\/www.macmillandictionary.com\/learn\/realgrammar.html",
      "display_url" : "macmillandictionary.com\/learn\/realgram\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "520602162863570944",
  "text" : "#RealGrammar http:\/\/t.co\/z7UCdOwWHu #eltchat #elt h\/t #corpusmooc",
  "id" : 520602162863570944,
  "created_at" : "2014-10-10 15:50:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Guardian",
      "screen_name" : "guardian",
      "indices" : [ 99, 108 ],
      "id_str" : "87818409",
      "id" : 87818409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/eD9HDObUZa",
      "expanded_url" : "http:\/\/gu.com\/p\/427e9\/tw",
      "display_url" : "gu.com\/p\/427e9\/tw"
    } ]
  },
  "geo" : { },
  "id_str" : "520582700625698817",
  "text" : "Satanic panic: how British agents stoked supernatural fears in Troubles http:\/\/t.co\/eD9HDObUZa via @guardian",
  "id" : 520582700625698817,
  "created_at" : "2014-10-10 14:32:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/520488761986383872\/photo\/1",
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/WdxcE5rhZ4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzklxSVIYAAC4Cr.png",
      "id_str" : "520488760602288128",
      "id" : 520488760602288128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzklxSVIYAAC4Cr.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 153,
        "resize" : "fit",
        "w" : 458
      }, {
        "h" : 153,
        "resize" : "fit",
        "w" : 458
      }, {
        "h" : 153,
        "resize" : "fit",
        "w" : 458
      }, {
        "h" : 114,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/WdxcE5rhZ4"
    } ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 47, 55 ]
    }, {
      "text" : "elt",
      "indices" : [ 56, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/4B8SVKN2xE",
      "expanded_url" : "http:\/\/webservices.ccl.kuleuven.be\/picto\/index_english.php",
      "display_url" : "webservices.ccl.kuleuven.be\/picto\/index_en\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "520488761986383872",
  "text" : "possible classroom uses http:\/\/t.co\/4B8SVKN2xE #eltchat #elt http:\/\/t.co\/WdxcE5rhZ4",
  "id" : 520488761986383872,
  "created_at" : "2014-10-10 08:19:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angus B Grieve-Smith",
      "screen_name" : "grvsmth",
      "indices" : [ 3, 11 ],
      "id_str" : "22381639",
      "id" : 22381639
    }, {
      "name" : "Charles Marohn",
      "screen_name" : "clmarohn",
      "indices" : [ 99, 108 ],
      "id_str" : "16426402",
      "id" : 16426402
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/Ho0PRXnWDH",
      "expanded_url" : "http:\/\/grieve-smith.com\/blog\/2014\/10\/minneapolis\/",
      "display_url" : "grieve-smith.com\/blog\/2014\/10\/m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "520452738115993600",
  "text" : "RT @grvsmth: America's Loveliest Accents: Minneapolis http:\/\/t.co\/Ho0PRXnWDH featuring Prince. And @clmarohn, because Brainerd isn't on the\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Charles Marohn",
        "screen_name" : "clmarohn",
        "indices" : [ 86, 95 ],
        "id_str" : "16426402",
        "id" : 16426402
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/Ho0PRXnWDH",
        "expanded_url" : "http:\/\/grieve-smith.com\/blog\/2014\/10\/minneapolis\/",
        "display_url" : "grieve-smith.com\/blog\/2014\/10\/m\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "520438641316085760",
    "text" : "America's Loveliest Accents: Minneapolis http:\/\/t.co\/Ho0PRXnWDH featuring Prince. And @clmarohn, because Brainerd isn't on the list!",
    "id" : 520438641316085760,
    "created_at" : "2014-10-10 05:00:16 +0000",
    "user" : {
      "name" : "Angus B Grieve-Smith",
      "screen_name" : "grvsmth",
      "protected" : false,
      "id_str" : "22381639",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/94827231\/portrait_normal.png",
      "id" : 22381639,
      "verified" : false
    }
  },
  "id" : 520452738115993600,
  "created_at" : "2014-10-10 05:56:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "indyscot",
      "indices" : [ 111, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/oIrxii9gEN",
      "expanded_url" : "http:\/\/fivemillionquestions.org\/blog\/2014\/09\/12\/bought-and-sold,-or-hype-in-bold-newspaper-framing-of-the-scottish-independence-debate\/",
      "display_url" : "fivemillionquestions.org\/blog\/2014\/09\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "520449778627272704",
  "text" : "Bought and Sold, or Hype in Bold? Newspaper Framing of the Scottish Independence Debate http:\/\/t.co\/oIrxii9gEN #indyscot",
  "id" : 520449778627272704,
  "created_at" : "2014-10-10 05:44:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr David Patrick",
      "screen_name" : "DrDavidPatrick",
      "indices" : [ 0, 15 ],
      "id_str" : "2811718813",
      "id" : 2811718813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "520448545288376321",
  "geo" : { },
  "id_str" : "520449242230697984",
  "in_reply_to_user_id" : 2811718813,
  "text" : "@DrDavidPatrick hi thx the link got messed up but guessed correct one :)",
  "id" : 520449242230697984,
  "in_reply_to_status_id" : 520448545288376321,
  "created_at" : "2014-10-10 05:42:23 +0000",
  "in_reply_to_screen_name" : "DrDavidPatrick",
  "in_reply_to_user_id_str" : "2811718813",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Douglas Carnall",
      "screen_name" : "JuliuzBeezer",
      "indices" : [ 0, 13 ],
      "id_str" : "25936824",
      "id" : 25936824
    }, {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "indices" : [ 14, 30 ],
      "id_str" : "1326508478",
      "id" : 1326508478
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "520438662140801024",
  "geo" : { },
  "id_str" : "520446376845783041",
  "in_reply_to_user_id" : 25936824,
  "text" : "@JuliuzBeezer @CorpusSocialSci true that she must have used some hocus pocs to ward it off :)",
  "id" : 520446376845783041,
  "in_reply_to_status_id" : 520438662140801024,
  "created_at" : "2014-10-10 05:31:00 +0000",
  "in_reply_to_screen_name" : "JuliuzBeezer",
  "in_reply_to_user_id_str" : "25936824",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr David Patrick",
      "screen_name" : "DrDavidPatrick",
      "indices" : [ 0, 15 ],
      "id_str" : "2811718813",
      "id" : 2811718813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/5uKHH58kFB",
      "expanded_url" : "http:\/\/cass.lancs.ac.uk\/?tag=scottish-referendum",
      "display_url" : "cass.lancs.ac.uk\/?tag=scottish-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "520445870190637056",
  "in_reply_to_user_id" : 2811718813,
  "text" : "@DrDavidPatrick Hi any link to papers of yr study? Also what do u think of this one http:\/\/t.co\/5uKHH58kFB \u2026 ? Thx",
  "id" : 520445870190637056,
  "created_at" : "2014-10-10 05:28:59 +0000",
  "in_reply_to_screen_name" : "DrDavidPatrick",
  "in_reply_to_user_id_str" : "2811718813",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kurt Kohn",
      "screen_name" : "KurtKohn",
      "indices" : [ 0, 9 ],
      "id_str" : "908509357",
      "id" : 908509357
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "520292295619272704",
  "geo" : { },
  "id_str" : "520432325252104193",
  "in_reply_to_user_id" : 908509357,
  "text" : "@KurtKohn OK thx :)",
  "id" : 520432325252104193,
  "in_reply_to_status_id" : 520292295619272704,
  "created_at" : "2014-10-10 04:35:10 +0000",
  "in_reply_to_screen_name" : "KurtKohn",
  "in_reply_to_user_id_str" : "908509357",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/5uKHH58kFB",
      "expanded_url" : "http:\/\/cass.lancs.ac.uk\/?tag=scottish-referendum",
      "display_url" : "cass.lancs.ac.uk\/?tag=scottish-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "520432147950481408",
  "text" : "Hi any link to papers of yr study? Also what do u think of this one http:\/\/t.co\/5uKHH58kFB ? Thx",
  "id" : 520432147950481408,
  "created_at" : "2014-10-10 04:34:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roe McDermott",
      "screen_name" : "roemcdermott",
      "indices" : [ 3, 16 ],
      "id_str" : "258503796",
      "id" : 258503796
    }, {
      "name" : "New Statesman",
      "screen_name" : "NewStatesman",
      "indices" : [ 27, 40 ],
      "id_str" : "19906615",
      "id" : 19906615
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/roemcdermott\/status\/520145253727092736\/photo\/1",
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/YasDQE1YAm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzftWPsCAAEgMpx.jpg",
      "id_str" : "520145248408698881",
      "id" : 520145248408698881,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzftWPsCAAEgMpx.jpg",
      "sizes" : [ {
        "h" : 447,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 779
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 779
      }, {
        "h" : 789,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/YasDQE1YAm"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "520173780262723584",
  "text" : "RT @roemcdermott: Cover of @NewStatesman, guest edited by Grayson Perry. Genius. http:\/\/t.co\/YasDQE1YAm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "New Statesman",
        "screen_name" : "NewStatesman",
        "indices" : [ 9, 22 ],
        "id_str" : "19906615",
        "id" : 19906615
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/roemcdermott\/status\/520145253727092736\/photo\/1",
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/YasDQE1YAm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BzftWPsCAAEgMpx.jpg",
        "id_str" : "520145248408698881",
        "id" : 520145248408698881,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzftWPsCAAEgMpx.jpg",
        "sizes" : [ {
          "h" : 447,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 779
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 779
        }, {
          "h" : 789,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/YasDQE1YAm"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "520145253727092736",
    "text" : "Cover of @NewStatesman, guest edited by Grayson Perry. Genius. http:\/\/t.co\/YasDQE1YAm",
    "id" : 520145253727092736,
    "created_at" : "2014-10-09 09:34:26 +0000",
    "user" : {
      "name" : "Roe McDermott",
      "screen_name" : "roemcdermott",
      "protected" : false,
      "id_str" : "258503796",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/640947742177558528\/TDYvCSr9_normal.jpg",
      "id" : 258503796,
      "verified" : false
    }
  },
  "id" : 520173780262723584,
  "created_at" : "2014-10-09 11:27:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "indices" : [ 0, 16 ],
      "id_str" : "1326508478",
      "id" : 1326508478
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "520127156945702912",
  "geo" : { },
  "id_str" : "520142113124925440",
  "in_reply_to_user_id" : 1326508478,
  "text" : "@CorpusSocialSci looks like a great seminar which does not need inaccurate title of \"big data\"  efcamdat ~30 million is not big data :\/",
  "id" : 520142113124925440,
  "in_reply_to_status_id" : 520127156945702912,
  "created_at" : "2014-10-09 09:21:58 +0000",
  "in_reply_to_screen_name" : "CorpusSocialSci",
  "in_reply_to_user_id_str" : "1326508478",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Graham",
      "screen_name" : "onalifeglug",
      "indices" : [ 0, 12 ],
      "id_str" : "19516039",
      "id" : 19516039
    }, {
      "name" : "kerem",
      "screen_name" : "KeremBrulee",
      "indices" : [ 13, 25 ],
      "id_str" : "242842522",
      "id" : 242842522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "520117617399701504",
  "geo" : { },
  "id_str" : "520119713884798976",
  "in_reply_to_user_id" : 19516039,
  "text" : "@onalifeglug @KeremBrulee yes cause western anti-imperialists are the problem..especially that venezualan guy madura what's he on about eh?",
  "id" : 520119713884798976,
  "in_reply_to_status_id" : 520117617399701504,
  "created_at" : "2014-10-09 07:52:57 +0000",
  "in_reply_to_screen_name" : "onalifeglug",
  "in_reply_to_user_id_str" : "19516039",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 0, 10 ],
      "id_str" : "525274103",
      "id" : 525274103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "519972638131617792",
  "geo" : { },
  "id_str" : "519975929029066753",
  "in_reply_to_user_id" : 525274103,
  "text" : "@ElkySmith this guy is a bullshit artist extraodinaire :\/",
  "id" : 519975929029066753,
  "in_reply_to_status_id" : 519972638131617792,
  "created_at" : "2014-10-08 22:21:36 +0000",
  "in_reply_to_screen_name" : "ElkySmith",
  "in_reply_to_user_id_str" : "525274103",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 93, 101 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/V003V9z5Kn",
      "expanded_url" : "http:\/\/youtu.be\/2bYajHIcXMk",
      "display_url" : "youtu.be\/2bYajHIcXMk"
    } ]
  },
  "geo" : { },
  "id_str" : "519960366315368448",
  "text" : "WRITING OFF SCOTLAND - Press Bias in the Independence Referendum: http:\/\/t.co\/V003V9z5Kn via @YouTube",
  "id" : 519960366315368448,
  "created_at" : "2014-10-08 21:19:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/IManBFnEcb",
      "expanded_url" : "http:\/\/corpus.ied.edu.hk\/ace\/index.html",
      "display_url" : "corpus.ied.edu.hk\/ace\/index.html"
    } ]
  },
  "geo" : { },
  "id_str" : "519957086180892673",
  "text" : "Asian Corpus of English http:\/\/t.co\/IManBFnEcb h\/t FB CL group",
  "id" : 519957086180892673,
  "created_at" : "2014-10-08 21:06:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kurt Kohn",
      "screen_name" : "KurtKohn",
      "indices" : [ 0, 9 ],
      "id_str" : "908509357",
      "id" : 908509357
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "519917038202925056",
  "geo" : { },
  "id_str" : "519931459252285441",
  "in_reply_to_user_id" : 908509357,
  "text" : "@KurtKohn hi setting on video is private?",
  "id" : 519931459252285441,
  "in_reply_to_status_id" : 519917038202925056,
  "created_at" : "2014-10-08 19:24:54 +0000",
  "in_reply_to_screen_name" : "KurtKohn",
  "in_reply_to_user_id_str" : "908509357",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpus",
      "indices" : [ 18, 25 ]
    }, {
      "text" : "corpusmooc",
      "indices" : [ 36, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/2wjWNo1jcr",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-Pj",
      "display_url" : "wp.me\/pgHyE-Pj"
    } ]
  },
  "geo" : { },
  "id_str" : "519927324175650816",
  "text" : "Building your own #corpus - BootCat #corpusmooc http:\/\/t.co\/2wjWNo1jcr",
  "id" : 519927324175650816,
  "created_at" : "2014-10-08 19:08:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2133\u0105h\u0105 B\u0105\u2113i \u0645\u0647\u0627 \u0628\u0627\u0644\u064A",
      "screen_name" : "Bali_Maha",
      "indices" : [ 0, 10 ],
      "id_str" : "1535273520",
      "id" : 1535273520
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "519916869672001536",
  "geo" : { },
  "id_str" : "519917085699620864",
  "in_reply_to_user_id" : 1535273520,
  "text" : "@Bali_Maha @Maha_Learning colloquial exp for chat, gossip, natter etc",
  "id" : 519917085699620864,
  "in_reply_to_status_id" : 519916869672001536,
  "created_at" : "2014-10-08 18:27:47 +0000",
  "in_reply_to_screen_name" : "Bali_Maha",
  "in_reply_to_user_id_str" : "1535273520",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2133\u0105h\u0105 B\u0105\u2113i \u0645\u0647\u0627 \u0628\u0627\u0644\u064A",
      "screen_name" : "Bali_Maha",
      "indices" : [ 0, 10 ],
      "id_str" : "1535273520",
      "id" : 1535273520
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchinwag",
      "indices" : [ 34, 45 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "519916195487952897",
  "geo" : { },
  "id_str" : "519916564481855488",
  "in_reply_to_user_id" : 1535273520,
  "text" : "@Bali_Maha @Maha_Learning there's #eltchinwag as well",
  "id" : 519916564481855488,
  "in_reply_to_status_id" : 519916195487952897,
  "created_at" : "2014-10-08 18:25:43 +0000",
  "in_reply_to_screen_name" : "Bali_Maha",
  "in_reply_to_user_id_str" : "1535273520",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2133\u0105h\u0105 B\u0105\u2113i \u0645\u0647\u0627 \u0628\u0627\u0644\u064A",
      "screen_name" : "Bali_Maha",
      "indices" : [ 0, 10 ],
      "id_str" : "1535273520",
      "id" : 1535273520
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 39, 47 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "519915115362398208",
  "geo" : { },
  "id_str" : "519915910552113152",
  "in_reply_to_user_id" : 1535273520,
  "text" : "@Bali_Maha @Maha_Learning don't forget #eltchat",
  "id" : 519915910552113152,
  "in_reply_to_status_id" : 519915115362398208,
  "created_at" : "2014-10-08 18:23:07 +0000",
  "in_reply_to_screen_name" : "Bali_Maha",
  "in_reply_to_user_id_str" : "1535273520",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Libby Brooks",
      "screen_name" : "libby_brooks",
      "indices" : [ 3, 16 ],
      "id_str" : "52730426",
      "id" : 52730426
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/MGz1dJdme9",
      "expanded_url" : "http:\/\/gu.com\/p\/429ng\/tw",
      "display_url" : "gu.com\/p\/429ng\/tw"
    } ]
  },
  "geo" : { },
  "id_str" : "519915685821300736",
  "text" : "RT @libby_brooks: Glasgow becomes first university in Europe to divest from fossil fuels http:\/\/t.co\/MGz1dJdme9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/MGz1dJdme9",
        "expanded_url" : "http:\/\/gu.com\/p\/429ng\/tw",
        "display_url" : "gu.com\/p\/429ng\/tw"
      } ]
    },
    "geo" : { },
    "id_str" : "519912166887936001",
    "text" : "Glasgow becomes first university in Europe to divest from fossil fuels http:\/\/t.co\/MGz1dJdme9",
    "id" : 519912166887936001,
    "created_at" : "2014-10-08 18:08:14 +0000",
    "user" : {
      "name" : "Libby Brooks",
      "screen_name" : "libby_brooks",
      "protected" : false,
      "id_str" : "52730426",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/645328449842884609\/fqRvktx8_normal.jpg",
      "id" : 52730426,
      "verified" : true
    }
  },
  "id" : 519915685821300736,
  "created_at" : "2014-10-08 18:22:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 3, 12 ],
      "id_str" : "121063600",
      "id" : 121063600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/smCSmhbAoN",
      "expanded_url" : "http:\/\/tlk.io\/iwbforefl",
      "display_url" : "tlk.io\/iwbforefl"
    } ]
  },
  "geo" : { },
  "id_str" : "519897154887122944",
  "text" : "RT @whyshona: Join me! I'm currently chatting on: http:\/\/t.co\/smCSmhbAoN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 36, 58 ],
        "url" : "http:\/\/t.co\/smCSmhbAoN",
        "expanded_url" : "http:\/\/tlk.io\/iwbforefl",
        "display_url" : "tlk.io\/iwbforefl"
      } ]
    },
    "geo" : { },
    "id_str" : "519896135729553408",
    "text" : "Join me! I'm currently chatting on: http:\/\/t.co\/smCSmhbAoN",
    "id" : 519896135729553408,
    "created_at" : "2014-10-08 17:04:32 +0000",
    "user" : {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "protected" : false,
      "id_str" : "121063600",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459074158974889984\/nMzMr6_1_normal.jpeg",
      "id" : 121063600,
      "verified" : false
    }
  },
  "id" : 519897154887122944,
  "created_at" : "2014-10-08 17:08:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StudyBundles",
      "screen_name" : "StudyBundles",
      "indices" : [ 0, 13 ],
      "id_str" : "2558614093",
      "id" : 2558614093
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "519878704089296896",
  "geo" : { },
  "id_str" : "519886636164059136",
  "in_reply_to_user_id" : 2558614093,
  "text" : "@StudyBundles Hi sample is taken from BNC spoken but bnc64 is more reliable",
  "id" : 519886636164059136,
  "in_reply_to_status_id" : 519878704089296896,
  "created_at" : "2014-10-08 16:26:47 +0000",
  "in_reply_to_screen_name" : "StudyBundles",
  "in_reply_to_user_id_str" : "2558614093",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/rDHT7Aw4ba",
      "expanded_url" : "http:\/\/www.theguardian.com\/teacher-network\/teacher-blog\/2014\/oct\/08\/master-teacher-how-students-learn?CMP=twt_gu",
      "display_url" : "theguardian.com\/teacher-networ\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "519617538561282049",
  "geo" : { },
  "id_str" : "519860157640351745",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow hi kev no worries check this article out http:\/\/t.co\/rDHT7Aw4ba",
  "id" : 519860157640351745,
  "in_reply_to_status_id" : 519617538561282049,
  "created_at" : "2014-10-08 14:41:34 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The School Aranda",
      "screen_name" : "TheSchoolAranda",
      "indices" : [ 0, 16 ],
      "id_str" : "316559494",
      "id" : 316559494
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "519859835958214656",
  "in_reply_to_user_id" : 316559494,
  "text" : "@TheSchoolAranda thx for share :)",
  "id" : 519859835958214656,
  "created_at" : "2014-10-08 14:40:18 +0000",
  "in_reply_to_screen_name" : "TheSchoolAranda",
  "in_reply_to_user_id_str" : "316559494",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StudyBundles",
      "screen_name" : "StudyBundles",
      "indices" : [ 0, 13 ],
      "id_str" : "2558614093",
      "id" : 2558614093
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "519782973353517056",
  "geo" : { },
  "id_str" : "519859716470870016",
  "in_reply_to_user_id" : 2558614093,
  "text" : "@StudyBundles glad u enjoyed it do take it with a bit of salt, the linked pdf is really good about danger of reifying gender diffs lang use",
  "id" : 519859716470870016,
  "in_reply_to_status_id" : 519782973353517056,
  "created_at" : "2014-10-08 14:39:49 +0000",
  "in_reply_to_screen_name" : "StudyBundles",
  "in_reply_to_user_id_str" : "2558614093",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "519805452427599873",
  "geo" : { },
  "id_str" : "519859173140729856",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan cheer for share leo hope u r having a good week :)",
  "id" : 519859173140729856,
  "in_reply_to_status_id" : 519805452427599873,
  "created_at" : "2014-10-08 14:37:40 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Guardian",
      "screen_name" : "guardian",
      "indices" : [ 104, 113 ],
      "id_str" : "87818409",
      "id" : 87818409
    }, {
      "name" : "P\u00E9rez-Paredes",
      "screen_name" : "perezparedes",
      "indices" : [ 118, 131 ],
      "id_str" : "28528850",
      "id" : 28528850
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/1RkfCV7zoU",
      "expanded_url" : "http:\/\/gu.com\/p\/428t2\/tw",
      "display_url" : "gu.com\/p\/428t2\/tw"
    } ]
  },
  "geo" : { },
  "id_str" : "519858913450029058",
  "text" : "\u2018I couldn\u2019t continue as a teacher without understanding how students learn\u2019\n http:\/\/t.co\/1RkfCV7zoU via @guardian h\/t @perezparedes",
  "id" : 519858913450029058,
  "created_at" : "2014-10-08 14:36:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Harbinson",
      "screen_name" : "DavidHarbinson",
      "indices" : [ 3, 18 ],
      "id_str" : "853078675",
      "id" : 853078675
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KoTESOL",
      "indices" : [ 30, 38 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/rmyLpAVpfb",
      "expanded_url" : "http:\/\/davidharbinson.com\/kotesol-international-conference-2014-review\/",
      "display_url" : "davidharbinson.com\/kotesol-intern\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "519805097858326528",
  "text" : "RT @DavidHarbinson: ICYMI: My #KoTESOL International Conference 2014 Review http:\/\/t.co\/rmyLpAVpfb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "KoTESOL",
        "indices" : [ 10, 18 ]
      } ],
      "urls" : [ {
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/rmyLpAVpfb",
        "expanded_url" : "http:\/\/davidharbinson.com\/kotesol-international-conference-2014-review\/",
        "display_url" : "davidharbinson.com\/kotesol-intern\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "519800682161790977",
    "text" : "ICYMI: My #KoTESOL International Conference 2014 Review http:\/\/t.co\/rmyLpAVpfb",
    "id" : 519800682161790977,
    "created_at" : "2014-10-08 10:45:14 +0000",
    "user" : {
      "name" : "David Harbinson",
      "screen_name" : "DavidHarbinson",
      "protected" : false,
      "id_str" : "853078675",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/524830685643538432\/NdyDn_ux_normal.jpeg",
      "id" : 853078675,
      "verified" : false
    }
  },
  "id" : 519805097858326528,
  "created_at" : "2014-10-08 11:02:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/BVooT0SR26",
      "expanded_url" : "http:\/\/decentralisedteachingandlearning.com\/2014\/10\/08\/10-minute-warmer-5-answers-looking-for-a-question\/",
      "display_url" : "decentralisedteachingandlearning.com\/2014\/10\/08\/10-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "519778170690482176",
  "text" : "10 Minute Warmer (5) Answers looking for a question http:\/\/t.co\/BVooT0SR26",
  "id" : 519778170690482176,
  "created_at" : "2014-10-08 09:15:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StudyBundles",
      "screen_name" : "StudyBundles",
      "indices" : [ 0, 13 ],
      "id_str" : "2558614093",
      "id" : 2558614093
    }, {
      "name" : "The Guardian",
      "screen_name" : "guardian",
      "indices" : [ 14, 23 ],
      "id_str" : "87818409",
      "id" : 87818409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/AyI5JuvjWa",
      "expanded_url" : "http:\/\/bncgender.englishup.me",
      "display_url" : "bncgender.englishup.me"
    } ]
  },
  "in_reply_to_status_id_str" : "519752270976536576",
  "geo" : { },
  "id_str" : "519775524433199105",
  "in_reply_to_user_id" : 2558614093,
  "text" : "@StudyBundles @guardian fyi play with gender here http:\/\/t.co\/AyI5JuvjWa now with added swearing :)",
  "id" : 519775524433199105,
  "in_reply_to_status_id" : 519752270976536576,
  "created_at" : "2014-10-08 09:05:16 +0000",
  "in_reply_to_screen_name" : "StudyBundles",
  "in_reply_to_user_id_str" : "2558614093",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GitHub Education",
      "screen_name" : "GitHubEducation",
      "indices" : [ 3, 19 ],
      "id_str" : "1943578656",
      "id" : 1943578656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/WJptY2hSdW",
      "expanded_url" : "https:\/\/education.github.com\/pack",
      "display_url" : "education.github.com\/pack"
    } ]
  },
  "geo" : { },
  "id_str" : "519586962219347968",
  "text" : "RT @GitHubEducation: The best developer tools, now free for students: https:\/\/t.co\/WJptY2hSdW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 72 ],
        "url" : "https:\/\/t.co\/WJptY2hSdW",
        "expanded_url" : "https:\/\/education.github.com\/pack",
        "display_url" : "education.github.com\/pack"
      } ]
    },
    "geo" : { },
    "id_str" : "519517968217415680",
    "text" : "The best developer tools, now free for students: https:\/\/t.co\/WJptY2hSdW",
    "id" : 519517968217415680,
    "created_at" : "2014-10-07 16:01:50 +0000",
    "user" : {
      "name" : "GitHub Education",
      "screen_name" : "GitHubEducation",
      "protected" : false,
      "id_str" : "1943578656",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000561692042\/a26a14bdfa11b045632e66b05369bc48_normal.png",
      "id" : 1943578656,
      "verified" : false
    }
  },
  "id" : 519586962219347968,
  "created_at" : "2014-10-07 20:35:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/medialens\/status\/519499139231793152\/photo\/1",
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/NNzBcypdxU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzWhtqlIYAAe-Lh.png",
      "id_str" : "519499137927372800",
      "id" : 519499137927372800,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzWhtqlIYAAe-Lh.png",
      "sizes" : [ {
        "h" : 64,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 185,
        "resize" : "fit",
        "w" : 985
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 113,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 185,
        "resize" : "fit",
        "w" : 985
      } ],
      "display_url" : "pic.twitter.com\/NNzBcypdxU"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/aR9xPfABLN",
      "expanded_url" : "http:\/\/www.morrissey-solo.com\/threads\/132984-New-interviw-El-Mundo-%28Spain%29-I-have-been-scraping-cancerous-tissues-four-times-already-but-who-ca?p=1986879685#post1986879685",
      "display_url" : "morrissey-solo.com\/threads\/132984\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "519581971517677568",
  "text" : "RT @medialens: Morrissey excellent on BBC thought control http:\/\/t.co\/aR9xPfABLN http:\/\/t.co\/NNzBcypdxU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/medialens\/status\/519499139231793152\/photo\/1",
        "indices" : [ 66, 88 ],
        "url" : "http:\/\/t.co\/NNzBcypdxU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BzWhtqlIYAAe-Lh.png",
        "id_str" : "519499137927372800",
        "id" : 519499137927372800,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzWhtqlIYAAe-Lh.png",
        "sizes" : [ {
          "h" : 64,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 185,
          "resize" : "fit",
          "w" : 985
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 113,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 185,
          "resize" : "fit",
          "w" : 985
        } ],
        "display_url" : "pic.twitter.com\/NNzBcypdxU"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 65 ],
        "url" : "http:\/\/t.co\/aR9xPfABLN",
        "expanded_url" : "http:\/\/www.morrissey-solo.com\/threads\/132984-New-interviw-El-Mundo-%28Spain%29-I-have-been-scraping-cancerous-tissues-four-times-already-but-who-ca?p=1986879685#post1986879685",
        "display_url" : "morrissey-solo.com\/threads\/132984\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "519499139231793152",
    "text" : "Morrissey excellent on BBC thought control http:\/\/t.co\/aR9xPfABLN http:\/\/t.co\/NNzBcypdxU",
    "id" : 519499139231793152,
    "created_at" : "2014-10-07 14:47:01 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 519581971517677568,
  "created_at" : "2014-10-07 20:16:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/FyxMOdiiae",
      "expanded_url" : "http:\/\/zcomm.org\/znetarticle\/george-monbiot-the-lefts-mccarthy\/",
      "display_url" : "zcomm.org\/znetarticle\/ge\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "519581800192962560",
  "text" : "RT @medialens: Jonathan Cook: 'George Monbiot, the Left\u2019s McCarthy' http:\/\/t.co\/FyxMOdiiae",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 75 ],
        "url" : "http:\/\/t.co\/FyxMOdiiae",
        "expanded_url" : "http:\/\/zcomm.org\/znetarticle\/george-monbiot-the-lefts-mccarthy\/",
        "display_url" : "zcomm.org\/znetarticle\/ge\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "519522328053813248",
    "text" : "Jonathan Cook: 'George Monbiot, the Left\u2019s McCarthy' http:\/\/t.co\/FyxMOdiiae",
    "id" : 519522328053813248,
    "created_at" : "2014-10-07 16:19:09 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 519581800192962560,
  "created_at" : "2014-10-07 20:15:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 3, 14 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "My100thPost",
      "indices" : [ 141, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/qOruFlTemo",
      "expanded_url" : "http:\/\/theotherthingsmatter.wordpress.com\/2014\/10\/06\/the",
      "display_url" : "theotherthingsmatter.wordpress.com\/2014\/10\/06\/the"
    } ]
  },
  "geo" : { },
  "id_str" : "519573706507423745",
  "text" : "RT @kevchanwow: 'Mostly Useless', a post on physical descriptions, changing language needs, &amp; a dash of shame: http:\/\/t.co\/qOruFlTemo\u2026 \u2026 #M\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "My100thPost",
        "indices" : [ 125, 137 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/qOruFlTemo",
        "expanded_url" : "http:\/\/theotherthingsmatter.wordpress.com\/2014\/10\/06\/the",
        "display_url" : "theotherthingsmatter.wordpress.com\/2014\/10\/06\/the"
      } ]
    },
    "geo" : { },
    "id_str" : "519430555876589568",
    "text" : "'Mostly Useless', a post on physical descriptions, changing language needs, &amp; a dash of shame: http:\/\/t.co\/qOruFlTemo\u2026 \u2026 #My100thPost",
    "id" : 519430555876589568,
    "created_at" : "2014-10-07 10:14:29 +0000",
    "user" : {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "protected" : false,
      "id_str" : "144663117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/559618421839507456\/nPF7dP47_normal.jpeg",
      "id" : 144663117,
      "verified" : false
    }
  },
  "id" : 519573706507423745,
  "created_at" : "2014-10-07 19:43:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Harbinson",
      "screen_name" : "DavidHarbinson",
      "indices" : [ 3, 18 ],
      "id_str" : "853078675",
      "id" : 853078675
    }, {
      "name" : "Jeff Lebow",
      "screen_name" : "jefflebow",
      "indices" : [ 23, 33 ],
      "id_str" : "1679571",
      "id" : 1679571
    }, {
      "name" : "Barbara Sakamoto ",
      "screen_name" : "barbsaka",
      "indices" : [ 54, 63 ],
      "id_str" : "2970224781",
      "id" : 2970224781
    }, {
      "name" : "Anna Loseva",
      "screen_name" : "AnnLoseva",
      "indices" : [ 64, 74 ],
      "id_str" : "38822368",
      "id" : 38822368
    }, {
      "name" : "Josette LeBlanc",
      "screen_name" : "JosetteLB",
      "indices" : [ 75, 85 ],
      "id_str" : "33503694",
      "id" : 33503694
    }, {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 86, 102 ],
      "id_str" : "394053348",
      "id" : 394053348
    }, {
      "name" : "itdi.pro",
      "screen_name" : "iTDipro",
      "indices" : [ 139, 140 ],
      "id_str" : "374391424",
      "id" : 374391424
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iTDi",
      "indices" : [ 39, 44 ]
    }, {
      "text" : "KoTESOL",
      "indices" : [ 106, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/N01rz78elh",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=r-HXbp5M4Wc",
      "display_url" : "youtube.com\/watch?v=r-HXbp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "519571471840968704",
  "text" : "RT @DavidHarbinson: MT @jefflebow: the #iTDi team of  @barbsaka @AnnLoseva @JosetteLB @michaelegriffin at #KoTESOL https:\/\/t.co\/N01rz78elh \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jeff Lebow",
        "screen_name" : "jefflebow",
        "indices" : [ 3, 13 ],
        "id_str" : "1679571",
        "id" : 1679571
      }, {
        "name" : "Barbara Sakamoto ",
        "screen_name" : "barbsaka",
        "indices" : [ 34, 43 ],
        "id_str" : "2970224781",
        "id" : 2970224781
      }, {
        "name" : "Anna Loseva",
        "screen_name" : "AnnLoseva",
        "indices" : [ 44, 54 ],
        "id_str" : "38822368",
        "id" : 38822368
      }, {
        "name" : "Josette LeBlanc",
        "screen_name" : "JosetteLB",
        "indices" : [ 55, 65 ],
        "id_str" : "33503694",
        "id" : 33503694
      }, {
        "name" : "Michael Griffin",
        "screen_name" : "michaelegriffin",
        "indices" : [ 66, 82 ],
        "id_str" : "394053348",
        "id" : 394053348
      }, {
        "name" : "itdi.pro",
        "screen_name" : "iTDipro",
        "indices" : [ 120, 128 ],
        "id_str" : "374391424",
        "id" : 374391424
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "iTDi",
        "indices" : [ 19, 24 ]
      }, {
        "text" : "KoTESOL",
        "indices" : [ 86, 94 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/N01rz78elh",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=r-HXbp5M4Wc",
        "display_url" : "youtube.com\/watch?v=r-HXbp\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "519528351745077248",
    "text" : "MT @jefflebow: the #iTDi team of  @barbsaka @AnnLoseva @JosetteLB @michaelegriffin at #KoTESOL https:\/\/t.co\/N01rz78elh  @iTDipro",
    "id" : 519528351745077248,
    "created_at" : "2014-10-07 16:43:06 +0000",
    "user" : {
      "name" : "David Harbinson",
      "screen_name" : "DavidHarbinson",
      "protected" : false,
      "id_str" : "853078675",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/524830685643538432\/NdyDn_ux_normal.jpeg",
      "id" : 853078675,
      "verified" : false
    }
  },
  "id" : 519571471840968704,
  "created_at" : "2014-10-07 19:34:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "519570436850327552",
  "text" : "re from last link i do seem to be seeing a lot of \"science by press release\"",
  "id" : 519570436850327552,
  "created_at" : "2014-10-07 19:30:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/pwhE05Oi1R",
      "expanded_url" : "http:\/\/indiancountrytodaymedianetwork.com\/2014\/03\/19\/how-linguists-are-pulling-apart-bering-strait-theory-154063?page=0%2C0",
      "display_url" : "indiancountrytodaymedianetwork.com\/2014\/03\/19\/how\u2026"
    }, {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/1JeYMETvrE",
      "expanded_url" : "http:\/\/lingblog.com\/",
      "display_url" : "lingblog.com"
    } ]
  },
  "geo" : { },
  "id_str" : "519569877636349952",
  "text" : "How Linguists Are Pulling Apart the Bering Straits Theory http:\/\/t.co\/pwhE05Oi1R h\/t http:\/\/t.co\/1JeYMETvrE",
  "id" : 519569877636349952,
  "created_at" : "2014-10-07 19:28:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike S. Boyle",
      "screen_name" : "heyboyle",
      "indices" : [ 0, 9 ],
      "id_str" : "612840231",
      "id" : 612840231
    }, {
      "name" : "Larry Ferlazzo",
      "screen_name" : "Larryferlazzo",
      "indices" : [ 10, 24 ],
      "id_str" : "18107749",
      "id" : 18107749
    }, {
      "name" : "CDBU",
      "screen_name" : "cdbuni",
      "indices" : [ 25, 32 ],
      "id_str" : "938864702",
      "id" : 938864702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/AyI5JuvjWa",
      "expanded_url" : "http:\/\/bncgender.englishup.me",
      "display_url" : "bncgender.englishup.me"
    }, {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/l73f37xNzI",
      "expanded_url" : "http:\/\/corpora.lancs.ac.uk\/bnc64\/",
      "display_url" : "corpora.lancs.ac.uk\/bnc64\/"
    } ]
  },
  "in_reply_to_status_id_str" : "519451146189299713",
  "geo" : { },
  "id_str" : "519486631934705664",
  "in_reply_to_user_id" : 612840231,
  "text" : "@heyboyle @Larryferlazzo @cdbuni fyi you can play with gender here http:\/\/t.co\/AyI5JuvjWa or a more reliable one here http:\/\/t.co\/l73f37xNzI",
  "id" : 519486631934705664,
  "in_reply_to_status_id" : 519451146189299713,
  "created_at" : "2014-10-07 13:57:19 +0000",
  "in_reply_to_screen_name" : "heyboyle",
  "in_reply_to_user_id_str" : "612840231",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hancock McDonald ELT",
      "screen_name" : "HancockMcDonald",
      "indices" : [ 0, 16 ],
      "id_str" : "552929354",
      "id" : 552929354
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "519481106199220224",
  "in_reply_to_user_id" : 552929354,
  "text" : "@HancockMcDonald hi thks for RT, comment of my post &amp;  thks for great write-up of McCarthy talk",
  "id" : 519481106199220224,
  "created_at" : "2014-10-07 13:35:21 +0000",
  "in_reply_to_screen_name" : "HancockMcDonald",
  "in_reply_to_user_id_str" : "552929354",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpus",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/wPqaY2OIbF",
      "expanded_url" : "http:\/\/eflnotes.wordpress.com\/2014\/10\/07\/you-should-have-the-body\/#comment-1726",
      "display_url" : "eflnotes.wordpress.com\/2014\/10\/07\/you\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "519480803508908032",
  "text" : "#corpus as heavenly choir :) great comment by Ray Carey http:\/\/t.co\/wPqaY2OIbF",
  "id" : 519480803508908032,
  "created_at" : "2014-10-07 13:34:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Costas Gabrielatos",
      "screen_name" : "congabonga",
      "indices" : [ 3, 14 ],
      "id_str" : "187484412",
      "id" : 187484412
    }, {
      "name" : "The Guardian",
      "screen_name" : "guardian",
      "indices" : [ 130, 139 ],
      "id_str" : "87818409",
      "id" : 87818409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/r5SbggMOIq",
      "expanded_url" : "http:\/\/gu.com\/p\/427mt\/tw",
      "display_url" : "gu.com\/p\/427mt\/tw"
    } ]
  },
  "geo" : { },
  "id_str" : "519478274259714048",
  "text" : "RT @congabonga: \"This awesome dissection of internet hyperbole will make you cry and change your life\" http:\/\/t.co\/r5SbggMOIq via @guardian",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Guardian",
        "screen_name" : "guardian",
        "indices" : [ 114, 123 ],
        "id_str" : "87818409",
        "id" : 87818409
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/r5SbggMOIq",
        "expanded_url" : "http:\/\/gu.com\/p\/427mt\/tw",
        "display_url" : "gu.com\/p\/427mt\/tw"
      } ]
    },
    "geo" : { },
    "id_str" : "519458435793158144",
    "text" : "\"This awesome dissection of internet hyperbole will make you cry and change your life\" http:\/\/t.co\/r5SbggMOIq via @guardian",
    "id" : 519458435793158144,
    "created_at" : "2014-10-07 12:05:16 +0000",
    "user" : {
      "name" : "Costas Gabrielatos",
      "screen_name" : "congabonga",
      "protected" : false,
      "id_str" : "187484412",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/603260667534127104\/FkSbeNEt_normal.jpg",
      "id" : 187484412,
      "verified" : false
    }
  },
  "id" : 519478274259714048,
  "created_at" : "2014-10-07 13:24:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "indices" : [ 3, 19 ],
      "id_str" : "1326508478",
      "id" : 1326508478
    }, {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "indices" : [ 53, 62 ],
      "id_str" : "167020390",
      "id" : 167020390
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusMOOC",
      "indices" : [ 132, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/nvze0TPb5v",
      "expanded_url" : "http:\/\/cass.lancs.ac.uk\/?p=1432",
      "display_url" : "cass.lancs.ac.uk\/?p=1432"
    } ]
  },
  "geo" : { },
  "id_str" : "519447820164931585",
  "text" : "RT @CorpusSocialSci: New blog: CASS visiting scholar @antlabjp on \"Brainstorming the Future of Corpus Tools\" http:\/\/t.co\/nvze0TPb5v #corpus\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Laurence Anthony",
        "screen_name" : "antlabjp",
        "indices" : [ 32, 41 ],
        "id_str" : "167020390",
        "id" : 167020390
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpusMOOC",
        "indices" : [ 111, 122 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/nvze0TPb5v",
        "expanded_url" : "http:\/\/cass.lancs.ac.uk\/?p=1432",
        "display_url" : "cass.lancs.ac.uk\/?p=1432"
      } ]
    },
    "geo" : { },
    "id_str" : "519412888004734976",
    "text" : "New blog: CASS visiting scholar @antlabjp on \"Brainstorming the Future of Corpus Tools\" http:\/\/t.co\/nvze0TPb5v #corpusMOOC",
    "id" : 519412888004734976,
    "created_at" : "2014-10-07 09:04:17 +0000",
    "user" : {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "protected" : false,
      "id_str" : "1326508478",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3493899777\/ced36fe15c32eb911cbe3d64377524dc_normal.jpeg",
      "id" : 1326508478,
      "verified" : false
    }
  },
  "id" : 519447820164931585,
  "created_at" : "2014-10-07 11:23:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 52, 68 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/agSbN6Brps",
      "expanded_url" : "http:\/\/wp.me\/pBWu-1C0",
      "display_url" : "wp.me\/pBWu-1C0"
    } ]
  },
  "geo" : { },
  "id_str" : "519345302231191552",
  "text" : "Backshifted Conditionals http:\/\/t.co\/agSbN6Brps via @wordpressdotcom",
  "id" : 519345302231191552,
  "created_at" : "2014-10-07 04:35:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/djgTcinvr9",
      "expanded_url" : "http:\/\/venezuelanalysis.com\/analysis\/10945",
      "display_url" : "venezuelanalysis.com\/analysis\/10945"
    } ]
  },
  "geo" : { },
  "id_str" : "519270259660828672",
  "text" : "International Media Barely Raises Eyebrow over Assassination of Pro-Government Legislator in  Venezuela http:\/\/t.co\/djgTcinvr9",
  "id" : 519270259660828672,
  "created_at" : "2014-10-06 23:37:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "indices" : [ 3, 12 ],
      "id_str" : "167020390",
      "id" : 167020390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 124, 140 ],
      "url" : "http:\/\/t.co\/ewIrt0ngbU",
      "expanded_url" : "http:\/\/www.laurenceanthony.net\/antwordprofiler_index.html",
      "display_url" : "laurenceanthony.net\/antwordprofile\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "519258187493806080",
  "text" : "RT @antlabjp: Just released AntWordProfiler 1.4.1 for Macintosh OS X. No more refresh problem on Mavericks. Download it at: http:\/\/t.co\/ewI\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/ewIrt0ngbU",
        "expanded_url" : "http:\/\/www.laurenceanthony.net\/antwordprofiler_index.html",
        "display_url" : "laurenceanthony.net\/antwordprofile\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "519257840276762625",
    "text" : "Just released AntWordProfiler 1.4.1 for Macintosh OS X. No more refresh problem on Mavericks. Download it at: http:\/\/t.co\/ewIrt0ngbU",
    "id" : 519257840276762625,
    "created_at" : "2014-10-06 22:48:11 +0000",
    "user" : {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "protected" : false,
      "id_str" : "167020390",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/428183580821315584\/ocgCI7Er_normal.jpeg",
      "id" : 167020390,
      "verified" : false
    }
  },
  "id" : 519258187493806080,
  "created_at" : "2014-10-06 22:49:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/qQmogud0A4",
      "expanded_url" : "http:\/\/english-jack.blogspot.com\/2014\/10\/on-meeting-otiose-twice-again.html?spref=tw",
      "display_url" : "english-jack.blogspot.com\/2014\/10\/on-mee\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "519255823281696768",
  "text" : "English, Jack: On meeting 'otiose' twice again http:\/\/t.co\/qQmogud0A4",
  "id" : 519255823281696768,
  "created_at" : "2014-10-06 22:40:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hancock McDonald ELT",
      "screen_name" : "HancockMcDonald",
      "indices" : [ 63, 79 ],
      "id_str" : "552929354",
      "id" : 552929354
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 80, 91 ]
    }, {
      "text" : "elt",
      "indices" : [ 92, 96 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 97, 105 ]
    }, {
      "text" : "tefl",
      "indices" : [ 106, 111 ]
    }, {
      "text" : "esl",
      "indices" : [ 112, 116 ]
    }, {
      "text" : "efl",
      "indices" : [ 117, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/6xrmEpa4th",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-Pa",
      "display_url" : "wp.me\/pgHyE-Pa"
    } ]
  },
  "geo" : { },
  "id_str" : "519247811427069952",
  "text" : "You should have the body! http:\/\/t.co\/6xrmEpa4th a response to @HancockMcDonald #corpusmooc #elt #eltchat #tefl #esl #efl",
  "id" : 519247811427069952,
  "created_at" : "2014-10-06 22:08:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Apps 4 EFL",
      "screen_name" : "apps4efl",
      "indices" : [ 0, 9 ],
      "id_str" : "2594237072",
      "id" : 2594237072
    }, {
      "name" : "Paul Raine",
      "screen_name" : "paul_sensei",
      "indices" : [ 10, 22 ],
      "id_str" : "176429301",
      "id" : 176429301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "519213391442083840",
  "geo" : { },
  "id_str" : "519214128947527680",
  "in_reply_to_user_id" : 18602422,
  "text" : "@apps4efl @paul_sensei oops sorry did nit check options! any plans for verbs? thx!",
  "id" : 519214128947527680,
  "in_reply_to_status_id" : 519213391442083840,
  "created_at" : "2014-10-06 19:54:29 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Apps 4 EFL",
      "screen_name" : "apps4efl",
      "indices" : [ 0, 9 ],
      "id_str" : "2594237072",
      "id" : 2594237072
    }, {
      "name" : "Paul Raine",
      "screen_name" : "paul_sensei",
      "indices" : [ 10, 22 ],
      "id_str" : "176429301",
      "id" : 176429301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/Yyzd9kUmMP",
      "expanded_url" : "http:\/\/cloze.it\/",
      "display_url" : "cloze.it"
    } ]
  },
  "in_reply_to_status_id_str" : "518594506900271105",
  "geo" : { },
  "id_str" : "519213391442083840",
  "in_reply_to_user_id" : 2594237072,
  "text" : "@apps4efl @paul_sensei hi any plans for a cloze where u can specify determiners\/prepositions\/verbs like this one http:\/\/t.co\/Yyzd9kUmMP?",
  "id" : 519213391442083840,
  "in_reply_to_status_id" : 518594506900271105,
  "created_at" : "2014-10-06 19:51:33 +0000",
  "in_reply_to_screen_name" : "apps4efl",
  "in_reply_to_user_id_str" : "2594237072",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Aisha Brown",
      "screen_name" : "amyaishab",
      "indices" : [ 3, 13 ],
      "id_str" : "900029641",
      "id" : 900029641
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CorpusMOOC",
      "indices" : [ 36, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 127, 140 ],
      "url" : "http:\/\/t.co\/Jadub85n4S",
      "expanded_url" : "http:\/\/bit.ly\/1Ek3lxW",
      "display_url" : "bit.ly\/1Ek3lxW"
    } ]
  },
  "geo" : { },
  "id_str" : "519204861951614976",
  "text" : "RT @amyaishab: Where do you do your #CorpusMOOC -ing? A challenge has been set on the forum. Can you beat while speed skating? http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CorpusMOOC",
        "indices" : [ 21, 32 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/Jadub85n4S",
        "expanded_url" : "http:\/\/bit.ly\/1Ek3lxW",
        "display_url" : "bit.ly\/1Ek3lxW"
      } ]
    },
    "geo" : { },
    "id_str" : "519085281874808832",
    "text" : "Where do you do your #CorpusMOOC -ing? A challenge has been set on the forum. Can you beat while speed skating? http:\/\/t.co\/Jadub85n4S",
    "id" : 519085281874808832,
    "created_at" : "2014-10-06 11:22:29 +0000",
    "user" : {
      "name" : "Amy Aisha Brown",
      "screen_name" : "amyaishab",
      "protected" : false,
      "id_str" : "900029641",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/620604005799067648\/nD3nCCXK_normal.jpg",
      "id" : 900029641,
      "verified" : false
    }
  },
  "id" : 519204861951614976,
  "created_at" : "2014-10-06 19:17:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beth Harvey",
      "screen_name" : "bethum",
      "indices" : [ 3, 10 ],
      "id_str" : "16318071",
      "id" : 16318071
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 104, 115 ]
    }, {
      "text" : "linguistics",
      "indices" : [ 116, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/wu4CZquSlL",
      "expanded_url" : "http:\/\/bit.ly\/1yH6CqM",
      "display_url" : "bit.ly\/1yH6CqM"
    } ]
  },
  "geo" : { },
  "id_str" : "519204592220135424",
  "text" : "RT @bethum: My newest blog posts about the Corpus Linguistics at Lancaster Uni: http:\/\/t.co\/wu4CZquSlL  #corpusmooc #linguistics",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpusmooc",
        "indices" : [ 92, 103 ]
      }, {
        "text" : "linguistics",
        "indices" : [ 104, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/wu4CZquSlL",
        "expanded_url" : "http:\/\/bit.ly\/1yH6CqM",
        "display_url" : "bit.ly\/1yH6CqM"
      } ]
    },
    "geo" : { },
    "id_str" : "519096819549495296",
    "text" : "My newest blog posts about the Corpus Linguistics at Lancaster Uni: http:\/\/t.co\/wu4CZquSlL  #corpusmooc #linguistics",
    "id" : 519096819549495296,
    "created_at" : "2014-10-06 12:08:20 +0000",
    "user" : {
      "name" : "Beth Harvey",
      "screen_name" : "bethum",
      "protected" : false,
      "id_str" : "16318071",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/654300279068688384\/LuZdvN6c_normal.png",
      "id" : 16318071,
      "verified" : false
    }
  },
  "id" : 519204592220135424,
  "created_at" : "2014-10-06 19:16:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "indices" : [ 3, 19 ],
      "id_str" : "1326508478",
      "id" : 1326508478
    }, {
      "name" : "Mark McGlashan",
      "screen_name" : "Mark_McGlashan",
      "indices" : [ 88, 103 ],
      "id_str" : "286869902",
      "id" : 286869902
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sweepyface",
      "indices" : [ 49, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/YR1qpSjzZF",
      "expanded_url" : "http:\/\/cass.lancs.ac.uk\/?p=1426",
      "display_url" : "cass.lancs.ac.uk\/?p=1426"
    } ]
  },
  "geo" : { },
  "id_str" : "519159906805776384",
  "text" : "RT @CorpusSocialSci: Up-to-the-minute research: \"#Sweepyface: a linguistic profile\", by @Mark_McGlashan http:\/\/t.co\/YR1qpSjzZF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mark McGlashan",
        "screen_name" : "Mark_McGlashan",
        "indices" : [ 67, 82 ],
        "id_str" : "286869902",
        "id" : 286869902
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Sweepyface",
        "indices" : [ 28, 39 ]
      } ],
      "urls" : [ {
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/YR1qpSjzZF",
        "expanded_url" : "http:\/\/cass.lancs.ac.uk\/?p=1426",
        "display_url" : "cass.lancs.ac.uk\/?p=1426"
      } ]
    },
    "geo" : { },
    "id_str" : "519158103175331840",
    "text" : "Up-to-the-minute research: \"#Sweepyface: a linguistic profile\", by @Mark_McGlashan http:\/\/t.co\/YR1qpSjzZF",
    "id" : 519158103175331840,
    "created_at" : "2014-10-06 16:11:51 +0000",
    "user" : {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "protected" : false,
      "id_str" : "1326508478",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3493899777\/ced36fe15c32eb911cbe3d64377524dc_normal.jpeg",
      "id" : 1326508478,
      "verified" : false
    }
  },
  "id" : 519159906805776384,
  "created_at" : "2014-10-06 16:19:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alannah Fitzgerald",
      "screen_name" : "AlannahFitz",
      "indices" : [ 0, 12 ],
      "id_str" : "223613160",
      "id" : 223613160
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "519132668928475137",
  "in_reply_to_user_id" : 223613160,
  "text" : "@AlannahFitz hi the people's choice link is broken",
  "id" : 519132668928475137,
  "created_at" : "2014-10-06 14:30:47 +0000",
  "in_reply_to_screen_name" : "AlannahFitz",
  "in_reply_to_user_id_str" : "223613160",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alannah Fitzgerald",
      "screen_name" : "AlannahFitz",
      "indices" : [ 88, 100 ],
      "id_str" : "223613160",
      "id" : 223613160
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/edrR5t4JWn",
      "expanded_url" : "http:\/\/wp.me\/p4ZDSP-L4",
      "display_url" : "wp.me\/p4ZDSP-L4"
    } ]
  },
  "geo" : { },
  "id_str" : "519129692175994880",
  "text" : "Wow! The FLAX Language System - So Much Open and Linked Data http:\/\/t.co\/edrR5t4JWn via @AlannahFitz",
  "id" : 519129692175994880,
  "created_at" : "2014-10-06 14:18:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noor Adnan",
      "screen_name" : "n00rbaizura",
      "indices" : [ 0, 12 ],
      "id_str" : "412094121",
      "id" : 412094121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/DS2hu9PVRx",
      "expanded_url" : "http:\/\/programminghistorian.org\/lessons\/",
      "display_url" : "programminghistorian.org\/lessons\/"
    } ]
  },
  "in_reply_to_status_id_str" : "519096285911982080",
  "geo" : { },
  "id_str" : "519127898155151361",
  "in_reply_to_user_id" : 412094121,
  "text" : "@n00rbaizura  for the programming route check out the programming historian guides http:\/\/t.co\/DS2hu9PVRx if not done so already",
  "id" : 519127898155151361,
  "in_reply_to_status_id" : 519096285911982080,
  "created_at" : "2014-10-06 14:11:50 +0000",
  "in_reply_to_screen_name" : "n00rbaizura",
  "in_reply_to_user_id_str" : "412094121",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noor Adnan",
      "screen_name" : "n00rbaizura",
      "indices" : [ 0, 12 ],
      "id_str" : "412094121",
      "id" : 412094121
    }, {
      "name" : "Magnus Nissel",
      "screen_name" : "u203d",
      "indices" : [ 13, 19 ],
      "id_str" : "533114985",
      "id" : 533114985
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "519074840066547713",
  "geo" : { },
  "id_str" : "519084507186466816",
  "in_reply_to_user_id" : 412094121,
  "text" : "@n00rbaizura @u203d hi for non-programming approach have u tried bootcat? iceweb? corpuscreator? textstat?",
  "id" : 519084507186466816,
  "in_reply_to_status_id" : 519074840066547713,
  "created_at" : "2014-10-06 11:19:25 +0000",
  "in_reply_to_screen_name" : "n00rbaizura",
  "in_reply_to_user_id_str" : "412094121",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "518873143130083328",
  "geo" : { },
  "id_str" : "519082886625251329",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan \/me clapping and cheering welcome back\/ :)",
  "id" : 519082886625251329,
  "in_reply_to_status_id" : 518873143130083328,
  "created_at" : "2014-10-06 11:12:58 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    }, {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 71, 86 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "519077811349618688",
  "geo" : { },
  "id_str" : "519082205965201408",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl geoff has mentioned this recently in a couple of his blog posts @GeoffreyJordan maybe he could do a follow-up on this?",
  "id" : 519082205965201408,
  "in_reply_to_status_id" : 519077811349618688,
  "created_at" : "2014-10-06 11:10:16 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "i_narrator",
      "screen_name" : "i_narrator",
      "indices" : [ 90, 101 ],
      "id_str" : "281361233",
      "id" : 281361233
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 0, 11 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/VPIHcaK4Kb",
      "expanded_url" : "http:\/\/youtu.be\/21a-lOghoK0",
      "display_url" : "youtu.be\/21a-lOghoK0"
    } ]
  },
  "geo" : { },
  "id_str" : "519081795779039232",
  "text" : "#corpusmooc 5 Reasons: Anke Luedeling on \"Corpus Linguistics\": http:\/\/t.co\/VPIHcaK4Kb h\/t @i_narrator",
  "id" : 519081795779039232,
  "created_at" : "2014-10-06 11:08:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "i_narrator",
      "screen_name" : "i_narrator",
      "indices" : [ 3, 14 ],
      "id_str" : "281361233",
      "id" : 281361233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/GQH7oiWLbE",
      "expanded_url" : "http:\/\/youtu.be\/gpxgh34pSAI",
      "display_url" : "youtu.be\/gpxgh34pSAI"
    } ]
  },
  "geo" : { },
  "id_str" : "519081380396171264",
  "text" : "RT @i_narrator: Linguistic Data Analysis - The BNC Frequency Search: http:\/\/t.co\/GQH7oiWLbE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 75 ],
        "url" : "http:\/\/t.co\/GQH7oiWLbE",
        "expanded_url" : "http:\/\/youtu.be\/gpxgh34pSAI",
        "display_url" : "youtu.be\/gpxgh34pSAI"
      } ]
    },
    "geo" : { },
    "id_str" : "519007165848100864",
    "text" : "Linguistic Data Analysis - The BNC Frequency Search: http:\/\/t.co\/GQH7oiWLbE",
    "id" : 519007165848100864,
    "created_at" : "2014-10-06 06:12:05 +0000",
    "user" : {
      "name" : "i_narrator",
      "screen_name" : "i_narrator",
      "protected" : false,
      "id_str" : "281361233",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000410308329\/8ed838331668e90230fc3a90a453f21b_normal.jpeg",
      "id" : 281361233,
      "verified" : false
    }
  },
  "id" : 519081380396171264,
  "created_at" : "2014-10-06 11:06:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hancock McDonald ELT",
      "screen_name" : "HancockMcDonald",
      "indices" : [ 3, 19 ],
      "id_str" : "552929354",
      "id" : 552929354
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/bQSpGWK1PF",
      "expanded_url" : "http:\/\/tinyurl.com\/pm4sfyr",
      "display_url" : "tinyurl.com\/pm4sfyr"
    } ]
  },
  "geo" : { },
  "id_str" : "519079976449343488",
  "text" : "RT @HancockMcDonald: Bringing the corpus back to life? Reflections on McCarthy on spoken grammar http:\/\/t.co\/bQSpGWK1PF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/bQSpGWK1PF",
        "expanded_url" : "http:\/\/tinyurl.com\/pm4sfyr",
        "display_url" : "tinyurl.com\/pm4sfyr"
      } ]
    },
    "geo" : { },
    "id_str" : "519068726474190848",
    "text" : "Bringing the corpus back to life? Reflections on McCarthy on spoken grammar http:\/\/t.co\/bQSpGWK1PF",
    "id" : 519068726474190848,
    "created_at" : "2014-10-06 10:16:42 +0000",
    "user" : {
      "name" : "Hancock McDonald ELT",
      "screen_name" : "HancockMcDonald",
      "protected" : false,
      "id_str" : "552929354",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2158919436\/HM_portrait_normal.jpg",
      "id" : 552929354,
      "verified" : false
    }
  },
  "id" : 519079976449343488,
  "created_at" : "2014-10-06 11:01:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((David Traynier)))",
      "screen_name" : "DTraynier",
      "indices" : [ 3, 13 ],
      "id_str" : "317716198",
      "id" : 317716198
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IS",
      "indices" : [ 115, 118 ]
    }, {
      "text" : "Iraq",
      "indices" : [ 119, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "518875569141055488",
  "text" : "RT @DTraynier: Proverb of the future,  \"When the only tool you have is bombing, every problem looks like an Arab.\" #IS #Iraq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/seesmic.com\/\" rel=\"nofollow\"\u003ESeesmic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IS",
        "indices" : [ 100, 103 ]
      }, {
        "text" : "Iraq",
        "indices" : [ 104, 109 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "518843094306127872",
    "text" : "Proverb of the future,  \"When the only tool you have is bombing, every problem looks like an Arab.\" #IS #Iraq",
    "id" : 518843094306127872,
    "created_at" : "2014-10-05 19:20:07 +0000",
    "user" : {
      "name" : "(((David Traynier)))",
      "screen_name" : "DTraynier",
      "protected" : false,
      "id_str" : "317716198",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727929911877480451\/fLuwL370_normal.jpg",
      "id" : 317716198,
      "verified" : false
    }
  },
  "id" : 518875569141055488,
  "created_at" : "2014-10-05 21:29:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 69, 84 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/irzsBKiZMh",
      "expanded_url" : "http:\/\/wp.me\/p3qkCB-Yk",
      "display_url" : "wp.me\/p3qkCB-Yk"
    } ]
  },
  "geo" : { },
  "id_str" : "518852661395742722",
  "text" : "Lexical Priming and the Competition Model http:\/\/t.co\/irzsBKiZMh via @GeoffreyJordan",
  "id" : 518852661395742722,
  "created_at" : "2014-10-05 19:58:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 3, 14 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "efl",
      "indices" : [ 124, 128 ]
    }, {
      "text" : "elt",
      "indices" : [ 129, 133 ]
    }, {
      "text" : "tesol",
      "indices" : [ 134, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/aUJIHBNRLZ",
      "expanded_url" : "http:\/\/leoxicon.blogspot.com\/2014\/10\/generate-language-silent-clips.html",
      "display_url" : "leoxicon.blogspot.com\/2014\/10\/genera\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "518846415007936512",
  "text" : "RT @leoselivan: New blog post: Not a word was spoken - generating language from silent video clips http:\/\/t.co\/aUJIHBNRLZ   #efl #elt #tesol",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "efl",
        "indices" : [ 108, 112 ]
      }, {
        "text" : "elt",
        "indices" : [ 113, 117 ]
      }, {
        "text" : "tesol",
        "indices" : [ 118, 124 ]
      } ],
      "urls" : [ {
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/aUJIHBNRLZ",
        "expanded_url" : "http:\/\/leoxicon.blogspot.com\/2014\/10\/generate-language-silent-clips.html",
        "display_url" : "leoxicon.blogspot.com\/2014\/10\/genera\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "518816232326172673",
    "text" : "New blog post: Not a word was spoken - generating language from silent video clips http:\/\/t.co\/aUJIHBNRLZ   #efl #elt #tesol",
    "id" : 518816232326172673,
    "created_at" : "2014-10-05 17:33:23 +0000",
    "user" : {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "protected" : false,
      "id_str" : "408365496",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/460546508601819136\/12ivDBb__normal.jpeg",
      "id" : 408365496,
      "verified" : false
    }
  },
  "id" : 518846415007936512,
  "created_at" : "2014-10-05 19:33:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 0, 11 ]
    }, {
      "text" : "videogrep",
      "indices" : [ 42, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/Vr3t9q05Mv",
      "expanded_url" : "http:\/\/youtu.be\/iXBg5eDZYfM",
      "display_url" : "youtu.be\/iXBg5eDZYfM"
    } ]
  },
  "geo" : { },
  "id_str" : "518846291413962753",
  "text" : "#corpusmooc it takes two, in conversation #videogrep supercut : http:\/\/t.co\/Vr3t9q05Mv",
  "id" : 518846291413962753,
  "created_at" : "2014-10-05 19:32:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joanna M",
      "screen_name" : "joannacre",
      "indices" : [ 0, 10 ],
      "id_str" : "444977554",
      "id" : 444977554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "518731381476978689",
  "geo" : { },
  "id_str" : "518789567227650048",
  "in_reply_to_user_id" : 444977554,
  "text" : "@joannacre yr very welcome have a good sunday :)",
  "id" : 518789567227650048,
  "in_reply_to_status_id" : 518731381476978689,
  "created_at" : "2014-10-05 15:47:26 +0000",
  "in_reply_to_screen_name" : "joannacre",
  "in_reply_to_user_id_str" : "444977554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joanna M",
      "screen_name" : "joannacre",
      "indices" : [ 3, 13 ],
      "id_str" : "444977554",
      "id" : 444977554
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "academic",
      "indices" : [ 52, 61 ]
    }, {
      "text" : "writing",
      "indices" : [ 62, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/5D2CU6B9z7",
      "expanded_url" : "http:\/\/myeltrambles.blogspot.gr\/2014\/10\/eap-writing.html",
      "display_url" : "myeltrambles.blogspot.gr\/2014\/10\/eap-wr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "518730402610311168",
  "text" : "RT @joannacre: Putting into practice what you teach #academic #writing . A post about my academic writing reality  http:\/\/t.co\/5D2CU6B9z7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "academic",
        "indices" : [ 37, 46 ]
      }, {
        "text" : "writing",
        "indices" : [ 47, 55 ]
      } ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/5D2CU6B9z7",
        "expanded_url" : "http:\/\/myeltrambles.blogspot.gr\/2014\/10\/eap-writing.html",
        "display_url" : "myeltrambles.blogspot.gr\/2014\/10\/eap-wr\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "518718527428386816",
    "text" : "Putting into practice what you teach #academic #writing . A post about my academic writing reality  http:\/\/t.co\/5D2CU6B9z7",
    "id" : 518718527428386816,
    "created_at" : "2014-10-05 11:05:08 +0000",
    "user" : {
      "name" : "Joanna M",
      "screen_name" : "joannacre",
      "protected" : false,
      "id_str" : "444977554",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3251727601\/179472a3feae34c6561a1dd313c450b9_normal.jpeg",
      "id" : 444977554,
      "verified" : false
    }
  },
  "id" : 518730402610311168,
  "created_at" : "2014-10-05 11:52:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 3, 14 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "tefl",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/A3NgUaMlbM",
      "expanded_url" : "http:\/\/buff.ly\/1rUMBbs",
      "display_url" : "buff.ly\/1rUMBbs"
    } ]
  },
  "geo" : { },
  "id_str" : "518719197346820097",
  "text" : "RT @leoselivan: Language teachers with corpora in mind: from starting steps to walking tall Language Learning, 39(1) http:\/\/t.co\/A3NgUaMlbM\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "elt",
        "indices" : [ 124, 128 ]
      }, {
        "text" : "tefl",
        "indices" : [ 129, 134 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/A3NgUaMlbM",
        "expanded_url" : "http:\/\/buff.ly\/1rUMBbs",
        "display_url" : "buff.ly\/1rUMBbs"
      } ]
    },
    "geo" : { },
    "id_str" : "518718282397147136",
    "text" : "Language teachers with corpora in mind: from starting steps to walking tall Language Learning, 39(1) http:\/\/t.co\/A3NgUaMlbM #elt #tefl",
    "id" : 518718282397147136,
    "created_at" : "2014-10-05 11:04:10 +0000",
    "user" : {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "protected" : false,
      "id_str" : "408365496",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/460546508601819136\/12ivDBb__normal.jpeg",
      "id" : 408365496,
      "verified" : false
    }
  },
  "id" : 518719197346820097,
  "created_at" : "2014-10-05 11:07:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Lancaster",
      "screen_name" : "S_J_Lancaster",
      "indices" : [ 3, 17 ],
      "id_str" : "240186025",
      "id" : 240186025
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ccourses",
      "indices" : [ 22, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "518552181201719296",
  "text" : "RT @S_J_Lancaster: ok #ccourses, what is \"quantum learning\" ?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ccourses",
        "indices" : [ 3, 12 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "518510481469083648",
    "text" : "ok #ccourses, what is \"quantum learning\" ?",
    "id" : 518510481469083648,
    "created_at" : "2014-10-04 21:18:26 +0000",
    "user" : {
      "name" : "Simon Lancaster",
      "screen_name" : "S_J_Lancaster",
      "protected" : false,
      "id_str" : "240186025",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000053679902\/d95b82c56b64d2ec493fe9be630663fb_normal.jpeg",
      "id" : 240186025,
      "verified" : false
    }
  },
  "id" : 518552181201719296,
  "created_at" : "2014-10-05 00:04:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 89, 100 ]
    }, {
      "text" : "textisbeautiful",
      "indices" : [ 124, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/9VXGGKKOdj",
      "expanded_url" : "http:\/\/i.imgur.com\/t1l4ypV.png",
      "display_url" : "i.imgur.com\/t1l4ypV.png"
    } ]
  },
  "geo" : { },
  "id_str" : "518532045556162561",
  "text" : "Another bit o fun, topic web of what u want to find out about lang question with 3 likes #corpusmooc http:\/\/t.co\/9VXGGKKOdj #textisbeautiful",
  "id" : 518532045556162561,
  "created_at" : "2014-10-04 22:44:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "518459536655798272",
  "geo" : { },
  "id_str" : "518463095266869248",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan i use google doc Research tool, have u tried that? saves a lot of time",
  "id" : 518463095266869248,
  "in_reply_to_status_id" : 518459536655798272,
  "created_at" : "2014-10-04 18:10:09 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ccourses",
      "indices" : [ 84, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/3raDQOYRnA",
      "expanded_url" : "http:\/\/lareviewofbooks.org\/review\/college-still-worth\/#.VDAqi1KR6bI.twitter",
      "display_url" : "lareviewofbooks.org\/review\/college\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "518448709562937344",
  "text" : "Is College Still Worth It? | The Los Angeles Review of Books http:\/\/t.co\/3raDQOYRnA #ccourses",
  "id" : 518448709562937344,
  "created_at" : "2014-10-04 17:12:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "indices" : [ 0, 13 ],
      "id_str" : "1685397408",
      "id" : 1685397408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "518445331311505408",
  "geo" : { },
  "id_str" : "518446039096115200",
  "in_reply_to_user_id" : 1685397408,
  "text" : "@harrisonmike looks like the Pressey machine?",
  "id" : 518446039096115200,
  "in_reply_to_status_id" : 518445331311505408,
  "created_at" : "2014-10-04 17:02:22 +0000",
  "in_reply_to_screen_name" : "harrisonmike",
  "in_reply_to_user_id_str" : "1685397408",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 46, 57 ]
    }, {
      "text" : "textisbeautiful",
      "indices" : [ 101, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/xOrxiqrEvX",
      "expanded_url" : "http:\/\/i.imgur.com\/416HIHC.png",
      "display_url" : "i.imgur.com\/416HIHC.png"
    } ]
  },
  "geo" : { },
  "id_str" : "518360251389599744",
  "text" : "a bit of fun: correlation wheel viz for intro #corpusmooc with min of 3 likes http:\/\/t.co\/xOrxiqrEvX #textisbeautiful",
  "id" : 518360251389599744,
  "created_at" : "2014-10-04 11:21:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 0, 11 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/r8qHcM8JBZ",
      "expanded_url" : "http:\/\/homes.chass.utoronto.ca\/~cpercy\/courses\/6361corrigan.htm",
      "display_url" : "homes.chass.utoronto.ca\/~cpercy\/course\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "518350623344168960",
  "geo" : { },
  "id_str" : "518353964547710976",
  "in_reply_to_user_id" : 88202140,
  "text" : "@hughdellar there's some nice example here http:\/\/t.co\/r8qHcM8JBZ",
  "id" : 518353964547710976,
  "in_reply_to_status_id" : 518350623344168960,
  "created_at" : "2014-10-04 10:56:30 +0000",
  "in_reply_to_screen_name" : "hughdellar",
  "in_reply_to_user_id_str" : "88202140",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beth Harvey",
      "screen_name" : "bethum",
      "indices" : [ 0, 7 ],
      "id_str" : "16318071",
      "id" : 16318071
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 21, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/NaTp83UXWu",
      "expanded_url" : "http:\/\/mis-maple.lancs.ac.uk\/corpus\/?cat=4",
      "display_url" : "mis-maple.lancs.ac.uk\/corpus\/?cat=4"
    } ]
  },
  "in_reply_to_status_id_str" : "518068958176755712",
  "geo" : { },
  "id_str" : "518346706942189568",
  "in_reply_to_user_id" : 16318071,
  "text" : "@bethum hi i like yr #corpusmooc blog don't forget to send rss link to coursereader http:\/\/t.co\/NaTp83UXWu",
  "id" : 518346706942189568,
  "in_reply_to_status_id" : 518068958176755712,
  "created_at" : "2014-10-04 10:27:40 +0000",
  "in_reply_to_screen_name" : "bethum",
  "in_reply_to_user_id_str" : "16318071",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Olson",
      "screen_name" : "mark_olson",
      "indices" : [ 0, 11 ],
      "id_str" : "3688491",
      "id" : 3688491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "518342806134611968",
  "in_reply_to_user_id" : 3688491,
  "text" : "@mark_olson hi sent Q about storyboard to yr gmail add, did u get it? thx",
  "id" : 518342806134611968,
  "created_at" : "2014-10-04 10:12:09 +0000",
  "in_reply_to_screen_name" : "mark_olson",
  "in_reply_to_user_id_str" : "3688491",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 110, 121 ]
    }, {
      "text" : "funnysad",
      "indices" : [ 122, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "518332161234313216",
  "text" : "lol there's a comment frm a participant about wanting to one up an annoying colleague as a reason for joining #corpusmooc #funnysad",
  "id" : 518332161234313216,
  "created_at" : "2014-10-04 09:29:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Natallia Novikava",
      "screen_name" : "Natashetta",
      "indices" : [ 0, 11 ],
      "id_str" : "56308635",
      "id" : 56308635
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "518281686157500416",
  "geo" : { },
  "id_str" : "518322767503298561",
  "in_reply_to_user_id" : 56308635,
  "text" : "@Natashetta thanks for share natallia how r u doing?",
  "id" : 518322767503298561,
  "in_reply_to_status_id" : 518281686157500416,
  "created_at" : "2014-10-04 08:52:32 +0000",
  "in_reply_to_screen_name" : "Natashetta",
  "in_reply_to_user_id_str" : "56308635",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 97, 113 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 114, 122 ]
    }, {
      "text" : "efl",
      "indices" : [ 123, 127 ]
    }, {
      "text" : "esl",
      "indices" : [ 128, 132 ]
    }, {
      "text" : "tefl",
      "indices" : [ 133, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/pgD01FP2gz",
      "expanded_url" : "http:\/\/wp.me\/p3vQZV-uN",
      "display_url" : "wp.me\/p3vQZV-uN"
    } ]
  },
  "geo" : { },
  "id_str" : "518321648152223746",
  "text" : "Vocabulary Learning and Instruction: A Journal of Vocabulary Research http:\/\/t.co\/pgD01FP2gz via @wordpressdotcom #eltchat #efl #esl #tefl",
  "id" : 518321648152223746,
  "created_at" : "2014-10-04 08:48:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hana Tich\u00E1",
      "screen_name" : "HanaTicha",
      "indices" : [ 3, 13 ],
      "id_str" : "512296705",
      "id" : 512296705
    }, {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 124, 135 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/ujx5JeCgck",
      "expanded_url" : "http:\/\/wp.me\/p4dmjk-ag",
      "display_url" : "wp.me\/p4dmjk-ag"
    } ]
  },
  "geo" : { },
  "id_str" : "517982380179861504",
  "text" : "RT @HanaTicha: Some great reading, important issue, for intermediate learners: My Friend, Marco  http:\/\/t.co\/ujx5JeCgck via @kevchanwow",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kevin Stein",
        "screen_name" : "kevchanwow",
        "indices" : [ 109, 120 ],
        "id_str" : "144663117",
        "id" : 144663117
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/ujx5JeCgck",
        "expanded_url" : "http:\/\/wp.me\/p4dmjk-ag",
        "display_url" : "wp.me\/p4dmjk-ag"
      } ]
    },
    "geo" : { },
    "id_str" : "517968042089660416",
    "text" : "Some great reading, important issue, for intermediate learners: My Friend, Marco  http:\/\/t.co\/ujx5JeCgck via @kevchanwow",
    "id" : 517968042089660416,
    "created_at" : "2014-10-03 09:22:59 +0000",
    "user" : {
      "name" : "Hana Tich\u00E1",
      "screen_name" : "HanaTicha",
      "protected" : false,
      "id_str" : "512296705",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/699528253598494721\/HL9Np6Gu_normal.jpg",
      "id" : 512296705,
      "verified" : false
    }
  },
  "id" : 517982380179861504,
  "created_at" : "2014-10-03 10:19:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bella Caledonia",
      "screen_name" : "bellacaledonia",
      "indices" : [ 49, 64 ],
      "id_str" : "103554348",
      "id" : 103554348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/XWegqKtxkb",
      "expanded_url" : "http:\/\/wp.me\/p93oK-4pj",
      "display_url" : "wp.me\/p93oK-4pj"
    } ]
  },
  "geo" : { },
  "id_str" : "517982143557804032",
  "text" : "A New Circle Politics http:\/\/t.co\/XWegqKtxkb via @bellacaledonia",
  "id" : 517982143557804032,
  "created_at" : "2014-10-03 10:19:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/VEFsJzZHEe",
      "expanded_url" : "http:\/\/www.craigmurray.org.uk\/archives\/2014\/10\/theresa-may-must-resign\/",
      "display_url" : "craigmurray.org.uk\/archives\/2014\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "517810345730400256",
  "text" : "RT @pchallinor: Mad old cat lady must go http:\/\/t.co\/VEFsJzZHEe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 25, 47 ],
        "url" : "http:\/\/t.co\/VEFsJzZHEe",
        "expanded_url" : "http:\/\/www.craigmurray.org.uk\/archives\/2014\/10\/theresa-may-must-resign\/",
        "display_url" : "craigmurray.org.uk\/archives\/2014\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "517754969840427008",
    "text" : "Mad old cat lady must go http:\/\/t.co\/VEFsJzZHEe",
    "id" : 517754969840427008,
    "created_at" : "2014-10-02 19:16:18 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 517810345730400256,
  "created_at" : "2014-10-02 22:56:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    }, {
      "name" : "BBC News (UK)",
      "screen_name" : "BBCNews",
      "indices" : [ 67, 75 ],
      "id_str" : "612473",
      "id" : 612473
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/lvYxbfAEsB",
      "expanded_url" : "http:\/\/www.medialens.org\/index.php\/alerts\/alert-archive\/2014\/777-the-comic-book-simplicity-of-propaganda.html",
      "display_url" : "medialens.org\/index.php\/aler\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "517770382666121216",
  "text" : "RT @medialens: Biased towards power, yet funded at public expense, @BBCNews is surely the most insidious propaganda outlet today. http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BBC News (UK)",
        "screen_name" : "BBCNews",
        "indices" : [ 52, 60 ],
        "id_str" : "612473",
        "id" : 612473
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/lvYxbfAEsB",
        "expanded_url" : "http:\/\/www.medialens.org\/index.php\/alerts\/alert-archive\/2014\/777-the-comic-book-simplicity-of-propaganda.html",
        "display_url" : "medialens.org\/index.php\/aler\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "517665552962449408",
    "text" : "Biased towards power, yet funded at public expense, @BBCNews is surely the most insidious propaganda outlet today. http:\/\/t.co\/lvYxbfAEsB",
    "id" : 517665552962449408,
    "created_at" : "2014-10-02 13:21:00 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 517770382666121216,
  "created_at" : "2014-10-02 20:17:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EALNexus",
      "indices" : [ 0, 9 ]
    }, {
      "text" : "videogrep",
      "indices" : [ 46, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517684557223833600",
  "text" : "#EALNexus fav current online resource\/tool is #videogrep for micro-listenings",
  "id" : 517684557223833600,
  "created_at" : "2014-10-02 14:36:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robbie Love",
      "screen_name" : "lovermob",
      "indices" : [ 3, 12 ],
      "id_str" : "19469715",
      "id" : 19469715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/ltT3MxYwoc",
      "expanded_url" : "http:\/\/cass.lancs.ac.uk\/?p=1407",
      "display_url" : "cass.lancs.ac.uk\/?p=1407"
    } ]
  },
  "geo" : { },
  "id_str" : "517678511134638080",
  "text" : "RT @lovermob: My reflections on the recent Spoken BNC media coverage \"Swimming in the deep end of the Spoken BNC2014 media frenzy\" http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/ltT3MxYwoc",
        "expanded_url" : "http:\/\/cass.lancs.ac.uk\/?p=1407",
        "display_url" : "cass.lancs.ac.uk\/?p=1407"
      } ]
    },
    "geo" : { },
    "id_str" : "517675739475632128",
    "text" : "My reflections on the recent Spoken BNC media coverage \"Swimming in the deep end of the Spoken BNC2014 media frenzy\" http:\/\/t.co\/ltT3MxYwoc",
    "id" : 517675739475632128,
    "created_at" : "2014-10-02 14:01:28 +0000",
    "user" : {
      "name" : "Robbie Love",
      "screen_name" : "lovermob",
      "protected" : false,
      "id_str" : "19469715",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733371018056716288\/4lRj6knU_normal.jpg",
      "id" : 19469715,
      "verified" : false
    }
  },
  "id" : 517678511134638080,
  "created_at" : "2014-10-02 14:12:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Moore",
      "screen_name" : "lexicojules",
      "indices" : [ 62, 74 ],
      "id_str" : "424320799",
      "id" : 424320799
    }, {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 79, 90 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 91, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/ExwSjo1epz",
      "expanded_url" : "http:\/\/news.collinselt.com\/wp-content\/uploads\/2014\/10\/MET-Oct_2014_Moore.pdf",
      "display_url" : "news.collinselt.com\/wp-content\/upl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "517658383525371904",
  "text" : "What has a corpus ever done for us? http:\/\/t.co\/ExwSjo1epz by @lexicojules h\/t @lexicoloco #corpusmooc",
  "id" : 517658383525371904,
  "created_at" : "2014-10-02 12:52:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 64, 74 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/z98UwCqe15",
      "expanded_url" : "http:\/\/goo.gl\/Y59U5U",
      "display_url" : "goo.gl\/Y59U5U"
    } ]
  },
  "geo" : { },
  "id_str" : "517622135737434112",
  "text" : "Beheadings v. Drone Assassinations - http:\/\/t.co\/z98UwCqe15 h\/t @medialens",
  "id" : 517622135737434112,
  "created_at" : "2014-10-02 10:28:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The BMJ",
      "screen_name" : "bmj_latest",
      "indices" : [ 3, 14 ],
      "id_str" : "16949344",
      "id" : 16949344
    }, {
      "name" : "WHO",
      "screen_name" : "WHO",
      "indices" : [ 33, 37 ],
      "id_str" : "14499829",
      "id" : 14499829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/NkNitUHaPJ",
      "expanded_url" : "http:\/\/www.bmj.com\/content\/349\/bmj.g5945",
      "display_url" : "bmj.com\/content\/349\/bm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "517621114571616257",
  "text" : "RT @bmj_latest: The BMJ calls on @WHO to declare a public health emergency on climate change http:\/\/t.co\/NkNitUHaPJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "WHO",
        "screen_name" : "WHO",
        "indices" : [ 17, 21 ],
        "id_str" : "14499829",
        "id" : 14499829
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/NkNitUHaPJ",
        "expanded_url" : "http:\/\/www.bmj.com\/content\/349\/bmj.g5945",
        "display_url" : "bmj.com\/content\/349\/bm\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "517588846083850242",
    "text" : "The BMJ calls on @WHO to declare a public health emergency on climate change http:\/\/t.co\/NkNitUHaPJ",
    "id" : 517588846083850242,
    "created_at" : "2014-10-02 08:16:11 +0000",
    "user" : {
      "name" : "The BMJ",
      "screen_name" : "bmj_latest",
      "protected" : false,
      "id_str" : "16949344",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/681770672369102848\/d7pjAVkK_normal.png",
      "id" : 16949344,
      "verified" : false
    }
  },
  "id" : 517621114571616257,
  "created_at" : "2014-10-02 10:24:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marek Kiczkowiak",
      "screen_name" : "MarekKiczkowiak",
      "indices" : [ 14, 30 ],
      "id_str" : "2561325079",
      "id" : 2561325079
    }, {
      "name" : "Anthony Ash FRSA",
      "screen_name" : "Ashowski",
      "indices" : [ 31, 40 ],
      "id_str" : "316596356",
      "id" : 316596356
    }, {
      "name" : "George Chilton",
      "screen_name" : "designerlessons",
      "indices" : [ 41, 57 ],
      "id_str" : "432090149",
      "id" : 432090149
    }, {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 58, 67 ],
      "id_str" : "134211317",
      "id" : 134211317
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517611359597764608",
  "text" : "RT @becksdad: @MarekKiczkowiak @Ashowski @designerlessons @josipa74 I'd sign up to a broad, independent &amp; international \"Teachers as Worker\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Marek Kiczkowiak",
        "screen_name" : "MarekKiczkowiak",
        "indices" : [ 0, 16 ],
        "id_str" : "2561325079",
        "id" : 2561325079
      }, {
        "name" : "Anthony Ash FRSA",
        "screen_name" : "Ashowski",
        "indices" : [ 17, 26 ],
        "id_str" : "316596356",
        "id" : 316596356
      }, {
        "name" : "George Chilton",
        "screen_name" : "designerlessons",
        "indices" : [ 27, 43 ],
        "id_str" : "432090149",
        "id" : 432090149
      }, {
        "name" : "paulw",
        "screen_name" : "josipa74",
        "indices" : [ 44, 53 ],
        "id_str" : "134211317",
        "id" : 134211317
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "517572005605146624",
    "geo" : { },
    "id_str" : "517582410008252416",
    "in_reply_to_user_id" : 2561325079,
    "text" : "@MarekKiczkowiak @Ashowski @designerlessons @josipa74 I'd sign up to a broad, independent &amp; international \"Teachers as Workers\" platform.",
    "id" : 517582410008252416,
    "in_reply_to_status_id" : 517572005605146624,
    "created_at" : "2014-10-02 07:50:37 +0000",
    "in_reply_to_screen_name" : "MarekKiczkowiak",
    "in_reply_to_user_id_str" : "2561325079",
    "user" : {
      "name" : "Neil McMillan",
      "screen_name" : "neil_mcm",
      "protected" : false,
      "id_str" : "60425505",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/419471700510920704\/RMN34luB_normal.jpeg",
      "id" : 60425505,
      "verified" : false
    }
  },
  "id" : 517611359597764608,
  "created_at" : "2014-10-02 09:45:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ccourses",
      "indices" : [ 89, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517456461257924608",
  "text" : "daily connect: enthuisasm for connected learning vs cold hard look at connected learning #ccourses",
  "id" : 517456461257924608,
  "created_at" : "2014-10-01 23:30:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u6C34\u672C\u3000\u7BE4",
      "screen_name" : "MizumotoAtsushi",
      "indices" : [ 3, 19 ],
      "id_str" : "298592919",
      "id" : 298592919
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/jVM7yuCVsR",
      "expanded_url" : "http:\/\/jaecs.com\/index.html",
      "display_url" : "jaecs.com\/index.html"
    } ]
  },
  "geo" : { },
  "id_str" : "517344453938278401",
  "text" : "RT @MizumotoAtsushi: New Website of JAECS (Japan Association for English Corpus Studies) \u82F1\u8A9E\u30B3\u30FC\u30D1\u30B9\u5B66\u4F1A http:\/\/t.co\/jVM7yuCVsR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/jVM7yuCVsR",
        "expanded_url" : "http:\/\/jaecs.com\/index.html",
        "display_url" : "jaecs.com\/index.html"
      } ]
    },
    "geo" : { },
    "id_str" : "517314664003166208",
    "text" : "New Website of JAECS (Japan Association for English Corpus Studies) \u82F1\u8A9E\u30B3\u30FC\u30D1\u30B9\u5B66\u4F1A http:\/\/t.co\/jVM7yuCVsR",
    "id" : 517314664003166208,
    "created_at" : "2014-10-01 14:06:41 +0000",
    "user" : {
      "name" : "\u6C34\u672C\u3000\u7BE4",
      "screen_name" : "MizumotoAtsushi",
      "protected" : false,
      "id_str" : "298592919",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2270366030\/knwooygvz9psyx838thw_normal.jpeg",
      "id" : 298592919,
      "verified" : false
    }
  },
  "id" : 517344453938278401,
  "created_at" : "2014-10-01 16:05:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 67, 75 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/cRxmSqn3OC",
      "expanded_url" : "http:\/\/youtu.be\/0YBumQHPAeU",
      "display_url" : "youtu.be\/0YBumQHPAeU"
    } ]
  },
  "geo" : { },
  "id_str" : "517342214704201728",
  "text" : "Cassetteboy - Cameron's Conference Rap: http:\/\/t.co\/cRxmSqn3OC via @YouTube",
  "id" : 517342214704201728,
  "created_at" : "2014-10-01 15:56:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lewis School HR",
      "screen_name" : "alatlewisschool",
      "indices" : [ 3, 19 ],
      "id_str" : "473783869",
      "id" : 473783869
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 140 ],
      "url" : "http:\/\/t.co\/Op5IMzKIPB",
      "expanded_url" : "http:\/\/bit.ly\/YNAcKB",
      "display_url" : "bit.ly\/YNAcKB"
    } ]
  },
  "geo" : { },
  "id_str" : "517177271518789632",
  "text" : "RT @alatlewisschool: \u2018People say the \u201980s had bad music, but we had great music\u2019: interview with Ninja Tune\u2019s Matt Black http:\/\/t.co\/Op5IMz\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/Op5IMzKIPB",
        "expanded_url" : "http:\/\/bit.ly\/YNAcKB",
        "display_url" : "bit.ly\/YNAcKB"
      } ]
    },
    "geo" : { },
    "id_str" : "517100105548046336",
    "text" : "\u2018People say the \u201980s had bad music, but we had great music\u2019: interview with Ninja Tune\u2019s Matt Black http:\/\/t.co\/Op5IMzKIPB",
    "id" : 517100105548046336,
    "created_at" : "2014-09-30 23:54:07 +0000",
    "user" : {
      "name" : "Lewis School HR",
      "screen_name" : "alatlewisschool",
      "protected" : false,
      "id_str" : "473783869",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1780093447\/lewis_logo_large_trans_normal_normal.png",
      "id" : 473783869,
      "verified" : false
    }
  },
  "id" : 517177271518789632,
  "created_at" : "2014-10-01 05:00:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Roy Douglas",
      "screen_name" : "scottroydouglas",
      "indices" : [ 0, 16 ],
      "id_str" : "1263168308",
      "id" : 1263168308
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusMOOC",
      "indices" : [ 132, 143 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "517162676347478016",
  "geo" : { },
  "id_str" : "517173731341651968",
  "in_reply_to_user_id" : 1263168308,
  "text" : "@scottroydouglas go to yr profile &amp; there is  tab called activity, also i think replies tab in main acitivity feed is the same? #corpusMOOC",
  "id" : 517173731341651968,
  "in_reply_to_status_id" : 517162676347478016,
  "created_at" : "2014-10-01 04:46:40 +0000",
  "in_reply_to_screen_name" : "scottroydouglas",
  "in_reply_to_user_id_str" : "1263168308",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
} ]