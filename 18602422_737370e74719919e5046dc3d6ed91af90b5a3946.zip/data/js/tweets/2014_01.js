Grailbird.data.tweets_2014_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Hardie",
      "screen_name" : "HardieResearch",
      "indices" : [ 0, 15 ],
      "id_str" : "970452764",
      "id" : 970452764
    }, {
      "name" : "Paul Rayson",
      "screen_name" : "perayson",
      "indices" : [ 16, 25 ],
      "id_str" : "263108959",
      "id" : 263108959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "429383266324328448",
  "geo" : { },
  "id_str" : "429383994514239488",
  "in_reply_to_user_id" : 970452764,
  "text" : "@HardieResearch @perayson okay thanks so CQPweb is the state of the art :)",
  "id" : 429383994514239488,
  "in_reply_to_status_id" : 429383266324328448,
  "created_at" : "2014-01-31 22:41:36 +0000",
  "in_reply_to_screen_name" : "HardieResearch",
  "in_reply_to_user_id_str" : "970452764",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Hardie",
      "screen_name" : "HardieResearch",
      "indices" : [ 0, 15 ],
      "id_str" : "970452764",
      "id" : 970452764
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "429381726532403200",
  "geo" : { },
  "id_str" : "429382314762588160",
  "in_reply_to_user_id" : 970452764,
  "text" : "@HardieResearch not nigglely at all an outright error on my part!",
  "id" : 429382314762588160,
  "in_reply_to_status_id" : 429381726532403200,
  "created_at" : "2014-01-31 22:34:56 +0000",
  "in_reply_to_screen_name" : "HardieResearch",
  "in_reply_to_user_id_str" : "970452764",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Hardie",
      "screen_name" : "HardieResearch",
      "indices" : [ 0, 15 ],
      "id_str" : "970452764",
      "id" : 970452764
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "429376418691031040",
  "geo" : { },
  "id_str" : "429376821306486784",
  "in_reply_to_user_id" : 970452764,
  "text" : "@HardieResearch great thanks do you know anything about byu concordance which late became wordcruncher? am trying to date byu concordance",
  "id" : 429376821306486784,
  "in_reply_to_status_id" : 429376418691031040,
  "created_at" : "2014-01-31 22:13:06 +0000",
  "in_reply_to_screen_name" : "HardieResearch",
  "in_reply_to_user_id_str" : "970452764",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Hardie",
      "screen_name" : "HardieResearch",
      "indices" : [ 0, 15 ],
      "id_str" : "970452764",
      "id" : 970452764
    }, {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "indices" : [ 16, 25 ],
      "id_str" : "167020390",
      "id" : 167020390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "429375276091314176",
  "geo" : { },
  "id_str" : "429375543599845377",
  "in_reply_to_user_id" : 970452764,
  "text" : "@HardieResearch @antlabjp great thanks :)",
  "id" : 429375543599845377,
  "in_reply_to_status_id" : 429375276091314176,
  "created_at" : "2014-01-31 22:08:01 +0000",
  "in_reply_to_screen_name" : "HardieResearch",
  "in_reply_to_user_id_str" : "970452764",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Hardie",
      "screen_name" : "HardieResearch",
      "indices" : [ 0, 15 ],
      "id_str" : "970452764",
      "id" : 970452764
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "429372964195168256",
  "geo" : { },
  "id_str" : "429374275720470528",
  "in_reply_to_user_id" : 970452764,
  "text" : "@HardieResearch have edited years thanks! if you have any more info on time line let me know :)",
  "id" : 429374275720470528,
  "in_reply_to_status_id" : 429372964195168256,
  "created_at" : "2014-01-31 22:02:59 +0000",
  "in_reply_to_screen_name" : "HardieResearch",
  "in_reply_to_user_id_str" : "970452764",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Hardie",
      "screen_name" : "HardieResearch",
      "indices" : [ 0, 15 ],
      "id_str" : "970452764",
      "id" : 970452764
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "429372964195168256",
  "geo" : { },
  "id_str" : "429373226766966784",
  "in_reply_to_user_id" : 970452764,
  "text" : "@HardieResearch okay meaning public access?",
  "id" : 429373226766966784,
  "in_reply_to_status_id" : 429372964195168256,
  "created_at" : "2014-01-31 21:58:49 +0000",
  "in_reply_to_screen_name" : "HardieResearch",
  "in_reply_to_user_id_str" : "970452764",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Hardie",
      "screen_name" : "HardieResearch",
      "indices" : [ 0, 15 ],
      "id_str" : "970452764",
      "id" : 970452764
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "429372879310839808",
  "geo" : { },
  "id_str" : "429373172941463553",
  "in_reply_to_user_id" : 970452764,
  "text" : "@HardieResearch okay i was wondering whether to date it from public access or not? was 2005 public acccess?",
  "id" : 429373172941463553,
  "in_reply_to_status_id" : 429372879310839808,
  "created_at" : "2014-01-31 21:58:36 +0000",
  "in_reply_to_screen_name" : "HardieResearch",
  "in_reply_to_user_id_str" : "970452764",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Moravec",
      "screen_name" : "ProfessMoravec",
      "indices" : [ 0, 15 ],
      "id_str" : "369529173",
      "id" : 369529173
    }, {
      "name" : "Andrew Hardie",
      "screen_name" : "HardieResearch",
      "indices" : [ 16, 31 ],
      "id_str" : "970452764",
      "id" : 970452764
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "429364635926409217",
  "geo" : { },
  "id_str" : "429372877679259648",
  "in_reply_to_user_id" : 369529173,
  "text" : "@ProfessMoravec @HardieResearch well am not sure it was designed to compare x2 1mill texts :) server took a while to get result!",
  "id" : 429372877679259648,
  "in_reply_to_status_id" : 429364635926409217,
  "created_at" : "2014-01-31 21:57:26 +0000",
  "in_reply_to_screen_name" : "ProfessMoravec",
  "in_reply_to_user_id_str" : "369529173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Hardie",
      "screen_name" : "HardieResearch",
      "indices" : [ 0, 15 ],
      "id_str" : "970452764",
      "id" : 970452764
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "429364557610377216",
  "geo" : { },
  "id_str" : "429371643928903680",
  "in_reply_to_user_id" : 970452764,
  "text" : "@HardieResearch hi of course which ones? oh and thanks for RT :)",
  "id" : 429371643928903680,
  "in_reply_to_status_id" : 429364557610377216,
  "created_at" : "2014-01-31 21:52:31 +0000",
  "in_reply_to_screen_name" : "HardieResearch",
  "in_reply_to_user_id_str" : "970452764",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Andrews",
      "screen_name" : "PatrickAndrews",
      "indices" : [ 3, 18 ],
      "id_str" : "29999737",
      "id" : 29999737
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusMOOC",
      "indices" : [ 43, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/0pUiJVQOrO",
      "expanded_url" : "http:\/\/patrickdandrews.blogspot.co.uk\/2014\/01\/initial-impressions-of-corpus.html",
      "display_url" : "patrickdandrews.blogspot.co.uk\/2014\/01\/initia\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429263031827439616",
  "text" : "RT @PatrickAndrews: Initial reflections on #corpusMOOC http:\/\/t.co\/0pUiJVQOrO \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpusMOOC",
        "indices" : [ 23, 34 ]
      } ],
      "urls" : [ {
        "indices" : [ 35, 57 ],
        "url" : "http:\/\/t.co\/0pUiJVQOrO",
        "expanded_url" : "http:\/\/patrickdandrews.blogspot.co.uk\/2014\/01\/initial-impressions-of-corpus.html",
        "display_url" : "patrickdandrews.blogspot.co.uk\/2014\/01\/initia\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "429243070932979712",
    "text" : "Initial reflections on #corpusMOOC http:\/\/t.co\/0pUiJVQOrO \u2026",
    "id" : 429243070932979712,
    "created_at" : "2014-01-31 13:21:37 +0000",
    "user" : {
      "name" : "Patrick Andrews",
      "screen_name" : "PatrickAndrews",
      "protected" : false,
      "id_str" : "29999737",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/454216022\/ash19238_2__normal.jpg",
      "id" : 29999737,
      "verified" : false
    }
  },
  "id" : 429263031827439616,
  "created_at" : "2014-01-31 14:40:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Timothy Tate",
      "screen_name" : "Timothy_Tate",
      "indices" : [ 3, 16 ],
      "id_str" : "1084531170",
      "id" : 1084531170
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/2cRpxFg8R3",
      "expanded_url" : "http:\/\/forgotify.com",
      "display_url" : "forgotify.com"
    } ]
  },
  "geo" : { },
  "id_str" : "429210339339948032",
  "text" : "RT @Timothy_Tate: Some for good reason - '4 million songs on Spotify have never been played. Not even once. We\u2019re changing that.' http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/2cRpxFg8R3",
        "expanded_url" : "http:\/\/forgotify.com",
        "display_url" : "forgotify.com"
      } ]
    },
    "geo" : { },
    "id_str" : "429159343225724929",
    "text" : "Some for good reason - '4 million songs on Spotify have never been played. Not even once. We\u2019re changing that.' http:\/\/t.co\/2cRpxFg8R3",
    "id" : 429159343225724929,
    "created_at" : "2014-01-31 07:48:55 +0000",
    "user" : {
      "name" : "Timothy Tate",
      "screen_name" : "Timothy_Tate",
      "protected" : false,
      "id_str" : "1084531170",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3578723900\/41c4d3a262e0defc1126475c46be261f_normal.jpeg",
      "id" : 1084531170,
      "verified" : false
    }
  },
  "id" : 429210339339948032,
  "created_at" : "2014-01-31 11:11:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dematerialise",
      "screen_name" : "dematerialise",
      "indices" : [ 0, 14 ],
      "id_str" : "551993401",
      "id" : 551993401
    }, {
      "name" : "James Baker",
      "screen_name" : "j_w_baker",
      "indices" : [ 15, 25 ],
      "id_str" : "110465562",
      "id" : 110465562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "429032271891275776",
  "geo" : { },
  "id_str" : "429036170224222209",
  "in_reply_to_user_id" : 551993401,
  "text" : "@dematerialise @j_w_baker thanks for sharing, keep an eye out for further changes as it is very much a work in progress",
  "id" : 429036170224222209,
  "in_reply_to_status_id" : 429032271891275776,
  "created_at" : "2014-01-30 23:39:28 +0000",
  "in_reply_to_screen_name" : "dematerialise",
  "in_reply_to_user_id_str" : "551993401",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allison Wright",
      "screen_name" : "wrightbutton",
      "indices" : [ 3, 16 ],
      "id_str" : "2303668855",
      "id" : 2303668855
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusMOOC",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 123, 140 ],
      "url" : "http:\/\/t.co\/64AvGpijnJ",
      "expanded_url" : "http:\/\/languagelog.ldc.upenn.edu\/nll\/?p=10092",
      "display_url" : "languagelog.ldc.upenn.edu\/nll\/?p=10092"
    } ]
  },
  "geo" : { },
  "id_str" : "429020984700444672",
  "text" : "RT @wrightbutton: Practical use of collocation in corpus linguistics: Defending allegations of plagiarism by US President- http:\/\/t.co\/64Av\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpusMOOC",
        "indices" : [ 129, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/64AvGpijnJ",
        "expanded_url" : "http:\/\/languagelog.ldc.upenn.edu\/nll\/?p=10092",
        "display_url" : "languagelog.ldc.upenn.edu\/nll\/?p=10092"
      } ]
    },
    "geo" : { },
    "id_str" : "428968790332678144",
    "text" : "Practical use of collocation in corpus linguistics: Defending allegations of plagiarism by US President- http:\/\/t.co\/64AvGpijnJ  #corpusMOOC",
    "id" : 428968790332678144,
    "created_at" : "2014-01-30 19:11:44 +0000",
    "user" : {
      "name" : "Allison Wright",
      "screen_name" : "wrightbutton",
      "protected" : false,
      "id_str" : "2303668855",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/425763783500251136\/IeK646DE_normal.jpeg",
      "id" : 2303668855,
      "verified" : false
    }
  },
  "id" : 429020984700444672,
  "created_at" : "2014-01-30 22:39:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lextutor",
      "indices" : [ 59, 68 ]
    }, {
      "text" : "corpusmooc",
      "indices" : [ 106, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/u9LRiI0zHY",
      "expanded_url" : "https:\/\/plus.google.com\/104940199413423400545\/posts\/D8K3m1M1nKZ",
      "display_url" : "plus.google.com\/10494019941342\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429016494165352448",
  "text" : "differences between brown and lob very apparent when using #lextutor text compare https:\/\/t.co\/u9LRiI0zHY #corpusmooc",
  "id" : 429016494165352448,
  "created_at" : "2014-01-30 22:21:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    }, {
      "name" : "John Pilger",
      "screen_name" : "johnpilger",
      "indices" : [ 51, 62 ],
      "id_str" : "869825995",
      "id" : 869825995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 124, 140 ],
      "url" : "http:\/\/t.co\/uMeklActUq",
      "expanded_url" : "http:\/\/tinyurl.com\/q6y292u",
      "display_url" : "tinyurl.com\/q6y292u"
    } ]
  },
  "geo" : { },
  "id_str" : "429005834626953217",
  "text" : "RT @medialens: 'It's the other Oscars.' Once again @johnpilger's honesty,wit and wisdom put the rest of journalism to shame http:\/\/t.co\/uMe\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Pilger",
        "screen_name" : "johnpilger",
        "indices" : [ 36, 47 ],
        "id_str" : "869825995",
        "id" : 869825995
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/uMeklActUq",
        "expanded_url" : "http:\/\/tinyurl.com\/q6y292u",
        "display_url" : "tinyurl.com\/q6y292u"
      } ]
    },
    "geo" : { },
    "id_str" : "428885838122872832",
    "text" : "'It's the other Oscars.' Once again @johnpilger's honesty,wit and wisdom put the rest of journalism to shame http:\/\/t.co\/uMeklActUq",
    "id" : 428885838122872832,
    "created_at" : "2014-01-30 13:42:06 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 429005834626953217,
  "created_at" : "2014-01-30 21:38:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "indices" : [ 0, 12 ],
      "id_str" : "849729062",
      "id" : 849729062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "428959697962807297",
  "geo" : { },
  "id_str" : "428975246491017216",
  "in_reply_to_user_id" : 849729062,
  "text" : "@TonyMcEnery glad to hear! they remind me of capital punishment chairs :)",
  "id" : 428975246491017216,
  "in_reply_to_status_id" : 428959697962807297,
  "created_at" : "2014-01-30 19:37:23 +0000",
  "in_reply_to_screen_name" : "TonyMcEnery",
  "in_reply_to_user_id_str" : "849729062",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((David Traynier)))",
      "screen_name" : "DTraynier",
      "indices" : [ 3, 13 ],
      "id_str" : "317716198",
      "id" : 317716198
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428861866501484544",
  "text" : "RT @DTraynier: Cameron also announced fresh supplies of indigestion tablets for Syrian 'rebels' who've only had access to uncooked hearts.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "428591076279332864",
    "text" : "Cameron also announced fresh supplies of indigestion tablets for Syrian 'rebels' who've only had access to uncooked hearts.",
    "id" : 428591076279332864,
    "created_at" : "2014-01-29 18:10:50 +0000",
    "user" : {
      "name" : "(((David Traynier)))",
      "screen_name" : "DTraynier",
      "protected" : false,
      "id_str" : "317716198",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727929911877480451\/fLuwL370_normal.jpg",
      "id" : 317716198,
      "verified" : false
    }
  },
  "id" : 428861866501484544,
  "created_at" : "2014-01-30 12:06:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 53, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428858214323474434",
  "text" : "i wonder how comfortable those high-backed chairs in #corpusmooc in conversation are? :)",
  "id" : 428858214323474434,
  "created_at" : "2014-01-30 11:52:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Patsko",
      "screen_name" : "lauraahaha",
      "indices" : [ 0, 11 ],
      "id_str" : "97957137",
      "id" : 97957137
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edtech",
      "indices" : [ 33, 40 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "428844516175777792",
  "geo" : { },
  "id_str" : "428845044150181888",
  "in_reply_to_user_id" : 97957137,
  "text" : "@lauraahaha hi people discussing #edtech and congrats on graduating",
  "id" : 428845044150181888,
  "in_reply_to_status_id" : 428844516175777792,
  "created_at" : "2014-01-30 11:00:00 +0000",
  "in_reply_to_screen_name" : "lauraahaha",
  "in_reply_to_user_id_str" : "97957137",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 27, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428836045187055616",
  "text" : "enjoying reading people in #corpusmooc exploring brown&amp;lob  &amp; good to have put chomsky in to remind us dangers of fishing experiments :)",
  "id" : 428836045187055616,
  "created_at" : "2014-01-30 10:24:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "428685563420770304",
  "geo" : { },
  "id_str" : "428795474867277825",
  "in_reply_to_user_id" : 60425505,
  "text" : "@becksdad maybe your googlefu may discover it? or you could email them? also lextutor has a 2mill TV corpus u can use as a ref corpus",
  "id" : 428795474867277825,
  "in_reply_to_status_id" : 428685563420770304,
  "created_at" : "2014-01-30 07:43:02 +0000",
  "in_reply_to_screen_name" : "neil_mcm",
  "in_reply_to_user_id_str" : "60425505",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/ISVvL48rok",
      "expanded_url" : "http:\/\/doe.concordia.ca\/copal\/documents\/4_macfadden_barret_horst.pdf",
      "display_url" : "doe.concordia.ca\/copal\/document\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "428672154687655936",
  "geo" : { },
  "id_str" : "428673574023331841",
  "in_reply_to_user_id" : 60425505,
  "text" : "@becksdad this is a good pointer if you have not seen it already http:\/\/t.co\/ISVvL48rok",
  "id" : 428673574023331841,
  "in_reply_to_status_id" : 428672154687655936,
  "created_at" : "2014-01-29 23:38:39 +0000",
  "in_reply_to_screen_name" : "neil_mcm",
  "in_reply_to_user_id_str" : "60425505",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "428672154687655936",
  "geo" : { },
  "id_str" : "428672789751402496",
  "in_reply_to_user_id" : 60425505,
  "text" : "@becksdad you could pop question on G+ CL community? :)",
  "id" : 428672789751402496,
  "in_reply_to_status_id" : 428672154687655936,
  "created_at" : "2014-01-29 23:35:32 +0000",
  "in_reply_to_screen_name" : "neil_mcm",
  "in_reply_to_user_id_str" : "60425505",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/becksdad\/status\/428672154687655936\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/LXZ7UXly4M",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfLzDanCEAA-udI.png",
      "id_str" : "428672154561810432",
      "id" : 428672154561810432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfLzDanCEAA-udI.png",
      "sizes" : [ {
        "h" : 239,
        "resize" : "fit",
        "w" : 494
      }, {
        "h" : 239,
        "resize" : "fit",
        "w" : 494
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 239,
        "resize" : "fit",
        "w" : 494
      }, {
        "h" : 164,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/LXZ7UXly4M"
    } ],
    "hashtags" : [ {
      "text" : "teachinglexically",
      "indices" : [ 85, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428672686680985601",
  "text" : "RT @becksdad: Building a corpus of TV sitcom scripts - could be a great resource for #teachinglexically. Anyone wanna collaborate? http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/becksdad\/status\/428672154687655936\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/LXZ7UXly4M",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BfLzDanCEAA-udI.png",
        "id_str" : "428672154561810432",
        "id" : 428672154561810432,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfLzDanCEAA-udI.png",
        "sizes" : [ {
          "h" : 239,
          "resize" : "fit",
          "w" : 494
        }, {
          "h" : 239,
          "resize" : "fit",
          "w" : 494
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 239,
          "resize" : "fit",
          "w" : 494
        }, {
          "h" : 164,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/LXZ7UXly4M"
      } ],
      "hashtags" : [ {
        "text" : "teachinglexically",
        "indices" : [ 71, 89 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "428672154687655936",
    "text" : "Building a corpus of TV sitcom scripts - could be a great resource for #teachinglexically. Anyone wanna collaborate? http:\/\/t.co\/LXZ7UXly4M",
    "id" : 428672154687655936,
    "created_at" : "2014-01-29 23:33:00 +0000",
    "user" : {
      "name" : "Neil McMillan",
      "screen_name" : "neil_mcm",
      "protected" : false,
      "id_str" : "60425505",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/419471700510920704\/RMN34luB_normal.jpeg",
      "id" : 60425505,
      "verified" : false
    }
  },
  "id" : 428672686680985601,
  "created_at" : "2014-01-29 23:35:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 47, 63 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/M6R70CC1ec",
      "expanded_url" : "http:\/\/wp.me\/p2TZun-5r",
      "display_url" : "wp.me\/p2TZun-5r"
    } ]
  },
  "geo" : { },
  "id_str" : "428660689981292544",
  "text" : "Seeing is believing http:\/\/t.co\/M6R70CC1ec via @wordpressdotcom",
  "id" : 428660689981292544,
  "created_at" : "2014-01-29 22:47:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noah P. Wilson",
      "screen_name" : "nhwlsn",
      "indices" : [ 0, 7 ],
      "id_str" : "149535184",
      "id" : 149535184
    }, {
      "name" : "Ed Summers",
      "screen_name" : "edsu",
      "indices" : [ 8, 13 ],
      "id_str" : "14331818",
      "id" : 14331818
    }, {
      "name" : "Amelia Joulain-Jay",
      "screen_name" : "Joulain_Jay",
      "indices" : [ 14, 26 ],
      "id_str" : "1968429444",
      "id" : 1968429444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428618962306207744",
  "in_reply_to_user_id" : 149535184,
  "text" : "@nhwlsn @edsu @Joulain_Jay thanks for RT of timeline :)",
  "id" : 428618962306207744,
  "created_at" : "2014-01-29 20:01:38 +0000",
  "in_reply_to_screen_name" : "nhwlsn",
  "in_reply_to_user_id_str" : "149535184",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/x6XV32qtHZ",
      "expanded_url" : "http:\/\/www.just-the-word.com\/",
      "display_url" : "just-the-word.com"
    }, {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/zSbpEhxCEE",
      "expanded_url" : "http:\/\/wordneighbors.ust.hk",
      "display_url" : "wordneighbors.ust.hk"
    } ]
  },
  "geo" : { },
  "id_str" : "428615918218772480",
  "text" : "i do believe justtheword's http:\/\/t.co\/x6XV32qtHZ crown has been taken by wordneighbours http:\/\/t.co\/zSbpEhxCEE",
  "id" : 428615918218772480,
  "created_at" : "2014-01-29 19:49:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/428306843727704064\/photo\/1",
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/3CXqWvFxZ2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfGmzhvCMAARBzn.png",
      "id_str" : "428306843736092672",
      "id" : 428306843736092672,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfGmzhvCMAARBzn.png",
      "sizes" : [ {
        "h" : 213,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/3CXqWvFxZ2"
    } ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 27, 38 ]
    }, {
      "text" : "openpandora",
      "indices" : [ 57, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428306843727704064",
  "text" : "microconcord on the go for #corpusmooc screenshot dosbox #openpandora oh yes :) http:\/\/t.co\/3CXqWvFxZ2",
  "id" : 428306843727704064,
  "created_at" : "2014-01-28 23:21:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ann Priestley",
      "screen_name" : "annindk",
      "indices" : [ 3, 11 ],
      "id_str" : "127530996",
      "id" : 127530996
    }, {
      "name" : "Martin Hawksey",
      "screen_name" : "mhawksey",
      "indices" : [ 113, 122 ],
      "id_str" : "13046992",
      "id" : 13046992
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 46, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/XKO8AYuvdd",
      "expanded_url" : "http:\/\/ow.ly\/t32FW",
      "display_url" : "ow.ly\/t32FW"
    }, {
      "indices" : [ 123, 140 ],
      "url" : "http:\/\/t.co\/yINr6wEsc7",
      "expanded_url" : "http:\/\/ow.ly\/i\/4qmoO",
      "display_url" : "ow.ly\/i\/4qmoO"
    } ]
  },
  "geo" : { },
  "id_str" : "428303734805106688",
  "text" : "RT @annindk: Here's a map of people using the #corpusmooc tag so far - see http:\/\/t.co\/XKO8AYuvdd Thx as ever to @mhawksey http:\/\/t.co\/yINr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Martin Hawksey",
        "screen_name" : "mhawksey",
        "indices" : [ 100, 109 ],
        "id_str" : "13046992",
        "id" : 13046992
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpusmooc",
        "indices" : [ 33, 44 ]
      } ],
      "urls" : [ {
        "indices" : [ 62, 84 ],
        "url" : "http:\/\/t.co\/XKO8AYuvdd",
        "expanded_url" : "http:\/\/ow.ly\/t32FW",
        "display_url" : "ow.ly\/t32FW"
      }, {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/yINr6wEsc7",
        "expanded_url" : "http:\/\/ow.ly\/i\/4qmoO",
        "display_url" : "ow.ly\/i\/4qmoO"
      } ]
    },
    "geo" : { },
    "id_str" : "428290330564526080",
    "text" : "Here's a map of people using the #corpusmooc tag so far - see http:\/\/t.co\/XKO8AYuvdd Thx as ever to @mhawksey http:\/\/t.co\/yINr6wEsc7",
    "id" : 428290330564526080,
    "created_at" : "2014-01-28 22:15:46 +0000",
    "user" : {
      "name" : "Ann Priestley",
      "screen_name" : "annindk",
      "protected" : false,
      "id_str" : "127530996",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/562162496090304512\/gWTN9idr_normal.jpeg",
      "id" : 127530996,
      "verified" : false
    }
  },
  "id" : 428303734805106688,
  "created_at" : "2014-01-28 23:09:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol Goodey",
      "screen_name" : "cgoodey",
      "indices" : [ 0, 8 ],
      "id_str" : "26606833",
      "id" : 26606833
    }, {
      "name" : "Sam Shepherd",
      "screen_name" : "samshep",
      "indices" : [ 9, 17 ],
      "id_str" : "20146035",
      "id" : 20146035
    }, {
      "name" : "Diana Tremayne",
      "screen_name" : "dianatremayne",
      "indices" : [ 18, 32 ],
      "id_str" : "148064860",
      "id" : 148064860
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/gnEFqIwmh8",
      "expanded_url" : "https:\/\/plus.google.com\/u\/0\/communities\/101266284417587206243",
      "display_url" : "plus.google.com\/u\/0\/communitie\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "428284337503875072",
  "geo" : { },
  "id_str" : "428295702947430400",
  "in_reply_to_user_id" : 26606833,
  "text" : "@cgoodey @samshep @dianatremayne quick plug for G+ CL community for lang teach\/learn https:\/\/t.co\/gnEFqIwmh8 c ya moocside :)",
  "id" : 428295702947430400,
  "in_reply_to_status_id" : 428284337503875072,
  "created_at" : "2014-01-28 22:37:07 +0000",
  "in_reply_to_screen_name" : "cgoodey",
  "in_reply_to_user_id_str" : "26606833",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol Goodey",
      "screen_name" : "cgoodey",
      "indices" : [ 3, 11 ],
      "id_str" : "26606833",
      "id" : 26606833
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusMOOC",
      "indices" : [ 65, 76 ]
    }, {
      "text" : "ELTchat",
      "indices" : [ 77, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/xJgOT7LnDp",
      "expanded_url" : "http:\/\/wp.me\/p2itcX-hT",
      "display_url" : "wp.me\/p2itcX-hT"
    } ]
  },
  "geo" : { },
  "id_str" : "428284319375712256",
  "text" : "RT @cgoodey: This is not just any MOOC... http:\/\/t.co\/xJgOT7LnDp #corpusMOOC #ELTchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpusMOOC",
        "indices" : [ 52, 63 ]
      }, {
        "text" : "ELTchat",
        "indices" : [ 64, 72 ]
      } ],
      "urls" : [ {
        "indices" : [ 29, 51 ],
        "url" : "http:\/\/t.co\/xJgOT7LnDp",
        "expanded_url" : "http:\/\/wp.me\/p2itcX-hT",
        "display_url" : "wp.me\/p2itcX-hT"
      } ]
    },
    "geo" : { },
    "id_str" : "428274004684574721",
    "text" : "This is not just any MOOC... http:\/\/t.co\/xJgOT7LnDp #corpusMOOC #ELTchat",
    "id" : 428274004684574721,
    "created_at" : "2014-01-28 21:10:54 +0000",
    "user" : {
      "name" : "Carol Goodey",
      "screen_name" : "cgoodey",
      "protected" : false,
      "id_str" : "26606833",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/739764539839926273\/EtEpZHsA_normal.jpg",
      "id" : 26606833,
      "verified" : false
    }
  },
  "id" : 428284319375712256,
  "created_at" : "2014-01-28 21:51:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Rae",
      "screen_name" : "simonrae",
      "indices" : [ 0, 9 ],
      "id_str" : "48292696",
      "id" : 48292696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "428198968137646080",
  "geo" : { },
  "id_str" : "428266430430081025",
  "in_reply_to_user_id" : 48292696,
  "text" : "@simonrae thanks keep an eye out timeline is a work in progress :)",
  "id" : 428266430430081025,
  "in_reply_to_status_id" : 428198968137646080,
  "created_at" : "2014-01-28 20:40:48 +0000",
  "in_reply_to_screen_name" : "simonrae",
  "in_reply_to_user_id_str" : "48292696",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noor Adnan",
      "screen_name" : "n00rbaizura",
      "indices" : [ 0, 12 ],
      "id_str" : "412094121",
      "id" : 412094121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "428049612402720768",
  "geo" : { },
  "id_str" : "428069288969109504",
  "in_reply_to_user_id" : 412094121,
  "text" : "@n00rbaizura thanks a lot :)",
  "id" : 428069288969109504,
  "in_reply_to_status_id" : 428049612402720768,
  "created_at" : "2014-01-28 07:37:26 +0000",
  "in_reply_to_screen_name" : "n00rbaizura",
  "in_reply_to_user_id_str" : "412094121",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Thornbury",
      "screen_name" : "thornburyscott",
      "indices" : [ 0, 15 ],
      "id_str" : "23090474",
      "id" : 23090474
    }, {
      "name" : "\u0414\u0438\u0430\u043D\u043A\u0430 \u0428\u043A\u0443\u0440\u0441\u043A\u0430\u044F",
      "screen_name" : "TheSecretDoS",
      "indices" : [ 16, 29 ],
      "id_str" : "440292980",
      "id" : 440292980
    }, {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 30, 45 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "428067711709900800",
  "geo" : { },
  "id_str" : "428069026107912192",
  "in_reply_to_user_id" : 23090474,
  "text" : "@thornburyscott @TheSecretDoS @GeoffreyJordan zing :)",
  "id" : 428069026107912192,
  "in_reply_to_status_id" : 428067711709900800,
  "created_at" : "2014-01-28 07:36:23 +0000",
  "in_reply_to_screen_name" : "thornburyscott",
  "in_reply_to_user_id_str" : "23090474",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "St\u00E9fan Sinclair",
      "screen_name" : "sgsinclair",
      "indices" : [ 0, 11 ],
      "id_str" : "45832102",
      "id" : 45832102
    }, {
      "name" : "Geoffrey Rockwell",
      "screen_name" : "GeoffRockwell",
      "indices" : [ 12, 26 ],
      "id_str" : "21966494",
      "id" : 21966494
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427994061317083136",
  "geo" : { },
  "id_str" : "427995999043198976",
  "in_reply_to_user_id" : 45832102,
  "text" : "@sgsinclair @GeoffRockwell will add TACT as that has come up in my research",
  "id" : 427995999043198976,
  "in_reply_to_status_id" : 427994061317083136,
  "created_at" : "2014-01-28 02:46:12 +0000",
  "in_reply_to_screen_name" : "sgsinclair",
  "in_reply_to_user_id_str" : "45832102",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "St\u00E9fan Sinclair",
      "screen_name" : "sgsinclair",
      "indices" : [ 0, 11 ],
      "id_str" : "45832102",
      "id" : 45832102
    }, {
      "name" : "Geoffrey Rockwell",
      "screen_name" : "GeoffRockwell",
      "indices" : [ 12, 26 ],
      "id_str" : "21966494",
      "id" : 21966494
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427986744198184961",
  "geo" : { },
  "id_str" : "427992315651567617",
  "in_reply_to_user_id" : 45832102,
  "text" : "@sgsinclair @GeoffRockwell ok done please check :)",
  "id" : 427992315651567617,
  "in_reply_to_status_id" : 427986744198184961,
  "created_at" : "2014-01-28 02:31:34 +0000",
  "in_reply_to_screen_name" : "sgsinclair",
  "in_reply_to_user_id_str" : "45832102",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 83, 98 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 123, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/FdZJoRbL35",
      "expanded_url" : "http:\/\/wp.me\/p3qkCB-LW",
      "display_url" : "wp.me\/p3qkCB-LW"
    } ]
  },
  "geo" : { },
  "id_str" : "427941350789509120",
  "text" : "Concordancing, lexical chunks and the Lexical Syllabus  http:\/\/t.co\/FdZJoRbL35 via @GeoffreyJordan interesting reading for #corpusmooc",
  "id" : 427941350789509120,
  "created_at" : "2014-01-27 23:09:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Moravec",
      "screen_name" : "ProfessMoravec",
      "indices" : [ 0, 15 ],
      "id_str" : "369529173",
      "id" : 369529173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427924608302321664",
  "geo" : { },
  "id_str" : "427926967619301376",
  "in_reply_to_user_id" : 369529173,
  "text" : "@ProfessMoravec tried to comment on post no luck :( tldr- nice post; done wk2vid2 as later in week busy; all good is far cyamoocside!",
  "id" : 427926967619301376,
  "in_reply_to_status_id" : 427924608302321664,
  "created_at" : "2014-01-27 22:11:54 +0000",
  "in_reply_to_screen_name" : "ProfessMoravec",
  "in_reply_to_user_id_str" : "369529173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    }, {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 56, 66 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 124, 140 ],
      "url" : "http:\/\/t.co\/LctXDtjDFZ",
      "expanded_url" : "http:\/\/tinyurl.com\/qa9hwpl",
      "display_url" : "tinyurl.com\/qa9hwpl"
    } ]
  },
  "geo" : { },
  "id_str" : "427921468857782272",
  "text" : "RT @johnwhilley: Latest set of treasure box truths from @medialens - Propaganda: \u2018The Dominant Grand Narrative Of Our Time\u2019 http:\/\/t.co\/Lct\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Media Lens",
        "screen_name" : "medialens",
        "indices" : [ 39, 49 ],
        "id_str" : "6531902",
        "id" : 6531902
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/LctXDtjDFZ",
        "expanded_url" : "http:\/\/tinyurl.com\/qa9hwpl",
        "display_url" : "tinyurl.com\/qa9hwpl"
      } ]
    },
    "geo" : { },
    "id_str" : "427787682689720320",
    "text" : "Latest set of treasure box truths from @medialens - Propaganda: \u2018The Dominant Grand Narrative Of Our Time\u2019 http:\/\/t.co\/LctXDtjDFZ",
    "id" : 427787682689720320,
    "created_at" : "2014-01-27 12:58:26 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 427921468857782272,
  "created_at" : "2014-01-27 21:50:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 0, 11 ],
      "id_str" : "282659955",
      "id" : 282659955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427914477649293312",
  "geo" : { },
  "id_str" : "427915842253099008",
  "in_reply_to_user_id" : 282659955,
  "text" : "@teflerinha woah! wordpress servers must have been creaking :)",
  "id" : 427915842253099008,
  "in_reply_to_status_id" : 427914477649293312,
  "created_at" : "2014-01-27 21:27:41 +0000",
  "in_reply_to_screen_name" : "teflerinha",
  "in_reply_to_user_id_str" : "282659955",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "427915558126768128",
  "text" : "&lt;&lt;still a n-word&gt;&gt; says Ali &amp; still sharp in the Trials of Muhammad Ali, a great documentary",
  "id" : 427915558126768128,
  "created_at" : "2014-01-27 21:26:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Patsko",
      "screen_name" : "lauraahaha",
      "indices" : [ 0, 11 ],
      "id_str" : "97957137",
      "id" : 97957137
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427702469725261824",
  "geo" : { },
  "id_str" : "427831950250749952",
  "in_reply_to_user_id" : 97957137,
  "text" : "@lauraahaha sure thx for a great post :)",
  "id" : 427831950250749952,
  "in_reply_to_status_id" : 427702469725261824,
  "created_at" : "2014-01-27 15:54:20 +0000",
  "in_reply_to_screen_name" : "lauraahaha",
  "in_reply_to_user_id_str" : "97957137",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacqueline Hettel",
      "screen_name" : "jacquehettel",
      "indices" : [ 0, 13 ],
      "id_str" : "1339834406",
      "id" : 1339834406
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "427830448769601536",
  "in_reply_to_user_id" : 1339834406,
  "text" : "@jacquehettel thanks for RT of timeline :)",
  "id" : 427830448769601536,
  "created_at" : "2014-01-27 15:48:22 +0000",
  "in_reply_to_screen_name" : "jacquehettel",
  "in_reply_to_user_id_str" : "1339834406",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "indices" : [ 88, 99 ],
      "id_str" : "152051625",
      "id" : 152051625
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/427824055698210816\/photo\/1",
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/bkXfAuKUwu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Be_vtkKCQAAMX9k.jpg",
      "id_str" : "427824055702405120",
      "id" : 427824055702405120,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Be_vtkKCQAAMX9k.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/bkXfAuKUwu"
    } ],
    "hashtags" : [ {
      "text" : "concordancing",
      "indices" : [ 3, 17 ]
    }, {
      "text" : "openpandora",
      "indices" : [ 72, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "427824055698210816",
  "text" : "re #concordancing on the go Longman Mini-Concordancer on DosBox 0.73 on #openpandora cc @heatherfro http:\/\/t.co\/bkXfAuKUwu",
  "id" : 427824055698210816,
  "created_at" : "2014-01-27 15:22:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 3, 11 ],
      "id_str" : "20650366",
      "id" : 20650366
    }, {
      "name" : "Adam Simpson",
      "screen_name" : "yearinthelifeof",
      "indices" : [ 111, 127 ],
      "id_str" : "78543378",
      "id" : 78543378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/HckjWvs41Y",
      "expanded_url" : "http:\/\/www.teachthemenglish.com\/2014\/01\/so-you-want-to-teach-academic-english-heres-how\/",
      "display_url" : "teachthemenglish.com\/2014\/01\/so-you\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427804188006178816",
  "text" : "RT @seburnt: So you want to teach academic English? Here&amp;#8217;s how&amp;#8230; http:\/\/t.co\/HckjWvs41Y via @yearinthelifeof",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Adam Simpson",
        "screen_name" : "yearinthelifeof",
        "indices" : [ 98, 114 ],
        "id_str" : "78543378",
        "id" : 78543378
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/HckjWvs41Y",
        "expanded_url" : "http:\/\/www.teachthemenglish.com\/2014\/01\/so-you-want-to-teach-academic-english-heres-how\/",
        "display_url" : "teachthemenglish.com\/2014\/01\/so-you\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "427797338241781760",
    "text" : "So you want to teach academic English? Here&amp;#8217;s how&amp;#8230; http:\/\/t.co\/HckjWvs41Y via @yearinthelifeof",
    "id" : 427797338241781760,
    "created_at" : "2014-01-27 13:36:48 +0000",
    "user" : {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "protected" : false,
      "id_str" : "20650366",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/743248377563971584\/9d9xlHlz_normal.jpg",
      "id" : 20650366,
      "verified" : false
    }
  },
  "id" : 427804188006178816,
  "created_at" : "2014-01-27 14:04:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "indices" : [ 61, 73 ],
      "id_str" : "849729062",
      "id" : 849729062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 0, 11 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "427768754450096129",
  "text" : "#corpusmooc 1.23 regex is \\br[a-z]*?t\\b can someone confirm? @TonyMcEnery",
  "id" : 427768754450096129,
  "created_at" : "2014-01-27 11:43:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 3, 12 ],
      "id_str" : "134211317",
      "id" : 134211317
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 105, 109 ]
    }, {
      "text" : "tefl",
      "indices" : [ 110, 115 ]
    }, {
      "text" : "BESIG",
      "indices" : [ 116, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/adIMNt4gzT",
      "expanded_url" : "http:\/\/wp.me\/p3Wm0j-cg",
      "display_url" : "wp.me\/p3Wm0j-cg"
    } ]
  },
  "geo" : { },
  "id_str" : "427764435911208960",
  "text" : "RT @josipa74: 'Appraisals...do's, don'ts and discourse markers' +free lesson plan http:\/\/t.co\/adIMNt4gzT #elt #tefl #BESIG please share w\/ \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "elt",
        "indices" : [ 91, 95 ]
      }, {
        "text" : "tefl",
        "indices" : [ 96, 101 ]
      }, {
        "text" : "BESIG",
        "indices" : [ 102, 108 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/adIMNt4gzT",
        "expanded_url" : "http:\/\/wp.me\/p3Wm0j-cg",
        "display_url" : "wp.me\/p3Wm0j-cg"
      } ]
    },
    "geo" : { },
    "id_str" : "427759395007504385",
    "text" : "'Appraisals...do's, don'ts and discourse markers' +free lesson plan http:\/\/t.co\/adIMNt4gzT #elt #tefl #BESIG please share w\/ other teachers!",
    "id" : 427759395007504385,
    "created_at" : "2014-01-27 11:06:01 +0000",
    "user" : {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "protected" : false,
      "id_str" : "134211317",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/526853654377021441\/MtEFhYIs_normal.jpeg",
      "id" : 134211317,
      "verified" : false
    }
  },
  "id" : 427764435911208960,
  "created_at" : "2014-01-27 11:26:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "indices" : [ 0, 11 ],
      "id_str" : "152051625",
      "id" : 152051625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427736412809859072",
  "geo" : { },
  "id_str" : "427755942113841152",
  "in_reply_to_user_id" : 152051625,
  "text" : "@heatherfro thanks! let me know if u c anything to add\/correct :)",
  "id" : 427755942113841152,
  "in_reply_to_status_id" : 427736412809859072,
  "created_at" : "2014-01-27 10:52:18 +0000",
  "in_reply_to_screen_name" : "heatherfro",
  "in_reply_to_user_id_str" : "152051625",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anouk Lang",
      "screen_name" : "a_e_lang",
      "indices" : [ 0, 9 ],
      "id_str" : "51271746",
      "id" : 51271746
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427734579974512640",
  "geo" : { },
  "id_str" : "427755856344530945",
  "in_reply_to_user_id" : 51271746,
  "text" : "@a_e_lang thanks for sharing :) let me know if u c anything to add\/correct",
  "id" : 427755856344530945,
  "in_reply_to_status_id" : 427734579974512640,
  "created_at" : "2014-01-27 10:51:58 +0000",
  "in_reply_to_screen_name" : "a_e_lang",
  "in_reply_to_user_id_str" : "51271746",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diego DC",
      "screen_name" : "DiegoDeCao",
      "indices" : [ 0, 11 ],
      "id_str" : "949943336",
      "id" : 949943336
    }, {
      "name" : "Anni Sairio",
      "screen_name" : "annisairi",
      "indices" : [ 27, 37 ],
      "id_str" : "353633245",
      "id" : 353633245
    }, {
      "name" : "VARIENG",
      "screen_name" : "Varieng",
      "indices" : [ 38, 46 ],
      "id_str" : "2228379120",
      "id" : 2228379120
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "427755699146223616",
  "in_reply_to_user_id" : 949943336,
  "text" : "@DiegoDeCao @Jessica__Frye @annisairi @Varieng thansl for sharing timeline if u c anything to add\/correct let me know",
  "id" : 427755699146223616,
  "created_at" : "2014-01-27 10:51:20 +0000",
  "in_reply_to_screen_name" : "DiegoDeCao",
  "in_reply_to_user_id_str" : "949943336",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 0, 11 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "427755032071512064",
  "text" : "#corpusmooc is serious bizness to wit - &lt;&lt;I came, I saw, I concordanced&gt;&gt; :)",
  "id" : 427755032071512064,
  "created_at" : "2014-01-27 10:48:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELF Pron",
      "screen_name" : "ELF_Pron",
      "indices" : [ 48, 57 ],
      "id_str" : "2222993041",
      "id" : 2222993041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/qhbUbSTqm5",
      "expanded_url" : "http:\/\/wp.me\/p3RMIO-43",
      "display_url" : "wp.me\/p3RMIO-43"
    } ]
  },
  "geo" : { },
  "id_str" : "427703576039673857",
  "text" : "Film star dictations http:\/\/t.co\/qhbUbSTqm5 via @ELF_Pron",
  "id" : 427703576039673857,
  "created_at" : "2014-01-27 07:24:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alannah Fitzgerald",
      "screen_name" : "AlannahFitz",
      "indices" : [ 3, 15 ],
      "id_str" : "223613160",
      "id" : 223613160
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oer",
      "indices" : [ 117, 121 ]
    }, {
      "text" : "oerrh",
      "indices" : [ 122, 128 ]
    }, {
      "text" : "openeducation",
      "indices" : [ 129, 143 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/2BZCm3pxDr",
      "expanded_url" : "http:\/\/oerexchange.org\/en",
      "display_url" : "oerexchange.org\/en"
    } ]
  },
  "geo" : { },
  "id_str" : "427549639295131648",
  "text" : "RT @AlannahFitz: OER Exchange Craigslist style: find &amp; share educational resources online http:\/\/t.co\/2BZCm3pxDr #oer #oerrh #openeducation",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.linkedin.com\/\" rel=\"nofollow\"\u003ELinkedIn\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "oer",
        "indices" : [ 100, 104 ]
      }, {
        "text" : "oerrh",
        "indices" : [ 105, 111 ]
      }, {
        "text" : "openeducation",
        "indices" : [ 112, 126 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/2BZCm3pxDr",
        "expanded_url" : "http:\/\/oerexchange.org\/en",
        "display_url" : "oerexchange.org\/en"
      } ]
    },
    "geo" : { },
    "id_str" : "427548100979605504",
    "text" : "OER Exchange Craigslist style: find &amp; share educational resources online http:\/\/t.co\/2BZCm3pxDr #oer #oerrh #openeducation",
    "id" : 427548100979605504,
    "created_at" : "2014-01-26 21:06:25 +0000",
    "user" : {
      "name" : "Alannah Fitzgerald",
      "screen_name" : "AlannahFitz",
      "protected" : false,
      "id_str" : "223613160",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2645381550\/e07d3b354efdac11bce2725cbc44e94e_normal.png",
      "id" : 223613160,
      "verified" : false
    }
  },
  "id" : 427549639295131648,
  "created_at" : "2014-01-26 21:12:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Huw Jarvis",
      "screen_name" : "TESOLacademic",
      "indices" : [ 3, 17 ],
      "id_str" : "43409552",
      "id" : 43409552
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gove",
      "indices" : [ 106, 111 ]
    }, {
      "text" : "ucu",
      "indices" : [ 134, 138 ]
    }, {
      "text" : "nut",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/att2ttrjGV",
      "expanded_url" : "http:\/\/m.truthdig.com\/report\/item\/why_the_united_states_is_destroying_her_education_system_20110410",
      "display_url" : "m.truthdig.com\/report\/item\/wh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427549113220358144",
  "text" : "RT @TESOLacademic: http:\/\/t.co\/att2ttrjGV  Much of this US-based critique is just as true for UK with the #gove assault on  education #ucu \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "gove",
        "indices" : [ 87, 92 ]
      }, {
        "text" : "ucu",
        "indices" : [ 115, 119 ]
      }, {
        "text" : "nut",
        "indices" : [ 120, 124 ]
      } ],
      "urls" : [ {
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/att2ttrjGV",
        "expanded_url" : "http:\/\/m.truthdig.com\/report\/item\/why_the_united_states_is_destroying_her_education_system_20110410",
        "display_url" : "m.truthdig.com\/report\/item\/wh\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "427538618341924864",
    "text" : "http:\/\/t.co\/att2ttrjGV  Much of this US-based critique is just as true for UK with the #gove assault on  education #ucu #nut",
    "id" : 427538618341924864,
    "created_at" : "2014-01-26 20:28:44 +0000",
    "user" : {
      "name" : "Huw Jarvis",
      "screen_name" : "TESOLacademic",
      "protected" : false,
      "id_str" : "43409552",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/569419268\/bg-logo_normal.jpg",
      "id" : 43409552,
      "verified" : false
    }
  },
  "id" : 427549113220358144,
  "created_at" : "2014-01-26 21:10:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Language Log",
      "screen_name" : "LanguageLog",
      "indices" : [ 3, 15 ],
      "id_str" : "20148973",
      "id" : 20148973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/2Eqo2LRnkR",
      "expanded_url" : "http:\/\/bit.ly\/1fo4fvs",
      "display_url" : "bit.ly\/1fo4fvs"
    } ]
  },
  "geo" : { },
  "id_str" : "427547034170961920",
  "text" : "RT @LanguageLog: SOTU evolution: In preparation for Tuesday's State of the Union address, I thought I'd take a look at the lang... http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/2Eqo2LRnkR",
        "expanded_url" : "http:\/\/bit.ly\/1fo4fvs",
        "display_url" : "bit.ly\/1fo4fvs"
      } ]
    },
    "geo" : { },
    "id_str" : "427510954729824256",
    "text" : "SOTU evolution: In preparation for Tuesday's State of the Union address, I thought I'd take a look at the lang... http:\/\/t.co\/2Eqo2LRnkR",
    "id" : 427510954729824256,
    "created_at" : "2014-01-26 18:38:49 +0000",
    "user" : {
      "name" : "Language Log",
      "screen_name" : "LanguageLog",
      "protected" : false,
      "id_str" : "20148973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1011503265\/gerund2_normal.jpg",
      "id" : 20148973,
      "verified" : false
    }
  },
  "id" : 427547034170961920,
  "created_at" : "2014-01-26 21:02:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sara Tonelli",
      "screen_name" : "sara_hlt",
      "indices" : [ 0, 9 ],
      "id_str" : "214062910",
      "id" : 214062910
    }, {
      "name" : "DH Group at FBK",
      "screen_name" : "DH_FBK",
      "indices" : [ 10, 17 ],
      "id_str" : "1598324696",
      "id" : 1598324696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "427510636428279808",
  "in_reply_to_user_id" : 214062910,
  "text" : "@sara_hlt @DH_FBK thanks for RT of timeline :)",
  "id" : 427510636428279808,
  "created_at" : "2014-01-26 18:37:33 +0000",
  "in_reply_to_screen_name" : "sara_hlt",
  "in_reply_to_user_id_str" : "214062910",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Costas Gabrielatos",
      "screen_name" : "congabonga",
      "indices" : [ 0, 11 ],
      "id_str" : "187484412",
      "id" : 187484412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/7ecaUnd0iw",
      "expanded_url" : "http:\/\/www.iva.dk\/bh\/core%20concepts%20in%20lis\/articles%20a-z\/luhn.htm",
      "display_url" : "iva.dk\/bh\/core%20conc\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "427485338207281152",
  "geo" : { },
  "id_str" : "427510191462948864",
  "in_reply_to_user_id" : 187484412,
  "text" : "@congabonga thanks im trying to understand this?  &lt;&lt;function of the rank peaked at intermediate values&gt;&gt; http:\/\/t.co\/7ecaUnd0iw any ideas\n?",
  "id" : 427510191462948864,
  "in_reply_to_status_id" : 427485338207281152,
  "created_at" : "2014-01-26 18:35:47 +0000",
  "in_reply_to_screen_name" : "congabonga",
  "in_reply_to_user_id_str" : "187484412",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Costas Gabrielatos",
      "screen_name" : "congabonga",
      "indices" : [ 0, 11 ],
      "id_str" : "187484412",
      "id" : 187484412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427473555639767040",
  "geo" : { },
  "id_str" : "427477053772804096",
  "in_reply_to_user_id" : 187484412,
  "text" : "@congabonga had to look that word up :) can u clarify? r u saying ref corpus is needed when measuring keyness?",
  "id" : 427477053772804096,
  "in_reply_to_status_id" : 427473555639767040,
  "created_at" : "2014-01-26 16:24:06 +0000",
  "in_reply_to_screen_name" : "congabonga",
  "in_reply_to_user_id_str" : "187484412",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Costas Gabrielatos",
      "screen_name" : "congabonga",
      "indices" : [ 0, 11 ],
      "id_str" : "187484412",
      "id" : 187484412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/P4YHYoxK9g",
      "expanded_url" : "https:\/\/text-analysis.googlecode.com\/files\/luhn58.pdf",
      "display_url" : "text-analysis.googlecode.com\/files\/luhn58.p\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "427452714201939969",
  "geo" : { },
  "id_str" : "427468125420789761",
  "in_reply_to_user_id" : 187484412,
  "text" : "@congabonga was this guy concluding same thing but without need of reference corpus? https:\/\/t.co\/P4YHYoxK9g",
  "id" : 427468125420789761,
  "in_reply_to_status_id" : 427452714201939969,
  "created_at" : "2014-01-26 15:48:37 +0000",
  "in_reply_to_screen_name" : "congabonga",
  "in_reply_to_user_id_str" : "187484412",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Rayson",
      "screen_name" : "perayson",
      "indices" : [ 0, 9 ],
      "id_str" : "263108959",
      "id" : 263108959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427406355779973121",
  "geo" : { },
  "id_str" : "427457013631553536",
  "in_reply_to_user_id" : 263108959,
  "text" : "@perayson ok done thanks :)",
  "id" : 427457013631553536,
  "in_reply_to_status_id" : 427406355779973121,
  "created_at" : "2014-01-26 15:04:28 +0000",
  "in_reply_to_screen_name" : "perayson",
  "in_reply_to_user_id_str" : "263108959",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Parise",
      "screen_name" : "peterrenshu",
      "indices" : [ 0, 12 ],
      "id_str" : "631949549",
      "id" : 631949549
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427450916287946752",
  "geo" : { },
  "id_str" : "427454330250088448",
  "in_reply_to_user_id" : 631949549,
  "text" : "@peterrenshu wonder what advantages that non-free PetaMem Scripting Environment posted in your comments has over say free NLTK?",
  "id" : 427454330250088448,
  "in_reply_to_status_id" : 427450916287946752,
  "created_at" : "2014-01-26 14:53:48 +0000",
  "in_reply_to_screen_name" : "peterrenshu",
  "in_reply_to_user_id_str" : "631949549",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Parise",
      "screen_name" : "peterrenshu",
      "indices" : [ 3, 15 ],
      "id_str" : "631949549",
      "id" : 631949549
    }, {
      "name" : "Peter Parise",
      "screen_name" : "peterrenshu",
      "indices" : [ 87, 99 ],
      "id_str" : "631949549",
      "id" : 631949549
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/an2YDvMMad",
      "expanded_url" : "http:\/\/wp.me\/PfNDY-1l",
      "display_url" : "wp.me\/PfNDY-1l"
    } ]
  },
  "geo" : { },
  "id_str" : "427453547836620800",
  "text" : "RT @peterrenshu: A (brief) Guide to Corpus  Analysis Tools  http:\/\/t.co\/an2YDvMMad via @peterrenshu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Peter Parise",
        "screen_name" : "peterrenshu",
        "indices" : [ 70, 82 ],
        "id_str" : "631949549",
        "id" : 631949549
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 65 ],
        "url" : "http:\/\/t.co\/an2YDvMMad",
        "expanded_url" : "http:\/\/wp.me\/PfNDY-1l",
        "display_url" : "wp.me\/PfNDY-1l"
      } ]
    },
    "geo" : { },
    "id_str" : "427450916287946752",
    "text" : "A (brief) Guide to Corpus  Analysis Tools  http:\/\/t.co\/an2YDvMMad via @peterrenshu",
    "id" : 427450916287946752,
    "created_at" : "2014-01-26 14:40:14 +0000",
    "user" : {
      "name" : "Peter Parise",
      "screen_name" : "peterrenshu",
      "protected" : false,
      "id_str" : "631949549",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2390141891\/azxwx57ppddic0hnd26k_normal.jpeg",
      "id" : 631949549,
      "verified" : false
    }
  },
  "id" : 427453547836620800,
  "created_at" : "2014-01-26 14:50:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noor Adnan",
      "screen_name" : "n00rbaizura",
      "indices" : [ 0, 12 ],
      "id_str" : "412094121",
      "id" : 412094121
    }, {
      "name" : "Akira Murakami",
      "screen_name" : "mrkm_a",
      "indices" : [ 13, 20 ],
      "id_str" : "116922669",
      "id" : 116922669
    }, {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "indices" : [ 21, 33 ],
      "id_str" : "849729062",
      "id" : 849729062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "427441342700998658",
  "in_reply_to_user_id" : 412094121,
  "text" : "@n00rbaizura @mrkm_a @TonyMcEnery thks for RT of timeline if u see anything missing\/errors\/additions let me know",
  "id" : 427441342700998658,
  "created_at" : "2014-01-26 14:02:12 +0000",
  "in_reply_to_screen_name" : "n00rbaizura",
  "in_reply_to_user_id_str" : "412094121",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Patsko",
      "screen_name" : "lauraahaha",
      "indices" : [ 77, 88 ],
      "id_str" : "97957137",
      "id" : 97957137
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/ad2Obbd5H2",
      "expanded_url" : "http:\/\/wp.me\/p2VnAo-7KsV2",
      "display_url" : "wp.me\/p2VnAo-7KsV2"
    } ]
  },
  "geo" : { },
  "id_str" : "427437485669351424",
  "text" : "ETAS Conference presentation: Whiteboard wizardry http:\/\/t.co\/ad2Obbd5H2 via @lauraahaha",
  "id" : 427437485669351424,
  "created_at" : "2014-01-26 13:46:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dermot Lynott",
      "screen_name" : "DermotLynott",
      "indices" : [ 0, 13 ],
      "id_str" : "389357467",
      "id" : 389357467
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "timeliner",
      "indices" : [ 47, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "427403045429706752",
  "in_reply_to_user_id" : 389357467,
  "text" : "@DermotLynott thx for computerised corpus tool #timeliner RT :)",
  "id" : 427403045429706752,
  "created_at" : "2014-01-26 11:30:01 +0000",
  "in_reply_to_screen_name" : "DermotLynott",
  "in_reply_to_user_id_str" : "389357467",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olcay Sert",
      "screen_name" : "SertOlcay",
      "indices" : [ 0, 10 ],
      "id_str" : "1490695945",
      "id" : 1490695945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427396089465942017",
  "geo" : { },
  "id_str" : "427402762385518592",
  "in_reply_to_user_id" : 1490695945,
  "text" : "@SertOlcay possibly though they are corpora than actual computer tools?",
  "id" : 427402762385518592,
  "in_reply_to_status_id" : 427396089465942017,
  "created_at" : "2014-01-26 11:28:53 +0000",
  "in_reply_to_screen_name" : "SertOlcay",
  "in_reply_to_user_id_str" : "1490695945",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Rayson",
      "screen_name" : "perayson",
      "indices" : [ 0, 9 ],
      "id_str" : "263108959",
      "id" : 263108959
    }, {
      "name" : "Olcay Sert",
      "screen_name" : "SertOlcay",
      "indices" : [ 10, 20 ],
      "id_str" : "1490695945",
      "id" : 1490695945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427389309709066240",
  "geo" : { },
  "id_str" : "427393260525350912",
  "in_reply_to_user_id" : 263108959,
  "text" : "@perayson @SertOlcay thanks for RTs :)  anything u think should be added to wmatrix entry?",
  "id" : 427393260525350912,
  "in_reply_to_status_id" : 427389309709066240,
  "created_at" : "2014-01-26 10:51:08 +0000",
  "in_reply_to_screen_name" : "perayson",
  "in_reply_to_user_id_str" : "263108959",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/tpxmd0qW68",
      "expanded_url" : "http:\/\/www.cepr.net\/index.php\/op-eds-&-columns\/op-eds-&-columns\/the-banking-industrys-biggest-problem-isnt-bonuses-or-market-share",
      "display_url" : "cepr.net\/index.php\/op-e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427382662756450304",
  "text" : "The Banking Industry's Biggest Problem isn't Bonuses or Market Share, Ha-Joon Chang http:\/\/t.co\/tpxmd0qW68",
  "id" : 427382662756450304,
  "created_at" : "2014-01-26 10:09:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Seymour",
      "screen_name" : "leninology",
      "indices" : [ 3, 14 ],
      "id_str" : "15557246",
      "id" : 15557246
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/kPDhcSc42C",
      "expanded_url" : "http:\/\/www.leninology.com\/2014\/01\/benefits-street-neoliberalism-in-our.html",
      "display_url" : "leninology.com\/2014\/01\/benefi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427375397714808832",
  "text" : "RT @leninology: Benefits Street: the neoliberalism in our souls? http:\/\/t.co\/kPDhcSc42C",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/kPDhcSc42C",
        "expanded_url" : "http:\/\/www.leninology.com\/2014\/01\/benefits-street-neoliberalism-in-our.html",
        "display_url" : "leninology.com\/2014\/01\/benefi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "427254861101801472",
    "text" : "Benefits Street: the neoliberalism in our souls? http:\/\/t.co\/kPDhcSc42C",
    "id" : 427254861101801472,
    "created_at" : "2014-01-26 01:41:11 +0000",
    "user" : {
      "name" : "Richard Seymour",
      "screen_name" : "leninology",
      "protected" : false,
      "id_str" : "15557246",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762344914583781377\/UDn8tMrp_normal.jpg",
      "id" : 15557246,
      "verified" : false
    }
  },
  "id" : 427375397714808832,
  "created_at" : "2014-01-26 09:40:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pando",
      "screen_name" : "PandoDaily",
      "indices" : [ 123, 134 ],
      "id_str" : "419710142",
      "id" : 419710142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/A7Fu1jqgn0",
      "expanded_url" : "http:\/\/pando.com\/2014\/01\/23\/the-techtopus-how-silicon-valleys-most-celebrated-ceos-conspired-to-drive-down-100000-tech-engineers-wages\/",
      "display_url" : "pando.com\/2014\/01\/23\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427372105785561088",
  "text" : "How Silicon Valley's most celebrated CEOs conspired to drive down 100,000 tech engineers' wages http:\/\/t.co\/A7Fu1jqgn0 via @pandodaily",
  "id" : 427372105785561088,
  "created_at" : "2014-01-26 09:27:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott McLeod",
      "screen_name" : "mcleod",
      "indices" : [ 3, 10 ],
      "id_str" : "4132841",
      "id" : 4132841
    }, {
      "name" : "Curt Rees",
      "screen_name" : "CurtRees",
      "indices" : [ 77, 86 ],
      "id_str" : "118413810",
      "id" : 118413810
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "funny",
      "indices" : [ 87, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/ua9GrYpn4x",
      "expanded_url" : "http:\/\/youtu.be\/DYu_bGbZiiQ",
      "display_url" : "youtu.be\/DYu_bGbZiiQ"
    } ]
  },
  "geo" : { },
  "id_str" : "427235462768762881",
  "text" : "RT @mcleod: A Conference Call in Real Life [VIDEO] http:\/\/t.co\/ua9GrYpn4x HT @curtrees #funny",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Curt Rees",
        "screen_name" : "CurtRees",
        "indices" : [ 65, 74 ],
        "id_str" : "118413810",
        "id" : 118413810
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "funny",
        "indices" : [ 75, 81 ]
      } ],
      "urls" : [ {
        "indices" : [ 39, 61 ],
        "url" : "http:\/\/t.co\/ua9GrYpn4x",
        "expanded_url" : "http:\/\/youtu.be\/DYu_bGbZiiQ",
        "display_url" : "youtu.be\/DYu_bGbZiiQ"
      } ]
    },
    "geo" : { },
    "id_str" : "427234382152474625",
    "text" : "A Conference Call in Real Life [VIDEO] http:\/\/t.co\/ua9GrYpn4x HT @curtrees #funny",
    "id" : 427234382152474625,
    "created_at" : "2014-01-26 00:19:48 +0000",
    "user" : {
      "name" : "Scott McLeod",
      "screen_name" : "mcleod",
      "protected" : false,
      "id_str" : "4132841",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528513398003077123\/U0fv_0fy_normal.jpeg",
      "id" : 4132841,
      "verified" : false
    }
  },
  "id" : 427235462768762881,
  "created_at" : "2014-01-26 00:24:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Moravec",
      "screen_name" : "ProfessMoravec",
      "indices" : [ 0, 15 ],
      "id_str" : "369529173",
      "id" : 369529173
    }, {
      "name" : "natiserhost197",
      "screen_name" : "esl_robert",
      "indices" : [ 16, 27 ],
      "id_str" : "2982357761",
      "id" : 2982357761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "427224279780831232",
  "in_reply_to_user_id" : 369529173,
  "text" : "@ProfessMoravec @esl_robert thks for RTs of corpus tool timeline, if you see anything to add\/modify let me know",
  "id" : 427224279780831232,
  "created_at" : "2014-01-25 23:39:40 +0000",
  "in_reply_to_screen_name" : "ProfessMoravec",
  "in_reply_to_user_id_str" : "369529173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpus",
      "indices" : [ 58, 65 ]
    }, {
      "text" : "wordneighbours",
      "indices" : [ 86, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/zAsqBN9Fxi",
      "expanded_url" : "https:\/\/plus.google.com\/104940199413423400545\/posts\/CUJbta7seoE",
      "display_url" : "plus.google.com\/10494019941342\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427222495414874112",
  "text" : "don't miss out join G+ CL community to be updated on cool #corpus language tools e.g. #wordneighbours https:\/\/t.co\/zAsqBN9Fxi",
  "id" : 427222495414874112,
  "created_at" : "2014-01-25 23:32:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Claire Hardaker",
      "screen_name" : "DrClaireH",
      "indices" : [ 3, 13 ],
      "id_str" : "237842162",
      "id" : 237842162
    }, {
      "name" : "Andrew Hardie",
      "screen_name" : "HardieResearch",
      "indices" : [ 112, 127 ],
      "id_str" : "970452764",
      "id" : 970452764
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/DrClaireH\/status\/427149389157916672\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/CjeLCiYxcX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Be2KGyrIQAAb5sR.jpg",
      "id_str" : "427149388956581888",
      "id" : 427149388956581888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Be2KGyrIQAAb5sR.jpg",
      "sizes" : [ {
        "h" : 693,
        "resize" : "fit",
        "w" : 959
      }, {
        "h" : 246,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 434,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 693,
        "resize" : "fit",
        "w" : 959
      } ],
      "display_url" : "pic.twitter.com\/CjeLCiYxcX"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "427208833766014976",
  "text" : "RT @DrClaireH: Ha! Kinda corpus linguisticky - the Google autocomplete results for: \"Why is [state] so...\" (HT: @HardieResearch.) http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Hardie",
        "screen_name" : "HardieResearch",
        "indices" : [ 97, 112 ],
        "id_str" : "970452764",
        "id" : 970452764
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/DrClaireH\/status\/427149389157916672\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/CjeLCiYxcX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Be2KGyrIQAAb5sR.jpg",
        "id_str" : "427149388956581888",
        "id" : 427149388956581888,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Be2KGyrIQAAb5sR.jpg",
        "sizes" : [ {
          "h" : 693,
          "resize" : "fit",
          "w" : 959
        }, {
          "h" : 246,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 434,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 693,
          "resize" : "fit",
          "w" : 959
        } ],
        "display_url" : "pic.twitter.com\/CjeLCiYxcX"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "427149389157916672",
    "text" : "Ha! Kinda corpus linguisticky - the Google autocomplete results for: \"Why is [state] so...\" (HT: @HardieResearch.) http:\/\/t.co\/CjeLCiYxcX",
    "id" : 427149389157916672,
    "created_at" : "2014-01-25 18:42:05 +0000",
    "user" : {
      "name" : "Dr Claire Hardaker",
      "screen_name" : "DrClaireH",
      "protected" : false,
      "id_str" : "237842162",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744470254177390592\/ZhYTy0JE_normal.jpg",
      "id" : 237842162,
      "verified" : false
    }
  },
  "id" : 427208833766014976,
  "created_at" : "2014-01-25 22:38:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Moravec",
      "screen_name" : "ProfessMoravec",
      "indices" : [ 0, 15 ],
      "id_str" : "369529173",
      "id" : 369529173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427195446117683200",
  "geo" : { },
  "id_str" : "427196543284695040",
  "in_reply_to_user_id" : 369529173,
  "text" : "@ProfessMoravec oh mountain lion shld work great :)",
  "id" : 427196543284695040,
  "in_reply_to_status_id" : 427195446117683200,
  "created_at" : "2014-01-25 21:49:27 +0000",
  "in_reply_to_screen_name" : "ProfessMoravec",
  "in_reply_to_user_id_str" : "369529173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Moravec",
      "screen_name" : "ProfessMoravec",
      "indices" : [ 0, 15 ],
      "id_str" : "369529173",
      "id" : 369529173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/tQFHI3RBvw",
      "expanded_url" : "https:\/\/groups.google.com\/d\/msg\/antconc\/yBxc2Pl5RcI\/pTvNd8wsrkUJ",
      "display_url" : "groups.google.com\/d\/msg\/antconc\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "427195446117683200",
  "geo" : { },
  "id_str" : "427196174966067200",
  "in_reply_to_user_id" : 369529173,
  "text" : "@ProfessMoravec and this what Anthony says about Mavericks screen refresh issue https:\/\/t.co\/tQFHI3RBvw",
  "id" : 427196174966067200,
  "in_reply_to_status_id" : 427195446117683200,
  "created_at" : "2014-01-25 21:47:59 +0000",
  "in_reply_to_screen_name" : "ProfessMoravec",
  "in_reply_to_user_id_str" : "369529173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Moravec",
      "screen_name" : "ProfessMoravec",
      "indices" : [ 0, 15 ],
      "id_str" : "369529173",
      "id" : 369529173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/XASh40PUKA",
      "expanded_url" : "https:\/\/plus.google.com\/104940199413423400545\/posts\/iencCMFCKwh",
      "display_url" : "plus.google.com\/10494019941342\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "427195446117683200",
  "geo" : { },
  "id_str" : "427195884560867328",
  "in_reply_to_user_id" : 369529173,
  "text" : "@ProfessMoravec some quick reactions here https:\/\/t.co\/XASh40PUKA",
  "id" : 427195884560867328,
  "in_reply_to_status_id" : 427195446117683200,
  "created_at" : "2014-01-25 21:46:50 +0000",
  "in_reply_to_screen_name" : "ProfessMoravec",
  "in_reply_to_user_id_str" : "369529173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Moravec",
      "screen_name" : "ProfessMoravec",
      "indices" : [ 121, 136 ],
      "id_str" : "369529173",
      "id" : 369529173
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "antconc",
      "indices" : [ 27, 35 ]
    }, {
      "text" : "corpusmooc",
      "indices" : [ 42, 53 ]
    }, {
      "text" : "Corpus",
      "indices" : [ 80, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/VlCviJzmwf",
      "expanded_url" : "http:\/\/timemapper.okfnlabs.org\/muranava\/history-of-computerised-corpus-tools#0",
      "display_url" : "timemapper.okfnlabs.org\/muranava\/histo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427194336334200832",
  "text" : "to celebrate new verson of #antconc &amp; #corpusmooc A History of Computerised #Corpus Tools http:\/\/t.co\/VlCviJzmwf h\/t @ProfessMoravec",
  "id" : 427194336334200832,
  "created_at" : "2014-01-25 21:40:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "textivate",
      "screen_name" : "textivate",
      "indices" : [ 0, 10 ],
      "id_str" : "757151820",
      "id" : 757151820
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427063674004832256",
  "geo" : { },
  "id_str" : "427105020119498752",
  "in_reply_to_user_id" : 757151820,
  "text" : "@textivate &lt;&lt;\u00E7a va dans la lune avec des ordinateurs et du coca-cola mais \u00E7a bouffe du gigot \u00E0 la confiture&gt;&gt; :)",
  "id" : 427105020119498752,
  "in_reply_to_status_id" : 427063674004832256,
  "created_at" : "2014-01-25 15:45:46 +0000",
  "in_reply_to_screen_name" : "textivate",
  "in_reply_to_user_id_str" : "757151820",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Claire Hart",
      "screen_name" : "claire_hart",
      "indices" : [ 3, 15 ],
      "id_str" : "96138105",
      "id" : 96138105
    }, {
      "name" : "Bethany Cagnol",
      "screen_name" : "bethcagnol",
      "indices" : [ 62, 73 ],
      "id_str" : "27641720",
      "id" : 27641720
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iatefl",
      "indices" : [ 29, 36 ]
    }, {
      "text" : "besig",
      "indices" : [ 37, 43 ]
    }, {
      "text" : "ELT",
      "indices" : [ 124, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/KN1E6Exya3",
      "expanded_url" : "http:\/\/bit.ly\/KKgvfM",
      "display_url" : "bit.ly\/KKgvfM"
    } ]
  },
  "geo" : { },
  "id_str" : "427098255290560512",
  "text" : "RT @claire_hart: In our next #iatefl #besig weekend workshop, @bethcagnol will be looking at incorporating life skills into #ELT 9 Feb http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bethany Cagnol",
        "screen_name" : "bethcagnol",
        "indices" : [ 45, 56 ],
        "id_str" : "27641720",
        "id" : 27641720
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "iatefl",
        "indices" : [ 12, 19 ]
      }, {
        "text" : "besig",
        "indices" : [ 20, 26 ]
      }, {
        "text" : "ELT",
        "indices" : [ 107, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/KN1E6Exya3",
        "expanded_url" : "http:\/\/bit.ly\/KKgvfM",
        "display_url" : "bit.ly\/KKgvfM"
      } ]
    },
    "geo" : { },
    "id_str" : "426434969116741632",
    "text" : "In our next #iatefl #besig weekend workshop, @bethcagnol will be looking at incorporating life skills into #ELT 9 Feb http:\/\/t.co\/KN1E6Exya3",
    "id" : 426434969116741632,
    "created_at" : "2014-01-23 19:23:14 +0000",
    "user" : {
      "name" : "Claire Hart",
      "screen_name" : "claire_hart",
      "protected" : false,
      "id_str" : "96138105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2521304594\/55hwgymtz99dmu1ka8rt_normal.jpeg",
      "id" : 96138105,
      "verified" : false
    }
  },
  "id" : 427098255290560512,
  "created_at" : "2014-01-25 15:18:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "antconc",
      "indices" : [ 17, 25 ]
    }, {
      "text" : "corpusmooc",
      "indices" : [ 58, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/lKuicMCos0",
      "expanded_url" : "https:\/\/groups.google.com\/forum\/#!topic\/antconc\/yBxc2Pl5RcI",
      "display_url" : "groups.google.com\/forum\/#!topic\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427071666632404992",
  "text" : "more info on new #antconc version https:\/\/t.co\/lKuicMCos0 #corpusmooc",
  "id" : 427071666632404992,
  "created_at" : "2014-01-25 13:33:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Moravec",
      "screen_name" : "ProfessMoravec",
      "indices" : [ 0, 15 ],
      "id_str" : "369529173",
      "id" : 369529173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427036660023312384",
  "geo" : { },
  "id_str" : "427071021296803840",
  "in_reply_to_user_id" : 369529173,
  "text" : "@ProfessMoravec ooh nice cheers :)",
  "id" : 427071021296803840,
  "in_reply_to_status_id" : 427036660023312384,
  "created_at" : "2014-01-25 13:30:40 +0000",
  "in_reply_to_screen_name" : "ProfessMoravec",
  "in_reply_to_user_id_str" : "369529173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "textivate",
      "screen_name" : "textivate",
      "indices" : [ 3, 13 ],
      "id_str" : "757151820",
      "id" : 757151820
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/nD7f27kSpx",
      "expanded_url" : "http:\/\/franska.fr\/smile\/1\/835\/La_France_vue_par_les_films_am%C3%A9ricains_\/",
      "display_url" : "franska.fr\/smile\/1\/835\/La\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427070255278858240",
  "text" : "RT @textivate: La France vue par les films am\u00E9ricains  - :) - News fle en fran\u00E7ais facile - easy french !   http:\/\/t.co\/nD7f27kSpx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/nD7f27kSpx",
        "expanded_url" : "http:\/\/franska.fr\/smile\/1\/835\/La_France_vue_par_les_films_am%C3%A9ricains_\/",
        "display_url" : "franska.fr\/smile\/1\/835\/La\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "427063674004832256",
    "text" : "La France vue par les films am\u00E9ricains  - :) - News fle en fran\u00E7ais facile - easy french !   http:\/\/t.co\/nD7f27kSpx",
    "id" : 427063674004832256,
    "created_at" : "2014-01-25 13:01:29 +0000",
    "user" : {
      "name" : "textivate",
      "screen_name" : "textivate",
      "protected" : false,
      "id_str" : "757151820",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616568320066764800\/rx5tLnzg_normal.png",
      "id" : 757151820,
      "verified" : false
    }
  },
  "id" : 427070255278858240,
  "created_at" : "2014-01-25 13:27:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 69, 85 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/tSLMLWnIwt",
      "expanded_url" : "http:\/\/wp.me\/p31zUY-jn",
      "display_url" : "wp.me\/p31zUY-jn"
    } ]
  },
  "geo" : { },
  "id_str" : "427050386675875843",
  "text" : "Cheat codes to intelligence: touchpaper#7 http:\/\/t.co\/tSLMLWnIwt via @wordpressdotcom",
  "id" : 427050386675875843,
  "created_at" : "2014-01-25 12:08:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anna Loseva",
      "screen_name" : "AnnLoseva",
      "indices" : [ 3, 13 ],
      "id_str" : "38822368",
      "id" : 38822368
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/FzPI6T5uNA",
      "expanded_url" : "http:\/\/wp.me\/p1wlqw-bIVGE",
      "display_url" : "wp.me\/p1wlqw-bIVGE"
    } ]
  },
  "geo" : { },
  "id_str" : "426879981223178240",
  "text" : "RT @AnnLoseva: 16 question marks and a soundtrack. http:\/\/t.co\/FzPI6T5uNA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 36, 58 ],
        "url" : "http:\/\/t.co\/FzPI6T5uNA",
        "expanded_url" : "http:\/\/wp.me\/p1wlqw-bIVGE",
        "display_url" : "wp.me\/p1wlqw-bIVGE"
      } ]
    },
    "geo" : { },
    "id_str" : "426850545567952896",
    "text" : "16 question marks and a soundtrack. http:\/\/t.co\/FzPI6T5uNA",
    "id" : 426850545567952896,
    "created_at" : "2014-01-24 22:54:35 +0000",
    "user" : {
      "name" : "Anna Loseva",
      "screen_name" : "AnnLoseva",
      "protected" : false,
      "id_str" : "38822368",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/767034457748541441\/VJrp4Jie_normal.jpg",
      "id" : 38822368,
      "verified" : false
    }
  },
  "id" : 426879981223178240,
  "created_at" : "2014-01-25 00:51:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 50, 66 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "426758966706589697",
  "text" : "there really should be a like button for comments @wordpressdotcom make it so please :)",
  "id" : 426758966706589697,
  "created_at" : "2014-01-24 16:50:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "indices" : [ 0, 11 ],
      "id_str" : "152051625",
      "id" : 152051625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426744080190943232",
  "geo" : { },
  "id_str" : "426747037900500992",
  "in_reply_to_user_id" : 152051625,
  "text" : "@heatherfro ok thanks",
  "id" : 426747037900500992,
  "in_reply_to_status_id" : 426744080190943232,
  "created_at" : "2014-01-24 16:03:17 +0000",
  "in_reply_to_screen_name" : "heatherfro",
  "in_reply_to_user_id_str" : "152051625",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "indices" : [ 0, 11 ],
      "id_str" : "152051625",
      "id" : 152051625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426742483671060480",
  "geo" : { },
  "id_str" : "426743175848271872",
  "in_reply_to_user_id" : 152051625,
  "text" : "@heatherfro analysis",
  "id" : 426743175848271872,
  "in_reply_to_status_id" : 426742483671060480,
  "created_at" : "2014-01-24 15:47:56 +0000",
  "in_reply_to_screen_name" : "heatherfro",
  "in_reply_to_user_id_str" : "152051625",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "indices" : [ 0, 11 ],
      "id_str" : "152051625",
      "id" : 152051625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426736097272807424",
  "geo" : { },
  "id_str" : "426742196440551425",
  "in_reply_to_user_id" : 152051625,
  "text" : "@heatherfro hi do u know any good (i.e. low learning curve!) xml based tools apart from XAIRA and CLARK?",
  "id" : 426742196440551425,
  "in_reply_to_status_id" : 426736097272807424,
  "created_at" : "2014-01-24 15:44:02 +0000",
  "in_reply_to_screen_name" : "heatherfro",
  "in_reply_to_user_id_str" : "152051625",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "indices" : [ 3, 14 ],
      "id_str" : "152051625",
      "id" : 152051625
    }, {
      "name" : "Nicola Carty",
      "screen_name" : "NicolaParty",
      "indices" : [ 19, 31 ],
      "id_str" : "590000451",
      "id" : 590000451
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 147, 148 ],
      "url" : "http:\/\/t.co\/YvYLqn7LKe",
      "expanded_url" : "http:\/\/www.sdkrashen.com\/",
      "display_url" : "sdkrashen.com"
    } ]
  },
  "geo" : { },
  "id_str" : "426720510492557313",
  "text" : "RT @heatherfro: MT @NicolaParty Krashen's Principles&amp;Practice in SLA and SLA&amp;Second Language Learning available for download FOR FREE http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nicola Carty",
        "screen_name" : "NicolaParty",
        "indices" : [ 3, 15 ],
        "id_str" : "590000451",
        "id" : 590000451
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 126, 148 ],
        "url" : "http:\/\/t.co\/YvYLqn7LKe",
        "expanded_url" : "http:\/\/www.sdkrashen.com\/",
        "display_url" : "sdkrashen.com"
      } ]
    },
    "geo" : { },
    "id_str" : "426713849799397376",
    "text" : "MT @NicolaParty Krashen's Principles&amp;Practice in SLA and SLA&amp;Second Language Learning available for download FOR FREE http:\/\/t.co\/YvYLqn7LKe",
    "id" : 426713849799397376,
    "created_at" : "2014-01-24 13:51:24 +0000",
    "user" : {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "protected" : false,
      "id_str" : "152051625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/688767277022494720\/KMrzOBc1_normal.jpg",
      "id" : 152051625,
      "verified" : false
    }
  },
  "id" : 426720510492557313,
  "created_at" : "2014-01-24 14:17:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "426711471892881408",
  "text" : "wow at woo! - appearing in an otherwise very rational article on academic writing in latest ETP @teflskeptic",
  "id" : 426711471892881408,
  "created_at" : "2014-01-24 13:41:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 53, 69 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/wELYniRZxv",
      "expanded_url" : "http:\/\/wp.me\/p2rTTh-60",
      "display_url" : "wp.me\/p2rTTh-60"
    } ]
  },
  "geo" : { },
  "id_str" : "426685367249428480",
  "text" : "the activity with no name http:\/\/t.co\/wELYniRZxv via @wordpressdotcom",
  "id" : 426685367249428480,
  "created_at" : "2014-01-24 11:58:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/ajuNPcA20Q",
      "expanded_url" : "http:\/\/rtw.ml.cmu.edu\/rtw\/",
      "display_url" : "rtw.ml.cmu.edu\/rtw\/"
    } ]
  },
  "geo" : { },
  "id_str" : "426502315005071360",
  "text" : "NELL Never ending language learning http:\/\/t.co\/ajuNPcA20Q h\/t facebook CL group",
  "id" : 426502315005071360,
  "created_at" : "2014-01-23 23:50:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 50, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/O63YCzdAg3",
      "expanded_url" : "http:\/\/sfltdu.blogspot.fr\/p\/lexis.html",
      "display_url" : "sfltdu.blogspot.fr\/p\/lexis.html"
    } ]
  },
  "geo" : { },
  "id_str" : "426477192181059584",
  "text" : "nice list of lexical tools http:\/\/t.co\/O63YCzdAg3 #eltchat",
  "id" : 426477192181059584,
  "created_at" : "2014-01-23 22:11:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/sabP8RQvM1",
      "expanded_url" : "http:\/\/www.lrb.co.uk\/v35\/n20\/stefan-collini\/sold-out",
      "display_url" : "lrb.co.uk\/v35\/n20\/stefan\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426476450955284481",
  "text" : "Sold Out...first-rate universities into third-rate companies...http:\/\/t.co\/sabP8RQvM1",
  "id" : 426476450955284481,
  "created_at" : "2014-01-23 22:08:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Kern\u24C4h\u24B6n",
      "screen_name" : "dkernohan",
      "indices" : [ 3, 13 ],
      "id_str" : "12219232",
      "id" : 12219232
    }, {
      "name" : "Martin Weller",
      "screen_name" : "mweller",
      "indices" : [ 80, 88 ],
      "id_str" : "7127162",
      "id" : 7127162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/lZaALnD1Jt",
      "expanded_url" : "http:\/\/nogoodreason.typepad.co.uk\/no_good_reason\/2014\/01\/the-dangers-of-the-silicon-valley-narrative.html",
      "display_url" : "nogoodreason.typepad.co.uk\/no_good_reason\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426397622497447936",
  "text" : "RT @dkernohan: This is an excellent post on the \"silicon valley narrative\" from @mweller http:\/\/t.co\/lZaALnD1Jt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/janetter.net\/\" rel=\"nofollow\"\u003EJanetter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Martin Weller",
        "screen_name" : "mweller",
        "indices" : [ 65, 73 ],
        "id_str" : "7127162",
        "id" : 7127162
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/lZaALnD1Jt",
        "expanded_url" : "http:\/\/nogoodreason.typepad.co.uk\/no_good_reason\/2014\/01\/the-dangers-of-the-silicon-valley-narrative.html",
        "display_url" : "nogoodreason.typepad.co.uk\/no_good_reason\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "426303073313882113",
    "text" : "This is an excellent post on the \"silicon valley narrative\" from @mweller http:\/\/t.co\/lZaALnD1Jt",
    "id" : 426303073313882113,
    "created_at" : "2014-01-23 10:39:07 +0000",
    "user" : {
      "name" : "David Kern\u24C4h\u24B6n",
      "screen_name" : "dkernohan",
      "protected" : false,
      "id_str" : "12219232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/757702202437804032\/4Xrm7IIe_normal.jpg",
      "id" : 12219232,
      "verified" : false
    }
  },
  "id" : 426397622497447936,
  "created_at" : "2014-01-23 16:54:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "indices" : [ 0, 11 ],
      "id_str" : "152051625",
      "id" : 152051625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/6sxYcefvrE",
      "expanded_url" : "http:\/\/worrydream.com\/MeanwhileAtCodeOrg\/",
      "display_url" : "worrydream.com\/MeanwhileAtCod\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "426370909788962817",
  "geo" : { },
  "id_str" : "426389271998500864",
  "in_reply_to_user_id" : 152051625,
  "text" : "@heatherfro seems interesting project, +emphasis+ on storytelling is promising, have u seen this? http:\/\/t.co\/6sxYcefvrE",
  "id" : 426389271998500864,
  "in_reply_to_status_id" : 426370909788962817,
  "created_at" : "2014-01-23 16:21:39 +0000",
  "in_reply_to_screen_name" : "heatherfro",
  "in_reply_to_user_id_str" : "152051625",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Li-Shih Huang, PhD",
      "screen_name" : "AppLingProf",
      "indices" : [ 3, 15 ],
      "id_str" : "128714685",
      "id" : 128714685
    }, {
      "name" : "\u6C34\u672C\u3000\u7BE4",
      "screen_name" : "MizumotoAtsushi",
      "indices" : [ 143, 144 ],
      "id_str" : "298592919",
      "id" : 298592919
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/LXo7Eeqp29",
      "expanded_url" : "http:\/\/goo.gl\/NSDxJ0",
      "display_url" : "goo.gl\/NSDxJ0"
    } ]
  },
  "geo" : { },
  "id_str" : "426322997054828544",
  "text" : "RT @AppLingProf: Direct teach'g of vocab after listening: is it worth the effort &amp; what method is best? http:\/\/t.co\/LXo7Eeqp29 [Abstract] H\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u6C34\u672C\u3000\u7BE4",
        "screen_name" : "MizumotoAtsushi",
        "indices" : [ 128, 144 ],
        "id_str" : "298592919",
        "id" : 298592919
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/LXo7Eeqp29",
        "expanded_url" : "http:\/\/goo.gl\/NSDxJ0",
        "display_url" : "goo.gl\/NSDxJ0"
      } ]
    },
    "geo" : { },
    "id_str" : "426247359043878913",
    "text" : "Direct teach'g of vocab after listening: is it worth the effort &amp; what method is best? http:\/\/t.co\/LXo7Eeqp29 [Abstract] HT @MizumotoAtsushi",
    "id" : 426247359043878913,
    "created_at" : "2014-01-23 06:57:44 +0000",
    "user" : {
      "name" : "Li-Shih Huang, PhD",
      "screen_name" : "AppLingProf",
      "protected" : false,
      "id_str" : "128714685",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/577224421611466752\/7ozjbHH5_normal.jpeg",
      "id" : 128714685,
      "verified" : false
    }
  },
  "id" : 426322997054828544,
  "created_at" : "2014-01-23 11:58:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angus B Grieve-Smith",
      "screen_name" : "grvsmth",
      "indices" : [ 3, 11 ],
      "id_str" : "22381639",
      "id" : 22381639
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 124, 133 ],
      "id_str" : "18602422",
      "id" : 18602422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/rSL4MLwV1X",
      "expanded_url" : "http:\/\/grieve-smith.com\/blog\/2014\/01\/speech-role-models\/",
      "display_url" : "grieve-smith.com\/blog\/2014\/01\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426248515313238017",
  "text" : "RT @grvsmth: New post: My experience using speech role models to teach English as a Second Language. http:\/\/t.co\/rSL4MLwV1X @muranava",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mura Nava",
        "screen_name" : "muranava",
        "indices" : [ 111, 120 ],
        "id_str" : "18602422",
        "id" : 18602422
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/rSL4MLwV1X",
        "expanded_url" : "http:\/\/grieve-smith.com\/blog\/2014\/01\/speech-role-models\/",
        "display_url" : "grieve-smith.com\/blog\/2014\/01\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "426221012272025600",
    "text" : "New post: My experience using speech role models to teach English as a Second Language. http:\/\/t.co\/rSL4MLwV1X @muranava",
    "id" : 426221012272025600,
    "created_at" : "2014-01-23 05:13:02 +0000",
    "user" : {
      "name" : "Angus B Grieve-Smith",
      "screen_name" : "grvsmth",
      "protected" : false,
      "id_str" : "22381639",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/94827231\/portrait_normal.png",
      "id" : 22381639,
      "verified" : false
    }
  },
  "id" : 426248515313238017,
  "created_at" : "2014-01-23 07:02:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 0, 14 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/99EFUlxp4V",
      "expanded_url" : "http:\/\/zeega.com\/161406",
      "display_url" : "zeega.com\/161406"
    } ]
  },
  "in_reply_to_status_id_str" : "426084469238296576",
  "geo" : { },
  "id_str" : "426105295819919360",
  "in_reply_to_user_id" : 25388528,
  "text" : "@audreywatters Eggsbox $3.60 for education http:\/\/t.co\/99EFUlxp4V",
  "id" : 426105295819919360,
  "in_reply_to_status_id" : 426084469238296576,
  "created_at" : "2014-01-22 21:33:13 +0000",
  "in_reply_to_screen_name" : "audreywatters",
  "in_reply_to_user_id_str" : "25388528",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "indices" : [ 0, 11 ],
      "id_str" : "152051625",
      "id" : 152051625
    }, {
      "name" : "Oliver Mason",
      "screen_name" : "ojmason",
      "indices" : [ 12, 20 ],
      "id_str" : "19781877",
      "id" : 19781877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426073769862778880",
  "geo" : { },
  "id_str" : "426076102130294784",
  "in_reply_to_user_id" : 152051625,
  "text" : "@heatherfro @ojmason i think byu is limited by resolution so if u have high res mobile screen may work?",
  "id" : 426076102130294784,
  "in_reply_to_status_id" : 426073769862778880,
  "created_at" : "2014-01-22 19:37:13 +0000",
  "in_reply_to_screen_name" : "heatherfro",
  "in_reply_to_user_id_str" : "152051625",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "indices" : [ 0, 11 ],
      "id_str" : "152051625",
      "id" : 152051625
    }, {
      "name" : "Oliver Mason",
      "screen_name" : "ojmason",
      "indices" : [ 12, 20 ],
      "id_str" : "19781877",
      "id" : 19781877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426073769862778880",
  "geo" : { },
  "id_str" : "426074992661372928",
  "in_reply_to_user_id" : 152051625,
  "text" : "@heatherfro @ojmason lextutor concordancer works great on lowend android through browser",
  "id" : 426074992661372928,
  "in_reply_to_status_id" : 426073769862778880,
  "created_at" : "2014-01-22 19:32:49 +0000",
  "in_reply_to_screen_name" : "heatherfro",
  "in_reply_to_user_id_str" : "152051625",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 38, 54 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/50OuzNqjG6",
      "expanded_url" : "http:\/\/wp.me\/p3YgLA-1q",
      "display_url" : "wp.me\/p3YgLA-1q"
    } ]
  },
  "geo" : { },
  "id_str" : "426060779515682816",
  "text" : "My Mindset http:\/\/t.co\/50OuzNqjG6 via @wordpressdotcom",
  "id" : 426060779515682816,
  "created_at" : "2014-01-22 18:36:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 3, 17 ],
      "id_str" : "25388528",
      "id" : 25388528
    }, {
      "name" : "Will Richardson",
      "screen_name" : "willrich45",
      "indices" : [ 41, 52 ],
      "id_str" : "1349941",
      "id" : 1349941
    }, {
      "name" : "Bruce Dixon",
      "screen_name" : "bruceadixon",
      "indices" : [ 59, 71 ],
      "id_str" : "9622952",
      "id" : 9622952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/odqRL87rRU",
      "expanded_url" : "http:\/\/modernlearners.com",
      "display_url" : "modernlearners.com"
    }, {
      "indices" : [ 143, 144 ],
      "url" : "http:\/\/t.co\/c41aOquq5Q",
      "expanded_url" : "http:\/\/audreywatters.com\/2014\/01\/21\/educating-modern-learners-announcement\/",
      "display_url" : "audreywatters.com\/2014\/01\/21\/edu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "425721612131123200",
  "text" : "RT @audreywatters: My latest project (w\/ @willrich45 &amp; @bruceadixon): Educating Modern Learners http:\/\/t.co\/odqRL87rRU. More info here: htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Will Richardson",
        "screen_name" : "willrich45",
        "indices" : [ 22, 33 ],
        "id_str" : "1349941",
        "id" : 1349941
      }, {
        "name" : "Bruce Dixon",
        "screen_name" : "bruceadixon",
        "indices" : [ 40, 52 ],
        "id_str" : "9622952",
        "id" : 9622952
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/odqRL87rRU",
        "expanded_url" : "http:\/\/modernlearners.com",
        "display_url" : "modernlearners.com"
      }, {
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/c41aOquq5Q",
        "expanded_url" : "http:\/\/audreywatters.com\/2014\/01\/21\/educating-modern-learners-announcement\/",
        "display_url" : "audreywatters.com\/2014\/01\/21\/edu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "425713028466626560",
    "text" : "My latest project (w\/ @willrich45 &amp; @bruceadixon): Educating Modern Learners http:\/\/t.co\/odqRL87rRU. More info here: http:\/\/t.co\/c41aOquq5Q",
    "id" : 425713028466626560,
    "created_at" : "2014-01-21 19:34:30 +0000",
    "user" : {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "protected" : false,
      "id_str" : "25388528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711668009723498496\/pauFZsdv_normal.jpg",
      "id" : 25388528,
      "verified" : false
    }
  },
  "id" : 425721612131123200,
  "created_at" : "2014-01-21 20:08:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "indices" : [ 3, 14 ],
      "id_str" : "152051625",
      "id" : 152051625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/X3bHSerER7",
      "expanded_url" : "http:\/\/nobrocomputing.tumblr.com",
      "display_url" : "nobrocomputing.tumblr.com"
    } ]
  },
  "geo" : { },
  "id_str" : "425721088530980864",
  "text" : "RT @heatherfro: bookmarking forever http:\/\/t.co\/X3bHSerER7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 20, 42 ],
        "url" : "http:\/\/t.co\/X3bHSerER7",
        "expanded_url" : "http:\/\/nobrocomputing.tumblr.com",
        "display_url" : "nobrocomputing.tumblr.com"
      } ]
    },
    "geo" : { },
    "id_str" : "425713781402910720",
    "text" : "bookmarking forever http:\/\/t.co\/X3bHSerER7",
    "id" : 425713781402910720,
    "created_at" : "2014-01-21 19:37:29 +0000",
    "user" : {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "protected" : false,
      "id_str" : "152051625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/688767277022494720\/KMrzOBc1_normal.jpg",
      "id" : 152051625,
      "verified" : false
    }
  },
  "id" : 425721088530980864,
  "created_at" : "2014-01-21 20:06:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Willingham",
      "screen_name" : "DTWillingham",
      "indices" : [ 3, 16 ],
      "id_str" : "84619537",
      "id" : 84619537
    }, {
      "name" : "Reed Gillespie",
      "screen_name" : "rggillespie",
      "indices" : [ 31, 43 ],
      "id_str" : "66528500",
      "id" : 66528500
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/2SjcfTZoMP",
      "expanded_url" : "http:\/\/goo.gl\/zw14lo",
      "display_url" : "goo.gl\/zw14lo"
    }, {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/RTeiwdFmvj",
      "expanded_url" : "http:\/\/goo.gl\/FeOUz3",
      "display_url" : "goo.gl\/FeOUz3"
    } ]
  },
  "geo" : { },
  "id_str" : "425639319983112192",
  "text" : "RT @DTWillingham: Nicely done! @rggillespie  two blog posts about pitfalls of learning styles http:\/\/t.co\/2SjcfTZoMP  http:\/\/t.co\/RTeiwdFmvj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Reed Gillespie",
        "screen_name" : "rggillespie",
        "indices" : [ 13, 25 ],
        "id_str" : "66528500",
        "id" : 66528500
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/2SjcfTZoMP",
        "expanded_url" : "http:\/\/goo.gl\/zw14lo",
        "display_url" : "goo.gl\/zw14lo"
      }, {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/RTeiwdFmvj",
        "expanded_url" : "http:\/\/goo.gl\/FeOUz3",
        "display_url" : "goo.gl\/FeOUz3"
      } ]
    },
    "geo" : { },
    "id_str" : "425232252235051008",
    "text" : "Nicely done! @rggillespie  two blog posts about pitfalls of learning styles http:\/\/t.co\/2SjcfTZoMP  http:\/\/t.co\/RTeiwdFmvj",
    "id" : 425232252235051008,
    "created_at" : "2014-01-20 11:44:04 +0000",
    "user" : {
      "name" : "Daniel Willingham",
      "screen_name" : "DTWillingham",
      "protected" : false,
      "id_str" : "84619537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1815678310\/Daniel_Willingham_Color_lowres_normal.JPG",
      "id" : 84619537,
      "verified" : false
    }
  },
  "id" : 425639319983112192,
  "created_at" : "2014-01-21 14:41:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EFF",
      "screen_name" : "EFF",
      "indices" : [ 119, 123 ],
      "id_str" : "4816",
      "id" : 4816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/VJDrEbJT7q",
      "expanded_url" : "https:\/\/www.eff.org\/deeplinks\/2014\/01\/newly-passed-appropriations-bill-makes-even-more-publicly-funded-research-available-online",
      "display_url" : "eff.org\/deeplinks\/2014\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "425607322589605888",
  "text" : "Newly Passed Appropriations Bill Makes Even More Publicly Funded Research Available Online https:\/\/t.co\/VJDrEbJT7q via @EFF",
  "id" : 425607322589605888,
  "created_at" : "2014-01-21 12:34:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "indices" : [ 3, 18 ],
      "id_str" : "27716419",
      "id" : 27716419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/LGdNDCeauf",
      "expanded_url" : "http:\/\/bit.ly\/1jtef9h",
      "display_url" : "bit.ly\/1jtef9h"
    } ]
  },
  "geo" : { },
  "id_str" : "425601162000490497",
  "text" : "RT @CraigMurrayOrg: Syria and Diplomacy: The problem with the Geneva Communique from the first Geneva round on Syria is that the g... http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/LGdNDCeauf",
        "expanded_url" : "http:\/\/bit.ly\/1jtef9h",
        "display_url" : "bit.ly\/1jtef9h"
      } ]
    },
    "geo" : { },
    "id_str" : "425599844854411265",
    "text" : "Syria and Diplomacy: The problem with the Geneva Communique from the first Geneva round on Syria is that the g... http:\/\/t.co\/LGdNDCeauf",
    "id" : 425599844854411265,
    "created_at" : "2014-01-21 12:04:44 +0000",
    "user" : {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "protected" : false,
      "id_str" : "27716419",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1388436826\/cm_normal.jpg",
      "id" : 27716419,
      "verified" : false
    }
  },
  "id" : 425601162000490497,
  "created_at" : "2014-01-21 12:09:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/H1c2VBOK0u",
      "expanded_url" : "http:\/\/www.jonathan-cook.net\/blog\/2014-01-21\/our-political-passivity-was-engineered\/",
      "display_url" : "jonathan-cook.net\/blog\/2014-01-2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "425598361090396160",
  "text" : "RT @johnwhilley: Great comment piece (on Monbiot piece) from Jonathan Cook:  Our political passivity was engineered http:\/\/t.co\/H1c2VBOK0u",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/H1c2VBOK0u",
        "expanded_url" : "http:\/\/www.jonathan-cook.net\/blog\/2014-01-21\/our-political-passivity-was-engineered\/",
        "display_url" : "jonathan-cook.net\/blog\/2014-01-2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "425597849452027905",
    "text" : "Great comment piece (on Monbiot piece) from Jonathan Cook:  Our political passivity was engineered http:\/\/t.co\/H1c2VBOK0u",
    "id" : 425597849452027905,
    "created_at" : "2014-01-21 11:56:49 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 425598361090396160,
  "created_at" : "2014-01-21 11:58:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MarisaConstantinides",
      "screen_name" : "Marisa_C",
      "indices" : [ 3, 12 ],
      "id_str" : "18272500",
      "id" : 18272500
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 14, 22 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/EiL1wGkHdZ",
      "expanded_url" : "http:\/\/eltchat.org\/wordpress\/general-announcements\/eltchat-in-2014\/#comments",
      "display_url" : "eltchat.org\/wordpress\/gene\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "425595146118631424",
  "text" : "RT @Marisa_C: #eltchat Remeber to vote for tomorrow's topics - a very interesting range of topics from gadgets to ESP http:\/\/t.co\/EiL1wGkHd\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twubs.com\/\" rel=\"nofollow\"\u003ETwubs\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "eltchat",
        "indices" : [ 0, 8 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/EiL1wGkHdZ",
        "expanded_url" : "http:\/\/eltchat.org\/wordpress\/general-announcements\/eltchat-in-2014\/#comments",
        "display_url" : "eltchat.org\/wordpress\/gene\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "425594242233536512",
    "text" : "#eltchat Remeber to vote for tomorrow's topics - a very interesting range of topics from gadgets to ESP http:\/\/t.co\/EiL1wGkHdZ Pls RT",
    "id" : 425594242233536512,
    "created_at" : "2014-01-21 11:42:29 +0000",
    "user" : {
      "name" : "MarisaConstantinides",
      "screen_name" : "Marisa_C",
      "protected" : false,
      "id_str" : "18272500",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/551128180497457153\/DRrY3cNw_normal.jpeg",
      "id" : 18272500,
      "verified" : false
    }
  },
  "id" : 425595146118631424,
  "created_at" : "2014-01-21 11:46:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FEED THE TEACHER",
      "screen_name" : "feedtheteacher",
      "indices" : [ 3, 18 ],
      "id_str" : "58839737",
      "id" : 58839737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/U9HuFKF0kc",
      "expanded_url" : "http:\/\/learning-reimagined.com\/noam-chomsky-on-technology-learning\/",
      "display_url" : "learning-reimagined.com\/noam-chomsky-o\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "425589129108553728",
  "text" : "RT @feedtheteacher: http:\/\/t.co\/U9HuFKF0kc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/U9HuFKF0kc",
        "expanded_url" : "http:\/\/learning-reimagined.com\/noam-chomsky-on-technology-learning\/",
        "display_url" : "learning-reimagined.com\/noam-chomsky-o\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "425588309792784384",
    "text" : "http:\/\/t.co\/U9HuFKF0kc",
    "id" : 425588309792784384,
    "created_at" : "2014-01-21 11:18:54 +0000",
    "user" : {
      "name" : "FEED THE TEACHER",
      "screen_name" : "feedtheteacher",
      "protected" : false,
      "id_str" : "58839737",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/755722190717190144\/86hxGYCb_normal.jpg",
      "id" : 58839737,
      "verified" : false
    }
  },
  "id" : 425589129108553728,
  "created_at" : "2014-01-21 11:22:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FutureLearn",
      "screen_name" : "FutureLearn",
      "indices" : [ 3, 15 ],
      "id_str" : "999095640",
      "id" : 999095640
    }, {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "indices" : [ 22, 34 ],
      "id_str" : "849729062",
      "id" : 849729062
    }, {
      "name" : "Lancaster University",
      "screen_name" : "LancasterUni",
      "indices" : [ 35, 48 ],
      "id_str" : "25521930",
      "id" : 25521930
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 102, 113 ]
    }, {
      "text" : "freeonlinecourse",
      "indices" : [ 114, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 143, 144 ],
      "url" : "http:\/\/t.co\/TwMlAAbl9Q",
      "expanded_url" : "http:\/\/bit.ly\/1hIrQsR",
      "display_url" : "bit.ly\/1hIrQsR"
    } ]
  },
  "geo" : { },
  "id_str" : "425587532982927360",
  "text" : "RT @FutureLearn: Prof @TonyMcEnery @LancasterUni talks about the uses &amp; abuses of language before #corpusmooc #freeonlinecourse starts http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tony McEnery",
        "screen_name" : "TonyMcEnery",
        "indices" : [ 5, 17 ],
        "id_str" : "849729062",
        "id" : 849729062
      }, {
        "name" : "Lancaster University",
        "screen_name" : "LancasterUni",
        "indices" : [ 18, 31 ],
        "id_str" : "25521930",
        "id" : 25521930
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpusmooc",
        "indices" : [ 85, 96 ]
      }, {
        "text" : "freeonlinecourse",
        "indices" : [ 97, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/TwMlAAbl9Q",
        "expanded_url" : "http:\/\/bit.ly\/1hIrQsR",
        "display_url" : "bit.ly\/1hIrQsR"
      } ]
    },
    "geo" : { },
    "id_str" : "425585933459550209",
    "text" : "Prof @TonyMcEnery @LancasterUni talks about the uses &amp; abuses of language before #corpusmooc #freeonlinecourse starts http:\/\/t.co\/TwMlAAbl9Q",
    "id" : 425585933459550209,
    "created_at" : "2014-01-21 11:09:28 +0000",
    "user" : {
      "name" : "FutureLearn",
      "screen_name" : "FutureLearn",
      "protected" : false,
      "id_str" : "999095640",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458916616395173888\/7OPlOvoF_normal.png",
      "id" : 999095640,
      "verified" : false
    }
  },
  "id" : 425587532982927360,
  "created_at" : "2014-01-21 11:15:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Akira Murakami",
      "screen_name" : "mrkm_a",
      "indices" : [ 3, 10 ],
      "id_str" : "116922669",
      "id" : 116922669
    }, {
      "name" : "acepor",
      "screen_name" : "acepor",
      "indices" : [ 12, 19 ],
      "id_str" : "19571913",
      "id" : 19571913
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 124, 140 ],
      "url" : "http:\/\/t.co\/FLvJNbWQE5",
      "expanded_url" : "http:\/\/drewconway.com\/zia\/2013\/3\/26\/building-a-better-word-cloud",
      "display_url" : "drewconway.com\/zia\/2013\/3\/26\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "425585811896430592",
  "text" : "RT @mrkm_a: @acepor Thanks. I completely agree with the view expressed here: The general word cloud is not very meaningful.\nhttp:\/\/t.co\/FLv\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "acepor",
        "screen_name" : "acepor",
        "indices" : [ 0, 7 ],
        "id_str" : "19571913",
        "id" : 19571913
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/FLvJNbWQE5",
        "expanded_url" : "http:\/\/drewconway.com\/zia\/2013\/3\/26\/building-a-better-word-cloud",
        "display_url" : "drewconway.com\/zia\/2013\/3\/26\/\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "425547932767911936",
    "geo" : { },
    "id_str" : "425557189441232896",
    "in_reply_to_user_id" : 19571913,
    "text" : "@acepor Thanks. I completely agree with the view expressed here: The general word cloud is not very meaningful.\nhttp:\/\/t.co\/FLvJNbWQE5",
    "id" : 425557189441232896,
    "in_reply_to_status_id" : 425547932767911936,
    "created_at" : "2014-01-21 09:15:15 +0000",
    "in_reply_to_screen_name" : "acepor",
    "in_reply_to_user_id_str" : "19571913",
    "user" : {
      "name" : "Akira Murakami",
      "screen_name" : "mrkm_a",
      "protected" : false,
      "id_str" : "116922669",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/491819353784860672\/LqdQ1Sye_normal.jpeg",
      "id" : 116922669,
      "verified" : false
    }
  },
  "id" : 425585811896430592,
  "created_at" : "2014-01-21 11:08:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Akira Murakami",
      "screen_name" : "mrkm_a",
      "indices" : [ 3, 10 ],
      "id_str" : "116922669",
      "id" : 116922669
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/nvECQFbPF1",
      "expanded_url" : "http:\/\/onlinelibrary.wiley.com\/doi\/10.1111\/tops.12078\/full",
      "display_url" : "onlinelibrary.wiley.com\/doi\/10.1111\/to\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "425403801659793408",
  "text" : "RT @mrkm_a: Baayen\u3089\u306E\u8AD6\u6587\u3002Ramscar et al. (2014). The Myth of Cognitive Decline: Non-Linear Dynamics of Lifelong Learning\nhttp:\/\/t.co\/nvECQFbPF1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/nvECQFbPF1",
        "expanded_url" : "http:\/\/onlinelibrary.wiley.com\/doi\/10.1111\/tops.12078\/full",
        "display_url" : "onlinelibrary.wiley.com\/doi\/10.1111\/to\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "425331321980719104",
    "text" : "Baayen\u3089\u306E\u8AD6\u6587\u3002Ramscar et al. (2014). The Myth of Cognitive Decline: Non-Linear Dynamics of Lifelong Learning\nhttp:\/\/t.co\/nvECQFbPF1",
    "id" : 425331321980719104,
    "created_at" : "2014-01-20 18:17:44 +0000",
    "user" : {
      "name" : "Akira Murakami",
      "screen_name" : "mrkm_a",
      "protected" : false,
      "id_str" : "116922669",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/491819353784860672\/LqdQ1Sye_normal.jpeg",
      "id" : 116922669,
      "verified" : false
    }
  },
  "id" : 425403801659793408,
  "created_at" : "2014-01-20 23:05:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 76, 92 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/zJTFp64fZn",
      "expanded_url" : "http:\/\/wp.me\/p2CPYN-a6",
      "display_url" : "wp.me\/p2CPYN-a6"
    } ]
  },
  "geo" : { },
  "id_str" : "425399606235508736",
  "text" : "The Libyan government is bombing its own people. http:\/\/t.co\/zJTFp64fZn via @wordpressdotcom",
  "id" : 425399606235508736,
  "created_at" : "2014-01-20 22:49:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Forensic Linguistics",
      "screen_name" : "FORGE_LU",
      "indices" : [ 0, 9 ],
      "id_str" : "2211139201",
      "id" : 2211139201
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "425386393393987584",
  "geo" : { },
  "id_str" : "425390633449050112",
  "in_reply_to_user_id" : 2211139201,
  "text" : "@FORGE_LU aka move along nothing to see here",
  "id" : 425390633449050112,
  "in_reply_to_status_id" : 425386393393987584,
  "created_at" : "2014-01-20 22:13:25 +0000",
  "in_reply_to_screen_name" : "FORGE_LU",
  "in_reply_to_user_id_str" : "2211139201",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Botanical Linguist",
      "screen_name" : "GrowMyEnglish",
      "indices" : [ 0, 14 ],
      "id_str" : "21865567",
      "id" : 21865567
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 111, 122 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "425344645585858560",
  "geo" : { },
  "id_str" : "425351512856858624",
  "in_reply_to_user_id" : 21865567,
  "text" : "@GrowMyEnglish great :) if u r on G+ why not join CL community to discuss language teaching\/learning issues of #corpusmooc :)",
  "id" : 425351512856858624,
  "in_reply_to_status_id" : 425344645585858560,
  "created_at" : "2014-01-20 19:37:57 +0000",
  "in_reply_to_screen_name" : "GrowMyEnglish",
  "in_reply_to_user_id_str" : "21865567",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Botanical Linguist",
      "screen_name" : "GrowMyEnglish",
      "indices" : [ 26, 40 ],
      "id_str" : "21865567",
      "id" : 21865567
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/wk81pNVFqG",
      "expanded_url" : "https:\/\/plus.google.com\/104940199413423400545\/posts\/cF1urb5nxFz",
      "display_url" : "plus.google.com\/10494019941342\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "425254514531123202",
  "geo" : { },
  "id_str" : "425306290705821696",
  "in_reply_to_user_id" : 21865567,
  "text" : "hi, you may be interested @GrowMyEnglish in this post https:\/\/t.co\/wk81pNVFqG",
  "id" : 425306290705821696,
  "in_reply_to_status_id" : 425254514531123202,
  "created_at" : "2014-01-20 16:38:16 +0000",
  "in_reply_to_screen_name" : "GrowMyEnglish",
  "in_reply_to_user_id_str" : "21865567",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 60, 69 ],
      "id_str" : "134211317",
      "id" : 134211317
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/XZXnqJGrEe",
      "expanded_url" : "http:\/\/wp.me\/p3Wm0j-bp",
      "display_url" : "wp.me\/p3Wm0j-bp"
    } ]
  },
  "geo" : { },
  "id_str" : "425292395513532416",
  "text" : "IF sentences...and other animals http:\/\/t.co\/XZXnqJGrEe via @josipa74",
  "id" : 425292395513532416,
  "created_at" : "2014-01-20 15:43:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Kern\u24C4h\u24B6n",
      "screen_name" : "dkernohan",
      "indices" : [ 3, 13 ],
      "id_str" : "12219232",
      "id" : 12219232
    }, {
      "name" : "mariekeguy",
      "screen_name" : "mariekeguy",
      "indices" : [ 28, 39 ],
      "id_str" : "14322554",
      "id" : 14322554
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ukoer",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/AF9XKmazcW",
      "expanded_url" : "http:\/\/education.okfn.org\/speakerthon-sharing-voice-samples\/",
      "display_url" : "education.okfn.org\/speakerthon-sh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "425215167937654784",
  "text" : "RT @dkernohan: Nice post by @mariekeguy about the BBC Speakerthon project - sharing voices from BBCr4 on wikipedia: http:\/\/t.co\/AF9XKmazcW \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/janetter.net\/\" rel=\"nofollow\"\u003EJanetter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "mariekeguy",
        "screen_name" : "mariekeguy",
        "indices" : [ 13, 24 ],
        "id_str" : "14322554",
        "id" : 14322554
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ukoer",
        "indices" : [ 124, 130 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/AF9XKmazcW",
        "expanded_url" : "http:\/\/education.okfn.org\/speakerthon-sharing-voice-samples\/",
        "display_url" : "education.okfn.org\/speakerthon-sh\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "425201253128609792",
    "text" : "Nice post by @mariekeguy about the BBC Speakerthon project - sharing voices from BBCr4 on wikipedia: http:\/\/t.co\/AF9XKmazcW #ukoer",
    "id" : 425201253128609792,
    "created_at" : "2014-01-20 09:40:53 +0000",
    "user" : {
      "name" : "David Kern\u24C4h\u24B6n",
      "screen_name" : "dkernohan",
      "protected" : false,
      "id_str" : "12219232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/757702202437804032\/4Xrm7IIe_normal.jpg",
      "id" : 12219232,
      "verified" : false
    }
  },
  "id" : 425215167937654784,
  "created_at" : "2014-01-20 10:36:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Botanical Linguist",
      "screen_name" : "GrowMyEnglish",
      "indices" : [ 0, 14 ],
      "id_str" : "21865567",
      "id" : 21865567
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "424880363203080192",
  "geo" : { },
  "id_str" : "425206335060201472",
  "in_reply_to_user_id" : 21865567,
  "text" : "@GrowMyEnglish thks have u rd? Pointing Out Frequent Phrasal Verbs A Corpus-Based Analysis http:\/\/203.72.145.166\/tesol\/tqd_2008\/VOL_41_2.pdf",
  "id" : 425206335060201472,
  "in_reply_to_status_id" : 424880363203080192,
  "created_at" : "2014-01-20 10:01:04 +0000",
  "in_reply_to_screen_name" : "GrowMyEnglish",
  "in_reply_to_user_id_str" : "21865567",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "indices" : [ 3, 14 ],
      "id_str" : "152051625",
      "id" : 152051625
    }, {
      "name" : "Evgeny Morozov",
      "screen_name" : "evgenymorozov",
      "indices" : [ 52, 66 ],
      "id_str" : "30331417",
      "id" : 30331417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/TODlKvkhpD",
      "expanded_url" : "http:\/\/nyr.kr\/1aAJrNL",
      "display_url" : "nyr.kr\/1aAJrNL"
    } ]
  },
  "geo" : { },
  "id_str" : "424654559068573696",
  "text" : "RT @heatherfro: a critical view of maker culture by @evgenymorozov http:\/\/t.co\/TODlKvkhpD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Evgeny Morozov",
        "screen_name" : "evgenymorozov",
        "indices" : [ 36, 50 ],
        "id_str" : "30331417",
        "id" : 30331417
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 73 ],
        "url" : "http:\/\/t.co\/TODlKvkhpD",
        "expanded_url" : "http:\/\/nyr.kr\/1aAJrNL",
        "display_url" : "nyr.kr\/1aAJrNL"
      } ]
    },
    "geo" : { },
    "id_str" : "424620776143060992",
    "text" : "a critical view of maker culture by @evgenymorozov http:\/\/t.co\/TODlKvkhpD",
    "id" : 424620776143060992,
    "created_at" : "2014-01-18 19:14:16 +0000",
    "user" : {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "protected" : false,
      "id_str" : "152051625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/688767277022494720\/KMrzOBc1_normal.jpg",
      "id" : 152051625,
      "verified" : false
    }
  },
  "id" : 424654559068573696,
  "created_at" : "2014-01-18 21:28:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angus B Grieve-Smith",
      "screen_name" : "grvsmth",
      "indices" : [ 0, 8 ],
      "id_str" : "22381639",
      "id" : 22381639
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "424629371748777984",
  "geo" : { },
  "id_str" : "424648818127151104",
  "in_reply_to_user_id" : 22381639,
  "text" : "@grvsmth any tips to pass on?",
  "id" : 424648818127151104,
  "in_reply_to_status_id" : 424629371748777984,
  "created_at" : "2014-01-18 21:05:42 +0000",
  "in_reply_to_screen_name" : "grvsmth",
  "in_reply_to_user_id_str" : "22381639",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 5, 16 ]
    } ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/vhyWLfFFDa",
      "expanded_url" : "https:\/\/elt.makes.org\/popcorn\/1p5d",
      "display_url" : "elt.makes.org\/popcorn\/1p5d"
    } ]
  },
  "geo" : { },
  "id_str" : "424614169959075840",
  "text" : "some #corpusmooc fun https:\/\/t.co\/vhyWLfFFDa",
  "id" : 424614169959075840,
  "created_at" : "2014-01-18 18:48:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JP Vergne",
      "screen_name" : "PirateOrg",
      "indices" : [ 3, 13 ],
      "id_str" : "605856131",
      "id" : 605856131
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/PirateOrg\/status\/422100900144889856\/photo\/1",
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/OMoEe3BZ0E",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BduaiEUCQAAhnAr.jpg",
      "id_str" : "422100900153278464",
      "id" : 422100900153278464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BduaiEUCQAAhnAr.jpg",
      "sizes" : [ {
        "h" : 245,
        "resize" : "fit",
        "w" : 594
      }, {
        "h" : 245,
        "resize" : "fit",
        "w" : 594
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 245,
        "resize" : "fit",
        "w" : 594
      }, {
        "h" : 140,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/OMoEe3BZ0E"
    } ],
    "hashtags" : [ {
      "text" : "tech",
      "indices" : [ 35, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "424513060683124736",
  "text" : "RT @PirateOrg: GOT IT: The perfect #tech talk. Just fill in the blanks. http:\/\/t.co\/OMoEe3BZ0E",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/PirateOrg\/status\/422100900144889856\/photo\/1",
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/OMoEe3BZ0E",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BduaiEUCQAAhnAr.jpg",
        "id_str" : "422100900153278464",
        "id" : 422100900153278464,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BduaiEUCQAAhnAr.jpg",
        "sizes" : [ {
          "h" : 245,
          "resize" : "fit",
          "w" : 594
        }, {
          "h" : 245,
          "resize" : "fit",
          "w" : 594
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 245,
          "resize" : "fit",
          "w" : 594
        }, {
          "h" : 140,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/OMoEe3BZ0E"
      } ],
      "hashtags" : [ {
        "text" : "tech",
        "indices" : [ 20, 25 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "422100900144889856",
    "text" : "GOT IT: The perfect #tech talk. Just fill in the blanks. http:\/\/t.co\/OMoEe3BZ0E",
    "id" : 422100900144889856,
    "created_at" : "2014-01-11 20:21:11 +0000",
    "user" : {
      "name" : "JP Vergne",
      "screen_name" : "PirateOrg",
      "protected" : false,
      "id_str" : "605856131",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/647020803503034368\/FHStVVF7_normal.jpg",
      "id" : 605856131,
      "verified" : false
    }
  },
  "id" : 424513060683124736,
  "created_at" : "2014-01-18 12:06:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JP Vergne",
      "screen_name" : "PirateOrg",
      "indices" : [ 3, 13 ],
      "id_str" : "605856131",
      "id" : 605856131
    }, {
      "name" : "Evgeny Morozov",
      "screen_name" : "evgenymorozov",
      "indices" : [ 120, 134 ],
      "id_str" : "30331417",
      "id" : 30331417
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/PirateOrg\/status\/424257688390758400\/photo\/1",
      "indices" : [ 142, 143 ],
      "url" : "http:\/\/t.co\/GONWjkgY0J",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BeNEHqpCcAEIMD9.png",
      "id_str" : "424257688399147009",
      "id" : 424257688399147009,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BeNEHqpCcAEIMD9.png",
      "sizes" : [ {
        "h" : 393,
        "resize" : "fit",
        "w" : 726
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 393,
        "resize" : "fit",
        "w" : 726
      }, {
        "h" : 184,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 325,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/GONWjkgY0J"
    } ],
    "hashtags" : [ {
      "text" : "wearable",
      "indices" : [ 37, 46 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/zQJQTSi5Um",
      "expanded_url" : "http:\/\/whatthefuckismywearablestrategy.com",
      "display_url" : "whatthefuckismywearablestrategy.com"
    } ]
  },
  "geo" : { },
  "id_str" : "424511682321596416",
  "text" : "RT @PirateOrg: What, you dont have a #wearable strategy yet? Its time to shift paradigms &gt; http:\/\/t.co\/zQJQTSi5Um cc @evgenymorozov http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Evgeny Morozov",
        "screen_name" : "evgenymorozov",
        "indices" : [ 105, 119 ],
        "id_str" : "30331417",
        "id" : 30331417
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/PirateOrg\/status\/424257688390758400\/photo\/1",
        "indices" : [ 120, 142 ],
        "url" : "http:\/\/t.co\/GONWjkgY0J",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BeNEHqpCcAEIMD9.png",
        "id_str" : "424257688399147009",
        "id" : 424257688399147009,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BeNEHqpCcAEIMD9.png",
        "sizes" : [ {
          "h" : 393,
          "resize" : "fit",
          "w" : 726
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 393,
          "resize" : "fit",
          "w" : 726
        }, {
          "h" : 184,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 325,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/GONWjkgY0J"
      } ],
      "hashtags" : [ {
        "text" : "wearable",
        "indices" : [ 22, 31 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/zQJQTSi5Um",
        "expanded_url" : "http:\/\/whatthefuckismywearablestrategy.com",
        "display_url" : "whatthefuckismywearablestrategy.com"
      } ]
    },
    "geo" : { },
    "id_str" : "424257688390758400",
    "text" : "What, you dont have a #wearable strategy yet? Its time to shift paradigms &gt; http:\/\/t.co\/zQJQTSi5Um cc @evgenymorozov http:\/\/t.co\/GONWjkgY0J",
    "id" : 424257688390758400,
    "created_at" : "2014-01-17 19:11:30 +0000",
    "user" : {
      "name" : "JP Vergne",
      "screen_name" : "PirateOrg",
      "protected" : false,
      "id_str" : "605856131",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/647020803503034368\/FHStVVF7_normal.jpg",
      "id" : 605856131,
      "verified" : false
    }
  },
  "id" : 424511682321596416,
  "created_at" : "2014-01-18 12:00:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/P2AUaBoL4P",
      "expanded_url" : "http:\/\/www.jonathan-cook.net\/blog\/2014-01-18\/both-obama-and-guardian-prettify-the-ugly\/",
      "display_url" : "jonathan-cook.net\/blog\/2014-01-1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424508424949628930",
  "text" : "RT @johnwhilley: Great double-hit from Jonathan Cook: Both Obama and Guardian prettify the ugly http:\/\/t.co\/P2AUaBoL4P",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/P2AUaBoL4P",
        "expanded_url" : "http:\/\/www.jonathan-cook.net\/blog\/2014-01-18\/both-obama-and-guardian-prettify-the-ugly\/",
        "display_url" : "jonathan-cook.net\/blog\/2014-01-1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "424500064514347009",
    "text" : "Great double-hit from Jonathan Cook: Both Obama and Guardian prettify the ugly http:\/\/t.co\/P2AUaBoL4P",
    "id" : 424500064514347009,
    "created_at" : "2014-01-18 11:14:36 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 424508424949628930,
  "created_at" : "2014-01-18 11:47:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 59, 67 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/dRcsMkbOMU",
      "expanded_url" : "http:\/\/youtu.be\/uFQfylQ2Jgg",
      "display_url" : "youtu.be\/uFQfylQ2Jgg"
    } ]
  },
  "geo" : { },
  "id_str" : "424494187212308480",
  "text" : "People with no kids don't know: http:\/\/t.co\/dRcsMkbOMU via @youtube",
  "id" : 424494187212308480,
  "created_at" : "2014-01-18 10:51:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angus B Grieve-Smith",
      "screen_name" : "grvsmth",
      "indices" : [ 0, 8 ],
      "id_str" : "22381639",
      "id" : 22381639
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "424341975219716097",
  "geo" : { },
  "id_str" : "424475549558255616",
  "in_reply_to_user_id" : 22381639,
  "text" : "@grvsmth am reading paper now, how did it go in your class?",
  "id" : 424475549558255616,
  "in_reply_to_status_id" : 424341975219716097,
  "created_at" : "2014-01-18 09:37:12 +0000",
  "in_reply_to_screen_name" : "grvsmth",
  "in_reply_to_user_id_str" : "22381639",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/x4NS3we2pC",
      "expanded_url" : "http:\/\/bit.ly\/19vXARu",
      "display_url" : "bit.ly\/19vXARu"
    } ]
  },
  "geo" : { },
  "id_str" : "424327444875579393",
  "text" : "Grammar and falling over in the bar http:\/\/t.co\/x4NS3we2pC",
  "id" : 424327444875579393,
  "created_at" : "2014-01-17 23:48:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 74, 90 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/gD0cfe7pDE",
      "expanded_url" : "http:\/\/wp.me\/p2ZJCG-ax",
      "display_url" : "wp.me\/p2ZJCG-ax"
    } ]
  },
  "geo" : { },
  "id_str" : "424315413434884096",
  "text" : "'Cloning' \u2013 using nonnative speakers as models http:\/\/t.co\/gD0cfe7pDE via @wordpressdotcom",
  "id" : 424315413434884096,
  "created_at" : "2014-01-17 23:00:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evgeny Morozov",
      "screen_name" : "evgenymorozov",
      "indices" : [ 3, 17 ],
      "id_str" : "30331417",
      "id" : 30331417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/Gr8s9djUom",
      "expanded_url" : "http:\/\/www.internetactu.net\/agenda\/",
      "display_url" : "internetactu.net\/agenda\/"
    } ]
  },
  "geo" : { },
  "id_str" : "424240923586088960",
  "text" : "RT @evgenymorozov: I am giving two talks in Paris next week. Details: http:\/\/t.co\/Gr8s9djUom",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 73 ],
        "url" : "http:\/\/t.co\/Gr8s9djUom",
        "expanded_url" : "http:\/\/www.internetactu.net\/agenda\/",
        "display_url" : "internetactu.net\/agenda\/"
      } ]
    },
    "geo" : { },
    "id_str" : "424230216580730880",
    "text" : "I am giving two talks in Paris next week. Details: http:\/\/t.co\/Gr8s9djUom",
    "id" : 424230216580730880,
    "created_at" : "2014-01-17 17:22:20 +0000",
    "user" : {
      "name" : "Evgeny Morozov",
      "screen_name" : "evgenymorozov",
      "protected" : false,
      "id_str" : "30331417",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/640536915477794816\/u9TxNsKI_normal.jpg",
      "id" : 30331417,
      "verified" : false
    }
  },
  "id" : 424240923586088960,
  "created_at" : "2014-01-17 18:04:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpuslinguistics",
      "indices" : [ 60, 78 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 85, 93 ]
    }, {
      "text" : "besig",
      "indices" : [ 94, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/C2ey2D3h1O",
      "expanded_url" : "http:\/\/lexicon.ft.com\/",
      "display_url" : "lexicon.ft.com"
    } ]
  },
  "geo" : { },
  "id_str" : "424220775021678592",
  "text" : "Financial Times Lexicon http:\/\/t.co\/C2ey2D3h1O  HT facebook #corpuslinguistics group #eltchat #besig",
  "id" : 424220775021678592,
  "created_at" : "2014-01-17 16:44:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "K Pitchford",
      "screen_name" : "Ms_Kmp",
      "indices" : [ 0, 7 ],
      "id_str" : "887161314",
      "id" : 887161314
    }, {
      "name" : "Pete Sanderson",
      "screen_name" : "LessonToolbox",
      "indices" : [ 8, 22 ],
      "id_str" : "1239302874",
      "id" : 1239302874
    }, {
      "name" : "Calestous Juma",
      "screen_name" : "calestous",
      "indices" : [ 23, 33 ],
      "id_str" : "33388399",
      "id" : 33388399
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/lOgdJZDsWa",
      "expanded_url" : "http:\/\/www.carbonbrief.org\/blog\/2014\/01\/uk-tops-list-of-world%E2%80%99s-biggest-greenhouse-gas-emitters\/",
      "display_url" : "carbonbrief.org\/blog\/2014\/01\/u\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "424187241750347776",
  "geo" : { },
  "id_str" : "424218775676665857",
  "in_reply_to_user_id" : 887161314,
  "text" : "@Ms_Kmp @LessonToolbox @calestous per person would be even more revealing e.g. http:\/\/t.co\/lOgdJZDsWa",
  "id" : 424218775676665857,
  "in_reply_to_status_id" : 424187241750347776,
  "created_at" : "2014-01-17 16:36:52 +0000",
  "in_reply_to_screen_name" : "Ms_Kmp",
  "in_reply_to_user_id_str" : "887161314",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 3, 14 ],
      "id_str" : "300734173",
      "id" : 300734173
    }, {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 16, 32 ],
      "id_str" : "394053348",
      "id" : 394053348
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 33, 42 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Gemma Lunn",
      "screen_name" : "GemL1",
      "indices" : [ 43, 49 ],
      "id_str" : "486146568",
      "id" : 486146568
    }, {
      "name" : "Ian Cook",
      "screen_name" : "idc74",
      "indices" : [ 50, 56 ],
      "id_str" : "290521216",
      "id" : 290521216
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "everylittlecounts",
      "indices" : [ 137, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/G6CDv2JZAR",
      "expanded_url" : "http:\/\/ilexir.co.uk\/applications\/clc-fce-dataset\/",
      "display_url" : "ilexir.co.uk\/applications\/c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424208590728347648",
  "text" : "RT @lexicoloco: @michaelegriffin @muranava @GemL1 @idc74 r you aware of the free Camb Learner Corpus FCE dataset? http:\/\/t.co\/G6CDv2JZAR #e\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Michael Griffin",
        "screen_name" : "michaelegriffin",
        "indices" : [ 0, 16 ],
        "id_str" : "394053348",
        "id" : 394053348
      }, {
        "name" : "Mura Nava",
        "screen_name" : "muranava",
        "indices" : [ 17, 26 ],
        "id_str" : "18602422",
        "id" : 18602422
      }, {
        "name" : "Gemma Lunn",
        "screen_name" : "GemL1",
        "indices" : [ 27, 33 ],
        "id_str" : "486146568",
        "id" : 486146568
      }, {
        "name" : "Ian Cook",
        "screen_name" : "idc74",
        "indices" : [ 34, 40 ],
        "id_str" : "290521216",
        "id" : 290521216
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "everylittlecounts",
        "indices" : [ 121, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/G6CDv2JZAR",
        "expanded_url" : "http:\/\/ilexir.co.uk\/applications\/clc-fce-dataset\/",
        "display_url" : "ilexir.co.uk\/applications\/c\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "424192386789429248",
    "geo" : { },
    "id_str" : "424200608388628480",
    "in_reply_to_user_id" : 394053348,
    "text" : "@michaelegriffin @muranava @GemL1 @idc74 r you aware of the free Camb Learner Corpus FCE dataset? http:\/\/t.co\/G6CDv2JZAR #everylittlecounts!",
    "id" : 424200608388628480,
    "in_reply_to_status_id" : 424192386789429248,
    "created_at" : "2014-01-17 15:24:40 +0000",
    "in_reply_to_screen_name" : "michaelegriffin",
    "in_reply_to_user_id_str" : "394053348",
    "user" : {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "protected" : false,
      "id_str" : "300734173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2403500097\/3nmx3kjaycyoc7irwe6s_normal.jpeg",
      "id" : 300734173,
      "verified" : false
    }
  },
  "id" : 424208590728347648,
  "created_at" : "2014-01-17 15:56:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    }, {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 12, 28 ],
      "id_str" : "394053348",
      "id" : 394053348
    }, {
      "name" : "Gemma Lunn",
      "screen_name" : "GemL1",
      "indices" : [ 29, 35 ],
      "id_str" : "486146568",
      "id" : 486146568
    }, {
      "name" : "Ian Cook",
      "screen_name" : "idc74",
      "indices" : [ 36, 42 ],
      "id_str" : "290521216",
      "id" : 290521216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "424200608388628480",
  "geo" : { },
  "id_str" : "424204897018343425",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco @michaelegriffin @GemL1 @idc74 i  tweeted that back in oct but not got round to playing with it so thanks for reminder!",
  "id" : 424204897018343425,
  "in_reply_to_status_id" : 424200608388628480,
  "created_at" : "2014-01-17 15:41:43 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    }, {
      "name" : "Gemma Lunn",
      "screen_name" : "GemL1",
      "indices" : [ 12, 18 ],
      "id_str" : "486146568",
      "id" : 486146568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "424174485768384512",
  "geo" : { },
  "id_str" : "424187257818341376",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco @GemL1 it's part of Cambridge Uni no?",
  "id" : 424187257818341376,
  "in_reply_to_status_id" : 424174485768384512,
  "created_at" : "2014-01-17 14:31:37 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemma Lunn",
      "screen_name" : "GemL1",
      "indices" : [ 0, 6 ],
      "id_str" : "486146568",
      "id" : 486146568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "424167786483830785",
  "geo" : { },
  "id_str" : "424168450538229760",
  "in_reply_to_user_id" : 486146568,
  "text" : "@GemL1 sure, it is amazing still that the majority of corpora done in taxpayer institutions are closed off to the public",
  "id" : 424168450538229760,
  "in_reply_to_status_id" : 424167786483830785,
  "created_at" : "2014-01-17 13:16:53 +0000",
  "in_reply_to_screen_name" : "GemL1",
  "in_reply_to_user_id_str" : "486146568",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemma Lunn",
      "screen_name" : "GemL1",
      "indices" : [ 0, 6 ],
      "id_str" : "486146568",
      "id" : 486146568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "424167136249262080",
  "geo" : { },
  "id_str" : "424167402075484160",
  "in_reply_to_user_id" : 486146568,
  "text" : "@GemL1 thanks for sharing gemma, have a grt weekend :)",
  "id" : 424167402075484160,
  "in_reply_to_status_id" : 424167136249262080,
  "created_at" : "2014-01-17 13:12:43 +0000",
  "in_reply_to_screen_name" : "GemL1",
  "in_reply_to_user_id_str" : "486146568",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ETpro",
      "screen_name" : "ETprofessional",
      "indices" : [ 0, 15 ],
      "id_str" : "501629829",
      "id" : 501629829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "424164193756270592",
  "geo" : { },
  "id_str" : "424166284410892288",
  "in_reply_to_user_id" : 501629829,
  "text" : "@ETprofessional sure :)",
  "id" : 424166284410892288,
  "in_reply_to_status_id" : 424164193756270592,
  "created_at" : "2014-01-17 13:08:17 +0000",
  "in_reply_to_screen_name" : "ETprofessional",
  "in_reply_to_user_id_str" : "501629829",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "424165875646595072",
  "geo" : { },
  "id_str" : "424166228903473152",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt RT is your friend ;)",
  "id" : 424166228903473152,
  "in_reply_to_status_id" : 424165875646595072,
  "created_at" : "2014-01-17 13:08:04 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jobs at CUP",
      "screen_name" : "cambuprecruit",
      "indices" : [ 1, 15 ],
      "id_str" : "461918261",
      "id" : 461918261
    }, {
      "name" : "Gemma Lunn",
      "screen_name" : "GemL1",
      "indices" : [ 16, 22 ],
      "id_str" : "486146568",
      "id" : 486146568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/RN09vXBeVy",
      "expanded_url" : "https:\/\/plus.google.com\/104940199413423400545\/posts\/RQkZs8DCFjG",
      "display_url" : "plus.google.com\/10494019941342\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "424134075012898816",
  "geo" : { },
  "id_str" : "424165717345177601",
  "in_reply_to_user_id" : 461918261,
  "text" : ".@cambuprecruit @GemL1 should we help in a building a corpus we won\"t have access to? https:\/\/t.co\/RN09vXBeVy",
  "id" : 424165717345177601,
  "in_reply_to_status_id" : 424134075012898816,
  "created_at" : "2014-01-17 13:06:02 +0000",
  "in_reply_to_screen_name" : "cambuprecruit",
  "in_reply_to_user_id_str" : "461918261",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chia Suan Chong",
      "screen_name" : "chiasuan",
      "indices" : [ 3, 12 ],
      "id_str" : "71588589",
      "id" : 71588589
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 143, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 127, 144 ],
      "url" : "http:\/\/t.co\/KE7AZdLqa4",
      "expanded_url" : "http:\/\/www.etprofessional.com\/why_is_39break39_like_39steal39_25769806281.aspx",
      "display_url" : "etprofessional.com\/why_is_39break\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424160907934322688",
  "text" : "RT @chiasuan: Are some teaching skills that are untrainable and best left to experience? Should we assume less &amp; ask more?\nhttp:\/\/t.co\/KE7A\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "elt",
        "indices" : [ 136, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/KE7AZdLqa4",
        "expanded_url" : "http:\/\/www.etprofessional.com\/why_is_39break39_like_39steal39_25769806281.aspx",
        "display_url" : "etprofessional.com\/why_is_39break\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "424159839028117504",
    "text" : "Are some teaching skills that are untrainable and best left to experience? Should we assume less &amp; ask more?\nhttp:\/\/t.co\/KE7AZdLqa4 #elt",
    "id" : 424159839028117504,
    "created_at" : "2014-01-17 12:42:40 +0000",
    "user" : {
      "name" : "Chia Suan Chong",
      "screen_name" : "chiasuan",
      "protected" : false,
      "id_str" : "71588589",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1672976345\/IMG_1047_normal.jpg",
      "id" : 71588589,
      "verified" : false
    }
  },
  "id" : 424160907934322688,
  "created_at" : "2014-01-17 12:46:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Thornbury",
      "screen_name" : "thornburyscott",
      "indices" : [ 68, 83 ],
      "id_str" : "23090474",
      "id" : 23090474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/PD5OdwqA65",
      "expanded_url" : "http:\/\/www.cambridge.org\/servlet\/file\/store7\/item7138221\/version1\/Tomlinson%20Willis%20Chap%203.pdf",
      "display_url" : "cambridge.org\/servlet\/file\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424158083212787713",
  "text" : "a great ref on hand concordancing http:\/\/t.co\/PD5OdwqA65  shared by @thornburyscott on G+ CL community",
  "id" : 424158083212787713,
  "created_at" : "2014-01-17 12:35:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpuslinguistics",
      "indices" : [ 19, 37 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 76, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/Ex7wVICwgf",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-Lm",
      "display_url" : "wp.me\/pgHyE-Lm"
    } ]
  },
  "geo" : { },
  "id_str" : "424143391929016320",
  "text" : "another roundup of #corpuslinguistics community news http:\/\/t.co\/Ex7wVICwgf #eltchat",
  "id" : 424143391929016320,
  "created_at" : "2014-01-17 11:37:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yolanda B. Schell",
      "screen_name" : "mattellman",
      "indices" : [ 0, 11 ],
      "id_str" : "725597315860434945",
      "id" : 725597315860434945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "424124969228853248",
  "geo" : { },
  "id_str" : "424125713755537409",
  "in_reply_to_user_id" : 394987109,
  "text" : "@mattellman new year greetings :) nice 2 posts u got there",
  "id" : 424125713755537409,
  "in_reply_to_status_id" : 424124969228853248,
  "created_at" : "2014-01-17 10:27:04 +0000",
  "in_reply_to_screen_name" : "MatthewEllman",
  "in_reply_to_user_id_str" : "394987109",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yolanda B. Schell",
      "screen_name" : "mattellman",
      "indices" : [ 3, 14 ],
      "id_str" : "725597315860434945",
      "id" : 725597315860434945
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ESL",
      "indices" : [ 101, 105 ]
    }, {
      "text" : "EFL",
      "indices" : [ 106, 110 ]
    }, {
      "text" : "ELT",
      "indices" : [ 111, 115 ]
    }, {
      "text" : "TESOL",
      "indices" : [ 116, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/D6HLpzD59r",
      "expanded_url" : "http:\/\/teachertolearner.com\/2014\/01\/04\/my-silent-period\/",
      "display_url" : "teachertolearner.com\/2014\/01\/04\/my-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424124105861103616",
  "text" : "RT @mattellman: My Silent Period, or How to Learn a Language Without Speaking http:\/\/t.co\/D6HLpzD59r #ESL #EFL #ELT #TESOL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ESL",
        "indices" : [ 85, 89 ]
      }, {
        "text" : "EFL",
        "indices" : [ 90, 94 ]
      }, {
        "text" : "ELT",
        "indices" : [ 95, 99 ]
      }, {
        "text" : "TESOL",
        "indices" : [ 100, 106 ]
      } ],
      "urls" : [ {
        "indices" : [ 62, 84 ],
        "url" : "http:\/\/t.co\/D6HLpzD59r",
        "expanded_url" : "http:\/\/teachertolearner.com\/2014\/01\/04\/my-silent-period\/",
        "display_url" : "teachertolearner.com\/2014\/01\/04\/my-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "424121727006695424",
    "text" : "My Silent Period, or How to Learn a Language Without Speaking http:\/\/t.co\/D6HLpzD59r #ESL #EFL #ELT #TESOL",
    "id" : 424121727006695424,
    "created_at" : "2014-01-17 10:11:14 +0000",
    "user" : {
      "name" : "Matthew Ellman",
      "screen_name" : "MatthewEllman",
      "protected" : false,
      "id_str" : "394987109",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1615371192\/classpic_normal.jpg",
      "id" : 394987109,
      "verified" : false
    }
  },
  "id" : 424124105861103616,
  "created_at" : "2014-01-17 10:20:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "European Tribune",
      "screen_name" : "EuropeanTribune",
      "indices" : [ 74, 90 ],
      "id_str" : "568326306",
      "id" : 568326306
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/YhVQXl0iVV",
      "expanded_url" : "http:\/\/www.eurotrib.com\/story\/2014\/1\/14\/8832\/46781",
      "display_url" : "eurotrib.com\/story\/2014\/1\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424117847061569536",
  "text" : "Transatlantic Trade and Investment Partnership http:\/\/t.co\/YhVQXl0iVV via @EuropeanTribune",
  "id" : 424117847061569536,
  "created_at" : "2014-01-17 09:55:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/5CJWDuAZXY",
      "expanded_url" : "http:\/\/www.jonathan-cook.net\/blog\/2014-01-15\/gasland-documents-our-race-to-extinction\/",
      "display_url" : "jonathan-cook.net\/blog\/2014-01-1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424110274954919936",
  "text" : "RT @johnwhilley: Jonathan Cook: Gasland documents our race to extinction  http:\/\/t.co\/5CJWDuAZXY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/5CJWDuAZXY",
        "expanded_url" : "http:\/\/www.jonathan-cook.net\/blog\/2014-01-15\/gasland-documents-our-race-to-extinction\/",
        "display_url" : "jonathan-cook.net\/blog\/2014-01-1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "423975384778960896",
    "text" : "Jonathan Cook: Gasland documents our race to extinction  http:\/\/t.co\/5CJWDuAZXY",
    "id" : 423975384778960896,
    "created_at" : "2014-01-17 00:29:43 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 424110274954919936,
  "created_at" : "2014-01-17 09:25:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Revolution News",
      "screen_name" : "NewsRevo",
      "indices" : [ 3, 12 ],
      "id_str" : "47862165",
      "id" : 47862165
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/NewsRevo\/status\/424052211753029632\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/TIbGU8Agau",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BeKJPWgCEAEuWGA.jpg",
      "id_str" : "424052211757223937",
      "id" : 424052211757223937,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BeKJPWgCEAEuWGA.jpg",
      "sizes" : [ {
        "h" : 565,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 565,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 192,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 339,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/TIbGU8Agau"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/PbxHFdHEPz",
      "expanded_url" : "http:\/\/revolution-news.com\/huge-steaming-pile-shit-dumped-national-assembly-france\/",
      "display_url" : "revolution-news.com\/huge-steaming-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424110224119967744",
  "text" : "RT @NewsRevo: Huge Steaming Pile of Shit Dumped at the National Assembly of France: http:\/\/t.co\/PbxHFdHEPz http:\/\/t.co\/TIbGU8Agau",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/NewsRevo\/status\/424052211753029632\/photo\/1",
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/TIbGU8Agau",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BeKJPWgCEAEuWGA.jpg",
        "id_str" : "424052211757223937",
        "id" : 424052211757223937,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BeKJPWgCEAEuWGA.jpg",
        "sizes" : [ {
          "h" : 565,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 565,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 192,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 339,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/TIbGU8Agau"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/PbxHFdHEPz",
        "expanded_url" : "http:\/\/revolution-news.com\/huge-steaming-pile-shit-dumped-national-assembly-france\/",
        "display_url" : "revolution-news.com\/huge-steaming-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "424052211753029632",
    "text" : "Huge Steaming Pile of Shit Dumped at the National Assembly of France: http:\/\/t.co\/PbxHFdHEPz http:\/\/t.co\/TIbGU8Agau",
    "id" : 424052211753029632,
    "created_at" : "2014-01-17 05:35:00 +0000",
    "user" : {
      "name" : "Revolution News",
      "screen_name" : "NewsRevo",
      "protected" : false,
      "id_str" : "47862165",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/573963111272570880\/lpNfTgyM_normal.jpeg",
      "id" : 47862165,
      "verified" : false
    }
  },
  "id" : 424110224119967744,
  "created_at" : "2014-01-17 09:25:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Forbes",
      "screen_name" : "GenkiSarah",
      "indices" : [ 3, 14 ],
      "id_str" : "586340658",
      "id" : 586340658
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/h2oxxb38km",
      "expanded_url" : "http:\/\/www.sarahtesolhub.com\/1\/post\/2014\/01\/what-does-it-mean-to-be-a-global-engineer1.html",
      "display_url" : "sarahtesolhub.com\/1\/post\/2014\/01\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424096370187055104",
  "text" : "RT @GenkiSarah: What does it mean to be a global engineer? http:\/\/t.co\/h2oxxb38km",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.weebly.com\/\" rel=\"nofollow\"\u003EWeebly App\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 65 ],
        "url" : "http:\/\/t.co\/h2oxxb38km",
        "expanded_url" : "http:\/\/www.sarahtesolhub.com\/1\/post\/2014\/01\/what-does-it-mean-to-be-a-global-engineer1.html",
        "display_url" : "sarahtesolhub.com\/1\/post\/2014\/01\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "424053415740588032",
    "text" : "What does it mean to be a global engineer? http:\/\/t.co\/h2oxxb38km",
    "id" : 424053415740588032,
    "created_at" : "2014-01-17 05:39:47 +0000",
    "user" : {
      "name" : "Sarah Forbes",
      "screen_name" : "GenkiSarah",
      "protected" : false,
      "id_str" : "586340658",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2237023794\/DSCF5375_normal.JPG",
      "id" : 586340658,
      "verified" : false
    }
  },
  "id" : 424096370187055104,
  "created_at" : "2014-01-17 08:30:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423920713150791680",
  "geo" : { },
  "id_str" : "423936327021629441",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@teflskeptic i guess that's not a ref to jimmy saville and co :\/",
  "id" : 423936327021629441,
  "in_reply_to_status_id" : 423920713150791680,
  "created_at" : "2014-01-16 21:54:31 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Yau",
      "screen_name" : "flowingdata",
      "indices" : [ 3, 15 ],
      "id_str" : "14109167",
      "id" : 14109167
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/flowingdata\/status\/423840149999345665\/photo\/1",
      "indices" : [ 124, 140 ],
      "url" : "http:\/\/t.co\/R3IYTU1nRJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BeHIXu7CYAMILgt.png",
      "id_str" : "423840150007734275",
      "id" : 423840150007734275,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BeHIXu7CYAMILgt.png",
      "sizes" : [ {
        "h" : 424,
        "resize" : "fit",
        "w" : 715
      }, {
        "h" : 424,
        "resize" : "fit",
        "w" : 715
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 356,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 202,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/R3IYTU1nRJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/bro9I2okDs",
      "expanded_url" : "http:\/\/flowingdata.com\/2014\/01\/16\/famous-movie-quotes-as-charts\/",
      "display_url" : "flowingdata.com\/2014\/01\/16\/fam\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423866148414029824",
  "text" : "RT @flowingdata: Famous movie quotes as charts. I made one and thought, hey, might as well make 100. http:\/\/t.co\/bro9I2okDs http:\/\/t.co\/R3I\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/flowingdata\/status\/423840149999345665\/photo\/1",
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/R3IYTU1nRJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BeHIXu7CYAMILgt.png",
        "id_str" : "423840150007734275",
        "id" : 423840150007734275,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BeHIXu7CYAMILgt.png",
        "sizes" : [ {
          "h" : 424,
          "resize" : "fit",
          "w" : 715
        }, {
          "h" : 424,
          "resize" : "fit",
          "w" : 715
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 356,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 202,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/R3IYTU1nRJ"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/bro9I2okDs",
        "expanded_url" : "http:\/\/flowingdata.com\/2014\/01\/16\/famous-movie-quotes-as-charts\/",
        "display_url" : "flowingdata.com\/2014\/01\/16\/fam\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "423840149999345665",
    "text" : "Famous movie quotes as charts. I made one and thought, hey, might as well make 100. http:\/\/t.co\/bro9I2okDs http:\/\/t.co\/R3IYTU1nRJ",
    "id" : 423840149999345665,
    "created_at" : "2014-01-16 15:32:21 +0000",
    "user" : {
      "name" : "Nathan Yau",
      "screen_name" : "flowingdata",
      "protected" : false,
      "id_str" : "14109167",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/585826994526355456\/R3tYT5Kj_normal.png",
      "id" : 14109167,
      "verified" : false
    }
  },
  "id" : 423866148414029824,
  "created_at" : "2014-01-16 17:15:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 3, 16 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/roDyD1sEL8",
      "expanded_url" : "http:\/\/wp.me\/pKFOt-pc",
      "display_url" : "wp.me\/pKFOt-pc"
    } ]
  },
  "geo" : { },
  "id_str" : "423593037080842241",
  "text" : "RT @rosemerebard: Learn, Practise and Test through Bingo -&gt; possibilities &amp; alternatives with Games http:\/\/t.co\/roDyD1sEL8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/roDyD1sEL8",
        "expanded_url" : "http:\/\/wp.me\/pKFOt-pc",
        "display_url" : "wp.me\/pKFOt-pc"
      } ]
    },
    "geo" : { },
    "id_str" : "423584126315556864",
    "text" : "Learn, Practise and Test through Bingo -&gt; possibilities &amp; alternatives with Games http:\/\/t.co\/roDyD1sEL8",
    "id" : 423584126315556864,
    "created_at" : "2014-01-15 22:35:00 +0000",
    "user" : {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "protected" : false,
      "id_str" : "88655243",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/706508144160145410\/pKzknb5H_normal.jpg",
      "id" : 88655243,
      "verified" : false
    }
  },
  "id" : 423593037080842241,
  "created_at" : "2014-01-15 23:10:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/gUI0m9OxZZ",
      "expanded_url" : "http:\/\/tinyurl.com\/pwjqbm5",
      "display_url" : "tinyurl.com\/pwjqbm5"
    } ]
  },
  "geo" : { },
  "id_str" : "423591580055113728",
  "text" : "RT @medialens: Our very own climate change sci-fi disaster movie unfolding: 'Heat Wave Kills 100,000 Bats in Australia' http:\/\/t.co\/gUI0m9O\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/gUI0m9OxZZ",
        "expanded_url" : "http:\/\/tinyurl.com\/pwjqbm5",
        "display_url" : "tinyurl.com\/pwjqbm5"
      } ]
    },
    "geo" : { },
    "id_str" : "423450748693651457",
    "text" : "Our very own climate change sci-fi disaster movie unfolding: 'Heat Wave Kills 100,000 Bats in Australia' http:\/\/t.co\/gUI0m9OxZZ",
    "id" : 423450748693651457,
    "created_at" : "2014-01-15 13:45:00 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 423591580055113728,
  "created_at" : "2014-01-15 23:04:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423561733564018689",
  "geo" : { },
  "id_str" : "423563359447826432",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson the Joker has stiff competition it seems :)",
  "id" : 423563359447826432,
  "in_reply_to_status_id" : 423561733564018689,
  "created_at" : "2014-01-15 21:12:28 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vicky Loras",
      "screen_name" : "vickyloras",
      "indices" : [ 0, 11 ],
      "id_str" : "95957241",
      "id" : 95957241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423537525395693570",
  "geo" : { },
  "id_str" : "423544684770631680",
  "in_reply_to_user_id" : 95957241,
  "text" : "@vickyloras yr welcome looking to be an interesting conf :)",
  "id" : 423544684770631680,
  "in_reply_to_status_id" : 423537525395693570,
  "created_at" : "2014-01-15 19:58:16 +0000",
  "in_reply_to_screen_name" : "vickyloras",
  "in_reply_to_user_id_str" : "95957241",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EFF",
      "screen_name" : "EFF",
      "indices" : [ 3, 7 ],
      "id_str" : "4816",
      "id" : 4816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/uSvuu4R9BT",
      "expanded_url" : "https:\/\/eff.org\/r.y74l",
      "display_url" : "eff.org\/r.y74l"
    } ]
  },
  "geo" : { },
  "id_str" : "423544230989287424",
  "text" : "RT @EFF: Gmail just made it so anyone on Google Plus can email you. Here's how to opt out: https:\/\/t.co\/uSvuu4R9BT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.eff.org\/\" rel=\"nofollow\"\u003EThingie\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/uSvuu4R9BT",
        "expanded_url" : "https:\/\/eff.org\/r.y74l",
        "display_url" : "eff.org\/r.y74l"
      } ]
    },
    "geo" : { },
    "id_str" : "423518765809414146",
    "text" : "Gmail just made it so anyone on Google Plus can email you. Here's how to opt out: https:\/\/t.co\/uSvuu4R9BT",
    "id" : 423518765809414146,
    "created_at" : "2014-01-15 18:15:17 +0000",
    "user" : {
      "name" : "EFF",
      "screen_name" : "EFF",
      "protected" : false,
      "id_str" : "4816",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/756133504413495296\/7NlilDyR_normal.jpg",
      "id" : 4816,
      "verified" : true
    }
  },
  "id" : 423544230989287424,
  "created_at" : "2014-01-15 19:56:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vicky Loras",
      "screen_name" : "vickyloras",
      "indices" : [ 3, 14 ],
      "id_str" : "95957241",
      "id" : 95957241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 127, 140 ],
      "url" : "http:\/\/t.co\/qeygEkiDF8",
      "expanded_url" : "http:\/\/fb.me\/6AMQeTkqn",
      "display_url" : "fb.me\/6AMQeTkqn"
    } ]
  },
  "geo" : { },
  "id_str" : "423537120897015808",
  "text" : "RT @vickyloras: Introducing the 2nd Loras Workshop 2014 Speakers, on the theme of Technology in Language Learning:\n\nMichael... http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/qeygEkiDF8",
        "expanded_url" : "http:\/\/fb.me\/6AMQeTkqn",
        "display_url" : "fb.me\/6AMQeTkqn"
      } ]
    },
    "geo" : { },
    "id_str" : "423534253381394432",
    "text" : "Introducing the 2nd Loras Workshop 2014 Speakers, on the theme of Technology in Language Learning:\n\nMichael... http:\/\/t.co\/qeygEkiDF8",
    "id" : 423534253381394432,
    "created_at" : "2014-01-15 19:16:49 +0000",
    "user" : {
      "name" : "Vicky Loras",
      "screen_name" : "vickyloras",
      "protected" : false,
      "id_str" : "95957241",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/649856172317519872\/zNL8t04-_normal.jpg",
      "id" : 95957241,
      "verified" : false
    }
  },
  "id" : 423537120897015808,
  "created_at" : "2014-01-15 19:28:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyler Schnoebelen",
      "screen_name" : "TSchnoebelen",
      "indices" : [ 3, 16 ],
      "id_str" : "14969147",
      "id" : 14969147
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/DHn5FI41VJ",
      "expanded_url" : "http:\/\/idibon.com\/innovating-innovation\/",
      "display_url" : "idibon.com\/innovating-inn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423527963196264449",
  "text" : "RT @TSchnoebelen: Innovations and linguistic innovations. Because Bronies. Because Bentobox Cumberbund. Because swag. http:\/\/t.co\/DHn5FI41VJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/DHn5FI41VJ",
        "expanded_url" : "http:\/\/idibon.com\/innovating-innovation\/",
        "display_url" : "idibon.com\/innovating-inn\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "423521297399021568",
    "text" : "Innovations and linguistic innovations. Because Bronies. Because Bentobox Cumberbund. Because swag. http:\/\/t.co\/DHn5FI41VJ",
    "id" : 423521297399021568,
    "created_at" : "2014-01-15 18:25:20 +0000",
    "user" : {
      "name" : "Tyler Schnoebelen",
      "screen_name" : "TSchnoebelen",
      "protected" : false,
      "id_str" : "14969147",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/604427674203779072\/Y4t_NODB_normal.jpg",
      "id" : 14969147,
      "verified" : false
    }
  },
  "id" : 423527963196264449,
  "created_at" : "2014-01-15 18:51:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "indices" : [ 3, 19 ],
      "id_str" : "1326508478",
      "id" : 1326508478
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/U7daoGQjDd",
      "expanded_url" : "http:\/\/cass.lancs.ac.uk\/?p=993",
      "display_url" : "cass.lancs.ac.uk\/?p=993"
    } ]
  },
  "geo" : { },
  "id_str" : "423454126580981760",
  "text" : "RT @CorpusSocialSci: \"Is this the way to do Corpus Linguistics?\" Development of a feedback system for the CASS Corpus Linguistics MOOC: htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/U7daoGQjDd",
        "expanded_url" : "http:\/\/cass.lancs.ac.uk\/?p=993",
        "display_url" : "cass.lancs.ac.uk\/?p=993"
      } ]
    },
    "geo" : { },
    "id_str" : "423384241825521664",
    "text" : "\"Is this the way to do Corpus Linguistics?\" Development of a feedback system for the CASS Corpus Linguistics MOOC: http:\/\/t.co\/U7daoGQjDd",
    "id" : 423384241825521664,
    "created_at" : "2014-01-15 09:20:44 +0000",
    "user" : {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "protected" : false,
      "id_str" : "1326508478",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3493899777\/ced36fe15c32eb911cbe3d64377524dc_normal.jpeg",
      "id" : 1326508478,
      "verified" : false
    }
  },
  "id" : 423454126580981760,
  "created_at" : "2014-01-15 13:58:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jobs at CUP",
      "screen_name" : "cambuprecruit",
      "indices" : [ 0, 14 ],
      "id_str" : "461918261",
      "id" : 461918261
    }, {
      "name" : "Claire Hart",
      "screen_name" : "claire_hart",
      "indices" : [ 15, 27 ],
      "id_str" : "96138105",
      "id" : 96138105
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/RN09vXBeVy",
      "expanded_url" : "https:\/\/plus.google.com\/104940199413423400545\/posts\/RQkZs8DCFjG",
      "display_url" : "plus.google.com\/10494019941342\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "423409286392582144",
  "geo" : { },
  "id_str" : "423449909694451712",
  "in_reply_to_user_id" : 461918261,
  "text" : "@cambuprecruit @claire_hart my thoughts on this https:\/\/t.co\/RN09vXBeVy",
  "id" : 423449909694451712,
  "in_reply_to_status_id" : 423409286392582144,
  "created_at" : "2014-01-15 13:41:40 +0000",
  "in_reply_to_screen_name" : "cambuprecruit",
  "in_reply_to_user_id_str" : "461918261",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luca Marchiori",
      "screen_name" : "chuechebueb",
      "indices" : [ 3, 15 ],
      "id_str" : "1334451956",
      "id" : 1334451956
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "French",
      "indices" : [ 21, 28 ]
    }, {
      "text" : "English",
      "indices" : [ 54, 62 ]
    }, {
      "text" : "language",
      "indices" : [ 100, 109 ]
    }, {
      "text" : "paradox",
      "indices" : [ 110, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423449114064732161",
  "text" : "RT @chuechebueb: The #French say: 'C'est le top!' The #English say: 'That's the cr\u00E8me de la cr\u00E8me.' #language #paradox",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "French",
        "indices" : [ 4, 11 ]
      }, {
        "text" : "English",
        "indices" : [ 37, 45 ]
      }, {
        "text" : "language",
        "indices" : [ 83, 92 ]
      }, {
        "text" : "paradox",
        "indices" : [ 93, 101 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "423419580627689472",
    "text" : "The #French say: 'C'est le top!' The #English say: 'That's the cr\u00E8me de la cr\u00E8me.' #language #paradox",
    "id" : 423419580627689472,
    "created_at" : "2014-01-15 11:41:09 +0000",
    "user" : {
      "name" : "Luca Marchiori",
      "screen_name" : "chuechebueb",
      "protected" : false,
      "id_str" : "1334451956",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/648051963029004288\/4-IhfZUE_normal.jpg",
      "id" : 1334451956,
      "verified" : false
    }
  },
  "id" : 423449114064732161,
  "created_at" : "2014-01-15 13:38:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luca Marchiori",
      "screen_name" : "chuechebueb",
      "indices" : [ 3, 15 ],
      "id_str" : "1334451956",
      "id" : 1334451956
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thoughts",
      "indices" : [ 17, 26 ]
    }, {
      "text" : "learning",
      "indices" : [ 30, 39 ]
    }, {
      "text" : "vocabulary",
      "indices" : [ 40, 51 ]
    }, {
      "text" : "language",
      "indices" : [ 75, 84 ]
    }, {
      "text" : "french",
      "indices" : [ 85, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/Uyf38t5BRo",
      "expanded_url" : "http:\/\/rosbifaparis.blogspot.fr\/",
      "display_url" : "rosbifaparis.blogspot.fr"
    } ]
  },
  "geo" : { },
  "id_str" : "423449044904837121",
  "text" : "RT @chuechebueb: #thoughts on #learning #vocabulary http:\/\/t.co\/Uyf38t5BRo #language #french",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "thoughts",
        "indices" : [ 0, 9 ]
      }, {
        "text" : "learning",
        "indices" : [ 13, 22 ]
      }, {
        "text" : "vocabulary",
        "indices" : [ 23, 34 ]
      }, {
        "text" : "language",
        "indices" : [ 58, 67 ]
      }, {
        "text" : "french",
        "indices" : [ 68, 75 ]
      } ],
      "urls" : [ {
        "indices" : [ 35, 57 ],
        "url" : "http:\/\/t.co\/Uyf38t5BRo",
        "expanded_url" : "http:\/\/rosbifaparis.blogspot.fr\/",
        "display_url" : "rosbifaparis.blogspot.fr"
      } ]
    },
    "geo" : { },
    "id_str" : "423410344002715648",
    "text" : "#thoughts on #learning #vocabulary http:\/\/t.co\/Uyf38t5BRo #language #french",
    "id" : 423410344002715648,
    "created_at" : "2014-01-15 11:04:27 +0000",
    "user" : {
      "name" : "Luca Marchiori",
      "screen_name" : "chuechebueb",
      "protected" : false,
      "id_str" : "1334451956",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/648051963029004288\/4-IhfZUE_normal.jpg",
      "id" : 1334451956,
      "verified" : false
    }
  },
  "id" : 423449044904837121,
  "created_at" : "2014-01-15 13:38:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Andrews",
      "screen_name" : "PatrickAndrews",
      "indices" : [ 0, 15 ],
      "id_str" : "29999737",
      "id" : 29999737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423102994473705472",
  "geo" : { },
  "id_str" : "423103155610460160",
  "in_reply_to_user_id" : 29999737,
  "text" : "@PatrickAndrews great :)",
  "id" : 423103155610460160,
  "in_reply_to_status_id" : 423102994473705472,
  "created_at" : "2014-01-14 14:43:47 +0000",
  "in_reply_to_screen_name" : "PatrickAndrews",
  "in_reply_to_user_id_str" : "29999737",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423073707414663168",
  "geo" : { },
  "id_str" : "423102488250572800",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco getting free access to learner corpora is one way to see more of that!",
  "id" : 423102488250572800,
  "in_reply_to_status_id" : 423073707414663168,
  "created_at" : "2014-01-14 14:41:08 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Andrews",
      "screen_name" : "PatrickAndrews",
      "indices" : [ 0, 15 ],
      "id_str" : "29999737",
      "id" : 29999737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/5HVxk4F4IY",
      "expanded_url" : "https:\/\/plus.google.com\/communities\/101266284417587206243",
      "display_url" : "plus.google.com\/communities\/10\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423101860099018752",
  "in_reply_to_user_id" : 29999737,
  "text" : "@PatrickAndrews hi for more corpora stuff consider joining G+ community https:\/\/t.co\/5HVxk4F4IY",
  "id" : 423101860099018752,
  "created_at" : "2014-01-14 14:38:38 +0000",
  "in_reply_to_screen_name" : "PatrickAndrews",
  "in_reply_to_user_id_str" : "29999737",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 1, 12 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/ulzd8EZIOw",
      "expanded_url" : "http:\/\/journals.cambridge.org\/repo_A86jAWXY",
      "display_url" : "journals.cambridge.org\/repo_A86jAWXY"
    } ]
  },
  "in_reply_to_status_id_str" : "423039100317212672",
  "geo" : { },
  "id_str" : "423071125052989440",
  "in_reply_to_user_id" : 300734173,
  "text" : ".@lexicoloco this text along with Raising teachers\u2019 awareness of corpora http:\/\/t.co\/ulzd8EZIOw are atm imo THE go to texts for lang tchrs",
  "id" : 423071125052989440,
  "in_reply_to_status_id" : 423039100317212672,
  "created_at" : "2014-01-14 12:36:31 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 3, 14 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELT",
      "indices" : [ 70, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/uBcFoCW8FV",
      "expanded_url" : "http:\/\/www.academia.edu\/3368339\/Integrating_corpora_with_everyday_language_teaching",
      "display_url" : "academia.edu\/3368339\/Integr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423060149377716224",
  "text" : "RT @lexicoloco: 'Integrating corpora with everyday language teaching' #ELT Ana Frankenberg-Garcia (PDF) http:\/\/t.co\/uBcFoCW8FV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELT",
        "indices" : [ 54, 58 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/uBcFoCW8FV",
        "expanded_url" : "http:\/\/www.academia.edu\/3368339\/Integrating_corpora_with_everyday_language_teaching",
        "display_url" : "academia.edu\/3368339\/Integr\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "423039100317212672",
    "text" : "'Integrating corpora with everyday language teaching' #ELT Ana Frankenberg-Garcia (PDF) http:\/\/t.co\/uBcFoCW8FV",
    "id" : 423039100317212672,
    "created_at" : "2014-01-14 10:29:15 +0000",
    "user" : {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "protected" : false,
      "id_str" : "300734173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2403500097\/3nmx3kjaycyoc7irwe6s_normal.jpeg",
      "id" : 300734173,
      "verified" : false
    }
  },
  "id" : 423060149377716224,
  "created_at" : "2014-01-14 11:52:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bret Victor",
      "screen_name" : "worrydream",
      "indices" : [ 3, 14 ],
      "id_str" : "255617445",
      "id" : 255617445
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/1x71oj0rON",
      "expanded_url" : "http:\/\/worrydream.com\/MeanwhileAtCodeOrg\/",
      "display_url" : "worrydream.com\/MeanwhileAtCod\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422867574779838464",
  "text" : "RT @worrydream: sometimes I start to make things like this, and then I think \"what's the point\", and then I think why am i even http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/1x71oj0rON",
        "expanded_url" : "http:\/\/worrydream.com\/MeanwhileAtCodeOrg\/",
        "display_url" : "worrydream.com\/MeanwhileAtCod\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "422221078182633472",
    "text" : "sometimes I start to make things like this, and then I think \"what's the point\", and then I think why am i even http:\/\/t.co\/1x71oj0rON",
    "id" : 422221078182633472,
    "created_at" : "2014-01-12 04:18:44 +0000",
    "user" : {
      "name" : "Bret Victor",
      "screen_name" : "worrydream",
      "protected" : false,
      "id_str" : "255617445",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/767981637623685120\/7WgbPNE9_normal.jpg",
      "id" : 255617445,
      "verified" : false
    }
  },
  "id" : 422867574779838464,
  "created_at" : "2014-01-13 23:07:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luca Marchiori",
      "screen_name" : "chuechebueb",
      "indices" : [ 3, 15 ],
      "id_str" : "1334451956",
      "id" : 1334451956
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "language",
      "indices" : [ 110, 119 ]
    }, {
      "text" : "french",
      "indices" : [ 120, 127 ]
    }, {
      "text" : "english",
      "indices" : [ 128, 136 ]
    }, {
      "text" : "france",
      "indices" : [ 137, 140 ]
    }, {
      "text" : "paradox",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "422852070405062656",
  "text" : "RT @chuechebueb: The French say: 'Il faut faire \u00E7a asap!' The English say: 'You need to do that toute suite!' #language #french #english #f\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "language",
        "indices" : [ 93, 102 ]
      }, {
        "text" : "french",
        "indices" : [ 103, 110 ]
      }, {
        "text" : "english",
        "indices" : [ 111, 119 ]
      }, {
        "text" : "france",
        "indices" : [ 120, 127 ]
      }, {
        "text" : "paradox",
        "indices" : [ 128, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "422840708425207810",
    "text" : "The French say: 'Il faut faire \u00E7a asap!' The English say: 'You need to do that toute suite!' #language #french #english #france #paradox",
    "id" : 422840708425207810,
    "created_at" : "2014-01-13 21:20:55 +0000",
    "user" : {
      "name" : "Luca Marchiori",
      "screen_name" : "chuechebueb",
      "protected" : false,
      "id_str" : "1334451956",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/648051963029004288\/4-IhfZUE_normal.jpg",
      "id" : 1334451956,
      "verified" : false
    }
  },
  "id" : 422852070405062656,
  "created_at" : "2014-01-13 22:06:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 76, 92 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/MivNBkdNTL",
      "expanded_url" : "http:\/\/wp.me\/p2jfML-5b",
      "display_url" : "wp.me\/p2jfML-5b"
    } ]
  },
  "geo" : { },
  "id_str" : "422833010753273856",
  "text" : "EAP Dogme style @ Masaryk University: The run up http:\/\/t.co\/MivNBkdNTL via @wordpressdotcom",
  "id" : 422833010753273856,
  "created_at" : "2014-01-13 20:50:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil Longwell",
      "screen_name" : "teacherphili",
      "indices" : [ 3, 16 ],
      "id_str" : "67863264",
      "id" : 67863264
    }, {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 129, 138 ],
      "id_str" : "134211317",
      "id" : 134211317
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/HgDmjVprIZ",
      "expanded_url" : "http:\/\/wp.me\/p3Wm0j-aB",
      "display_url" : "wp.me\/p3Wm0j-aB"
    } ]
  },
  "geo" : { },
  "id_str" : "422811082668142595",
  "text" : "RT @teacherphili: Problems which arose from the 'Backshfiting' of tenses. 4\u00BD ways of Reporting Speech http:\/\/t.co\/HgDmjVprIZ via @josipa74",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "paulw",
        "screen_name" : "josipa74",
        "indices" : [ 111, 120 ],
        "id_str" : "134211317",
        "id" : 134211317
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/HgDmjVprIZ",
        "expanded_url" : "http:\/\/wp.me\/p3Wm0j-aB",
        "display_url" : "wp.me\/p3Wm0j-aB"
      } ]
    },
    "geo" : { },
    "id_str" : "422800604134510592",
    "text" : "Problems which arose from the 'Backshfiting' of tenses. 4\u00BD ways of Reporting Speech http:\/\/t.co\/HgDmjVprIZ via @josipa74",
    "id" : 422800604134510592,
    "created_at" : "2014-01-13 18:41:33 +0000",
    "user" : {
      "name" : "Phil Longwell",
      "screen_name" : "teacherphili",
      "protected" : false,
      "id_str" : "67863264",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637201716295933952\/4n4DCm-q_normal.jpg",
      "id" : 67863264,
      "verified" : false
    }
  },
  "id" : 422811082668142595,
  "created_at" : "2014-01-13 19:23:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maria Pia Montoro",
      "screen_name" : "WordLo",
      "indices" : [ 3, 10 ],
      "id_str" : "190569306",
      "id" : 190569306
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/NTMI8DbHT7",
      "expanded_url" : "http:\/\/pinterest.com\/pin\/445012006901388880\/",
      "display_url" : "pinterest.com\/pin\/4450120069\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422685142722019328",
  "text" : "RT @WordLo: European word translator http:\/\/t.co\/NTMI8DbHT7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/pinterest.com\" rel=\"nofollow\"\u003EPinterest\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 25, 47 ],
        "url" : "http:\/\/t.co\/NTMI8DbHT7",
        "expanded_url" : "http:\/\/pinterest.com\/pin\/445012006901388880\/",
        "display_url" : "pinterest.com\/pin\/4450120069\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "422683874263859200",
    "text" : "European word translator http:\/\/t.co\/NTMI8DbHT7",
    "id" : 422683874263859200,
    "created_at" : "2014-01-13 10:57:43 +0000",
    "user" : {
      "name" : "Maria Pia Montoro",
      "screen_name" : "WordLo",
      "protected" : false,
      "id_str" : "190569306",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/660652749881782272\/BB1P3zUR_normal.jpg",
      "id" : 190569306,
      "verified" : false
    }
  },
  "id" : 422685142722019328,
  "created_at" : "2014-01-13 11:02:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KevinHodgson",
      "screen_name" : "dogtrax",
      "indices" : [ 3, 11 ],
      "id_str" : "13307352",
      "id" : 13307352
    }, {
      "name" : "William Ian O'Byrne",
      "screen_name" : "wiobyrne",
      "indices" : [ 130, 139 ],
      "id_str" : "88676762",
      "id" : 88676762
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "walkmyworld",
      "indices" : [ 50, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/fM6cfBxuu4",
      "expanded_url" : "http:\/\/visibletweets.com\/#query=%23walkmyworld&animation=1",
      "display_url" : "visibletweets.com\/#query=%23walk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422677778962853888",
  "text" : "RT @dogtrax: Wow \u2014 the Visible Tweets search with #walkmyworld hashtag is stunning to watch unfold. http:\/\/t.co\/fM6cfBxuu4 Thanks @wiobyrne\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "William Ian O'Byrne",
        "screen_name" : "wiobyrne",
        "indices" : [ 117, 126 ],
        "id_str" : "88676762",
        "id" : 88676762
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "walkmyworld",
        "indices" : [ 37, 49 ]
      } ],
      "urls" : [ {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/fM6cfBxuu4",
        "expanded_url" : "http:\/\/visibletweets.com\/#query=%23walkmyworld&animation=1",
        "display_url" : "visibletweets.com\/#query=%23walk\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "422676524584562688",
    "text" : "Wow \u2014 the Visible Tweets search with #walkmyworld hashtag is stunning to watch unfold. http:\/\/t.co\/fM6cfBxuu4 Thanks @wiobyrne for that one",
    "id" : 422676524584562688,
    "created_at" : "2014-01-13 10:28:31 +0000",
    "user" : {
      "name" : "KevinHodgson",
      "screen_name" : "dogtrax",
      "protected" : false,
      "id_str" : "13307352",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629952065809334272\/BKXrDkoi_normal.png",
      "id" : 13307352,
      "verified" : false
    }
  },
  "id" : 422677778962853888,
  "created_at" : "2014-01-13 10:33:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Costas Gabrielatos",
      "screen_name" : "congabonga",
      "indices" : [ 0, 11 ],
      "id_str" : "187484412",
      "id" : 187484412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422669794073382912",
  "geo" : { },
  "id_str" : "422675358681268224",
  "in_reply_to_user_id" : 187484412,
  "text" : "@congabonga that's an interesting site, thx, oh and good joke :)",
  "id" : 422675358681268224,
  "in_reply_to_status_id" : 422669794073382912,
  "created_at" : "2014-01-13 10:23:53 +0000",
  "in_reply_to_screen_name" : "congabonga",
  "in_reply_to_user_id_str" : "187484412",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "indices" : [ 3, 14 ],
      "id_str" : "152051625",
      "id" : 152051625
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "s679",
      "indices" : [ 87, 92 ]
    }, {
      "text" : "mla14",
      "indices" : [ 93, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/RlCGrdHnoo",
      "expanded_url" : "http:\/\/bit.ly\/1gKrRyo",
      "display_url" : "bit.ly\/1gKrRyo"
    } ]
  },
  "geo" : { },
  "id_str" : "422410164382494721",
  "text" : "RT @heatherfro: When \u201CLife Hacking\u201D Is Really White Privilege http:\/\/t.co\/RlCGrdHnoo   #s679 #mla14",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "s679",
        "indices" : [ 71, 76 ]
      }, {
        "text" : "mla14",
        "indices" : [ 77, 83 ]
      } ],
      "urls" : [ {
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/RlCGrdHnoo",
        "expanded_url" : "http:\/\/bit.ly\/1gKrRyo",
        "display_url" : "bit.ly\/1gKrRyo"
      } ]
    },
    "geo" : { },
    "id_str" : "422387445942849536",
    "text" : "When \u201CLife Hacking\u201D Is Really White Privilege http:\/\/t.co\/RlCGrdHnoo   #s679 #mla14",
    "id" : 422387445942849536,
    "created_at" : "2014-01-12 15:19:49 +0000",
    "user" : {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "protected" : false,
      "id_str" : "152051625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/688767277022494720\/KMrzOBc1_normal.jpg",
      "id" : 152051625,
      "verified" : false
    }
  },
  "id" : 422410164382494721,
  "created_at" : "2014-01-12 16:50:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katy Davies",
      "screen_name" : "katysdavies",
      "indices" : [ 0, 12 ],
      "id_str" : "2919479375",
      "id" : 2919479375
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422348404329418752",
  "geo" : { },
  "id_str" : "422350025193046017",
  "in_reply_to_user_id" : 357785615,
  "text" : "@KatySDavies great to see you there :)",
  "id" : 422350025193046017,
  "in_reply_to_status_id" : 422348404329418752,
  "created_at" : "2014-01-12 12:51:07 +0000",
  "in_reply_to_screen_name" : "KatyELT",
  "in_reply_to_user_id_str" : "357785615",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katy Davies",
      "screen_name" : "katysdavies",
      "indices" : [ 0, 12 ],
      "id_str" : "2919479375",
      "id" : 2919479375
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/5HVxk4F4IY",
      "expanded_url" : "https:\/\/plus.google.com\/communities\/101266284417587206243",
      "display_url" : "plus.google.com\/communities\/10\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "422346266173902849",
  "geo" : { },
  "id_str" : "422347058851237888",
  "in_reply_to_user_id" : 357785615,
  "text" : "@KatySDavies no worries do consider joining corp ling community, if u on G+, for more of that thing :) https:\/\/t.co\/5HVxk4F4IY",
  "id" : 422347058851237888,
  "in_reply_to_status_id" : 422346266173902849,
  "created_at" : "2014-01-12 12:39:20 +0000",
  "in_reply_to_screen_name" : "KatyELT",
  "in_reply_to_user_id_str" : "357785615",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katy Davies",
      "screen_name" : "katysdavies",
      "indices" : [ 0, 12 ],
      "id_str" : "2919479375",
      "id" : 2919479375
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/OH4ulgiTQc",
      "expanded_url" : "https:\/\/plus.google.com\/104940199413423400545\/posts\/JLrgVniSjW5",
      "display_url" : "plus.google.com\/10494019941342\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "422341881096179712",
  "geo" : { },
  "id_str" : "422345151747338240",
  "in_reply_to_user_id" : 357785615,
  "text" : "@KatySDavies enjoyed it a lot, fyi put a note about using VOICE (audio) corpus here https:\/\/t.co\/OH4ulgiTQc",
  "id" : 422345151747338240,
  "in_reply_to_status_id" : 422341881096179712,
  "created_at" : "2014-01-12 12:31:45 +0000",
  "in_reply_to_screen_name" : "KatyELT",
  "in_reply_to_user_id_str" : "357785615",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Randolph",
      "screen_name" : "TomTesol",
      "indices" : [ 0, 9 ],
      "id_str" : "1039673456",
      "id" : 1039673456
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422316773892177920",
  "geo" : { },
  "id_str" : "422338269091606528",
  "in_reply_to_user_id" : 1039673456,
  "text" : "@TomTesol my pleasure, enjoyed video, especially the 'dog eating' bit :)",
  "id" : 422338269091606528,
  "in_reply_to_status_id" : 422316773892177920,
  "created_at" : "2014-01-12 12:04:24 +0000",
  "in_reply_to_screen_name" : "TomTesol",
  "in_reply_to_user_id_str" : "1039673456",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C Rebuffet-Broadus",
      "screen_name" : "RebuffetBroadus",
      "indices" : [ 3, 19 ],
      "id_str" : "22635290",
      "id" : 22635290
    }, {
      "name" : "The-Round ELT",
      "screen_name" : "wetheround",
      "indices" : [ 114, 125 ],
      "id_str" : "281918842",
      "id" : 281918842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/NCuAaWN52D",
      "expanded_url" : "http:\/\/ow.ly\/2adceQ",
      "display_url" : "ow.ly\/2adceQ"
    } ]
  },
  "geo" : { },
  "id_str" : "422124021812305920",
  "text" : "RT @RebuffetBroadus: Great news! \"Experimental practice in ELT\" is now avail.!!! http:\/\/t.co\/NCuAaWN52D Thanks to @wetheround for helping u\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The-Round ELT",
        "screen_name" : "wetheround",
        "indices" : [ 93, 104 ],
        "id_str" : "281918842",
        "id" : 281918842
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/NCuAaWN52D",
        "expanded_url" : "http:\/\/ow.ly\/2adceQ",
        "display_url" : "ow.ly\/2adceQ"
      } ]
    },
    "geo" : { },
    "id_str" : "422105934660632576",
    "text" : "Great news! \"Experimental practice in ELT\" is now avail.!!! http:\/\/t.co\/NCuAaWN52D Thanks to @wetheround for helping us make it happen!!",
    "id" : 422105934660632576,
    "created_at" : "2014-01-11 20:41:11 +0000",
    "user" : {
      "name" : "C Rebuffet-Broadus",
      "screen_name" : "RebuffetBroadus",
      "protected" : false,
      "id_str" : "22635290",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3591430389\/aba53edd59922a0e1f786128e7797e4a_normal.jpeg",
      "id" : 22635290,
      "verified" : false
    }
  },
  "id" : 422124021812305920,
  "created_at" : "2014-01-11 21:53:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IHWO YL Advisor",
      "screen_name" : "IHWO_YL_Ts",
      "indices" : [ 3, 14 ],
      "id_str" : "52217770",
      "id" : 52217770
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ihdos14",
      "indices" : [ 68, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/ID1NMwntnw",
      "expanded_url" : "http:\/\/Www.just-the-word.com",
      "display_url" : "just-the-word.com"
    } ]
  },
  "geo" : { },
  "id_str" : "422042696732377088",
  "text" : "RT @IHWO_YL_Ts: http:\/\/t.co\/ID1NMwntnw easy to use corpora resource #ihdos14",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ihdos14",
        "indices" : [ 52, 60 ]
      } ],
      "urls" : [ {
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/ID1NMwntnw",
        "expanded_url" : "http:\/\/Www.just-the-word.com",
        "display_url" : "just-the-word.com"
      } ]
    },
    "geo" : { },
    "id_str" : "422021531477475328",
    "text" : "http:\/\/t.co\/ID1NMwntnw easy to use corpora resource #ihdos14",
    "id" : 422021531477475328,
    "created_at" : "2014-01-11 15:05:48 +0000",
    "user" : {
      "name" : "IHWO YL Advisor",
      "screen_name" : "IHWO_YL_Ts",
      "protected" : false,
      "id_str" : "52217770",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1744110638\/Blue_3D_blob_normal.jpg",
      "id" : 52217770,
      "verified" : false
    }
  },
  "id" : 422042696732377088,
  "created_at" : "2014-01-11 16:29:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katy Davies",
      "screen_name" : "katysdavies",
      "indices" : [ 3, 15 ],
      "id_str" : "2919479375",
      "id" : 2919479375
    }, {
      "name" : "Laura Patsko",
      "screen_name" : "lauraahaha",
      "indices" : [ 49, 60 ],
      "id_str" : "97957137",
      "id" : 97957137
    }, {
      "name" : "BCSeminars",
      "screen_name" : "BCseminars",
      "indices" : [ 96, 107 ],
      "id_str" : "134099962",
      "id" : 134099962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/FYh1oc6INV",
      "expanded_url" : "http:\/\/englishagenda.britishcouncil.org\/seminars\/practical-ideas-teaching-pronunciation-and-listening-english-lingua-franca-elf-context",
      "display_url" : "englishagenda.britishcouncil.org\/seminars\/pract\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421943327295287296",
  "text" : "RT @KatySDavies: Seminar on ELF pronunciation by @lauraahaha and myself is now online thanks to @BCseminars http:\/\/t.co\/FYh1oc6INV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Laura Patsko",
        "screen_name" : "lauraahaha",
        "indices" : [ 32, 43 ],
        "id_str" : "97957137",
        "id" : 97957137
      }, {
        "name" : "BCSeminars",
        "screen_name" : "BCseminars",
        "indices" : [ 79, 90 ],
        "id_str" : "134099962",
        "id" : 134099962
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/FYh1oc6INV",
        "expanded_url" : "http:\/\/englishagenda.britishcouncil.org\/seminars\/practical-ideas-teaching-pronunciation-and-listening-english-lingua-franca-elf-context",
        "display_url" : "englishagenda.britishcouncil.org\/seminars\/pract\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "421926321753559041",
    "text" : "Seminar on ELF pronunciation by @lauraahaha and myself is now online thanks to @BCseminars http:\/\/t.co\/FYh1oc6INV",
    "id" : 421926321753559041,
    "created_at" : "2014-01-11 08:47:28 +0000",
    "user" : {
      "name" : "Katy Simpson",
      "screen_name" : "KatyELT",
      "protected" : false,
      "id_str" : "357785615",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3525711987\/eeb01458d4856135c08edba71c938325_normal.jpeg",
      "id" : 357785615,
      "verified" : false
    }
  },
  "id" : 421943327295287296,
  "created_at" : "2014-01-11 09:55:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Asia Lindsay",
      "screen_name" : "AsiaLindsay",
      "indices" : [ 3, 15 ],
      "id_str" : "54717883",
      "id" : 54717883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/WGvI4EicWJ",
      "expanded_url" : "http:\/\/sassybirds.tumblr.com\/",
      "display_url" : "sassybirds.tumblr.com"
    } ]
  },
  "geo" : { },
  "id_str" : "421754696005844992",
  "text" : "RT @AsiaLindsay: New favourite tumblr- http:\/\/t.co\/WGvI4EicWJ. Very sassy indeed.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 22, 44 ],
        "url" : "http:\/\/t.co\/WGvI4EicWJ",
        "expanded_url" : "http:\/\/sassybirds.tumblr.com\/",
        "display_url" : "sassybirds.tumblr.com"
      } ]
    },
    "geo" : { },
    "id_str" : "421754303053709313",
    "text" : "New favourite tumblr- http:\/\/t.co\/WGvI4EicWJ. Very sassy indeed.",
    "id" : 421754303053709313,
    "created_at" : "2014-01-10 21:23:56 +0000",
    "user" : {
      "name" : "Asia Lindsay",
      "screen_name" : "AsiaLindsay",
      "protected" : false,
      "id_str" : "54717883",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587030637288251392\/VS_zfPF6_normal.jpg",
      "id" : 54717883,
      "verified" : false
    }
  },
  "id" : 421754696005844992,
  "created_at" : "2014-01-10 21:25:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pete Sanderson",
      "screen_name" : "LessonToolbox",
      "indices" : [ 3, 17 ],
      "id_str" : "1239302874",
      "id" : 1239302874
    }, {
      "name" : "Dr Ian McCormick",
      "screen_name" : "PostFilm",
      "indices" : [ 74, 83 ],
      "id_str" : "107943025",
      "id" : 107943025
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edchat",
      "indices" : [ 108, 115 ]
    }, {
      "text" : "satchat",
      "indices" : [ 116, 124 ]
    }, {
      "text" : "ukedchat",
      "indices" : [ 125, 134 ]
    }, {
      "text" : "PedagooFriday",
      "indices" : [ 135, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/XuPfcsSsqk",
      "expanded_url" : "http:\/\/twitter.com\/PostFilm\/status\/410781230204874752\/photo\/1",
      "display_url" : "pic.twitter.com\/XuPfcsSsqk"
    } ]
  },
  "geo" : { },
  "id_str" : "421731366011940864",
  "text" : "RT @LessonToolbox: WOW!!! Love this! Tube mapped sentence transitions via @PostFilm http:\/\/t.co\/XuPfcsSsqk\n\n#edchat #satchat #ukedchat #Ped\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dr Ian McCormick",
        "screen_name" : "PostFilm",
        "indices" : [ 55, 64 ],
        "id_str" : "107943025",
        "id" : 107943025
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "edchat",
        "indices" : [ 89, 96 ]
      }, {
        "text" : "satchat",
        "indices" : [ 97, 105 ]
      }, {
        "text" : "ukedchat",
        "indices" : [ 106, 115 ]
      }, {
        "text" : "PedagooFriday",
        "indices" : [ 116, 130 ]
      } ],
      "urls" : [ {
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/XuPfcsSsqk",
        "expanded_url" : "http:\/\/twitter.com\/PostFilm\/status\/410781230204874752\/photo\/1",
        "display_url" : "pic.twitter.com\/XuPfcsSsqk"
      } ]
    },
    "geo" : { },
    "id_str" : "421725366555013121",
    "text" : "WOW!!! Love this! Tube mapped sentence transitions via @PostFilm http:\/\/t.co\/XuPfcsSsqk\n\n#edchat #satchat #ukedchat #PedagooFriday",
    "id" : 421725366555013121,
    "created_at" : "2014-01-10 19:28:57 +0000",
    "user" : {
      "name" : "Pete Sanderson",
      "screen_name" : "LessonToolbox",
      "protected" : false,
      "id_str" : "1239302874",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/664922957127524352\/UMdIHllp_normal.jpg",
      "id" : 1239302874,
      "verified" : false
    }
  },
  "id" : 421731366011940864,
  "created_at" : "2014-01-10 19:52:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 64, 72 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/soLzUaow2l",
      "expanded_url" : "http:\/\/youtu.be\/6YA5UdVhhsI",
      "display_url" : "youtu.be\/6YA5UdVhhsI"
    } ]
  },
  "geo" : { },
  "id_str" : "421681287724670977",
  "text" : "Stewart Lee - Anti-Islamic Stand Up: http:\/\/t.co\/soLzUaow2l via @youtube",
  "id" : 421681287724670977,
  "created_at" : "2014-01-10 16:33:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nelson Flores",
      "screen_name" : "nelsonlflores",
      "indices" : [ 98, 112 ],
      "id_str" : "248343882",
      "id" : 248343882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/Yjj48OG3PH",
      "expanded_url" : "http:\/\/wp.me\/p45k2O-1y",
      "display_url" : "wp.me\/p45k2O-1y"
    } ]
  },
  "geo" : { },
  "id_str" : "421678514635407360",
  "text" : "How Education Reform Suffers from the Soft Bigotry of Good Intentions: http:\/\/t.co\/Yjj48OG3PH via @nelsonlflores",
  "id" : 421678514635407360,
  "created_at" : "2014-01-10 16:22:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 0, 11 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "421637232735170560",
  "geo" : { },
  "id_str" : "421659024073826304",
  "in_reply_to_user_id" : 87902543,
  "text" : "@tornhalves no worries, glossed abit o yr art in a talk i was at on what r teachers for? - to wit making students less afraid of the void :)",
  "id" : 421659024073826304,
  "in_reply_to_status_id" : 421637232735170560,
  "created_at" : "2014-01-10 15:05:20 +0000",
  "in_reply_to_screen_name" : "tornhalves",
  "in_reply_to_user_id_str" : "87902543",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "421622819361812481",
  "geo" : { },
  "id_str" : "421625547261628416",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@teflskeptic i bet getting asked about learning styles was all downhilll from there for u?",
  "id" : 421625547261628416,
  "in_reply_to_status_id" : 421622819361812481,
  "created_at" : "2014-01-10 12:52:18 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "421620114304155648",
  "text" : "A la rentr\u00E9e je vais pouvoir fangirler sur Sherlock avec ma prof d'anglais renforc\u00E9e. C'est une des choses qui me motivent pour la reprise.",
  "id" : 421620114304155648,
  "created_at" : "2014-01-10 12:30:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemma Lunn",
      "screen_name" : "GemL1",
      "indices" : [ 0, 6 ],
      "id_str" : "486146568",
      "id" : 486146568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "421608437462859776",
  "geo" : { },
  "id_str" : "421611117433991168",
  "in_reply_to_user_id" : 486146568,
  "text" : "@GemL1 congrats! :)",
  "id" : 421611117433991168,
  "in_reply_to_status_id" : 421608437462859776,
  "created_at" : "2014-01-10 11:54:58 +0000",
  "in_reply_to_screen_name" : "GemL1",
  "in_reply_to_user_id_str" : "486146568",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Divya Madhavan",
      "screen_name" : "_divyamadhavan",
      "indices" : [ 0, 15 ],
      "id_str" : "408492806",
      "id" : 408492806
    }, {
      "name" : "Jeremy Harmer",
      "screen_name" : "Harmerj",
      "indices" : [ 16, 24 ],
      "id_str" : "21094022",
      "id" : 21094022
    }, {
      "name" : "centraleparis",
      "screen_name" : "centraleparis",
      "indices" : [ 25, 39 ],
      "id_str" : "3384225669",
      "id" : 3384225669
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "421610038298689536",
  "geo" : { },
  "id_str" : "421610613987504129",
  "in_reply_to_user_id" : 408492806,
  "text" : "@_divyamadhavan @Harmerj @centraleparis thanks for correcting twitter addresses :)",
  "id" : 421610613987504129,
  "in_reply_to_status_id" : 421610038298689536,
  "created_at" : "2014-01-10 11:52:58 +0000",
  "in_reply_to_screen_name" : "_divyamadhavan",
  "in_reply_to_user_id_str" : "408492806",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacob Appelbaum",
      "screen_name" : "ioerror",
      "indices" : [ 0, 8 ],
      "id_str" : "13862172",
      "id" : 13862172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420460401965281280",
  "geo" : { },
  "id_str" : "421610197824454656",
  "in_reply_to_user_id" : 13862172,
  "text" : "@ioerror good report though in video no recognition that all domestic laws useless when you have 5eyes program",
  "id" : 421610197824454656,
  "in_reply_to_status_id" : 420460401965281280,
  "created_at" : "2014-01-10 11:51:18 +0000",
  "in_reply_to_screen_name" : "ioerror",
  "in_reply_to_user_id_str" : "13862172",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacob Appelbaum",
      "screen_name" : "ioerror",
      "indices" : [ 3, 11 ],
      "id_str" : "13862172",
      "id" : 13862172
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FBI",
      "indices" : [ 26, 30 ]
    }, {
      "text" : "COINTELPRO",
      "indices" : [ 31, 42 ]
    }, {
      "text" : "heroes",
      "indices" : [ 72, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/E7G1EJK3TG",
      "expanded_url" : "http:\/\/www.nytimes.com\/2014\/01\/07\/us\/burglars-who-took-on-fbi-abandon-shadows.html",
      "display_url" : "nytimes.com\/2014\/01\/07\/us\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421592141836849152",
  "text" : "RT @ioerror: This is huge #FBI #COINTELPRO news: http:\/\/t.co\/E7G1EJK3TG #heroes",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FBI",
        "indices" : [ 13, 17 ]
      }, {
        "text" : "COINTELPRO",
        "indices" : [ 18, 29 ]
      }, {
        "text" : "heroes",
        "indices" : [ 59, 66 ]
      } ],
      "urls" : [ {
        "indices" : [ 36, 58 ],
        "url" : "http:\/\/t.co\/E7G1EJK3TG",
        "expanded_url" : "http:\/\/www.nytimes.com\/2014\/01\/07\/us\/burglars-who-took-on-fbi-abandon-shadows.html",
        "display_url" : "nytimes.com\/2014\/01\/07\/us\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "420460401965281280",
    "text" : "This is huge #FBI #COINTELPRO news: http:\/\/t.co\/E7G1EJK3TG #heroes",
    "id" : 420460401965281280,
    "created_at" : "2014-01-07 07:42:26 +0000",
    "user" : {
      "name" : "Jacob Appelbaum",
      "screen_name" : "ioerror",
      "protected" : false,
      "id_str" : "13862172",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/510535958807068672\/Xk-mjIxF_normal.jpeg",
      "id" : 13862172,
      "verified" : false
    }
  },
  "id" : 421592141836849152,
  "created_at" : "2014-01-10 10:39:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JP Vergne",
      "screen_name" : "PirateOrg",
      "indices" : [ 3, 13 ],
      "id_str" : "605856131",
      "id" : 605856131
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 125, 143 ],
      "url" : "http:\/\/t.co\/e0SK3fiSAJ",
      "expanded_url" : "http:\/\/brokenlibrarian.org\/bitcoin",
      "display_url" : "brokenlibrarian.org\/bitcoin"
    } ]
  },
  "geo" : { },
  "id_str" : "421590853980012544",
  "text" : "RT @PirateOrg: BITCOIN: 'not anonymous, not free, not instant and not convenient. It will never go into widespread use' &gt; http:\/\/t.co\/e0SK3\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/manageflitter.com\" rel=\"nofollow\"\u003EManageFlitter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/e0SK3fiSAJ",
        "expanded_url" : "http:\/\/brokenlibrarian.org\/bitcoin",
        "display_url" : "brokenlibrarian.org\/bitcoin"
      } ]
    },
    "geo" : { },
    "id_str" : "420600972440637442",
    "text" : "BITCOIN: 'not anonymous, not free, not instant and not convenient. It will never go into widespread use' &gt; http:\/\/t.co\/e0SK3fiSAJ",
    "id" : 420600972440637442,
    "created_at" : "2014-01-07 17:01:00 +0000",
    "user" : {
      "name" : "JP Vergne",
      "screen_name" : "PirateOrg",
      "protected" : false,
      "id_str" : "605856131",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/647020803503034368\/FHStVVF7_normal.jpg",
      "id" : 605856131,
      "verified" : false
    }
  },
  "id" : 421590853980012544,
  "created_at" : "2014-01-10 10:34:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/6GivyywFDF",
      "expanded_url" : "http:\/\/members5.boardhost.com\/medialens\/msg\/1389348235.html",
      "display_url" : "members5.boardhost.com\/medialens\/msg\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421585409626218496",
  "text" : "White House links latest extreme US weather event to climate change http:\/\/t.co\/6GivyywFDF",
  "id" : 421585409626218496,
  "created_at" : "2014-01-10 10:12:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Seymour",
      "screen_name" : "leninology",
      "indices" : [ 3, 14 ],
      "id_str" : "15557246",
      "id" : 15557246
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/Ak7dzbi5CD",
      "expanded_url" : "http:\/\/revolutionarysocialism.tumblr.com\/post\/72691539793\/mark-duggan-was-executed-we-still-believe-that",
      "display_url" : "revolutionarysocialism.tumblr.com\/post\/726915397\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421584909497806848",
  "text" : "RT @leninology: Mark Duggan was executed.  We still believe that. http:\/\/t.co\/Ak7dzbi5CD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 72 ],
        "url" : "http:\/\/t.co\/Ak7dzbi5CD",
        "expanded_url" : "http:\/\/revolutionarysocialism.tumblr.com\/post\/72691539793\/mark-duggan-was-executed-we-still-believe-that",
        "display_url" : "revolutionarysocialism.tumblr.com\/post\/726915397\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "421435115357863936",
    "text" : "Mark Duggan was executed.  We still believe that. http:\/\/t.co\/Ak7dzbi5CD",
    "id" : 421435115357863936,
    "created_at" : "2014-01-10 00:15:36 +0000",
    "user" : {
      "name" : "Richard Seymour",
      "screen_name" : "leninology",
      "protected" : false,
      "id_str" : "15557246",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762344914583781377\/UDn8tMrp_normal.jpg",
      "id" : 15557246,
      "verified" : false
    }
  },
  "id" : 421584909497806848,
  "created_at" : "2014-01-10 10:10:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ela Wassell",
      "screen_name" : "elawassell",
      "indices" : [ 0, 11 ],
      "id_str" : "51157050",
      "id" : 51157050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "421554795238137856",
  "geo" : { },
  "id_str" : "421582769706135553",
  "in_reply_to_user_id" : 51157050,
  "text" : "@elawassell i agree, though the bile does make a change from circle-jerk that dominates socialmedia :\/",
  "id" : 421582769706135553,
  "in_reply_to_status_id" : 421554795238137856,
  "created_at" : "2014-01-10 10:02:19 +0000",
  "in_reply_to_screen_name" : "elawassell",
  "in_reply_to_user_id_str" : "51157050",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daria Addiscombe",
      "screen_name" : "ihdubai",
      "indices" : [ 0, 8 ],
      "id_str" : "3414090479",
      "id" : 3414090479
    }, {
      "name" : "Adi Rajan",
      "screen_name" : "adi_rajan",
      "indices" : [ 9, 19 ],
      "id_str" : "1011323449",
      "id" : 1011323449
    }, {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 20, 31 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "421575261159956480",
  "geo" : { },
  "id_str" : "421579350698254336",
  "in_reply_to_user_id" : 49906646,
  "text" : "@IHDubai @adi_rajan @hughdellar not giving up Natural Language Processing shurely ;)",
  "id" : 421579350698254336,
  "in_reply_to_status_id" : 421575261159956480,
  "created_at" : "2014-01-10 09:48:44 +0000",
  "in_reply_to_screen_name" : "SMARTERtcm",
  "in_reply_to_user_id_str" : "49906646",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luca Marchiori",
      "screen_name" : "chuechebueb",
      "indices" : [ 0, 12 ],
      "id_str" : "1334451956",
      "id" : 1334451956
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "421577524993200130",
  "geo" : { },
  "id_str" : "421578898267045888",
  "in_reply_to_user_id" : 1334451956,
  "text" : "@chuechebueb yr welcome it a neat tool, was nice to meet you in person yesterday even if briefly :)",
  "id" : 421578898267045888,
  "in_reply_to_status_id" : 421577524993200130,
  "created_at" : "2014-01-10 09:46:56 +0000",
  "in_reply_to_screen_name" : "chuechebueb",
  "in_reply_to_user_id_str" : "1334451956",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/Ra6cqBweey",
      "expanded_url" : "http:\/\/www.dialectatlas.mun.ca\/app\/atlas\/",
      "display_url" : "dialectatlas.mun.ca\/app\/atlas\/"
    }, {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/DOGeFeww2y",
      "expanded_url" : "http:\/\/allthingslinguistic.com\/post\/72706484576\/the-dialect-atlas-of-newfoundland-and-labrador",
      "display_url" : "allthingslinguistic.com\/post\/727064845\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421576237241208832",
  "text" : "The Dialect Atlas of Newfoundland and Labrador http:\/\/t.co\/Ra6cqBweey H\/T http:\/\/t.co\/DOGeFeww2y",
  "id" : 421576237241208832,
  "created_at" : "2014-01-10 09:36:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Simpson",
      "screen_name" : "yearinthelifeof",
      "indices" : [ 3, 19 ],
      "id_str" : "78543378",
      "id" : 78543378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/HNXX2sDDDl",
      "expanded_url" : "http:\/\/goo.gl\/fb\/qrHD5",
      "display_url" : "goo.gl\/fb\/qrHD5"
    } ]
  },
  "geo" : { },
  "id_str" : "421575173733892096",
  "text" : "RT @yearinthelifeof: Class is going great and I want to find out why! http:\/\/t.co\/HNXX2sDDDl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/HNXX2sDDDl",
        "expanded_url" : "http:\/\/goo.gl\/fb\/qrHD5",
        "display_url" : "goo.gl\/fb\/qrHD5"
      } ]
    },
    "geo" : { },
    "id_str" : "421351063825162240",
    "text" : "Class is going great and I want to find out why! http:\/\/t.co\/HNXX2sDDDl",
    "id" : 421351063825162240,
    "created_at" : "2014-01-09 18:41:36 +0000",
    "user" : {
      "name" : "Adam Simpson",
      "screen_name" : "yearinthelifeof",
      "protected" : false,
      "id_str" : "78543378",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3631509371\/58d02c1bbadd12516d17de635652eb05_normal.jpeg",
      "id" : 78543378,
      "verified" : false
    }
  },
  "id" : 421575173733892096,
  "created_at" : "2014-01-10 09:32:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Randolph",
      "screen_name" : "TomTesol",
      "indices" : [ 3, 12 ],
      "id_str" : "1039673456",
      "id" : 1039673456
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "keltchat",
      "indices" : [ 101, 110 ]
    }, {
      "text" : "elt",
      "indices" : [ 111, 115 ]
    }, {
      "text" : "TESOL",
      "indices" : [ 116, 122 ]
    }, {
      "text" : "EbookEVO",
      "indices" : [ 123, 132 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/XOQqoqRfSE",
      "expanded_url" : "http:\/\/wp.me\/p3bfrS-px",
      "display_url" : "wp.me\/p3bfrS-px"
    } ]
  },
  "geo" : { },
  "id_str" : "421557597519773696",
  "text" : "RT @TomTesol: Video Eleven Things! No reading required! Multimedia! Hilarity! http:\/\/t.co\/XOQqoqRfSE #keltchat #elt #TESOL #EbookEVO #eltch\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "keltchat",
        "indices" : [ 87, 96 ]
      }, {
        "text" : "elt",
        "indices" : [ 97, 101 ]
      }, {
        "text" : "TESOL",
        "indices" : [ 102, 108 ]
      }, {
        "text" : "EbookEVO",
        "indices" : [ 109, 118 ]
      }, {
        "text" : "eltchat",
        "indices" : [ 119, 127 ]
      } ],
      "urls" : [ {
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/XOQqoqRfSE",
        "expanded_url" : "http:\/\/wp.me\/p3bfrS-px",
        "display_url" : "wp.me\/p3bfrS-px"
      } ]
    },
    "geo" : { },
    "id_str" : "421474302169329665",
    "text" : "Video Eleven Things! No reading required! Multimedia! Hilarity! http:\/\/t.co\/XOQqoqRfSE #keltchat #elt #TESOL #EbookEVO #eltchat",
    "id" : 421474302169329665,
    "created_at" : "2014-01-10 02:51:18 +0000",
    "user" : {
      "name" : "Tom Randolph",
      "screen_name" : "TomTesol",
      "protected" : false,
      "id_str" : "1039673456",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3032150495\/9652e9187ec1987380345c59bfce97b9_normal.jpeg",
      "id" : 1039673456,
      "verified" : false
    }
  },
  "id" : 421557597519773696,
  "created_at" : "2014-01-10 08:22:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josette LeBlanc",
      "screen_name" : "JosetteLB",
      "indices" : [ 3, 13 ],
      "id_str" : "33503694",
      "id" : 33503694
    }, {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 18, 30 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "keltchat",
      "indices" : [ 134, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/CvgJNF87MK",
      "expanded_url" : "http:\/\/lizzieserene.wordpress.com\/2014\/01\/10\/poetry-on-a-topic\/",
      "display_url" : "lizzieserene.wordpress.com\/2014\/01\/10\/poe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421556995133820928",
  "text" : "RT @JosetteLB: MT @AnneHendler \"Poetry on a Topic\" http:\/\/t.co\/CvgJNF87MK A great example of how even the shyest Ss have a lot to say #kelt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
        "screen_name" : "AnneHendler",
        "indices" : [ 3, 15 ],
        "id_str" : "525013404",
        "id" : 525013404
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "keltchat",
        "indices" : [ 119, 128 ]
      } ],
      "urls" : [ {
        "indices" : [ 36, 58 ],
        "url" : "http:\/\/t.co\/CvgJNF87MK",
        "expanded_url" : "http:\/\/lizzieserene.wordpress.com\/2014\/01\/10\/poetry-on-a-topic\/",
        "display_url" : "lizzieserene.wordpress.com\/2014\/01\/10\/poe\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "421329777434165249",
    "geo" : { },
    "id_str" : "421504143044255744",
    "in_reply_to_user_id" : 525013404,
    "text" : "MT @AnneHendler \"Poetry on a Topic\" http:\/\/t.co\/CvgJNF87MK A great example of how even the shyest Ss have a lot to say #keltchat",
    "id" : 421504143044255744,
    "in_reply_to_status_id" : 421329777434165249,
    "created_at" : "2014-01-10 04:49:53 +0000",
    "in_reply_to_screen_name" : "AnneHendler",
    "in_reply_to_user_id_str" : "525013404",
    "user" : {
      "name" : "Josette LeBlanc",
      "screen_name" : "JosetteLB",
      "protected" : false,
      "id_str" : "33503694",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/692220258900377601\/uWdvfCiP_normal.jpg",
      "id" : 33503694,
      "verified" : false
    }
  },
  "id" : 421556995133820928,
  "created_at" : "2014-01-10 08:19:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anna Loseva",
      "screen_name" : "AnnLoseva",
      "indices" : [ 3, 13 ],
      "id_str" : "38822368",
      "id" : 38822368
    }, {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 76, 87 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/3v2i2FyKfx",
      "expanded_url" : "http:\/\/wp.me\/p4dmjk-7z",
      "display_url" : "wp.me\/p4dmjk-7z"
    } ]
  },
  "geo" : { },
  "id_str" : "421556079764717568",
  "text" : "RT @AnnLoseva: Don't know a word...get ridda it! http:\/\/t.co\/3v2i2FyKfx via @kevchanwow",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kevin Stein",
        "screen_name" : "kevchanwow",
        "indices" : [ 61, 72 ],
        "id_str" : "144663117",
        "id" : 144663117
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 34, 56 ],
        "url" : "http:\/\/t.co\/3v2i2FyKfx",
        "expanded_url" : "http:\/\/wp.me\/p4dmjk-7z",
        "display_url" : "wp.me\/p4dmjk-7z"
      } ]
    },
    "geo" : { },
    "id_str" : "421540370615250944",
    "text" : "Don't know a word...get ridda it! http:\/\/t.co\/3v2i2FyKfx via @kevchanwow",
    "id" : 421540370615250944,
    "created_at" : "2014-01-10 07:13:50 +0000",
    "user" : {
      "name" : "Anna Loseva",
      "screen_name" : "AnnLoseva",
      "protected" : false,
      "id_str" : "38822368",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/767034457748541441\/VJrp4Jie_normal.jpg",
      "id" : 38822368,
      "verified" : false
    }
  },
  "id" : 421556079764717568,
  "created_at" : "2014-01-10 08:16:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "indices" : [ 0, 16 ],
      "id_str" : "1326508478",
      "id" : 1326508478
    }, {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 17, 28 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "421550533694865408",
  "geo" : { },
  "id_str" : "421554700538753024",
  "in_reply_to_user_id" : 1326508478,
  "text" : "@CorpusSocialSci @lexicoloco the spreadsheet of freq adjectives given in article is useful when using film genres in a language lesson :)",
  "id" : 421554700538753024,
  "in_reply_to_status_id" : 421550533694865408,
  "created_at" : "2014-01-10 08:10:47 +0000",
  "in_reply_to_screen_name" : "CorpusSocialSci",
  "in_reply_to_user_id_str" : "1326508478",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ela Wassell",
      "screen_name" : "elawassell",
      "indices" : [ 0, 11 ],
      "id_str" : "51157050",
      "id" : 51157050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "421392295233990656",
  "geo" : { },
  "id_str" : "421397479804792833",
  "in_reply_to_user_id" : 51157050,
  "text" : "@elawassell another one to copy paste before Geoff edits out good bits :)",
  "id" : 421397479804792833,
  "in_reply_to_status_id" : 421392295233990656,
  "created_at" : "2014-01-09 21:46:03 +0000",
  "in_reply_to_screen_name" : "elawassell",
  "in_reply_to_user_id_str" : "51157050",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00F6rg Lohrer",
      "screen_name" : "empeiria",
      "indices" : [ 45, 54 ],
      "id_str" : "19389942",
      "id" : 19389942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/iYJfsILHkB",
      "expanded_url" : "http:\/\/www.rete-mirabile.net\/lernen\/feedback-lernen-wachsen-duerfen",
      "display_url" : "rete-mirabile.net\/lernen\/feedbac\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421393639898505216",
  "text" : "Austin's Butterfly http:\/\/t.co\/iYJfsILHkB HT @empeiria",
  "id" : 421393639898505216,
  "created_at" : "2014-01-09 21:30:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/LqPR4f2rvW",
      "expanded_url" : "http:\/\/us2.campaign-archive1.com\/?u=c7a8d4ceb5662e31f6e5b2607&id=8859bbec82&e=a1b7b1d723",
      "display_url" : "us2.campaign-archive1.com\/?u=c7a8d4ceb56\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421386305030090752",
  "text" : "RT @johnwhilley: MIT PhD Candidate Sues CIA for the Records Surrounding the 1962 Arrest of Nelson Mandela http:\/\/t.co\/LqPR4f2rvW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/LqPR4f2rvW",
        "expanded_url" : "http:\/\/us2.campaign-archive1.com\/?u=c7a8d4ceb5662e31f6e5b2607&id=8859bbec82&e=a1b7b1d723",
        "display_url" : "us2.campaign-archive1.com\/?u=c7a8d4ceb56\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "421296362202742785",
    "text" : "MIT PhD Candidate Sues CIA for the Records Surrounding the 1962 Arrest of Nelson Mandela http:\/\/t.co\/LqPR4f2rvW",
    "id" : 421296362202742785,
    "created_at" : "2014-01-09 15:04:14 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 421386305030090752,
  "created_at" : "2014-01-09 21:01:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Revolution News",
      "screen_name" : "NewsRevo",
      "indices" : [ 3, 12 ],
      "id_str" : "47862165",
      "id" : 47862165
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Gefahrengebiet",
      "indices" : [ 101, 116 ]
    }, {
      "text" : "WirSindAlleHamburg",
      "indices" : [ 117, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/Mx6F1V4H5M",
      "expanded_url" : "http:\/\/bit.ly\/1lOLhQw",
      "display_url" : "bit.ly\/1lOLhQw"
    } ]
  },
  "geo" : { },
  "id_str" : "421385057790857217",
  "text" : "RT @NewsRevo: Day 3 of \u201CDanger zone\u201D Protests in Hamburg, Police Lies Exposed http:\/\/t.co\/Mx6F1V4H5M #Gefahrengebiet #WirSindAlleHamburg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Gefahrengebiet",
        "indices" : [ 87, 102 ]
      }, {
        "text" : "WirSindAlleHamburg",
        "indices" : [ 103, 122 ]
      } ],
      "urls" : [ {
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/Mx6F1V4H5M",
        "expanded_url" : "http:\/\/bit.ly\/1lOLhQw",
        "display_url" : "bit.ly\/1lOLhQw"
      } ]
    },
    "geo" : { },
    "id_str" : "421236329997811713",
    "text" : "Day 3 of \u201CDanger zone\u201D Protests in Hamburg, Police Lies Exposed http:\/\/t.co\/Mx6F1V4H5M #Gefahrengebiet #WirSindAlleHamburg",
    "id" : 421236329997811713,
    "created_at" : "2014-01-09 11:05:41 +0000",
    "user" : {
      "name" : "Revolution News",
      "screen_name" : "NewsRevo",
      "protected" : false,
      "id_str" : "47862165",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/573963111272570880\/lpNfTgyM_normal.jpeg",
      "id" : 47862165,
      "verified" : false
    }
  },
  "id" : 421385057790857217,
  "created_at" : "2014-01-09 20:56:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Divya Madhavan",
      "screen_name" : "_divyamadhavan",
      "indices" : [ 28, 43 ],
      "id_str" : "408492806",
      "id" : 408492806
    }, {
      "name" : "jeremyH",
      "screen_name" : "jeremyH",
      "indices" : [ 49, 57 ],
      "id_str" : "11094062",
      "id" : 11094062
    }, {
      "name" : "ECOLE CENTRALE",
      "screen_name" : "ecolecentrale",
      "indices" : [ 61, 75 ],
      "id_str" : "117709037",
      "id" : 117709037
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/421314019186970624\/photo\/1",
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/drkHL7VJzr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BdjO3jhIMAAp90X.jpg",
      "id_str" : "421314018981457920",
      "id" : 421314018981457920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdjO3jhIMAAp90X.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/drkHL7VJzr"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "421314019186970624",
  "text" : "action research graffiti by @_divyamadhavan with @Jeremyh at @ecolecentrale http:\/\/t.co\/drkHL7VJzr",
  "id" : 421314019186970624,
  "created_at" : "2014-01-09 16:14:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Harmer",
      "screen_name" : "Harmerj",
      "indices" : [ 15, 23 ],
      "id_str" : "21094022",
      "id" : 21094022
    }, {
      "name" : "ECOLE CENTRALE",
      "screen_name" : "ecolecentrale",
      "indices" : [ 67, 81 ],
      "id_str" : "117709037",
      "id" : 117709037
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "421276937215291392",
  "text" : "about to watch @Harmerj in a room you can draw on and moving walls @ecolecentrale",
  "id" : 421276937215291392,
  "created_at" : "2014-01-09 13:47:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 3, 14 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "liberation",
      "indices" : [ 89, 100 ]
    }, {
      "text" : "pedagogy",
      "indices" : [ 101, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/lURqDioib7",
      "expanded_url" : "http:\/\/bit.ly\/1hyHUzN",
      "display_url" : "bit.ly\/1hyHUzN"
    } ]
  },
  "geo" : { },
  "id_str" : "421259037330931713",
  "text" : "RT @tornhalves: The child IS an empty vessel - a defence of the blank slate in education #liberation #pedagogy http:\/\/t.co\/lURqDioib7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "liberation",
        "indices" : [ 73, 84 ]
      }, {
        "text" : "pedagogy",
        "indices" : [ 85, 94 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/lURqDioib7",
        "expanded_url" : "http:\/\/bit.ly\/1hyHUzN",
        "display_url" : "bit.ly\/1hyHUzN"
      } ]
    },
    "geo" : { },
    "id_str" : "421248802813517824",
    "text" : "The child IS an empty vessel - a defence of the blank slate in education #liberation #pedagogy http:\/\/t.co\/lURqDioib7",
    "id" : 421248802813517824,
    "created_at" : "2014-01-09 11:55:15 +0000",
    "user" : {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "protected" : false,
      "id_str" : "87902543",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3059742703\/1d3c7a2052db17d29644fa0a49af6480_normal.jpeg",
      "id" : 87902543,
      "verified" : false
    }
  },
  "id" : 421259037330931713,
  "created_at" : "2014-01-09 12:35:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Botanical Linguist",
      "screen_name" : "GrowMyEnglish",
      "indices" : [ 0, 14 ],
      "id_str" : "21865567",
      "id" : 21865567
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "421214680082702336",
  "geo" : { },
  "id_str" : "421218402418454528",
  "in_reply_to_user_id" : 21865567,
  "text" : "@GrowMyEnglish hi be interested in source for frequency list you used for this?",
  "id" : 421218402418454528,
  "in_reply_to_status_id" : 421214680082702336,
  "created_at" : "2014-01-09 09:54:27 +0000",
  "in_reply_to_screen_name" : "GrowMyEnglish",
  "in_reply_to_user_id_str" : "21865567",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "421120286054809600",
  "geo" : { },
  "id_str" : "421204034108674049",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt thanks tyson! :)",
  "id" : 421204034108674049,
  "in_reply_to_status_id" : 421120286054809600,
  "created_at" : "2014-01-09 08:57:21 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "421098108865359873",
  "geo" : { },
  "id_str" : "421203983839920128",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow cheers kev :)",
  "id" : 421203983839920128,
  "in_reply_to_status_id" : 421098108865359873,
  "created_at" : "2014-01-09 08:57:09 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Divya Madhavan",
      "screen_name" : "_divyamadhavan",
      "indices" : [ 0, 15 ],
      "id_str" : "408492806",
      "id" : 408492806
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "421203914566807553",
  "in_reply_to_user_id" : 408492806,
  "text" : "@_divyamadhavan many thanks for RT :)",
  "id" : 421203914566807553,
  "created_at" : "2014-01-09 08:56:53 +0000",
  "in_reply_to_screen_name" : "_divyamadhavan",
  "in_reply_to_user_id_str" : "408492806",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Canan Aktu\u011F",
      "screen_name" : "Jananstwit",
      "indices" : [ 0, 11 ],
      "id_str" : "179676661",
      "id" : 179676661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/OAmRHrhUls",
      "expanded_url" : "http:\/\/translationhandout.wordpress.com\/2011\/10\/25\/hello-world\/",
      "display_url" : "translationhandout.wordpress.com\/2011\/10\/25\/hel\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "421013623209996288",
  "geo" : { },
  "id_str" : "421203794794266624",
  "in_reply_to_user_id" : 179676661,
  "text" : "@Jananstwit true, makes a good blog title though :) there's a good biblio w\/ some pdfs in this area by Philip Kerr http:\/\/t.co\/OAmRHrhUls",
  "id" : 421203794794266624,
  "in_reply_to_status_id" : 421013623209996288,
  "created_at" : "2014-01-09 08:56:24 +0000",
  "in_reply_to_screen_name" : "Jananstwit",
  "in_reply_to_user_id_str" : "179676661",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 76, 92 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/0P4gGZvd0V",
      "expanded_url" : "http:\/\/wp.me\/pbMLY-GB",
      "display_url" : "wp.me\/pbMLY-GB"
    } ]
  },
  "geo" : { },
  "id_str" : "420994410923323392",
  "text" : "A New Way to Teach Grammar: The Bilingual Option http:\/\/t.co\/0P4gGZvd0V via @wordpressdotcom",
  "id" : 420994410923323392,
  "created_at" : "2014-01-08 19:04:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anna Loseva",
      "screen_name" : "AnnLoseva",
      "indices" : [ 0, 10 ],
      "id_str" : "38822368",
      "id" : 38822368
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "flashmobELT",
      "indices" : [ 36, 48 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420952946168188928",
  "geo" : { },
  "id_str" : "420954032060907520",
  "in_reply_to_user_id" : 38822368,
  "text" : "@AnnLoseva thanks doubly to you and #flashmobELT :)",
  "id" : 420954032060907520,
  "in_reply_to_status_id" : 420952946168188928,
  "created_at" : "2014-01-08 16:23:56 +0000",
  "in_reply_to_screen_name" : "AnnLoseva",
  "in_reply_to_user_id_str" : "38822368",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Lee",
      "screen_name" : "desktopenglish",
      "indices" : [ 0, 15 ],
      "id_str" : "345925613",
      "id" : 345925613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420941962435260416",
  "geo" : { },
  "id_str" : "420953717844615168",
  "in_reply_to_user_id" : 345925613,
  "text" : "@desktopenglish commented :) thanks interesting post",
  "id" : 420953717844615168,
  "in_reply_to_status_id" : 420941962435260416,
  "created_at" : "2014-01-08 16:22:41 +0000",
  "in_reply_to_screen_name" : "desktopenglish",
  "in_reply_to_user_id_str" : "345925613",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "indices" : [ 3, 15 ],
      "id_str" : "849729062",
      "id" : 849729062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusMOOC",
      "indices" : [ 37, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "420953280697860096",
  "text" : "RT @TonyMcEnery: Great news! For the #corpusMOOC we have permission to give away the book Corpus Annotation for free on the course! Thanks \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpusMOOC",
        "indices" : [ 20, 31 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "420946995058970624",
    "text" : "Great news! For the #corpusMOOC we have permission to give away the book Corpus Annotation for free on the course! Thanks Routledge!",
    "id" : 420946995058970624,
    "created_at" : "2014-01-08 15:55:59 +0000",
    "user" : {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "protected" : false,
      "id_str" : "849729062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2676020930\/a4a1f40d56b447c9dfca1d7b9be4f4b4_normal.jpeg",
      "id" : 849729062,
      "verified" : false
    }
  },
  "id" : 420953280697860096,
  "created_at" : "2014-01-08 16:20:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 87, 103 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/woHBXR3tfH",
      "expanded_url" : "http:\/\/wp.me\/pBm7c-21T",
      "display_url" : "wp.me\/pBm7c-21T"
    } ]
  },
  "geo" : { },
  "id_str" : "420939938092179456",
  "text" : "Why online teaching requires rigorous training (Mary Burns) http:\/\/t.co\/woHBXR3tfH via @wordpressdotcom",
  "id" : 420939938092179456,
  "created_at" : "2014-01-08 15:27:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/COvdxNd8y4",
      "expanded_url" : "http:\/\/www.theatlantic.com\/health\/archive\/2014\/01\/the-shape-of-your-head-and-the-shape-of-your-mind\/282578\/",
      "display_url" : "theatlantic.com\/health\/archive\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "420836415552118784",
  "geo" : { },
  "id_str" : "420938967547002881",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@teflskeptic not much more then 21stC phrenology? http:\/\/t.co\/COvdxNd8y4",
  "id" : 420938967547002881,
  "in_reply_to_status_id" : 420836415552118784,
  "created_at" : "2014-01-08 15:24:05 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyler Schnoebelen",
      "screen_name" : "TSchnoebelen",
      "indices" : [ 3, 16 ],
      "id_str" : "14969147",
      "id" : 14969147
    }, {
      "name" : "Will Potter",
      "screen_name" : "will_potter",
      "indices" : [ 39, 51 ],
      "id_str" : "18195997",
      "id" : 18195997
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/will_potter\/status\/417669447793401856\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/REvmvqJQSI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BcvcJl2CYAAAzx-.png",
      "id_str" : "417669447797596160",
      "id" : 417669447797596160,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BcvcJl2CYAAAzx-.png",
      "sizes" : [ {
        "h" : 619,
        "resize" : "fit",
        "w" : 985
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 377,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 214,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 619,
        "resize" : "fit",
        "w" : 985
      } ],
      "display_url" : "pic.twitter.com\/REvmvqJQSI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "420938143479894016",
  "text" : "RT @TSchnoebelen: RT @m_l_mcginnis: RT @will_potter: Woody Guthrie's New Year's resolutions, #33: \"Wake Up And Fight\" http:\/\/t.co\/REvmvqJQSI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Will Potter",
        "screen_name" : "will_potter",
        "indices" : [ 21, 33 ],
        "id_str" : "18195997",
        "id" : 18195997
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/will_potter\/status\/417669447793401856\/photo\/1",
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/REvmvqJQSI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BcvcJl2CYAAAzx-.png",
        "id_str" : "417669447797596160",
        "id" : 417669447797596160,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BcvcJl2CYAAAzx-.png",
        "sizes" : [ {
          "h" : 619,
          "resize" : "fit",
          "w" : 985
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 377,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 214,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 619,
          "resize" : "fit",
          "w" : 985
        } ],
        "display_url" : "pic.twitter.com\/REvmvqJQSI"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "420746720524660737",
    "text" : "RT @m_l_mcginnis: RT @will_potter: Woody Guthrie's New Year's resolutions, #33: \"Wake Up And Fight\" http:\/\/t.co\/REvmvqJQSI",
    "id" : 420746720524660737,
    "created_at" : "2014-01-08 02:40:09 +0000",
    "user" : {
      "name" : "Tyler Schnoebelen",
      "screen_name" : "TSchnoebelen",
      "protected" : false,
      "id_str" : "14969147",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/604427674203779072\/Y4t_NODB_normal.jpg",
      "id" : 14969147,
      "verified" : false
    }
  },
  "id" : 420938143479894016,
  "created_at" : "2014-01-08 15:20:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420933626109239297",
  "geo" : { },
  "id_str" : "420936326024671232",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler thanks you too, though not thinking too \"productive\" rightnow as got a ranty post building related to open access corpora!",
  "id" : 420936326024671232,
  "in_reply_to_status_id" : 420933626109239297,
  "created_at" : "2014-01-08 15:13:35 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 15, 27 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420930694924095488",
  "geo" : { },
  "id_str" : "420931768238088192",
  "in_reply_to_user_id" : 525013404,
  "text" : "happy new year @AnneHendler thanks very much and to past likes on posts, always forget to thanks peeps for likes!",
  "id" : 420931768238088192,
  "in_reply_to_status_id" : 420930694924095488,
  "created_at" : "2014-01-08 14:55:28 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "420930004273209345",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin cheers for RT mike :) happy new year!",
  "id" : 420930004273209345,
  "created_at" : "2014-01-08 14:48:28 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420928116245024768",
  "geo" : { },
  "id_str" : "420929592589684736",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@teflskeptic summary? another link? dont want to pay for paper :)",
  "id" : 420929592589684736,
  "in_reply_to_status_id" : 420928116245024768,
  "created_at" : "2014-01-08 14:46:50 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Natallia Novikava",
      "screen_name" : "Natashetta",
      "indices" : [ 16, 27 ],
      "id_str" : "56308635",
      "id" : 56308635
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420919476993798144",
  "geo" : { },
  "id_str" : "420928851816894464",
  "in_reply_to_user_id" : 56308635,
  "text" : "thanks natallia @Natashetta i think that's a 1st for me! someone tweeting before me tweeting :) happy new year",
  "id" : 420928851816894464,
  "in_reply_to_status_id" : 420919476993798144,
  "created_at" : "2014-01-08 14:43:53 +0000",
  "in_reply_to_screen_name" : "Natashetta",
  "in_reply_to_user_id_str" : "56308635",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "English & Media Ctr",
      "screen_name" : "EngMediaCentre",
      "indices" : [ 0, 15 ],
      "id_str" : "432590539",
      "id" : 432590539
    }, {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "indices" : [ 16, 28 ],
      "id_str" : "849729062",
      "id" : 849729062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hopenotoverstepng",
      "indices" : [ 121, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/gnEFqIwmh8",
      "expanded_url" : "https:\/\/plus.google.com\/u\/0\/communities\/101266284417587206243",
      "display_url" : "plus.google.com\/u\/0\/communitie\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "420905785753743360",
  "geo" : { },
  "id_str" : "420918314513072128",
  "in_reply_to_user_id" : 432590539,
  "text" : "@EngMediaCentre @TonyMcEnery for lang teachers w\/ google u may be int in this comm https:\/\/t.co\/gnEFqIwmh8 as discusshub #hopenotoverstepng",
  "id" : 420918314513072128,
  "in_reply_to_status_id" : 420905785753743360,
  "created_at" : "2014-01-08 14:02:01 +0000",
  "in_reply_to_screen_name" : "EngMediaCentre",
  "in_reply_to_user_id_str" : "432590539",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maria Pia Montoro",
      "screen_name" : "WordLo",
      "indices" : [ 0, 7 ],
      "id_str" : "190569306",
      "id" : 190569306
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420913944543252481",
  "geo" : { },
  "id_str" : "420915166276894720",
  "in_reply_to_user_id" : 190569306,
  "text" : "@WordLo the NK dictator is horrendous but what i find more horrendous is the preaching about how horrendous he is by our horrendous govs :\/",
  "id" : 420915166276894720,
  "in_reply_to_status_id" : 420913944543252481,
  "created_at" : "2014-01-08 13:49:30 +0000",
  "in_reply_to_screen_name" : "WordLo",
  "in_reply_to_user_id_str" : "190569306",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maria Pia Montoro",
      "screen_name" : "WordLo",
      "indices" : [ 0, 7 ],
      "id_str" : "190569306",
      "id" : 190569306
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420911840533557248",
  "geo" : { },
  "id_str" : "420913785361022976",
  "in_reply_to_user_id" : 190569306,
  "text" : "@WordLo satire works best when looking at one's own government i find, each to their own :)",
  "id" : 420913785361022976,
  "in_reply_to_status_id" : 420911840533557248,
  "created_at" : "2014-01-08 13:44:01 +0000",
  "in_reply_to_screen_name" : "WordLo",
  "in_reply_to_user_id_str" : "190569306",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 58, 74 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/ojzVApuUjt",
      "expanded_url" : "http:\/\/wp.me\/p4dmjk-75",
      "display_url" : "wp.me\/p4dmjk-75"
    } ]
  },
  "geo" : { },
  "id_str" : "420900175905714176",
  "text" : "The Fruit of Language Learning http:\/\/t.co\/ojzVApuUjt via @wordpressdotcom",
  "id" : 420900175905714176,
  "created_at" : "2014-01-08 12:49:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/y13tyIDfkz",
      "expanded_url" : "http:\/\/www.jonathan-cook.net\/2014-01-07\/israels-education-system-peddles-intolerance-and-lies\/",
      "display_url" : "jonathan-cook.net\/2014-01-07\/isr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "420890290690334720",
  "text" : "when...exposed to spoken Arabic at an early age...they hold far less hostile and stereotypical views of Arabs http:\/\/t.co\/y13tyIDfkz",
  "id" : 420890290690334720,
  "created_at" : "2014-01-08 12:10:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "William Ian O'Byrne",
      "screen_name" : "wiobyrne",
      "indices" : [ 3, 12 ],
      "id_str" : "88676762",
      "id" : 88676762
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/wiobyrne\/status\/420571863329554432\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/6IhDo6yjiV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BdYr4Z4IMAAUKNw.jpg",
      "id_str" : "420571863224692736",
      "id" : 420571863224692736,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdYr4Z4IMAAUKNw.jpg",
      "sizes" : [ {
        "h" : 619,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 413,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 234,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 619,
        "resize" : "fit",
        "w" : 900
      } ],
      "display_url" : "pic.twitter.com\/6IhDo6yjiV"
    } ],
    "hashtags" : [ {
      "text" : "WALKMYWORLD",
      "indices" : [ 87, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/QVzU7EgZXv",
      "expanded_url" : "http:\/\/bit.ly\/1bNCR6f",
      "display_url" : "bit.ly\/1bNCR6f"
    } ]
  },
  "geo" : { },
  "id_str" : "420723712951074817",
  "text" : "RT @wiobyrne: Come join us on a social media experiment for the next 10 weeks with the #WALKMYWORLD proj... http:\/\/t.co\/QVzU7EgZXv http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/friendsplus.me\" rel=\"nofollow\"\u003EFriends Me\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/wiobyrne\/status\/420571863329554432\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/6IhDo6yjiV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BdYr4Z4IMAAUKNw.jpg",
        "id_str" : "420571863224692736",
        "id" : 420571863224692736,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdYr4Z4IMAAUKNw.jpg",
        "sizes" : [ {
          "h" : 619,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 413,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 234,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 619,
          "resize" : "fit",
          "w" : 900
        } ],
        "display_url" : "pic.twitter.com\/6IhDo6yjiV"
      } ],
      "hashtags" : [ {
        "text" : "WALKMYWORLD",
        "indices" : [ 73, 85 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/QVzU7EgZXv",
        "expanded_url" : "http:\/\/bit.ly\/1bNCR6f",
        "display_url" : "bit.ly\/1bNCR6f"
      } ]
    },
    "geo" : { },
    "id_str" : "420571863329554432",
    "text" : "Come join us on a social media experiment for the next 10 weeks with the #WALKMYWORLD proj... http:\/\/t.co\/QVzU7EgZXv http:\/\/t.co\/6IhDo6yjiV",
    "id" : 420571863329554432,
    "created_at" : "2014-01-07 15:05:20 +0000",
    "user" : {
      "name" : "William Ian O'Byrne",
      "screen_name" : "wiobyrne",
      "protected" : false,
      "id_str" : "88676762",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/519580082\/twitter_normal.jpg",
      "id" : 88676762,
      "verified" : false
    }
  },
  "id" : 420723712951074817,
  "created_at" : "2014-01-08 01:08:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Claire Hart",
      "screen_name" : "claire_hart",
      "indices" : [ 3, 15 ],
      "id_str" : "96138105",
      "id" : 96138105
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iatefl",
      "indices" : [ 34, 41 ]
    }, {
      "text" : "besig",
      "indices" : [ 42, 48 ]
    } ],
    "urls" : [ {
      "indices" : [ 127, 140 ],
      "url" : "http:\/\/t.co\/8ChVqLADaV",
      "expanded_url" : "http:\/\/bit.ly\/19Q7duI",
      "display_url" : "bit.ly\/19Q7duI"
    } ]
  },
  "geo" : { },
  "id_str" : "420650930145873920",
  "text" : "RT @claire_hart: Register for our #iatefl #besig sponsored EVO session: Developing Business English Teachers starting 13th Jan http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "iatefl",
        "indices" : [ 17, 24 ]
      }, {
        "text" : "besig",
        "indices" : [ 25, 31 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/8ChVqLADaV",
        "expanded_url" : "http:\/\/bit.ly\/19Q7duI",
        "display_url" : "bit.ly\/19Q7duI"
      } ]
    },
    "geo" : { },
    "id_str" : "420624954221031424",
    "text" : "Register for our #iatefl #besig sponsored EVO session: Developing Business English Teachers starting 13th Jan http:\/\/t.co\/8ChVqLADaV",
    "id" : 420624954221031424,
    "created_at" : "2014-01-07 18:36:18 +0000",
    "user" : {
      "name" : "Claire Hart",
      "screen_name" : "claire_hart",
      "protected" : false,
      "id_str" : "96138105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2521304594\/55hwgymtz99dmu1ka8rt_normal.jpeg",
      "id" : 96138105,
      "verified" : false
    }
  },
  "id" : 420650930145873920,
  "created_at" : "2014-01-07 20:19:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420590738187898881",
  "geo" : { },
  "id_str" : "420593571989696512",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@teflskeptic 2008? where is your skepticism? :)",
  "id" : 420593571989696512,
  "in_reply_to_status_id" : 420590738187898881,
  "created_at" : "2014-01-07 16:31:36 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jobs at CUP",
      "screen_name" : "cambuprecruit",
      "indices" : [ 31, 45 ],
      "id_str" : "461918261",
      "id" : 461918261
    }, {
      "name" : "Ian Cook",
      "screen_name" : "idc74",
      "indices" : [ 46, 52 ],
      "id_str" : "290521216",
      "id" : 290521216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "420510215617122304",
  "geo" : { },
  "id_str" : "420512350509072385",
  "in_reply_to_user_id" : 461918261,
  "text" : "will corpus be open to public? @cambuprecruit @idc74",
  "id" : 420512350509072385,
  "in_reply_to_status_id" : 420510215617122304,
  "created_at" : "2014-01-07 11:08:51 +0000",
  "in_reply_to_screen_name" : "cambuprecruit",
  "in_reply_to_user_id_str" : "461918261",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Bunyan",
      "screen_name" : "bunyanchris",
      "indices" : [ 0, 12 ],
      "id_str" : "237402639",
      "id" : 237402639
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/wiPeD4dBRp",
      "expanded_url" : "http:\/\/eflnotes.wordpress.com\/2013\/09\/16\/getting-learner-data-for-vocabulary-activities-efcamdat\/",
      "display_url" : "eflnotes.wordpress.com\/2013\/09\/16\/get\u2026"
    }, {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/ytZZrodYgm",
      "expanded_url" : "http:\/\/eflnotes.wordpress.com\/2013\/09\/19\/counting-countability-efcamdat\/",
      "display_url" : "eflnotes.wordpress.com\/2013\/09\/19\/cou\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "420326846421807104",
  "geo" : { },
  "id_str" : "420328075570597888",
  "in_reply_to_user_id" : 237402639,
  "text" : "@bunyanchris fyi have written about efcamdat here http:\/\/t.co\/wiPeD4dBRp &amp; here http:\/\/t.co\/ytZZrodYgm good luck! maybe report back on G+?",
  "id" : 420328075570597888,
  "in_reply_to_status_id" : 420326846421807104,
  "created_at" : "2014-01-06 22:56:37 +0000",
  "in_reply_to_screen_name" : "bunyanchris",
  "in_reply_to_user_id_str" : "237402639",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Bunyan",
      "screen_name" : "bunyanchris",
      "indices" : [ 1, 13 ],
      "id_str" : "237402639",
      "id" : 237402639
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/miEYwUvmNN",
      "expanded_url" : "http:\/\/corpus.mml.cam.ac.uk\/efcamdat\/",
      "display_url" : "corpus.mml.cam.ac.uk\/efcamdat\/"
    }, {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/j7zfmUFABL",
      "expanded_url" : "https:\/\/plus.google.com\/104940199413423400545\/posts\/U6qCNhLgYwK",
      "display_url" : "plus.google.com\/10494019941342\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "420322308923084800",
  "geo" : { },
  "id_str" : "420325023950180352",
  "in_reply_to_user_id" : 237402639,
  "text" : ".@bunyanchris there is efcamdat http:\/\/t.co\/miEYwUvmNN; also search BAWE by reported nationality see comments here https:\/\/t.co\/j7zfmUFABL",
  "id" : 420325023950180352,
  "in_reply_to_status_id" : 420322308923084800,
  "created_at" : "2014-01-06 22:44:29 +0000",
  "in_reply_to_screen_name" : "bunyanchris",
  "in_reply_to_user_id_str" : "237402639",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Bunyan",
      "screen_name" : "bunyanchris",
      "indices" : [ 0, 12 ],
      "id_str" : "237402639",
      "id" : 237402639
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/gnEFqIwmh8",
      "expanded_url" : "https:\/\/plus.google.com\/u\/0\/communities\/101266284417587206243",
      "display_url" : "plus.google.com\/u\/0\/communitie\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "420293270947000320",
  "geo" : { },
  "id_str" : "420298509552590849",
  "in_reply_to_user_id" : 237402639,
  "text" : "@bunyanchris thanks for hat tip chris, btw if u have google account do consider joining corpus linguistics community https:\/\/t.co\/gnEFqIwmh8",
  "id" : 420298509552590849,
  "in_reply_to_status_id" : 420293270947000320,
  "created_at" : "2014-01-06 20:59:08 +0000",
  "in_reply_to_screen_name" : "bunyanchris",
  "in_reply_to_user_id_str" : "237402639",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419936549417918464",
  "geo" : { },
  "id_str" : "420162240927371264",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan i like the variety of activities in this vocab worksheet :)",
  "id" : 420162240927371264,
  "in_reply_to_status_id" : 419936549417918464,
  "created_at" : "2014-01-06 11:57:39 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "edulang",
      "screen_name" : "edulang",
      "indices" : [ 0, 8 ],
      "id_str" : "2877002950",
      "id" : 2877002950
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "anotherneoliberalmagazine",
      "indices" : [ 77, 103 ]
    }, {
      "text" : "frenchbashing",
      "indices" : [ 104, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/GOMZc9abj4",
      "expanded_url" : "http:\/\/www.economist.com\/news\/christmas-specials\/21591749-bleak-chic",
      "display_url" : "economist.com\/news\/christmas\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "420137800063660032",
  "geo" : { },
  "id_str" : "420143186074296320",
  "in_reply_to_user_id" : 236921161,
  "text" : "@Edulang and the French are miserable buggers to boot http:\/\/t.co\/GOMZc9abj4 #anotherneoliberalmagazine #frenchbashing",
  "id" : 420143186074296320,
  "in_reply_to_status_id" : 420137800063660032,
  "created_at" : "2014-01-06 10:41:56 +0000",
  "in_reply_to_screen_name" : "wordtov",
  "in_reply_to_user_id_str" : "236921161",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AllThingsLinguistic",
      "screen_name" : "AllThingsLing",
      "indices" : [ 0, 14 ],
      "id_str" : "857291268",
      "id" : 857291268
    }, {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 15, 26 ],
      "id_str" : "300734173",
      "id" : 300734173
    }, {
      "name" : "Language Log",
      "screen_name" : "LanguageLog",
      "indices" : [ 51, 63 ],
      "id_str" : "20148973",
      "id" : 20148973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419611887853383680",
  "geo" : { },
  "id_str" : "420133982894686208",
  "in_reply_to_user_id" : 857291268,
  "text" : "@AllThingsLing @lexicoloco interesting when latest @LanguageLog (Pullam) takes view because is not subordinating conjunction...",
  "id" : 420133982894686208,
  "in_reply_to_status_id" : 419611887853383680,
  "created_at" : "2014-01-06 10:05:21 +0000",
  "in_reply_to_screen_name" : "AllThingsLing",
  "in_reply_to_user_id_str" : "857291268",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Language Log",
      "screen_name" : "LanguageLog",
      "indices" : [ 3, 15 ],
      "id_str" : "20148973",
      "id" : 20148973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/k8xVdBiIqB",
      "expanded_url" : "http:\/\/bit.ly\/1i7RBm8",
      "display_url" : "bit.ly\/1i7RBm8"
    } ]
  },
  "geo" : { },
  "id_str" : "419907663208939524",
  "text" : "RT @LanguageLog: Because syntax: Many people will be somewhat surprised that the American Dialect Society's \"Word of the Year\" ... http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/k8xVdBiIqB",
        "expanded_url" : "http:\/\/bit.ly\/1i7RBm8",
        "display_url" : "bit.ly\/1i7RBm8"
      } ]
    },
    "geo" : { },
    "id_str" : "419894930060767232",
    "text" : "Because syntax: Many people will be somewhat surprised that the American Dialect Society's \"Word of the Year\" ... http:\/\/t.co\/k8xVdBiIqB",
    "id" : 419894930060767232,
    "created_at" : "2014-01-05 18:15:27 +0000",
    "user" : {
      "name" : "Language Log",
      "screen_name" : "LanguageLog",
      "protected" : false,
      "id_str" : "20148973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1011503265\/gerund2_normal.jpg",
      "id" : 20148973,
      "verified" : false
    }
  },
  "id" : 419907663208939524,
  "created_at" : "2014-01-05 19:06:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 3, 14 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 91, 95 ]
    }, {
      "text" : "tefl",
      "indices" : [ 96, 101 ]
    }, {
      "text" : "esol",
      "indices" : [ 102, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/hhcQe9o37l",
      "expanded_url" : "http:\/\/leoxicon.blogspot.com\/2014\/01\/news-quiz-2013-vocabulary.html",
      "display_url" : "leoxicon.blogspot.com\/2014\/01\/news-q\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419898680867844096",
  "text" : "RT @leoselivan: Follow up to the News Quiz 2013: Vocab activities: http:\/\/t.co\/hhcQe9o37l  #elt #tefl #esol",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "elt",
        "indices" : [ 75, 79 ]
      }, {
        "text" : "tefl",
        "indices" : [ 80, 85 ]
      }, {
        "text" : "esol",
        "indices" : [ 86, 91 ]
      } ],
      "urls" : [ {
        "indices" : [ 51, 73 ],
        "url" : "http:\/\/t.co\/hhcQe9o37l",
        "expanded_url" : "http:\/\/leoxicon.blogspot.com\/2014\/01\/news-quiz-2013-vocabulary.html",
        "display_url" : "leoxicon.blogspot.com\/2014\/01\/news-q\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "419896717857673216",
    "text" : "Follow up to the News Quiz 2013: Vocab activities: http:\/\/t.co\/hhcQe9o37l  #elt #tefl #esol",
    "id" : 419896717857673216,
    "created_at" : "2014-01-05 18:22:33 +0000",
    "user" : {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "protected" : false,
      "id_str" : "408365496",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/460546508601819136\/12ivDBb__normal.jpeg",
      "id" : 408365496,
      "verified" : false
    }
  },
  "id" : 419898680867844096,
  "created_at" : "2014-01-05 18:30:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "419897972793425920",
  "text" : "@mikejhldn that's one way to find plenty more fish... i'll get me coat...",
  "id" : 419897972793425920,
  "created_at" : "2014-01-05 18:27:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yuichiro Kobayashi",
      "screen_name" : "langstat",
      "indices" : [ 3, 12 ],
      "id_str" : "108896452",
      "id" : 108896452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/cPIubIxIP5",
      "expanded_url" : "http:\/\/elms.wordpress.com\/2008\/03\/04\/lexical-distance-among-languages-of-europe\/",
      "display_url" : "elms.wordpress.com\/2008\/03\/04\/lex\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419863226017673216",
  "text" : "RT @langstat: Lexical Distance Among the Languages of Europe \u00AB Etymologikon\u2122 http:\/\/t.co\/cPIubIxIP5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/cPIubIxIP5",
        "expanded_url" : "http:\/\/elms.wordpress.com\/2008\/03\/04\/lexical-distance-among-languages-of-europe\/",
        "display_url" : "elms.wordpress.com\/2008\/03\/04\/lex\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "419853552866312192",
    "text" : "Lexical Distance Among the Languages of Europe \u00AB Etymologikon\u2122 http:\/\/t.co\/cPIubIxIP5",
    "id" : 419853552866312192,
    "created_at" : "2014-01-05 15:31:02 +0000",
    "user" : {
      "name" : "Yuichiro Kobayashi",
      "screen_name" : "langstat",
      "protected" : false,
      "id_str" : "108896452",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1111159202\/profile_normal.gif",
      "id" : 108896452,
      "verified" : false
    }
  },
  "id" : 419863226017673216,
  "created_at" : "2014-01-05 16:09:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Honnibal",
      "screen_name" : "honnibal",
      "indices" : [ 98, 107 ],
      "id_str" : "14699038",
      "id" : 14699038
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 108, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/swvmRj7YOR",
      "expanded_url" : "http:\/\/cloze.it\/",
      "display_url" : "cloze.it"
    } ]
  },
  "geo" : { },
  "id_str" : "419854985606615040",
  "text" : "very interesting cloze generator web program (not free but good price) http:\/\/t.co\/swvmRj7YOR  by @honnibal #eltchat",
  "id" : 419854985606615040,
  "created_at" : "2014-01-05 15:36:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 89, 105 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/758b8N492Q",
      "expanded_url" : "http:\/\/wp.me\/p2KE8s-49j",
      "display_url" : "wp.me\/p2KE8s-49j"
    } ]
  },
  "geo" : { },
  "id_str" : "419603652639072256",
  "text" : "Longer phrases card games (TEFLtastic Classics Part Nineteen) http:\/\/t.co\/758b8N492Q via @wordpressdotcom",
  "id" : 419603652639072256,
  "created_at" : "2014-01-04 22:58:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 57, 73 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/5tzGWzcnpc",
      "expanded_url" : "http:\/\/wp.me\/pBWu-1wN",
      "display_url" : "wp.me\/pBWu-1wN"
    } ]
  },
  "geo" : { },
  "id_str" : "419394136026804224",
  "text" : "Gerund Movie Titles Revisited http:\/\/t.co\/5tzGWzcnpc via @wordpressdotcom",
  "id" : 419394136026804224,
  "created_at" : "2014-01-04 09:05:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darius Kazemi",
      "screen_name" : "tinysubversions",
      "indices" : [ 3, 19 ],
      "id_str" : "14475298",
      "id" : 14475298
    }, {
      "name" : "Daniel Benmergui",
      "screen_name" : "danielben",
      "indices" : [ 27, 37 ],
      "id_str" : "14239078",
      "id" : 14239078
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/TRcVVCZSrW",
      "expanded_url" : "http:\/\/bit.ly\/1gxIgng",
      "display_url" : "bit.ly\/1gxIgng"
    } ]
  },
  "geo" : { },
  "id_str" : "419236189867376641",
  "text" : "RT @tinysubversions: Uh so @danielben released one of those stripped-down RPGs that I love love love: http:\/\/t.co\/TRcVVCZSrW PS I love it",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Daniel Benmergui",
        "screen_name" : "danielben",
        "indices" : [ 6, 16 ],
        "id_str" : "14239078",
        "id" : 14239078
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/TRcVVCZSrW",
        "expanded_url" : "http:\/\/bit.ly\/1gxIgng",
        "display_url" : "bit.ly\/1gxIgng"
      } ]
    },
    "geo" : { },
    "id_str" : "419201722993868801",
    "text" : "Uh so @danielben released one of those stripped-down RPGs that I love love love: http:\/\/t.co\/TRcVVCZSrW PS I love it",
    "id" : 419201722993868801,
    "created_at" : "2014-01-03 20:20:53 +0000",
    "user" : {
      "name" : "Darius Kazemi",
      "screen_name" : "tinysubversions",
      "protected" : false,
      "id_str" : "14475298",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723889712772059136\/4T8a46Sp_normal.jpg",
      "id" : 14475298,
      "verified" : false
    }
  },
  "id" : 419236189867376641,
  "created_at" : "2014-01-03 22:37:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donald Clark",
      "screen_name" : "DonaldClark",
      "indices" : [ 3, 15 ],
      "id_str" : "1632891",
      "id" : 1632891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/iOJB4N8Pa8",
      "expanded_url" : "http:\/\/bit.ly\/1d1hrZB",
      "display_url" : "bit.ly\/1d1hrZB"
    }, {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/QoVxc2bbEM",
      "expanded_url" : "http:\/\/bit.ly\/1dr6mQ4",
      "display_url" : "bit.ly\/1dr6mQ4"
    } ]
  },
  "geo" : { },
  "id_str" : "419136254375391232",
  "text" : "RT @DonaldClark: Lamont on cliches in Rapid Authoring http:\/\/t.co\/iOJB4N8Pa8 Me on the same (spoof) http:\/\/t.co\/QoVxc2bbEM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 59 ],
        "url" : "http:\/\/t.co\/iOJB4N8Pa8",
        "expanded_url" : "http:\/\/bit.ly\/1d1hrZB",
        "display_url" : "bit.ly\/1d1hrZB"
      }, {
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/QoVxc2bbEM",
        "expanded_url" : "http:\/\/bit.ly\/1dr6mQ4",
        "display_url" : "bit.ly\/1dr6mQ4"
      } ]
    },
    "geo" : { },
    "id_str" : "418749943860301824",
    "text" : "Lamont on cliches in Rapid Authoring http:\/\/t.co\/iOJB4N8Pa8 Me on the same (spoof) http:\/\/t.co\/QoVxc2bbEM",
    "id" : 418749943860301824,
    "created_at" : "2014-01-02 14:25:41 +0000",
    "user" : {
      "name" : "Donald Clark",
      "screen_name" : "DonaldClark",
      "protected" : false,
      "id_str" : "1632891",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/513085530695663616\/BfWK4n6u_normal.jpeg",
      "id" : 1632891,
      "verified" : false
    }
  },
  "id" : 419136254375391232,
  "created_at" : "2014-01-03 16:00:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/KUtrKju2fq",
      "expanded_url" : "http:\/\/www.psychologytoday.com\/blog\/mental-mishaps\/201312\/photographs-and-memories",
      "display_url" : "psychologytoday.com\/blog\/mental-mi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419105580859412480",
  "text" : "Photographs and Memories | Psychology Today http:\/\/t.co\/KUtrKju2fq",
  "id" : 419105580859412480,
  "created_at" : "2014-01-03 13:58:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Seymour",
      "screen_name" : "leninology",
      "indices" : [ 3, 14 ],
      "id_str" : "15557246",
      "id" : 15557246
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/0HlzBC4hXU",
      "expanded_url" : "http:\/\/www.leninology.com\/2014\/01\/they-shit-in-doorways-dont-they.html",
      "display_url" : "leninology.com\/2014\/01\/they-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418692210058878977",
  "text" : "RT @leninology: They shit in doorways, don\u2019t they?  A brief archaeology of race-making scatology. http:\/\/t.co\/0HlzBC4hXU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/0HlzBC4hXU",
        "expanded_url" : "http:\/\/www.leninology.com\/2014\/01\/they-shit-in-doorways-dont-they.html",
        "display_url" : "leninology.com\/2014\/01\/they-s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "418338558840422400",
    "text" : "They shit in doorways, don\u2019t they?  A brief archaeology of race-making scatology. http:\/\/t.co\/0HlzBC4hXU",
    "id" : 418338558840422400,
    "created_at" : "2014-01-01 11:10:59 +0000",
    "user" : {
      "name" : "Richard Seymour",
      "screen_name" : "leninology",
      "protected" : false,
      "id_str" : "15557246",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762344914583781377\/UDn8tMrp_normal.jpg",
      "id" : 15557246,
      "verified" : false
    }
  },
  "id" : 418692210058878977,
  "created_at" : "2014-01-02 10:36:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adeline Koh",
      "screen_name" : "adelinekoh",
      "indices" : [ 3, 14 ],
      "id_str" : "10116502",
      "id" : 10116502
    }, {
      "name" : "(((Karen Kelsky)))",
      "screen_name" : "ProfessorIsIn",
      "indices" : [ 87, 101 ],
      "id_str" : "332967893",
      "id" : 332967893
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/6Fy5WiHA8p",
      "expanded_url" : "http:\/\/bit.ly\/Ju3Kpq",
      "display_url" : "bit.ly\/Ju3Kpq"
    } ]
  },
  "geo" : { },
  "id_str" : "418395338345828352",
  "text" : "RT @adelinekoh: How the Tenured are to the Job Market as White People are to Racism by @ProfessorIsIn http:\/\/t.co\/6Fy5WiHA8p",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.att.com\" rel=\"nofollow\"\u003EAT&T Browser Bar\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "(((Karen Kelsky)))",
        "screen_name" : "ProfessorIsIn",
        "indices" : [ 71, 85 ],
        "id_str" : "332967893",
        "id" : 332967893
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/6Fy5WiHA8p",
        "expanded_url" : "http:\/\/bit.ly\/Ju3Kpq",
        "display_url" : "bit.ly\/Ju3Kpq"
      } ]
    },
    "geo" : { },
    "id_str" : "418381000708980736",
    "text" : "How the Tenured are to the Job Market as White People are to Racism by @ProfessorIsIn http:\/\/t.co\/6Fy5WiHA8p",
    "id" : 418381000708980736,
    "created_at" : "2014-01-01 13:59:38 +0000",
    "user" : {
      "name" : "Adeline Koh",
      "screen_name" : "adelinekoh",
      "protected" : false,
      "id_str" : "10116502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/753773794364420096\/OGaOhPQy_normal.jpg",
      "id" : 10116502,
      "verified" : false
    }
  },
  "id" : 418395338345828352,
  "created_at" : "2014-01-01 14:56:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adi Rajan",
      "screen_name" : "adi_rajan",
      "indices" : [ 3, 13 ],
      "id_str" : "1011323449",
      "id" : 1011323449
    }, {
      "name" : "Ljiljana Havran",
      "screen_name" : "LjiljanaHavran",
      "indices" : [ 17, 32 ],
      "id_str" : "1395825290",
      "id" : 1395825290
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/oOSvemoRAX",
      "expanded_url" : "http:\/\/wp.me\/p3sNrs-5i",
      "display_url" : "wp.me\/p3sNrs-5i"
    } ]
  },
  "geo" : { },
  "id_str" : "418370075897647104",
  "text" : "RT @adi_rajan: . @LjiljanaHavran And here's my response to your 11 things blog challenge. http:\/\/t.co\/oOSvemoRAX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ljiljana Havran",
        "screen_name" : "LjiljanaHavran",
        "indices" : [ 2, 17 ],
        "id_str" : "1395825290",
        "id" : 1395825290
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/oOSvemoRAX",
        "expanded_url" : "http:\/\/wp.me\/p3sNrs-5i",
        "display_url" : "wp.me\/p3sNrs-5i"
      } ]
    },
    "geo" : { },
    "id_str" : "418253457863090176",
    "text" : ". @LjiljanaHavran And here's my response to your 11 things blog challenge. http:\/\/t.co\/oOSvemoRAX",
    "id" : 418253457863090176,
    "created_at" : "2014-01-01 05:32:49 +0000",
    "user" : {
      "name" : "Adi Rajan",
      "screen_name" : "adi_rajan",
      "protected" : false,
      "id_str" : "1011323449",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/692989458682085381\/JzeJM-e1_normal.jpg",
      "id" : 1011323449,
      "verified" : false
    }
  },
  "id" : 418370075897647104,
  "created_at" : "2014-01-01 13:16:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth Anne",
      "screen_name" : "eannegrenoble",
      "indices" : [ 0, 14 ],
      "id_str" : "19869781",
      "id" : 19869781
    }, {
      "name" : "Sue Annan",
      "screen_name" : "SueAnnan",
      "indices" : [ 15, 24 ],
      "id_str" : "136001411",
      "id" : 136001411
    }, {
      "name" : "MarisaConstantinides",
      "screen_name" : "Marisa_C",
      "indices" : [ 25, 34 ],
      "id_str" : "18272500",
      "id" : 18272500
    }, {
      "name" : "Shelly Sanchez",
      "screen_name" : "ShellTerrell",
      "indices" : [ 35, 48 ],
      "id_str" : "29655018",
      "id" : 29655018
    }, {
      "name" : "Anne Hodgson",
      "screen_name" : "annehodg",
      "indices" : [ 49, 58 ],
      "id_str" : "17589213",
      "id" : 17589213
    }, {
      "name" : "Lesley",
      "screen_name" : "cioccas",
      "indices" : [ 59, 67 ],
      "id_str" : "227474018",
      "id" : 227474018
    }, {
      "name" : "Cecilia Lemos",
      "screen_name" : "CeciELT",
      "indices" : [ 68, 76 ],
      "id_str" : "164527997",
      "id" : 164527997
    }, {
      "name" : "Carla Arena",
      "screen_name" : "carlaarena",
      "indices" : [ 77, 88 ],
      "id_str" : "6162732",
      "id" : 6162732
    }, {
      "name" : "Vicky Loras",
      "screen_name" : "vickyloras",
      "indices" : [ 89, 100 ],
      "id_str" : "95957241",
      "id" : 95957241
    }, {
      "name" : "Joe Dale",
      "screen_name" : "joedale",
      "indices" : [ 101, 109 ],
      "id_str" : "5923092",
      "id" : 5923092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "418338986139324416",
  "geo" : { },
  "id_str" : "418368947629461504",
  "in_reply_to_user_id" : 19869781,
  "text" : "@eannegrenoble @SueAnnan @Marisa_C @ShellTerrell @annehodg @cioccas @CeciELT @carlaarena @vickyloras @joedale thks happy 2014 y'all :]",
  "id" : 418368947629461504,
  "in_reply_to_status_id" : 418338986139324416,
  "created_at" : "2014-01-01 13:11:44 +0000",
  "in_reply_to_screen_name" : "eannegrenoble",
  "in_reply_to_user_id_str" : "19869781",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    }, {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 13, 26 ],
      "id_str" : "88655243",
      "id" : 88655243
    }, {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 27, 43 ],
      "id_str" : "394053348",
      "id" : 394053348
    }, {
      "name" : "Matthew Walker",
      "screen_name" : "esltasks",
      "indices" : [ 44, 53 ],
      "id_str" : "358765485",
      "id" : 358765485
    }, {
      "name" : "Alex Grevett",
      "screen_name" : "breathyvowel",
      "indices" : [ 54, 67 ],
      "id_str" : "237547177",
      "id" : 237547177
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "418008049769406465",
  "geo" : { },
  "id_str" : "418238090830815232",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler @rosemerebard @michaelegriffin @esltasks @breathyvowel here's to 2014 commentary :)",
  "id" : 418238090830815232,
  "in_reply_to_status_id" : 418008049769406465,
  "created_at" : "2014-01-01 04:31:46 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
} ]