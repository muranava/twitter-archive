Grailbird.data.tweets_2013_04 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil Longwell",
      "screen_name" : "teacherphili",
      "indices" : [ 3, 16 ],
      "id_str" : "67863264",
      "id" : 67863264
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELTchat",
      "indices" : [ 123, 131 ]
    }, {
      "text" : "Corpora",
      "indices" : [ 132, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/ElfWEhgAU7",
      "expanded_url" : "http:\/\/bit.ly\/1293rCn",
      "display_url" : "bit.ly\/1293rCn"
    } ]
  },
  "geo" : { },
  "id_str" : "329259475632537601",
  "text" : "RT @teacherphili: Justed Posted &gt; Summary of 6 March chat about using Corpora in the Classroom http:\/\/t.co\/ElfWEhgAU7 - #ELTchat #Corpora",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELTchat",
        "indices" : [ 105, 113 ]
      }, {
        "text" : "Corpora",
        "indices" : [ 114, 122 ]
      } ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/ElfWEhgAU7",
        "expanded_url" : "http:\/\/bit.ly\/1293rCn",
        "display_url" : "bit.ly\/1293rCn"
      } ]
    },
    "geo" : { },
    "id_str" : "328848586496438274",
    "text" : "Justed Posted &gt; Summary of 6 March chat about using Corpora in the Classroom http:\/\/t.co\/ElfWEhgAU7 - #ELTchat #Corpora",
    "id" : 328848586496438274,
    "created_at" : "2013-04-29 12:29:47 +0000",
    "user" : {
      "name" : "Phil Longwell",
      "screen_name" : "teacherphili",
      "protected" : false,
      "id_str" : "67863264",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637201716295933952\/4n4DCm-q_normal.jpg",
      "id" : 67863264,
      "verified" : false
    }
  },
  "id" : 329259475632537601,
  "created_at" : "2013-04-30 15:42:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "markwarschauer",
      "screen_name" : "markwarschauer",
      "indices" : [ 3, 18 ],
      "id_str" : "17316060",
      "id" : 17316060
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/9tpLDrxeHE",
      "expanded_url" : "http:\/\/nyti.ms\/10JEDqB",
      "display_url" : "nyti.ms\/10JEDqB"
    } ]
  },
  "geo" : { },
  "id_str" : "328976990218625024",
  "text" : "RT @markwarschauer: We blame failing schools &amp; the poor for trends that result from deepening income inequality and behavior of the ric\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/9tpLDrxeHE",
        "expanded_url" : "http:\/\/nyti.ms\/10JEDqB",
        "display_url" : "nyti.ms\/10JEDqB"
      } ]
    },
    "geo" : { },
    "id_str" : "328738515837927424",
    "text" : "We blame failing schools &amp; the poor for trends that result from deepening income inequality and behavior of the rich http:\/\/t.co\/9tpLDrxeHE",
    "id" : 328738515837927424,
    "created_at" : "2013-04-29 05:12:24 +0000",
    "user" : {
      "name" : "markwarschauer",
      "screen_name" : "markwarschauer",
      "protected" : false,
      "id_str" : "17316060",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535141210432622592\/ZXqkNrhW_normal.jpeg",
      "id" : 17316060,
      "verified" : false
    }
  },
  "id" : 328976990218625024,
  "created_at" : "2013-04-29 21:00:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Burcu Akyol",
      "screen_name" : "burcuakyol",
      "indices" : [ 0, 11 ],
      "id_str" : "25390789",
      "id" : 25390789
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "328061797900906496",
  "geo" : { },
  "id_str" : "328062065510064128",
  "in_reply_to_user_id" : 25390789,
  "text" : "@burcuakyol \/thumbs up\/ :)",
  "id" : 328062065510064128,
  "in_reply_to_status_id" : 328061797900906496,
  "created_at" : "2013-04-27 08:24:26 +0000",
  "in_reply_to_screen_name" : "burcuakyol",
  "in_reply_to_user_id_str" : "25390789",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 81, 89 ]
    }, {
      "text" : "corpuslinguistics",
      "indices" : [ 90, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/jR3VySExym",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-Aa",
      "display_url" : "wp.me\/pgHyE-Aa"
    } ]
  },
  "geo" : { },
  "id_str" : "328031014075125760",
  "text" : "a followup blog post StringNet \u2013 exploring will suit you http:\/\/t.co\/jR3VySExym  #eltchat #corpuslinguistics",
  "id" : 328031014075125760,
  "created_at" : "2013-04-27 06:21:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "327834771738730496",
  "geo" : { },
  "id_str" : "327849935800254465",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson wow 200 posts! double century nice :)",
  "id" : 327849935800254465,
  "in_reply_to_status_id" : 327834771738730496,
  "created_at" : "2013-04-26 18:21:30 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheConsultantsE",
      "screen_name" : "TheConsultantsE",
      "indices" : [ 0, 16 ],
      "id_str" : "13435662",
      "id" : 13435662
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "327734885672443904",
  "geo" : { },
  "id_str" : "327845466807095296",
  "in_reply_to_user_id" : 13435662,
  "text" : "@TheConsultantsE thanks for the share :) have a good w\/e",
  "id" : 327845466807095296,
  "in_reply_to_status_id" : 327734885672443904,
  "created_at" : "2013-04-26 18:03:45 +0000",
  "in_reply_to_screen_name" : "TheConsultantsE",
  "in_reply_to_user_id_str" : "13435662",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/816neckL90",
      "expanded_url" : "http:\/\/www.deltapublishing.co.uk\/titles\/methodology\/spotlight-on-learning-styles",
      "display_url" : "deltapublishing.co.uk\/titles\/methodo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "327674103916023808",
  "text" : "@EBEFL http:\/\/t.co\/816neckL90",
  "id" : 327674103916023808,
  "created_at" : "2013-04-26 06:42:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vicky Loras",
      "screen_name" : "vickyloras",
      "indices" : [ 0, 11 ],
      "id_str" : "95957241",
      "id" : 95957241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "327658139723919360",
  "geo" : { },
  "id_str" : "327658578448113664",
  "in_reply_to_user_id" : 95957241,
  "text" : "@vickyloras happy birthday vicki, have a good un!",
  "id" : 327658578448113664,
  "in_reply_to_status_id" : 327658139723919360,
  "created_at" : "2013-04-26 05:41:07 +0000",
  "in_reply_to_screen_name" : "vickyloras",
  "in_reply_to_user_id_str" : "95957241",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327657116326318081",
  "text" : "@EBEFL nice punchy article, did not the council of woo launch a woo book recently?",
  "id" : 327657116326318081,
  "created_at" : "2013-04-26 05:35:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "teachtheweb",
      "indices" : [ 107, 119 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 120, 128 ]
    }, {
      "text" : "efl",
      "indices" : [ 129, 133 ]
    }, {
      "text" : "tesol",
      "indices" : [ 134, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/IG8No6paMI",
      "expanded_url" : "https:\/\/plus.google.com\/u\/0\/communities\/103732709087976219248",
      "display_url" : "plus.google.com\/u\/0\/communitie\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "327532728356589568",
  "text" : "fancy using mozilla web projects in yr English class? join google+ ELT webmakers https:\/\/t.co\/IG8No6paMI \u2026 #teachtheweb #eltchat #efl #tesol",
  "id" : 327532728356589568,
  "created_at" : "2013-04-25 21:21:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susie CowleyHaselden",
      "screen_name" : "SusieCowley",
      "indices" : [ 0, 12 ],
      "id_str" : "613540409",
      "id" : 613540409
    }, {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 13, 21 ],
      "id_str" : "20650366",
      "id" : 20650366
    }, {
      "name" : "Sheri Rhodes",
      "screen_name" : "whistlepunch",
      "indices" : [ 22, 35 ],
      "id_str" : "3952041",
      "id" : 3952041
    }, {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "indices" : [ 36, 48 ],
      "id_str" : "192437743",
      "id" : 192437743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/H7GuDV7SHh",
      "expanded_url" : "http:\/\/folk.uib.no\/nfylk\/concordle\/",
      "display_url" : "folk.uib.no\/nfylk\/concordl\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "327526827318996992",
  "geo" : { },
  "id_str" : "327528173682167809",
  "in_reply_to_user_id" : 613540409,
  "text" : "@SusieCowley @seburnt @whistlepunch @nathanghall concordle http:\/\/t.co\/H7GuDV7SHh is okay and is open sourced so potential for int dev",
  "id" : 327528173682167809,
  "in_reply_to_status_id" : 327526827318996992,
  "created_at" : "2013-04-25 21:02:56 +0000",
  "in_reply_to_screen_name" : "SusieCowley",
  "in_reply_to_user_id_str" : "613540409",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Siva Vaidhyanathan",
      "screen_name" : "sivavaid",
      "indices" : [ 3, 12 ],
      "id_str" : "20406724",
      "id" : 20406724
    }, {
      "name" : "Slate",
      "screen_name" : "Slate",
      "indices" : [ 128, 134 ],
      "id_str" : "15164565",
      "id" : 15164565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/PaXolSMBp3",
      "expanded_url" : "http:\/\/www.slate.com\/articles\/technology\/future_tense\/2013\/04\/life_without_google_when_my_account_was_suspended_i_felt_like_i_d_been_dumped.html?utm_source=tw&utm_medium=sm&utm_campaign=button_toolbar",
      "display_url" : "slate.com\/articles\/techn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "327418377540874241",
  "text" : "RT @sivavaid: Somebody should write a book about dangers of Google dependency. Oh wait. Someone did. http:\/\/t.co\/PaXolSMBp3 via @slate",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Slate",
        "screen_name" : "Slate",
        "indices" : [ 114, 120 ],
        "id_str" : "15164565",
        "id" : 15164565
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/PaXolSMBp3",
        "expanded_url" : "http:\/\/www.slate.com\/articles\/technology\/future_tense\/2013\/04\/life_without_google_when_my_account_was_suspended_i_felt_like_i_d_been_dumped.html?utm_source=tw&utm_medium=sm&utm_campaign=button_toolbar",
        "display_url" : "slate.com\/articles\/techn\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "327156148421672960",
    "text" : "Somebody should write a book about dangers of Google dependency. Oh wait. Someone did. http:\/\/t.co\/PaXolSMBp3 via @slate",
    "id" : 327156148421672960,
    "created_at" : "2013-04-24 20:24:38 +0000",
    "user" : {
      "name" : "Siva Vaidhyanathan",
      "screen_name" : "sivavaid",
      "protected" : false,
      "id_str" : "20406724",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/767792599050649600\/aaiFpS9e_normal.jpg",
      "id" : 20406724,
      "verified" : false
    }
  },
  "id" : 327418377540874241,
  "created_at" : "2013-04-25 13:46:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C Rebuffet-Broadus",
      "screen_name" : "RebuffetBroadus",
      "indices" : [ 0, 16 ],
      "id_str" : "22635290",
      "id" : 22635290
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "327095402115502080",
  "geo" : { },
  "id_str" : "327350365534179328",
  "in_reply_to_user_id" : 22635290,
  "text" : "@RebuffetBroadus hope it helped; text is v. int esp the examples thgh authors admit bay area biased",
  "id" : 327350365534179328,
  "in_reply_to_status_id" : 327095402115502080,
  "created_at" : "2013-04-25 09:16:23 +0000",
  "in_reply_to_screen_name" : "RebuffetBroadus",
  "in_reply_to_user_id_str" : "22635290",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    }, {
      "name" : "Laura McInerney",
      "screen_name" : "miss_mcinerney",
      "indices" : [ 17, 32 ],
      "id_str" : "41098406",
      "id" : 41098406
    }, {
      "name" : "NARM August 25th",
      "screen_name" : "sulibreaks",
      "indices" : [ 33, 44 ],
      "id_str" : "39160416",
      "id" : 39160416
    }, {
      "name" : "Sam Shepherd",
      "screen_name" : "samshep",
      "indices" : [ 45, 53 ],
      "id_str" : "20146035",
      "id" : 20146035
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "teachtheweb",
      "indices" : [ 127, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/Q3FaLErj7F",
      "expanded_url" : "http:\/\/popcorn.webmadecontent.org\/yug",
      "display_url" : "popcorn.webmadecontent.org\/yug"
    } ]
  },
  "in_reply_to_status_id_str" : "326721047514738688",
  "geo" : { },
  "id_str" : "326839706585272320",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin @miss_mcinerney @sulibreaks @samshep my response to his hate school\/love education vid http:\/\/t.co\/Q3FaLErj7F #teachtheweb",
  "id" : 326839706585272320,
  "in_reply_to_status_id" : 326721047514738688,
  "created_at" : "2013-04-23 23:27:13 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C Rebuffet-Broadus",
      "screen_name" : "RebuffetBroadus",
      "indices" : [ 0, 16 ],
      "id_str" : "22635290",
      "id" : 22635290
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/BnM54AjRYV",
      "expanded_url" : "http:\/\/www.scribd.com\/doc\/29228151\/Communicating-the-American-Way",
      "display_url" : "scribd.com\/doc\/29228151\/C\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "326266223996325888",
  "geo" : { },
  "id_str" : "326347573386428419",
  "in_reply_to_user_id" : 22635290,
  "text" : "@RebuffetBroadus this is pretty gd http:\/\/t.co\/BnM54AjRYV thgh nothing specifically on prj mgmt",
  "id" : 326347573386428419,
  "in_reply_to_status_id" : 326266223996325888,
  "created_at" : "2013-04-22 14:51:39 +0000",
  "in_reply_to_screen_name" : "RebuffetBroadus",
  "in_reply_to_user_id_str" : "22635290",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/RrxregMUNk",
      "expanded_url" : "http:\/\/www.cardiff.ac.uk\/encap\/resources\/wray_jfl_2009.pdf",
      "display_url" : "cardiff.ac.uk\/encap\/resource\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "325671453984964608",
  "geo" : { },
  "id_str" : "325692131622653952",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan thx that lead me to this http:\/\/t.co\/RrxregMUNk",
  "id" : 325692131622653952,
  "in_reply_to_status_id" : 325671453984964608,
  "created_at" : "2013-04-20 19:27:09 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/Hd7YK5OcMD",
      "expanded_url" : "http:\/\/dial.academielouvain.be\/vital\/access\/services\/Download\/boreal:75732\/PDF_01",
      "display_url" : "dial.academielouvain.be\/vital\/access\/s\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "325640684851838976",
  "geo" : { },
  "id_str" : "325643976113803267",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan this article http:\/\/t.co\/Hd7YK5OcMD",
  "id" : 325643976113803267,
  "in_reply_to_status_id" : 325640684851838976,
  "created_at" : "2013-04-20 16:15:48 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "325577418733658112",
  "geo" : { },
  "id_str" : "325637267844628480",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan yes in the conclusion stating we know little about pre-fabs;wonder if there is recent work on what we know about them?",
  "id" : 325637267844628480,
  "in_reply_to_status_id" : 325577418733658112,
  "created_at" : "2013-04-20 15:49:09 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "325533583114657792",
  "geo" : { },
  "id_str" : "325565248859934720",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan thx for this i followed up that granger ref which notes caution in using prefabs do u know any more recent work on prefabs leo?",
  "id" : 325565248859934720,
  "in_reply_to_status_id" : 325533583114657792,
  "created_at" : "2013-04-20 11:02:58 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    }, {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 17, 32 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "325257250040078337",
  "geo" : { },
  "id_str" : "325563396420427776",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin @MrChrisJWilson thx fr the mighty twitter love, mike :) and for the mighty twitter pun, chris!",
  "id" : 325563396420427776,
  "in_reply_to_status_id" : 325257250040078337,
  "created_at" : "2013-04-20 10:55:37 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "325200361616969729",
  "geo" : { },
  "id_str" : "325562936875683841",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt cheers for sharing tyson :)",
  "id" : 325562936875683841,
  "in_reply_to_status_id" : 325200361616969729,
  "created_at" : "2013-04-20 10:53:47 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 11, 19 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324630935519768578",
  "text" : "thx all :) #eltchat",
  "id" : 324630935519768578,
  "created_at" : "2013-04-17 21:10:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 41, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324628063952465921",
  "text" : "Jun Liu seems to like the word \"Digital\" #eltchat",
  "id" : 324628063952465921,
  "created_at" : "2013-04-17 20:58:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 101, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324626950561886209",
  "text" : "maybe instead of content knowledge talk about general knowledge? tchers required enter pubquizzes :) #eltchat",
  "id" : 324626950561886209,
  "created_at" : "2013-04-17 20:54:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 97, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/dHaQSRGRR6",
      "expanded_url" : "http:\/\/bit.ly\/ZJGc7h",
      "display_url" : "bit.ly\/ZJGc7h"
    } ]
  },
  "geo" : { },
  "id_str" : "324625057785708544",
  "text" : "Jun Liu \"non directive approaches\" critiques of this fr beginner learners http:\/\/t.co\/dHaQSRGRR6 #eltchat",
  "id" : 324625057785708544,
  "created_at" : "2013-04-17 20:46:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MarisaConstantinides",
      "screen_name" : "Marisa_C",
      "indices" : [ 0, 9 ],
      "id_str" : "18272500",
      "id" : 18272500
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 118, 126 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324617195399290880",
  "geo" : { },
  "id_str" : "324618020444053505",
  "in_reply_to_user_id" : 18272500,
  "text" : "@Marisa_C Sept this year, the newsletter archive sme info \/\/www.epg-project.eu\/wp-content\/uploads\/Newsletter3_EPG.pdf #eltchat",
  "id" : 324618020444053505,
  "in_reply_to_status_id" : 324617195399290880,
  "created_at" : "2013-04-17 20:19:01 +0000",
  "in_reply_to_screen_name" : "Marisa_C",
  "in_reply_to_user_id_str" : "18272500",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 47, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/BIQGQammKv",
      "expanded_url" : "http:\/\/www.epg-project.eu\/grid\/",
      "display_url" : "epg-project.eu\/grid\/"
    } ]
  },
  "geo" : { },
  "id_str" : "324615722804342784",
  "text" : "European Profiling Grid http:\/\/t.co\/BIQGQammKv #eltchat",
  "id" : 324615722804342784,
  "created_at" : "2013-04-17 20:09:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 11, 19 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324614021997289472",
  "text" : "lurking :) #eltchat",
  "id" : 324614021997289472,
  "created_at" : "2013-04-17 20:03:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 78, 91 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/0NddwFufJu",
      "expanded_url" : "http:\/\/wp.me\/pKFOt-er",
      "display_url" : "wp.me\/pKFOt-er"
    } ]
  },
  "geo" : { },
  "id_str" : "324588001311203328",
  "text" : "Virtual Exchange Projects: Lessons learned so far: http:\/\/t.co\/0NddwFufJu via @rosemerebard",
  "id" : 324588001311203328,
  "created_at" : "2013-04-17 18:19:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 24, 40 ],
      "id_str" : "394053348",
      "id" : 394053348
    }, {
      "name" : "evanfrendo",
      "screen_name" : "evanfrendo",
      "indices" : [ 41, 52 ],
      "id_str" : "17589664",
      "id" : 17589664
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324584590754852864",
  "text" : "cheers for RT gentlemen @michaelegriffin @evanfrendo :)",
  "id" : 324584590754852864,
  "created_at" : "2013-04-17 18:06:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Olsen",
      "screen_name" : "JonathanAOlsen",
      "indices" : [ 0, 15 ],
      "id_str" : "859753454",
      "id" : 859753454
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324551773614374913",
  "geo" : { },
  "id_str" : "324584404179628032",
  "in_reply_to_user_id" : 859753454,
  "text" : "@JonathanAOlsen thx, i liked wht u did with famous people; the mozilla projects are a boon to classes i teach in :)",
  "id" : 324584404179628032,
  "in_reply_to_status_id" : 324551773614374913,
  "created_at" : "2013-04-17 18:05:27 +0000",
  "in_reply_to_screen_name" : "JonathanAOlsen",
  "in_reply_to_user_id_str" : "859753454",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 67, 75 ]
    }, {
      "text" : "corpuslinguistics",
      "indices" : [ 76, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/xWvvww4jNN",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-zt",
      "display_url" : "wp.me\/pgHyE-zt"
    } ]
  },
  "geo" : { },
  "id_str" : "324534642738860032",
  "text" : "new post Around the GloWbE in a few clicks http:\/\/t.co\/xWvvww4jNN  #eltchat #corpuslinguistics",
  "id" : 324534642738860032,
  "created_at" : "2013-04-17 14:47:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/OigAnTwEZj",
      "expanded_url" : "http:\/\/corpus2.byu.edu\/glowbe\/?c=glowbe&q=22458259",
      "display_url" : "corpus2.byu.edu\/glowbe\/?c=glow\u2026"
    }, {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/Up3kx24pIJ",
      "expanded_url" : "http:\/\/corpus.byu.edu\/coca\/?c=coca&q=22458286",
      "display_url" : "corpus.byu.edu\/coca\/?c=coca&q\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "324525866711388160",
  "geo" : { },
  "id_str" : "324529286998552577",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson nice post chris, magic number &amp; seven is 4th in GloWbE http:\/\/t.co\/OigAnTwEZj and 18th in COCA http:\/\/t.co\/Up3kx24pIJ",
  "id" : 324529286998552577,
  "in_reply_to_status_id" : 324525866711388160,
  "created_at" : "2013-04-17 14:26:26 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Meghan Beler",
      "screen_name" : "MeghanBeler",
      "indices" : [ 0, 12 ],
      "id_str" : "102388600",
      "id" : 102388600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/GNGhDq9D0v",
      "expanded_url" : "http:\/\/eflnotes.wordpress.com\/2013\/04\/02\/more-than-a-thimbleful-of-learning\/",
      "display_url" : "eflnotes.wordpress.com\/2013\/04\/02\/mor\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "324496037140123648",
  "geo" : { },
  "id_str" : "324499536418598914",
  "in_reply_to_user_id" : 102388600,
  "text" : "@MeghanBeler hi used this in class http:\/\/t.co\/GNGhDq9D0v, agreed a grt activity",
  "id" : 324499536418598914,
  "in_reply_to_status_id" : 324496037140123648,
  "created_at" : "2013-04-17 12:28:13 +0000",
  "in_reply_to_screen_name" : "MeghanBeler",
  "in_reply_to_user_id_str" : "102388600",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
} ]