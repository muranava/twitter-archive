Grailbird.data.tweets_2014_08 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "indyref",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 126, 140 ],
      "url" : "http:\/\/t.co\/q18WznaI7u",
      "expanded_url" : "http:\/\/johnhilley.blogspot.co.uk\/2014\/08\/allyson-pollock-independence-as.html",
      "display_url" : "johnhilley.blogspot.co.uk\/2014\/08\/allyso\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "506181614939152384",
  "text" : "RT @johnwhilley: Crucial piece. Leading health expert Allyson Pollock says Yes vote only way to secure NHS in Scotland. Full: http:\/\/t.co\/q\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "indyref",
        "indices" : [ 132, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/q18WznaI7u",
        "expanded_url" : "http:\/\/johnhilley.blogspot.co.uk\/2014\/08\/allyson-pollock-independence-as.html",
        "display_url" : "johnhilley.blogspot.co.uk\/2014\/08\/allyso\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "506155044895739904",
    "text" : "Crucial piece. Leading health expert Allyson Pollock says Yes vote only way to secure NHS in Scotland. Full: http:\/\/t.co\/q18WznaI7u #indyref",
    "id" : 506155044895739904,
    "created_at" : "2014-08-31 19:02:21 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 506181614939152384,
  "created_at" : "2014-08-31 20:47:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/S8tQrI1JvH",
      "expanded_url" : "http:\/\/www.bmj.com\/content\/327\/7429\/1459\/rapid-responses",
      "display_url" : "bmj.com\/content\/327\/74\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "506066608565919744",
  "geo" : { },
  "id_str" : "506073191841013760",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin a lot of comments to article are even more amusing http:\/\/t.co\/S8tQrI1JvH",
  "id" : 506073191841013760,
  "in_reply_to_status_id" : 506066608565919744,
  "created_at" : "2014-08-31 13:37:05 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "506066608565919744",
  "geo" : { },
  "id_str" : "506068637313425408",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin hehe :)",
  "id" : 506068637313425408,
  "in_reply_to_status_id" : 506066608565919744,
  "created_at" : "2014-08-31 13:19:00 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil Clark",
      "screen_name" : "NeilClark66",
      "indices" : [ 3, 15 ],
      "id_str" : "728039605",
      "id" : 728039605
    }, {
      "name" : "George Galloway",
      "screen_name" : "georgegalloway",
      "indices" : [ 139, 140 ],
      "id_str" : "15484198",
      "id" : 15484198
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "506065967500505089",
  "text" : "RT @NeilClark66: Who will be blamed, I wonder, for 'radicalising' the Zionist fanatic who brutally attacked a British MP in a London street\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "George Galloway",
        "screen_name" : "georgegalloway",
        "indices" : [ 124, 139 ],
        "id_str" : "15484198",
        "id" : 15484198
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "506020339491807232",
    "text" : "Who will be blamed, I wonder, for 'radicalising' the Zionist fanatic who brutally attacked a British MP in a London street? @georgegalloway",
    "id" : 506020339491807232,
    "created_at" : "2014-08-31 10:07:04 +0000",
    "user" : {
      "name" : "Neil Clark",
      "screen_name" : "NeilClark66",
      "protected" : false,
      "id_str" : "728039605",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2451450991\/neil_clark_normal.png",
      "id" : 728039605,
      "verified" : false
    }
  },
  "id" : 506065967500505089,
  "created_at" : "2014-08-31 13:08:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vedrana Vojkovi\u0107",
      "screen_name" : "Ven_VVE",
      "indices" : [ 0, 8 ],
      "id_str" : "270839603",
      "id" : 270839603
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "505617266902581249",
  "geo" : { },
  "id_str" : "505691825961984001",
  "in_reply_to_user_id" : 270839603,
  "text" : "@Ven_VVE yr welcome &amp; nice to c u over at G+ comm :)",
  "id" : 505691825961984001,
  "in_reply_to_status_id" : 505617266902581249,
  "created_at" : "2014-08-30 12:21:41 +0000",
  "in_reply_to_screen_name" : "Ven_VVE",
  "in_reply_to_user_id_str" : "270839603",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EL Gazette",
      "screen_name" : "ELGazette",
      "indices" : [ 0, 10 ],
      "id_str" : "614186998",
      "id" : 614186998
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "505684647703871489",
  "geo" : { },
  "id_str" : "505688511367090177",
  "in_reply_to_user_id" : 614186998,
  "text" : "@ELGazette intereting instance of \"researches\"",
  "id" : 505688511367090177,
  "in_reply_to_status_id" : 505684647703871489,
  "created_at" : "2014-08-30 12:08:31 +0000",
  "in_reply_to_screen_name" : "ELGazette",
  "in_reply_to_user_id_str" : "614186998",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 3, 14 ],
      "id_str" : "300734173",
      "id" : 300734173
    }, {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 134, 140 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/fJCMCtNHuD",
      "expanded_url" : "http:\/\/wp.me\/p3augf-eK",
      "display_url" : "wp.me\/p3augf-eK"
    } ]
  },
  "geo" : { },
  "id_str" : "505663853578166273",
  "text" : "RT @lexicoloco: 'VOICES' Spoken ELF corpus study. Needles in a haystack: questioning the \"fluidity\" of ELF http:\/\/t.co\/fJCMCtNHuD via @word\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "WordPress.com",
        "screen_name" : "wordpressdotcom",
        "indices" : [ 118, 134 ],
        "id_str" : "823905",
        "id" : 823905
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/fJCMCtNHuD",
        "expanded_url" : "http:\/\/wp.me\/p3augf-eK",
        "display_url" : "wp.me\/p3augf-eK"
      } ]
    },
    "geo" : { },
    "id_str" : "504620642356830208",
    "text" : "'VOICES' Spoken ELF corpus study. Needles in a haystack: questioning the \"fluidity\" of ELF http:\/\/t.co\/fJCMCtNHuD via @wordpressdotcom",
    "id" : 504620642356830208,
    "created_at" : "2014-08-27 13:25:11 +0000",
    "user" : {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "protected" : false,
      "id_str" : "300734173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2403500097\/3nmx3kjaycyoc7irwe6s_normal.jpeg",
      "id" : 300734173,
      "verified" : false
    }
  },
  "id" : 505663853578166273,
  "created_at" : "2014-08-30 10:30:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/xcyM4sbTEi",
      "expanded_url" : "http:\/\/www.counterpunch.org\/2014\/08\/29\/obamas-catastrophic-defeat-in-ukraine\/#.VAEOPaH297M.twitter",
      "display_url" : "counterpunch.org\/2014\/08\/29\/oba\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "505499021683613696",
  "text" : "Obama\u2019s \u201CCatastrophic Defeat\u201D in Ukraine \u00BB CounterPunch: Tells the Facts, Names the Names http:\/\/t.co\/xcyM4sbTEi",
  "id" : 505499021683613696,
  "created_at" : "2014-08-29 23:35:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vox",
      "screen_name" : "voxdotcom",
      "indices" : [ 89, 99 ],
      "id_str" : "2347049341",
      "id" : 2347049341
    }, {
      "name" : "Alan Jacobs",
      "screen_name" : "ayjay",
      "indices" : [ 103, 109 ],
      "id_str" : "2141771",
      "id" : 2141771
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/Bmo9KEPxS7",
      "expanded_url" : "http:\/\/www.vox.com\/2014\/8\/26\/6066069\/swearing-science-obscenity-research?utm_medium=social&utm_source=twitter&utm_name=share-button&utm_campaign=vox&utm_content=article-share-top",
      "display_url" : "vox.com\/2014\/8\/26\/6066\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "505494943230480384",
  "text" : "5 surprising things scientists have discovered about swearing http:\/\/t.co\/Bmo9KEPxS7 via @voxdotcom ht @ayjay",
  "id" : 505494943230480384,
  "created_at" : "2014-08-29 23:19:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/P9vOpCvr4G",
      "expanded_url" : "http:\/\/members5.boardhost.com\/medialens\/msg\/1409351508.html",
      "display_url" : "members5.boardhost.com\/medialens\/msg\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "505484887810666496",
  "text" : "Krusty Warkmonger and Newsnight's Urban Worrier press all the War War buttons, including replay of http:\/\/t.co\/P9vOpCvr4G",
  "id" : 505484887810666496,
  "created_at" : "2014-08-29 22:39:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil Clark",
      "screen_name" : "NeilClark66",
      "indices" : [ 3, 15 ],
      "id_str" : "728039605",
      "id" : 728039605
    }, {
      "name" : "John Wight",
      "screen_name" : "JohnWight1",
      "indices" : [ 93, 104 ],
      "id_str" : "313221429",
      "id" : 313221429
    }, {
      "name" : "RT",
      "screen_name" : "RT_com",
      "indices" : [ 109, 116 ],
      "id_str" : "64643056",
      "id" : 64643056
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 143, 144 ]
    }, {
      "text" : "IS",
      "indices" : [ 143, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 124, 144 ],
      "url" : "http:\/\/t.co\/aa14AGs8HC",
      "expanded_url" : "http:\/\/rt.com\/op-edge\/183476-us-beg-syrians-forgiveness\/#",
      "display_url" : "rt.com\/op-edge\/183476\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "505470582633558016",
  "text" : "RT @NeilClark66: 'US &amp; allies should beg Syrian people for forgiveness' -v.good piece by @JohnWight1 for @RT_com OpEdge http:\/\/t.co\/aa14AGs\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Wight",
        "screen_name" : "JohnWight1",
        "indices" : [ 76, 87 ],
        "id_str" : "313221429",
        "id" : 313221429
      }, {
        "name" : "RT",
        "screen_name" : "RT_com",
        "indices" : [ 92, 99 ],
        "id_str" : "64643056",
        "id" : 64643056
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Syria",
        "indices" : [ 131, 137 ]
      }, {
        "text" : "IS",
        "indices" : [ 138, 141 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/aa14AGs8HC",
        "expanded_url" : "http:\/\/rt.com\/op-edge\/183476-us-beg-syrians-forgiveness\/#",
        "display_url" : "rt.com\/op-edge\/183476\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "505338063178846208",
    "text" : "'US &amp; allies should beg Syrian people for forgiveness' -v.good piece by @JohnWight1 for @RT_com OpEdge http:\/\/t.co\/aa14AGs8HC  #Syria #IS",
    "id" : 505338063178846208,
    "created_at" : "2014-08-29 12:55:57 +0000",
    "user" : {
      "name" : "Neil Clark",
      "screen_name" : "NeilClark66",
      "protected" : false,
      "id_str" : "728039605",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2451450991\/neil_clark_normal.png",
      "id" : 728039605,
      "verified" : false
    }
  },
  "id" : 505470582633558016,
  "created_at" : "2014-08-29 21:42:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Les Adams",
      "screen_name" : "LesAdams3",
      "indices" : [ 0, 10 ],
      "id_str" : "581792166",
      "id" : 581792166
    }, {
      "name" : "George Galloway",
      "screen_name" : "georgegalloway",
      "indices" : [ 11, 26 ],
      "id_str" : "15484198",
      "id" : 15484198
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "505466508966113280",
  "geo" : { },
  "id_str" : "505469646867533824",
  "in_reply_to_user_id" : 581792166,
  "text" : "@LesAdams3 @georgegalloway can play very quick Galloway corporate media bingo - controversial, firebrand",
  "id" : 505469646867533824,
  "in_reply_to_status_id" : 505466508966113280,
  "created_at" : "2014-08-29 21:38:49 +0000",
  "in_reply_to_screen_name" : "LesAdams3",
  "in_reply_to_user_id_str" : "581792166",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vedrana Vojkovi\u0107",
      "screen_name" : "Ven_VVE",
      "indices" : [ 0, 8 ],
      "id_str" : "270839603",
      "id" : 270839603
    }, {
      "name" : "Joanna M",
      "screen_name" : "joannacre",
      "indices" : [ 9, 19 ],
      "id_str" : "444977554",
      "id" : 444977554
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 45, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/9e8DMyIPX8",
      "expanded_url" : "https:\/\/plus.google.com\/u\/0\/communities\/101266284417587206243\/stream\/ea5b64fa-abb3-4788-bdaa-1db319ebcce0",
      "display_url" : "plus.google.com\/u\/0\/communitie\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "504531805782163456",
  "geo" : { },
  "id_str" : "505446472373256193",
  "in_reply_to_user_id" : 270839603,
  "text" : "@Ven_VVE @joannacre hi you may find some int #corpusmooc info here https:\/\/t.co\/9e8DMyIPX8 &amp; yr welcome to share thoughts in G+ community :)",
  "id" : 505446472373256193,
  "in_reply_to_status_id" : 504531805782163456,
  "created_at" : "2014-08-29 20:06:44 +0000",
  "in_reply_to_screen_name" : "Ven_VVE",
  "in_reply_to_user_id_str" : "270839603",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 87, 95 ]
    }, {
      "text" : "efl",
      "indices" : [ 96, 100 ]
    }, {
      "text" : "tefl",
      "indices" : [ 101, 106 ]
    }, {
      "text" : "esl",
      "indices" : [ 107, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/9IVsJZ5c6b",
      "expanded_url" : "http:\/\/blog.nus.edu.sg\/eltwo\/2014\/08\/27\/incorporating-collocation-teaching-in-a-reading-writing-program-2\/#.VAChEttRYk0.twitter",
      "display_url" : "blog.nus.edu.sg\/eltwo\/2014\/08\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "505381891428470784",
  "text" : "Incorporating Collocation Teaching in a Reading-Writing Program http:\/\/t.co\/9IVsJZ5c6b #eltchat #efl #tefl #esl",
  "id" : 505381891428470784,
  "created_at" : "2014-08-29 15:50:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Damien Munchip",
      "screen_name" : "chimponobo",
      "indices" : [ 3, 14 ],
      "id_str" : "327186537",
      "id" : 327186537
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AUSelt",
      "indices" : [ 130, 137 ]
    }, {
      "text" : "TESOL",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "EFL",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/z4BPHXvd6V",
      "expanded_url" : "http:\/\/stressifier.herokuapp.com\/",
      "display_url" : "stressifier.herokuapp.com"
    } ]
  },
  "geo" : { },
  "id_str" : "505377780155301888",
  "text" : "RT @chimponobo: Not sure on accuracy of it but might has some classroom applications for looking at stress\nhttp:\/\/t.co\/z4BPHXvd6V\n#AUSelt #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AUSelt",
        "indices" : [ 114, 121 ]
      }, {
        "text" : "TESOL",
        "indices" : [ 122, 128 ]
      }, {
        "text" : "EFL",
        "indices" : [ 129, 133 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/z4BPHXvd6V",
        "expanded_url" : "http:\/\/stressifier.herokuapp.com\/",
        "display_url" : "stressifier.herokuapp.com"
      } ]
    },
    "geo" : { },
    "id_str" : "505266245130665984",
    "text" : "Not sure on accuracy of it but might has some classroom applications for looking at stress\nhttp:\/\/t.co\/z4BPHXvd6V\n#AUSelt #TESOL #EFL",
    "id" : 505266245130665984,
    "created_at" : "2014-08-29 08:10:34 +0000",
    "user" : {
      "name" : "Damien Munchip",
      "screen_name" : "chimponobo",
      "protected" : false,
      "id_str" : "327186537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703504370713780224\/Ffd779uj_normal.jpg",
      "id" : 327186537,
      "verified" : false
    }
  },
  "id" : 505377780155301888,
  "created_at" : "2014-08-29 15:33:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Damien Munchip",
      "screen_name" : "chimponobo",
      "indices" : [ 0, 11 ],
      "id_str" : "327186537",
      "id" : 327186537
    }, {
      "name" : "Sophia Khan",
      "screen_name" : "SophiaKhan4",
      "indices" : [ 12, 24 ],
      "id_str" : "351390617",
      "id" : 351390617
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/p2ESuKTgzT",
      "expanded_url" : "http:\/\/michelleful.github.io\/code-blog\/2014\/07\/23\/stressifier.html",
      "display_url" : "michelleful.github.io\/code-blog\/2014\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "505266245130665984",
  "geo" : { },
  "id_str" : "505376963360731136",
  "in_reply_to_user_id" : 327186537,
  "text" : "@chimponobo @SophiaKhan4 nice, some info on accuracy here http:\/\/t.co\/p2ESuKTgzT",
  "id" : 505376963360731136,
  "in_reply_to_status_id" : 505266245130665984,
  "created_at" : "2014-08-29 15:30:32 +0000",
  "in_reply_to_screen_name" : "chimponobo",
  "in_reply_to_user_id_str" : "327186537",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robbie Love",
      "screen_name" : "lovermob",
      "indices" : [ 91, 100 ],
      "id_str" : "19469715",
      "id" : 19469715
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpus",
      "indices" : [ 37, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/FYDp1bLhBI",
      "expanded_url" : "https:\/\/plus.google.com\/104940199413423400545\/posts\/1HGHyCeHMt8",
      "display_url" : "plus.google.com\/10494019941342\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "505347560475987968",
  "text" : "want to know more about BNC14 spoken #corpus? check https:\/\/t.co\/FYDp1bLhBI many thanks to @lovermob",
  "id" : 505347560475987968,
  "created_at" : "2014-08-29 13:33:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KevinHodgson",
      "screen_name" : "dogtrax",
      "indices" : [ 3, 11 ],
      "id_str" : "13307352",
      "id" : 13307352
    }, {
      "name" : "Jenna Mcmahon",
      "screen_name" : "decibelnet",
      "indices" : [ 39, 50 ],
      "id_str" : "702889570136932352",
      "id" : 702889570136932352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/zgRQzwXeLc",
      "expanded_url" : "https:\/\/medium.com\/@decibelnet\/hip-hop-and-metadata-885e5d0b8fe9?source=tw-b3630663dd2d-1409310665077",
      "display_url" : "medium.com\/@decibelnet\/hi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "505313248171008001",
  "text" : "RT @dogtrax: \u201CHip hop and Metadata\u201D by @decibelnet https:\/\/t.co\/zgRQzwXeLc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jenna Mcmahon",
        "screen_name" : "decibelnet",
        "indices" : [ 26, 37 ],
        "id_str" : "702889570136932352",
        "id" : 702889570136932352
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 61 ],
        "url" : "https:\/\/t.co\/zgRQzwXeLc",
        "expanded_url" : "https:\/\/medium.com\/@decibelnet\/hip-hop-and-metadata-885e5d0b8fe9?source=tw-b3630663dd2d-1409310665077",
        "display_url" : "medium.com\/@decibelnet\/hi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "505311719908847616",
    "text" : "\u201CHip hop and Metadata\u201D by @decibelnet https:\/\/t.co\/zgRQzwXeLc",
    "id" : 505311719908847616,
    "created_at" : "2014-08-29 11:11:16 +0000",
    "user" : {
      "name" : "KevinHodgson",
      "screen_name" : "dogtrax",
      "protected" : false,
      "id_str" : "13307352",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629952065809334272\/BKXrDkoi_normal.png",
      "id" : 13307352,
      "verified" : false
    }
  },
  "id" : 505313248171008001,
  "created_at" : "2014-08-29 11:17:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Borg",
      "screen_name" : "Simon_Borg",
      "indices" : [ 3, 14 ],
      "id_str" : "94652779",
      "id" : 94652779
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELT",
      "indices" : [ 110, 114 ]
    }, {
      "text" : "TESOL",
      "indices" : [ 115, 121 ]
    }, {
      "text" : "EFL",
      "indices" : [ 122, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/SQ3eMd0AM5",
      "expanded_url" : "http:\/\/tinyurl.com\/mhfd3em",
      "display_url" : "tinyurl.com\/mhfd3em"
    } ]
  },
  "geo" : { },
  "id_str" : "505311301632278528",
  "text" : "RT @Simon_Borg: New article on the benefits to teachers of attending ELT conferences - http:\/\/t.co\/SQ3eMd0AM5 #ELT #TESOL #EFL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELT",
        "indices" : [ 94, 98 ]
      }, {
        "text" : "TESOL",
        "indices" : [ 99, 105 ]
      }, {
        "text" : "EFL",
        "indices" : [ 106, 110 ]
      } ],
      "urls" : [ {
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/SQ3eMd0AM5",
        "expanded_url" : "http:\/\/tinyurl.com\/mhfd3em",
        "display_url" : "tinyurl.com\/mhfd3em"
      } ]
    },
    "geo" : { },
    "id_str" : "504906615171317760",
    "text" : "New article on the benefits to teachers of attending ELT conferences - http:\/\/t.co\/SQ3eMd0AM5 #ELT #TESOL #EFL",
    "id" : 504906615171317760,
    "created_at" : "2014-08-28 08:21:32 +0000",
    "user" : {
      "name" : "Simon Borg",
      "screen_name" : "Simon_Borg",
      "protected" : false,
      "id_str" : "94652779",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/505335486622097408\/EQupUwnd_normal.jpeg",
      "id" : 94652779,
      "verified" : false
    }
  },
  "id" : 505311301632278528,
  "created_at" : "2014-08-29 11:09:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/E0FJbdGFVC",
      "expanded_url" : "http:\/\/members5.boardhost.com\/medialens\/msg\/1409269227.html",
      "display_url" : "members5.boardhost.com\/medialens\/msg\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "505280203665731585",
  "text" : "Laugh aloud moment on BBC Radio 4's World Tonight http:\/\/t.co\/E0FJbdGFVC",
  "id" : 505280203665731585,
  "created_at" : "2014-08-29 09:06:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "P\u00E9rez-Paredes",
      "screen_name" : "perezparedes",
      "indices" : [ 3, 16 ],
      "id_str" : "28528850",
      "id" : 28528850
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SketchEngine",
      "indices" : [ 24, 37 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/uqrFMvfAoI",
      "expanded_url" : "http:\/\/perezparedes.blogspot.com.es\/2014\/07\/using-sketch-engine-some-how-to.html",
      "display_url" : "perezparedes.blogspot.com.es\/2014\/07\/using-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "505266086741573632",
  "text" : "RT @perezparedes: Using #SketchEngine: some how-to resources http:\/\/t.co\/uqrFMvfAoI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SketchEngine",
        "indices" : [ 6, 19 ]
      } ],
      "urls" : [ {
        "indices" : [ 43, 65 ],
        "url" : "http:\/\/t.co\/uqrFMvfAoI",
        "expanded_url" : "http:\/\/perezparedes.blogspot.com.es\/2014\/07\/using-sketch-engine-some-how-to.html",
        "display_url" : "perezparedes.blogspot.com.es\/2014\/07\/using-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "505263867023609856",
    "text" : "Using #SketchEngine: some how-to resources http:\/\/t.co\/uqrFMvfAoI",
    "id" : 505263867023609856,
    "created_at" : "2014-08-29 08:01:07 +0000",
    "user" : {
      "name" : "P\u00E9rez-Paredes",
      "screen_name" : "perezparedes",
      "protected" : false,
      "id_str" : "28528850",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746249968139313153\/2-1yieTh_normal.jpg",
      "id" : 28528850,
      "verified" : false
    }
  },
  "id" : 505266086741573632,
  "created_at" : "2014-08-29 08:09:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robbie Love",
      "screen_name" : "lovermob",
      "indices" : [ 0, 9 ],
      "id_str" : "19469715",
      "id" : 19469715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505260239021932545",
  "in_reply_to_user_id" : 19469715,
  "text" : "@lovermob hi was wondering if a more detailed write up will be done of initial BNC14 findings? ta",
  "id" : 505260239021932545,
  "created_at" : "2014-08-29 07:46:42 +0000",
  "in_reply_to_screen_name" : "lovermob",
  "in_reply_to_user_id_str" : "19469715",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nic Subtirelu",
      "screen_name" : "linguisticpulse",
      "indices" : [ 0, 16 ],
      "id_str" : "1400748798",
      "id" : 1400748798
    }, {
      "name" : "Kieran Snyder",
      "screen_name" : "KieranSnyder",
      "indices" : [ 17, 30 ],
      "id_str" : "372910226",
      "id" : 372910226
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "505069197823848448",
  "geo" : { },
  "id_str" : "505074695281336320",
  "in_reply_to_user_id" : 1400748798,
  "text" : "@linguisticpulse @KieranSnyder used abrasive v recent to descr male comm style in just the way you argue - \"whimsical idiosyncrasy\" :\/",
  "id" : 505074695281336320,
  "in_reply_to_status_id" : 505069197823848448,
  "created_at" : "2014-08-28 19:29:25 +0000",
  "in_reply_to_screen_name" : "linguisticpulse",
  "in_reply_to_user_id_str" : "1400748798",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maria Pia Montoro",
      "screen_name" : "WordLo",
      "indices" : [ 79, 86 ],
      "id_str" : "190569306",
      "id" : 190569306
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/LnXA8AruQV",
      "expanded_url" : "https:\/\/www.tausdata.org\/",
      "display_url" : "tausdata.org"
    } ]
  },
  "geo" : { },
  "id_str" : "505031169889828865",
  "text" : "student anxious about technical vocab really liked https:\/\/t.co\/LnXA8AruQV h\/t @WordLo",
  "id" : 505031169889828865,
  "created_at" : "2014-08-28 16:36:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Revolution News",
      "screen_name" : "NewsRevo",
      "indices" : [ 3, 12 ],
      "id_str" : "47862165",
      "id" : 47862165
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/NewsRevo\/status\/504903457778589696\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/XVtt1oif9J",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BwHHBMFIMAAwNdt.jpg",
      "id_str" : "504903456478736384",
      "id" : 504903456478736384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwHHBMFIMAAwNdt.jpg",
      "sizes" : [ {
        "h" : 283,
        "resize" : "fit",
        "w" : 637
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 151,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 267,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 283,
        "resize" : "fit",
        "w" : 637
      } ],
      "display_url" : "pic.twitter.com\/XVtt1oif9J"
    } ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 66, 75 ]
    }, {
      "text" : "HandsUp",
      "indices" : [ 101, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/xkYKteORb0",
      "expanded_url" : "http:\/\/revolution-news.com\/mumia-abu-jamal-weighs-outside-agitators-ferguson\/",
      "display_url" : "revolution-news.com\/mumia-abu-jama\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "505026972242968576",
  "text" : "RT @NewsRevo: Mumia Abu Jamal Weighs in on \u201COutside Agitators\u201D in #Ferguson | http:\/\/t.co\/xkYKteORb0 #HandsUp http:\/\/t.co\/XVtt1oif9J",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/NewsRevo\/status\/504903457778589696\/photo\/1",
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/XVtt1oif9J",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BwHHBMFIMAAwNdt.jpg",
        "id_str" : "504903456478736384",
        "id" : 504903456478736384,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwHHBMFIMAAwNdt.jpg",
        "sizes" : [ {
          "h" : 283,
          "resize" : "fit",
          "w" : 637
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 151,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 267,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 283,
          "resize" : "fit",
          "w" : 637
        } ],
        "display_url" : "pic.twitter.com\/XVtt1oif9J"
      } ],
      "hashtags" : [ {
        "text" : "Ferguson",
        "indices" : [ 52, 61 ]
      }, {
        "text" : "HandsUp",
        "indices" : [ 87, 95 ]
      } ],
      "urls" : [ {
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/xkYKteORb0",
        "expanded_url" : "http:\/\/revolution-news.com\/mumia-abu-jamal-weighs-outside-agitators-ferguson\/",
        "display_url" : "revolution-news.com\/mumia-abu-jama\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "504903457778589696",
    "text" : "Mumia Abu Jamal Weighs in on \u201COutside Agitators\u201D in #Ferguson | http:\/\/t.co\/xkYKteORb0 #HandsUp http:\/\/t.co\/XVtt1oif9J",
    "id" : 504903457778589696,
    "created_at" : "2014-08-28 08:08:59 +0000",
    "user" : {
      "name" : "Revolution News",
      "screen_name" : "NewsRevo",
      "protected" : false,
      "id_str" : "47862165",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/573963111272570880\/lpNfTgyM_normal.jpeg",
      "id" : 47862165,
      "verified" : false
    }
  },
  "id" : 505026972242968576,
  "created_at" : "2014-08-28 16:19:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "indices" : [ 3, 18 ],
      "id_str" : "27716419",
      "id" : 27716419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/H9GfvFcsuK",
      "expanded_url" : "http:\/\/bit.ly\/1nHHRAf",
      "display_url" : "bit.ly\/1nHHRAf"
    } ]
  },
  "geo" : { },
  "id_str" : "505025581961211904",
  "text" : "RT @CraigMurrayOrg: St Andrews Speech: Here am I talking in St Andrews two nights ago. The interesting thing is that this informat... http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/H9GfvFcsuK",
        "expanded_url" : "http:\/\/bit.ly\/1nHHRAf",
        "display_url" : "bit.ly\/1nHHRAf"
      } ]
    },
    "geo" : { },
    "id_str" : "504952849873133568",
    "text" : "St Andrews Speech: Here am I talking in St Andrews two nights ago. The interesting thing is that this informat... http:\/\/t.co\/H9GfvFcsuK",
    "id" : 504952849873133568,
    "created_at" : "2014-08-28 11:25:15 +0000",
    "user" : {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "protected" : false,
      "id_str" : "27716419",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1388436826\/cm_normal.jpg",
      "id" : 27716419,
      "verified" : false
    }
  },
  "id" : 505025581961211904,
  "created_at" : "2014-08-28 16:14:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tressie Mc",
      "screen_name" : "tressiemcphd",
      "indices" : [ 3, 16 ],
      "id_str" : "148593548",
      "id" : 148593548
    }, {
      "name" : "Julie Bosman",
      "screen_name" : "juliebosman",
      "indices" : [ 67, 79 ],
      "id_str" : "29263488",
      "id" : 29263488
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/juliebosman\/status\/504636770227863552\/photo\/1",
      "indices" : [ 124, 140 ],
      "url" : "http:\/\/t.co\/UBFRlDVkVu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BwDUd_bIUAAtphB.jpg",
      "id_str" : "504636769972015104",
      "id" : 504636769972015104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwDUd_bIUAAtphB.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 852,
        "resize" : "fit",
        "w" : 639
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 852,
        "resize" : "fit",
        "w" : 639
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/UBFRlDVkVu"
    } ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 114, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "504959103253626880",
  "text" : "RT @tressiemcphd: This is why the humanities don't need saving. Rt @juliebosman: Letter-to-the-editor of the day. #Ferguson http:\/\/t.co\/UBF\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Julie Bosman",
        "screen_name" : "juliebosman",
        "indices" : [ 49, 61 ],
        "id_str" : "29263488",
        "id" : 29263488
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/juliebosman\/status\/504636770227863552\/photo\/1",
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/UBFRlDVkVu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BwDUd_bIUAAtphB.jpg",
        "id_str" : "504636769972015104",
        "id" : 504636769972015104,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwDUd_bIUAAtphB.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 852,
          "resize" : "fit",
          "w" : 639
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 852,
          "resize" : "fit",
          "w" : 639
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/UBFRlDVkVu"
      } ],
      "hashtags" : [ {
        "text" : "Ferguson",
        "indices" : [ 96, 105 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "504636770227863552",
    "geo" : { },
    "id_str" : "504856715830247425",
    "in_reply_to_user_id" : 29263488,
    "text" : "This is why the humanities don't need saving. Rt @juliebosman: Letter-to-the-editor of the day. #Ferguson http:\/\/t.co\/UBFRlDVkVu\u201D",
    "id" : 504856715830247425,
    "in_reply_to_status_id" : 504636770227863552,
    "created_at" : "2014-08-28 05:03:15 +0000",
    "in_reply_to_screen_name" : "juliebosman",
    "in_reply_to_user_id_str" : "29263488",
    "user" : {
      "name" : "Tressie Mc",
      "screen_name" : "tressiemcphd",
      "protected" : false,
      "id_str" : "148593548",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608377192331005952\/-4qqbOp2_normal.jpg",
      "id" : 148593548,
      "verified" : true
    }
  },
  "id" : 504959103253626880,
  "created_at" : "2014-08-28 11:50:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "androidgeekery",
      "indices" : [ 32, 47 ]
    }, {
      "text" : "apologies",
      "indices" : [ 48, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "504750402735464448",
  "text" : "nice multi-booting my phone now #androidgeekery #apologies",
  "id" : 504750402735464448,
  "created_at" : "2014-08-27 22:00:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 3, 14 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edtech",
      "indices" : [ 113, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/s742Aifs7k",
      "expanded_url" : "http:\/\/bit.ly\/1rzzj5T",
      "display_url" : "bit.ly\/1rzzj5T"
    } ]
  },
  "geo" : { },
  "id_str" : "504608210717011968",
  "text" : "RT @tornhalves: Yes, it IS okay to be a Luddite. Our call for a Luddite revival. Pedagogy with a hammer! End the #edtech slander! http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "edtech",
        "indices" : [ 97, 104 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/s742Aifs7k",
        "expanded_url" : "http:\/\/bit.ly\/1rzzj5T",
        "display_url" : "bit.ly\/1rzzj5T"
      } ]
    },
    "geo" : { },
    "id_str" : "504583845703081984",
    "text" : "Yes, it IS okay to be a Luddite. Our call for a Luddite revival. Pedagogy with a hammer! End the #edtech slander! http:\/\/t.co\/s742Aifs7k",
    "id" : 504583845703081984,
    "created_at" : "2014-08-27 10:58:58 +0000",
    "user" : {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "protected" : false,
      "id_str" : "87902543",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3059742703\/1d3c7a2052db17d29644fa0a49af6480_normal.jpeg",
      "id" : 87902543,
      "verified" : false
    }
  },
  "id" : 504608210717011968,
  "created_at" : "2014-08-27 12:35:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Claire Hardaker",
      "screen_name" : "DrClaireH",
      "indices" : [ 0, 10 ],
      "id_str" : "237842162",
      "id" : 237842162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "504373421661515777",
  "geo" : { },
  "id_str" : "504381929656184832",
  "in_reply_to_user_id" : 237842162,
  "text" : "@DrClaireH Odds change if tweeting at same time as well I think :)",
  "id" : 504381929656184832,
  "in_reply_to_status_id" : 504373421661515777,
  "created_at" : "2014-08-26 21:36:37 +0000",
  "in_reply_to_screen_name" : "DrClaireH",
  "in_reply_to_user_id_str" : "237842162",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/CipZ6jKNKM",
      "expanded_url" : "https:\/\/www.academia.edu\/7568971\/1990-Collins_COBUILD_English_Grammar",
      "display_url" : "academia.edu\/7568971\/1990-C\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "504355248040075264",
  "text" : "1990 Cobuild English Grammar book https:\/\/t.co\/CipZ6jKNKM",
  "id" : 504355248040075264,
  "created_at" : "2014-08-26 19:50:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Classroom Discourse",
      "screen_name" : "ClassDisc",
      "indices" : [ 3, 13 ],
      "id_str" : "1649782256",
      "id" : 1649782256
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CA",
      "indices" : [ 122, 125 ]
    }, {
      "text" : "interaction",
      "indices" : [ 126, 138 ]
    }, {
      "text" : "complexity",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/pd2zALLQLm",
      "expanded_url" : "http:\/\/www.tandfonline.com\/doi\/full\/10.1080\/19463011003750624",
      "display_url" : "tandfonline.com\/doi\/full\/10.10\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "504342872402190338",
  "text" : "RT @ClassDisc: Free access to Paul Seedhouse's article on complexity theory and spoken interaction http:\/\/t.co\/pd2zALLQLm #CA #interaction \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CA",
        "indices" : [ 107, 110 ]
      }, {
        "text" : "interaction",
        "indices" : [ 111, 123 ]
      }, {
        "text" : "complexity",
        "indices" : [ 124, 135 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/pd2zALLQLm",
        "expanded_url" : "http:\/\/www.tandfonline.com\/doi\/full\/10.1080\/19463011003750624",
        "display_url" : "tandfonline.com\/doi\/full\/10.10\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "504329385974190080",
    "text" : "Free access to Paul Seedhouse's article on complexity theory and spoken interaction http:\/\/t.co\/pd2zALLQLm #CA #interaction #complexity",
    "id" : 504329385974190080,
    "created_at" : "2014-08-26 18:07:50 +0000",
    "user" : {
      "name" : "Classroom Discourse",
      "screen_name" : "ClassDisc",
      "protected" : false,
      "id_str" : "1649782256",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/426672533790654464\/ulChsvPI_normal.jpeg",
      "id" : 1649782256,
      "verified" : false
    }
  },
  "id" : 504342872402190338,
  "created_at" : "2014-08-26 19:01:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nic Subtirelu",
      "screen_name" : "linguisticpulse",
      "indices" : [ 3, 19 ],
      "id_str" : "1400748798",
      "id" : 1400748798
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "feminists",
      "indices" : [ 92, 102 ]
    }, {
      "text" : "BeyonceonVMA",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/GI09AaxSDr",
      "expanded_url" : "http:\/\/bit.ly\/YWug2w",
      "display_url" : "bit.ly\/YWug2w"
    } ]
  },
  "geo" : { },
  "id_str" : "504336093979111424",
  "text" : "RT @linguisticpulse: Militant, radical, man-hating? A short piece of the media portrayal of #feminists (http:\/\/t.co\/GI09AaxSDr) following #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "feminists",
        "indices" : [ 71, 81 ]
      }, {
        "text" : "BeyonceonVMA",
        "indices" : [ 117, 130 ]
      } ],
      "urls" : [ {
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/GI09AaxSDr",
        "expanded_url" : "http:\/\/bit.ly\/YWug2w",
        "display_url" : "bit.ly\/YWug2w"
      } ]
    },
    "geo" : { },
    "id_str" : "504332736409391104",
    "text" : "Militant, radical, man-hating? A short piece of the media portrayal of #feminists (http:\/\/t.co\/GI09AaxSDr) following #BeyonceonVMA",
    "id" : 504332736409391104,
    "created_at" : "2014-08-26 18:21:09 +0000",
    "user" : {
      "name" : "Nic Subtirelu",
      "screen_name" : "linguisticpulse",
      "protected" : false,
      "id_str" : "1400748798",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3609632834\/4ae2ef11e9cffa43e820f3ef7e18b016_normal.jpeg",
      "id" : 1400748798,
      "verified" : false
    }
  },
  "id" : 504336093979111424,
  "created_at" : "2014-08-26 18:34:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robbie Love",
      "screen_name" : "lovermob",
      "indices" : [ 3, 12 ],
      "id_str" : "19469715",
      "id" : 19469715
    }, {
      "name" : "The Guardian",
      "screen_name" : "guardian",
      "indices" : [ 139, 140 ],
      "id_str" : "87818409",
      "id" : 87818409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/sEwRtLKmtD",
      "expanded_url" : "http:\/\/gu.com\/p\/4x33g\/tw",
      "display_url" : "gu.com\/p\/4x33g\/tw"
    } ]
  },
  "geo" : { },
  "id_str" : "504325796895653888",
  "text" : "RT @lovermob: Great article from The Guardian! \"From marvellous to awesome: how spoken British English has changed\" http:\/\/t.co\/sEwRtLKmtD \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Guardian",
        "screen_name" : "guardian",
        "indices" : [ 129, 138 ],
        "id_str" : "87818409",
        "id" : 87818409
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/sEwRtLKmtD",
        "expanded_url" : "http:\/\/gu.com\/p\/4x33g\/tw",
        "display_url" : "gu.com\/p\/4x33g\/tw"
      } ]
    },
    "geo" : { },
    "id_str" : "504303756708569088",
    "text" : "Great article from The Guardian! \"From marvellous to awesome: how spoken British English has changed\" http:\/\/t.co\/sEwRtLKmtD via @guardian",
    "id" : 504303756708569088,
    "created_at" : "2014-08-26 16:25:59 +0000",
    "user" : {
      "name" : "Robbie Love",
      "screen_name" : "lovermob",
      "protected" : false,
      "id_str" : "19469715",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733371018056716288\/4lRj6knU_normal.jpg",
      "id" : 19469715,
      "verified" : false
    }
  },
  "id" : 504325796895653888,
  "created_at" : "2014-08-26 17:53:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Claire Dembry",
      "screen_name" : "ClaireDembry",
      "indices" : [ 0, 13 ],
      "id_str" : "2396240628",
      "id" : 2396240628
    }, {
      "name" : "Robbie Love",
      "screen_name" : "lovermob",
      "indices" : [ 14, 23 ],
      "id_str" : "19469715",
      "id" : 19469715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "504321182632792064",
  "geo" : { },
  "id_str" : "504324237226950656",
  "in_reply_to_user_id" : 2396240628,
  "text" : "@ClaireDembry @lovermob okay enjoy yr hols :)",
  "id" : 504324237226950656,
  "in_reply_to_status_id" : 504321182632792064,
  "created_at" : "2014-08-26 17:47:22 +0000",
  "in_reply_to_screen_name" : "ClaireDembry",
  "in_reply_to_user_id_str" : "2396240628",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Claire Dembry",
      "screen_name" : "ClaireDembry",
      "indices" : [ 0, 13 ],
      "id_str" : "2396240628",
      "id" : 2396240628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "504305441216954368",
  "in_reply_to_user_id" : 2396240628,
  "text" : "@ClaireDembry hi the figure of 155\/mill for marvel(l)lous is correct? 31.8 from bncweb? also how many tokens is ~200 recordings bnc14? thx!",
  "id" : 504305441216954368,
  "created_at" : "2014-08-26 16:32:41 +0000",
  "in_reply_to_screen_name" : "ClaireDembry",
  "in_reply_to_user_id_str" : "2396240628",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "indices" : [ 0, 11 ],
      "id_str" : "152051625",
      "id" : 152051625
    }, {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "indices" : [ 12, 24 ],
      "id_str" : "849729062",
      "id" : 849729062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "504266802667339776",
  "geo" : { },
  "id_str" : "504285198654402560",
  "in_reply_to_user_id" : 152051625,
  "text" : "@heatherfro @TonyMcEnery native?",
  "id" : 504285198654402560,
  "in_reply_to_status_id" : 504266802667339776,
  "created_at" : "2014-08-26 15:12:15 +0000",
  "in_reply_to_screen_name" : "heatherfro",
  "in_reply_to_user_id_str" : "152051625",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/0xL28aRs6g",
      "expanded_url" : "http:\/\/eltj.oxfordjournals.org\/content\/67\/4\/475.abstract?sid=857300ba-e391-47f9-94a3-68161a361b22",
      "display_url" : "eltj.oxfordjournals.org\/content\/67\/4\/4\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "503865592827625473",
  "geo" : { },
  "id_str" : "504018600005746691",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl this article (free if registered) http:\/\/t.co\/0xL28aRs6g questions context driven position",
  "id" : 504018600005746691,
  "in_reply_to_status_id" : 503865592827625473,
  "created_at" : "2014-08-25 21:32:53 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George Siemens",
      "screen_name" : "gsiemens",
      "indices" : [ 3, 12 ],
      "id_str" : "18613",
      "id" : 18613
    }, {
      "name" : "SoLAR",
      "screen_name" : "SoLAResearch",
      "indices" : [ 90, 103 ],
      "id_str" : "395576921",
      "id" : 395576921
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "learninganalytics",
      "indices" : [ 68, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/5t3T13DKfO",
      "expanded_url" : "http:\/\/swirlstats.com\/",
      "display_url" : "swirlstats.com"
    } ]
  },
  "geo" : { },
  "id_str" : "504000001513889793",
  "text" : "RT @gsiemens: Learn R in R: http:\/\/t.co\/5t3T13DKfO (great approach) #learninganalytics cc @SoLAResearch",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "SoLAR",
        "screen_name" : "SoLAResearch",
        "indices" : [ 76, 89 ],
        "id_str" : "395576921",
        "id" : 395576921
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "learninganalytics",
        "indices" : [ 54, 72 ]
      } ],
      "urls" : [ {
        "indices" : [ 14, 36 ],
        "url" : "http:\/\/t.co\/5t3T13DKfO",
        "expanded_url" : "http:\/\/swirlstats.com\/",
        "display_url" : "swirlstats.com"
      } ]
    },
    "geo" : { },
    "id_str" : "503970302188347392",
    "text" : "Learn R in R: http:\/\/t.co\/5t3T13DKfO (great approach) #learninganalytics cc @SoLAResearch",
    "id" : 503970302188347392,
    "created_at" : "2014-08-25 18:20:58 +0000",
    "user" : {
      "name" : "George Siemens",
      "screen_name" : "gsiemens",
      "protected" : false,
      "id_str" : "18613",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451036825637761025\/7_0RawE8_normal.jpeg",
      "id" : 18613,
      "verified" : false
    }
  },
  "id" : 504000001513889793,
  "created_at" : "2014-08-25 20:18:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "4TUNE Teller App",
      "screen_name" : "4tunetellernet",
      "indices" : [ 0, 15 ],
      "id_str" : "467634146",
      "id" : 467634146
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "503980880709578752",
  "geo" : { },
  "id_str" : "503984424175042560",
  "in_reply_to_user_id" : 467634146,
  "text" : "@4tunetellernet marvel(l)ous :)",
  "id" : 503984424175042560,
  "in_reply_to_status_id" : 503980880709578752,
  "created_at" : "2014-08-25 19:17:04 +0000",
  "in_reply_to_screen_name" : "4tunetellernet",
  "in_reply_to_user_id_str" : "467634146",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "indices" : [ 0, 12 ],
      "id_str" : "849729062",
      "id" : 849729062
    }, {
      "name" : "Robbie Love",
      "screen_name" : "lovermob",
      "indices" : [ 13, 22 ],
      "id_str" : "19469715",
      "id" : 19469715
    }, {
      "name" : "Daily Mail Online",
      "screen_name" : "MailOnline",
      "indices" : [ 23, 34 ],
      "id_str" : "15438913",
      "id" : 15438913
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/503979235045019648\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/3VVqzxvtvU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bv5-cWXIUAAWfWq.png",
      "id_str" : "503979233816104960",
      "id" : 503979233816104960,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bv5-cWXIUAAWfWq.png",
      "sizes" : [ {
        "h" : 132,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 75,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 223,
        "resize" : "fit",
        "w" : 1012
      }, {
        "h" : 223,
        "resize" : "fit",
        "w" : 1012
      } ],
      "display_url" : "pic.twitter.com\/3VVqzxvtvU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "503973904583376896",
  "geo" : { },
  "id_str" : "503979235045019648",
  "in_reply_to_user_id" : 849729062,
  "text" : "@TonyMcEnery @lovermob @MailOnline less of a 'mail' angle when seeing US language has shown similar pattern? ;) http:\/\/t.co\/3VVqzxvtvU",
  "id" : 503979235045019648,
  "in_reply_to_status_id" : 503973904583376896,
  "created_at" : "2014-08-25 18:56:27 +0000",
  "in_reply_to_screen_name" : "TonyMcEnery",
  "in_reply_to_user_id_str" : "849729062",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robbie Love",
      "screen_name" : "lovermob",
      "indices" : [ 3, 12 ],
      "id_str" : "19469715",
      "id" : 19469715
    }, {
      "name" : "Daily Mail Online",
      "screen_name" : "MailOnline",
      "indices" : [ 126, 137 ],
      "id_str" : "15438913",
      "id" : 15438913
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/8YZN007H3k",
      "expanded_url" : "http:\/\/dailym.ai\/1vfio9n",
      "display_url" : "dailym.ai\/1vfio9n"
    } ]
  },
  "geo" : { },
  "id_str" : "503972082708144128",
  "text" : "RT @lovermob: The Spoken BNC2014 in the Daily Mail: \"No longer marvellous - now we're all awesome\" http:\/\/t.co\/8YZN007H3k via @MailOnline",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Daily Mail Online",
        "screen_name" : "MailOnline",
        "indices" : [ 112, 123 ],
        "id_str" : "15438913",
        "id" : 15438913
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/8YZN007H3k",
        "expanded_url" : "http:\/\/dailym.ai\/1vfio9n",
        "display_url" : "dailym.ai\/1vfio9n"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 54.0483845, -2.8010455 ]
    },
    "id_str" : "503949489565347841",
    "text" : "The Spoken BNC2014 in the Daily Mail: \"No longer marvellous - now we're all awesome\" http:\/\/t.co\/8YZN007H3k via @MailOnline",
    "id" : 503949489565347841,
    "created_at" : "2014-08-25 16:58:15 +0000",
    "user" : {
      "name" : "Robbie Love",
      "screen_name" : "lovermob",
      "protected" : false,
      "id_str" : "19469715",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733371018056716288\/4lRj6knU_normal.jpg",
      "id" : 19469715,
      "verified" : false
    }
  },
  "id" : 503972082708144128,
  "created_at" : "2014-08-25 18:28:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NBC News",
      "screen_name" : "NBCNews",
      "indices" : [ 3, 11 ],
      "id_str" : "14173315",
      "id" : 14173315
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/NBCNews\/status\/503895547921440769\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/YwamLUfEhO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bv4yVLFCMAMiYG9.png",
      "id_str" : "503895547644620803",
      "id" : 503895547644620803,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bv4yVLFCMAMiYG9.png",
      "sizes" : [ {
        "h" : 231,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 501
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 501
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 501
      } ],
      "display_url" : "pic.twitter.com\/YwamLUfEhO"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/PfT4GhGl42",
      "expanded_url" : "http:\/\/nbcnews.to\/1ntGt49",
      "display_url" : "nbcnews.to\/1ntGt49"
    } ]
  },
  "geo" : { },
  "id_str" : "503971597364264960",
  "text" : "RT @NBCNews: Gazans launch \"rubble bucket challenge\" to call attention to the strife there http:\/\/t.co\/PfT4GhGl42 http:\/\/t.co\/YwamLUfEhO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/adobe.com\" rel=\"nofollow\"\u003EAdobe\u00AE Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/NBCNews\/status\/503895547921440769\/photo\/1",
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/YwamLUfEhO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bv4yVLFCMAMiYG9.png",
        "id_str" : "503895547644620803",
        "id" : 503895547644620803,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bv4yVLFCMAMiYG9.png",
        "sizes" : [ {
          "h" : 231,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 501
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 501
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 501
        } ],
        "display_url" : "pic.twitter.com\/YwamLUfEhO"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/PfT4GhGl42",
        "expanded_url" : "http:\/\/nbcnews.to\/1ntGt49",
        "display_url" : "nbcnews.to\/1ntGt49"
      } ]
    },
    "geo" : { },
    "id_str" : "503895547921440769",
    "text" : "Gazans launch \"rubble bucket challenge\" to call attention to the strife there http:\/\/t.co\/PfT4GhGl42 http:\/\/t.co\/YwamLUfEhO",
    "id" : 503895547921440769,
    "created_at" : "2014-08-25 13:23:55 +0000",
    "user" : {
      "name" : "NBC News",
      "screen_name" : "NBCNews",
      "protected" : false,
      "id_str" : "14173315",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/721554521957138436\/tTocueCd_normal.jpg",
      "id" : 14173315,
      "verified" : true
    }
  },
  "id" : 503971597364264960,
  "created_at" : "2014-08-25 18:26:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Sample",
      "screen_name" : "samplereality",
      "indices" : [ 3, 17 ],
      "id_str" : "8497292",
      "id" : 8497292
    }, {
      "name" : "ManicStreetPreachers",
      "screen_name" : "Manics",
      "indices" : [ 23, 30 ],
      "id_str" : "158416438",
      "id" : 158416438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/wVSupc0P0c",
      "expanded_url" : "http:\/\/youtu.be\/C4mIOINia8M",
      "display_url" : "youtu.be\/C4mIOINia8M"
    } ]
  },
  "geo" : { },
  "id_str" : "503952528867098625",
  "text" : "RT @samplereality: The @manics have finally made their Berlin album. It's dazzling. http:\/\/t.co\/wVSupc0P0c",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.metrotwit.com\/\" rel=\"nofollow\"\u003EMetroTwit\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ManicStreetPreachers",
        "screen_name" : "Manics",
        "indices" : [ 4, 11 ],
        "id_str" : "158416438",
        "id" : 158416438
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/wVSupc0P0c",
        "expanded_url" : "http:\/\/youtu.be\/C4mIOINia8M",
        "display_url" : "youtu.be\/C4mIOINia8M"
      } ]
    },
    "geo" : { },
    "id_str" : "503696932997705729",
    "text" : "The @manics have finally made their Berlin album. It's dazzling. http:\/\/t.co\/wVSupc0P0c",
    "id" : 503696932997705729,
    "created_at" : "2014-08-25 00:14:41 +0000",
    "user" : {
      "name" : "Mark Sample",
      "screen_name" : "samplereality",
      "protected" : false,
      "id_str" : "8497292",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000707852410\/a86167716ecb748acc89638ad165a162_normal.jpeg",
      "id" : 8497292,
      "verified" : false
    }
  },
  "id" : 503952528867098625,
  "created_at" : "2014-08-25 17:10:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nagendra Singh",
      "screen_name" : "nagendrasp",
      "indices" : [ 3, 14 ],
      "id_str" : "56630434",
      "id" : 56630434
    }, {
      "name" : "Amit Agarwal",
      "screen_name" : "labnol",
      "indices" : [ 132, 139 ],
      "id_str" : "724473",
      "id" : 724473
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/TvyaG96kuz",
      "expanded_url" : "http:\/\/labnol.org\/?p=8410",
      "display_url" : "labnol.org\/?p=8410"
    } ]
  },
  "geo" : { },
  "id_str" : "503951284572262401",
  "text" : "RT @nagendrasp: This was useful today! Find the Date When a Web Page was First Published on the Internet http:\/\/t.co\/TvyaG96kuz via @labnol",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Amit Agarwal",
        "screen_name" : "labnol",
        "indices" : [ 116, 123 ],
        "id_str" : "724473",
        "id" : 724473
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/TvyaG96kuz",
        "expanded_url" : "http:\/\/labnol.org\/?p=8410",
        "display_url" : "labnol.org\/?p=8410"
      } ]
    },
    "geo" : { },
    "id_str" : "503846749207687168",
    "text" : "This was useful today! Find the Date When a Web Page was First Published on the Internet http:\/\/t.co\/TvyaG96kuz via @labnol",
    "id" : 503846749207687168,
    "created_at" : "2014-08-25 10:10:00 +0000",
    "user" : {
      "name" : "Nagendra Singh",
      "screen_name" : "nagendrasp",
      "protected" : false,
      "id_str" : "56630434",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000529334178\/ef958ce909ad4169f0fd39fa005f72fa_normal.jpeg",
      "id" : 56630434,
      "verified" : false
    }
  },
  "id" : 503951284572262401,
  "created_at" : "2014-08-25 17:05:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 12, 23 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "503856428310753280",
  "geo" : { },
  "id_str" : "503911209738174464",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan @lexicoloco true, point is google results are too noisy so balanced corpus like coca much better",
  "id" : 503911209738174464,
  "in_reply_to_status_id" : 503856428310753280,
  "created_at" : "2014-08-25 14:26:09 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    }, {
      "name" : "IATEFL ReSIG",
      "screen_name" : "IATEFLResig",
      "indices" : [ 55, 67 ],
      "id_str" : "335823604",
      "id" : 335823604
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/9n9AZQ6ygT",
      "expanded_url" : "http:\/\/resig.weebly.com\/blog\/7-21-september-article-discussion-unpackaging-the-past-clt-through-eltj-keywords-elt-journal-664-430-439",
      "display_url" : "resig.weebly.com\/blog\/7-21-sept\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "503772431967064064",
  "geo" : { },
  "id_str" : "503832696700014592",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl pleasure fyi if not aware of it there will be a @IATEFLResig discussion of the article http:\/\/t.co\/9n9AZQ6ygT",
  "id" : 503832696700014592,
  "in_reply_to_status_id" : 503772431967064064,
  "created_at" : "2014-08-25 09:14:10 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Timothy Tate",
      "screen_name" : "Timothy_Tate",
      "indices" : [ 0, 13 ],
      "id_str" : "1084531170",
      "id" : 1084531170
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "503660600959188992",
  "geo" : { },
  "id_str" : "503665260617019393",
  "in_reply_to_user_id" : 1084531170,
  "text" : "@Timothy_Tate those r some hard rocking vegans from listening to spotify tracks",
  "id" : 503665260617019393,
  "in_reply_to_status_id" : 503660600959188992,
  "created_at" : "2014-08-24 22:08:50 +0000",
  "in_reply_to_screen_name" : "Timothy_Tate",
  "in_reply_to_user_id_str" : "1084531170",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 0, 14 ],
      "id_str" : "25388528",
      "id" : 25388528
    }, {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 25, 36 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/tbRcnO8JM9",
      "expanded_url" : "http:\/\/www.digitalcounterrevolution.co.uk\/2012\/the-crisis-of-education-hannah-arendt\/",
      "display_url" : "digitalcounterrevolution.co.uk\/2012\/the-crisi\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "503620342284156929",
  "geo" : { },
  "id_str" : "503659407209943042",
  "in_reply_to_user_id" : 25388528,
  "text" : "@audreywatters check out @tornhalves reading of Arendt if u haven't already http:\/\/t.co\/tbRcnO8JM9",
  "id" : 503659407209943042,
  "in_reply_to_status_id" : 503620342284156929,
  "created_at" : "2014-08-24 21:45:34 +0000",
  "in_reply_to_screen_name" : "audreywatters",
  "in_reply_to_user_id_str" : "25388528",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Costas Gabrielatos",
      "screen_name" : "congabonga",
      "indices" : [ 3, 14 ],
      "id_str" : "187484412",
      "id" : 187484412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/EalNOCeWmf",
      "expanded_url" : "http:\/\/m.chronicle.com\/article\/The-Shadow-Scholar\/125329\/",
      "display_url" : "m.chronicle.com\/article\/The-Sh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "503653111391875074",
  "text" : "RT @congabonga: \"The Shadow Scholar: The man who writes your students' papers tells his story\" http:\/\/t.co\/EalNOCeWmf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/EalNOCeWmf",
        "expanded_url" : "http:\/\/m.chronicle.com\/article\/The-Shadow-Scholar\/125329\/",
        "display_url" : "m.chronicle.com\/article\/The-Sh\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "503604031001210880",
    "text" : "\"The Shadow Scholar: The man who writes your students' papers tells his story\" http:\/\/t.co\/EalNOCeWmf",
    "id" : 503604031001210880,
    "created_at" : "2014-08-24 18:05:32 +0000",
    "user" : {
      "name" : "Costas Gabrielatos",
      "screen_name" : "congabonga",
      "protected" : false,
      "id_str" : "187484412",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/603260667534127104\/FkSbeNEt_normal.jpg",
      "id" : 187484412,
      "verified" : false
    }
  },
  "id" : 503653111391875074,
  "created_at" : "2014-08-24 21:20:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/mPxahD5Aj3",
      "expanded_url" : "http:\/\/eltj.oxfordjournals.org\/content\/66\/4\/430.full",
      "display_url" : "eltj.oxfordjournals.org\/content\/66\/4\/4\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "503638435702538240",
  "geo" : { },
  "id_str" : "503646646593671168",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl knowledge is ever critical e.g. your commenter can read how 'learners' were being talked about before CLT era http:\/\/t.co\/mPxahD5Aj3",
  "id" : 503646646593671168,
  "in_reply_to_status_id" : 503638435702538240,
  "created_at" : "2014-08-24 20:54:52 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Timothy Tate",
      "screen_name" : "Timothy_Tate",
      "indices" : [ 0, 13 ],
      "id_str" : "1084531170",
      "id" : 1084531170
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/nJple2NsCj",
      "expanded_url" : "http:\/\/everynoise.com\/engenremap.html",
      "display_url" : "everynoise.com\/engenremap.html"
    } ]
  },
  "geo" : { },
  "id_str" : "503540582657298432",
  "in_reply_to_user_id" : 1084531170,
  "text" : "@Timothy_Tate check this http:\/\/t.co\/nJple2NsCj",
  "id" : 503540582657298432,
  "created_at" : "2014-08-24 13:53:24 +0000",
  "in_reply_to_screen_name" : "Timothy_Tate",
  "in_reply_to_user_id_str" : "1084531170",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Moravec",
      "screen_name" : "ProfessMoravec",
      "indices" : [ 0, 15 ],
      "id_str" : "369529173",
      "id" : 369529173
    }, {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "indices" : [ 36, 48 ],
      "id_str" : "192437743",
      "id" : 192437743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/C5YdqNarit",
      "expanded_url" : "http:\/\/nathanghall.wordpress.com\/tag\/saw\/",
      "display_url" : "nathanghall.wordpress.com\/tag\/saw\/"
    } ]
  },
  "in_reply_to_status_id_str" : "502832736886067200",
  "geo" : { },
  "id_str" : "502838525868642304",
  "in_reply_to_user_id" : 369529173,
  "text" : "@ProfessMoravec you could check out @nathanghall uses as a webinar platform http:\/\/t.co\/C5YdqNarit",
  "id" : 502838525868642304,
  "in_reply_to_status_id" : 502832736886067200,
  "created_at" : "2014-08-22 15:23:41 +0000",
  "in_reply_to_screen_name" : "ProfessMoravec",
  "in_reply_to_user_id_str" : "369529173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Harbinson",
      "screen_name" : "DavidHarbinson",
      "indices" : [ 0, 15 ],
      "id_str" : "853078675",
      "id" : 853078675
    }, {
      "name" : "Forensic Linguistics",
      "screen_name" : "FORGE_LU",
      "indices" : [ 16, 25 ],
      "id_str" : "2211139201",
      "id" : 2211139201
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/QVVBWLZ4ct",
      "expanded_url" : "http:\/\/www.utica.edu\/academic\/institutes\/ecii\/publications\/articles\/B49F9C4A-0362-765C-6A235CB8ABDFACFF.pdf",
      "display_url" : "utica.edu\/academic\/insti\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "502824487281098753",
  "geo" : { },
  "id_str" : "502833627353612289",
  "in_reply_to_user_id" : 853078675,
  "text" : "@DavidHarbinson @FORGE_LU this paper esp on punctuations\/markedness (p5-7) i found interesting http:\/\/t.co\/QVVBWLZ4ct",
  "id" : 502833627353612289,
  "in_reply_to_status_id" : 502824487281098753,
  "created_at" : "2014-08-22 15:04:13 +0000",
  "in_reply_to_screen_name" : "DavidHarbinson",
  "in_reply_to_user_id_str" : "853078675",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 52, 68 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/QFWacmbDHV",
      "expanded_url" : "http:\/\/wp.me\/p2CPYN-f1",
      "display_url" : "wp.me\/p2CPYN-f1"
    } ]
  },
  "geo" : { },
  "id_str" : "502829302593753089",
  "text" : "Jonathan Rugman on Iraq. http:\/\/t.co\/QFWacmbDHV via @wordpressdotcom",
  "id" : 502829302593753089,
  "created_at" : "2014-08-22 14:47:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 3, 19 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELTchat",
      "indices" : [ 93, 101 ]
    }, {
      "text" : "iTDi",
      "indices" : [ 102, 107 ]
    }, {
      "text" : "KELTchat",
      "indices" : [ 108, 117 ]
    }, {
      "text" : "Auselt",
      "indices" : [ 118, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/5dWxbtuAFz",
      "expanded_url" : "http:\/\/wp.me\/p25Kfd-yF",
      "display_url" : "wp.me\/p25Kfd-yF"
    } ]
  },
  "geo" : { },
  "id_str" : "502572536174215168",
  "text" : "RT @michaelegriffin: New on my blog: Interview with Marcos Benevides  http:\/\/t.co\/5dWxbtuAFz #ELTchat #iTDi #KELTchat #Auselt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELTchat",
        "indices" : [ 72, 80 ]
      }, {
        "text" : "iTDi",
        "indices" : [ 81, 86 ]
      }, {
        "text" : "KELTchat",
        "indices" : [ 87, 96 ]
      }, {
        "text" : "Auselt",
        "indices" : [ 97, 104 ]
      } ],
      "urls" : [ {
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/5dWxbtuAFz",
        "expanded_url" : "http:\/\/wp.me\/p25Kfd-yF",
        "display_url" : "wp.me\/p25Kfd-yF"
      } ]
    },
    "geo" : { },
    "id_str" : "502570608941486080",
    "text" : "New on my blog: Interview with Marcos Benevides  http:\/\/t.co\/5dWxbtuAFz #ELTchat #iTDi #KELTchat #Auselt",
    "id" : 502570608941486080,
    "created_at" : "2014-08-21 21:39:05 +0000",
    "user" : {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "protected" : false,
      "id_str" : "394053348",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766911330645315584\/il5gKyOJ_normal.jpg",
      "id" : 394053348,
      "verified" : false
    }
  },
  "id" : 502572536174215168,
  "created_at" : "2014-08-21 21:46:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "502567767263182849",
  "geo" : { },
  "id_str" : "502570861770313728",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan use COCA or GLOWBE and not Google? :)",
  "id" : 502570861770313728,
  "in_reply_to_status_id" : 502567767263182849,
  "created_at" : "2014-08-21 21:40:05 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/PvmUNxVRj2",
      "expanded_url" : "http:\/\/members5.boardhost.com\/medialens\/msg\/1408648367.html",
      "display_url" : "members5.boardhost.com\/medialens\/msg\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "502564502215614465",
  "text" : "\"Your allegiances seem to be as changeable as your daft socks\" Snowmail...Short email to 6 Pilgers http:\/\/t.co\/PvmUNxVRj2",
  "id" : 502564502215614465,
  "created_at" : "2014-08-21 21:14:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "indices" : [ 3, 12 ],
      "id_str" : "167020390",
      "id" : 167020390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 124, 140 ],
      "url" : "http:\/\/t.co\/VoXQEubkPt",
      "expanded_url" : "http:\/\/www.antlab.sci.waseda.ac.jp\/software.html",
      "display_url" : "antlab.sci.waseda.ac.jp\/software.html"
    } ]
  },
  "geo" : { },
  "id_str" : "502459814392647681",
  "text" : "RT @antlabjp: A Macintosh OS X (Mavericks) compatible version of AntConc (3.4.2) is now available. No more refresh problem. http:\/\/t.co\/VoX\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/VoXQEubkPt",
        "expanded_url" : "http:\/\/www.antlab.sci.waseda.ac.jp\/software.html",
        "display_url" : "antlab.sci.waseda.ac.jp\/software.html"
      } ]
    },
    "geo" : { },
    "id_str" : "502451416472883200",
    "text" : "A Macintosh OS X (Mavericks) compatible version of AntConc (3.4.2) is now available. No more refresh problem. http:\/\/t.co\/VoXQEubkPt.",
    "id" : 502451416472883200,
    "created_at" : "2014-08-21 13:45:27 +0000",
    "user" : {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "protected" : false,
      "id_str" : "167020390",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/428183580821315584\/ocgCI7Er_normal.jpeg",
      "id" : 167020390,
      "verified" : false
    }
  },
  "id" : 502459814392647681,
  "created_at" : "2014-08-21 14:18:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 3, 18 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/77zUKV8aLa",
      "expanded_url" : "http:\/\/www.bbc.co.uk\/programmes\/b04dmxwl",
      "display_url" : "bbc.co.uk\/programmes\/b04\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "502165113995292672",
  "text" : "RT @GeoffreyJordan: What really works in schools and classrooms? V. good interview with John Hattie http:\/\/t.co\/77zUKV8aLa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/77zUKV8aLa",
        "expanded_url" : "http:\/\/www.bbc.co.uk\/programmes\/b04dmxwl",
        "display_url" : "bbc.co.uk\/programmes\/b04\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "502152589191151616",
    "text" : "What really works in schools and classrooms? V. good interview with John Hattie http:\/\/t.co\/77zUKV8aLa",
    "id" : 502152589191151616,
    "created_at" : "2014-08-20 17:58:01 +0000",
    "user" : {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "protected" : false,
      "id_str" : "334332424",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/455317817537986561\/SD4wNKO3_normal.jpeg",
      "id" : 334332424,
      "verified" : false
    }
  },
  "id" : 502165113995292672,
  "created_at" : "2014-08-20 18:47:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 3, 17 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "502127786216394752",
  "text" : "RT @audreywatters: The US constitution burns in Ferguson. Meanwhile, has your favorite white rockstar\/politician\/CEO made an icebox video y\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "501976865586692097",
    "text" : "The US constitution burns in Ferguson. Meanwhile, has your favorite white rockstar\/politician\/CEO made an icebox video yet?",
    "id" : 501976865586692097,
    "created_at" : "2014-08-20 06:19:45 +0000",
    "user" : {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "protected" : false,
      "id_str" : "25388528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711668009723498496\/pauFZsdv_normal.jpg",
      "id" : 25388528,
      "verified" : false
    }
  },
  "id" : 502127786216394752,
  "created_at" : "2014-08-20 16:19:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Hardie",
      "screen_name" : "HardieResearch",
      "indices" : [ 3, 18 ],
      "id_str" : "970452764",
      "id" : 970452764
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/PczsDuAcF5",
      "expanded_url" : "http:\/\/cass.lancs.ac.uk\/?p=1358",
      "display_url" : "cass.lancs.ac.uk\/?p=1358"
    } ]
  },
  "geo" : { },
  "id_str" : "502122251236675584",
  "text" : "RT @HardieResearch: Our colleague and friend, Prof. Geoffrey Leech, passed away yesterday. A first, brief tribute: http:\/\/t.co\/PczsDuAcF5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/PczsDuAcF5",
        "expanded_url" : "http:\/\/cass.lancs.ac.uk\/?p=1358",
        "display_url" : "cass.lancs.ac.uk\/?p=1358"
      } ]
    },
    "geo" : { },
    "id_str" : "502104924130668544",
    "text" : "Our colleague and friend, Prof. Geoffrey Leech, passed away yesterday. A first, brief tribute: http:\/\/t.co\/PczsDuAcF5",
    "id" : 502104924130668544,
    "created_at" : "2014-08-20 14:48:37 +0000",
    "user" : {
      "name" : "Andrew Hardie",
      "screen_name" : "HardieResearch",
      "protected" : false,
      "id_str" : "970452764",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2895091886\/5274f8f34de87999703c0f92adfdf465_normal.jpeg",
      "id" : 970452764,
      "verified" : false
    }
  },
  "id" : 502122251236675584,
  "created_at" : "2014-08-20 15:57:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George Chilton",
      "screen_name" : "designerlessons",
      "indices" : [ 0, 16 ],
      "id_str" : "432090149",
      "id" : 432090149
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "501861374155567104",
  "geo" : { },
  "id_str" : "501878435560824832",
  "in_reply_to_user_id" : 432090149,
  "text" : "@designerlessons maybe students also walked out hearing memes still being flogged as a serious idea? :\/",
  "id" : 501878435560824832,
  "in_reply_to_status_id" : 501861374155567104,
  "created_at" : "2014-08-19 23:48:38 +0000",
  "in_reply_to_screen_name" : "designerlessons",
  "in_reply_to_user_id_str" : "432090149",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Brown",
      "screen_name" : "sbrowntweets",
      "indices" : [ 14, 27 ],
      "id_str" : "885343459",
      "id" : 885343459
    }, {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 28, 43 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/MxFqlkH0xK",
      "expanded_url" : "http:\/\/wp.me\/p4XmN0-3",
      "display_url" : "wp.me\/p4XmN0-3"
    } ]
  },
  "geo" : { },
  "id_str" : "501857533980860416",
  "text" : "RT @becksdad: @sbrowntweets @GeoffreyJordan I put my money where my mouth is and started the blog I was threatening to: http:\/\/t.co\/MxFqlkH\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Steve Brown",
        "screen_name" : "sbrowntweets",
        "indices" : [ 0, 13 ],
        "id_str" : "885343459",
        "id" : 885343459
      }, {
        "name" : "Geoffrey Jordan",
        "screen_name" : "GeoffreyJordan",
        "indices" : [ 14, 29 ],
        "id_str" : "334332424",
        "id" : 334332424
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/MxFqlkH0xK",
        "expanded_url" : "http:\/\/wp.me\/p4XmN0-3",
        "display_url" : "wp.me\/p4XmN0-3"
      } ]
    },
    "geo" : { },
    "id_str" : "501850459880316928",
    "in_reply_to_user_id" : 885343459,
    "text" : "@sbrowntweets @GeoffreyJordan I put my money where my mouth is and started the blog I was threatening to: http:\/\/t.co\/MxFqlkH0xK",
    "id" : 501850459880316928,
    "created_at" : "2014-08-19 21:57:28 +0000",
    "in_reply_to_screen_name" : "sbrowntweets",
    "in_reply_to_user_id_str" : "885343459",
    "user" : {
      "name" : "Neil McMillan",
      "screen_name" : "neil_mcm",
      "protected" : false,
      "id_str" : "60425505",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/419471700510920704\/RMN34luB_normal.jpeg",
      "id" : 60425505,
      "verified" : false
    }
  },
  "id" : 501857533980860416,
  "created_at" : "2014-08-19 22:25:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark J Doran",
      "screen_name" : "MarkJDoran",
      "indices" : [ 3, 14 ],
      "id_str" : "19364252",
      "id" : 19364252
    }, {
      "name" : "BBC Breaking News",
      "screen_name" : "BBCBreaking",
      "indices" : [ 17, 29 ],
      "id_str" : "5402612",
      "id" : 5402612
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BBCbias",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "501829015062061056",
  "text" : "RT @MarkJDoran: .@BBCBreaking You just can't make yourselves say it, can you? The girl was killed *BY* an Israeli air strike, not 'after' i\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BBC Breaking News",
        "screen_name" : "BBCBreaking",
        "indices" : [ 1, 13 ],
        "id_str" : "5402612",
        "id" : 5402612
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BBCbias",
        "indices" : [ 126, 134 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "501814214831636482",
    "geo" : { },
    "id_str" : "501816158358880256",
    "in_reply_to_user_id" : 5402612,
    "text" : ".@BBCBreaking You just can't make yourselves say it, can you? The girl was killed *BY* an Israeli air strike, not 'after' it. #BBCbias",
    "id" : 501816158358880256,
    "in_reply_to_status_id" : 501814214831636482,
    "created_at" : "2014-08-19 19:41:10 +0000",
    "in_reply_to_screen_name" : "BBCBreaking",
    "in_reply_to_user_id_str" : "5402612",
    "user" : {
      "name" : "Mark J Doran",
      "screen_name" : "MarkJDoran",
      "protected" : false,
      "id_str" : "19364252",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747220190887239680\/1sS-3xVw_normal.jpg",
      "id" : 19364252,
      "verified" : false
    }
  },
  "id" : 501829015062061056,
  "created_at" : "2014-08-19 20:32:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    }, {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 7, 18 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "501755063950643200",
  "geo" : { },
  "id_str" : "501828227459854336",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl @lexicoloco colour me jaded but i c this more as a disciplinary tool than an educational tool :\/",
  "id" : 501828227459854336,
  "in_reply_to_status_id" : 501755063950643200,
  "created_at" : "2014-08-19 20:29:07 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    }, {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 12, 18 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    }, {
      "name" : "Lynne Murphy",
      "screen_name" : "lynneguist",
      "indices" : [ 19, 30 ],
      "id_str" : "16316886",
      "id" : 16316886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "501684341291110400",
  "geo" : { },
  "id_str" : "501688046224695296",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco @ebefl @lynneguist agr poss use for autonom lang learnrs, others? Pullam ignoring management use concerns?",
  "id" : 501688046224695296,
  "in_reply_to_status_id" : 501684341291110400,
  "created_at" : "2014-08-19 11:12:05 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    }, {
      "name" : "Lynne Murphy",
      "screen_name" : "lynneguist",
      "indices" : [ 7, 18 ],
      "id_str" : "16316886",
      "id" : 16316886
    }, {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 19, 30 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "501603189331087360",
  "geo" : { },
  "id_str" : "501653855483224065",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl @lynneguist @lexicoloco and even less chance of getting paid for marking in future with these kinds of tools...",
  "id" : 501653855483224065,
  "in_reply_to_status_id" : 501603189331087360,
  "created_at" : "2014-08-19 08:56:14 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "501512479844106240",
  "geo" : { },
  "id_str" : "501513555800113153",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco or prob of robos as final grade given increasing student numbers?",
  "id" : 501513555800113153,
  "in_reply_to_status_id" : 501512479844106240,
  "created_at" : "2014-08-18 23:38:44 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lynne Murphy",
      "screen_name" : "lynneguist",
      "indices" : [ 0, 11 ],
      "id_str" : "16316886",
      "id" : 16316886
    }, {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 12, 23 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "501420238987337728",
  "geo" : { },
  "id_str" : "501511837678964737",
  "in_reply_to_user_id" : 16316886,
  "text" : "@lynneguist @lexicoloco what's probability robos will be used as wage bargaining tool given that management seek to cut cost?",
  "id" : 501511837678964737,
  "in_reply_to_status_id" : 501420238987337728,
  "created_at" : "2014-08-18 23:31:54 +0000",
  "in_reply_to_screen_name" : "lynneguist",
  "in_reply_to_user_id_str" : "16316886",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yuichiro Kobayashi",
      "screen_name" : "langstat",
      "indices" : [ 3, 12 ],
      "id_str" : "108896452",
      "id" : 108896452
    }, {
      "name" : "Corpusbaalsig",
      "screen_name" : "corpusbaalsig",
      "indices" : [ 17, 31 ],
      "id_str" : "2741766716",
      "id" : 2741766716
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BAAL",
      "indices" : [ 33, 38 ]
    }, {
      "text" : "CorpusLinguistics",
      "indices" : [ 39, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "501500857326649344",
  "text" : "RT @langstat: RT @corpusbaalsig: #BAAL #CorpusLinguistics SIG is now on twitter keeping you informed as to what we're up to! Please follow \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Corpusbaalsig",
        "screen_name" : "corpusbaalsig",
        "indices" : [ 3, 17 ],
        "id_str" : "2741766716",
        "id" : 2741766716
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BAAL",
        "indices" : [ 19, 24 ]
      }, {
        "text" : "CorpusLinguistics",
        "indices" : [ 25, 43 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "501358371551707136",
    "text" : "RT @corpusbaalsig: #BAAL #CorpusLinguistics SIG is now on twitter keeping you informed as to what we're up to! Please follow us!",
    "id" : 501358371551707136,
    "created_at" : "2014-08-18 13:22:05 +0000",
    "user" : {
      "name" : "Yuichiro Kobayashi",
      "screen_name" : "langstat",
      "protected" : false,
      "id_str" : "108896452",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1111159202\/profile_normal.gif",
      "id" : 108896452,
      "verified" : false
    }
  },
  "id" : 501500857326649344,
  "created_at" : "2014-08-18 22:48:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 64, 80 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/4xRRp7G85C",
      "expanded_url" : "http:\/\/wp.me\/p2CPYN-eO",
      "display_url" : "wp.me\/p2CPYN-eO"
    } ]
  },
  "geo" : { },
  "id_str" : "501428100761010176",
  "text" : "'Every far-Lefty's worst nightmare'. http:\/\/t.co\/4xRRp7G85C via @wordpressdotcom",
  "id" : 501428100761010176,
  "created_at" : "2014-08-18 17:59:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LSE Public Affairs",
      "screen_name" : "LSEPubAffairs",
      "indices" : [ 0, 14 ],
      "id_str" : "1288778468",
      "id" : 1288778468
    }, {
      "name" : "Achilleas Kostoulas",
      "screen_name" : "AchilleasK",
      "indices" : [ 15, 26 ],
      "id_str" : "134191406",
      "id" : 134191406
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "501301987422769153",
  "geo" : { },
  "id_str" : "501306872948092928",
  "in_reply_to_user_id" : 1288778468,
  "text" : "@LSEPubAffairs @AchilleasK worthy victims armed by political and moral right",
  "id" : 501306872948092928,
  "in_reply_to_status_id" : 501301987422769153,
  "created_at" : "2014-08-18 09:57:27 +0000",
  "in_reply_to_screen_name" : "LSEPubAffairs",
  "in_reply_to_user_id_str" : "1288778468",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Air France",
      "screen_name" : "airfrance",
      "indices" : [ 0, 10 ],
      "id_str" : "106062176",
      "id" : 106062176
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "501301400068825088",
  "geo" : { },
  "id_str" : "501303722035929088",
  "in_reply_to_user_id" : 106062176,
  "text" : "@airfrance ok",
  "id" : 501303722035929088,
  "in_reply_to_status_id" : 501301400068825088,
  "created_at" : "2014-08-18 09:44:55 +0000",
  "in_reply_to_screen_name" : "airfrance",
  "in_reply_to_user_id_str" : "106062176",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nelson Flores",
      "screen_name" : "nelsonlflores",
      "indices" : [ 105, 119 ],
      "id_str" : "248343882",
      "id" : 248343882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/3MU7n4kBPu",
      "expanded_url" : "http:\/\/wp.me\/p45k2O-2B",
      "display_url" : "wp.me\/p45k2O-2B"
    } ]
  },
  "geo" : { },
  "id_str" : "500736826806927360",
  "text" : "The Fundamental Disposability of Black and Brown Bodies and Education Reform: http:\/\/t.co\/3MU7n4kBPu via @nelsonlflores",
  "id" : 500736826806927360,
  "created_at" : "2014-08-16 20:12:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Huw Jarvis",
      "screen_name" : "TESOLacademic",
      "indices" : [ 3, 17 ],
      "id_str" : "43409552",
      "id" : 43409552
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tesol",
      "indices" : [ 100, 106 ]
    }, {
      "text" : "tesolac",
      "indices" : [ 107, 115 ]
    }, {
      "text" : "elt",
      "indices" : [ 116, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/i4QzNyYyN3",
      "expanded_url" : "http:\/\/youtu.be\/UKQcVE9d67s",
      "display_url" : "youtu.be\/UKQcVE9d67s"
    }, {
      "indices" : [ 143, 144 ],
      "url" : "http:\/\/t.co\/kJrerh9gOp",
      "expanded_url" : "http:\/\/www.tesolacademic.org",
      "display_url" : "tesolacademic.org"
    } ]
  },
  "geo" : { },
  "id_str" : "500730204919459840",
  "text" : "RT @TESOLacademic: Prof. McCarthy reflects on corpora &amp; spoken language: http:\/\/t.co\/i4QzNyYyN3 #tesol #tesolac #elt More Keynotes from htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tesol",
        "indices" : [ 81, 87 ]
      }, {
        "text" : "tesolac",
        "indices" : [ 88, 96 ]
      }, {
        "text" : "elt",
        "indices" : [ 97, 101 ]
      } ],
      "urls" : [ {
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/i4QzNyYyN3",
        "expanded_url" : "http:\/\/youtu.be\/UKQcVE9d67s",
        "display_url" : "youtu.be\/UKQcVE9d67s"
      }, {
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/kJrerh9gOp",
        "expanded_url" : "http:\/\/www.tesolacademic.org",
        "display_url" : "tesolacademic.org"
      } ]
    },
    "geo" : { },
    "id_str" : "500531934900940801",
    "text" : "Prof. McCarthy reflects on corpora &amp; spoken language: http:\/\/t.co\/i4QzNyYyN3 #tesol #tesolac #elt More Keynotes from http:\/\/t.co\/kJrerh9gOp",
    "id" : 500531934900940801,
    "created_at" : "2014-08-16 06:38:07 +0000",
    "user" : {
      "name" : "Huw Jarvis",
      "screen_name" : "TESOLacademic",
      "protected" : false,
      "id_str" : "43409552",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/569419268\/bg-logo_normal.jpg",
      "id" : 43409552,
      "verified" : false
    }
  },
  "id" : 500730204919459840,
  "created_at" : "2014-08-16 19:45:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "indices" : [ 3, 18 ],
      "id_str" : "152194866",
      "id" : 152194866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "education",
      "indices" : [ 63, 73 ]
    }, {
      "text" : "Xerte",
      "indices" : [ 74, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/tEe9UNP9DI",
      "expanded_url" : "http:\/\/ow.ly\/AnG2q",
      "display_url" : "ow.ly\/AnG2q"
    } ]
  },
  "geo" : { },
  "id_str" : "500713340583542784",
  "text" : "RT @patrickDurusau: XPERT (Xerte Public E-learning ReposiTory) #education #Xerte http:\/\/t.co\/tEe9UNP9DI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "education",
        "indices" : [ 43, 53 ]
      }, {
        "text" : "Xerte",
        "indices" : [ 54, 60 ]
      } ],
      "urls" : [ {
        "indices" : [ 61, 83 ],
        "url" : "http:\/\/t.co\/tEe9UNP9DI",
        "expanded_url" : "http:\/\/ow.ly\/AnG2q",
        "display_url" : "ow.ly\/AnG2q"
      } ]
    },
    "geo" : { },
    "id_str" : "500477093613154305",
    "text" : "XPERT (Xerte Public E-learning ReposiTory) #education #Xerte http:\/\/t.co\/tEe9UNP9DI",
    "id" : 500477093613154305,
    "created_at" : "2014-08-16 03:00:12 +0000",
    "user" : {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "protected" : false,
      "id_str" : "152194866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/961579480\/patrick_normal.jpeg",
      "id" : 152194866,
      "verified" : false
    }
  },
  "id" : 500713340583542784,
  "created_at" : "2014-08-16 18:38:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 0, 9 ],
      "id_str" : "121063600",
      "id" : 121063600
    }, {
      "name" : "Antoine Besnehard",
      "screen_name" : "Languages2_0",
      "indices" : [ 10, 23 ],
      "id_str" : "28194214",
      "id" : 28194214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "500627953563467776",
  "geo" : { },
  "id_str" : "500663801751302146",
  "in_reply_to_user_id" : 121063600,
  "text" : "@whyshona @Languages2_0 thx for share  hope u r enjoying the end of summer :)",
  "id" : 500663801751302146,
  "in_reply_to_status_id" : 500627953563467776,
  "created_at" : "2014-08-16 15:22:06 +0000",
  "in_reply_to_screen_name" : "whyshona",
  "in_reply_to_user_id_str" : "121063600",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "indices" : [ 3, 14 ],
      "id_str" : "152051625",
      "id" : 152051625
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 78, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/MvELZrVq4o",
      "expanded_url" : "http:\/\/bit.ly\/1oUUxIy",
      "display_url" : "bit.ly\/1oUUxIy"
    } ]
  },
  "geo" : { },
  "id_str" : "500324317159514112",
  "text" : "RT @heatherfro: is this some discourse analysis on print media's reporting on #Ferguson? I think it is http:\/\/t.co\/MvELZrVq4o",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Ferguson",
        "indices" : [ 62, 71 ]
      } ],
      "urls" : [ {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/MvELZrVq4o",
        "expanded_url" : "http:\/\/bit.ly\/1oUUxIy",
        "display_url" : "bit.ly\/1oUUxIy"
      } ]
    },
    "geo" : { },
    "id_str" : "500246336248487937",
    "text" : "is this some discourse analysis on print media's reporting on #Ferguson? I think it is http:\/\/t.co\/MvELZrVq4o",
    "id" : 500246336248487937,
    "created_at" : "2014-08-15 11:43:15 +0000",
    "user" : {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "protected" : false,
      "id_str" : "152051625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/688767277022494720\/KMrzOBc1_normal.jpg",
      "id" : 152051625,
      "verified" : false
    }
  },
  "id" : 500324317159514112,
  "created_at" : "2014-08-15 16:53:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jo Sayers",
      "screen_name" : "jo_sayers",
      "indices" : [ 3, 13 ],
      "id_str" : "87176766",
      "id" : 87176766
    }, {
      "name" : "ELTjam",
      "screen_name" : "eltjam",
      "indices" : [ 22, 29 ],
      "id_str" : "1356363686",
      "id" : 1356363686
    }, {
      "name" : "LearnEnglish",
      "screen_name" : "LearnEnglish_BC",
      "indices" : [ 46, 62 ],
      "id_str" : "21316293",
      "id" : 21316293
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 110, 114 ]
    }, {
      "text" : "edtech",
      "indices" : [ 115, 122 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 123, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/6TzR68lH7L",
      "expanded_url" : "http:\/\/eltjam.com\/review-writing-for-a-purpose\/",
      "display_url" : "eltjam.com\/review-writing\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "499919644166467585",
  "text" : "RT @jo_sayers: New on @eltjam blog. Review of @LearnEnglish_BC's Writing for a Purpose http:\/\/t.co\/6TzR68lH7L #elt #edtech #eltchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ELTjam",
        "screen_name" : "eltjam",
        "indices" : [ 7, 14 ],
        "id_str" : "1356363686",
        "id" : 1356363686
      }, {
        "name" : "LearnEnglish",
        "screen_name" : "LearnEnglish_BC",
        "indices" : [ 31, 47 ],
        "id_str" : "21316293",
        "id" : 21316293
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "elt",
        "indices" : [ 95, 99 ]
      }, {
        "text" : "edtech",
        "indices" : [ 100, 107 ]
      }, {
        "text" : "eltchat",
        "indices" : [ 108, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/6TzR68lH7L",
        "expanded_url" : "http:\/\/eltjam.com\/review-writing-for-a-purpose\/",
        "display_url" : "eltjam.com\/review-writing\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "499879305187688448",
    "text" : "New on @eltjam blog. Review of @LearnEnglish_BC's Writing for a Purpose http:\/\/t.co\/6TzR68lH7L #elt #edtech #eltchat",
    "id" : 499879305187688448,
    "created_at" : "2014-08-14 11:24:48 +0000",
    "user" : {
      "name" : "Jo Sayers",
      "screen_name" : "jo_sayers",
      "protected" : false,
      "id_str" : "87176766",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/466896591480037376\/EssZHYa4_normal.jpeg",
      "id" : 87176766,
      "verified" : false
    }
  },
  "id" : 499919644166467585,
  "created_at" : "2014-08-14 14:05:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doug Belshaw",
      "screen_name" : "dajbelshaw",
      "indices" : [ 0, 11 ],
      "id_str" : "764365",
      "id" : 764365
    }, {
      "name" : "Richard Whiteside",
      "screen_name" : "nutrich",
      "indices" : [ 12, 20 ],
      "id_str" : "95495064",
      "id" : 95495064
    }, {
      "name" : "IH London",
      "screen_name" : "IHLondon",
      "indices" : [ 21, 30 ],
      "id_str" : "21182478",
      "id" : 21182478
    }, {
      "name" : "TheConsultantsE",
      "screen_name" : "TheConsultantsE",
      "indices" : [ 31, 47 ],
      "id_str" : "13435662",
      "id" : 13435662
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "499853905011150848",
  "geo" : { },
  "id_str" : "499859340699111424",
  "in_reply_to_user_id" : 764365,
  "text" : "@dajbelshaw @nutrich @IHLondon @TheConsultantsE great :)",
  "id" : 499859340699111424,
  "in_reply_to_status_id" : 499853905011150848,
  "created_at" : "2014-08-14 10:05:28 +0000",
  "in_reply_to_screen_name" : "dajbelshaw",
  "in_reply_to_user_id_str" : "764365",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Whiteside",
      "screen_name" : "nutrich",
      "indices" : [ 0, 8 ],
      "id_str" : "95495064",
      "id" : 95495064
    }, {
      "name" : "Doug Belshaw",
      "screen_name" : "dajbelshaw",
      "indices" : [ 9, 20 ],
      "id_str" : "764365",
      "id" : 764365
    }, {
      "name" : "IH London",
      "screen_name" : "IHLondon",
      "indices" : [ 21, 30 ],
      "id_str" : "21182478",
      "id" : 21182478
    }, {
      "name" : "TheConsultantsE",
      "screen_name" : "TheConsultantsE",
      "indices" : [ 31, 47 ],
      "id_str" : "13435662",
      "id" : 13435662
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "499206094607380480",
  "geo" : { },
  "id_str" : "499851074921328641",
  "in_reply_to_user_id" : 95495064,
  "text" : "@nutrich @dajbelshaw @IHLondon @TheConsultantsE  strange image changed since attribution wld have been to another gd resource for dig lit :\/",
  "id" : 499851074921328641,
  "in_reply_to_status_id" : 499206094607380480,
  "created_at" : "2014-08-14 09:32:37 +0000",
  "in_reply_to_screen_name" : "nutrich",
  "in_reply_to_user_id_str" : "95495064",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jack Askew",
      "screen_name" : "eslonlinejack",
      "indices" : [ 3, 17 ],
      "id_str" : "1513170398",
      "id" : 1513170398
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/eslonlinejack\/status\/499185267404992512\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/Ogh7r9OUEL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bu12WuMCIAAZrwJ.png",
      "id_str" : "499185266435694592",
      "id" : 499185266435694592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bu12WuMCIAAZrwJ.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/Ogh7r9OUEL"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/4F2OONHB0P",
      "expanded_url" : "http:\/\/bit.ly\/1AaysJr",
      "display_url" : "bit.ly\/1AaysJr"
    } ]
  },
  "geo" : { },
  "id_str" : "499187140891512832",
  "text" : "RT @eslonlinejack: The Teach English Online Course is live! http:\/\/t.co\/4F2OONHB0P See you on the inside! http:\/\/t.co\/Ogh7r9OUEL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/eslonlinejack\/status\/499185267404992512\/photo\/1",
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/Ogh7r9OUEL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bu12WuMCIAAZrwJ.png",
        "id_str" : "499185266435694592",
        "id" : 499185266435694592,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bu12WuMCIAAZrwJ.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/Ogh7r9OUEL"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/4F2OONHB0P",
        "expanded_url" : "http:\/\/bit.ly\/1AaysJr",
        "display_url" : "bit.ly\/1AaysJr"
      } ]
    },
    "geo" : { },
    "id_str" : "499185267404992512",
    "text" : "The Teach English Online Course is live! http:\/\/t.co\/4F2OONHB0P See you on the inside! http:\/\/t.co\/Ogh7r9OUEL",
    "id" : 499185267404992512,
    "created_at" : "2014-08-12 13:26:56 +0000",
    "user" : {
      "name" : "Jack Askew",
      "screen_name" : "eslonlinejack",
      "protected" : false,
      "id_str" : "1513170398",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/484685723677638657\/aIA1Yymj_normal.png",
      "id" : 1513170398,
      "verified" : false
    }
  },
  "id" : 499187140891512832,
  "created_at" : "2014-08-12 13:34:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IH London",
      "screen_name" : "IHLondon",
      "indices" : [ 0, 9 ],
      "id_str" : "21182478",
      "id" : 21182478
    }, {
      "name" : "Richard Whiteside",
      "screen_name" : "nutrich",
      "indices" : [ 10, 18 ],
      "id_str" : "95495064",
      "id" : 95495064
    }, {
      "name" : "TheConsultantsE",
      "screen_name" : "TheConsultantsE",
      "indices" : [ 19, 35 ],
      "id_str" : "13435662",
      "id" : 13435662
    }, {
      "name" : "Doug Belshaw",
      "screen_name" : "dajbelshaw",
      "indices" : [ 87, 98 ],
      "id_str" : "764365",
      "id" : 764365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "497309052402417664",
  "geo" : { },
  "id_str" : "499183600152367105",
  "in_reply_to_user_id" : 21182478,
  "text" : "@IHLondon @nutrich @TheConsultantsE Maybe its my phone but 1st image no attribution to @dajbelshaw ?",
  "id" : 499183600152367105,
  "in_reply_to_status_id" : 497309052402417664,
  "created_at" : "2014-08-12 13:20:19 +0000",
  "in_reply_to_screen_name" : "IHLondon",
  "in_reply_to_user_id_str" : "21182478",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Air France",
      "screen_name" : "airfrance",
      "indices" : [ 0, 10 ],
      "id_str" : "106062176",
      "id" : 106062176
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "497465710101008384",
  "geo" : { },
  "id_str" : "497466625898315776",
  "in_reply_to_user_id" : 106062176,
  "text" : "@airfrance well going to be too late as we are leaving tomorrow morning and won't be back till Sun 17 Aug, &amp; means buying new clothes! :\/",
  "id" : 497466625898315776,
  "in_reply_to_status_id" : 497465710101008384,
  "created_at" : "2014-08-07 19:37:40 +0000",
  "in_reply_to_screen_name" : "airfrance",
  "in_reply_to_user_id_str" : "106062176",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Air France",
      "screen_name" : "airfrance",
      "indices" : [ 0, 10 ],
      "id_str" : "106062176",
      "id" : 106062176
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "patheticairline",
      "indices" : [ 86, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "497451859679121408",
  "in_reply_to_user_id" : 106062176,
  "text" : "@airfrance you only had to deliver one missing luggage and it has already been 2 days #patheticairline",
  "id" : 497451859679121408,
  "created_at" : "2014-08-07 18:39:00 +0000",
  "in_reply_to_screen_name" : "airfrance",
  "in_reply_to_user_id_str" : "106062176",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Max Planck Society",
      "screen_name" : "maxplanckpress",
      "indices" : [ 3, 18 ],
      "id_str" : "205195655",
      "id" : 205195655
    }, {
      "name" : "MIT Tech Review",
      "screen_name" : "techreview",
      "indices" : [ 136, 144 ],
      "id_str" : "15808647",
      "id" : 15808647
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "linguistics",
      "indices" : [ 34, 46 ]
    }, {
      "text" : "Twitter",
      "indices" : [ 50, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/QNTxn9K6L4",
      "expanded_url" : "http:\/\/bit.ly\/1slO2gQ",
      "display_url" : "bit.ly\/1slO2gQ"
    } ]
  },
  "geo" : { },
  "id_str" : "497425337689866241",
  "text" : "RT @maxplanckpress: Computational #linguistics of #Twitter shines spotlight on city &amp; rural superdialects: http:\/\/t.co\/QNTxn9K6L4 RT@techre\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "MIT Tech Review",
        "screen_name" : "techreview",
        "indices" : [ 116, 127 ],
        "id_str" : "15808647",
        "id" : 15808647
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "linguistics",
        "indices" : [ 14, 26 ]
      }, {
        "text" : "Twitter",
        "indices" : [ 30, 38 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/QNTxn9K6L4",
        "expanded_url" : "http:\/\/bit.ly\/1slO2gQ",
        "display_url" : "bit.ly\/1slO2gQ"
      } ]
    },
    "geo" : { },
    "id_str" : "497419563618033664",
    "text" : "Computational #linguistics of #Twitter shines spotlight on city &amp; rural superdialects: http:\/\/t.co\/QNTxn9K6L4 RT@techreview",
    "id" : 497419563618033664,
    "created_at" : "2014-08-07 16:30:40 +0000",
    "user" : {
      "name" : "Max Planck Society",
      "screen_name" : "maxplanckpress",
      "protected" : false,
      "id_str" : "205195655",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/699231548944576512\/6dZVg3Kt_normal.jpg",
      "id" : 205195655,
      "verified" : false
    }
  },
  "id" : 497425337689866241,
  "created_at" : "2014-08-07 16:53:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 62, 78 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/mXOsbVCRGX",
      "expanded_url" : "http:\/\/wp.me\/p2CPYN-eJ",
      "display_url" : "wp.me\/p2CPYN-eJ"
    } ]
  },
  "geo" : { },
  "id_str" : "497323978566803457",
  "text" : "Tomorrow's fish and chip wrappers. http:\/\/t.co\/mXOsbVCRGX via @wordpressdotcom",
  "id" : 497323978566803457,
  "created_at" : "2014-08-07 10:10:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve King",
      "screen_name" : "steveathon",
      "indices" : [ 0, 11 ],
      "id_str" : "33233425",
      "id" : 33233425
    }, {
      "name" : "Christopher Phipps",
      "screen_name" : "lousylinguist",
      "indices" : [ 12, 26 ],
      "id_str" : "48459936",
      "id" : 48459936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/pbU58SghWW",
      "expanded_url" : "http:\/\/youtu.be\/SKaGMjlzZOg?t=1m54s",
      "display_url" : "youtu.be\/SKaGMjlzZOg?t=\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "497012788644950016",
  "geo" : { },
  "id_str" : "497094417057349632",
  "in_reply_to_user_id" : 33233425,
  "text" : "@steveathon @lousylinguist apparently some of the DrWho newspaper is in Klingon http:\/\/t.co\/pbU58SghWW maybe Beeb reporter is a deep nerd..",
  "id" : 497094417057349632,
  "in_reply_to_status_id" : 497012788644950016,
  "created_at" : "2014-08-06 18:58:39 +0000",
  "in_reply_to_screen_name" : "steveathon",
  "in_reply_to_user_id_str" : "33233425",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "497071247088709632",
  "text" : "@_FTaylor_ or you could add @cazzwebbo  to a penis list :)",
  "id" : 497071247088709632,
  "created_at" : "2014-08-06 17:26:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "indices" : [ 0, 12 ],
      "id_str" : "192437743",
      "id" : 192437743
    }, {
      "name" : "Inside Higher Ed",
      "screen_name" : "insidehighered",
      "indices" : [ 13, 28 ],
      "id_str" : "16045268",
      "id" : 16045268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "497035531688366081",
  "geo" : { },
  "id_str" : "497037863738155008",
  "in_reply_to_user_id" : 192437743,
  "text" : "@nathanghall @insidehighered lol at that last para :)",
  "id" : 497037863738155008,
  "in_reply_to_status_id" : 497035531688366081,
  "created_at" : "2014-08-06 15:13:55 +0000",
  "in_reply_to_screen_name" : "nathanghall",
  "in_reply_to_user_id_str" : "192437743",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 93, 104 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/UD4NT3eWTR",
      "expanded_url" : "http:\/\/www.digitalcounterrevolution.co.uk\/2014\/digital-citizenship-critique\/",
      "display_url" : "digitalcounterrevolution.co.uk\/2014\/digital-c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "497014850141585408",
  "text" : "making comments...the discursive equivalent of a drive-by shooting http:\/\/t.co\/UD4NT3eWTR by @tornhalves",
  "id" : 497014850141585408,
  "created_at" : "2014-08-06 13:42:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 3, 14 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/7SrYmx9qfG",
      "expanded_url" : "http:\/\/bit.ly\/USkVqg",
      "display_url" : "bit.ly\/USkVqg"
    } ]
  },
  "geo" : { },
  "id_str" : "497006619155505152",
  "text" : "RT @tornhalves: After the digital revolution: What holds society together is the way it facilitates escape from it. http:\/\/t.co\/7SrYmx9qfG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/7SrYmx9qfG",
        "expanded_url" : "http:\/\/bit.ly\/USkVqg",
        "display_url" : "bit.ly\/USkVqg"
      } ]
    },
    "geo" : { },
    "id_str" : "496927765124620289",
    "text" : "After the digital revolution: What holds society together is the way it facilitates escape from it. http:\/\/t.co\/7SrYmx9qfG",
    "id" : 496927765124620289,
    "created_at" : "2014-08-06 07:56:26 +0000",
    "user" : {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "protected" : false,
      "id_str" : "87902543",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3059742703\/1d3c7a2052db17d29644fa0a49af6480_normal.jpeg",
      "id" : 87902543,
      "verified" : false
    }
  },
  "id" : 497006619155505152,
  "created_at" : "2014-08-06 13:09:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nikki Fortova",
      "screen_name" : "NikkiFortova",
      "indices" : [ 0, 13 ],
      "id_str" : "35838394",
      "id" : 35838394
    }, {
      "name" : "Hana Tich\u00E1",
      "screen_name" : "HanaTicha",
      "indices" : [ 14, 24 ],
      "id_str" : "512296705",
      "id" : 512296705
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 142 ],
      "url" : "http:\/\/t.co\/lDyZNMFrE3",
      "expanded_url" : "http:\/\/stroppyeditor.wordpress.com\/2014\/02\/18\/modern-standards-of-grammar-do-not-make-you-kill-yourself\/",
      "display_url" : "stroppyeditor.wordpress.com\/2014\/02\/18\/mod\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "496958158024495104",
  "geo" : { },
  "id_str" : "496964415099781120",
  "in_reply_to_user_id" : 35838394,
  "text" : "@NikkiFortova @HanaTicha certain media seem to like his simple message, lot of criticisms on web of him &amp; book e.g. http:\/\/t.co\/lDyZNMFrE3",
  "id" : 496964415099781120,
  "in_reply_to_status_id" : 496958158024495104,
  "created_at" : "2014-08-06 10:22:04 +0000",
  "in_reply_to_screen_name" : "NikkiFortova",
  "in_reply_to_user_id_str" : "35838394",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hack Education",
      "screen_name" : "hackeducation",
      "indices" : [ 86, 100 ],
      "id_str" : "149029700",
      "id" : 149029700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/231JSgEdlp",
      "expanded_url" : "http:\/\/hackeducation.com\/2014\/07\/30\/tressie-mcmillan-cottom-ideology-identity-regimes\/",
      "display_url" : "hackeducation.com\/2014\/07\/30\/tre\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "496868374903681026",
  "text" : "Student Data, Algorithms, Ideology, and Identity-less-ness http:\/\/t.co\/231JSgEdlp via @hackeducation",
  "id" : 496868374903681026,
  "created_at" : "2014-08-06 04:00:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "i_narrator",
      "screen_name" : "i_narrator",
      "indices" : [ 3, 14 ],
      "id_str" : "281361233",
      "id" : 281361233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/zJ43FFFSYP",
      "expanded_url" : "http:\/\/t.usnews.com\/Z2huu4",
      "display_url" : "t.usnews.com\/Z2huu4"
    } ]
  },
  "geo" : { },
  "id_str" : "496496544653139968",
  "text" : "RT @i_narrator: New Tools From Yelp and The New York Times Examine Changes in Language http:\/\/t.co\/zJ43FFFSYP \u901A\u6642\u7684\u306BNew York Times\u3092\u898B\u308B\u3068\u3001\u8A9E\u5F59\u306E\u5909\u5BB9\u304C\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/zJ43FFFSYP",
        "expanded_url" : "http:\/\/t.usnews.com\/Z2huu4",
        "display_url" : "t.usnews.com\/Z2huu4"
      } ]
    },
    "geo" : { },
    "id_str" : "496431663337836544",
    "text" : "New Tools From Yelp and The New York Times Examine Changes in Language http:\/\/t.co\/zJ43FFFSYP \u901A\u6642\u7684\u306BNew York Times\u3092\u898B\u308B\u3068\u3001\u8A9E\u5F59\u306E\u5909\u5BB9\u304C\u308F\u304B\u308B\u3002broccoli\u304C\u826F\u3044\u306D\u3002",
    "id" : 496431663337836544,
    "created_at" : "2014-08-04 23:05:06 +0000",
    "user" : {
      "name" : "i_narrator",
      "screen_name" : "i_narrator",
      "protected" : false,
      "id_str" : "281361233",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000410308329\/8ed838331668e90230fc3a90a453f21b_normal.jpeg",
      "id" : 281361233,
      "verified" : false
    }
  },
  "id" : 496496544653139968,
  "created_at" : "2014-08-05 03:22:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Szab\u00F3",
      "screen_name" : "RobertASzabo",
      "indices" : [ 3, 16 ],
      "id_str" : "145285777",
      "id" : 145285777
    }, {
      "name" : "IATEFL BESIG",
      "screen_name" : "iatefl_besig",
      "indices" : [ 130, 140 ],
      "id_str" : "146913655",
      "id" : 146913655
    }, {
      "name" : "Pete Rutherford",
      "screen_name" : "peteruthe",
      "indices" : [ 139, 140 ],
      "id_str" : "20842594",
      "id" : 20842594
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/OQz7KG5V1r",
      "expanded_url" : "http:\/\/bit.ly\/1AE0hef",
      "display_url" : "bit.ly\/1AE0hef"
    } ]
  },
  "geo" : { },
  "id_str" : "496210073228554241",
  "text" : "RT @RobertASzabo: The more responses, the more useful the data. Please respond to our quick BE survey. http:\/\/t.co\/OQz7KG5V1r     @iatefl_b\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "IATEFL BESIG",
        "screen_name" : "iatefl_besig",
        "indices" : [ 112, 125 ],
        "id_str" : "146913655",
        "id" : 146913655
      }, {
        "name" : "Pete Rutherford",
        "screen_name" : "peteruthe",
        "indices" : [ 126, 136 ],
        "id_str" : "20842594",
        "id" : 20842594
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/OQz7KG5V1r",
        "expanded_url" : "http:\/\/bit.ly\/1AE0hef",
        "display_url" : "bit.ly\/1AE0hef"
      } ]
    },
    "geo" : { },
    "id_str" : "496203980390039552",
    "text" : "The more responses, the more useful the data. Please respond to our quick BE survey. http:\/\/t.co\/OQz7KG5V1r     @iatefl_besig @peteruthe",
    "id" : 496203980390039552,
    "created_at" : "2014-08-04 08:00:22 +0000",
    "user" : {
      "name" : "Rob Szab\u00F3",
      "screen_name" : "RobertASzabo",
      "protected" : false,
      "id_str" : "145285777",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666724461559812096\/XTsQWxw6_normal.jpg",
      "id" : 145285777,
      "verified" : false
    }
  },
  "id" : 496210073228554241,
  "created_at" : "2014-08-04 08:24:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "indices" : [ 3, 19 ],
      "id_str" : "1326508478",
      "id" : 1326508478
    }, {
      "name" : "Cambridge Uni Press",
      "screen_name" : "CambridgeUP",
      "indices" : [ 30, 42 ],
      "id_str" : "319110295",
      "id" : 319110295
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/mW3QiMy2yl",
      "expanded_url" : "http:\/\/cass.lancs.ac.uk\/?p=1335",
      "display_url" : "cass.lancs.ac.uk\/?p=1335"
    } ]
  },
  "geo" : { },
  "id_str" : "496209469391396864",
  "text" : "RT @CorpusSocialSci: CASS and @CambridgeUP are compiling a new, publicly accessible corpus of spoken British English - the Spoken BNC2014 h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Cambridge Uni Press",
        "screen_name" : "CambridgeUP",
        "indices" : [ 9, 21 ],
        "id_str" : "319110295",
        "id" : 319110295
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/mW3QiMy2yl",
        "expanded_url" : "http:\/\/cass.lancs.ac.uk\/?p=1335",
        "display_url" : "cass.lancs.ac.uk\/?p=1335"
      } ]
    },
    "geo" : { },
    "id_str" : "493682778010300416",
    "text" : "CASS and @CambridgeUP are compiling a new, publicly accessible corpus of spoken British English - the Spoken BNC2014 http:\/\/t.co\/mW3QiMy2yl",
    "id" : 493682778010300416,
    "created_at" : "2014-07-28 09:02:01 +0000",
    "user" : {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "protected" : false,
      "id_str" : "1326508478",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3493899777\/ced36fe15c32eb911cbe3d64377524dc_normal.jpeg",
      "id" : 1326508478,
      "verified" : false
    }
  },
  "id" : 496209469391396864,
  "created_at" : "2014-08-04 08:22:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hana Tich\u00E1",
      "screen_name" : "HanaTicha",
      "indices" : [ 3, 13 ],
      "id_str" : "512296705",
      "id" : 512296705
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/82JDJQiPID",
      "expanded_url" : "http:\/\/how-i-see-it-now.blogspot.cz\/2014\/08\/using-corpora-in-class-simple-way.html",
      "display_url" : "how-i-see-it-now.blogspot.cz\/2014\/08\/using-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "496177760931299329",
  "text" : "RT @HanaTicha: New on my blog: Using corpora in class (the simple way) http:\/\/t.co\/82JDJQiPID",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/82JDJQiPID",
        "expanded_url" : "http:\/\/how-i-see-it-now.blogspot.cz\/2014\/08\/using-corpora-in-class-simple-way.html",
        "display_url" : "how-i-see-it-now.blogspot.cz\/2014\/08\/using-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "496015920746479616",
    "text" : "New on my blog: Using corpora in class (the simple way) http:\/\/t.co\/82JDJQiPID",
    "id" : 496015920746479616,
    "created_at" : "2014-08-03 19:33:05 +0000",
    "user" : {
      "name" : "Hana Tich\u00E1",
      "screen_name" : "HanaTicha",
      "protected" : false,
      "id_str" : "512296705",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/699528253598494721\/HL9Np6Gu_normal.jpg",
      "id" : 512296705,
      "verified" : false
    }
  },
  "id" : 496177760931299329,
  "created_at" : "2014-08-04 06:16:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gregory Hickok",
      "screen_name" : "GregoryHickok",
      "indices" : [ 3, 17 ],
      "id_str" : "2579527148",
      "id" : 2579527148
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/exOiZUSkYs",
      "expanded_url" : "http:\/\/www.nytimes.com\/2014\/08\/03\/opinion\/sunday\/three-myths-about-the-brain.html?hp&action=click&pgtype=Homepage&module=c-column-top-span-region&region=c-column-top-span-region&WT.nav=c-column-top-span-region",
      "display_url" : "nytimes.com\/2014\/08\/03\/opi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "495506186439909377",
  "text" : "RT @GregoryHickok: Three brain myths. My just posted NYT OpEd piece.  http:\/\/t.co\/exOiZUSkYs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 73 ],
        "url" : "http:\/\/t.co\/exOiZUSkYs",
        "expanded_url" : "http:\/\/www.nytimes.com\/2014\/08\/03\/opinion\/sunday\/three-myths-about-the-brain.html?hp&action=click&pgtype=Homepage&module=c-column-top-span-region&region=c-column-top-span-region&WT.nav=c-column-top-span-region",
        "display_url" : "nytimes.com\/2014\/08\/03\/opi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "495322073074376707",
    "text" : "Three brain myths. My just posted NYT OpEd piece.  http:\/\/t.co\/exOiZUSkYs",
    "id" : 495322073074376707,
    "created_at" : "2014-08-01 21:35:59 +0000",
    "user" : {
      "name" : "Gregory Hickok",
      "screen_name" : "GregoryHickok",
      "protected" : false,
      "id_str" : "2579527148",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/552243530844762113\/0R1eK-w2_normal.jpeg",
      "id" : 2579527148,
      "verified" : false
    }
  },
  "id" : 495506186439909377,
  "created_at" : "2014-08-02 09:47:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
} ]