Grailbird.data.tweets_2012_11 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "274550664280039424",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson woot! another write up on yr weeks summary, chuffed to bits :)",
  "id" : 274550664280039424,
  "created_at" : "2012-11-30 16:29:13 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 3, 18 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 31, 35 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 64, 72 ]
    }, {
      "text" : "tefl",
      "indices" : [ 73, 78 ]
    }, {
      "text" : "esl",
      "indices" : [ 79, 83 ]
    }, {
      "text" : "esol",
      "indices" : [ 84, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/lSZ7DpKq",
      "expanded_url" : "http:\/\/elt2.co.uk\/SkiF5s",
      "display_url" : "elt2.co.uk\/SkiF5s"
    } ]
  },
  "geo" : { },
  "id_str" : "274550329322897408",
  "text" : "RT @MrChrisJWilson: This weeks #elt summary.I hope you enjoy it #eltchat #tefl #esl #esol http:\/\/t.co\/lSZ7DpKq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "elt",
        "indices" : [ 11, 15 ]
      }, {
        "text" : "eltchat",
        "indices" : [ 44, 52 ]
      }, {
        "text" : "tefl",
        "indices" : [ 53, 58 ]
      }, {
        "text" : "esl",
        "indices" : [ 59, 63 ]
      }, {
        "text" : "esol",
        "indices" : [ 64, 69 ]
      } ],
      "urls" : [ {
        "indices" : [ 70, 90 ],
        "url" : "http:\/\/t.co\/lSZ7DpKq",
        "expanded_url" : "http:\/\/elt2.co.uk\/SkiF5s",
        "display_url" : "elt2.co.uk\/SkiF5s"
      } ]
    },
    "geo" : { },
    "id_str" : "274540684889976832",
    "text" : "This weeks #elt summary.I hope you enjoy it #eltchat #tefl #esl #esol http:\/\/t.co\/lSZ7DpKq",
    "id" : 274540684889976832,
    "created_at" : "2012-11-30 15:49:34 +0000",
    "user" : {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "protected" : false,
      "id_str" : "20760283",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744952885595758592\/H4bmsUn3_normal.jpg",
      "id" : 20760283,
      "verified" : false
    }
  },
  "id" : 274550329322897408,
  "created_at" : "2012-11-30 16:27:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 31, 42 ],
      "id_str" : "144663117",
      "id" : 144663117
    }, {
      "name" : "Alex Grevett",
      "screen_name" : "breathyvowel",
      "indices" : [ 43, 56 ],
      "id_str" : "237547177",
      "id" : 237547177
    }, {
      "name" : "Jim George",
      "screen_name" : "oyajimbo",
      "indices" : [ 57, 66 ],
      "id_str" : "96103979",
      "id" : 96103979
    }, {
      "name" : "JohnPfordresher",
      "screen_name" : "JohnPfordresher",
      "indices" : [ 67, 83 ],
      "id_str" : "168973558",
      "id" : 168973558
    }, {
      "name" : "Josette LeBlanc",
      "screen_name" : "JosetteLB",
      "indices" : [ 84, 94 ],
      "id_str" : "33503694",
      "id" : 33503694
    }, {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 95, 107 ],
      "id_str" : "525013404",
      "id" : 525013404
    }, {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 108, 123 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FF",
      "indices" : [ 0, 3 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "274516997205807104",
  "geo" : { },
  "id_str" : "274550099563139072",
  "in_reply_to_user_id" : 144663117,
  "text" : "#FF these more than fine folks @kevchanwow @breathyvowel @oyajimbo @JohnPfordresher @JosetteLB @AnneHendler @MrChrisJWilson",
  "id" : 274550099563139072,
  "in_reply_to_status_id" : 274516997205807104,
  "created_at" : "2012-11-30 16:26:59 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    }, {
      "name" : "JohnPfordresher",
      "screen_name" : "JohnPfordresher",
      "indices" : [ 17, 33 ],
      "id_str" : "168973558",
      "id" : 168973558
    }, {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 34, 46 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tesolfr",
      "indices" : [ 59, 67 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "274422742735011840",
  "geo" : { },
  "id_str" : "274497902410354688",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin @JohnPfordresher @AnneHendler enjoyed his #tesolfr talk, dusting off my recorder to use in class :\/",
  "id" : 274497902410354688,
  "in_reply_to_status_id" : 274422742735011840,
  "created_at" : "2012-11-30 12:59:34 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sophia Khan",
      "screen_name" : "SophiaKhan4",
      "indices" : [ 0, 12 ],
      "id_str" : "351390617",
      "id" : 351390617
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "274459226464731136",
  "geo" : { },
  "id_str" : "274466024861073408",
  "in_reply_to_user_id" : 351390617,
  "text" : "@SophiaKhan4 new one for me! thx",
  "id" : 274466024861073408,
  "in_reply_to_status_id" : 274459226464731136,
  "created_at" : "2012-11-30 10:52:54 +0000",
  "in_reply_to_screen_name" : "SophiaKhan4",
  "in_reply_to_user_id_str" : "351390617",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 0, 11 ],
      "id_str" : "282659955",
      "id" : 282659955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "274386961970630657",
  "geo" : { },
  "id_str" : "274416558372188164",
  "in_reply_to_user_id" : 282659955,
  "text" : "@teflerinha hi link is broken?",
  "id" : 274416558372188164,
  "in_reply_to_status_id" : 274386961970630657,
  "created_at" : "2012-11-30 07:36:20 +0000",
  "in_reply_to_screen_name" : "teflerinha",
  "in_reply_to_user_id_str" : "282659955",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "274415329688571905",
  "text" : "hmm email tweets...",
  "id" : 274415329688571905,
  "created_at" : "2012-11-30 07:31:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 3, 14 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/jEGXHPGl",
      "expanded_url" : "http:\/\/bit.ly\/Tt50r5",
      "display_url" : "bit.ly\/Tt50r5"
    } ]
  },
  "geo" : { },
  "id_str" : "274265692524666882",
  "text" : "MT @tornhalves Is the internet the edtech really such a boon for learner autonomy?http:\/\/t.co\/jEGXHPGl&lt;--grt dispatch frm edtech frnt line",
  "id" : 274265692524666882,
  "created_at" : "2012-11-29 21:36:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephanie McIntosh",
      "screen_name" : "purple_steph",
      "indices" : [ 0, 13 ],
      "id_str" : "18678010",
      "id" : 18678010
    }, {
      "name" : "Angela Boothroyd",
      "screen_name" : "StudyingOnline",
      "indices" : [ 14, 29 ],
      "id_str" : "16680885",
      "id" : 16680885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/7MAobFyj",
      "expanded_url" : "http:\/\/news.ycombinator.com\/item?id=4844786",
      "display_url" : "news.ycombinator.com\/item?id=4844786"
    } ]
  },
  "in_reply_to_status_id_str" : "274103989551906816",
  "geo" : { },
  "id_str" : "274108605526056962",
  "in_reply_to_user_id" : 18678010,
  "text" : "@purple_steph @StudyingOnline there's a v int discussion of this here http:\/\/t.co\/7MAobFyj",
  "id" : 274108605526056962,
  "in_reply_to_status_id" : 274103989551906816,
  "created_at" : "2012-11-29 11:12:38 +0000",
  "in_reply_to_screen_name" : "purple_steph",
  "in_reply_to_user_id_str" : "18678010",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alannah Fitzgerald",
      "screen_name" : "AlannahFitz",
      "indices" : [ 3, 15 ],
      "id_str" : "223613160",
      "id" : 223613160
    }, {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 101, 117 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/PLxaLL4q",
      "expanded_url" : "http:\/\/wp.me\/pLDYo-GP",
      "display_url" : "wp.me\/pLDYo-GP"
    } ]
  },
  "geo" : { },
  "id_str" : "274103165400522752",
  "text" : "RT @AlannahFitz: An Exploration of Open Licenses and Financial Remuneration http:\/\/t.co\/PLxaLL4q via @wordpressdotcom",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "WordPress.com",
        "screen_name" : "wordpressdotcom",
        "indices" : [ 84, 100 ],
        "id_str" : "823905",
        "id" : 823905
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 79 ],
        "url" : "http:\/\/t.co\/PLxaLL4q",
        "expanded_url" : "http:\/\/wp.me\/pLDYo-GP",
        "display_url" : "wp.me\/pLDYo-GP"
      } ]
    },
    "geo" : { },
    "id_str" : "274096703542542336",
    "text" : "An Exploration of Open Licenses and Financial Remuneration http:\/\/t.co\/PLxaLL4q via @wordpressdotcom",
    "id" : 274096703542542336,
    "created_at" : "2012-11-29 10:25:21 +0000",
    "user" : {
      "name" : "Alannah Fitzgerald",
      "screen_name" : "AlannahFitz",
      "protected" : false,
      "id_str" : "223613160",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2645381550\/e07d3b354efdac11bce2725cbc44e94e_normal.png",
      "id" : 223613160,
      "verified" : false
    }
  },
  "id" : 274103165400522752,
  "created_at" : "2012-11-29 10:51:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Byrne",
      "screen_name" : "rmbyrne",
      "indices" : [ 93, 101 ],
      "id_str" : "11112092",
      "id" : 11112092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/PAOhVdu9",
      "expanded_url" : "http:\/\/www.freetech4teachers.com\/2012\/11\/gmail1-student-email-addresses-to.html#.ULcxd2TboJA.twitter",
      "display_url" : "freetech4teachers.com\/2012\/11\/gmail1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "274090150882062337",
  "text" : "Gmail+1 = Student Email Addresses to Register for Online Services \n http:\/\/t.co\/PAOhVdu9 via @rmbyrne",
  "id" : 274090150882062337,
  "created_at" : "2012-11-29 09:59:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 0, 11 ],
      "id_str" : "282659955",
      "id" : 282659955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "274059843315326976",
  "geo" : { },
  "id_str" : "274077397937160193",
  "in_reply_to_user_id" : 282659955,
  "text" : "@teflerinha happy birthday rachael! have a good 'un :)",
  "id" : 274077397937160193,
  "in_reply_to_status_id" : 274059843315326976,
  "created_at" : "2012-11-29 09:08:38 +0000",
  "in_reply_to_screen_name" : "teflerinha",
  "in_reply_to_user_id_str" : "282659955",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273915520821108736",
  "geo" : { },
  "id_str" : "273919556991459328",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow no i dont be grt Will dm add, are mirrirs inc? ;)",
  "id" : 273919556991459328,
  "in_reply_to_status_id" : 273915520821108736,
  "created_at" : "2012-11-28 22:41:26 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 14, 25 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273910522892664832",
  "geo" : { },
  "id_str" : "273911615043289088",
  "in_reply_to_user_id" : 501629829,
  "text" : "@eltknowledge @leoselivan lk fwd to it! :)",
  "id" : 273911615043289088,
  "in_reply_to_status_id" : 273910522892664832,
  "created_at" : "2012-11-28 22:09:52 +0000",
  "in_reply_to_screen_name" : "ETprofessional",
  "in_reply_to_user_id_str" : "501629829",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 20, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273910381267808256",
  "text" : "thx all for chat :) #eltchat",
  "id" : 273910381267808256,
  "created_at" : "2012-11-28 22:04:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tesolfr",
      "indices" : [ 95, 103 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273905019353448448",
  "geo" : { },
  "id_str" : "273910205392236544",
  "in_reply_to_user_id" : 501629829,
  "text" : "@eltknowledge was honoured to just shake yr hands to be honest chia :) meeting u and others at #tesolfr felt kinda like a elt groupie! :\/",
  "id" : 273910205392236544,
  "in_reply_to_status_id" : 273905019353448448,
  "created_at" : "2012-11-28 22:04:16 +0000",
  "in_reply_to_screen_name" : "ETprofessional",
  "in_reply_to_user_id_str" : "501629829",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 96, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273908229644369920",
  "text" : "very often using 'run of the mill' language data is surprising for sts e.g. freq data for words #eltchat",
  "id" : 273908229644369920,
  "created_at" : "2012-11-28 21:56:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 70, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/eu76cA78",
      "expanded_url" : "http:\/\/bit.ly\/Sbo8eO",
      "display_url" : "bit.ly\/Sbo8eO"
    } ]
  },
  "in_reply_to_status_id_str" : "273903905883160576",
  "geo" : { },
  "id_str" : "273904739597578242",
  "in_reply_to_user_id" : 501629829,
  "text" : "@eltknowledge yr story made me think of this guy http:\/\/t.co\/eu76cA78 #eltchat",
  "id" : 273904739597578242,
  "in_reply_to_status_id" : 273903905883160576,
  "created_at" : "2012-11-28 21:42:33 +0000",
  "in_reply_to_screen_name" : "ETprofessional",
  "in_reply_to_user_id_str" : "501629829",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marjorie Rosenberg",
      "screen_name" : "MarjorieRosenbe",
      "indices" : [ 0, 16 ],
      "id_str" : "328052618",
      "id" : 328052618
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 95, 103 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273901992093552640",
  "geo" : { },
  "id_str" : "273902717934657536",
  "in_reply_to_user_id" : 328052618,
  "text" : "@MarjorieRosenbe yes and that's why need to be careful it is not too far from sts expectations #eltchat",
  "id" : 273902717934657536,
  "in_reply_to_status_id" : 273901992093552640,
  "created_at" : "2012-11-28 21:34:31 +0000",
  "in_reply_to_screen_name" : "MarjorieRosenbe",
  "in_reply_to_user_id_str" : "328052618",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 80, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273900115784265728",
  "text" : "i guess there may be an optimal point when breaking a sts schemata of a lesson? #eltchat",
  "id" : 273900115784265728,
  "created_at" : "2012-11-28 21:24:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 53, 64 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 86, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/nFD1htsE",
      "expanded_url" : "http:\/\/bit.ly\/TtIX7r",
      "display_url" : "bit.ly\/TtIX7r"
    } ]
  },
  "geo" : { },
  "id_str" : "273898308408336384",
  "text" : "there's a grt one on mirrored text amongst others by @kevchanwow http:\/\/t.co\/nFD1htsE #eltchat",
  "id" : 273898308408336384,
  "created_at" : "2012-11-28 21:17:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stan Carey",
      "screen_name" : "StanCarey",
      "indices" : [ 3, 13 ],
      "id_str" : "34347535",
      "id" : 34347535
    }, {
      "name" : "Jesse Sheidlower",
      "screen_name" : "jessesheidlower",
      "indices" : [ 139, 140 ],
      "id_str" : "43074937",
      "id" : 43074937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/pFIIRuWx",
      "expanded_url" : "http:\/\/nyr.kr\/Wvtcdy",
      "display_url" : "nyr.kr\/Wvtcdy"
    } ]
  },
  "geo" : { },
  "id_str" : "273895969278554113",
  "text" : "RT @StanCarey: Here's why I didn't tweet that Guardian story about foreign words being deleted from the OED: http:\/\/t.co\/pFIIRuWx via @j ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jesse Sheidlower",
        "screen_name" : "jessesheidlower",
        "indices" : [ 119, 135 ],
        "id_str" : "43074937",
        "id" : 43074937
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 114 ],
        "url" : "http:\/\/t.co\/pFIIRuWx",
        "expanded_url" : "http:\/\/nyr.kr\/Wvtcdy",
        "display_url" : "nyr.kr\/Wvtcdy"
      } ]
    },
    "geo" : { },
    "id_str" : "273868194270281728",
    "text" : "Here's why I didn't tweet that Guardian story about foreign words being deleted from the OED: http:\/\/t.co\/pFIIRuWx via @jessesheidlower",
    "id" : 273868194270281728,
    "created_at" : "2012-11-28 19:17:20 +0000",
    "user" : {
      "name" : "Stan Carey",
      "screen_name" : "StanCarey",
      "protected" : false,
      "id_str" : "34347535",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/611193710240514048\/w5lUpuqq_normal.jpg",
      "id" : 34347535,
      "verified" : false
    }
  },
  "id" : 273895969278554113,
  "created_at" : "2012-11-28 21:07:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 68, 74 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273845661240279041",
  "geo" : { },
  "id_str" : "273849856152449024",
  "in_reply_to_user_id" : 61521432,
  "text" : "@ICAL_TEFL sniff sniff i NOSE somethings missing in this list :\/ cc @EBEFL",
  "id" : 273849856152449024,
  "in_reply_to_status_id" : 273845661240279041,
  "created_at" : "2012-11-28 18:04:28 +0000",
  "in_reply_to_screen_name" : "ICALTEFL",
  "in_reply_to_user_id_str" : "61521432",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "annoyingnotifications",
      "indices" : [ 66, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273831552272707584",
  "text" : "pls twitter i do not want to make my header bootiful stop asking! #annoyingnotifications",
  "id" : 273831552272707584,
  "created_at" : "2012-11-28 16:51:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273825032281653250",
  "geo" : { },
  "id_str" : "273831245857837056",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson nice one chris, have a couple of recordings of ss acting dialogue i may add to post, alas funniest ones weren't recorded!",
  "id" : 273831245857837056,
  "in_reply_to_status_id" : 273825032281653250,
  "created_at" : "2012-11-28 16:50:31 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    }, {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 16, 27 ],
      "id_str" : "144663117",
      "id" : 144663117
    }, {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 28, 40 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273815917920677888",
  "geo" : { },
  "id_str" : "273819528608235520",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson @kevchanwow @AnneHendler hehe need to add that to yr twitter handle :)",
  "id" : 273819528608235520,
  "in_reply_to_status_id" : 273815917920677888,
  "created_at" : "2012-11-28 16:03:57 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 82, 93 ],
      "id_str" : "282659955",
      "id" : 282659955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/6ovbHF6D",
      "expanded_url" : "http:\/\/wp.me\/p2e2Wf-99",
      "display_url" : "wp.me\/p2e2Wf-99"
    } ]
  },
  "geo" : { },
  "id_str" : "273818471840763904",
  "text" : "Mindfulness for students (with no tibetan bells or yoga) http:\/\/t.co\/6ovbHF6D via @teflerinha&lt;v useful advice and some grt links to follow",
  "id" : 273818471840763904,
  "created_at" : "2012-11-28 15:59:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    }, {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 16, 27 ],
      "id_str" : "144663117",
      "id" : 144663117
    }, {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 28, 40 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273755918481620992",
  "geo" : { },
  "id_str" : "273814356368695296",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson @kevchanwow @AnneHendler sorry could not join you, how did it go?",
  "id" : 273814356368695296,
  "in_reply_to_status_id" : 273755918481620992,
  "created_at" : "2012-11-28 15:43:24 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "c m kerr",
      "screen_name" : "KerrCarolyn",
      "indices" : [ 43, 55 ],
      "id_str" : "468676296",
      "id" : 468676296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 38 ],
      "url" : "http:\/\/t.co\/vyrIWcUR",
      "expanded_url" : "http:\/\/amodisco.wordpress.com\/2012\/11\/25\/cracking-the-code\/",
      "display_url" : "amodisco.wordpress.com\/2012\/11\/25\/cra\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "273814124629213185",
  "text" : "Cracking the code http:\/\/t.co\/vyrIWcUR via @KerrCarolyn &lt;grt post on decoding accents",
  "id" : 273814124629213185,
  "created_at" : "2012-11-28 15:42:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 19, 30 ],
      "id_str" : "282659955",
      "id" : 282659955
    }, {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 35, 51 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273730693773795329",
  "text" : "thanks for sharing @teflerinha and @michaelegriffin looking to do a brand newpost on building a corpus soonish!",
  "id" : 273730693773795329,
  "created_at" : "2012-11-28 10:10:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 79, 90 ],
      "id_str" : "282659955",
      "id" : 282659955
    }, {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 91, 107 ],
      "id_str" : "394053348",
      "id" : 394053348
    }, {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 108, 119 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/w40Vz8Ju",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-1t",
      "display_url" : "wp.me\/pgHyE-1t"
    } ]
  },
  "geo" : { },
  "id_str" : "273721874381418496",
  "text" : "finally remembered to add small update to corpora post http:\/\/t.co\/w40Vz8Ju cc @teflerinha @michaelegriffin @leoselivan",
  "id" : 273721874381418496,
  "created_at" : "2012-11-28 09:35:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Sketchley",
      "screen_name" : "ELTExperiences",
      "indices" : [ 0, 15 ],
      "id_str" : "22779473",
      "id" : 22779473
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273714572198805504",
  "geo" : { },
  "id_str" : "273714902017929216",
  "in_reply_to_user_id" : 22779473,
  "text" : "@ELTExperiences wow some nice stats there, congrats!",
  "id" : 273714902017929216,
  "in_reply_to_status_id" : 273714572198805504,
  "created_at" : "2012-11-28 09:08:12 +0000",
  "in_reply_to_screen_name" : "ELTExperiences",
  "in_reply_to_user_id_str" : "22779473",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    }, {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 12, 27 ],
      "id_str" : "20760283",
      "id" : 20760283
    }, {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 28, 40 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273712381086027776",
  "geo" : { },
  "id_str" : "273714035898327040",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow @MrChrisJWilson @AnneHendler ohh forgot about timediff :) could possibly make it!",
  "id" : 273714035898327040,
  "in_reply_to_status_id" : 273712381086027776,
  "created_at" : "2012-11-28 09:04:46 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    }, {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 12, 24 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273705926328979456",
  "geo" : { },
  "id_str" : "273710812131106816",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow @AnneHendler dang can't tonight! lk fwd to a future onefor sure:)",
  "id" : 273710812131106816,
  "in_reply_to_status_id" : 273705926328979456,
  "created_at" : "2012-11-28 08:51:57 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 50, 66 ],
      "id_str" : "394053348",
      "id" : 394053348
    }, {
      "name" : "Chris O\u017C\u00F3g",
      "screen_name" : "ChrisOzog",
      "indices" : [ 67, 77 ],
      "id_str" : "79192243",
      "id" : 79192243
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IHJournal",
      "indices" : [ 97, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/EzmKJVpu",
      "expanded_url" : "http:\/\/bit.ly\/Tspbt1",
      "display_url" : "bit.ly\/Tspbt1"
    } ]
  },
  "geo" : { },
  "id_str" : "273700720589545472",
  "text" : "RT @Ben_Naismith: Thanks for all the editing help @michaelegriffin @ChrisOzog - made it into the #IHJournal http:\/\/t.co\/EzmKJVpu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Michael Griffin",
        "screen_name" : "michaelegriffin",
        "indices" : [ 32, 48 ],
        "id_str" : "394053348",
        "id" : 394053348
      }, {
        "name" : "Chris O\u017C\u00F3g",
        "screen_name" : "ChrisOzog",
        "indices" : [ 49, 59 ],
        "id_str" : "79192243",
        "id" : 79192243
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IHJournal",
        "indices" : [ 79, 89 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 110 ],
        "url" : "http:\/\/t.co\/EzmKJVpu",
        "expanded_url" : "http:\/\/bit.ly\/Tspbt1",
        "display_url" : "bit.ly\/Tspbt1"
      } ]
    },
    "geo" : { },
    "id_str" : "273678887052001281",
    "text" : "Thanks for all the editing help @michaelegriffin @ChrisOzog - made it into the #IHJournal http:\/\/t.co\/EzmKJVpu",
    "id" : 273678887052001281,
    "created_at" : "2012-11-28 06:45:06 +0000",
    "user" : {
      "name" : "Ben Naismith",
      "screen_name" : "BenNaismithELT",
      "protected" : false,
      "id_str" : "305248493",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1462371557\/dog_normal.jpg",
      "id" : 305248493,
      "verified" : false
    }
  },
  "id" : 273700720589545472,
  "created_at" : "2012-11-28 08:11:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "le_mac",
      "screen_name" : "le_mac",
      "indices" : [ 0, 7 ],
      "id_str" : "17064137",
      "id" : 17064137
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273665878460092417",
  "geo" : { },
  "id_str" : "273690372247519232",
  "in_reply_to_user_id" : 17064137,
  "text" : "@le_mac u should check him out in pusher 2 ;)",
  "id" : 273690372247519232,
  "in_reply_to_status_id" : 273665878460092417,
  "created_at" : "2012-11-28 07:30:44 +0000",
  "in_reply_to_screen_name" : "le_mac",
  "in_reply_to_user_id_str" : "17064137",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 73, 81 ]
    }, {
      "text" : "elt",
      "indices" : [ 82, 86 ]
    }, {
      "text" : "tefl",
      "indices" : [ 87, 92 ]
    }, {
      "text" : "efl",
      "indices" : [ 93, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http:\/\/t.co\/10LUWBgk",
      "expanded_url" : "http:\/\/wp.me\/p2jfML-37",
      "display_url" : "wp.me\/p2jfML-37"
    } ]
  },
  "geo" : { },
  "id_str" : "273562862885158914",
  "text" : "Tell someone what you've learnt http:\/\/t.co\/10LUWBgk  via keepitrealemma #eltchat #elt #tefl #efl",
  "id" : 273562862885158914,
  "created_at" : "2012-11-27 23:04:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George Chilton",
      "screen_name" : "designerlessons",
      "indices" : [ 0, 16 ],
      "id_str" : "432090149",
      "id" : 432090149
    }, {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 17, 33 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/1NvLJElf",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=G0rFe0YHd9A&feature=watch_response",
      "display_url" : "youtube.com\/watch?v=G0rFe0\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "273538849022558208",
  "geo" : { },
  "id_str" : "273551472308916224",
  "in_reply_to_user_id" : 432090149,
  "text" : "@designerlessons @michaelegriffin bbc audio dceptive cut up this part is mch mre intelligble http:\/\/t.co\/1NvLJElf, wndr if he is lrng frnch?",
  "id" : 273551472308916224,
  "in_reply_to_status_id" : 273538849022558208,
  "created_at" : "2012-11-27 22:18:47 +0000",
  "in_reply_to_screen_name" : "designerlessons",
  "in_reply_to_user_id_str" : "432090149",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 0, 11 ],
      "id_str" : "282659955",
      "id" : 282659955
    }, {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 12, 28 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273472210067415040",
  "geo" : { },
  "id_str" : "273549813910491136",
  "in_reply_to_user_id" : 282659955,
  "text" : "@teflerinha @michaelegriffin it did not detract much frm your points though, i recall a blog post with that triangle?",
  "id" : 273549813910491136,
  "in_reply_to_status_id" : 273472210067415040,
  "created_at" : "2012-11-27 22:12:12 +0000",
  "in_reply_to_screen_name" : "teflerinha",
  "in_reply_to_user_id_str" : "282659955",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 64, 72 ]
    }, {
      "text" : "elt",
      "indices" : [ 73, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/f3oNXctJ",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-aT",
      "display_url" : "wp.me\/pgHyE-aT"
    } ]
  },
  "geo" : { },
  "id_str" : "273548844107694081",
  "text" : "New blog post: Dr Strangelove, telephoning http:\/\/t.co\/f3oNXctJ #eltchat #elt",
  "id" : 273548844107694081,
  "created_at" : "2012-11-27 22:08:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 0, 11 ],
      "id_str" : "282659955",
      "id" : 282659955
    }, {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 12, 28 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273469690389618688",
  "geo" : { },
  "id_str" : "273470857886724096",
  "in_reply_to_user_id" : 282659955,
  "text" : "@teflerinha @michaelegriffin sorry could not attend from start had to pick up little un from creche, aprt frm sound v informative! thx",
  "id" : 273470857886724096,
  "in_reply_to_status_id" : 273469690389618688,
  "created_at" : "2012-11-27 16:58:28 +0000",
  "in_reply_to_screen_name" : "teflerinha",
  "in_reply_to_user_id_str" : "282659955",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/1NvLJElf",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=G0rFe0YHd9A&feature=watch_response",
      "display_url" : "youtube.com\/watch?v=G0rFe0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "273439319790862336",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin chk this vid of barton at same press conf http:\/\/t.co\/1NvLJElf, more understandable to a french person? possibly",
  "id" : 273439319790862336,
  "created_at" : "2012-11-27 14:53:08 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273433289212166144",
  "geo" : { },
  "id_str" : "273434203918585857",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin hehe good enough reason to try :)",
  "id" : 273434203918585857,
  "in_reply_to_status_id" : 273433289212166144,
  "created_at" : "2012-11-27 14:32:49 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 10, 26 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273431965296889856",
  "geo" : { },
  "id_str" : "273433066196856832",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava @michaelegriffin i wonder what would happen if asked my french students to speak in french with an english accent? hmm",
  "id" : 273433066196856832,
  "in_reply_to_status_id" : 273431965296889856,
  "created_at" : "2012-11-27 14:28:17 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273430280122011648",
  "geo" : { },
  "id_str" : "273431965296889856",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin yes, also i find the press reaction in some ways  mre int than the footballer's attempt to adapt to his new context :)",
  "id" : 273431965296889856,
  "in_reply_to_status_id" : 273430280122011648,
  "created_at" : "2012-11-27 14:23:55 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273427493195771904",
  "geo" : { },
  "id_str" : "273429779334696961",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin i am no expert either but i found it a fascinating audio, e.g. \"I have good engine to to stop attacks\"",
  "id" : 273429779334696961,
  "in_reply_to_status_id" : 273427493195771904,
  "created_at" : "2012-11-27 14:15:14 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    }, {
      "name" : "George Chilton",
      "screen_name" : "designerlessons",
      "indices" : [ 17, 33 ],
      "id_str" : "432090149",
      "id" : 432090149
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273425128694640641",
  "geo" : { },
  "id_str" : "273427065779400704",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin @designerlessons a little bit near the end maybe? my wife, who is french, said he sounded scottish.",
  "id" : 273427065779400704,
  "in_reply_to_status_id" : 273425128694640641,
  "created_at" : "2012-11-27 14:04:27 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    }, {
      "name" : "George Chilton",
      "screen_name" : "designerlessons",
      "indices" : [ 17, 33 ],
      "id_str" : "432090149",
      "id" : 432090149
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273422740957061120",
  "geo" : { },
  "id_str" : "273424897525559296",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin @designerlessons v v interesting but accent? attempt at simple sentences, pausing, sometimes drops the s on a verb",
  "id" : 273424897525559296,
  "in_reply_to_status_id" : 273422740957061120,
  "created_at" : "2012-11-27 13:55:50 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Levine",
      "screen_name" : "cogdog",
      "indices" : [ 3, 10 ],
      "id_str" : "740343",
      "id" : 740343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/UnyxOMZ6",
      "expanded_url" : "http:\/\/wp.me\/pf0PM-4nR",
      "display_url" : "wp.me\/pf0PM-4nR"
    } ]
  },
  "geo" : { },
  "id_str" : "273353028952805376",
  "text" : "RT @cogdog: CogDogBlogged:  Owning Your Massive Numbers http:\/\/t.co\/UnyxOMZ6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/sopresto.mailchimp.com\" rel=\"nofollow\"\u003ESocial Proxy by Mailchimp\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 64 ],
        "url" : "http:\/\/t.co\/UnyxOMZ6",
        "expanded_url" : "http:\/\/wp.me\/pf0PM-4nR",
        "display_url" : "wp.me\/pf0PM-4nR"
      } ]
    },
    "geo" : { },
    "id_str" : "273324752037347328",
    "text" : "CogDogBlogged:  Owning Your Massive Numbers http:\/\/t.co\/UnyxOMZ6",
    "id" : 273324752037347328,
    "created_at" : "2012-11-27 07:17:53 +0000",
    "user" : {
      "name" : "Alan Levine",
      "screen_name" : "cogdog",
      "protected" : false,
      "id_str" : "740343",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/740063389527859201\/BN9buLB9_normal.jpg",
      "id" : 740343,
      "verified" : false
    }
  },
  "id" : 273353028952805376,
  "created_at" : "2012-11-27 09:10:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Siva Vaidhyanathan",
      "screen_name" : "sivavaid",
      "indices" : [ 3, 12 ],
      "id_str" : "20406724",
      "id" : 20406724
    }, {
      "name" : "Cato Unbound",
      "screen_name" : "CatoUnbound",
      "indices" : [ 139, 140 ],
      "id_str" : "575489049",
      "id" : 575489049
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "highered",
      "indices" : [ 98, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/LG3b8WFw",
      "expanded_url" : "http:\/\/www.cato-unbound.org\/2012\/11\/26\/siva-vaidhyanathan\/the-accent-is-on-the-massive-should-it-be\/",
      "display_url" : "cato-unbound.org\/2012\/11\/26\/siv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "273351446831980544",
  "text" : "RT @sivavaid: How the focus on MOOCs &amp; their perverse incentives prevent clear discussions of #highered http:\/\/t.co\/LG3b8WFw via @Ca ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Cato Unbound",
        "screen_name" : "CatoUnbound",
        "indices" : [ 119, 131 ],
        "id_str" : "575489049",
        "id" : 575489049
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "highered",
        "indices" : [ 84, 93 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 114 ],
        "url" : "http:\/\/t.co\/LG3b8WFw",
        "expanded_url" : "http:\/\/www.cato-unbound.org\/2012\/11\/26\/siva-vaidhyanathan\/the-accent-is-on-the-massive-should-it-be\/",
        "display_url" : "cato-unbound.org\/2012\/11\/26\/siv\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "273233166679015426",
    "text" : "How the focus on MOOCs &amp; their perverse incentives prevent clear discussions of #highered http:\/\/t.co\/LG3b8WFw via @CatoUnbound",
    "id" : 273233166679015426,
    "created_at" : "2012-11-27 01:13:58 +0000",
    "user" : {
      "name" : "Siva Vaidhyanathan",
      "screen_name" : "sivavaid",
      "protected" : false,
      "id_str" : "20406724",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/767792599050649600\/aaiFpS9e_normal.jpg",
      "id" : 20406724,
      "verified" : false
    }
  },
  "id" : 273351446831980544,
  "created_at" : "2012-11-27 09:03:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annie Murphy Paul",
      "screen_name" : "anniemurphypaul",
      "indices" : [ 3, 19 ],
      "id_str" : "105810697",
      "id" : 105810697
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/8qzOfETb",
      "expanded_url" : "http:\/\/bit.ly\/TpPY8n",
      "display_url" : "bit.ly\/TpPY8n"
    } ]
  },
  "geo" : { },
  "id_str" : "273121707454234625",
  "text" : "RT @anniemurphypaul: Cognitive scientist Dan Willingham takes on \"neuro-garbage\"\u2014the unscientific \"brain-based\" junk ascendant in educat ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/8qzOfETb",
        "expanded_url" : "http:\/\/bit.ly\/TpPY8n",
        "display_url" : "bit.ly\/TpPY8n"
      } ]
    },
    "geo" : { },
    "id_str" : "273046946267136000",
    "text" : "Cognitive scientist Dan Willingham takes on \"neuro-garbage\"\u2014the unscientific \"brain-based\" junk ascendant in education: http:\/\/t.co\/8qzOfETb",
    "id" : 273046946267136000,
    "created_at" : "2012-11-26 12:53:59 +0000",
    "user" : {
      "name" : "Annie Murphy Paul",
      "screen_name" : "anniemurphypaul",
      "protected" : false,
      "id_str" : "105810697",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2120251878\/annie_murphy_paul.head_shot_normal.jpg",
      "id" : 105810697,
      "verified" : false
    }
  },
  "id" : 273121707454234625,
  "created_at" : "2012-11-26 17:51:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 3, 14 ],
      "id_str" : "282659955",
      "id" : 282659955
    }, {
      "name" : "PearsonELT",
      "screen_name" : "Pearson_ELT",
      "indices" : [ 19, 31 ],
      "id_str" : "63127949",
      "id" : 63127949
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/qQ0BY6vl",
      "expanded_url" : "http:\/\/mt204.sabameeting.com\/main\/Customers\/pearson\/Registrar\/NewRegistration.jsp?event_id=0000006913e1490139fa041265007cab&source=",
      "display_url" : "mt204.sabameeting.com\/main\/Customers\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "273120278169677824",
  "text" : "RT @teflerinha: RT @Pearson_ELT: Listen up and take notice - join me 2morrow 4pm UK time- using semi authentic listening to notice lang\n ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "PearsonELT",
        "screen_name" : "Pearson_ELT",
        "indices" : [ 3, 15 ],
        "id_str" : "63127949",
        "id" : 63127949
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/qQ0BY6vl",
        "expanded_url" : "http:\/\/mt204.sabameeting.com\/main\/Customers\/pearson\/Registrar\/NewRegistration.jsp?event_id=0000006913e1490139fa041265007cab&source=",
        "display_url" : "mt204.sabameeting.com\/main\/Customers\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "273092915893510144",
    "text" : "RT @Pearson_ELT: Listen up and take notice - join me 2morrow 4pm UK time- using semi authentic listening to notice lang\nhttp:\/\/t.co\/qQ0BY6vl",
    "id" : 273092915893510144,
    "created_at" : "2012-11-26 15:56:39 +0000",
    "user" : {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "protected" : false,
      "id_str" : "282659955",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2149898907\/Rachael_Roberts_headshot_square_normal.jpg",
      "id" : 282659955,
      "verified" : false
    }
  },
  "id" : 273120278169677824,
  "created_at" : "2012-11-26 17:45:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CDE",
      "screen_name" : "cdelondon",
      "indices" : [ 0, 10 ],
      "id_str" : "158683357",
      "id" : 158683357
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273089698451292160",
  "geo" : { },
  "id_str" : "273112447064367105",
  "in_reply_to_user_id" : 158683357,
  "text" : "@cdelondon hi getting a page not redirecting error message for this link?",
  "id" : 273112447064367105,
  "in_reply_to_status_id" : 273089698451292160,
  "created_at" : "2012-11-26 17:14:16 +0000",
  "in_reply_to_screen_name" : "cdelondon",
  "in_reply_to_user_id_str" : "158683357",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 3, 9 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/IDC9bXmB",
      "expanded_url" : "http:\/\/bit.ly\/TlBVyg",
      "display_url" : "bit.ly\/TlBVyg"
    } ]
  },
  "geo" : { },
  "id_str" : "273020293293932544",
  "text" : "RT @EBEFL new post new post! Get it while it's hot! \"Fantastic Dr. Fox\" http:\/\/t.co\/IDC9bXmB&lt;that fox vid is grt for presentation skills :)",
  "id" : 273020293293932544,
  "created_at" : "2012-11-26 11:08:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Grevett",
      "screen_name" : "breathyvowel",
      "indices" : [ 0, 13 ],
      "id_str" : "237547177",
      "id" : 237547177
    }, {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 53, 69 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "keltchat",
      "indices" : [ 109, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/K2x3R2ym",
      "expanded_url" : "http:\/\/www.widgets-inc.com\/teacher\/tblt.php",
      "display_url" : "widgets-inc.com\/teacher\/tblt.p\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "272665278016528384",
  "geo" : { },
  "id_str" : "272666101027074049",
  "in_reply_to_user_id" : 237547177,
  "text" : "@breathyvowel assessment guidelines here from a prev @michaelegriffin linky near bottom http:\/\/t.co\/K2x3R2ym #keltchat",
  "id" : 272666101027074049,
  "in_reply_to_status_id" : 272665278016528384,
  "created_at" : "2012-11-25 11:40:39 +0000",
  "in_reply_to_screen_name" : "breathyvowel",
  "in_reply_to_user_id_str" : "237547177",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Phelps",
      "screen_name" : "pterolaur",
      "indices" : [ 0, 10 ],
      "id_str" : "90093887",
      "id" : 90093887
    }, {
      "name" : "LoyarBurok",
      "screen_name" : "LoyarBurok",
      "indices" : [ 11, 22 ],
      "id_str" : "42426196",
      "id" : 42426196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "272358674289291265",
  "geo" : { },
  "id_str" : "272360203343785984",
  "in_reply_to_user_id" : 90093887,
  "text" : "@pterolaur @LoyarBurok  i too intrigued since my limited perception of Malaysia is that of a country somewhat independent to US hegemony?",
  "id" : 272360203343785984,
  "in_reply_to_status_id" : 272358674289291265,
  "created_at" : "2012-11-24 15:25:07 +0000",
  "in_reply_to_screen_name" : "pterolaur",
  "in_reply_to_user_id_str" : "90093887",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Phelps",
      "screen_name" : "pterolaur",
      "indices" : [ 0, 10 ],
      "id_str" : "90093887",
      "id" : 90093887
    }, {
      "name" : "LoyarBurok",
      "screen_name" : "LoyarBurok",
      "indices" : [ 11, 22 ],
      "id_str" : "42426196",
      "id" : 42426196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "272342659971047425",
  "geo" : { },
  "id_str" : "272347314071425024",
  "in_reply_to_user_id" : 90093887,
  "text" : "@pterolaur @LoyarBurok hmm shurely one can say that about any modern schooling no? ref to \"third world\" unfort considering colonial history",
  "id" : 272347314071425024,
  "in_reply_to_status_id" : 272342659971047425,
  "created_at" : "2012-11-24 14:33:54 +0000",
  "in_reply_to_screen_name" : "pterolaur",
  "in_reply_to_user_id_str" : "90093887",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Seymour",
      "screen_name" : "leninology",
      "indices" : [ 99, 110 ],
      "id_str" : "15557246",
      "id" : 15557246
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/G1WLqugf",
      "expanded_url" : "http:\/\/www.guardian.co.uk\/commentisfree\/2012\/nov\/23\/lord-freud-welfare-poor-risk",
      "display_url" : "guardian.co.uk\/commentisfree\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "272335895519186944",
  "text" : "Lord Freud on welfare: making the poor pay for the risk-taking of the rich http:\/\/t.co\/G1WLqugf by @leninology",
  "id" : 272335895519186944,
  "created_at" : "2012-11-24 13:48:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 77, 87 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/IQuaeQm3",
      "expanded_url" : "http:\/\/rt.com\/usa\/news\/walmart-strike-black-friday-436\/",
      "display_url" : "rt.com\/usa\/news\/walma\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "272327928073826305",
  "text" : "Walmart strike goes nationwide on Black Friday http:\/\/t.co\/IQuaeQm3 HT Sue J @medialens",
  "id" : 272327928073826305,
  "created_at" : "2012-11-24 13:16:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Mearns",
      "screen_name" : "davidmearns",
      "indices" : [ 3, 15 ],
      "id_str" : "30931681",
      "id" : 30931681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/aGMXqUOp",
      "expanded_url" : "http:\/\/davidmearns.blogspot.com\/2012\/11\/google-docs-2-ideas-for-classroom_20.html?spref=tw",
      "display_url" : "davidmearns.blogspot.com\/2012\/11\/google\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "272322432092762112",
  "text" : "RT @davidmearns Google Docs #2: Ideas for the Classroom http:\/\/t.co\/aGMXqUOp \u2026 &lt;--nice lk fwd to presentation post",
  "id" : 272322432092762112,
  "created_at" : "2012-11-24 12:55:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "le_mac",
      "screen_name" : "le_mac",
      "indices" : [ 0, 7 ],
      "id_str" : "17064137",
      "id" : 17064137
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "272317579924762628",
  "geo" : { },
  "id_str" : "272319135650816000",
  "in_reply_to_user_id" : 17064137,
  "text" : "@le_mac hehe modern life - free to choose but can't choose to be free?",
  "id" : 272319135650816000,
  "in_reply_to_status_id" : 272317579924762628,
  "created_at" : "2012-11-24 12:41:56 +0000",
  "in_reply_to_screen_name" : "le_mac",
  "in_reply_to_user_id_str" : "17064137",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    }, {
      "name" : "Nagehan Tunar",
      "screen_name" : "stiiiv",
      "indices" : [ 9, 16 ],
      "id_str" : "799058600",
      "id" : 799058600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "272317116068265985",
  "geo" : { },
  "id_str" : "272318286245556224",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt @stiiiv thx my last post hat tips u by the way :) \/waits for steve to allow comments\/ ;)",
  "id" : 272318286245556224,
  "in_reply_to_status_id" : 272317116068265985,
  "created_at" : "2012-11-24 12:38:33 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 3, 11 ],
      "id_str" : "20650366",
      "id" : 20650366
    }, {
      "name" : "Nagehan Tunar",
      "screen_name" : "stiiiv",
      "indices" : [ 98, 105 ],
      "id_str" : "799058600",
      "id" : 799058600
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EAPchat",
      "indices" : [ 106, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/1rzLjv9U",
      "expanded_url" : "http:\/\/wp.me\/p219lY-v",
      "display_url" : "wp.me\/p219lY-v"
    } ]
  },
  "geo" : { },
  "id_str" : "272315667829633025",
  "text" : "RT @seburnt Writing for Thinking (or why EAP professionals should blog) http:\/\/t.co\/1rzLjv9U  via @stiiiv #EAPchat &lt;thx to know steve blogs",
  "id" : 272315667829633025,
  "created_at" : "2012-11-24 12:28:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "secrettwilightindulgeralso",
      "indices" : [ 89, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "272293430527418369",
  "text" : "despite its US individualism ideology enjoyed teacher based movie Here comes the Boom :) #secrettwilightindulgeralso",
  "id" : 272293430527418369,
  "created_at" : "2012-11-24 10:59:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    }, {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 28, 39 ],
      "id_str" : "282659955",
      "id" : 282659955
    }, {
      "name" : "BELTA Belgium",
      "screen_name" : "BELTABelgium",
      "indices" : [ 59, 72 ],
      "id_str" : "884934438",
      "id" : 884934438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "272033571252871168",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson the link to @teflerinha post is linking to @BELTABelgium post",
  "id" : 272033571252871168,
  "created_at" : "2012-11-23 17:47:12 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    }, {
      "name" : "Heike Philp",
      "screen_name" : "heikephilp",
      "indices" : [ 39, 50 ],
      "id_str" : "14387055",
      "id" : 14387055
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "272028772625166336",
  "geo" : { },
  "id_str" : "272031073985249280",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt is this available offline? cc @heikephilp",
  "id" : 272031073985249280,
  "in_reply_to_status_id" : 272028772625166336,
  "created_at" : "2012-11-23 17:37:16 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CDE",
      "screen_name" : "cdelondon",
      "indices" : [ 0, 10 ],
      "id_str" : "158683357",
      "id" : 158683357
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271976599233130496",
  "geo" : { },
  "id_str" : "272004568022392832",
  "in_reply_to_user_id" : 158683357,
  "text" : "@cdelondon agreed, yes and moocs imo will not radically change HE learning, will be incorporated, provided students get the last word!",
  "id" : 272004568022392832,
  "in_reply_to_status_id" : 271976599233130496,
  "created_at" : "2012-11-23 15:51:57 +0000",
  "in_reply_to_screen_name" : "cdelondon",
  "in_reply_to_user_id_str" : "158683357",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "edulang",
      "screen_name" : "edulang",
      "indices" : [ 0, 8 ],
      "id_str" : "2877002950",
      "id" : 2877002950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/O8aYmlpH",
      "expanded_url" : "http:\/\/www.meetup.com\/English-teachers-in-Paris\/events\/91774702\/?a=me1_grp&rv=me1",
      "display_url" : "meetup.com\/English-teache\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "270213942402510850",
  "geo" : { },
  "id_str" : "272003786787147776",
  "in_reply_to_user_id" : 236921161,
  "text" : "@Edulang if i can going to try to make this http:\/\/t.co\/O8aYmlpH, maybe catch u then?",
  "id" : 272003786787147776,
  "in_reply_to_status_id" : 270213942402510850,
  "created_at" : "2012-11-23 15:48:51 +0000",
  "in_reply_to_screen_name" : "wordtov",
  "in_reply_to_user_id_str" : "236921161",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "edulang",
      "screen_name" : "edulang",
      "indices" : [ 0, 8 ],
      "id_str" : "2877002950",
      "id" : 2877002950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "272002515736862721",
  "in_reply_to_user_id" : 236921161,
  "text" : "@Edulang many thx for props :) and nice to be aware of other classroom rockers in france :0",
  "id" : 272002515736862721,
  "created_at" : "2012-11-23 15:43:47 +0000",
  "in_reply_to_screen_name" : "wordtov",
  "in_reply_to_user_id_str" : "236921161",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "272000822177570816",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson wow! honoured to be listed with great great bloggers in best of week. look fwd to check out some of those posts not yet read",
  "id" : 272000822177570816,
  "created_at" : "2012-11-23 15:37:04 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CDE",
      "screen_name" : "cdelondon",
      "indices" : [ 0, 10 ],
      "id_str" : "158683357",
      "id" : 158683357
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HELivechat",
      "indices" : [ 73, 84 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271974591302361088",
  "geo" : { },
  "id_str" : "271975158007332866",
  "in_reply_to_user_id" : 158683357,
  "text" : "@cdelondon re napster music consumption and education vey diff things no?#HELivechat",
  "id" : 271975158007332866,
  "in_reply_to_status_id" : 271974591302361088,
  "created_at" : "2012-11-23 13:55:05 +0000",
  "in_reply_to_screen_name" : "cdelondon",
  "in_reply_to_user_id_str" : "158683357",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sandy Millin",
      "screen_name" : "sandymillin",
      "indices" : [ 0, 12 ],
      "id_str" : "144236944",
      "id" : 144236944
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/hEAm4GEP",
      "expanded_url" : "http:\/\/office.microsoft.com\/en-us\/word-help\/word-features-for-right-to-left-languages-HP005258567.aspx",
      "display_url" : "office.microsoft.com\/en-us\/word-hel\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "271943455071162368",
  "geo" : { },
  "id_str" : "271946772828528642",
  "in_reply_to_user_id" : 144236944,
  "text" : "@sandymillin this may help? http:\/\/t.co\/hEAm4GEP",
  "id" : 271946772828528642,
  "in_reply_to_status_id" : 271943455071162368,
  "created_at" : "2012-11-23 12:02:17 +0000",
  "in_reply_to_screen_name" : "sandymillin",
  "in_reply_to_user_id_str" : "144236944",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 3, 14 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "BELTA Belgium",
      "screen_name" : "BELTABelgium",
      "indices" : [ 16, 29 ],
      "id_str" : "884934438",
      "id" : 884934438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "271716920984748032",
  "text" : "RT @leoselivan: @BELTABelgium congrats on establishment of BELTA !",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BELTA Belgium",
        "screen_name" : "BELTABelgium",
        "indices" : [ 0, 13 ],
        "id_str" : "884934438",
        "id" : 884934438
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "271715676018847744",
    "in_reply_to_user_id" : 884934438,
    "text" : "@BELTABelgium congrats on establishment of BELTA !",
    "id" : 271715676018847744,
    "created_at" : "2012-11-22 20:44:00 +0000",
    "in_reply_to_screen_name" : "BELTABelgium",
    "in_reply_to_user_id_str" : "884934438",
    "user" : {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "protected" : false,
      "id_str" : "408365496",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/460546508601819136\/12ivDBb__normal.jpeg",
      "id" : 408365496,
      "verified" : false
    }
  },
  "id" : 271716920984748032,
  "created_at" : "2012-11-22 20:48:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 3, 18 ],
      "id_str" : "20760283",
      "id" : 20760283
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 46, 55 ],
      "id_str" : "18602422",
      "id" : 18602422
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 110, 118 ]
    }, {
      "text" : "elt",
      "indices" : [ 119, 123 ]
    }, {
      "text" : "edtech",
      "indices" : [ 124, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/YrjIutYq",
      "expanded_url" : "http:\/\/eflnotes.wordpress.com\/2012\/11\/22\/popcorn-maker-taste-test\/",
      "display_url" : "eflnotes.wordpress.com\/2012\/11\/22\/pop\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "271715374200918020",
  "text" : "RT @MrChrisJWilson\n\nInteresting activity from @muranava for \"remixing\" videos in class http:\/\/t.co\/YrjIutYq \u2026 #eltchat #elt #edtech&lt;ta chris",
  "id" : 271715374200918020,
  "created_at" : "2012-11-22 20:42:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 32, 47 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "271613517038252033",
  "text" : "thx for RT of my last blog post @MrChrisJWilson",
  "id" : 271613517038252033,
  "created_at" : "2012-11-22 13:58:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "indices" : [ 37, 52 ],
      "id_str" : "27716419",
      "id" : 27716419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 30 ],
      "url" : "http:\/\/t.co\/PTecv9X5",
      "expanded_url" : "http:\/\/www.craigmurray.org.uk\/archives\/2012\/11\/bbc-vomit\/",
      "display_url" : "craigmurray.org.uk\/archives\/2012\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "271613299542609920",
  "text" : "BBC Vomit http:\/\/t.co\/PTecv9X5 \u2026  by @CraigMurrayOrg &lt;--nice and blunt post",
  "id" : 271613299542609920,
  "created_at" : "2012-11-22 13:57:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/JA5P6Y1r",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-ar",
      "display_url" : "wp.me\/pgHyE-ar"
    } ]
  },
  "geo" : { },
  "id_str" : "271553317405085696",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson replied to and appreciate v much yr commment on popcorn maker http:\/\/t.co\/JA5P6Y1r post chris",
  "id" : 271553317405085696,
  "created_at" : "2012-11-22 09:58:50 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Guardian Education",
      "screen_name" : "GuardianEdu",
      "indices" : [ 3, 15 ],
      "id_str" : "24907913",
      "id" : 24907913
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/3XE2BBYH",
      "expanded_url" : "http:\/\/gu.com\/p\/3cxg6\/tf",
      "display_url" : "gu.com\/p\/3cxg6\/tf"
    } ]
  },
  "geo" : { },
  "id_str" : "271407836741918720",
  "text" : "RT @GuardianEdu: Students stage mass protest in London http:\/\/t.co\/3XE2BBYH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 58 ],
        "url" : "http:\/\/t.co\/3XE2BBYH",
        "expanded_url" : "http:\/\/gu.com\/p\/3cxg6\/tf",
        "display_url" : "gu.com\/p\/3cxg6\/tf"
      } ]
    },
    "geo" : { },
    "id_str" : "271212334645665792",
    "text" : "Students stage mass protest in London http:\/\/t.co\/3XE2BBYH",
    "id" : 271212334645665792,
    "created_at" : "2012-11-21 11:23:54 +0000",
    "user" : {
      "name" : "Guardian Education",
      "screen_name" : "GuardianEdu",
      "protected" : false,
      "id_str" : "24907913",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/564806209258008576\/_vb2d4yR_normal.png",
      "id" : 24907913,
      "verified" : false
    }
  },
  "id" : 271407836741918720,
  "created_at" : "2012-11-22 00:20:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JohnPfordresher",
      "screen_name" : "JohnPfordresher",
      "indices" : [ 0, 16 ],
      "id_str" : "168973558",
      "id" : 168973558
    }, {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 17, 28 ],
      "id_str" : "144663117",
      "id" : 144663117
    }, {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 29, 45 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gettingthingswrongagain",
      "indices" : [ 98, 122 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271404436881035264",
  "geo" : { },
  "id_str" : "271404837390929920",
  "in_reply_to_user_id" : 168973558,
  "text" : "@JohnPfordresher @kevchanwow @michaelegriffin someone told me it was neuro linguistic tweeting :0 #gettingthingswrongagain",
  "id" : 271404837390929920,
  "in_reply_to_status_id" : 271404436881035264,
  "created_at" : "2012-11-22 00:08:50 +0000",
  "in_reply_to_screen_name" : "JohnPfordresher",
  "in_reply_to_user_id_str" : "168973558",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271401486376894465",
  "geo" : { },
  "id_str" : "271402645351178240",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow wow thx kevin, pssibly my fastest RT cheers! literally and metaphorically floored by your last post, funny and enlightening!",
  "id" : 271402645351178240,
  "in_reply_to_status_id" : 271401486376894465,
  "created_at" : "2012-11-22 00:00:07 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "englishformultimedia",
      "indices" : [ 63, 84 ]
    }, {
      "text" : "englishfortheweb",
      "indices" : [ 85, 102 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 103, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/JA5P6Y1r",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-ar",
      "display_url" : "wp.me\/pgHyE-ar"
    } ]
  },
  "geo" : { },
  "id_str" : "271400534697721856",
  "text" : "new blog post - Popcorn Maker, taste test http:\/\/t.co\/JA5P6Y1r #englishformultimedia #englishfortheweb #eltchat",
  "id" : 271400534697721856,
  "created_at" : "2012-11-21 23:51:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    }, {
      "name" : "Jeremy Harmer",
      "screen_name" : "Harmerj",
      "indices" : [ 7, 15 ],
      "id_str" : "21094022",
      "id" : 21094022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/mnW0QdDe",
      "expanded_url" : "http:\/\/elt.oup.com\/catalogue\/items\/global\/business_esp\/oxford_eap\/?cc=global&selLanguage=en",
      "display_url" : "elt.oup.com\/catalogue\/item\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "271398815251181568",
  "text" : "@EBEFL @Harmerj its this one http:\/\/t.co\/mnW0QdDe",
  "id" : 271398815251181568,
  "created_at" : "2012-11-21 23:44:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JohnPfordresher",
      "screen_name" : "JohnPfordresher",
      "indices" : [ 3, 19 ],
      "id_str" : "168973558",
      "id" : 168973558
    }, {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 122, 133 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/HtX4oVw2",
      "expanded_url" : "http:\/\/theotherthingsmatter.blogspot.jp\/2012\/11\/i-dont-like-bananas-but-i-like-banana.html",
      "display_url" : "theotherthingsmatter.blogspot.jp\/2012\/11\/i-dont\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "271398381048459265",
  "text" : "RT @JohnPfordresher: pineapple candy, banana chips &amp; the little things that make all the difference in the classroom. @kevchanwow's  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kevin Stein",
        "screen_name" : "kevchanwow",
        "indices" : [ 101, 112 ],
        "id_str" : "144663117",
        "id" : 144663117
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 124, 144 ],
        "url" : "http:\/\/t.co\/HtX4oVw2",
        "expanded_url" : "http:\/\/theotherthingsmatter.blogspot.jp\/2012\/11\/i-dont-like-bananas-but-i-like-banana.html",
        "display_url" : "theotherthingsmatter.blogspot.jp\/2012\/11\/i-dont\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "271393623868850177",
    "text" : "pineapple candy, banana chips &amp; the little things that make all the difference in the classroom. @kevchanwow's new post http:\/\/t.co\/HtX4oVw2",
    "id" : 271393623868850177,
    "created_at" : "2012-11-21 23:24:16 +0000",
    "user" : {
      "name" : "JohnPfordresher",
      "screen_name" : "JohnPfordresher",
      "protected" : false,
      "id_str" : "168973558",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2721387966\/29d6336d02c0b84b3982c1186425b00a_normal.jpeg",
      "id" : 168973558,
      "verified" : false
    }
  },
  "id" : 271398381048459265,
  "created_at" : "2012-11-21 23:43:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/sMP81Ucs",
      "expanded_url" : "http:\/\/plover.net\/~bonds\/smugskimreader.html",
      "display_url" : "plover.net\/~bonds\/smugski\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "271357288428761088",
  "text" : "INTERNET ICONS: THE SMUG SKIM-READER http:\/\/t.co\/sMP81Ucs",
  "id" : 271357288428761088,
  "created_at" : "2012-11-21 20:59:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 87, 93 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "271291504901894144",
  "text" : "surprising - unit in OXFORD EAP book encouriging sts to think in leanring styles :\/ cc @EBEFL u need to get on the case :)",
  "id" : 271291504901894144,
  "created_at" : "2012-11-21 16:38:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Taylor",
      "screen_name" : "theteacherjames",
      "indices" : [ 0, 16 ],
      "id_str" : "71746265",
      "id" : 71746265
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270999113246580736",
  "geo" : { },
  "id_str" : "271194703880404992",
  "in_reply_to_user_id" : 71746265,
  "text" : "@theteacherjames nice :) guess climate much better there in jan than in europe :\/",
  "id" : 271194703880404992,
  "in_reply_to_status_id" : 270999113246580736,
  "created_at" : "2012-11-21 10:13:50 +0000",
  "in_reply_to_screen_name" : "theteacherjames",
  "in_reply_to_user_id_str" : "71746265",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/r7v3sO3l",
      "expanded_url" : "http:\/\/boingboing.net\/2012\/11\/20\/apples-siri-vs-japanese-acc.html",
      "display_url" : "boingboing.net\/2012\/11\/20\/app\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "271166896722817024",
  "text" : "Apple's Siri vs. Japanese-accented English: http:\/\/t.co\/r7v3sO3l",
  "id" : 271166896722817024,
  "created_at" : "2012-11-21 08:23:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/7dtt6Lgb",
      "expanded_url" : "http:\/\/boingboing.net\/2012\/11\/20\/africa-for-norway-raising-mon.html",
      "display_url" : "boingboing.net\/2012\/11\/20\/afr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "271166533781295104",
  "text" : "Africa for Norway: raising money in Africa to help poor Norwegians struggle through the frozen winter: http:\/\/t.co\/7dtt6Lgb :)",
  "id" : 271166533781295104,
  "created_at" : "2012-11-21 08:21:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth Anne",
      "screen_name" : "eannegrenoble",
      "indices" : [ 0, 14 ],
      "id_str" : "19869781",
      "id" : 19869781
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tesolfr",
      "indices" : [ 28, 36 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270846895017058304",
  "geo" : { },
  "id_str" : "270899763296219137",
  "in_reply_to_user_id" : 19869781,
  "text" : "@eannegrenoble thks puts yr #tesolfr slides into some context for me",
  "id" : 270899763296219137,
  "in_reply_to_status_id" : 270846895017058304,
  "created_at" : "2012-11-20 14:41:51 +0000",
  "in_reply_to_screen_name" : "eannegrenoble",
  "in_reply_to_user_id_str" : "19869781",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/qMbTDWKt",
      "expanded_url" : "http:\/\/Wired.com",
      "display_url" : "Wired.com"
    }, {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/Bqh5itnb",
      "expanded_url" : "http:\/\/www.webmonkey.com\/2012\/11\/hugepic\/",
      "display_url" : "webmonkey.com\/2012\/11\/hugepi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "270896289036779521",
  "text" : "HUGEpic Embeds Massive Images Without the Huge Downloads | Webmonkey | http:\/\/t.co\/qMbTDWKt http:\/\/t.co\/Bqh5itnb",
  "id" : 270896289036779521,
  "created_at" : "2012-11-20 14:28:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/8JKxlCud",
      "expanded_url" : "http:\/\/www.counterpunch.org\/2012\/11\/19\/why-gaza-must-suffer-again\/",
      "display_url" : "counterpunch.org\/2012\/11\/19\/why\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "270657469888466946",
  "text" : "Why Gaza Must Suffer Again\nby JONATHAN COOK http:\/\/t.co\/8JKxlCud",
  "id" : 270657469888466946,
  "created_at" : "2012-11-19 22:39:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270627603780628480",
  "geo" : { },
  "id_str" : "270635893109424128",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt ah right so u are on a proper holiday in europe? enjoy!",
  "id" : 270635893109424128,
  "in_reply_to_status_id" : 270627603780628480,
  "created_at" : "2012-11-19 21:13:19 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EAPchat",
      "indices" : [ 19, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270635401222443008",
  "text" : "gtta go thanks all #EAPchat",
  "id" : 270635401222443008,
  "created_at" : "2012-11-19 21:11:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EAPchat",
      "indices" : [ 63, 71 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270626902983708673",
  "geo" : { },
  "id_str" : "270627297160220672",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt hey tyson u still in france! how long us staying for? #EAPchat",
  "id" : 270627297160220672,
  "in_reply_to_status_id" : 270626902983708673,
  "created_at" : "2012-11-19 20:39:10 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharon Turner",
      "screen_name" : "Sharonzspace",
      "indices" : [ 0, 13 ],
      "id_str" : "235194378",
      "id" : 235194378
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EAPchat",
      "indices" : [ 93, 101 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270626395632324609",
  "geo" : { },
  "id_str" : "270626809517862912",
  "in_reply_to_user_id" : 235194378,
  "text" : "@Sharonzspace will do, is this an ongoing project? and have u used tpack with anything else? #EAPchat",
  "id" : 270626809517862912,
  "in_reply_to_status_id" : 270626395632324609,
  "created_at" : "2012-11-19 20:37:14 +0000",
  "in_reply_to_screen_name" : "Sharonzspace",
  "in_reply_to_user_id_str" : "235194378",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharon Turner",
      "screen_name" : "Sharonzspace",
      "indices" : [ 0, 13 ],
      "id_str" : "235194378",
      "id" : 235194378
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EAPchat",
      "indices" : [ 109, 117 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270616676221984769",
  "geo" : { },
  "id_str" : "270625515629596672",
  "in_reply_to_user_id" : 235194378,
  "text" : "@Sharonzspace thks a lot to think about from this post and gives me a clearer idea of how tpack can be used. #EAPchat",
  "id" : 270625515629596672,
  "in_reply_to_status_id" : 270616676221984769,
  "created_at" : "2012-11-19 20:32:05 +0000",
  "in_reply_to_screen_name" : "Sharonzspace",
  "in_reply_to_user_id_str" : "235194378",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nagehan Tunar",
      "screen_name" : "stiiiv",
      "indices" : [ 0, 7 ],
      "id_str" : "799058600",
      "id" : 799058600
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EAPchat",
      "indices" : [ 67, 75 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270622539875749888",
  "geo" : { },
  "id_str" : "270624228896829440",
  "in_reply_to_user_id" : 69068757,
  "text" : "@stiiiv cya and thx, a new area for me and a lot for me to ponder! #EAPchat",
  "id" : 270624228896829440,
  "in_reply_to_status_id" : 270622539875749888,
  "created_at" : "2012-11-19 20:26:58 +0000",
  "in_reply_to_screen_name" : "stiivkirk",
  "in_reply_to_user_id_str" : "69068757",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nagehan Tunar",
      "screen_name" : "stiiiv",
      "indices" : [ 0, 7 ],
      "id_str" : "799058600",
      "id" : 799058600
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EAPchat",
      "indices" : [ 58, 66 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270618415956377600",
  "geo" : { },
  "id_str" : "270619735119523840",
  "in_reply_to_user_id" : 69068757,
  "text" : "@stiiiv sounds intriguing any write up somewhere of that? #EAPchat",
  "id" : 270619735119523840,
  "in_reply_to_status_id" : 270618415956377600,
  "created_at" : "2012-11-19 20:09:07 +0000",
  "in_reply_to_screen_name" : "stiivkirk",
  "in_reply_to_user_id_str" : "69068757",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EAPchat",
      "indices" : [ 65, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270615524415787008",
  "text" : "does anyone have any refs to follow up looking at TPACK and ELT? #EAPchat",
  "id" : 270615524415787008,
  "created_at" : "2012-11-19 19:52:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nagehan Tunar",
      "screen_name" : "stiiiv",
      "indices" : [ 0, 7 ],
      "id_str" : "799058600",
      "id" : 799058600
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EAPchat",
      "indices" : [ 64, 72 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270614672640724992",
  "geo" : { },
  "id_str" : "270614995514040320",
  "in_reply_to_user_id" : 69068757,
  "text" : "@stiiiv i was also putting my son to sleep, thinking, typing :) #EAPchat",
  "id" : 270614995514040320,
  "in_reply_to_status_id" : 270614672640724992,
  "created_at" : "2012-11-19 19:50:17 +0000",
  "in_reply_to_screen_name" : "stiivkirk",
  "in_reply_to_user_id_str" : "69068757",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Simpson",
      "screen_name" : "yearinthelifeof",
      "indices" : [ 0, 16 ],
      "id_str" : "78543378",
      "id" : 78543378
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EAPchat",
      "indices" : [ 111, 119 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270614175573745668",
  "geo" : { },
  "id_str" : "270614447196889088",
  "in_reply_to_user_id" : 78543378,
  "text" : "@yearinthelifeof thanks for drawing attention to this area and framework in particular will read up more on it #EAPchat",
  "id" : 270614447196889088,
  "in_reply_to_status_id" : 270614175573745668,
  "created_at" : "2012-11-19 19:48:06 +0000",
  "in_reply_to_screen_name" : "yearinthelifeof",
  "in_reply_to_user_id_str" : "78543378",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nagehan Tunar",
      "screen_name" : "stiiiv",
      "indices" : [ 0, 7 ],
      "id_str" : "799058600",
      "id" : 799058600
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EAPchat",
      "indices" : [ 39, 47 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270613447136399360",
  "geo" : { },
  "id_str" : "270613965044842496",
  "in_reply_to_user_id" : 69068757,
  "text" : "@stiiiv yes tech used as tools, agreed #EAPchat",
  "id" : 270613965044842496,
  "in_reply_to_status_id" : 270613447136399360,
  "created_at" : "2012-11-19 19:46:11 +0000",
  "in_reply_to_screen_name" : "stiivkirk",
  "in_reply_to_user_id_str" : "69068757",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Simpson",
      "screen_name" : "yearinthelifeof",
      "indices" : [ 0, 16 ],
      "id_str" : "78543378",
      "id" : 78543378
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EAPchat",
      "indices" : [ 22, 30 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270613662107070464",
  "geo" : { },
  "id_str" : "270613841145118720",
  "in_reply_to_user_id" : 78543378,
  "text" : "@yearinthelifeof hehe #EAPchat",
  "id" : 270613841145118720,
  "in_reply_to_status_id" : 270613662107070464,
  "created_at" : "2012-11-19 19:45:42 +0000",
  "in_reply_to_screen_name" : "yearinthelifeof",
  "in_reply_to_user_id_str" : "78543378",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nagehan Tunar",
      "screen_name" : "stiiiv",
      "indices" : [ 0, 7 ],
      "id_str" : "799058600",
      "id" : 799058600
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 54, 62 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270612025468657664",
  "geo" : { },
  "id_str" : "270612377953783808",
  "in_reply_to_user_id" : 69068757,
  "text" : "@stiiiv and what about 'analog' tech e.g. whiteboard? #eapchat",
  "id" : 270612377953783808,
  "in_reply_to_status_id" : 270612025468657664,
  "created_at" : "2012-11-19 19:39:53 +0000",
  "in_reply_to_screen_name" : "stiivkirk",
  "in_reply_to_user_id_str" : "69068757",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 103, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270611807771693056",
  "text" : "i can see tech as a 'genuine space' in certain fields e.g. say programming what about general english? #eapchat",
  "id" : 270611807771693056,
  "created_at" : "2012-11-19 19:37:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nagehan Tunar",
      "screen_name" : "stiiiv",
      "indices" : [ 0, 7 ],
      "id_str" : "799058600",
      "id" : 799058600
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 74, 82 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270610351475789824",
  "geo" : { },
  "id_str" : "270610782100787200",
  "in_reply_to_user_id" : 69068757,
  "text" : "@stiiiv yes, where the tech is a tool rather than 'ed tech' can work well #eapchat",
  "id" : 270610782100787200,
  "in_reply_to_status_id" : 270610351475789824,
  "created_at" : "2012-11-19 19:33:32 +0000",
  "in_reply_to_screen_name" : "stiivkirk",
  "in_reply_to_user_id_str" : "69068757",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Simpson",
      "screen_name" : "yearinthelifeof",
      "indices" : [ 0, 16 ],
      "id_str" : "78543378",
      "id" : 78543378
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 130, 138 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270608918064033792",
  "geo" : { },
  "id_str" : "270609403110121475",
  "in_reply_to_user_id" : 78543378,
  "text" : "@yearinthelifeof it does, a comment on yr post suggested that language was the 'context' so it permeated the three knowledge base #eapchat",
  "id" : 270609403110121475,
  "in_reply_to_status_id" : 270608918064033792,
  "created_at" : "2012-11-19 19:28:04 +0000",
  "in_reply_to_screen_name" : "yearinthelifeof",
  "in_reply_to_user_id_str" : "78543378",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 65, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270608814313713664",
  "text" : "so the ideal is integrating all three knowledge at any one time? #eapchat",
  "id" : 270608814313713664,
  "created_at" : "2012-11-19 19:25:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nagehan Tunar",
      "screen_name" : "stiiiv",
      "indices" : [ 0, 7 ],
      "id_str" : "799058600",
      "id" : 799058600
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 31, 39 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270607089938862080",
  "geo" : { },
  "id_str" : "270607594110980096",
  "in_reply_to_user_id" : 69068757,
  "text" : "@stiiiv start now, why not? ;) #eapchat",
  "id" : 270607594110980096,
  "in_reply_to_status_id" : 270607089938862080,
  "created_at" : "2012-11-19 19:20:52 +0000",
  "in_reply_to_screen_name" : "stiivkirk",
  "in_reply_to_user_id_str" : "69068757",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 46, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270607311414898690",
  "text" : "so how does the TPACK framework apply to ELT? #eapchat",
  "id" : 270607311414898690,
  "created_at" : "2012-11-19 19:19:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 68, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270606556981252096",
  "text" : "yes read up v quickly! not really digested though! what time start? #eapchat",
  "id" : 270606556981252096,
  "created_at" : "2012-11-19 19:16:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 23, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270606136632287232",
  "text" : "i'm here, is it time?\n #eapchat",
  "id" : 270606136632287232,
  "created_at" : "2012-11-19 19:15:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/divrqeCP",
      "expanded_url" : "http:\/\/www.guardian.co.uk\/society\/2012\/nov\/18\/families-rising-food-prices-budgets?intcmp=122",
      "display_url" : "guardian.co.uk\/society\/2012\/n\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "270463710550716418",
  "text" : "Families struggle to eat healthily amid rising food bills and shrinking budgets http:\/\/t.co\/divrqeCP",
  "id" : 270463710550716418,
  "created_at" : "2012-11-19 09:49:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth Anne",
      "screen_name" : "eannegrenoble",
      "indices" : [ 0, 14 ],
      "id_str" : "19869781",
      "id" : 19869781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270289567330996224",
  "geo" : { },
  "id_str" : "270450804786331648",
  "in_reply_to_user_id" : 19869781,
  "text" : "@eannegrenoble yeah was gutted not to be able to make it on sunday! thks for sharing yr slides, have u written about that somewhere?",
  "id" : 270450804786331648,
  "in_reply_to_status_id" : 270289567330996224,
  "created_at" : "2012-11-19 08:57:51 +0000",
  "in_reply_to_screen_name" : "eannegrenoble",
  "in_reply_to_user_id_str" : "19869781",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/ontB8MDT",
      "expanded_url" : "http:\/\/ceasefiremagazine.co.uk\/it-misquoting-noam-chomsky-gaza\/",
      "display_url" : "ceasefiremagazine.co.uk\/it-misquoting-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "270256391070040065",
  "text" : "Did he say it? Misquoting Noam Chomsky on Gaza http:\/\/t.co\/ontB8MDT HT@medialens",
  "id" : 270256391070040065,
  "created_at" : "2012-11-18 20:05:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah",
      "screen_name" : "SK00070",
      "indices" : [ 0, 8 ],
      "id_str" : "19370307",
      "id" : 19370307
    }, {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 9, 20 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "Chia Suan Chong",
      "screen_name" : "chiasuan",
      "indices" : [ 21, 30 ],
      "id_str" : "71588589",
      "id" : 71588589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270180267703013378",
  "geo" : { },
  "id_str" : "270182300392775682",
  "in_reply_to_user_id" : 19370307,
  "text" : "@SK00070 @leoselivan @chiasuan yeah be interested in that too :)",
  "id" : 270182300392775682,
  "in_reply_to_status_id" : 270180267703013378,
  "created_at" : "2012-11-18 15:10:54 +0000",
  "in_reply_to_screen_name" : "SK00070",
  "in_reply_to_user_id_str" : "19370307",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    }, {
      "name" : "Sue Annan",
      "screen_name" : "SueAnnan",
      "indices" : [ 9, 18 ],
      "id_str" : "136001411",
      "id" : 136001411
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "269957724505251841",
  "geo" : { },
  "id_str" : "270181951124668416",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt @SueAnnan doubt it'll happen :), safe trip back.",
  "id" : 270181951124668416,
  "in_reply_to_status_id" : 269957724505251841,
  "created_at" : "2012-11-18 15:09:31 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chia Suan Chong",
      "screen_name" : "chiasuan",
      "indices" : [ 0, 9 ],
      "id_str" : "71588589",
      "id" : 71588589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270069605882548224",
  "geo" : { },
  "id_str" : "270181702071107587",
  "in_reply_to_user_id" : 71588589,
  "text" : "@chiasuan unfortunately had to miss today,have a safe trip back to blighty :)",
  "id" : 270181702071107587,
  "in_reply_to_status_id" : 270069605882548224,
  "created_at" : "2012-11-18 15:08:32 +0000",
  "in_reply_to_screen_name" : "chiasuan",
  "in_reply_to_user_id_str" : "71588589",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "edulang",
      "screen_name" : "edulang",
      "indices" : [ 0, 8 ],
      "id_str" : "2877002950",
      "id" : 2877002950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270122983941607425",
  "geo" : { },
  "id_str" : "270181264718446593",
  "in_reply_to_user_id" : 236921161,
  "text" : "@Edulang couldn't make it today, seems like some excellent talks went dozn,  catch u round paris sometime :)",
  "id" : 270181264718446593,
  "in_reply_to_status_id" : 270122983941607425,
  "created_at" : "2012-11-18 15:06:47 +0000",
  "in_reply_to_screen_name" : "wordtov",
  "in_reply_to_user_id_str" : "236921161",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270130459952959488",
  "geo" : { },
  "id_str" : "270131035612786688",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt good luck! damn sorry not to be able to make it. :(",
  "id" : 270131035612786688,
  "in_reply_to_status_id" : 270130459952959488,
  "created_at" : "2012-11-18 11:47:12 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 97, 107 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/UAvxZQ0H",
      "expanded_url" : "http:\/\/www.salem-news.com\/articles\/november172012\/chomsky-gaza.php",
      "display_url" : "salem-news.com\/articles\/novem\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "270127285452038144",
  "text" : "Chomsky Statement on Israel's War on Gaza - It is not war it is a murder http:\/\/t.co\/UAvxZQ0H HT @medialens",
  "id" : 270127285452038144,
  "created_at" : "2012-11-18 11:32:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willy C. Cardoso",
      "screen_name" : "willycard",
      "indices" : [ 19, 29 ],
      "id_str" : "102353142",
      "id" : 102353142
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tesolfr",
      "indices" : [ 53, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269954730334244864",
  "text" : "and not forgetting @willycard :) hope all r enjoying #tesolfr",
  "id" : 269954730334244864,
  "created_at" : "2012-11-18 00:06:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "edulang",
      "screen_name" : "edulang",
      "indices" : [ 13, 21 ],
      "id_str" : "2877002950",
      "id" : 2877002950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269954174324731904",
  "text" : "and ofc brad @Edulang tweeting and feeding a baby does not mix!",
  "id" : 269954174324731904,
  "created_at" : "2012-11-18 00:04:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heike Philp",
      "screen_name" : "heikephilp",
      "indices" : [ 7, 18 ],
      "id_str" : "14387055",
      "id" : 14387055
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269953140076453888",
  "text" : "oh and @heikephilp :) (u have a strong handshake!)",
  "id" : 269953140076453888,
  "created_at" : "2012-11-18 00:00:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 17, 28 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "stevemuir",
      "screen_name" : "steve_muir",
      "indices" : [ 29, 40 ],
      "id_str" : "18537988",
      "id" : 18537988
    }, {
      "name" : "James Taylor",
      "screen_name" : "theteacherjames",
      "indices" : [ 41, 57 ],
      "id_str" : "71746265",
      "id" : 71746265
    }, {
      "name" : "Vicky Loras",
      "screen_name" : "vickyloras",
      "indices" : [ 58, 69 ],
      "id_str" : "95957241",
      "id" : 95957241
    }, {
      "name" : "Mieke Kenis",
      "screen_name" : "mkofab",
      "indices" : [ 70, 77 ],
      "id_str" : "96527212",
      "id" : 96527212
    }, {
      "name" : "Chia Suan Chong",
      "screen_name" : "chiasuan",
      "indices" : [ 78, 87 ],
      "id_str" : "71588589",
      "id" : 71588589
    }, {
      "name" : "C Rebuffet-Broadus",
      "screen_name" : "RebuffetBroadus",
      "indices" : [ 88, 104 ],
      "id_str" : "22635290",
      "id" : 22635290
    }, {
      "name" : "Elizabeth Anne",
      "screen_name" : "eannegrenoble",
      "indices" : [ 105, 119 ],
      "id_str" : "19869781",
      "id" : 19869781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269952710789459968",
  "text" : "grt also to meet @leoselivan @steve_muir @theteacherjames @vickyloras @mkofab @chiasuan @RebuffetBroadus @eannegrenoble  even briefly!",
  "id" : 269952710789459968,
  "created_at" : "2012-11-17 23:58:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    }, {
      "name" : "Sue Annan",
      "screen_name" : "SueAnnan",
      "indices" : [ 9, 18 ],
      "id_str" : "136001411",
      "id" : 136001411
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "269906775120171008",
  "geo" : { },
  "id_str" : "269952006830039040",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt @SueAnnan hehe nice meet u as well, up feeding my son, am hoping convince my wife to let me out to attend tyson's session sunday!",
  "id" : 269952006830039040,
  "in_reply_to_status_id" : 269906775120171008,
  "created_at" : "2012-11-17 23:55:48 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 73, 83 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/wRzosdFz",
      "expanded_url" : "http:\/\/ow.ly\/flNdu",
      "display_url" : "ow.ly\/flNdu"
    } ]
  },
  "geo" : { },
  "id_str" : "269545560678211584",
  "text" : "Gaza Blitz - Turmoil And Tragicomedy At The BBC http:\/\/t.co\/wRzosdFz via @medialens",
  "id" : 269545560678211584,
  "created_at" : "2012-11-16 21:00:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 30, 41 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FF",
      "indices" : [ 26, 29 ]
    }, {
      "text" : "tesolfr",
      "indices" : [ 82, 90 ]
    }, {
      "text" : "techdebate",
      "indices" : [ 91, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/GIZrHBaO",
      "expanded_url" : "http:\/\/www.digitalcounterrevolution.co.uk\/",
      "display_url" : "digitalcounterrevolution.co.uk"
    } ]
  },
  "geo" : { },
  "id_str" : "269498320030932992",
  "text" : "ed tech followers u gotta #FF @tornhalves and their blog  http:\/\/t.co\/GIZrHBaO cc #tesolfr #techdebate",
  "id" : 269498320030932992,
  "created_at" : "2012-11-16 17:53:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 0, 11 ],
      "id_str" : "282659955",
      "id" : 282659955
    }, {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 12, 28 ],
      "id_str" : "394053348",
      "id" : 394053348
    }, {
      "name" : "Sophia Khan",
      "screen_name" : "SophiaKhan4",
      "indices" : [ 29, 41 ],
      "id_str" : "351390617",
      "id" : 351390617
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "269428838788907008",
  "geo" : { },
  "id_str" : "269430613688344576",
  "in_reply_to_user_id" : 282659955,
  "text" : "@teflerinha @michaelegriffin @SophiaKhan4 did someone say big mikes and thrusting in the same sentence? :\/",
  "id" : 269430613688344576,
  "in_reply_to_status_id" : 269428838788907008,
  "created_at" : "2012-11-16 13:23:58 +0000",
  "in_reply_to_screen_name" : "teflerinha",
  "in_reply_to_user_id_str" : "282659955",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sophia Khan",
      "screen_name" : "SophiaKhan4",
      "indices" : [ 0, 12 ],
      "id_str" : "351390617",
      "id" : 351390617
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "269400750457749504",
  "geo" : { },
  "id_str" : "269414651396231168",
  "in_reply_to_user_id" : 351390617,
  "text" : "@SophiaKhan4 great! lk fwd to more tweets from u ;)",
  "id" : 269414651396231168,
  "in_reply_to_status_id" : 269400750457749504,
  "created_at" : "2012-11-16 12:20:33 +0000",
  "in_reply_to_screen_name" : "SophiaKhan4",
  "in_reply_to_user_id_str" : "351390617",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "le_mac",
      "screen_name" : "le_mac",
      "indices" : [ 0, 7 ],
      "id_str" : "17064137",
      "id" : 17064137
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "269319583821877248",
  "geo" : { },
  "id_str" : "269371970607513601",
  "in_reply_to_user_id" : 17064137,
  "text" : "@le_mac nice! hope u get a signed someit or other? :)",
  "id" : 269371970607513601,
  "in_reply_to_status_id" : 269319583821877248,
  "created_at" : "2012-11-16 09:30:57 +0000",
  "in_reply_to_screen_name" : "le_mac",
  "in_reply_to_user_id_str" : "17064137",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 3, 9 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    }, {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 61, 72 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/D6I0W7jC",
      "expanded_url" : "http:\/\/bit.ly\/U35Tdl",
      "display_url" : "bit.ly\/U35Tdl"
    } ]
  },
  "geo" : { },
  "id_str" : "269341259913629696",
  "text" : "RT @EBEFL Something light &amp; linguisticky for the weekend @leoselivan Less\/fewer http:\/\/t.co\/D6I0W7jC&lt;a cracking descriptivist call to arms",
  "id" : 269341259913629696,
  "created_at" : "2012-11-16 07:28:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Sample",
      "screen_name" : "samplereality",
      "indices" : [ 3, 17 ],
      "id_str" : "8497292",
      "id" : 8497292
    }, {
      "name" : "Jane Eyre",
      "screen_name" : "GovernessGirl",
      "indices" : [ 88, 102 ],
      "id_str" : "933490602",
      "id" : 933490602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269230243217285120",
  "text" : "RT @samplereality: One of my students is retelling Jane Eyre as a Twitter novel. Follow @GovernessGirl.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.metrotwit.com\/\" rel=\"nofollow\"\u003EMetroTwit\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jane Eyre",
        "screen_name" : "GovernessGirl",
        "indices" : [ 69, 83 ],
        "id_str" : "933490602",
        "id" : 933490602
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "269226979226693633",
    "text" : "One of my students is retelling Jane Eyre as a Twitter novel. Follow @GovernessGirl.",
    "id" : 269226979226693633,
    "created_at" : "2012-11-15 23:54:48 +0000",
    "user" : {
      "name" : "Mark Sample",
      "screen_name" : "samplereality",
      "protected" : false,
      "id_str" : "8497292",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000707852410\/a86167716ecb748acc89638ad165a162_normal.jpeg",
      "id" : 8497292,
      "verified" : false
    }
  },
  "id" : 269230243217285120,
  "created_at" : "2012-11-16 00:07:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 73, 83 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/TNmtKamq",
      "expanded_url" : "http:\/\/youtu.be\/1vUUgCptqpw",
      "display_url" : "youtu.be\/1vUUgCptqpw"
    } ]
  },
  "geo" : { },
  "id_str" : "269202742453608448",
  "text" : "Interview: Ali Abunimah on the situation in Gaza http:\/\/t.co\/TNmtKamq HT @medialens",
  "id" : 269202742453608448,
  "created_at" : "2012-11-15 22:18:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mieke Kenis",
      "screen_name" : "mkofab",
      "indices" : [ 0, 7 ],
      "id_str" : "96527212",
      "id" : 96527212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "269193043264020481",
  "geo" : { },
  "id_str" : "269196564570976257",
  "in_reply_to_user_id" : 96527212,
  "text" : "@mkofab yikes good luck migrating to new computer, always tiresome!",
  "id" : 269196564570976257,
  "in_reply_to_status_id" : 269193043264020481,
  "created_at" : "2012-11-15 21:53:57 +0000",
  "in_reply_to_screen_name" : "mkofab",
  "in_reply_to_user_id_str" : "96527212",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TESOL Intl Assn",
      "screen_name" : "TESOL_Assn",
      "indices" : [ 0, 11 ],
      "id_str" : "21091012",
      "id" : 21091012
    }, {
      "name" : "Karen Rowan",
      "screen_name" : "KarenRowan",
      "indices" : [ 12, 23 ],
      "id_str" : "53215364",
      "id" : 53215364
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "269183191070437376",
  "geo" : { },
  "id_str" : "269185851525849088",
  "in_reply_to_user_id" : 21091012,
  "text" : "@TESOL_Assn @KarenRowan do u know which volume it is?",
  "id" : 269185851525849088,
  "in_reply_to_status_id" : 269183191070437376,
  "created_at" : "2012-11-15 21:11:22 +0000",
  "in_reply_to_screen_name" : "TESOL_Assn",
  "in_reply_to_user_id_str" : "21091012",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mieke Kenis",
      "screen_name" : "mkofab",
      "indices" : [ 0, 7 ],
      "id_str" : "96527212",
      "id" : 96527212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http:\/\/t.co\/mKoZh1Kr",
      "expanded_url" : "http:\/\/www.oldapps.com\/tweetdeck.php",
      "display_url" : "oldapps.com\/tweetdeck.php"
    } ]
  },
  "in_reply_to_status_id_str" : "269181295693807616",
  "geo" : { },
  "id_str" : "269182387253030912",
  "in_reply_to_user_id" : 96527212,
  "text" : "@mkofab have u looked here http:\/\/t.co\/mKoZh1Kr ?",
  "id" : 269182387253030912,
  "in_reply_to_status_id" : 269181295693807616,
  "created_at" : "2012-11-15 20:57:36 +0000",
  "in_reply_to_screen_name" : "mkofab",
  "in_reply_to_user_id_str" : "96527212",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269170384702676994",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan happy birthday leo, have a good un and lk fwd to yr talk on sat",
  "id" : 269170384702676994,
  "created_at" : "2012-11-15 20:09:55 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#ELTchat",
      "screen_name" : "ELTchat",
      "indices" : [ 12, 20 ],
      "id_str" : "189578708",
      "id" : 189578708
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/DqiW9kSJ",
      "expanded_url" : "http:\/\/eltchatpodcast.podomatic.com\/player\/web\/2012-11-14T03_46_55-08_00",
      "display_url" : "eltchatpodcast.podomatic.com\/player\/web\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "269056748386652160",
  "text" : "another grt @ELTchat  podcast http:\/\/t.co\/DqiW9kSJ",
  "id" : 269056748386652160,
  "created_at" : "2012-11-15 12:38:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Levine",
      "screen_name" : "cogdog",
      "indices" : [ 66, 73 ],
      "id_str" : "740343",
      "id" : 740343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/b7tllshB",
      "expanded_url" : "http:\/\/cogdogblog.com\/2012\/11\/14\/gif-out\/",
      "display_url" : "cogdogblog.com\/2012\/11\/14\/gif\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "269022736020537344",
  "text" : "post about the news of the verb 'to gif' http:\/\/t.co\/b7tllshB via @cogdog",
  "id" : 269022736020537344,
  "created_at" : "2012-11-15 10:23:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anna Loseva",
      "screen_name" : "AnnLoseva",
      "indices" : [ 0, 10 ],
      "id_str" : "38822368",
      "id" : 38822368
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268819009816915968",
  "geo" : { },
  "id_str" : "268820599403577344",
  "in_reply_to_user_id" : 38822368,
  "text" : "@AnnLoseva for sure, though longterm less likely as individual app may disappear (unless it gets of course get much much more popular).",
  "id" : 268820599403577344,
  "in_reply_to_status_id" : 268819009816915968,
  "created_at" : "2012-11-14 21:00:00 +0000",
  "in_reply_to_screen_name" : "AnnLoseva",
  "in_reply_to_user_id_str" : "38822368",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anna Loseva",
      "screen_name" : "AnnLoseva",
      "indices" : [ 0, 10 ],
      "id_str" : "38822368",
      "id" : 38822368
    }, {
      "name" : "Alan Levine",
      "screen_name" : "cogdog",
      "indices" : [ 44, 51 ],
      "id_str" : "740343",
      "id" : 740343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 40 ],
      "url" : "http:\/\/t.co\/4qoBMEg6",
      "expanded_url" : "http:\/\/blog.oxforddictionaries.com\/2012\/11\/us-word-of-the-year-2012\/",
      "display_url" : "blog.oxforddictionaries.com\/2012\/11\/us-wor\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "268815429676437506",
  "geo" : { },
  "id_str" : "268818129994530817",
  "in_reply_to_user_id" : 38822368,
  "text" : "@AnnLoseva \u2018to GIF\u2019 http:\/\/t.co\/4qoBMEg6 HT @cogdog",
  "id" : 268818129994530817,
  "in_reply_to_status_id" : 268815429676437506,
  "created_at" : "2012-11-14 20:50:11 +0000",
  "in_reply_to_screen_name" : "AnnLoseva",
  "in_reply_to_user_id_str" : "38822368",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    }, {
      "name" : "Sandy Millin",
      "screen_name" : "sandymillin",
      "indices" : [ 12, 24 ],
      "id_str" : "144236944",
      "id" : 144236944
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268500047921033216",
  "geo" : { },
  "id_str" : "268501199144251392",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow @sandymillin sweet checking it.",
  "id" : 268501199144251392,
  "in_reply_to_status_id" : 268500047921033216,
  "created_at" : "2012-11-13 23:50:49 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268494159306960896",
  "geo" : { },
  "id_str" : "268496268689563649",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow any good online refs for using these things in ELT? i remember buying a set at the very begining now gathering dust :?",
  "id" : 268496268689563649,
  "in_reply_to_status_id" : 268494159306960896,
  "created_at" : "2012-11-13 23:31:13 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 81, 91 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/RHyyqOIl",
      "expanded_url" : "http:\/\/static.guim.co.uk\/sys-images\/Guardian\/Pix\/pictures\/2012\/11\/13\/1352765487552\/13.11.12-Steve-Bell-on-te-008.jpg",
      "display_url" : "static.guim.co.uk\/sys-images\/Gua\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "268468045712850944",
  "text" : "Ministry of Defence guide to burning poppies responsibly http:\/\/t.co\/RHyyqOIl HT @medialens",
  "id" : 268468045712850944,
  "created_at" : "2012-11-13 21:39:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268317283657588736",
  "geo" : { },
  "id_str" : "268360845891883010",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow no i don't remember that,  it never achieved the voyeuristic heights like the specs :\/",
  "id" : 268360845891883010,
  "in_reply_to_status_id" : 268317283657588736,
  "created_at" : "2012-11-13 14:33:06 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268309045314715650",
  "geo" : { },
  "id_str" : "268310260723372032",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow oh x-ray specs, the holy grail pinnacle of comic book ads! grt blog post as usual :)",
  "id" : 268310260723372032,
  "in_reply_to_status_id" : 268309045314715650,
  "created_at" : "2012-11-13 11:12:05 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 45, 56 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TESOLGreece",
      "indices" : [ 10, 22 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/GnLQlEG9",
      "expanded_url" : "http:\/\/tesolgreece.blogspot.gr\/2012\/11\/the-crisis-digital-complicity-torn.html",
      "display_url" : "tesolgreece.blogspot.gr\/2012\/11\/the-cr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "268298953584414722",
  "text" : "thanks to #TESOLGreece for turning me ont to @tornhalves http:\/\/t.co\/GnLQlEG9",
  "id" : 268298953584414722,
  "created_at" : "2012-11-13 10:27:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/C0DjzNrH",
      "expanded_url" : "http:\/\/www.ted.com\/talks\/beau_lotto_amy_o_toole_science_is_for_everyone_kids_included.html",
      "display_url" : "ted.com\/talks\/beau_lot\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "268295124356833280",
  "text" : "great sci ed video seen whilst checking out popcorn maker http:\/\/t.co\/C0DjzNrH",
  "id" : 268295124356833280,
  "created_at" : "2012-11-13 10:11:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Patterson",
      "screen_name" : "Brad5Patterson",
      "indices" : [ 0, 15 ],
      "id_str" : "944237276",
      "id" : 944237276
    }, {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 16, 27 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266518932255567872",
  "geo" : { },
  "id_str" : "266535022998196224",
  "in_reply_to_user_id" : 236921161,
  "text" : "@brad5patterson @leoselivan hehe if i ciuld retire then would be great! ;0",
  "id" : 266535022998196224,
  "in_reply_to_status_id" : 266518932255567872,
  "created_at" : "2012-11-08 13:37:56 +0000",
  "in_reply_to_screen_name" : "wordtov",
  "in_reply_to_user_id_str" : "236921161",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willy C. Cardoso",
      "screen_name" : "willycard",
      "indices" : [ 0, 10 ],
      "id_str" : "102353142",
      "id" : 102353142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266534156169773056",
  "in_reply_to_user_id" : 102353142,
  "text" : "@willycard thanks a  lot for what i think is my first blog \"strike\", a comment and a like on my last blog post! :)",
  "id" : 266534156169773056,
  "created_at" : "2012-11-08 13:34:29 +0000",
  "in_reply_to_screen_name" : "willycard",
  "in_reply_to_user_id_str" : "102353142",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "Brad Patterson",
      "screen_name" : "Brad5Patterson",
      "indices" : [ 12, 27 ],
      "id_str" : "944237276",
      "id" : 944237276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266234480224772097",
  "geo" : { },
  "id_str" : "266236584544858112",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan @brad5patterson dang i teach till 2030 on thursdays so will have to see how much energy i have left! happy birthday in advance!",
  "id" : 266236584544858112,
  "in_reply_to_status_id" : 266234480224772097,
  "created_at" : "2012-11-07 17:52:02 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 70, 80 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/FT9Sntar",
      "expanded_url" : "http:\/\/tinyurl.com\/c8jpe8n",
      "display_url" : "tinyurl.com\/c8jpe8n"
    } ]
  },
  "geo" : { },
  "id_str" : "265924545205116928",
  "text" : "wow, just finished 'Sworn Enemies'? - A Response To George Monbiot by @medialens http:\/\/t.co\/FT9Sntar subtitle 2004monbiot vs 2012monbiot",
  "id" : 265924545205116928,
  "created_at" : "2012-11-06 21:12:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/4rmnDXBp",
      "expanded_url" : "http:\/\/www.telegraph.co.uk\/history\/9653497\/British-have-invaded-nine-out-of-ten-countries-so-look-out-Luxembourg.html",
      "display_url" : "telegraph.co.uk\/history\/965349\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "265915271976480768",
  "text" : "a reason for spread of English? British have invaded nine out of ten countries - so look out Luxembourg http:\/\/t.co\/4rmnDXBp",
  "id" : 265915271976480768,
  "created_at" : "2012-11-06 20:35:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Petrie",
      "screen_name" : "teflgeek",
      "indices" : [ 0, 9 ],
      "id_str" : "305260555",
      "id" : 305260555
    }, {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 10, 25 ],
      "id_str" : "20760283",
      "id" : 20760283
    }, {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 26, 37 ],
      "id_str" : "282659955",
      "id" : 282659955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/38PuwOaj",
      "expanded_url" : "http:\/\/bit.ly\/Nw2TCs",
      "display_url" : "bit.ly\/Nw2TCs"
    }, {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/ntff7ZvS",
      "expanded_url" : "http:\/\/bit.ly\/nvcKrP",
      "display_url" : "bit.ly\/nvcKrP"
    } ]
  },
  "in_reply_to_status_id_str" : "265902990412636160",
  "geo" : { },
  "id_str" : "265910255437893633",
  "in_reply_to_user_id" : 305260555,
  "text" : "@teflgeek @MrChrisJWilson @teflerinha gd for speeches? round robin\/popcorn reading dismissed http:\/\/t.co\/38PuwOaj but c http:\/\/t.co\/ntff7ZvS",
  "id" : 265910255437893633,
  "in_reply_to_status_id" : 265902990412636160,
  "created_at" : "2012-11-06 20:15:19 +0000",
  "in_reply_to_screen_name" : "teflgeek",
  "in_reply_to_user_id_str" : "305260555",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Treme",
      "screen_name" : "watchingtreme",
      "indices" : [ 57, 71 ],
      "id_str" : "126354323",
      "id" : 126354323
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265906834882301952",
  "text" : "Treme TV drama that's got heart and soul and that swing! @watchingtreme",
  "id" : 265906834882301952,
  "created_at" : "2012-11-06 20:01:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JohnPfordresher",
      "screen_name" : "JohnPfordresher",
      "indices" : [ 0, 16 ],
      "id_str" : "168973558",
      "id" : 168973558
    }, {
      "name" : "Brad Patterson",
      "screen_name" : "Brad5Patterson",
      "indices" : [ 17, 32 ],
      "id_str" : "944237276",
      "id" : 944237276
    }, {
      "name" : "Huw Jarvis",
      "screen_name" : "TESOLacademic",
      "indices" : [ 113, 127 ],
      "id_str" : "43409552",
      "id" : 43409552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265606722855526401",
  "geo" : { },
  "id_str" : "265700770500980737",
  "in_reply_to_user_id" : 168973558,
  "text" : "@JohnPfordresher @brad5patterson agrred and some discussion of that in comments of article, the links posted by  @TESOLacademic luk int.",
  "id" : 265700770500980737,
  "in_reply_to_status_id" : 265606722855526401,
  "created_at" : "2012-11-06 06:22:54 +0000",
  "in_reply_to_screen_name" : "JohnPfordresher",
  "in_reply_to_user_id_str" : "168973558",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JohnPfordresher",
      "screen_name" : "JohnPfordresher",
      "indices" : [ 0, 16 ],
      "id_str" : "168973558",
      "id" : 168973558
    }, {
      "name" : "Brad Patterson",
      "screen_name" : "Brad5Patterson",
      "indices" : [ 17, 32 ],
      "id_str" : "944237276",
      "id" : 944237276
    }, {
      "name" : "Huw Jarvis",
      "screen_name" : "TESOLacademic",
      "indices" : [ 123, 137 ],
      "id_str" : "43409552",
      "id" : 43409552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/3JcspuFN",
      "expanded_url" : "http:\/\/bit.ly\/I9YC65",
      "display_url" : "bit.ly\/I9YC65"
    } ]
  },
  "in_reply_to_status_id_str" : "265601508836519937",
  "geo" : { },
  "id_str" : "265603069746741248",
  "in_reply_to_user_id" : 168973558,
  "text" : "@JohnPfordresher @brad5patterson u may find this int a contrary pov  English belongs to everyone? http:\/\/t.co\/3JcspuFN  HT @TESOLacademic",
  "id" : 265603069746741248,
  "in_reply_to_status_id" : 265601508836519937,
  "created_at" : "2012-11-05 23:54:41 +0000",
  "in_reply_to_screen_name" : "JohnPfordresher",
  "in_reply_to_user_id_str" : "168973558",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 0, 11 ],
      "id_str" : "282659955",
      "id" : 282659955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265598039266295808",
  "geo" : { },
  "id_str" : "265599850610057217",
  "in_reply_to_user_id" : 282659955,
  "text" : "@teflerinha maybe a recording artifact?",
  "id" : 265599850610057217,
  "in_reply_to_status_id" : 265598039266295808,
  "created_at" : "2012-11-05 23:41:53 +0000",
  "in_reply_to_screen_name" : "teflerinha",
  "in_reply_to_user_id_str" : "282659955",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 0, 11 ],
      "id_str" : "282659955",
      "id" : 282659955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265586562266456064",
  "geo" : { },
  "id_str" : "265596307815686144",
  "in_reply_to_user_id" : 282659955,
  "text" : "@teflerinha on the Sounds app, 'schwa addition effect' is pronounced with the voiced consonants, any clue there?",
  "id" : 265596307815686144,
  "in_reply_to_status_id" : 265586562266456064,
  "created_at" : "2012-11-05 23:27:48 +0000",
  "in_reply_to_screen_name" : "teflerinha",
  "in_reply_to_user_id_str" : "282659955",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol Goodey",
      "screen_name" : "cgoodey",
      "indices" : [ 0, 8 ],
      "id_str" : "26606833",
      "id" : 26606833
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265494640801767424",
  "geo" : { },
  "id_str" : "265504340670808064",
  "in_reply_to_user_id" : 26606833,
  "text" : "@cgoodey stuff by Howard Rheingold a good accessible jumpoff point",
  "id" : 265504340670808064,
  "in_reply_to_status_id" : 265494640801767424,
  "created_at" : "2012-11-05 17:22:22 +0000",
  "in_reply_to_screen_name" : "cgoodey",
  "in_reply_to_user_id_str" : "26606833",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Simpson",
      "screen_name" : "yearinthelifeof",
      "indices" : [ 0, 16 ],
      "id_str" : "78543378",
      "id" : 78543378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/zSiMXRX8",
      "expanded_url" : "http:\/\/higorcavalcante.files.wordpress.com\/2012\/04\/sherlock-grammar-video-warm-up-script-and-activity.pdf",
      "display_url" : "higorcavalcante.files.wordpress.com\/2012\/04\/sherlo\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "265240957824413697",
  "geo" : { },
  "id_str" : "265251331982381056",
  "in_reply_to_user_id" : 78543378,
  "text" : "@yearinthelifeof the case of the missing video clip? transcript here as a substitute http:\/\/t.co\/zSiMXRX8",
  "id" : 265251331982381056,
  "in_reply_to_status_id" : 265240957824413697,
  "created_at" : "2012-11-05 00:37:00 +0000",
  "in_reply_to_screen_name" : "yearinthelifeof",
  "in_reply_to_user_id_str" : "78543378",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 0, 11 ],
      "id_str" : "282659955",
      "id" : 282659955
    }, {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 12, 28 ],
      "id_str" : "394053348",
      "id" : 394053348
    }, {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 29, 40 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "cheimi10",
      "screen_name" : "cheimi10",
      "indices" : [ 128, 137 ],
      "id_str" : "2547295525",
      "id" : 2547295525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/BuQqVagj",
      "expanded_url" : "http:\/\/www.onestopenglish.com\/skills\/vocabulary\/corpora\/",
      "display_url" : "onestopenglish.com\/skills\/vocabul\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "265058274620080128",
  "geo" : { },
  "id_str" : "265091760965951488",
  "in_reply_to_user_id" : 282659955,
  "text" : "@teflerinha @michaelegriffin @leoselivan thanks useful list, have you seen the onestopenglish resources http:\/\/t.co\/BuQqVagj by @cheimi10 ?",
  "id" : 265091760965951488,
  "in_reply_to_status_id" : 265058274620080128,
  "created_at" : "2012-11-04 14:02:55 +0000",
  "in_reply_to_screen_name" : "teflerinha",
  "in_reply_to_user_id_str" : "282659955",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
} ]