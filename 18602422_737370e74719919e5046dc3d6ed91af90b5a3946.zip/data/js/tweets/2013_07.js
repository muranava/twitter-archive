Grailbird.data.tweets_2013_07 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "indices" : [ 3, 15 ],
      "id_str" : "192437743",
      "id" : 192437743
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltresearch",
      "indices" : [ 113, 125 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 126, 134 ]
    }, {
      "text" : "ellchat",
      "indices" : [ 135, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/Zx2KbCdtJD",
      "expanded_url" : "http:\/\/bit.ly\/133jDqi",
      "display_url" : "bit.ly\/133jDqi"
    } ]
  },
  "geo" : { },
  "id_str" : "362663034201706498",
  "text" : "RT @nathanghall: Just wrote a primer on reading and evaluating academic research articles http:\/\/t.co\/Zx2KbCdtJD #eltresearch #eltchat #ell\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "eltresearch",
        "indices" : [ 96, 108 ]
      }, {
        "text" : "eltchat",
        "indices" : [ 109, 117 ]
      }, {
        "text" : "ellchat",
        "indices" : [ 118, 126 ]
      } ],
      "urls" : [ {
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/Zx2KbCdtJD",
        "expanded_url" : "http:\/\/bit.ly\/133jDqi",
        "display_url" : "bit.ly\/133jDqi"
      } ]
    },
    "geo" : { },
    "id_str" : "362655296520327169",
    "text" : "Just wrote a primer on reading and evaluating academic research articles http:\/\/t.co\/Zx2KbCdtJD #eltresearch #eltchat #ellchat",
    "id" : 362655296520327169,
    "created_at" : "2013-07-31 19:25:35 +0000",
    "user" : {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "protected" : false,
      "id_str" : "192437743",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/715691315158061056\/_00s_D48_normal.jpg",
      "id" : 192437743,
      "verified" : false
    }
  },
  "id" : 362663034201706498,
  "created_at" : "2013-07-31 19:56:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 3, 14 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edtech",
      "indices" : [ 20, 27 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/n7SBcSMwe4",
      "expanded_url" : "http:\/\/bit.ly\/17REOyR",
      "display_url" : "bit.ly\/17REOyR"
    } ]
  },
  "geo" : { },
  "id_str" : "362273625270796289",
  "text" : "RT @tornhalves: The #edtech obsession with tools - a plea to end the digital prolongation of the dark side of the 18th century:  http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "edtech",
        "indices" : [ 4, 11 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/n7SBcSMwe4",
        "expanded_url" : "http:\/\/bit.ly\/17REOyR",
        "display_url" : "bit.ly\/17REOyR"
      } ]
    },
    "geo" : { },
    "id_str" : "362265893771816961",
    "text" : "The #edtech obsession with tools - a plea to end the digital prolongation of the dark side of the 18th century:  http:\/\/t.co\/n7SBcSMwe4",
    "id" : 362265893771816961,
    "created_at" : "2013-07-30 17:38:14 +0000",
    "user" : {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "protected" : false,
      "id_str" : "87902543",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3059742703\/1d3c7a2052db17d29644fa0a49af6480_normal.jpeg",
      "id" : 87902543,
      "verified" : false
    }
  },
  "id" : 362273625270796289,
  "created_at" : "2013-07-30 18:08:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "indices" : [ 0, 12 ],
      "id_str" : "192437743",
      "id" : 192437743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362252553104265218",
  "geo" : { },
  "id_str" : "362273589115883522",
  "in_reply_to_user_id" : 192437743,
  "text" : "@nathanghall lk fwd to reading contributions sadly not sure got time to contribute apart from commenting possibly",
  "id" : 362273589115883522,
  "in_reply_to_status_id" : 362252553104265218,
  "created_at" : "2013-07-30 18:08:49 +0000",
  "in_reply_to_screen_name" : "nathanghall",
  "in_reply_to_user_id_str" : "192437743",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "indices" : [ 3, 15 ],
      "id_str" : "192437743",
      "id" : 192437743
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 114, 118 ]
    }, {
      "text" : "esl",
      "indices" : [ 119, 123 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 124, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/S7rV0xWbjR",
      "expanded_url" : "http:\/\/bit.ly\/13aMpc3",
      "display_url" : "bit.ly\/13aMpc3"
    } ]
  },
  "geo" : { },
  "id_str" : "362189280283602946",
  "text" : "RT @nathanghall: Please consider joining in the ELT Research Blog Carnival. More info here http:\/\/t.co\/S7rV0xWbjR #elt #esl #eltchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "elt",
        "indices" : [ 97, 101 ]
      }, {
        "text" : "esl",
        "indices" : [ 102, 106 ]
      }, {
        "text" : "eltchat",
        "indices" : [ 107, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/S7rV0xWbjR",
        "expanded_url" : "http:\/\/bit.ly\/13aMpc3",
        "display_url" : "bit.ly\/13aMpc3"
      } ]
    },
    "geo" : { },
    "id_str" : "362128591426813953",
    "text" : "Please consider joining in the ELT Research Blog Carnival. More info here http:\/\/t.co\/S7rV0xWbjR #elt #esl #eltchat",
    "id" : 362128591426813953,
    "created_at" : "2013-07-30 08:32:38 +0000",
    "user" : {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "protected" : false,
      "id_str" : "192437743",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/715691315158061056\/_00s_D48_normal.jpg",
      "id" : 192437743,
      "verified" : false
    }
  },
  "id" : 362189280283602946,
  "created_at" : "2013-07-30 12:33:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Rago",
      "screen_name" : "tesolwar",
      "indices" : [ 3, 12 ],
      "id_str" : "234781682",
      "id" : 234781682
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tesol",
      "indices" : [ 81, 87 ]
    }, {
      "text" : "esl",
      "indices" : [ 88, 92 ]
    }, {
      "text" : "esol",
      "indices" : [ 93, 98 ]
    }, {
      "text" : "teachertraining",
      "indices" : [ 99, 115 ]
    }, {
      "text" : "keltchat",
      "indices" : [ 116, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/ynPQEzdODQ",
      "expanded_url" : "http:\/\/wp.me\/p3oXG1-1S",
      "display_url" : "wp.me\/p3oXG1-1S"
    } ]
  },
  "geo" : { },
  "id_str" : "362182395727855617",
  "text" : "RT @tesolwar: TESOL training and academic reading circles http:\/\/t.co\/ynPQEzdODQ #tesol #esl #esol #teachertraining #keltchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tesol",
        "indices" : [ 67, 73 ]
      }, {
        "text" : "esl",
        "indices" : [ 74, 78 ]
      }, {
        "text" : "esol",
        "indices" : [ 79, 84 ]
      }, {
        "text" : "teachertraining",
        "indices" : [ 85, 101 ]
      }, {
        "text" : "keltchat",
        "indices" : [ 102, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/ynPQEzdODQ",
        "expanded_url" : "http:\/\/wp.me\/p3oXG1-1S",
        "display_url" : "wp.me\/p3oXG1-1S"
      } ]
    },
    "geo" : { },
    "id_str" : "362159553942519810",
    "text" : "TESOL training and academic reading circles http:\/\/t.co\/ynPQEzdODQ #tesol #esl #esol #teachertraining #keltchat",
    "id" : 362159553942519810,
    "created_at" : "2013-07-30 10:35:40 +0000",
    "user" : {
      "name" : "Bill Rago",
      "screen_name" : "tesolwar",
      "protected" : false,
      "id_str" : "234781682",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/646499301141573632\/BQfwxt1a_normal.jpg",
      "id" : 234781682,
      "verified" : false
    }
  },
  "id" : 362182395727855617,
  "created_at" : "2013-07-30 12:06:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 63, 79 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/8MYgzJbp9E",
      "expanded_url" : "http:\/\/wp.me\/p3kNSH-P",
      "display_url" : "wp.me\/p3kNSH-P"
    } ]
  },
  "geo" : { },
  "id_str" : "362147386363101184",
  "text" : "Teaching is a McJob Part 1: Low Pay http:\/\/t.co\/8MYgzJbp9E via @wordpressdotcom",
  "id" : 362147386363101184,
  "created_at" : "2013-07-30 09:47:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "P\u00E9rez-Paredes",
      "screen_name" : "perezparedes",
      "indices" : [ 3, 16 ],
      "id_str" : "28528850",
      "id" : 28528850
    }, {
      "name" : "Scoop.it",
      "screen_name" : "scoopit",
      "indices" : [ 61, 69 ],
      "id_str" : "209484168",
      "id" : 209484168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/vEiq4cd43z",
      "expanded_url" : "http:\/\/sco.lt\/5HDfv7",
      "display_url" : "sco.lt\/5HDfv7"
    } ]
  },
  "geo" : { },
  "id_str" : "361449258509012992",
  "text" : "RT @perezparedes: Corpus_Technology_pedagogy_promotion.pdf | @scoopit http:\/\/t.co\/vEiq4cd43z",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.scoop.it\" rel=\"nofollow\"\u003EScoop.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Scoop.it",
        "screen_name" : "scoopit",
        "indices" : [ 43, 51 ],
        "id_str" : "209484168",
        "id" : 209484168
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/vEiq4cd43z",
        "expanded_url" : "http:\/\/sco.lt\/5HDfv7",
        "display_url" : "sco.lt\/5HDfv7"
      } ]
    },
    "geo" : { },
    "id_str" : "361020680571060225",
    "text" : "Corpus_Technology_pedagogy_promotion.pdf | @scoopit http:\/\/t.co\/vEiq4cd43z",
    "id" : 361020680571060225,
    "created_at" : "2013-07-27 07:10:12 +0000",
    "user" : {
      "name" : "P\u00E9rez-Paredes",
      "screen_name" : "perezparedes",
      "protected" : false,
      "id_str" : "28528850",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746249968139313153\/2-1yieTh_normal.jpg",
      "id" : 28528850,
      "verified" : false
    }
  },
  "id" : 361449258509012992,
  "created_at" : "2013-07-28 11:33:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Claire Hardaker",
      "screen_name" : "LangLingDrCH",
      "indices" : [ 0, 13 ],
      "id_str" : "1644889734",
      "id" : 1644889734
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "359813092831526913",
  "geo" : { },
  "id_str" : "359817695207755776",
  "in_reply_to_user_id" : 237842162,
  "text" : "@LangLingDrCH grt, many thanks :)",
  "id" : 359817695207755776,
  "in_reply_to_status_id" : 359813092831526913,
  "created_at" : "2013-07-23 23:29:58 +0000",
  "in_reply_to_screen_name" : "DrClaireH",
  "in_reply_to_user_id_str" : "237842162",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boing Boing",
      "screen_name" : "BoingBoing",
      "indices" : [ 3, 14 ],
      "id_str" : "5971922",
      "id" : 5971922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/XSdT1tfU6s",
      "expanded_url" : "http:\/\/dlvr.it\/3hmzp0",
      "display_url" : "dlvr.it\/3hmzp0"
    } ]
  },
  "geo" : { },
  "id_str" : "359817326113198081",
  "text" : "RT @BoingBoing: LED Tetris tie http:\/\/t.co\/XSdT1tfU6s",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/dlvr.it\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 15, 37 ],
        "url" : "http:\/\/t.co\/XSdT1tfU6s",
        "expanded_url" : "http:\/\/dlvr.it\/3hmzp0",
        "display_url" : "dlvr.it\/3hmzp0"
      } ]
    },
    "geo" : { },
    "id_str" : "359764214379839492",
    "text" : "LED Tetris tie http:\/\/t.co\/XSdT1tfU6s",
    "id" : 359764214379839492,
    "created_at" : "2013-07-23 19:57:27 +0000",
    "user" : {
      "name" : "Boing Boing",
      "screen_name" : "BoingBoing",
      "protected" : false,
      "id_str" : "5971922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616924998226153472\/0EfZYjr2_normal.png",
      "id" : 5971922,
      "verified" : true
    }
  },
  "id" : 359817326113198081,
  "created_at" : "2013-07-23 23:28:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Claire Hardaker",
      "screen_name" : "LangLingDrCH",
      "indices" : [ 0, 13 ],
      "id_str" : "1644889734",
      "id" : 1644889734
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "359462330234437634",
  "geo" : { },
  "id_str" : "359809716190322689",
  "in_reply_to_user_id" : 237842162,
  "text" : "@LangLingDrCH thanks, is yr work openly available somewhere?",
  "id" : 359809716190322689,
  "in_reply_to_status_id" : 359462330234437634,
  "created_at" : "2013-07-23 22:58:15 +0000",
  "in_reply_to_screen_name" : "DrClaireH",
  "in_reply_to_user_id_str" : "237842162",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/84q7lJLDDc",
      "expanded_url" : "http:\/\/johnhilley.blogspot.co.uk\/2013\/07\/baby-arrival-royal-commands-and-media.html",
      "display_url" : "johnhilley.blogspot.co.uk\/2013\/07\/baby-a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "359808360331214848",
  "text" : "RT @johnwhilley: Baby arrival - royal commands and media expectations http:\/\/t.co\/84q7lJLDDc One day we may live in a sane republic.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 75 ],
        "url" : "http:\/\/t.co\/84q7lJLDDc",
        "expanded_url" : "http:\/\/johnhilley.blogspot.co.uk\/2013\/07\/baby-arrival-royal-commands-and-media.html",
        "display_url" : "johnhilley.blogspot.co.uk\/2013\/07\/baby-a\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "359646946174058496",
    "text" : "Baby arrival - royal commands and media expectations http:\/\/t.co\/84q7lJLDDc One day we may live in a sane republic.",
    "id" : 359646946174058496,
    "created_at" : "2013-07-23 12:11:28 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 359808360331214848,
  "created_at" : "2013-07-23 22:52:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott McLeod",
      "screen_name" : "mcleod",
      "indices" : [ 3, 10 ],
      "id_str" : "4132841",
      "id" : 4132841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/BT2jjPwb30",
      "expanded_url" : "http:\/\/bit.ly\/1602bos",
      "display_url" : "bit.ly\/1602bos"
    } ]
  },
  "geo" : { },
  "id_str" : "359451899528871939",
  "text" : "RT @mcleod: The Billionaires' War Against Public Education http:\/\/t.co\/BT2jjPwb30",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 69 ],
        "url" : "http:\/\/t.co\/BT2jjPwb30",
        "expanded_url" : "http:\/\/bit.ly\/1602bos",
        "display_url" : "bit.ly\/1602bos"
      } ]
    },
    "geo" : { },
    "id_str" : "359440261786501120",
    "text" : "The Billionaires' War Against Public Education http:\/\/t.co\/BT2jjPwb30",
    "id" : 359440261786501120,
    "created_at" : "2013-07-22 22:30:11 +0000",
    "user" : {
      "name" : "Scott McLeod",
      "screen_name" : "mcleod",
      "protected" : false,
      "id_str" : "4132841",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528513398003077123\/U0fv_0fy_normal.jpeg",
      "id" : 4132841,
      "verified" : false
    }
  },
  "id" : 359451899528871939,
  "created_at" : "2013-07-22 23:16:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Claire Hardaker",
      "screen_name" : "LangLingDrCH",
      "indices" : [ 0, 13 ],
      "id_str" : "1644889734",
      "id" : 1644889734
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "359235521718919168",
  "geo" : { },
  "id_str" : "359436766505218048",
  "in_reply_to_user_id" : 237842162,
  "text" : "@LangLingDrCH hi, either, both",
  "id" : 359436766505218048,
  "in_reply_to_status_id" : 359235521718919168,
  "created_at" : "2013-07-22 22:16:17 +0000",
  "in_reply_to_screen_name" : "DrClaireH",
  "in_reply_to_user_id_str" : "237842162",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "snowden",
      "indices" : [ 100, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/ZBiXon57KH",
      "expanded_url" : "http:\/\/www.accuracy.org\/release\/military-contractor-resigns-in-impassioned-protest-i-hereby-throw-down-my-rifle\/",
      "display_url" : "accuracy.org\/release\/milita\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "358721361209856000",
  "text" : "RT @medialens: The ripple effect of a good example. Power hates it when this kind of stuff happens. #snowden http:\/\/t.co\/ZBiXon57KH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "snowden",
        "indices" : [ 85, 93 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/ZBiXon57KH",
        "expanded_url" : "http:\/\/www.accuracy.org\/release\/military-contractor-resigns-in-impassioned-protest-i-hereby-throw-down-my-rifle\/",
        "display_url" : "accuracy.org\/release\/milita\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "357897404613263360",
    "text" : "The ripple effect of a good example. Power hates it when this kind of stuff happens. #snowden http:\/\/t.co\/ZBiXon57KH",
    "id" : 357897404613263360,
    "created_at" : "2013-07-18 16:19:25 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 358721361209856000,
  "created_at" : "2013-07-20 22:53:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 3, 17 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 143, 144 ],
      "url" : "http:\/\/t.co\/CTgwN6xtOB",
      "expanded_url" : "http:\/\/timmmmyboy.com\/2013\/07\/a-distributed-domain-of-ones-own\/",
      "display_url" : "timmmmyboy.com\/2013\/07\/a-dist\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "358519625807429632",
  "text" : "RT @audreywatters: Further proof that UMW's \"Domain of One's Own\" initiative is one of the most important &amp; innovative things in ed-tech ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/CTgwN6xtOB",
        "expanded_url" : "http:\/\/timmmmyboy.com\/2013\/07\/a-distributed-domain-of-ones-own\/",
        "display_url" : "timmmmyboy.com\/2013\/07\/a-dist\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "357957060840792064",
    "text" : "Further proof that UMW's \"Domain of One's Own\" initiative is one of the most important &amp; innovative things in ed-tech http:\/\/t.co\/CTgwN6xtOB",
    "id" : 357957060840792064,
    "created_at" : "2013-07-18 20:16:28 +0000",
    "user" : {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "protected" : false,
      "id_str" : "25388528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711668009723498496\/pauFZsdv_normal.jpg",
      "id" : 25388528,
      "verified" : false
    }
  },
  "id" : 358519625807429632,
  "created_at" : "2013-07-20 09:31:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 33, 44 ],
      "id_str" : "144663117",
      "id" : 144663117
    }, {
      "name" : "\u0411\u0430\u043B\u0438\u043D\u0433",
      "screen_name" : "websofsubstance",
      "indices" : [ 76, 92 ],
      "id_str" : "235176479",
      "id" : 235176479
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/bnPgyBLSeo",
      "expanded_url" : "http:\/\/theotherthingsmatter.blogspot.jp\/2013\/07\/english-in-dollars-and-sense.html",
      "display_url" : "theotherthingsmatter.blogspot.jp\/2013\/07\/englis\u2026"
    }, {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/WpdkZ69GDS",
      "expanded_url" : "http:\/\/websofsubstance.wordpress.com\/2013\/07\/19\/opportunity-cost\/",
      "display_url" : "websofsubstance.wordpress.com\/2013\/07\/19\/opp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "358485023319523328",
  "text" : "economics and teaching policy by @kevchanwow http:\/\/t.co\/bnPgyBLSeo \u2026 &amp; @websofsubstance http:\/\/t.co\/WpdkZ69GDS \u2026",
  "id" : 358485023319523328,
  "created_at" : "2013-07-20 07:14:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yuichiro Kobayashi",
      "screen_name" : "langstat",
      "indices" : [ 78, 87 ],
      "id_str" : "108896452",
      "id" : 108896452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/o0llGMfDMu",
      "expanded_url" : "http:\/\/linguistlist.org\/issues\/24\/24-2935.html?utm_source=twitterfeed&utm_medium=twitter",
      "display_url" : "linguistlist.org\/issues\/24\/24-2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "358365361457995777",
  "text" : "nice! a L2 writing corpus w\/o stoopid restrictions http:\/\/t.co\/o0llGMfDMu HT  @langstat",
  "id" : 358365361457995777,
  "created_at" : "2013-07-19 23:18:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 0, 13 ],
      "id_str" : "88655243",
      "id" : 88655243
    }, {
      "name" : "Adi Rajan",
      "screen_name" : "adi_rajan",
      "indices" : [ 54, 64 ],
      "id_str" : "1011323449",
      "id" : 1011323449
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357594722140819456",
  "geo" : { },
  "id_str" : "357784590418583553",
  "in_reply_to_user_id" : 88655243,
  "text" : "@rosemerebard thx rose i just replied to a comment by @adi_rajan that gengen maybe a limited but still useful way to explore coca.",
  "id" : 357784590418583553,
  "in_reply_to_status_id" : 357594722140819456,
  "created_at" : "2013-07-18 08:51:08 +0000",
  "in_reply_to_screen_name" : "rosemerebard",
  "in_reply_to_user_id_str" : "88655243",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "010-8575-6630",
      "screen_name" : "djnada",
      "indices" : [ 0, 7 ],
      "id_str" : "2271666128",
      "id" : 2271666128
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/1bLsaauw83",
      "expanded_url" : "http:\/\/www.eapfoundation.com\/about\/",
      "display_url" : "eapfoundation.com\/about\/"
    } ]
  },
  "in_reply_to_status_id_str" : "357231636686974978",
  "geo" : { },
  "id_str" : "357478122851020800",
  "in_reply_to_user_id" : 15663328,
  "text" : "@djnada glad to help; it's a curious site, still being built, nice tools, and a belief in learning styles http:\/\/t.co\/1bLsaauw83",
  "id" : 357478122851020800,
  "in_reply_to_status_id" : 357231636686974978,
  "created_at" : "2013-07-17 12:33:20 +0000",
  "in_reply_to_screen_name" : "LauraSoracco",
  "in_reply_to_user_id_str" : "15663328",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "010-8575-6630",
      "screen_name" : "djnada",
      "indices" : [ 0, 7 ],
      "id_str" : "2271666128",
      "id" : 2271666128
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/HnKJsmHwYT",
      "expanded_url" : "http:\/\/www.eapfoundation.com\/vocab\/academic\/highlighter\/",
      "display_url" : "eapfoundation.com\/vocab\/academic\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "357220256097386498",
  "geo" : { },
  "id_str" : "357223471790559233",
  "in_reply_to_user_id" : 15663328,
  "text" : "@djnada have u tried this one? http:\/\/t.co\/HnKJsmHwYT",
  "id" : 357223471790559233,
  "in_reply_to_status_id" : 357220256097386498,
  "created_at" : "2013-07-16 19:41:27 +0000",
  "in_reply_to_screen_name" : "LauraSoracco",
  "in_reply_to_user_id_str" : "15663328",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Willingham",
      "screen_name" : "DTWillingham",
      "indices" : [ 3, 16 ],
      "id_str" : "84619537",
      "id" : 84619537
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edchat",
      "indices" : [ 123, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/3u8nx92nC4",
      "expanded_url" : "http:\/\/bit.ly\/1aGWRwK",
      "display_url" : "bit.ly\/1aGWRwK"
    } ]
  },
  "geo" : { },
  "id_str" : "357212712108965889",
  "text" : "RT @DTWillingham: In case you missed it, new blog: Fundamental flaw in claims about brain training. http:\/\/t.co\/3u8nx92nC4 #edchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "edchat",
        "indices" : [ 105, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/3u8nx92nC4",
        "expanded_url" : "http:\/\/bit.ly\/1aGWRwK",
        "display_url" : "bit.ly\/1aGWRwK"
      } ]
    },
    "geo" : { },
    "id_str" : "356817240961728513",
    "text" : "In case you missed it, new blog: Fundamental flaw in claims about brain training. http:\/\/t.co\/3u8nx92nC4 #edchat",
    "id" : 356817240961728513,
    "created_at" : "2013-07-15 16:47:14 +0000",
    "user" : {
      "name" : "Daniel Willingham",
      "screen_name" : "DTWillingham",
      "protected" : false,
      "id_str" : "84619537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1815678310\/Daniel_Willingham_Color_lowres_normal.JPG",
      "id" : 84619537,
      "verified" : false
    }
  },
  "id" : 357212712108965889,
  "created_at" : "2013-07-16 18:58:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Claire Hardaker",
      "screen_name" : "LangLingDrCH",
      "indices" : [ 0, 13 ],
      "id_str" : "1644889734",
      "id" : 1644889734
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "356718984520933376",
  "geo" : { },
  "id_str" : "357188612833558528",
  "in_reply_to_user_id" : 237842162,
  "text" : "@LangLingDrCH was wondering if u had a look at decline in use of flaming relative to trolling?",
  "id" : 357188612833558528,
  "in_reply_to_status_id" : 356718984520933376,
  "created_at" : "2013-07-16 17:22:56 +0000",
  "in_reply_to_screen_name" : "DrClaireH",
  "in_reply_to_user_id_str" : "237842162",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "4TUNE Teller App",
      "screen_name" : "4tunetellernet",
      "indices" : [ 0, 15 ],
      "id_str" : "467634146",
      "id" : 467634146
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "354202841948233728",
  "geo" : { },
  "id_str" : "355779449687511040",
  "in_reply_to_user_id" : 467634146,
  "text" : "@4tunetellernet thats NICE :)",
  "id" : 355779449687511040,
  "in_reply_to_status_id" : 354202841948233728,
  "created_at" : "2013-07-12 20:03:25 +0000",
  "in_reply_to_screen_name" : "4tunetellernet",
  "in_reply_to_user_id_str" : "467634146",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "354421981799645184",
  "geo" : { },
  "id_str" : "355779284511621121",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt thanks for share hope yr summer is shiny :)",
  "id" : 355779284511621121,
  "in_reply_to_status_id" : 354421981799645184,
  "created_at" : "2013-07-12 20:02:46 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Pride",
      "screen_name" : "ThomasPride",
      "indices" : [ 103, 115 ],
      "id_str" : "385867551",
      "id" : 385867551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/JGnE65BbIR",
      "expanded_url" : "http:\/\/wp.me\/p1U04a-4RB",
      "display_url" : "wp.me\/p1U04a-4RB"
    } ]
  },
  "geo" : { },
  "id_str" : "353854166378098688",
  "text" : "Blair backs Egypt coup saying too few Arabs dying to secure democracy there http:\/\/t.co\/JGnE65BbIR via @ThomasPride",
  "id" : 353854166378098688,
  "created_at" : "2013-07-07 12:33:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/uOqFvhpaU8",
      "expanded_url" : "http:\/\/www.badassteacher.org",
      "display_url" : "badassteacher.org"
    }, {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/nDELFJ1vKX",
      "expanded_url" : "https:\/\/teacherbiz.wordpress.com\/2013\/07\/06\/an-open-letter-to-badass-supporter-of-public-education-jon-stewart\/",
      "display_url" : "teacherbiz.wordpress.com\/2013\/07\/06\/an-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "353592369934893056",
  "text" : "Bad Ass Teacher Association http:\/\/t.co\/uOqFvhpaU8&lt;--where do i signup? :) HT https:\/\/t.co\/nDELFJ1vKX",
  "id" : 353592369934893056,
  "created_at" : "2013-07-06 19:12:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "4TUNE Teller App",
      "screen_name" : "4tunetellernet",
      "indices" : [ 0, 15 ],
      "id_str" : "467634146",
      "id" : 467634146
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "353190529011433473",
  "geo" : { },
  "id_str" : "353196707359625216",
  "in_reply_to_user_id" : 467634146,
  "text" : "@4tunetellernet maybe it was because of her (poor) jazz knowledge -\"Minnie the Moocher, classic Blues Brothers song\" :)",
  "id" : 353196707359625216,
  "in_reply_to_status_id" : 353190529011433473,
  "created_at" : "2013-07-05 17:00:31 +0000",
  "in_reply_to_screen_name" : "4tunetellernet",
  "in_reply_to_user_id_str" : "467634146",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 104, 112 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/hmHrBqZBdj",
      "expanded_url" : "http:\/\/youtu.be\/Lfx9D_MUkCU",
      "display_url" : "youtu.be\/Lfx9D_MUkCU"
    } ]
  },
  "geo" : { },
  "id_str" : "353148980970000384",
  "text" : "I could never vote for New Labour - Owen Jones Interview #22 \"fight from...: http:\/\/t.co\/hmHrBqZBdj via @youtube",
  "id" : 353148980970000384,
  "created_at" : "2013-07-05 13:50:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BEBC",
      "screen_name" : "Books4English",
      "indices" : [ 0, 14 ],
      "id_str" : "181893496",
      "id" : 181893496
    }, {
      "name" : "Scott Thornbury",
      "screen_name" : "thornburyscott",
      "indices" : [ 15, 30 ],
      "id_str" : "23090474",
      "id" : 23090474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "353100831052152833",
  "geo" : { },
  "id_str" : "353102159417585666",
  "in_reply_to_user_id" : 181893496,
  "text" : "@Books4English @thornburyscott looks like you do same with other posts on your blog? rebloggng shld only be few lines &amp; link to orignal post",
  "id" : 353102159417585666,
  "in_reply_to_status_id" : 353100831052152833,
  "created_at" : "2013-07-05 10:44:49 +0000",
  "in_reply_to_screen_name" : "Books4English",
  "in_reply_to_user_id_str" : "181893496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim George",
      "screen_name" : "oyajimbo",
      "indices" : [ 0, 9 ],
      "id_str" : "96103979",
      "id" : 96103979
    }, {
      "name" : "The Guardian",
      "screen_name" : "guardian",
      "indices" : [ 10, 19 ],
      "id_str" : "87818409",
      "id" : 87818409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/AK415NkhXM",
      "expanded_url" : "http:\/\/www.washingtonpost.com\/blogs\/worldviews\/wp\/2013\/07\/03\/audio-purportedly-from-inside-the-cockpit-of-bolivian-president-evo-moraless-flight\/",
      "display_url" : "washingtonpost.com\/blogs\/worldvie\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "353093423688986624",
  "geo" : { },
  "id_str" : "353094273027162113",
  "in_reply_to_user_id" : 96103979,
  "text" : "@oyajimbo @guardian there's some interesting audio here, no idea if authentic but int nevertheless http:\/\/t.co\/AK415NkhXM",
  "id" : 353094273027162113,
  "in_reply_to_status_id" : 353093423688986624,
  "created_at" : "2013-07-05 10:13:29 +0000",
  "in_reply_to_screen_name" : "oyajimbo",
  "in_reply_to_user_id_str" : "96103979",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yolanda B. Schell",
      "screen_name" : "mattellman",
      "indices" : [ 0, 11 ],
      "id_str" : "725597315860434945",
      "id" : 725597315860434945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/CMspXEkQXH",
      "expanded_url" : "http:\/\/www.corpus4u.org\/forum\/index.php",
      "display_url" : "corpus4u.org\/forum\/index.php"
    } ]
  },
  "in_reply_to_status_id_str" : "353051916101615616",
  "geo" : { },
  "id_str" : "353053087881109504",
  "in_reply_to_user_id" : 394987109,
  "text" : "@mattellman thx, if u r int in corpus text sign up to chinese forum http:\/\/t.co\/CMspXEkQXH lots of int pdfs floating about on that site :)",
  "id" : 353053087881109504,
  "in_reply_to_status_id" : 353051916101615616,
  "created_at" : "2013-07-05 07:29:50 +0000",
  "in_reply_to_screen_name" : "MatthewEllman",
  "in_reply_to_user_id_str" : "394987109",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yolanda B. Schell",
      "screen_name" : "mattellman",
      "indices" : [ 0, 11 ],
      "id_str" : "725597315860434945",
      "id" : 725597315860434945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352908450008809475",
  "geo" : { },
  "id_str" : "352909733151244290",
  "in_reply_to_user_id" : 394987109,
  "text" : "@mattellman where's the quote from?",
  "id" : 352909733151244290,
  "in_reply_to_status_id" : 352908450008809475,
  "created_at" : "2013-07-04 22:00:11 +0000",
  "in_reply_to_screen_name" : "MatthewEllman",
  "in_reply_to_user_id_str" : "394987109",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 0, 11 ],
      "id_str" : "88202140",
      "id" : 88202140
    }, {
      "name" : "Sarah Forbes",
      "screen_name" : "GenkiSarah",
      "indices" : [ 12, 23 ],
      "id_str" : "586340658",
      "id" : 586340658
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352905078392365056",
  "geo" : { },
  "id_str" : "352909483074265088",
  "in_reply_to_user_id" : 88202140,
  "text" : "@hughdellar @GenkiSarah wanted to attach ? but then would have destroyed symmetry with earlier compare tweet :)",
  "id" : 352909483074265088,
  "in_reply_to_status_id" : 352905078392365056,
  "created_at" : "2013-07-04 21:59:12 +0000",
  "in_reply_to_screen_name" : "hughdellar",
  "in_reply_to_user_id_str" : "88202140",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Levine",
      "screen_name" : "cogdog",
      "indices" : [ 108, 115 ],
      "id_str" : "740343",
      "id" : 740343
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ds106",
      "indices" : [ 15, 21 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/XgaYibuKg2",
      "expanded_url" : "http:\/\/tdc.ds106.us\/writings\/sir-michael-robinson-thatcher\/",
      "display_url" : "tdc.ds106.us\/writings\/sir-m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "352900544911769601",
  "text" : "hehe like this #ds106 daily create 3-in-one leaders sir-michael-robinson-thatcher http:\/\/t.co\/XgaYibuKg2 ht @cogdog",
  "id" : 352900544911769601,
  "created_at" : "2013-07-04 21:23:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Thornbury",
      "screen_name" : "thornburyscott",
      "indices" : [ 0, 15 ],
      "id_str" : "23090474",
      "id" : 23090474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/JZWBitQ1Gj",
      "expanded_url" : "https:\/\/bebcblog.wordpress.com\/2013\/07\/04\/s-is-for-soaps\/",
      "display_url" : "bebcblog.wordpress.com\/2013\/07\/04\/s-i\u2026"
    }, {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/3VcTPuWNSl",
      "expanded_url" : "http:\/\/bebcblog.wordpress.com\/2013\/07\/04\/p-is-for-pedagogic-grammar\/",
      "display_url" : "bebcblog.wordpress.com\/2013\/07\/04\/p-i\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "352427338572636161",
  "geo" : { },
  "id_str" : "352842608017547265",
  "in_reply_to_user_id" : 23090474,
  "text" : "@thornburyscott they seem to be at it again https:\/\/t.co\/JZWBitQ1Gj and http:\/\/t.co\/3VcTPuWNSl they have some custom auto reblogger?",
  "id" : 352842608017547265,
  "in_reply_to_status_id" : 352427338572636161,
  "created_at" : "2013-07-04 17:33:27 +0000",
  "in_reply_to_screen_name" : "thornburyscott",
  "in_reply_to_user_id_str" : "23090474",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/vXqYu0xlDE",
      "expanded_url" : "http:\/\/mobandmultitude.com\/2013\/07\/02\/the-nsa-comes-recruiting\/",
      "display_url" : "mobandmultitude.com\/2013\/07\/02\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "352779929529753600",
  "text" : "The NSA Comes Recruiting - http:\/\/t.co\/vXqYu0xlDE",
  "id" : 352779929529753600,
  "created_at" : "2013-07-04 13:24:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "4TUNE Teller App",
      "screen_name" : "4tunetellernet",
      "indices" : [ 0, 15 ],
      "id_str" : "467634146",
      "id" : 467634146
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/6x6hpnkADI",
      "expanded_url" : "https:\/\/soundcloud.com\/theraphosa\/war-machine",
      "display_url" : "soundcloud.com\/theraphosa\/war\u2026"
    }, {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/R169hx1BIb",
      "expanded_url" : "http:\/\/www.theraphosa.fr\/",
      "display_url" : "theraphosa.fr"
    } ]
  },
  "geo" : { },
  "id_str" : "352768170630713345",
  "in_reply_to_user_id" : 467634146,
  "text" : "@4tunetellernet eh up dan u may want to check this https:\/\/t.co\/6x6hpnkADI frm one of my sts badn site http:\/\/t.co\/R169hx1BIb",
  "id" : 352768170630713345,
  "created_at" : "2013-07-04 12:37:40 +0000",
  "in_reply_to_screen_name" : "4tunetellernet",
  "in_reply_to_user_id_str" : "467634146",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Forbes",
      "screen_name" : "GenkiSarah",
      "indices" : [ 11, 22 ],
      "id_str" : "586340658",
      "id" : 586340658
    }, {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 73, 84 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/yMzvi38Qpc",
      "expanded_url" : "http:\/\/sarahatktc.weebly.com\/1\/post\/2013\/07\/global-knowledge-efl.html",
      "display_url" : "sarahatktc.weebly.com\/1\/post\/2013\/07\u2026"
    }, {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/CPcPaF0Mck",
      "expanded_url" : "http:\/\/wp.me\/p2kILc-bB",
      "display_url" : "wp.me\/p2kILc-bB"
    } ]
  },
  "geo" : { },
  "id_str" : "352728700665602050",
  "text" : "Contrast - @GenkiSarah Global Knowledge &amp; EFL http:\/\/t.co\/yMzvi38Qpc @hughdellar Probably the best blog post. . . http:\/\/t.co\/CPcPaF0Mck",
  "id" : 352728700665602050,
  "created_at" : "2013-07-04 10:00:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bret Victor",
      "screen_name" : "worrydream",
      "indices" : [ 11, 22 ],
      "id_str" : "255617445",
      "id" : 255617445
    }, {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 63, 74 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/Sg4PDlCcVZ",
      "expanded_url" : "http:\/\/worrydream.com\/Engelbart",
      "display_url" : "worrydream.com\/Engelbart"
    }, {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/pGqDycIUZ7",
      "expanded_url" : "http:\/\/bit.ly\/14PJmnl",
      "display_url" : "bit.ly\/14PJmnl"
    } ]
  },
  "geo" : { },
  "id_str" : "352728528552329216",
  "text" : "Compare - \u200F@worrydream Doug Engelbart. http:\/\/t.co\/Sg4PDlCcVZ  @tornhalves the challenges the digital revolution? http:\/\/t.co\/pGqDycIUZ7",
  "id" : 352728528552329216,
  "created_at" : "2013-07-04 10:00:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "maybetheywill",
      "indices" : [ 56, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352725493096792064",
  "text" : "@EBEFL oh i thought they had done a followup to yr post #maybetheywill?",
  "id" : 352725493096792064,
  "created_at" : "2013-07-04 09:48:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "William Ian O'Byrne",
      "screen_name" : "wiobyrne",
      "indices" : [ 3, 12 ],
      "id_str" : "88676762",
      "id" : 88676762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/qIg3RHiVns",
      "expanded_url" : "http:\/\/fplus.me\/2hoH",
      "display_url" : "fplus.me\/2hoH"
    } ]
  },
  "geo" : { },
  "id_str" : "352724910050779136",
  "text" : "RT @wiobyrne: Twitter Wants to Start Tracking You on the Web, Here's How to Opt-Out http:\/\/t.co\/qIg3RHiVns",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/friendsplus.me\" rel=\"nofollow\"\u003EFriends Me\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/qIg3RHiVns",
        "expanded_url" : "http:\/\/fplus.me\/2hoH",
        "display_url" : "fplus.me\/2hoH"
      } ]
    },
    "geo" : { },
    "id_str" : "352580883808653312",
    "text" : "Twitter Wants to Start Tracking You on the Web, Here's How to Opt-Out http:\/\/t.co\/qIg3RHiVns",
    "id" : 352580883808653312,
    "created_at" : "2013-07-04 00:13:27 +0000",
    "user" : {
      "name" : "William Ian O'Byrne",
      "screen_name" : "wiobyrne",
      "protected" : false,
      "id_str" : "88676762",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/519580082\/twitter_normal.jpg",
      "id" : 88676762,
      "verified" : false
    }
  },
  "id" : 352724910050779136,
  "created_at" : "2013-07-04 09:45:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bret Victor",
      "screen_name" : "worrydream",
      "indices" : [ 3, 14 ],
      "id_str" : "255617445",
      "id" : 255617445
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/HiirBQK9Vu",
      "expanded_url" : "http:\/\/worrydream.com\/Engelbart",
      "display_url" : "worrydream.com\/Engelbart"
    } ]
  },
  "geo" : { },
  "id_str" : "352719800969076736",
  "text" : "RT @worrydream: \u2605 I tried to write a few words about Doug Engelbart.  http:\/\/t.co\/HiirBQK9Vu  It's the best I can do right now.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 76 ],
        "url" : "http:\/\/t.co\/HiirBQK9Vu",
        "expanded_url" : "http:\/\/worrydream.com\/Engelbart",
        "display_url" : "worrydream.com\/Engelbart"
      } ]
    },
    "geo" : { },
    "id_str" : "352595662816284675",
    "text" : "\u2605 I tried to write a few words about Doug Engelbart.  http:\/\/t.co\/HiirBQK9Vu  It's the best I can do right now.",
    "id" : 352595662816284675,
    "created_at" : "2013-07-04 01:12:11 +0000",
    "user" : {
      "name" : "Bret Victor",
      "screen_name" : "worrydream",
      "protected" : false,
      "id_str" : "255617445",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/767981637623685120\/7WgbPNE9_normal.jpg",
      "id" : 255617445,
      "verified" : false
    }
  },
  "id" : 352719800969076736,
  "created_at" : "2013-07-04 09:25:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/AjNJEdr99t",
      "expanded_url" : "http:\/\/members5.boardhost.com\/medialens\/msg\/1372923764.html",
      "display_url" : "members5.boardhost.com\/medialens\/msg\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "352706937906937856",
  "text" : "Yes Scotland http:\/\/t.co\/AjNJEdr99t",
  "id" : 352706937906937856,
  "created_at" : "2013-07-04 08:34:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "indices" : [ 3, 18 ],
      "id_str" : "27716419",
      "id" : 27716419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/oD5yTSt1w8",
      "expanded_url" : "http:\/\/bit.ly\/16Qb2Kf",
      "display_url" : "bit.ly\/16Qb2Kf"
    } ]
  },
  "geo" : { },
  "id_str" : "352702983185760257",
  "text" : "RT @CraigMurrayOrg: New post: Counter-Revolution http:\/\/t.co\/oD5yTSt1w8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.craigmurray.org.uk\" rel=\"nofollow\"\u003ECraig Murray posting plugin\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 29, 51 ],
        "url" : "http:\/\/t.co\/oD5yTSt1w8",
        "expanded_url" : "http:\/\/bit.ly\/16Qb2Kf",
        "display_url" : "bit.ly\/16Qb2Kf"
      } ]
    },
    "geo" : { },
    "id_str" : "352695832816009216",
    "text" : "New post: Counter-Revolution http:\/\/t.co\/oD5yTSt1w8",
    "id" : 352695832816009216,
    "created_at" : "2013-07-04 07:50:13 +0000",
    "user" : {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "protected" : false,
      "id_str" : "27716419",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1388436826\/cm_normal.jpg",
      "id" : 27716419,
      "verified" : false
    }
  },
  "id" : 352702983185760257,
  "created_at" : "2013-07-04 08:18:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    }, {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 17, 32 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352701561073434624",
  "geo" : { },
  "id_str" : "352702598329020417",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin @MrChrisJWilson cheers mike, i do have a US niece who is 9 months old and will be seeing her 1st time in a few weeks.",
  "id" : 352702598329020417,
  "in_reply_to_status_id" : 352701561073434624,
  "created_at" : "2013-07-04 08:17:06 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/oHjwEpeOjP",
      "expanded_url" : "http:\/\/www.upi.com\/Top_News\/US\/2013\/07\/04\/US-Postal-Service-logs-all-mail-for-law-enforcement\/UPI-36491372921200\/?spt=hs&or=tn",
      "display_url" : "upi.com\/Top_News\/US\/20\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "352700582055780354",
  "text" : "U.S. Postal Service logs all mail for law enforcement http:\/\/t.co\/oHjwEpeOjP",
  "id" : 352700582055780354,
  "created_at" : "2013-07-04 08:09:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352691206792282114",
  "geo" : { },
  "id_str" : "352697127312429057",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson hehe i am guessing u dont have many US twitter folkf? or they have not woken up yet ;) watch out!",
  "id" : 352697127312429057,
  "in_reply_to_status_id" : 352691206792282114,
  "created_at" : "2013-07-04 07:55:22 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Forbes",
      "screen_name" : "GenkiSarah",
      "indices" : [ 3, 14 ],
      "id_str" : "586340658",
      "id" : 586340658
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/ftKiwihBMx",
      "expanded_url" : "http:\/\/sarahatktc.weebly.com\/1\/post\/2013\/07\/summer-madness.html",
      "display_url" : "sarahatktc.weebly.com\/1\/post\/2013\/07\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "352694043593027584",
  "text" : "RT @GenkiSarah: Summer Madness http:\/\/t.co\/ftKiwihBMx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.weebly.com\/\" rel=\"nofollow\"\u003EWeebly App\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 15, 37 ],
        "url" : "http:\/\/t.co\/ftKiwihBMx",
        "expanded_url" : "http:\/\/sarahatktc.weebly.com\/1\/post\/2013\/07\/summer-madness.html",
        "display_url" : "sarahatktc.weebly.com\/1\/post\/2013\/07\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "352686247451435008",
    "text" : "Summer Madness http:\/\/t.co\/ftKiwihBMx",
    "id" : 352686247451435008,
    "created_at" : "2013-07-04 07:12:08 +0000",
    "user" : {
      "name" : "Sarah Forbes",
      "screen_name" : "GenkiSarah",
      "protected" : false,
      "id_str" : "586340658",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2237023794\/DSCF5375_normal.JPG",
      "id" : 586340658,
      "verified" : false
    }
  },
  "id" : 352694043593027584,
  "created_at" : "2013-07-04 07:43:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/16Ddyk9tRS",
      "expanded_url" : "http:\/\/tinysubversions.com\/gengen\/gen.html?key=0ArFW2BYaBgeidHhrNVdheHlBWmF4Wm0wV2Y3WHpEbnc",
      "display_url" : "tinysubversions.com\/gengen\/gen.htm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "352544124467027969",
  "text" : "the example generator from GenGen blog post http:\/\/t.co\/16Ddyk9tRS",
  "id" : 352544124467027969,
  "created_at" : "2013-07-03 21:47:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darius Kazemi",
      "screen_name" : "tinysubversions",
      "indices" : [ 88, 104 ],
      "id_str" : "14475298",
      "id" : 14475298
    }, {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "indices" : [ 111, 124 ],
      "id_str" : "1685397408",
      "id" : 1685397408
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 125, 133 ]
    }, {
      "text" : "TESOL",
      "indices" : [ 134, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/vJKfyVj7YR",
      "expanded_url" : "https:\/\/eflnotes.wordpress.com\/2013\/07\/03\/gengen-a-tool-to-encourage-playing-with-coca\/",
      "display_url" : "eflnotes.wordpress.com\/2013\/07\/03\/gen\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "352543479374684160",
  "text" : "new post GenGen \u2013 a tool to encourage playing with COCA?\nhttps:\/\/t.co\/vJKfyVj7YR thx to @tinysubversions &amp; @harrisonmike #eltchat #TESOL",
  "id" : 352543479374684160,
  "created_at" : "2013-07-03 21:44:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darius Kazemi",
      "screen_name" : "tinysubversions",
      "indices" : [ 0, 16 ],
      "id_str" : "14475298",
      "id" : 14475298
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352535908811149312",
  "geo" : { },
  "id_str" : "352537984748355585",
  "in_reply_to_user_id" : 18602422,
  "text" : "@tinysubversions anyway to format text e.g. bold etc?",
  "id" : 352537984748355585,
  "in_reply_to_status_id" : 352535908811149312,
  "created_at" : "2013-07-03 21:23:00 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darius Kazemi",
      "screen_name" : "tinysubversions",
      "indices" : [ 0, 16 ],
      "id_str" : "14475298",
      "id" : 14475298
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352535908811149312",
  "geo" : { },
  "id_str" : "352537458463866881",
  "in_reply_to_user_id" : 18602422,
  "text" : "@tinysubversions oops sorry was entering link given by publish to web and not the url doh",
  "id" : 352537458463866881,
  "in_reply_to_status_id" : 352535908811149312,
  "created_at" : "2013-07-03 21:20:54 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darius Kazemi",
      "screen_name" : "tinysubversions",
      "indices" : [ 0, 16 ],
      "id_str" : "14475298",
      "id" : 14475298
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352520707420332032",
  "geo" : { },
  "id_str" : "352535908811149312",
  "in_reply_to_user_id" : 14475298,
  "text" : "@tinysubversions hi getting the error message Um, something went wrong...",
  "id" : 352535908811149312,
  "in_reply_to_status_id" : 352520707420332032,
  "created_at" : "2013-07-03 21:14:45 +0000",
  "in_reply_to_screen_name" : "tinysubversions",
  "in_reply_to_user_id_str" : "14475298",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boing Boing",
      "screen_name" : "BoingBoing",
      "indices" : [ 3, 14 ],
      "id_str" : "5971922",
      "id" : 5971922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/OVUlf5tOkN",
      "expanded_url" : "http:\/\/dlvr.it\/3c60qn",
      "display_url" : "dlvr.it\/3c60qn"
    } ]
  },
  "geo" : { },
  "id_str" : "352521116759232512",
  "text" : "RT @BoingBoing: The real reason Google wants to kill RSS http:\/\/t.co\/OVUlf5tOkN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/dlvr.it\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/OVUlf5tOkN",
        "expanded_url" : "http:\/\/dlvr.it\/3c60qn",
        "display_url" : "dlvr.it\/3c60qn"
      } ]
    },
    "geo" : { },
    "id_str" : "352516728917458945",
    "text" : "The real reason Google wants to kill RSS http:\/\/t.co\/OVUlf5tOkN",
    "id" : 352516728917458945,
    "created_at" : "2013-07-03 19:58:32 +0000",
    "user" : {
      "name" : "Boing Boing",
      "screen_name" : "BoingBoing",
      "protected" : false,
      "id_str" : "5971922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616924998226153472\/0EfZYjr2_normal.png",
      "id" : 5971922,
      "verified" : true
    }
  },
  "id" : 352521116759232512,
  "created_at" : "2013-07-03 20:15:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "indices" : [ 3, 18 ],
      "id_str" : "27716419",
      "id" : 27716419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/huxkEPKIx5",
      "expanded_url" : "http:\/\/bit.ly\/19WdF2w",
      "display_url" : "bit.ly\/19WdF2w"
    } ]
  },
  "geo" : { },
  "id_str" : "352444571210358785",
  "text" : "RT @CraigMurrayOrg: New post: All Law is Gone: Naked Power Remains http:\/\/t.co\/huxkEPKIx5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.craigmurray.org.uk\" rel=\"nofollow\"\u003ECraig Murray posting plugin\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 69 ],
        "url" : "http:\/\/t.co\/huxkEPKIx5",
        "expanded_url" : "http:\/\/bit.ly\/19WdF2w",
        "display_url" : "bit.ly\/19WdF2w"
      } ]
    },
    "geo" : { },
    "id_str" : "352330860046979073",
    "text" : "New post: All Law is Gone: Naked Power Remains http:\/\/t.co\/huxkEPKIx5",
    "id" : 352330860046979073,
    "created_at" : "2013-07-03 07:39:57 +0000",
    "user" : {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "protected" : false,
      "id_str" : "27716419",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1388436826\/cm_normal.jpg",
      "id" : 27716419,
      "verified" : false
    }
  },
  "id" : 352444571210358785,
  "created_at" : "2013-07-03 15:11:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adi Rajan",
      "screen_name" : "adi_rajan",
      "indices" : [ 0, 10 ],
      "id_str" : "1011323449",
      "id" : 1011323449
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352427896528310272",
  "geo" : { },
  "id_str" : "352436056513187840",
  "in_reply_to_user_id" : 1011323449,
  "text" : "@adi_rajan i liked the 'non-commital' response you gave near end of story :),did yr student recover phone?",
  "id" : 352436056513187840,
  "in_reply_to_status_id" : 352427896528310272,
  "created_at" : "2013-07-03 14:37:58 +0000",
  "in_reply_to_screen_name" : "adi_rajan",
  "in_reply_to_user_id_str" : "1011323449",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/wapCr0fmSn",
      "expanded_url" : "http:\/\/malingual.blogspot.com\/2013\/07\/kkcl-elt-podcast-or-why-ls-is-so-popular.html?spref=tw",
      "display_url" : "malingual.blogspot.com\/2013\/07\/kkcl-e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "352434199975829504",
  "text" : "Evidence Based EFL: KKCL ELT podcast or why LS is so popular http:\/\/t.co\/wapCr0fmSn",
  "id" : 352434199975829504,
  "created_at" : "2013-07-03 14:30:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate Bowles",
      "screen_name" : "KateMfD",
      "indices" : [ 3, 11 ],
      "id_str" : "379065166",
      "id" : 379065166
    }, {
      "name" : "David Kern\u24C4h\u24B6n",
      "screen_name" : "dkernohan",
      "indices" : [ 24, 34 ],
      "id_str" : "12219232",
      "id" : 12219232
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "highered",
      "indices" : [ 118, 127 ]
    }, {
      "text" : "avalanche",
      "indices" : [ 128, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/6HAjNkhHGY",
      "expanded_url" : "http:\/\/followersoftheapocalyp.se\/eighteen-percent\/",
      "display_url" : "followersoftheapocalyp.se\/eighteen-perce\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "352431371806965763",
  "text" : "RT @KateMfD: Read this: @dkernohan does the detective work on bad numbers behind bad arguments\u2014http:\/\/t.co\/6HAjNkhHGY #highered #avalanche",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "David Kern\u24C4h\u24B6n",
        "screen_name" : "dkernohan",
        "indices" : [ 11, 21 ],
        "id_str" : "12219232",
        "id" : 12219232
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "highered",
        "indices" : [ 105, 114 ]
      }, {
        "text" : "avalanche",
        "indices" : [ 115, 125 ]
      } ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/6HAjNkhHGY",
        "expanded_url" : "http:\/\/followersoftheapocalyp.se\/eighteen-percent\/",
        "display_url" : "followersoftheapocalyp.se\/eighteen-perce\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "352403724297175040",
    "text" : "Read this: @dkernohan does the detective work on bad numbers behind bad arguments\u2014http:\/\/t.co\/6HAjNkhHGY #highered #avalanche",
    "id" : 352403724297175040,
    "created_at" : "2013-07-03 12:29:29 +0000",
    "user" : {
      "name" : "Kate Bowles",
      "screen_name" : "KateMfD",
      "protected" : false,
      "id_str" : "379065166",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1557363696\/Screen_shot_2011-09-24_at_7.36.20_PM_normal.png",
      "id" : 379065166,
      "verified" : false
    }
  },
  "id" : 352431371806965763,
  "created_at" : "2013-07-03 14:19:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adi Rajan",
      "screen_name" : "adi_rajan",
      "indices" : [ 0, 10 ],
      "id_str" : "1011323449",
      "id" : 1011323449
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352426078809235456",
  "geo" : { },
  "id_str" : "352427415454220289",
  "in_reply_to_user_id" : 1011323449,
  "text" : "@adi_rajan done :)",
  "id" : 352427415454220289,
  "in_reply_to_status_id" : 352426078809235456,
  "created_at" : "2013-07-03 14:03:38 +0000",
  "in_reply_to_screen_name" : "adi_rajan",
  "in_reply_to_user_id_str" : "1011323449",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naomi Epstein",
      "screen_name" : "naomishema",
      "indices" : [ 0, 11 ],
      "id_str" : "228469472",
      "id" : 228469472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352170038993752064",
  "geo" : { },
  "id_str" : "352427293907496963",
  "in_reply_to_user_id" : 228469472,
  "text" : "@naomishema glad you got it working :)",
  "id" : 352427293907496963,
  "in_reply_to_status_id" : 352170038993752064,
  "created_at" : "2013-07-03 14:03:09 +0000",
  "in_reply_to_screen_name" : "naomishema",
  "in_reply_to_user_id_str" : "228469472",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mickey Mangan",
      "screen_name" : "mickeymangan",
      "indices" : [ 0, 13 ],
      "id_str" : "26698223",
      "id" : 26698223
    }, {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 14, 30 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352409859519561728",
  "geo" : { },
  "id_str" : "352427210054975489",
  "in_reply_to_user_id" : 26698223,
  "text" : "@mickeymangan @wordpressdotcom yeah i saw that but my twitter-fu is weak :)",
  "id" : 352427210054975489,
  "in_reply_to_status_id" : 352409859519561728,
  "created_at" : "2013-07-03 14:02:49 +0000",
  "in_reply_to_screen_name" : "mickeymangan",
  "in_reply_to_user_id_str" : "26698223",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 3, 14 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edtech",
      "indices" : [ 98, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/Ek5bcLpGh0",
      "expanded_url" : "http:\/\/bit.ly\/14PJmnl",
      "display_url" : "bit.ly\/14PJmnl"
    } ]
  },
  "geo" : { },
  "id_str" : "352390188854554624",
  "text" : "RT @tornhalves: Gavin Dudeney or Nicolas Rubashov: Who better understands the challenges posed by #edtech and the digital revolution? http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "edtech",
        "indices" : [ 82, 89 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/Ek5bcLpGh0",
        "expanded_url" : "http:\/\/bit.ly\/14PJmnl",
        "display_url" : "bit.ly\/14PJmnl"
      } ]
    },
    "geo" : { },
    "id_str" : "352359874698543105",
    "text" : "Gavin Dudeney or Nicolas Rubashov: Who better understands the challenges posed by #edtech and the digital revolution? http:\/\/t.co\/Ek5bcLpGh0",
    "id" : 352359874698543105,
    "created_at" : "2013-07-03 09:35:15 +0000",
    "user" : {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "protected" : false,
      "id_str" : "87902543",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3059742703\/1d3c7a2052db17d29644fa0a49af6480_normal.jpeg",
      "id" : 87902543,
      "verified" : false
    }
  },
  "id" : 352390188854554624,
  "created_at" : "2013-07-03 11:35:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 80, 96 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/rGOXHtuvpF",
      "expanded_url" : "http:\/\/wp.me\/p1CmXJ-gn",
      "display_url" : "wp.me\/p1CmXJ-gn"
    } ]
  },
  "geo" : { },
  "id_str" : "352384446789459971",
  "text" : "The Lernen to Talk Show: Episode 51 - DRadio Wissen! http:\/\/t.co\/rGOXHtuvpF via @wordpressdotcom&lt;a German learner finds saying French funny",
  "id" : 352384446789459971,
  "created_at" : "2013-07-03 11:12:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemma Lunn",
      "screen_name" : "GemL1",
      "indices" : [ 0, 6 ],
      "id_str" : "486146568",
      "id" : 486146568
    }, {
      "name" : "Swan Dos santos",
      "screen_name" : "SwanDos",
      "indices" : [ 7, 15 ],
      "id_str" : "4025199586",
      "id" : 4025199586
    }, {
      "name" : "Anne Hodgson",
      "screen_name" : "annehodg",
      "indices" : [ 52, 61 ],
      "id_str" : "17589213",
      "id" : 17589213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/GJsYIG9042",
      "expanded_url" : "http:\/\/annehodgson.de\/2013\/06\/28\/brene-brown-the-power-of-vulnerability\/",
      "display_url" : "annehodgson.de\/2013\/06\/28\/bre\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "352367147437137922",
  "geo" : { },
  "id_str" : "352380785778634752",
  "in_reply_to_user_id" : 486146568,
  "text" : "@GemL1 @SwanDOS this post http:\/\/t.co\/GJsYIG9042 by @annehodg complements very nicely",
  "id" : 352380785778634752,
  "in_reply_to_status_id" : 352367147437137922,
  "created_at" : "2013-07-03 10:58:20 +0000",
  "in_reply_to_screen_name" : "GemL1",
  "in_reply_to_user_id_str" : "486146568",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evgeny Morozov",
      "screen_name" : "evgenymorozov",
      "indices" : [ 3, 17 ],
      "id_str" : "30331417",
      "id" : 30331417
    }, {
      "name" : "Boston Review",
      "screen_name" : "BostonReview",
      "indices" : [ 86, 99 ],
      "id_str" : "36969470",
      "id" : 36969470
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/vQRSY1HLti",
      "expanded_url" : "https:\/\/www.bostonreview.net\/books-ideas\/whats-wrong-technological-fixes",
      "display_url" : "bostonreview.net\/books-ideas\/wh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "352066992783634432",
  "text" : "RT @evgenymorozov: In case you missed it yesterday: Terry Winograd interviewed me for @BostonReview https:\/\/t.co\/vQRSY1HLti",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Boston Review",
        "screen_name" : "BostonReview",
        "indices" : [ 67, 80 ],
        "id_str" : "36969470",
        "id" : 36969470
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/vQRSY1HLti",
        "expanded_url" : "https:\/\/www.bostonreview.net\/books-ideas\/whats-wrong-technological-fixes",
        "display_url" : "bostonreview.net\/books-ideas\/wh\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "352060916168261632",
    "text" : "In case you missed it yesterday: Terry Winograd interviewed me for @BostonReview https:\/\/t.co\/vQRSY1HLti",
    "id" : 352060916168261632,
    "created_at" : "2013-07-02 13:47:18 +0000",
    "user" : {
      "name" : "Evgeny Morozov",
      "screen_name" : "evgenymorozov",
      "protected" : false,
      "id_str" : "30331417",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/640536915477794816\/u9TxNsKI_normal.jpg",
      "id" : 30331417,
      "verified" : false
    }
  },
  "id" : 352066992783634432,
  "created_at" : "2013-07-02 14:11:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Willingham",
      "screen_name" : "DTWillingham",
      "indices" : [ 3, 16 ],
      "id_str" : "84619537",
      "id" : 84619537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/c3tPxkvNRe",
      "expanded_url" : "http:\/\/psycnet.apa.org\/psycinfo\/2013-22764-001\/",
      "display_url" : "psycnet.apa.org\/psycinfo\/2013-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "352056365100957696",
  "text" : "RT @DTWillingham: Covert retrieval practice aids memory as much as overt does http:\/\/t.co\/c3tPxkvNRe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/c3tPxkvNRe",
        "expanded_url" : "http:\/\/psycnet.apa.org\/psycinfo\/2013-22764-001\/",
        "display_url" : "psycnet.apa.org\/psycinfo\/2013-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "352044189220995073",
    "text" : "Covert retrieval practice aids memory as much as overt does http:\/\/t.co\/c3tPxkvNRe",
    "id" : 352044189220995073,
    "created_at" : "2013-07-02 12:40:50 +0000",
    "user" : {
      "name" : "Daniel Willingham",
      "screen_name" : "DTWillingham",
      "protected" : false,
      "id_str" : "84619537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1815678310\/Daniel_Willingham_Color_lowres_normal.JPG",
      "id" : 84619537,
      "verified" : false
    }
  },
  "id" : 352056365100957696,
  "created_at" : "2013-07-02 13:29:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WikiLeaks",
      "screen_name" : "wikileaks",
      "indices" : [ 3, 13 ],
      "id_str" : "16589206",
      "id" : 16589206
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "snowden",
      "indices" : [ 79, 87 ]
    }, {
      "text" : "wikileaks",
      "indices" : [ 88, 98 ]
    }, {
      "text" : "nsa",
      "indices" : [ 99, 103 ]
    }, {
      "text" : "prism",
      "indices" : [ 104, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/aDKgLy1xya",
      "expanded_url" : "http:\/\/wikileaks.org\/Statement-from-Edward-Snowden-in.html?snow",
      "display_url" : "wikileaks.org\/Statement-from\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "352055013931102208",
  "text" : "RT @wikileaks: STATEMENT: by Edward Snowden from Moscow http:\/\/t.co\/aDKgLy1xya #snowden #wikileaks #nsa #prism",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "snowden",
        "indices" : [ 64, 72 ]
      }, {
        "text" : "wikileaks",
        "indices" : [ 73, 83 ]
      }, {
        "text" : "nsa",
        "indices" : [ 84, 88 ]
      }, {
        "text" : "prism",
        "indices" : [ 89, 95 ]
      } ],
      "urls" : [ {
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/aDKgLy1xya",
        "expanded_url" : "http:\/\/wikileaks.org\/Statement-from-Edward-Snowden-in.html?snow",
        "display_url" : "wikileaks.org\/Statement-from\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "351823566435655681",
    "text" : "STATEMENT: by Edward Snowden from Moscow http:\/\/t.co\/aDKgLy1xya #snowden #wikileaks #nsa #prism",
    "id" : 351823566435655681,
    "created_at" : "2013-07-01 22:04:09 +0000",
    "user" : {
      "name" : "WikiLeaks",
      "screen_name" : "wikileaks",
      "protected" : false,
      "id_str" : "16589206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/512138307870785536\/Fe00yVS2_normal.png",
      "id" : 16589206,
      "verified" : true
    }
  },
  "id" : 352055013931102208,
  "created_at" : "2013-07-02 13:23:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/1CE6a7Jpm6",
      "expanded_url" : "http:\/\/freerangekef.blogspot.com\/2013\/07\/individual-words.html?spref=tw",
      "display_url" : "freerangekef.blogspot.com\/2013\/07\/indivi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "352052179890225152",
  "text" : "Free-Range ELT: Individual Words http:\/\/t.co\/1CE6a7Jpm6",
  "id" : 352052179890225152,
  "created_at" : "2013-07-02 13:12:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naomi Epstein",
      "screen_name" : "naomishema",
      "indices" : [ 0, 11 ],
      "id_str" : "228469472",
      "id" : 228469472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352041608952283138",
  "geo" : { },
  "id_str" : "352052129319497728",
  "in_reply_to_user_id" : 228469472,
  "text" : "@naomishema hmm  i guess a net search for info using your phone model and symptoms would be best bet?",
  "id" : 352052129319497728,
  "in_reply_to_status_id" : 352041608952283138,
  "created_at" : "2013-07-02 13:12:23 +0000",
  "in_reply_to_screen_name" : "naomishema",
  "in_reply_to_user_id_str" : "228469472",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yolanda B. Schell",
      "screen_name" : "mattellman",
      "indices" : [ 3, 14 ],
      "id_str" : "725597315860434945",
      "id" : 725597315860434945
    }, {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 83, 94 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELT",
      "indices" : [ 118, 122 ]
    }, {
      "text" : "ESL",
      "indices" : [ 123, 127 ]
    }, {
      "text" : "EFL",
      "indices" : [ 128, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/bDmF3KIcnl",
      "expanded_url" : "http:\/\/leoxicon.blogspot.co.uk\/2013\/07\/it-doesnt-matter.html",
      "display_url" : "leoxicon.blogspot.co.uk\/2013\/07\/it-doe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "352005536964816898",
  "text" : "RT @mattellman: Do your students often say \"it's depend...\"? Useful exercises from @leoselivan http:\/\/t.co\/bDmF3KIcnl #ELT #ESL #EFL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/janetter.net\/\" rel=\"nofollow\"\u003EJanetter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lexical Leo",
        "screen_name" : "leoselivan",
        "indices" : [ 67, 78 ],
        "id_str" : "408365496",
        "id" : 408365496
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELT",
        "indices" : [ 102, 106 ]
      }, {
        "text" : "ESL",
        "indices" : [ 107, 111 ]
      }, {
        "text" : "EFL",
        "indices" : [ 112, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/bDmF3KIcnl",
        "expanded_url" : "http:\/\/leoxicon.blogspot.co.uk\/2013\/07\/it-doesnt-matter.html",
        "display_url" : "leoxicon.blogspot.co.uk\/2013\/07\/it-doe\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "351947070141251585",
    "text" : "Do your students often say \"it's depend...\"? Useful exercises from @leoselivan http:\/\/t.co\/bDmF3KIcnl #ELT #ESL #EFL",
    "id" : 351947070141251585,
    "created_at" : "2013-07-02 06:14:55 +0000",
    "user" : {
      "name" : "Matthew Ellman",
      "screen_name" : "MatthewEllman",
      "protected" : false,
      "id_str" : "394987109",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1615371192\/classpic_normal.jpg",
      "id" : 394987109,
      "verified" : false
    }
  },
  "id" : 352005536964816898,
  "created_at" : "2013-07-02 10:07:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naomi Epstein",
      "screen_name" : "naomishema",
      "indices" : [ 0, 11 ],
      "id_str" : "228469472",
      "id" : 228469472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352000436632420352",
  "geo" : { },
  "id_str" : "352005369821794304",
  "in_reply_to_user_id" : 228469472,
  "text" : "@naomishema have you enabled usb sharing frm phone? also may need to install drivers for it?",
  "id" : 352005369821794304,
  "in_reply_to_status_id" : 352000436632420352,
  "created_at" : "2013-07-02 10:06:34 +0000",
  "in_reply_to_screen_name" : "naomishema",
  "in_reply_to_user_id_str" : "228469472",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 113, 121 ]
    }, {
      "text" : "tesol",
      "indices" : [ 122, 128 ]
    }, {
      "text" : "toeic",
      "indices" : [ 129, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/QhESS7oVvs",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-Eu",
      "display_url" : "wp.me\/pgHyE-Eu"
    } ]
  },
  "geo" : { },
  "id_str" : "352004904535064577",
  "text" : "Just the Word - alternatives function \nor how to introduce concordances to your students. http:\/\/t.co\/QhESS7oVvs #eltchat #tesol #toeic",
  "id" : 352004904535064577,
  "created_at" : "2013-07-02 10:04:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim George",
      "screen_name" : "oyajimbo",
      "indices" : [ 3, 12 ],
      "id_str" : "96103979",
      "id" : 96103979
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/AHJs8q8xs4",
      "expanded_url" : "http:\/\/twy.la\/16JeQgk",
      "display_url" : "twy.la\/16JeQgk"
    } ]
  },
  "geo" : { },
  "id_str" : "351610806770745345",
  "text" : "RT @oyajimbo: A Useful Twitter Advanced Search Sheet for Teachers ~ Educational Technology and Mobile Learning http:\/\/t.co\/AHJs8q8xs4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twylah.com\" rel=\"nofollow\"\u003ETwylah\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/AHJs8q8xs4",
        "expanded_url" : "http:\/\/twy.la\/16JeQgk",
        "display_url" : "twy.la\/16JeQgk"
      } ]
    },
    "geo" : { },
    "id_str" : "351604208753065984",
    "text" : "A Useful Twitter Advanced Search Sheet for Teachers ~ Educational Technology and Mobile Learning http:\/\/t.co\/AHJs8q8xs4",
    "id" : 351604208753065984,
    "created_at" : "2013-07-01 07:32:30 +0000",
    "user" : {
      "name" : "Jim George",
      "screen_name" : "oyajimbo",
      "protected" : false,
      "id_str" : "96103979",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1154960940\/JIM_agata_normal.jpg",
      "id" : 96103979,
      "verified" : false
    }
  },
  "id" : 351610806770745345,
  "created_at" : "2013-07-01 07:58:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
} ]