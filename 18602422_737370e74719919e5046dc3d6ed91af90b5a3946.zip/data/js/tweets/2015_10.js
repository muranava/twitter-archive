Grailbird.data.tweets_2015_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/G560Ro4UmB",
      "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2015\/10\/sick-wogs-cough-up.html",
      "display_url" : "thecurmudgeonly.blogspot.co.uk\/2015\/10\/sick-w\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "660417504783826944",
  "text" : "RT @pchallinor: New mudgeonry: Sick wogs cough up https:\/\/t.co\/G560Ro4UmB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 34, 57 ],
        "url" : "https:\/\/t.co\/G560Ro4UmB",
        "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2015\/10\/sick-wogs-cough-up.html",
        "display_url" : "thecurmudgeonly.blogspot.co.uk\/2015\/10\/sick-w\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "660415533494484992",
    "text" : "New mudgeonry: Sick wogs cough up https:\/\/t.co\/G560Ro4UmB",
    "id" : 660415533494484992,
    "created_at" : "2015-10-31 11:18:27 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 660417504783826944,
  "created_at" : "2015-10-31 11:26:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Chesnut",
      "screen_name" : "MichaelChesnut2",
      "indices" : [ 0, 16 ],
      "id_str" : "820940430",
      "id" : 820940430
    }, {
      "name" : "Nicola Prentis",
      "screen_name" : "NicolaPrentis",
      "indices" : [ 17, 31 ],
      "id_str" : "810667033",
      "id" : 810667033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/2avPLuStud",
      "expanded_url" : "http:\/\/bookworm.benschmidt.org\/posts\/2015-10-30-rejecting-the-gender-binary.html",
      "display_url" : "bookworm.benschmidt.org\/posts\/2015-10-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "660377083269414912",
  "geo" : { },
  "id_str" : "660408753087455236",
  "in_reply_to_user_id" : 820940430,
  "text" : "@MichaelChesnut2 @NicolaPrentis u should check his latest analysis amazing https:\/\/t.co\/2avPLuStud",
  "id" : 660408753087455236,
  "in_reply_to_status_id" : 660377083269414912,
  "created_at" : "2015-10-31 10:51:31 +0000",
  "in_reply_to_screen_name" : "MichaelChesnut2",
  "in_reply_to_user_id_str" : "820940430",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kim Sydow Campbell",
      "screen_name" : "_dr_kim_",
      "indices" : [ 66, 75 ],
      "id_str" : "364412485",
      "id" : 364412485
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/qbIGfdRnC2",
      "expanded_url" : "http:\/\/wp.me\/p2upSM-1H4",
      "display_url" : "wp.me\/p2upSM-1H4"
    } ]
  },
  "geo" : { },
  "id_str" : "660199753695821825",
  "text" : "Readers label you based on your style https:\/\/t.co\/qbIGfdRnC2 via @_dr_kim_",
  "id" : 660199753695821825,
  "created_at" : "2015-10-30 21:01:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyler Schnoebelen",
      "screen_name" : "TSchnoebelen",
      "indices" : [ 3, 16 ],
      "id_str" : "14969147",
      "id" : 14969147
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/ZHbJIt0Z84",
      "expanded_url" : "http:\/\/idibon.com\/intensity-in-consumer-complaints-about-banks\/",
      "display_url" : "idibon.com\/intensity-in-c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "660143979267125249",
  "text" : "RT @TSchnoebelen: A bit on the language of complaints: intensifiers and financial service complaints https:\/\/t.co\/ZHbJIt0Z84",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/ZHbJIt0Z84",
        "expanded_url" : "http:\/\/idibon.com\/intensity-in-consumer-complaints-about-banks\/",
        "display_url" : "idibon.com\/intensity-in-c\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "660140175259922432",
    "text" : "A bit on the language of complaints: intensifiers and financial service complaints https:\/\/t.co\/ZHbJIt0Z84",
    "id" : 660140175259922432,
    "created_at" : "2015-10-30 17:04:17 +0000",
    "user" : {
      "name" : "Tyler Schnoebelen",
      "screen_name" : "TSchnoebelen",
      "protected" : false,
      "id_str" : "14969147",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/604427674203779072\/Y4t_NODB_normal.jpg",
      "id" : 14969147,
      "verified" : false
    }
  },
  "id" : 660143979267125249,
  "created_at" : "2015-10-30 17:19:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon H",
      "screen_name" : "ruchbah",
      "indices" : [ 17, 25 ],
      "id_str" : "2167401",
      "id" : 2167401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "660100514080808960",
  "text" : "RT @DeanFrenkel: @ruchbah Gee thanks Jon H. Are you one of those linguists who wish for the power to control the agenda?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jon H",
        "screen_name" : "ruchbah",
        "indices" : [ 0, 8 ],
        "id_str" : "2167401",
        "id" : 2167401
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "659807456445538304",
    "geo" : { },
    "id_str" : "659846725335543808",
    "in_reply_to_user_id" : 2167401,
    "text" : "@ruchbah Gee thanks Jon H. Are you one of those linguists who wish for the power to control the agenda?",
    "id" : 659846725335543808,
    "in_reply_to_status_id" : 659807456445538304,
    "created_at" : "2015-10-29 21:38:13 +0000",
    "in_reply_to_screen_name" : "ruchbah",
    "in_reply_to_user_id_str" : "2167401",
    "user" : {
      "name" : "Dean Frenkel",
      "screen_name" : "FrenklySpeaking",
      "protected" : false,
      "id_str" : "33190984",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/473033424886693888\/KToxNCMm_normal.jpeg",
      "id" : 33190984,
      "verified" : false
    }
  },
  "id" : 660100514080808960,
  "created_at" : "2015-10-30 14:26:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Crystal",
      "screen_name" : "davcr",
      "indices" : [ 3, 9 ],
      "id_str" : "37702831",
      "id" : 37702831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/KcarFQRu2p",
      "expanded_url" : "http:\/\/david-crystal.blogspot.co.uk\/2015\/10\/on-one-word-reaction-to-reports-about.html",
      "display_url" : "david-crystal.blogspot.co.uk\/2015\/10\/on-one\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "660093626907774976",
  "text" : "RT @davcr: Dragged out of blog seclusion because of the awful Aussie story circulating this week: https:\/\/t.co\/KcarFQRu2p",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/KcarFQRu2p",
        "expanded_url" : "http:\/\/david-crystal.blogspot.co.uk\/2015\/10\/on-one-word-reaction-to-reports-about.html",
        "display_url" : "david-crystal.blogspot.co.uk\/2015\/10\/on-one\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "660037751061020672",
    "text" : "Dragged out of blog seclusion because of the awful Aussie story circulating this week: https:\/\/t.co\/KcarFQRu2p",
    "id" : 660037751061020672,
    "created_at" : "2015-10-30 10:17:17 +0000",
    "user" : {
      "name" : "David Crystal",
      "screen_name" : "davcr",
      "protected" : false,
      "id_str" : "37702831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2172268605\/DClibrary_India_normal.jpg",
      "id" : 37702831,
      "verified" : false
    }
  },
  "id" : 660093626907774976,
  "created_at" : "2015-10-30 13:59:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alison Phipps",
      "screen_name" : "alisonphipps",
      "indices" : [ 3, 16 ],
      "id_str" : "215588549",
      "id" : 215588549
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/alisonphipps\/status\/659724909287993344\/photo\/1",
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/z7mYYPq2bI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSfQTxDXAAALIJR.jpg",
      "id_str" : "659724908436586496",
      "id" : 659724908436586496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSfQTxDXAAALIJR.jpg",
      "sizes" : [ {
        "h" : 395,
        "resize" : "fit",
        "w" : 534
      }, {
        "h" : 251,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 395,
        "resize" : "fit",
        "w" : 534
      }, {
        "h" : 395,
        "resize" : "fit",
        "w" : 534
      } ],
      "display_url" : "pic.twitter.com\/z7mYYPq2bI"
    } ],
    "hashtags" : [ {
      "text" : "prevent",
      "indices" : [ 84, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "660075749844639744",
  "text" : "RT @alisonphipps: Letter just sent to my son's nursery about their participation in #prevent https:\/\/t.co\/z7mYYPq2bI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/alisonphipps\/status\/659724909287993344\/photo\/1",
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/z7mYYPq2bI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSfQTxDXAAALIJR.jpg",
        "id_str" : "659724908436586496",
        "id" : 659724908436586496,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSfQTxDXAAALIJR.jpg",
        "sizes" : [ {
          "h" : 395,
          "resize" : "fit",
          "w" : 534
        }, {
          "h" : 251,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 395,
          "resize" : "fit",
          "w" : 534
        }, {
          "h" : 395,
          "resize" : "fit",
          "w" : 534
        } ],
        "display_url" : "pic.twitter.com\/z7mYYPq2bI"
      } ],
      "hashtags" : [ {
        "text" : "prevent",
        "indices" : [ 66, 74 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "659724909287993344",
    "text" : "Letter just sent to my son's nursery about their participation in #prevent https:\/\/t.co\/z7mYYPq2bI",
    "id" : 659724909287993344,
    "created_at" : "2015-10-29 13:34:10 +0000",
    "user" : {
      "name" : "Alison Phipps",
      "screen_name" : "alisonphipps",
      "protected" : false,
      "id_str" : "215588549",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762929359082708992\/oOcTf3Te_normal.jpg",
      "id" : 215588549,
      "verified" : false
    }
  },
  "id" : 660075749844639744,
  "created_at" : "2015-10-30 12:48:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Poole",
      "screen_name" : "RobertEPoole",
      "indices" : [ 3, 16 ],
      "id_str" : "18526186",
      "id" : 18526186
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 140 ],
      "url" : "https:\/\/t.co\/ikvDIAf48A",
      "expanded_url" : "http:\/\/www.webcorp.org.uk\/live\/index.jsp",
      "display_url" : "webcorp.org.uk\/live\/index.jsp"
    } ]
  },
  "geo" : { },
  "id_str" : "659751137424384000",
  "text" : "RT @RobertEPoole: A new-to-me and perhaps new-to-you corpus tool. Feature I like: enter website URL and get freq list. https:\/\/t.co\/ikvDIAf\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/ikvDIAf48A",
        "expanded_url" : "http:\/\/www.webcorp.org.uk\/live\/index.jsp",
        "display_url" : "webcorp.org.uk\/live\/index.jsp"
      } ]
    },
    "geo" : { },
    "id_str" : "659729443829616640",
    "text" : "A new-to-me and perhaps new-to-you corpus tool. Feature I like: enter website URL and get freq list. https:\/\/t.co\/ikvDIAf48A",
    "id" : 659729443829616640,
    "created_at" : "2015-10-29 13:52:11 +0000",
    "user" : {
      "name" : "Robert Poole",
      "screen_name" : "RobertEPoole",
      "protected" : false,
      "id_str" : "18526186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/586985086073069568\/UbAcX_I3_normal.jpg",
      "id" : 18526186,
      "verified" : false
    }
  },
  "id" : 659751137424384000,
  "created_at" : "2015-10-29 15:18:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donald Clark",
      "screen_name" : "DonaldClark",
      "indices" : [ 3, 15 ],
      "id_str" : "1632891",
      "id" : 1632891
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/DonaldClark\/status\/659706919674859520\/photo\/1",
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/6tZ6GhAjOF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSe_8oMWcAAciWO.jpg",
      "id_str" : "659706918735343616",
      "id" : 659706918735343616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSe_8oMWcAAciWO.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 388,
        "resize" : "fit",
        "w" : 582
      }, {
        "h" : 388,
        "resize" : "fit",
        "w" : 582
      }, {
        "h" : 388,
        "resize" : "fit",
        "w" : 582
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/6tZ6GhAjOF"
    } ],
    "hashtags" : [ {
      "text" : "wired",
      "indices" : [ 70, 76 ]
    }, {
      "text" : "edtech",
      "indices" : [ 77, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/TpJuBZIhNs",
      "expanded_url" : "http:\/\/bit.ly\/1O9F4BU",
      "display_url" : "bit.ly\/1O9F4BU"
    } ]
  },
  "geo" : { },
  "id_str" : "659750228115988480",
  "text" : "RT @DonaldClark: Mitra\u2019s SOLE \u2013 10 reasons why it is \u2018not even wrong\u2019 #wired #edtech https:\/\/t.co\/TpJuBZIhNs https:\/\/t.co\/6tZ6GhAjOF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/DonaldClark\/status\/659706919674859520\/photo\/1",
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/6tZ6GhAjOF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSe_8oMWcAAciWO.jpg",
        "id_str" : "659706918735343616",
        "id" : 659706918735343616,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSe_8oMWcAAciWO.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 388,
          "resize" : "fit",
          "w" : 582
        }, {
          "h" : 388,
          "resize" : "fit",
          "w" : 582
        }, {
          "h" : 388,
          "resize" : "fit",
          "w" : 582
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/6tZ6GhAjOF"
      } ],
      "hashtags" : [ {
        "text" : "wired",
        "indices" : [ 53, 59 ]
      }, {
        "text" : "edtech",
        "indices" : [ 60, 67 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/TpJuBZIhNs",
        "expanded_url" : "http:\/\/bit.ly\/1O9F4BU",
        "display_url" : "bit.ly\/1O9F4BU"
      } ]
    },
    "geo" : { },
    "id_str" : "659706919674859520",
    "text" : "Mitra\u2019s SOLE \u2013 10 reasons why it is \u2018not even wrong\u2019 #wired #edtech https:\/\/t.co\/TpJuBZIhNs https:\/\/t.co\/6tZ6GhAjOF",
    "id" : 659706919674859520,
    "created_at" : "2015-10-29 12:22:41 +0000",
    "user" : {
      "name" : "Donald Clark",
      "screen_name" : "DonaldClark",
      "protected" : false,
      "id_str" : "1632891",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/513085530695663616\/BfWK4n6u_normal.jpeg",
      "id" : 1632891,
      "verified" : false
    }
  },
  "id" : 659750228115988480,
  "created_at" : "2015-10-29 15:14:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    }, {
      "name" : "MSF International",
      "screen_name" : "MSF",
      "indices" : [ 82, 86 ],
      "id_str" : "2195671183",
      "id" : 2195671183
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/medialens\/status\/659312256849678336\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/bEGr0OaWi6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSZZAOSWoAACK0n.jpg",
      "id_str" : "659312255826305024",
      "id" : 659312255826305024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSZZAOSWoAACK0n.jpg",
      "sizes" : [ {
        "h" : 370,
        "resize" : "fit",
        "w" : 708
      }, {
        "h" : 178,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 314,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 370,
        "resize" : "fit",
        "w" : 708
      } ],
      "display_url" : "pic.twitter.com\/bEGr0OaWi6"
    } ],
    "hashtags" : [ {
      "text" : "Kunduz",
      "indices" : [ 87, 94 ]
    }, {
      "text" : "WarCrime",
      "indices" : [ 95, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/7786CaaUMq",
      "expanded_url" : "http:\/\/www.medialens.org\/index.php\/alerts\/alert-archive\/2015\/805-i-would-have-refused-such-an-order-former-raf-pilot-gives-his-view-of-us-bombing-of-msf-hospital-in-kunduz.html",
      "display_url" : "medialens.org\/index.php\/aler\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "659463983733284864",
  "text" : "RT @medialens: 'U.S. forces destroyed what they knew was a functioning hospital'. @MSF #Kunduz #WarCrime https:\/\/t.co\/7786CaaUMq https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "MSF International",
        "screen_name" : "MSF",
        "indices" : [ 67, 71 ],
        "id_str" : "2195671183",
        "id" : 2195671183
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/medialens\/status\/659312256849678336\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/bEGr0OaWi6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSZZAOSWoAACK0n.jpg",
        "id_str" : "659312255826305024",
        "id" : 659312255826305024,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSZZAOSWoAACK0n.jpg",
        "sizes" : [ {
          "h" : 370,
          "resize" : "fit",
          "w" : 708
        }, {
          "h" : 178,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 314,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 370,
          "resize" : "fit",
          "w" : 708
        } ],
        "display_url" : "pic.twitter.com\/bEGr0OaWi6"
      } ],
      "hashtags" : [ {
        "text" : "Kunduz",
        "indices" : [ 72, 79 ]
      }, {
        "text" : "WarCrime",
        "indices" : [ 80, 89 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/7786CaaUMq",
        "expanded_url" : "http:\/\/www.medialens.org\/index.php\/alerts\/alert-archive\/2015\/805-i-would-have-refused-such-an-order-former-raf-pilot-gives-his-view-of-us-bombing-of-msf-hospital-in-kunduz.html",
        "display_url" : "medialens.org\/index.php\/aler\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "659312256849678336",
    "text" : "'U.S. forces destroyed what they knew was a functioning hospital'. @MSF #Kunduz #WarCrime https:\/\/t.co\/7786CaaUMq https:\/\/t.co\/bEGr0OaWi6",
    "id" : 659312256849678336,
    "created_at" : "2015-10-28 10:14:26 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 659463983733284864,
  "created_at" : "2015-10-28 20:17:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenys Hanson",
      "screen_name" : "GlenysHanson",
      "indices" : [ 0, 13 ],
      "id_str" : "527238447",
      "id" : 527238447
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "659131115870011392",
  "geo" : { },
  "id_str" : "659141117536030720",
  "in_reply_to_user_id" : 527238447,
  "text" : "@GlenysHanson ha \"recent\" in publishing terms? Pullam has a nice steely edged line in \"folk who don't know what they are talking about\" : )",
  "id" : 659141117536030720,
  "in_reply_to_status_id" : 659131115870011392,
  "created_at" : "2015-10-27 22:54:23 +0000",
  "in_reply_to_screen_name" : "GlenysHanson",
  "in_reply_to_user_id_str" : "527238447",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 67, 83 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/4fdg9jC1l2",
      "expanded_url" : "http:\/\/wp.me\/pglsT-5AT",
      "display_url" : "wp.me\/pglsT-5AT"
    } ]
  },
  "geo" : { },
  "id_str" : "659119022374526977",
  "text" : "Fear and loathing of the passive voice https:\/\/t.co\/4fdg9jC1l2 via @wordpressdotcom",
  "id" : 659119022374526977,
  "created_at" : "2015-10-27 21:26:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Rayson",
      "screen_name" : "perayson",
      "indices" : [ 0, 9 ],
      "id_str" : "263108959",
      "id" : 263108959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "659114624621674500",
  "geo" : { },
  "id_str" : "659116186471370753",
  "in_reply_to_user_id" : 263108959,
  "text" : "@perayson great thanks!",
  "id" : 659116186471370753,
  "in_reply_to_status_id" : 659114624621674500,
  "created_at" : "2015-10-27 21:15:19 +0000",
  "in_reply_to_screen_name" : "perayson",
  "in_reply_to_user_id_str" : "263108959",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Rayson",
      "screen_name" : "perayson",
      "indices" : [ 0, 9 ],
      "id_str" : "263108959",
      "id" : 263108959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659079826637266944",
  "in_reply_to_user_id" : 263108959,
  "text" : "@perayson hi Paul is the MWE function in wmatrix an ngram extractor or something else? thx",
  "id" : 659079826637266944,
  "created_at" : "2015-10-27 18:50:50 +0000",
  "in_reply_to_screen_name" : "perayson",
  "in_reply_to_user_id_str" : "263108959",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 3, 14 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "activelearning",
      "indices" : [ 16, 31 ]
    }, {
      "text" : "education",
      "indices" : [ 82, 92 ]
    }, {
      "text" : "pedagogy",
      "indices" : [ 108, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/WJISsyH35D",
      "expanded_url" : "http:\/\/bit.ly\/1ic6WHa",
      "display_url" : "bit.ly\/1ic6WHa"
    } ]
  },
  "geo" : { },
  "id_str" : "659037205759926272",
  "text" : "RT @tornhalves: #activelearning reconsidered - why the bad press for passivity in #education ? Wordsworth's #pedagogy was onto sthg. https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "activelearning",
        "indices" : [ 0, 15 ]
      }, {
        "text" : "education",
        "indices" : [ 66, 76 ]
      }, {
        "text" : "pedagogy",
        "indices" : [ 92, 101 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/WJISsyH35D",
        "expanded_url" : "http:\/\/bit.ly\/1ic6WHa",
        "display_url" : "bit.ly\/1ic6WHa"
      } ]
    },
    "geo" : { },
    "id_str" : "658939088515526656",
    "text" : "#activelearning reconsidered - why the bad press for passivity in #education ? Wordsworth's #pedagogy was onto sthg. https:\/\/t.co\/WJISsyH35D",
    "id" : 658939088515526656,
    "created_at" : "2015-10-27 09:31:35 +0000",
    "user" : {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "protected" : false,
      "id_str" : "87902543",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3059742703\/1d3c7a2052db17d29644fa0a49af6480_normal.jpeg",
      "id" : 87902543,
      "verified" : false
    }
  },
  "id" : 659037205759926272,
  "created_at" : "2015-10-27 16:01:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicola Prentis",
      "screen_name" : "NicolaPrentis",
      "indices" : [ 76, 90 ],
      "id_str" : "810667033",
      "id" : 810667033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/H17ER06Liy",
      "expanded_url" : "http:\/\/wp.me\/p1RJaO-lsy",
      "display_url" : "wp.me\/p1RJaO-lsy"
    } ]
  },
  "geo" : { },
  "id_str" : "658992880841789440",
  "text" : "New English File Intermediate - Reverse Reading https:\/\/t.co\/H17ER06Liy via @NicolaPrentis",
  "id" : 658992880841789440,
  "created_at" : "2015-10-27 13:05:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/cmpLpTtVxi",
      "expanded_url" : "http:\/\/www.newstatesman.com\/politics\/feminism\/2015\/10\/problem-men-participating-feminism-there-no-risk-plenty-glory",
      "display_url" : "newstatesman.com\/politics\/femin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "658646855421706244",
  "text" : "RT @pchallinor: If you're male and call yourself a feminist, you ought to be ashamed of yourself https:\/\/t.co\/cmpLpTtVxi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/cmpLpTtVxi",
        "expanded_url" : "http:\/\/www.newstatesman.com\/politics\/feminism\/2015\/10\/problem-men-participating-feminism-there-no-risk-plenty-glory",
        "display_url" : "newstatesman.com\/politics\/femin\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "658646110014185472",
    "text" : "If you're male and call yourself a feminist, you ought to be ashamed of yourself https:\/\/t.co\/cmpLpTtVxi",
    "id" : 658646110014185472,
    "created_at" : "2015-10-26 14:07:24 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 658646855421706244,
  "created_at" : "2015-10-26 14:10:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bansi Kara",
      "screen_name" : "benniekara",
      "indices" : [ 0, 11 ],
      "id_str" : "36195821",
      "id" : 36195821
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "658630146954387457",
  "geo" : { },
  "id_str" : "658633820883787776",
  "in_reply_to_user_id" : 36195821,
  "text" : "@benniekara yr welcome, thx for heads up of the miss representation film",
  "id" : 658633820883787776,
  "in_reply_to_status_id" : 658630146954387457,
  "created_at" : "2015-10-26 13:18:34 +0000",
  "in_reply_to_screen_name" : "benniekara",
  "in_reply_to_user_id_str" : "36195821",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bansi Kara",
      "screen_name" : "benniekara",
      "indices" : [ 83, 94 ],
      "id_str" : "36195821",
      "id" : 36195821
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/5CaRR95TF4",
      "expanded_url" : "http:\/\/wp.me\/pYxLg-5h",
      "display_url" : "wp.me\/pYxLg-5h"
    } ]
  },
  "geo" : { },
  "id_str" : "658629179773165568",
  "text" : "I Must Have Blinked: Gender Inequality Is Over, Right? https:\/\/t.co\/5CaRR95TF4 via @benniekara",
  "id" : 658629179773165568,
  "created_at" : "2015-10-26 13:00:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicola Prentis",
      "screen_name" : "NicolaPrentis",
      "indices" : [ 3, 17 ],
      "id_str" : "810667033",
      "id" : 810667033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "womeninELT",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/Jbpg5IhM2u",
      "expanded_url" : "http:\/\/wp.me\/p1RJaO-lsu",
      "display_url" : "wp.me\/p1RJaO-lsu"
    } ]
  },
  "geo" : { },
  "id_str" : "658628741044793349",
  "text" : "RT @NicolaPrentis: Nice mix of self-nominations and men and women nominating women for list of speakers. Sign up! https:\/\/t.co\/Jbpg5IhM2u #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "womeninELT",
        "indices" : [ 119, 130 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/Jbpg5IhM2u",
        "expanded_url" : "http:\/\/wp.me\/p1RJaO-lsu",
        "display_url" : "wp.me\/p1RJaO-lsu"
      } ]
    },
    "geo" : { },
    "id_str" : "658627153576132608",
    "text" : "Nice mix of self-nominations and men and women nominating women for list of speakers. Sign up! https:\/\/t.co\/Jbpg5IhM2u #womeninELT",
    "id" : 658627153576132608,
    "created_at" : "2015-10-26 12:52:04 +0000",
    "user" : {
      "name" : "Nicola Prentis",
      "screen_name" : "NicolaPrentis",
      "protected" : false,
      "id_str" : "810667033",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3046181441\/a51ef543c16ff30fdb8966f23237790d_normal.jpeg",
      "id" : 810667033,
      "verified" : false
    }
  },
  "id" : 658628741044793349,
  "created_at" : "2015-10-26 12:58:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Igor Brigadir",
      "screen_name" : "IgorBrigadir",
      "indices" : [ 3, 16 ],
      "id_str" : "495430242",
      "id" : 495430242
    }, {
      "name" : "CaSMa Research",
      "screen_name" : "CaSMaResearch",
      "indices" : [ 118, 132 ],
      "id_str" : "2797652043",
      "id" : 2797652043
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/0n7UPnSvKP",
      "expanded_url" : "https:\/\/twitter.com\/CaSMaResearch\/status\/658470575573086208",
      "display_url" : "twitter.com\/CaSMaResearch\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "658627332081631232",
  "text" : "RT @IgorBrigadir: Great post: \"Should online platforms have to explain inferences of their data-driven algorithms...\" @CaSMaResearch https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CaSMa Research",
        "screen_name" : "CaSMaResearch",
        "indices" : [ 100, 114 ],
        "id_str" : "2797652043",
        "id" : 2797652043
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/0n7UPnSvKP",
        "expanded_url" : "https:\/\/twitter.com\/CaSMaResearch\/status\/658470575573086208",
        "display_url" : "twitter.com\/CaSMaResearch\/\u2026"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 53.2820544, -6.1906215 ]
    },
    "id_str" : "658620563297062912",
    "text" : "Great post: \"Should online platforms have to explain inferences of their data-driven algorithms...\" @CaSMaResearch https:\/\/t.co\/0n7UPnSvKP",
    "id" : 658620563297062912,
    "created_at" : "2015-10-26 12:25:53 +0000",
    "user" : {
      "name" : "Igor Brigadir",
      "screen_name" : "IgorBrigadir",
      "protected" : false,
      "id_str" : "495430242",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2538946114\/xiveugt78rc97y1dasxf_normal.jpeg",
      "id" : 495430242,
      "verified" : false
    }
  },
  "id" : 658627332081631232,
  "created_at" : "2015-10-26 12:52:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/mFLsBp7Le9",
      "expanded_url" : "http:\/\/members5.boardhost.com\/medialens\/msg\/1445846358.html",
      "display_url" : "members5.boardhost.com\/medialens\/msg\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "658588615296065537",
  "text" : "Letter to JK Rowling from a Palestinian, protesting her opposition to cultural boycott of Israel...https:\/\/t.co\/mFLsBp7Le9",
  "id" : 658588615296065537,
  "created_at" : "2015-10-26 10:18:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "selfie",
      "indices" : [ 45, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/8Q8xgpMtlS",
      "expanded_url" : "http:\/\/disq.us\/8pwhjn",
      "display_url" : "disq.us\/8pwhjn"
    } ]
  },
  "geo" : { },
  "id_str" : "658583766777110528",
  "text" : "What a Deep Neural Network thinks about your #selfie https:\/\/t.co\/8Q8xgpMtlS",
  "id" : 658583766777110528,
  "created_at" : "2015-10-26 09:59:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Help Net Security",
      "screen_name" : "helpnetsecurity",
      "indices" : [ 3, 19 ],
      "id_str" : "14293266",
      "id" : 14293266
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/helpnetsecurity\/status\/656341844436131840\/photo\/1",
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/jZrGuxHsCI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRvLbgUW0AAd-rZ.png",
      "id_str" : "656341844104761344",
      "id" : 656341844104761344,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRvLbgUW0AAd-rZ.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 384,
        "resize" : "fit",
        "w" : 512
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 384,
        "resize" : "fit",
        "w" : 512
      }, {
        "h" : 384,
        "resize" : "fit",
        "w" : 512
      } ],
      "display_url" : "pic.twitter.com\/jZrGuxHsCI"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/d8moeisMA7",
      "expanded_url" : "http:\/\/bit.ly\/1LZL7Cs",
      "display_url" : "bit.ly\/1LZL7Cs"
    } ]
  },
  "geo" : { },
  "id_str" : "658422106460418053",
  "text" : "RT @helpnetsecurity: Secret code in color printers enables government tracking - https:\/\/t.co\/d8moeisMA7 https:\/\/t.co\/jZrGuxHsCI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/helpnetsecurity\/status\/656341844436131840\/photo\/1",
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/jZrGuxHsCI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CRvLbgUW0AAd-rZ.png",
        "id_str" : "656341844104761344",
        "id" : 656341844104761344,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRvLbgUW0AAd-rZ.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 384,
          "resize" : "fit",
          "w" : 512
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 384,
          "resize" : "fit",
          "w" : 512
        }, {
          "h" : 384,
          "resize" : "fit",
          "w" : 512
        } ],
        "display_url" : "pic.twitter.com\/jZrGuxHsCI"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/d8moeisMA7",
        "expanded_url" : "http:\/\/bit.ly\/1LZL7Cs",
        "display_url" : "bit.ly\/1LZL7Cs"
      } ]
    },
    "geo" : { },
    "id_str" : "656341844436131840",
    "text" : "Secret code in color printers enables government tracking - https:\/\/t.co\/d8moeisMA7 https:\/\/t.co\/jZrGuxHsCI",
    "id" : 656341844436131840,
    "created_at" : "2015-10-20 05:31:04 +0000",
    "user" : {
      "name" : "Help Net Security",
      "screen_name" : "helpnetsecurity",
      "protected" : false,
      "id_str" : "14293266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/698777219779469312\/IkGy7y0o_normal.jpg",
      "id" : 14293266,
      "verified" : true
    }
  },
  "id" : 658422106460418053,
  "created_at" : "2015-10-25 23:17:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debbie Cameron",
      "screen_name" : "wordspinster",
      "indices" : [ 3, 16 ],
      "id_str" : "2820709207",
      "id" : 2820709207
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "realistproverbs",
      "indices" : [ 109, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "658371609800126465",
  "text" : "RT @wordspinster: All work and no play makes Jack a typical participant in the globalized neoliberal economy #realistproverbs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "realistproverbs",
        "indices" : [ 91, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "658337415615090689",
    "text" : "All work and no play makes Jack a typical participant in the globalized neoliberal economy #realistproverbs",
    "id" : 658337415615090689,
    "created_at" : "2015-10-25 17:40:45 +0000",
    "user" : {
      "name" : "Debbie Cameron",
      "screen_name" : "wordspinster",
      "protected" : false,
      "id_str" : "2820709207",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/671103881812799488\/n6CtqOqq_normal.jpg",
      "id" : 2820709207,
      "verified" : false
    }
  },
  "id" : 658371609800126465,
  "created_at" : "2015-10-25 19:56:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Ireland",
      "screen_name" : "bloggerheads",
      "indices" : [ 3, 16 ],
      "id_str" : "28528503",
      "id" : 28528503
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BlameCorbyn",
      "indices" : [ 89, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "658338083042127872",
  "text" : "RT @bloggerheads: None of my analogue clocks have updated automatically from BST to GMT.\n#BlameCorbyn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BlameCorbyn",
        "indices" : [ 71, 83 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "658275734155341824",
    "text" : "None of my analogue clocks have updated automatically from BST to GMT.\n#BlameCorbyn",
    "id" : 658275734155341824,
    "created_at" : "2015-10-25 13:35:39 +0000",
    "user" : {
      "name" : "Tim Ireland",
      "screen_name" : "bloggerheads",
      "protected" : false,
      "id_str" : "28528503",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/596591826590629888\/MDb5sSMs_normal.png",
      "id" : 28528503,
      "verified" : false
    }
  },
  "id" : 658338083042127872,
  "created_at" : "2015-10-25 17:43:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenys Hanson",
      "screen_name" : "GlenysHanson",
      "indices" : [ 0, 13 ],
      "id_str" : "527238447",
      "id" : 527238447
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "658292558875987968",
  "geo" : { },
  "id_str" : "658296459368992768",
  "in_reply_to_user_id" : 527238447,
  "text" : "@GlenysHanson why not your blog Glenys?",
  "id" : 658296459368992768,
  "in_reply_to_status_id" : 658292558875987968,
  "created_at" : "2015-10-25 14:58:01 +0000",
  "in_reply_to_screen_name" : "GlenysHanson",
  "in_reply_to_user_id_str" : "527238447",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Robinson",
      "screen_name" : "SurrealAnarchy",
      "indices" : [ 0, 15 ],
      "id_str" : "4622730281",
      "id" : 4622730281
    }, {
      "name" : "Tim Knight",
      "screen_name" : "nakanotim",
      "indices" : [ 16, 26 ],
      "id_str" : "295968758",
      "id" : 295968758
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "658275026907475971",
  "geo" : { },
  "id_str" : "658293490518990849",
  "in_reply_to_user_id" : 99895700,
  "text" : "@SurrealAnarchy @nakanotim interesting article has not one word on libel laws in UK...",
  "id" : 658293490518990849,
  "in_reply_to_status_id" : 658275026907475971,
  "created_at" : "2015-10-25 14:46:13 +0000",
  "in_reply_to_screen_name" : "Trivium21c",
  "in_reply_to_user_id_str" : "99895700",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenys Hanson",
      "screen_name" : "GlenysHanson",
      "indices" : [ 0, 13 ],
      "id_str" : "527238447",
      "id" : 527238447
    }, {
      "name" : "IRD2015",
      "screen_name" : "ird2015",
      "indices" : [ 14, 22 ],
      "id_str" : "3004141222",
      "id" : 3004141222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/gnEFqIeLpA",
      "expanded_url" : "https:\/\/plus.google.com\/u\/0\/communities\/101266284417587206243",
      "display_url" : "plus.google.com\/u\/0\/communitie\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "658292558875987968",
  "geo" : { },
  "id_str" : "658292987403849728",
  "in_reply_to_user_id" : 527238447,
  "text" : "@GlenysHanson @ird2015 cool! maybe https:\/\/t.co\/gnEFqIeLpA :)",
  "id" : 658292987403849728,
  "in_reply_to_status_id" : 658292558875987968,
  "created_at" : "2015-10-25 14:44:13 +0000",
  "in_reply_to_screen_name" : "GlenysHanson",
  "in_reply_to_user_id_str" : "527238447",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 0, 10 ],
      "id_str" : "525274103",
      "id" : 525274103
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/658060641761128449\/photo\/1",
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/UxIyppfaf3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSHmqpUW0AAP4wi.png",
      "id_str" : "658060640892932096",
      "id" : 658060640892932096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSHmqpUW0AAP4wi.png",
      "sizes" : [ {
        "h" : 321,
        "resize" : "fit",
        "w" : 428
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 321,
        "resize" : "fit",
        "w" : 428
      }, {
        "h" : 321,
        "resize" : "fit",
        "w" : 428
      } ],
      "display_url" : "pic.twitter.com\/UxIyppfaf3"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/EnuVfsABTG",
      "expanded_url" : "http:\/\/videolectures.net\/eswc2012_welty_watson\/",
      "display_url" : "videolectures.net\/eswc2012_welty\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "658012948741255168",
  "geo" : { },
  "id_str" : "658060641761128449",
  "in_reply_to_user_id" : 525274103,
  "text" : "@ElkySmith more fundamentally machine int \u2260 human int  https:\/\/t.co\/EnuVfsABTG https:\/\/t.co\/UxIyppfaf3",
  "id" : 658060641761128449,
  "in_reply_to_status_id" : 658012948741255168,
  "created_at" : "2015-10-24 23:20:57 +0000",
  "in_reply_to_screen_name" : "ElkySmith",
  "in_reply_to_user_id_str" : "525274103",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IRD2015",
      "screen_name" : "ird2015",
      "indices" : [ 94, 102 ],
      "id_str" : "3004141222",
      "id" : 3004141222
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusresources",
      "indices" : [ 0, 16 ]
    }, {
      "text" : "IRD2015",
      "indices" : [ 85, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/JNCVwNAy6P",
      "expanded_url" : "https:\/\/sites.google.com\/site\/multidimensionaltagger\/",
      "display_url" : "sites.google.com\/site\/multidime\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "658004441128419328",
  "text" : "#corpusresources  MAT - Multidimensional Analysis Tagger https:\/\/t.co\/JNCVwNAy6P h\/t #IRD2015 @ird2015",
  "id" : 658004441128419328,
  "created_at" : "2015-10-24 19:37:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonny Ingham",
      "screen_name" : "jonathaningham",
      "indices" : [ 44, 59 ],
      "id_str" : "116582779",
      "id" : 116582779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/M1jdqKXbzs",
      "expanded_url" : "http:\/\/wp.me\/s2J1qM-phonemes",
      "display_url" : "wp.me\/s2J1qM-phonemes"
    } ]
  },
  "geo" : { },
  "id_str" : "657992332965494785",
  "text" : "Cheeky Phonemes https:\/\/t.co\/M1jdqKXbzs via @jonathaningham",
  "id" : 657992332965494785,
  "created_at" : "2015-10-24 18:49:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 0, 10 ],
      "id_str" : "6531902",
      "id" : 6531902
    }, {
      "name" : "Joe Emersberger",
      "screen_name" : "rosendo_joe",
      "indices" : [ 11, 23 ],
      "id_str" : "3351345863",
      "id" : 3351345863
    }, {
      "name" : "The Guardian",
      "screen_name" : "guardian",
      "indices" : [ 24, 33 ],
      "id_str" : "87818409",
      "id" : 87818409
    }, {
      "name" : "Seumas Milne",
      "screen_name" : "SeumasMilne",
      "indices" : [ 34, 46 ],
      "id_str" : "319675272",
      "id" : 319675272
    }, {
      "name" : "Chris Elliott",
      "screen_name" : "chriselliott57",
      "indices" : [ 47, 62 ],
      "id_str" : "75028951",
      "id" : 75028951
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/657991276093161472\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/QPAGzLRZV8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSGnlBDWwAAkgxd.png",
      "id_str" : "657991274952310784",
      "id" : 657991274952310784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSGnlBDWwAAkgxd.png",
      "sizes" : [ {
        "h" : 231,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 77,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 135,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 277,
        "resize" : "fit",
        "w" : 1229
      } ],
      "display_url" : "pic.twitter.com\/QPAGzLRZV8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "657950585396842497",
  "geo" : { },
  "id_str" : "657991276093161472",
  "in_reply_to_user_id" : 6531902,
  "text" : "@medialens @rosendo_joe @guardian @SeumasMilne @chriselliott57 topics milne 2015 campbell 1994 which is which? ; ) https:\/\/t.co\/QPAGzLRZV8",
  "id" : 657991276093161472,
  "in_reply_to_status_id" : 657950585396842497,
  "created_at" : "2015-10-24 18:45:19 +0000",
  "in_reply_to_screen_name" : "medialens",
  "in_reply_to_user_id_str" : "6531902",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/yOvbN4PjEO",
      "expanded_url" : "http:\/\/members5.boardhost.com\/medialens\/msg\/1445645724.html",
      "display_url" : "members5.boardhost.com\/medialens\/msg\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "657860593014173696",
  "text" : "On Seumas Milne's sudden vilification...https:\/\/t.co\/yOvbN4PjEO",
  "id" : 657860593014173696,
  "created_at" : "2015-10-24 10:06:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IRD2015",
      "screen_name" : "ird2015",
      "indices" : [ 3, 11 ],
      "id_str" : "3004141222",
      "id" : 3004141222
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/ird2015\/status\/657576101707980800\/photo\/1",
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/kSd1GIF3bi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSAt-vbWcAA6Kf_.jpg",
      "id_str" : "657576101502414848",
      "id" : 657576101502414848,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSAt-vbWcAA6Kf_.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1400,
        "resize" : "fit",
        "w" : 1050
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/kSd1GIF3bi"
    } ],
    "hashtags" : [ {
      "text" : "ird2015",
      "indices" : [ 26, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "657588898378436609",
  "text" : "RT @ird2015: La pizza tei #ird2015 \uD83D\uDE0B\uD83C\uDF55\uD83C\uDF7B\uD83C\uDF79 le cmc style https:\/\/t.co\/kSd1GIF3bi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ird2015\/status\/657576101707980800\/photo\/1",
        "indices" : [ 40, 63 ],
        "url" : "https:\/\/t.co\/kSd1GIF3bi",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSAt-vbWcAA6Kf_.jpg",
        "id_str" : "657576101502414848",
        "id" : 657576101502414848,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSAt-vbWcAA6Kf_.jpg",
        "sizes" : [ {
          "h" : 1365,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1400,
          "resize" : "fit",
          "w" : 1050
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/kSd1GIF3bi"
      } ],
      "hashtags" : [ {
        "text" : "ird2015",
        "indices" : [ 13, 21 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "657576101707980800",
    "text" : "La pizza tei #ird2015 \uD83D\uDE0B\uD83C\uDF55\uD83C\uDF7B\uD83C\uDF79 le cmc style https:\/\/t.co\/kSd1GIF3bi",
    "id" : 657576101707980800,
    "created_at" : "2015-10-23 15:15:34 +0000",
    "user" : {
      "name" : "IRD2015",
      "screen_name" : "ird2015",
      "protected" : false,
      "id_str" : "3004141222",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/569823716201099264\/uXXtyK3a_normal.jpeg",
      "id" : 3004141222,
      "verified" : false
    }
  },
  "id" : 657588898378436609,
  "created_at" : "2015-10-23 16:06:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/Kbl6UkpZtL",
      "expanded_url" : "http:\/\/dailycurrant.com\/2015\/10\/22\/netanyahu-palestinians-killed-the-dinosaurs\/",
      "display_url" : "dailycurrant.com\/2015\/10\/22\/net\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "657584392303452160",
  "text" : "Netanyahu: \u2018Palestinians Killed The Dinosaurs\u2019 https:\/\/t.co\/Kbl6UkpZtL",
  "id" : 657584392303452160,
  "created_at" : "2015-10-23 15:48:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 3, 17 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nwelearn",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/WaMIlOoBvP",
      "expanded_url" : "http:\/\/hackeducation.com\/2015\/10\/22\/robot-tutors\/",
      "display_url" : "hackeducation.com\/2015\/10\/22\/rob\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "657523431651569664",
  "text" : "RT @audreywatters: The Algorithmic Future of Education (my keynote at #nwelearn) https:\/\/t.co\/WaMIlOoBvP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/withknown.com\/\" rel=\"nofollow\"\u003EKnown Twitter Syndication\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "nwelearn",
        "indices" : [ 51, 60 ]
      } ],
      "urls" : [ {
        "indices" : [ 62, 85 ],
        "url" : "https:\/\/t.co\/WaMIlOoBvP",
        "expanded_url" : "http:\/\/hackeducation.com\/2015\/10\/22\/robot-tutors\/",
        "display_url" : "hackeducation.com\/2015\/10\/22\/rob\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "657324841108811780",
    "text" : "The Algorithmic Future of Education (my keynote at #nwelearn) https:\/\/t.co\/WaMIlOoBvP",
    "id" : 657324841108811780,
    "created_at" : "2015-10-22 22:37:09 +0000",
    "user" : {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "protected" : false,
      "id_str" : "25388528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711668009723498496\/pauFZsdv_normal.jpg",
      "id" : 25388528,
      "verified" : false
    }
  },
  "id" : 657523431651569664,
  "created_at" : "2015-10-23 11:46:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "damon_tokyo",
      "screen_name" : "damon_tokyo",
      "indices" : [ 0, 12 ],
      "id_str" : "17856980",
      "id" : 17856980
    }, {
      "name" : "Harry Leslie Smith",
      "screen_name" : "Harryslaststand",
      "indices" : [ 13, 29 ],
      "id_str" : "209176493",
      "id" : 209176493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/f6zcFgjOMD",
      "expanded_url" : "http:\/\/linguisticpulse.com\/2015\/10\/12\/are-we-citizens-or-taxpayers\/",
      "display_url" : "linguisticpulse.com\/2015\/10\/12\/are\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "657201205291040768",
  "geo" : { },
  "id_str" : "657205860180054018",
  "in_reply_to_user_id" : 17856980,
  "text" : "@damon_tokyo @Harryslaststand have u read this about US political use of terms? - https:\/\/t.co\/f6zcFgjOMD",
  "id" : 657205860180054018,
  "in_reply_to_status_id" : 657201205291040768,
  "created_at" : "2015-10-22 14:44:22 +0000",
  "in_reply_to_screen_name" : "damon_tokyo",
  "in_reply_to_user_id_str" : "17856980",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Poole",
      "screen_name" : "RobertEPoole",
      "indices" : [ 0, 13 ],
      "id_str" : "18526186",
      "id" : 18526186
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "657202757581967360",
  "geo" : { },
  "id_str" : "657204209427857408",
  "in_reply_to_user_id" : 18526186,
  "text" : "@RobertEPoole awesomely ridiculous? : )",
  "id" : 657204209427857408,
  "in_reply_to_status_id" : 657202757581967360,
  "created_at" : "2015-10-22 14:37:48 +0000",
  "in_reply_to_screen_name" : "RobertEPoole",
  "in_reply_to_user_id_str" : "18526186",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexandria Hall",
      "screen_name" : "alxndghall",
      "indices" : [ 0, 11 ],
      "id_str" : "1656929592",
      "id" : 1656929592
    }, {
      "name" : "Patricia Brenes",
      "screen_name" : "patriciambr",
      "indices" : [ 12, 24 ],
      "id_str" : "35764443",
      "id" : 35764443
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "656659475298840576",
  "geo" : { },
  "id_str" : "656941984129658881",
  "in_reply_to_user_id" : 1656929592,
  "text" : "@alxndghall @patriciambr uhoh :\/",
  "id" : 656941984129658881,
  "in_reply_to_status_id" : 656659475298840576,
  "created_at" : "2015-10-21 21:15:49 +0000",
  "in_reply_to_screen_name" : "alxndghall",
  "in_reply_to_user_id_str" : "1656929592",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jack Grieve",
      "screen_name" : "JWGrieve",
      "indices" : [ 0, 9 ],
      "id_str" : "2950391813",
      "id" : 2950391813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/iERUFT7jDz",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=21pHWDQx-wo",
      "display_url" : "youtube.com\/watch?v=21pHWD\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "656851991742824448",
  "geo" : { },
  "id_str" : "656853403394514944",
  "in_reply_to_user_id" : 2950391813,
  "text" : "@JWGrieve hi u may enjoy this https:\/\/t.co\/iERUFT7jDz",
  "id" : 656853403394514944,
  "in_reply_to_status_id" : 656851991742824448,
  "created_at" : "2015-10-21 15:23:49 +0000",
  "in_reply_to_screen_name" : "JWGrieve",
  "in_reply_to_user_id_str" : "2950391813",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gosia Kwiatkowska",
      "screen_name" : "LessonPlansDig",
      "indices" : [ 74, 89 ],
      "id_str" : "3293928293",
      "id" : 3293928293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/A3PZ9z04FR",
      "expanded_url" : "http:\/\/www.lessonplansdigger.com\/2015\/10\/21\/7-ways-to-create-interest-in-the-lesson-topic\/",
      "display_url" : "lessonplansdigger.com\/2015\/10\/21\/7-w\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "656852869010837504",
  "text" : "7 ways to create interest in the lesson topic https:\/\/t.co\/A3PZ9z04FR via @LessonPlansDig",
  "id" : 656852869010837504,
  "created_at" : "2015-10-21 15:21:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/fTq0uOPVEa",
      "expanded_url" : "http:\/\/steveoliver.net\/exercises-in-style-2\/",
      "display_url" : "steveoliver.net\/exercises-in-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "656852652639277057",
  "text" : "Excercises in style https:\/\/t.co\/fTq0uOPVEa",
  "id" : 656852652639277057,
  "created_at" : "2015-10-21 15:20:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoff Jordan",
      "screen_name" : "GeoffJordan",
      "indices" : [ 55, 67 ],
      "id_str" : "29510765",
      "id" : 29510765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/mdyTYCRfxg",
      "expanded_url" : "http:\/\/wp.me\/p3qkCB-1ok",
      "display_url" : "wp.me\/p3qkCB-1ok"
    } ]
  },
  "geo" : { },
  "id_str" : "656846790097051648",
  "text" : "Dellar and Lexical Priming https:\/\/t.co\/mdyTYCRfxg via @GeoffJordan",
  "id" : 656846790097051648,
  "created_at" : "2015-10-21 14:57:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "656728347695849472",
  "geo" : { },
  "id_str" : "656747545574645760",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco grt thx will chk it",
  "id" : 656747545574645760,
  "in_reply_to_status_id" : 656728347695849472,
  "created_at" : "2015-10-21 08:23:11 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexandria Hall",
      "screen_name" : "alxndghall",
      "indices" : [ 0, 11 ],
      "id_str" : "1656929592",
      "id" : 1656929592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "656623027321331712",
  "geo" : { },
  "id_str" : "656623657045872640",
  "in_reply_to_user_id" : 1656929592,
  "text" : "@alxndghall the title is Negative &amp; Neutral, labels are Positive &amp; Neutral, American is shaded neutral?",
  "id" : 656623657045872640,
  "in_reply_to_status_id" : 656623027321331712,
  "created_at" : "2015-10-21 00:10:53 +0000",
  "in_reply_to_screen_name" : "alxndghall",
  "in_reply_to_user_id_str" : "1656929592",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Poole",
      "screen_name" : "RobertEPoole",
      "indices" : [ 0, 13 ],
      "id_str" : "18526186",
      "id" : 18526186
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/QSJitqVKHW",
      "expanded_url" : "https:\/\/plus.google.com\/+MuraNava\/posts\/VfjHSdfv9SG",
      "display_url" : "plus.google.com\/+MuraNava\/post\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "656619635689721856",
  "geo" : { },
  "id_str" : "656622346434932736",
  "in_reply_to_user_id" : 18526186,
  "text" : "@RobertEPoole a couple of others as well https:\/\/t.co\/QSJitqVKHW",
  "id" : 656622346434932736,
  "in_reply_to_status_id" : 656619635689721856,
  "created_at" : "2015-10-21 00:05:41 +0000",
  "in_reply_to_screen_name" : "RobertEPoole",
  "in_reply_to_user_id_str" : "18526186",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 64, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/2P2qFidfwO",
      "expanded_url" : "https:\/\/twitter.com\/alxndghall\/status\/656234462141771776",
      "display_url" : "twitter.com\/alxndghall\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "656622115706306561",
  "text" : "great post! thought the \"needless\" graph labels seem messed up? #corpusmooc https:\/\/t.co\/2P2qFidfwO",
  "id" : 656622115706306561,
  "created_at" : "2015-10-21 00:04:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patricia Brenes",
      "screen_name" : "patriciambr",
      "indices" : [ 0, 12 ],
      "id_str" : "35764443",
      "id" : 35764443
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 52, 63 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "656459529299759105",
  "geo" : { },
  "id_str" : "656597061580759041",
  "in_reply_to_user_id" : 35764443,
  "text" : "@patriciambr yr welcome seems like u r enjoying the #corpusmooc :)",
  "id" : 656597061580759041,
  "in_reply_to_status_id" : 656459529299759105,
  "created_at" : "2015-10-20 22:25:13 +0000",
  "in_reply_to_screen_name" : "patriciambr",
  "in_reply_to_user_id_str" : "35764443",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Igor Brigadir",
      "screen_name" : "IgorBrigadir",
      "indices" : [ 0, 13 ],
      "id_str" : "495430242",
      "id" : 495430242
    }, {
      "name" : "megan squire",
      "screen_name" : "MeganSquire0",
      "indices" : [ 14, 27 ],
      "id_str" : "986601",
      "id" : 986601
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "656565927459356672",
  "geo" : { },
  "id_str" : "656567378894036992",
  "in_reply_to_user_id" : 495430242,
  "text" : "@IgorBrigadir @MeganSquire0 very nice thanks :)",
  "id" : 656567378894036992,
  "in_reply_to_status_id" : 656565927459356672,
  "created_at" : "2015-10-20 20:27:16 +0000",
  "in_reply_to_screen_name" : "IgorBrigadir",
  "in_reply_to_user_id_str" : "495430242",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "Cerstin Mahlow",
      "screen_name" : "CerstinMahlow",
      "indices" : [ 12, 26 ],
      "id_str" : "1377767730",
      "id" : 1377767730
    }, {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 74, 85 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/6MGUGOyi3y",
      "expanded_url" : "http:\/\/ucrel.lancs.ac.uk\/publications\/cl2003\/papers\/nicholls.pdf",
      "display_url" : "ucrel.lancs.ac.uk\/publications\/c\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "656565182152491012",
  "geo" : { },
  "id_str" : "656566067746181124",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan @CerstinMahlow have you seen this? https:\/\/t.co\/6MGUGOyi3y by @lexicoloco",
  "id" : 656566067746181124,
  "in_reply_to_status_id" : 656565182152491012,
  "created_at" : "2015-10-20 20:22:03 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Speech Dudes",
      "screen_name" : "SpeechDudes",
      "indices" : [ 0, 12 ],
      "id_str" : "310919399",
      "id" : 310919399
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/R5eQvBOFlB",
      "expanded_url" : "https:\/\/twitter.com\/SpeechDudes\/status\/656560677792915457",
      "display_url" : "twitter.com\/SpeechDudes\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "656562668518682624",
  "in_reply_to_user_id" : 310919399,
  "text" : "@SpeechDudes hope not spreading any linguistic herpes by RTing this ;) https:\/\/t.co\/R5eQvBOFlB",
  "id" : 656562668518682624,
  "created_at" : "2015-10-20 20:08:33 +0000",
  "in_reply_to_screen_name" : "SpeechDudes",
  "in_reply_to_user_id_str" : "310919399",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/gmpdF6vnJR",
      "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2015\/10\/healthy-profits.html",
      "display_url" : "thecurmudgeonly.blogspot.co.uk\/2015\/10\/health\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "656559854358806528",
  "text" : "RT @pchallinor: New mudgeonry: Healthy profits https:\/\/t.co\/gmpdF6vnJR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 31, 54 ],
        "url" : "https:\/\/t.co\/gmpdF6vnJR",
        "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2015\/10\/healthy-profits.html",
        "display_url" : "thecurmudgeonly.blogspot.co.uk\/2015\/10\/health\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "656530588397117444",
    "text" : "New mudgeonry: Healthy profits https:\/\/t.co\/gmpdF6vnJR",
    "id" : 656530588397117444,
    "created_at" : "2015-10-20 18:01:04 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 656559854358806528,
  "created_at" : "2015-10-20 19:57:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Idibon",
      "screen_name" : "idibon",
      "indices" : [ 3, 10 ],
      "id_str" : "749992082",
      "id" : 749992082
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/idibon\/status\/656546261718454273\/photo\/1",
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/FYvQbXksA5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRyFWJ1UcAAFxTl.png",
      "id_str" : "656546261332422656",
      "id" : 656546261332422656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRyFWJ1UcAAFxTl.png",
      "sizes" : [ {
        "h" : 500,
        "resize" : "fit",
        "w" : 735
      }, {
        "h" : 408,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 231,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 735
      } ],
      "display_url" : "pic.twitter.com\/FYvQbXksA5"
    } ],
    "hashtags" : [ {
      "text" : "NLProc",
      "indices" : [ 29, 36 ]
    }, {
      "text" : "AI",
      "indices" : [ 38, 41 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/ioXO4vF7Yw",
      "expanded_url" : "http:\/\/ow.ly\/TBui1",
      "display_url" : "ow.ly\/TBui1"
    } ]
  },
  "geo" : { },
  "id_str" : "656547305106120708",
  "text" : "RT @idibon: A T-Rex takes on #NLProc, #AI, and sports reporting\u00A0\nhttps:\/\/t.co\/ioXO4vF7Yw https:\/\/t.co\/FYvQbXksA5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/idibon\/status\/656546261718454273\/photo\/1",
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/FYvQbXksA5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CRyFWJ1UcAAFxTl.png",
        "id_str" : "656546261332422656",
        "id" : 656546261332422656,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRyFWJ1UcAAFxTl.png",
        "sizes" : [ {
          "h" : 500,
          "resize" : "fit",
          "w" : 735
        }, {
          "h" : 408,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 231,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 735
        } ],
        "display_url" : "pic.twitter.com\/FYvQbXksA5"
      } ],
      "hashtags" : [ {
        "text" : "NLProc",
        "indices" : [ 17, 24 ]
      }, {
        "text" : "AI",
        "indices" : [ 26, 29 ]
      } ],
      "urls" : [ {
        "indices" : [ 53, 76 ],
        "url" : "https:\/\/t.co\/ioXO4vF7Yw",
        "expanded_url" : "http:\/\/ow.ly\/TBui1",
        "display_url" : "ow.ly\/TBui1"
      } ]
    },
    "geo" : { },
    "id_str" : "656546261718454273",
    "text" : "A T-Rex takes on #NLProc, #AI, and sports reporting\u00A0\nhttps:\/\/t.co\/ioXO4vF7Yw https:\/\/t.co\/FYvQbXksA5",
    "id" : 656546261718454273,
    "created_at" : "2015-10-20 19:03:21 +0000",
    "user" : {
      "name" : "Idibon",
      "screen_name" : "idibon",
      "protected" : false,
      "id_str" : "749992082",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/577899744749481985\/ospcUqfV_normal.jpeg",
      "id" : 749992082,
      "verified" : false
    }
  },
  "id" : 656547305106120708,
  "created_at" : "2015-10-20 19:07:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/656531122487230464\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/Q0SUqXuOI5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRx3k54XIAEwN8V.png",
      "id_str" : "656531121585463297",
      "id" : 656531121585463297,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRx3k54XIAEwN8V.png",
      "sizes" : [ {
        "h" : 672,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 763,
        "resize" : "fit",
        "w" : 1162
      }, {
        "h" : 394,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 223,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Q0SUqXuOI5"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656531122487230464",
  "text" : "Blair talked a good game re honesty, honest, integrity...as does Cameron...by contrast Corbyn is an outlier again ;) https:\/\/t.co\/Q0SUqXuOI5",
  "id" : 656531122487230464,
  "created_at" : "2015-10-20 18:03:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    }, {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 13, 24 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "656438695583551488",
  "geo" : { },
  "id_str" : "656441027260252160",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler @leoselivan have u thought of writing up your experience of this Anne? sure a lot of interest in grading texts",
  "id" : 656441027260252160,
  "in_reply_to_status_id" : 656438695583551488,
  "created_at" : "2015-10-20 12:05:11 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "indices" : [ 3, 14 ],
      "id_str" : "152051625",
      "id" : 152051625
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "d2e2015",
      "indices" : [ 68, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/QBA2gWbmC5",
      "expanded_url" : "http:\/\/search.politicalmashup.nl",
      "display_url" : "search.politicalmashup.nl"
    } ]
  },
  "geo" : { },
  "id_str" : "656440402799689728",
  "text" : "RT @heatherfro: Parliament Debate Searches: https:\/\/t.co\/QBA2gWbmC5 #d2e2015",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "d2e2015",
        "indices" : [ 52, 60 ]
      } ],
      "urls" : [ {
        "indices" : [ 28, 51 ],
        "url" : "https:\/\/t.co\/QBA2gWbmC5",
        "expanded_url" : "http:\/\/search.politicalmashup.nl",
        "display_url" : "search.politicalmashup.nl"
      } ]
    },
    "geo" : { },
    "id_str" : "656437392635641856",
    "text" : "Parliament Debate Searches: https:\/\/t.co\/QBA2gWbmC5 #d2e2015",
    "id" : 656437392635641856,
    "created_at" : "2015-10-20 11:50:45 +0000",
    "user" : {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "protected" : false,
      "id_str" : "152051625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/688767277022494720\/KMrzOBc1_normal.jpg",
      "id" : 152051625,
      "verified" : false
    }
  },
  "id" : 656440402799689728,
  "created_at" : "2015-10-20 12:02:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    }, {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 57, 67 ],
      "id_str" : "6531902",
      "id" : 6531902
    }, {
      "name" : "Jon Sopel",
      "screen_name" : "BBCJonSopel",
      "indices" : [ 120, 132 ],
      "id_str" : "130104942",
      "id" : 130104942
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MSF",
      "indices" : [ 37, 41 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/lSK8dvxYjo",
      "expanded_url" : "http:\/\/www.medialens.org\/index.php\/alerts\/alert-archive\/2015\/804-sick-sophistry-bbc-news-on-the-afghan-hospital-mistakenly-bombed-by-the-united-states.html",
      "display_url" : "medialens.org\/index.php\/aler\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "656411415742386176",
  "text" : "RT @johnwhilley: Criminal bombing of #MSF hospital: fine @medialens indictment of US, protective media and sophistry of @BBCJonSopel https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Media Lens",
        "screen_name" : "medialens",
        "indices" : [ 40, 50 ],
        "id_str" : "6531902",
        "id" : 6531902
      }, {
        "name" : "Jon Sopel",
        "screen_name" : "BBCJonSopel",
        "indices" : [ 103, 115 ],
        "id_str" : "130104942",
        "id" : 130104942
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MSF",
        "indices" : [ 20, 24 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/lSK8dvxYjo",
        "expanded_url" : "http:\/\/www.medialens.org\/index.php\/alerts\/alert-archive\/2015\/804-sick-sophistry-bbc-news-on-the-afghan-hospital-mistakenly-bombed-by-the-united-states.html",
        "display_url" : "medialens.org\/index.php\/aler\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "656411077308194816",
    "text" : "Criminal bombing of #MSF hospital: fine @medialens indictment of US, protective media and sophistry of @BBCJonSopel https:\/\/t.co\/lSK8dvxYjo",
    "id" : 656411077308194816,
    "created_at" : "2015-10-20 10:06:11 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 656411415742386176,
  "created_at" : "2015-10-20 10:07:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicola Prentis",
      "screen_name" : "NicolaPrentis",
      "indices" : [ 29, 43 ],
      "id_str" : "810667033",
      "id" : 810667033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/vmLzaO17tz",
      "expanded_url" : "https:\/\/medium.com\/@nicolaprentis\/splainin-the-splains-8c031ef59299?source=tw-lo_dnt_27d6f5cfc5d7-1445335361625",
      "display_url" : "medium.com\/@nicolaprentis\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "656410227663851520",
  "text" : "\u201C\u2019Splainin\u2019 the \u2019splains\u201D by @NicolaPrentis https:\/\/t.co\/vmLzaO17tz",
  "id" : 656410227663851520,
  "created_at" : "2015-10-20 10:02:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemma Lunn",
      "screen_name" : "GemL1",
      "indices" : [ 0, 6 ],
      "id_str" : "486146568",
      "id" : 486146568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "656365102925524992",
  "geo" : { },
  "id_str" : "656410074596950016",
  "in_reply_to_user_id" : 486146568,
  "text" : "@GemL1 cheers Gemma hope all is good with you :)",
  "id" : 656410074596950016,
  "in_reply_to_status_id" : 656365102925524992,
  "created_at" : "2015-10-20 10:02:11 +0000",
  "in_reply_to_screen_name" : "GemL1",
  "in_reply_to_user_id_str" : "486146568",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "656361951069646848",
  "geo" : { },
  "id_str" : "656409815904841728",
  "in_reply_to_user_id" : 1558541821,
  "text" : "@JournalETAS thanks for sharing :)",
  "id" : 656409815904841728,
  "in_reply_to_status_id" : 656361951069646848,
  "created_at" : "2015-10-20 10:01:10 +0000",
  "in_reply_to_screen_name" : "ETAS_CH",
  "in_reply_to_user_id_str" : "1558541821",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yolanda B. Schell",
      "screen_name" : "mattellman",
      "indices" : [ 0, 11 ],
      "id_str" : "725597315860434945",
      "id" : 725597315860434945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656168422238236672",
  "in_reply_to_user_id" : 394987109,
  "text" : "@MattEllman hey Matthew how goes it? and thanks for RT (wld u be interested in knowing how to set wiki up on yr phone?)",
  "id" : 656168422238236672,
  "created_at" : "2015-10-19 18:01:57 +0000",
  "in_reply_to_screen_name" : "MatthewEllman",
  "in_reply_to_user_id_str" : "394987109",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Magnus Nissel",
      "screen_name" : "u203d",
      "indices" : [ 0, 6 ],
      "id_str" : "533114985",
      "id" : 533114985
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "656151524922531840",
  "geo" : { },
  "id_str" : "656168170126974976",
  "in_reply_to_user_id" : 533114985,
  "text" : "@u203d hi no not tried Zim will have a look thx; what kind of things did u use it for?",
  "id" : 656168170126974976,
  "in_reply_to_status_id" : 656151524922531840,
  "created_at" : "2015-10-19 18:00:57 +0000",
  "in_reply_to_screen_name" : "u203d",
  "in_reply_to_user_id_str" : "533114985",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 52, 60 ]
    }, {
      "text" : "edtech",
      "indices" : [ 61, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/bsEneu7cSv",
      "expanded_url" : "https:\/\/eflnotes.wordpress.com\/2015\/10\/19\/offline-doku-wiki-writing\/",
      "display_url" : "eflnotes.wordpress.com\/2015\/10\/19\/off\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "656124330569564160",
  "text" : "Offline (doku) wiki writing https:\/\/t.co\/bsEneu7cSv #eltchat #edtech",
  "id" : 656124330569564160,
  "created_at" : "2015-10-19 15:06:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lynn Cherny",
      "screen_name" : "arnicas",
      "indices" : [ 3, 11 ],
      "id_str" : "6146692",
      "id" : 6146692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/zc3KY1kHNI",
      "expanded_url" : "http:\/\/ghostweather.slides.com\/lynncherny\/text-data-analysis-without-programming#\/",
      "display_url" : "ghostweather.slides.com\/lynncherny\/tex\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "656026108442353664",
  "text" : "RT @arnicas: My talk slides: Text Analysis Without Programming (biased to journalism, vis, dh): http:\/\/t.co\/zc3KY1kHNI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/zc3KY1kHNI",
        "expanded_url" : "http:\/\/ghostweather.slides.com\/lynncherny\/text-data-analysis-without-programming#\/",
        "display_url" : "ghostweather.slides.com\/lynncherny\/tex\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "655080756717486080",
    "text" : "My talk slides: Text Analysis Without Programming (biased to journalism, vis, dh): http:\/\/t.co\/zc3KY1kHNI",
    "id" : 655080756717486080,
    "created_at" : "2015-10-16 17:59:57 +0000",
    "user" : {
      "name" : "Lynn Cherny",
      "screen_name" : "arnicas",
      "protected" : false,
      "id_str" : "6146692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53142956\/Saw-whet_Owl_10_normal.jpg",
      "id" : 6146692,
      "verified" : false
    }
  },
  "id" : 656026108442353664,
  "created_at" : "2015-10-19 08:36:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patricia Brenes",
      "screen_name" : "patriciambr",
      "indices" : [ 86, 98 ],
      "id_str" : "35764443",
      "id" : 35764443
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 99, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/kpb2c3hjMQ",
      "expanded_url" : "http:\/\/inmyownterms.com\/from-the-terminologist-toolbox-graphcoll-visualizing-your-term-networks-and-its-fun\/",
      "display_url" : "inmyownterms.com\/from-the-termi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "656002047217651712",
  "text" : "GraphColl \u2013 visualizing your term networks (and it\u2019s fun!) http:\/\/t.co\/kpb2c3hjMQ via @patriciambr #corpusmooc",
  "id" : 656002047217651712,
  "created_at" : "2015-10-19 07:00:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Hirst",
      "screen_name" : "psychemedia",
      "indices" : [ 74, 86 ],
      "id_str" : "7129072",
      "id" : 7129072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/9ouqUlxFj1",
      "expanded_url" : "http:\/\/wp.me\/p1mEF-3zS",
      "display_url" : "wp.me\/p1mEF-3zS"
    } ]
  },
  "geo" : { },
  "id_str" : "656001287486615552",
  "text" : "When Your Identity Can Be Used Against You...: http:\/\/t.co\/9ouqUlxFj1 via @psychemedia",
  "id" : 656001287486615552,
  "created_at" : "2015-10-19 06:57:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CorCenCC",
      "screen_name" : "CorCenCC",
      "indices" : [ 3, 12 ],
      "id_str" : "3945092685",
      "id" : 3945092685
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CorCenCC",
      "indices" : [ 14, 23 ]
    } ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/HT5OWOGkUm",
      "expanded_url" : "http:\/\/www.walesonline.co.uk\/news\/wales-news\/welsh-language-10-million-words-10217359",
      "display_url" : "walesonline.co.uk\/news\/wales-new\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "655851176420900870",
  "text" : "RT @CorCenCC: #CorCenCC in the news: http:\/\/t.co\/HT5OWOGkUm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CorCenCC",
        "indices" : [ 0, 9 ]
      } ],
      "urls" : [ {
        "indices" : [ 23, 45 ],
        "url" : "http:\/\/t.co\/HT5OWOGkUm",
        "expanded_url" : "http:\/\/www.walesonline.co.uk\/news\/wales-news\/welsh-language-10-million-words-10217359",
        "display_url" : "walesonline.co.uk\/news\/wales-new\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "653884850215231488",
    "text" : "#CorCenCC in the news: http:\/\/t.co\/HT5OWOGkUm",
    "id" : 653884850215231488,
    "created_at" : "2015-10-13 10:47:51 +0000",
    "user" : {
      "name" : "CorCenCC",
      "screen_name" : "CorCenCC",
      "protected" : false,
      "id_str" : "3945092685",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/653878035456892928\/OUdQRPpt_normal.png",
      "id" : 3945092685,
      "verified" : false
    }
  },
  "id" : 655851176420900870,
  "created_at" : "2015-10-18 21:01:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vicky Cooke",
      "screen_name" : "MsVCooke",
      "indices" : [ 0, 9 ],
      "id_str" : "1308373140",
      "id" : 1308373140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/1jFlvDeM4d",
      "expanded_url" : "http:\/\/www.lextutor.ca\/freq\/lists_download\/",
      "display_url" : "lextutor.ca\/freq\/lists_dow\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "655817523955372033",
  "geo" : { },
  "id_str" : "655848141351223296",
  "in_reply_to_user_id" : 18602422,
  "text" : "@MsVCooke lextutor has some as well http:\/\/t.co\/1jFlvDeM4d",
  "id" : 655848141351223296,
  "in_reply_to_status_id" : 655817523955372033,
  "created_at" : "2015-10-18 20:49:16 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 0, 10 ],
      "id_str" : "6531902",
      "id" : 6531902
    }, {
      "name" : "Joe Emersberger",
      "screen_name" : "rosendo_joe",
      "indices" : [ 11, 23 ],
      "id_str" : "3351345863",
      "id" : 3351345863
    }, {
      "name" : "Jon Sopel",
      "screen_name" : "BBCJonSopel",
      "indices" : [ 24, 36 ],
      "id_str" : "130104942",
      "id" : 130104942
    }, {
      "name" : "BBC News (UK)",
      "screen_name" : "BBCNews",
      "indices" : [ 37, 45 ],
      "id_str" : "612473",
      "id" : 612473
    }, {
      "name" : "MSF International",
      "screen_name" : "MSF",
      "indices" : [ 46, 50 ],
      "id_str" : "2195671183",
      "id" : 2195671183
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/655827625496158208\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/HTpWlRRVJe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRn3v-_XAAISPsr.png",
      "id_str" : "655827624493776898",
      "id" : 655827624493776898,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRn3v-_XAAISPsr.png",
      "sizes" : [ {
        "h" : 325,
        "resize" : "fit",
        "w" : 530
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 208,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 325,
        "resize" : "fit",
        "w" : 530
      }, {
        "h" : 325,
        "resize" : "fit",
        "w" : 530
      } ],
      "display_url" : "pic.twitter.com\/HTpWlRRVJe"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "655815077006852096",
  "geo" : { },
  "id_str" : "655827625496158208",
  "in_reply_to_user_id" : 6531902,
  "text" : "@medialens @rosendo_joe @BBCJonSopel @BBCNews @MSF hmm some synonyms of mistakenly from a 12 Billion word corpus http:\/\/t.co\/HTpWlRRVJe",
  "id" : 655827625496158208,
  "in_reply_to_status_id" : 655815077006852096,
  "created_at" : "2015-10-18 19:27:45 +0000",
  "in_reply_to_screen_name" : "medialens",
  "in_reply_to_user_id_str" : "6531902",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vicky Cooke",
      "screen_name" : "MsVCooke",
      "indices" : [ 0, 9 ],
      "id_str" : "1308373140",
      "id" : 1308373140
    }, {
      "name" : "Joe Dale",
      "screen_name" : "joedale",
      "indices" : [ 10, 18 ],
      "id_str" : "5923092",
      "id" : 5923092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/f7DLQVdUtv",
      "expanded_url" : "http:\/\/sites.univ-provence.fr\/~veronis\/donnees\/index.html",
      "display_url" : "sites.univ-provence.fr\/~veronis\/donne\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "655807570716835840",
  "geo" : { },
  "id_str" : "655817523955372033",
  "in_reply_to_user_id" : 1308373140,
  "text" : "@MsVCooke @joedale u could try this http:\/\/t.co\/f7DLQVdUtv",
  "id" : 655817523955372033,
  "in_reply_to_status_id" : 655807570716835840,
  "created_at" : "2015-10-18 18:47:36 +0000",
  "in_reply_to_screen_name" : "MsVCooke",
  "in_reply_to_user_id_str" : "1308373140",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 3, 18 ],
      "id_str" : "285614027",
      "id" : 285614027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/KSvbeOuVRp",
      "expanded_url" : "https:\/\/twitter.com\/pronbites\/status\/655601476568522752",
      "display_url" : "twitter.com\/pronbites\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "655785574851325952",
  "text" : "RT @AnthonyTeacher: YouTube as a multi modal corpus https:\/\/t.co\/KSvbeOuVRp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 32, 55 ],
        "url" : "https:\/\/t.co\/KSvbeOuVRp",
        "expanded_url" : "https:\/\/twitter.com\/pronbites\/status\/655601476568522752",
        "display_url" : "twitter.com\/pronbites\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "655743547942043648",
    "text" : "YouTube as a multi modal corpus https:\/\/t.co\/KSvbeOuVRp",
    "id" : 655743547942043648,
    "created_at" : "2015-10-18 13:53:39 +0000",
    "user" : {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "protected" : false,
      "id_str" : "285614027",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/412336845658132481\/Om5kKuMQ_normal.jpeg",
      "id" : 285614027,
      "verified" : false
    }
  },
  "id" : 655785574851325952,
  "created_at" : "2015-10-18 16:40:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    }, {
      "name" : "Costas Gabrielatos",
      "screen_name" : "congabonga",
      "indices" : [ 13, 24 ],
      "id_str" : "187484412",
      "id" : 187484412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "655685009039167488",
  "geo" : { },
  "id_str" : "655708017451732992",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler @congabonga hi Anne did u get this sorted?",
  "id" : 655708017451732992,
  "in_reply_to_status_id" : 655685009039167488,
  "created_at" : "2015-10-18 11:32:28 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bret Victor",
      "screen_name" : "worrydream",
      "indices" : [ 3, 14 ],
      "id_str" : "255617445",
      "id" : 255617445
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655391967657000960",
  "text" : "RT @worrydream: \"Caveat\": a writing platform like \"Medium\" but you annotate every sentence you write w\/ context, hedging, exceptions, \"it's\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "653646860402298880",
    "text" : "\"Caveat\": a writing platform like \"Medium\" but you annotate every sentence you write w\/ context, hedging, exceptions, \"it's not that simple\"",
    "id" : 653646860402298880,
    "created_at" : "2015-10-12 19:02:10 +0000",
    "user" : {
      "name" : "Bret Victor",
      "screen_name" : "worrydream",
      "protected" : false,
      "id_str" : "255617445",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/767981637623685120\/7WgbPNE9_normal.jpg",
      "id" : 255617445,
      "verified" : false
    }
  },
  "id" : 655391967657000960,
  "created_at" : "2015-10-17 14:36:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 0, 11 ],
      "id_str" : "88202140",
      "id" : 88202140
    }, {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 12, 28 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "655359592424185856",
  "geo" : { },
  "id_str" : "655360934324649984",
  "in_reply_to_user_id" : 88202140,
  "text" : "@hughdellar @getgreatenglish hopefully :) thanks for your tweets though",
  "id" : 655360934324649984,
  "in_reply_to_status_id" : 655359592424185856,
  "created_at" : "2015-10-17 12:33:17 +0000",
  "in_reply_to_screen_name" : "hughdellar",
  "in_reply_to_user_id_str" : "88202140",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    }, {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 17, 28 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "655357568211009536",
  "geo" : { },
  "id_str" : "655358866964815872",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish @hughdellar true that are these talks being filmed Hugh?",
  "id" : 655358866964815872,
  "in_reply_to_status_id" : 655357568211009536,
  "created_at" : "2015-10-17 12:25:04 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 0, 11 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "655355957300580352",
  "geo" : { },
  "id_str" : "655356334003589120",
  "in_reply_to_user_id" : 88202140,
  "text" : "@hughdellar the claims of \"adaptive\" programs esp in lang learn is \"generalised\" hype?",
  "id" : 655356334003589120,
  "in_reply_to_status_id" : 655355957300580352,
  "created_at" : "2015-10-17 12:15:00 +0000",
  "in_reply_to_screen_name" : "hughdellar",
  "in_reply_to_user_id_str" : "88202140",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 0, 11 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "655354629157441536",
  "geo" : { },
  "id_str" : "655355607155920896",
  "in_reply_to_user_id" : 88202140,
  "text" : "@hughdellar at one level \"adaptiveness\" in lang learn pointless if learner goes through \"fixed\" stages",
  "id" : 655355607155920896,
  "in_reply_to_status_id" : 655354629157441536,
  "created_at" : "2015-10-17 12:12:07 +0000",
  "in_reply_to_screen_name" : "hughdellar",
  "in_reply_to_user_id_str" : "88202140",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 0, 11 ],
      "id_str" : "88202140",
      "id" : 88202140
    }, {
      "name" : "Donald Clark",
      "screen_name" : "DonaldClark",
      "indices" : [ 12, 24 ],
      "id_str" : "1632891",
      "id" : 1632891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "655353794079903744",
  "geo" : { },
  "id_str" : "655354030835765248",
  "in_reply_to_user_id" : 88202140,
  "text" : "@hughdellar @DonaldClark interlanguage?",
  "id" : 655354030835765248,
  "in_reply_to_status_id" : 655353794079903744,
  "created_at" : "2015-10-17 12:05:51 +0000",
  "in_reply_to_screen_name" : "hughdellar",
  "in_reply_to_user_id_str" : "88202140",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 0, 11 ],
      "id_str" : "88202140",
      "id" : 88202140
    }, {
      "name" : "Donald Clark",
      "screen_name" : "DonaldClark",
      "indices" : [ 12, 24 ],
      "id_str" : "1632891",
      "id" : 1632891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "655330959689187328",
  "geo" : { },
  "id_str" : "655351676304543744",
  "in_reply_to_user_id" : 88202140,
  "text" : "@hughdellar @DonaldClark what if the z is built on the a? ;)",
  "id" : 655351676304543744,
  "in_reply_to_status_id" : 655330959689187328,
  "created_at" : "2015-10-17 11:56:30 +0000",
  "in_reply_to_screen_name" : "hughdellar",
  "in_reply_to_user_id_str" : "88202140",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "655293659517075456",
  "geo" : { },
  "id_str" : "655297267256172544",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish a pleasure enjoy your w\/e too",
  "id" : 655297267256172544,
  "in_reply_to_status_id" : 655293659517075456,
  "created_at" : "2015-10-17 08:20:18 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 49, 65 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/YOso8xYdr7",
      "expanded_url" : "https:\/\/freelanceteacherselfdevelopment.wordpress.com\/2015\/10\/16\/blog-challenge-poem\/",
      "display_url" : "\u2026eteacherselfdevelopment.wordpress.com\/2015\/10\/16\/blo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "655291678648115200",
  "text" : "Blog challenge:\u00A0poem https:\/\/t.co\/YOso8xYdr7 via @wordpressdotcom",
  "id" : 655291678648115200,
  "created_at" : "2015-10-17 07:58:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Ford",
      "screen_name" : "EdSacredProfane",
      "indices" : [ 99, 115 ],
      "id_str" : "2288627443",
      "id" : 2288627443
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/DpXkyrCVq1",
      "expanded_url" : "http:\/\/wp.me\/p4c373-17w",
      "display_url" : "wp.me\/p4c373-17w"
    } ]
  },
  "geo" : { },
  "id_str" : "655290249917108224",
  "text" : "On Nadiya and \"how it is that an 87 year old retired professor .......\" http:\/\/t.co\/DpXkyrCVq1 via @EdSacredProfane",
  "id" : 655290249917108224,
  "created_at" : "2015-10-17 07:52:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate Bowles",
      "screen_name" : "KateMfD",
      "indices" : [ 3, 11 ],
      "id_str" : "379065166",
      "id" : 379065166
    }, {
      "name" : "Jonathan Rees",
      "screen_name" : "jhrees",
      "indices" : [ 106, 113 ],
      "id_str" : "227708559",
      "id" : 227708559
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dlrn15",
      "indices" : [ 123, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655287722958016512",
  "text" : "RT @KateMfD: The LMS is the troll under the bridge collecting data as we pass over to reach our students. @jhrees nails it #dlrn15",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jonathan Rees",
        "screen_name" : "jhrees",
        "indices" : [ 93, 100 ],
        "id_str" : "227708559",
        "id" : 227708559
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "dlrn15",
        "indices" : [ 110, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "655072782884061186",
    "text" : "The LMS is the troll under the bridge collecting data as we pass over to reach our students. @jhrees nails it #dlrn15",
    "id" : 655072782884061186,
    "created_at" : "2015-10-16 17:28:16 +0000",
    "user" : {
      "name" : "Kate Bowles",
      "screen_name" : "KateMfD",
      "protected" : false,
      "id_str" : "379065166",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1557363696\/Screen_shot_2011-09-24_at_7.36.20_PM_normal.png",
      "id" : 379065166,
      "verified" : false
    }
  },
  "id" : 655287722958016512,
  "created_at" : "2015-10-17 07:42:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharon Hartle",
      "screen_name" : "hartle",
      "indices" : [ 3, 10 ],
      "id_str" : "20324125",
      "id" : 20324125
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/hartle\/status\/655074184641441792\/photo\/1",
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/DPqRspYvCy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRdKf8DVEAAm8U9.jpg",
      "id_str" : "655074183362187264",
      "id" : 655074183362187264,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRdKf8DVEAAm8U9.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/DPqRspYvCy"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/x0MItttfud",
      "expanded_url" : "https:\/\/hartlelearning.wordpress.com\/2015\/10\/16\/the-cambridge-english-profiles-vocabulary-and-now-grammar",
      "display_url" : "hartlelearning.wordpress.com\/2015\/10\/16\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "655088450031460353",
  "text" : "RT @hartle: The Cambridge English Profiles vocabulary and now\u2026\u00A0grammar! https:\/\/t.co\/x0MItttfud http:\/\/t.co\/DPqRspYvCy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/hartle\/status\/655074184641441792\/photo\/1",
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/DPqRspYvCy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CRdKf8DVEAAm8U9.jpg",
        "id_str" : "655074183362187264",
        "id" : 655074183362187264,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRdKf8DVEAAm8U9.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/DPqRspYvCy"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/x0MItttfud",
        "expanded_url" : "https:\/\/hartlelearning.wordpress.com\/2015\/10\/16\/the-cambridge-english-profiles-vocabulary-and-now-grammar",
        "display_url" : "hartlelearning.wordpress.com\/2015\/10\/16\/the\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "655074184641441792",
    "text" : "The Cambridge English Profiles vocabulary and now\u2026\u00A0grammar! https:\/\/t.co\/x0MItttfud http:\/\/t.co\/DPqRspYvCy",
    "id" : 655074184641441792,
    "created_at" : "2015-10-16 17:33:50 +0000",
    "user" : {
      "name" : "Sharon Hartle",
      "screen_name" : "hartle",
      "protected" : false,
      "id_str" : "20324125",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1387040491\/Snapshot_of_me_1_normal.png",
      "id" : 20324125,
      "verified" : false
    }
  },
  "id" : 655088450031460353,
  "created_at" : "2015-10-16 18:30:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Serveis Ling\u00FC\u00EDstics",
      "screen_name" : "SLBCoop",
      "indices" : [ 3, 11 ],
      "id_str" : "2365399801",
      "id" : 2365399801
    }, {
      "name" : "TEFL Iberia",
      "screen_name" : "TEFL_Iberia",
      "indices" : [ 32, 44 ],
      "id_str" : "280664750",
      "id" : 280664750
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TEFL",
      "indices" : [ 92, 97 ]
    }, {
      "text" : "teachertraining",
      "indices" : [ 98, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/7xUjm4C2ob",
      "expanded_url" : "http:\/\/www.slb.coop\/?p=2100",
      "display_url" : "slb.coop\/?p=2100"
    } ]
  },
  "geo" : { },
  "id_str" : "655058799351435266",
  "text" : "RT @SLBCoop: Congratulations to @TEFL_Iberia for achieving SLB validation for their initial #TEFL #teachertraining course! More: http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TEFL Iberia",
        "screen_name" : "TEFL_Iberia",
        "indices" : [ 19, 31 ],
        "id_str" : "280664750",
        "id" : 280664750
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TEFL",
        "indices" : [ 79, 84 ]
      }, {
        "text" : "teachertraining",
        "indices" : [ 85, 101 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/7xUjm4C2ob",
        "expanded_url" : "http:\/\/www.slb.coop\/?p=2100",
        "display_url" : "slb.coop\/?p=2100"
      } ]
    },
    "geo" : { },
    "id_str" : "655050991851675648",
    "text" : "Congratulations to @TEFL_Iberia for achieving SLB validation for their initial #TEFL #teachertraining course! More: http:\/\/t.co\/7xUjm4C2ob",
    "id" : 655050991851675648,
    "created_at" : "2015-10-16 16:01:41 +0000",
    "user" : {
      "name" : "Serveis Ling\u00FC\u00EDstics",
      "screen_name" : "SLBCoop",
      "protected" : false,
      "id_str" : "2365399801",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705151471386546176\/ECVLcba-_normal.jpg",
      "id" : 2365399801,
      "verified" : false
    }
  },
  "id" : 655058799351435266,
  "created_at" : "2015-10-16 16:32:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chad Weinard",
      "screen_name" : "caw_",
      "indices" : [ 3, 8 ],
      "id_str" : "18562791",
      "id" : 18562791
    }, {
      "name" : "Lynn Cherny",
      "screen_name" : "arnicas",
      "indices" : [ 90, 98 ],
      "id_str" : "6146692",
      "id" : 6146692
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/arnicas\/status\/655017157428912129\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/c1cNMOFpuf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRcWjXaWoAAfojx.png",
      "id_str" : "655017067641479168",
      "id" : 655017067641479168,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRcWjXaWoAAfojx.png",
      "sizes" : [ {
        "h" : 548,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 182,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1274
      }, {
        "h" : 321,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/c1cNMOFpuf"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/AzHMM8Xjtc",
      "expanded_url" : "http:\/\/www.thomaswilhelm.eu\/shakespeare\/output\/twelfthnight.html",
      "display_url" : "thomaswilhelm.eu\/shakespeare\/ou\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "655037494799564800",
  "text" : "RT @caw_: Whoa. Tool for visual analysis of Shakespeare plays http:\/\/t.co\/AzHMM8Xjtc \/via @arnicas http:\/\/t.co\/c1cNMOFpuf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lynn Cherny",
        "screen_name" : "arnicas",
        "indices" : [ 80, 88 ],
        "id_str" : "6146692",
        "id" : 6146692
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/arnicas\/status\/655017157428912129\/photo\/1",
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/c1cNMOFpuf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CRcWjXaWoAAfojx.png",
        "id_str" : "655017067641479168",
        "id" : 655017067641479168,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRcWjXaWoAAfojx.png",
        "sizes" : [ {
          "h" : 548,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 182,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1274
        }, {
          "h" : 321,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/c1cNMOFpuf"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/AzHMM8Xjtc",
        "expanded_url" : "http:\/\/www.thomaswilhelm.eu\/shakespeare\/output\/twelfthnight.html",
        "display_url" : "thomaswilhelm.eu\/shakespeare\/ou\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "655017157428912129",
    "geo" : { },
    "id_str" : "655034934327930880",
    "in_reply_to_user_id" : 6146692,
    "text" : "Whoa. Tool for visual analysis of Shakespeare plays http:\/\/t.co\/AzHMM8Xjtc \/via @arnicas http:\/\/t.co\/c1cNMOFpuf",
    "id" : 655034934327930880,
    "in_reply_to_status_id" : 655017157428912129,
    "created_at" : "2015-10-16 14:57:52 +0000",
    "in_reply_to_screen_name" : "arnicas",
    "in_reply_to_user_id_str" : "6146692",
    "user" : {
      "name" : "Chad Weinard",
      "screen_name" : "caw_",
      "protected" : false,
      "id_str" : "18562791",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567429321208233985\/A3gTfO7X_normal.jpeg",
      "id" : 18562791,
      "verified" : false
    }
  },
  "id" : 655037494799564800,
  "created_at" : "2015-10-16 15:08:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jack Grieve",
      "screen_name" : "JWGrieve",
      "indices" : [ 0, 9 ],
      "id_str" : "2950391813",
      "id" : 2950391813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "655022991588335617",
  "geo" : { },
  "id_str" : "655024260369502208",
  "in_reply_to_user_id" : 2950391813,
  "text" : "@JWGrieve what's the sampling period? oh dope maps :)",
  "id" : 655024260369502208,
  "in_reply_to_status_id" : 655022991588335617,
  "created_at" : "2015-10-16 14:15:28 +0000",
  "in_reply_to_screen_name" : "JWGrieve",
  "in_reply_to_user_id_str" : "2950391813",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 74, 82 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/UdBGzoMv2v",
      "expanded_url" : "https:\/\/youtu.be\/9pnt_uT5YzQ",
      "display_url" : "youtu.be\/9pnt_uT5YzQ"
    } ]
  },
  "geo" : { },
  "id_str" : "655017359053320193",
  "text" : "BBC reports on royal family celebrations 2015 https:\/\/t.co\/UdBGzoMv2v via @YouTube",
  "id" : 655017359053320193,
  "created_at" : "2015-10-16 13:48:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 3, 14 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELT",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/VgWoR3Kbhs",
      "expanded_url" : "http:\/\/koreanlearnercorpusblog.blogspot.com\/2013\/01\/hello.html?spref=tw",
      "display_url" : "koreanlearnercorpusblog.blogspot.com\/2013\/01\/hello.\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "655014775164899328",
  "text" : "RT @lexicoloco: Korean Learner Corpus Blog: Learner Corpora Made Easy! http:\/\/t.co\/VgWoR3Kbhs Such a lot of valuable work made openly avail\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELT",
        "indices" : [ 133, 137 ]
      } ],
      "urls" : [ {
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/VgWoR3Kbhs",
        "expanded_url" : "http:\/\/koreanlearnercorpusblog.blogspot.com\/2013\/01\/hello.html?spref=tw",
        "display_url" : "koreanlearnercorpusblog.blogspot.com\/2013\/01\/hello.\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "654973950145994752",
    "text" : "Korean Learner Corpus Blog: Learner Corpora Made Easy! http:\/\/t.co\/VgWoR3Kbhs Such a lot of valuable work made openly available! :-) #ELT",
    "id" : 654973950145994752,
    "created_at" : "2015-10-16 10:55:33 +0000",
    "user" : {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "protected" : false,
      "id_str" : "300734173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2403500097\/3nmx3kjaycyoc7irwe6s_normal.jpeg",
      "id" : 300734173,
      "verified" : false
    }
  },
  "id" : 655014775164899328,
  "created_at" : "2015-10-16 13:37:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "damon_tokyo",
      "screen_name" : "damon_tokyo",
      "indices" : [ 0, 12 ],
      "id_str" : "17856980",
      "id" : 17856980
    }, {
      "name" : "Duygu \u00C7andarl\u0131",
      "screen_name" : "duygucandarli",
      "indices" : [ 13, 27 ],
      "id_str" : "48839094",
      "id" : 48839094
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654753451918778368",
  "in_reply_to_user_id" : 17856980,
  "text" : "@damon_tokyo @duygucandarli thanks for sharing :)",
  "id" : 654753451918778368,
  "created_at" : "2015-10-15 20:19:22 +0000",
  "in_reply_to_screen_name" : "damon_tokyo",
  "in_reply_to_user_id_str" : "17856980",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "indices" : [ 0, 10 ],
      "id_str" : "577931950",
      "id" : 577931950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "654628887796797444",
  "geo" : { },
  "id_str" : "654753317554294784",
  "in_reply_to_user_id" : 577931950,
  "text" : "@RudyLoock yr welcome, yep i think AntConc is still tough to beat in its class",
  "id" : 654753317554294784,
  "in_reply_to_status_id" : 654628887796797444,
  "created_at" : "2015-10-15 20:18:50 +0000",
  "in_reply_to_screen_name" : "RudyLoock",
  "in_reply_to_user_id_str" : "577931950",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 0, 15 ],
      "id_str" : "285614027",
      "id" : 285614027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "654635974501212160",
  "geo" : { },
  "id_str" : "654752911155576837",
  "in_reply_to_user_id" : 285614027,
  "text" : "@AnthonyTeacher a pleasure it's a great write-up :)",
  "id" : 654752911155576837,
  "in_reply_to_status_id" : 654635974501212160,
  "created_at" : "2015-10-15 20:17:13 +0000",
  "in_reply_to_screen_name" : "AnthonyTeacher",
  "in_reply_to_user_id_str" : "285614027",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 45, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/QSJitqVKHW",
      "expanded_url" : "https:\/\/plus.google.com\/+MuraNava\/posts\/VfjHSdfv9SG",
      "display_url" : "plus.google.com\/+MuraNava\/post\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "654627759575183360",
  "text" : "Antconc Alternatives https:\/\/t.co\/QSJitqVKHW #corpusmooc",
  "id" : 654627759575183360,
  "created_at" : "2015-10-15 11:59:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Avery",
      "screen_name" : "Toms_elt",
      "indices" : [ 69, 78 ],
      "id_str" : "1004068988",
      "id" : 1004068988
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/rSyf0fqaSU",
      "expanded_url" : "http:\/\/wp.me\/p2Z88c-5h",
      "display_url" : "wp.me\/p2Z88c-5h"
    } ]
  },
  "geo" : { },
  "id_str" : "654615584534097922",
  "text" : "Rotating Students in Class - A Solution!: http:\/\/t.co\/rSyf0fqaSU via @Toms_elt",
  "id" : 654615584534097922,
  "created_at" : "2015-10-15 11:11:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 0, 9 ],
      "id_str" : "121063600",
      "id" : 121063600
    }, {
      "name" : "Juergen Wagner",
      "screen_name" : "wagjuer",
      "indices" : [ 10, 18 ],
      "id_str" : "31678345",
      "id" : 31678345
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "654582132422131713",
  "geo" : { },
  "id_str" : "654587738994417664",
  "in_reply_to_user_id" : 121063600,
  "text" : "@whyshona @wagjuer it's quite complex software suited for linguistics than ELT; OSX usrs cld try casualconc as alt to antconc",
  "id" : 654587738994417664,
  "in_reply_to_status_id" : 654582132422131713,
  "created_at" : "2015-10-15 09:20:53 +0000",
  "in_reply_to_screen_name" : "whyshona",
  "in_reply_to_user_id_str" : "121063600",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/ZRK237p5z1",
      "expanded_url" : "http:\/\/xsavikx.github.io\/AndroidScreencast\/",
      "display_url" : "xsavikx.github.io\/AndroidScreenc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "654289266672054274",
  "text" : "if anyone wants to display their android phone on their pc (via usb cable) this is a working option - http:\/\/t.co\/ZRK237p5z1",
  "id" : 654289266672054274,
  "created_at" : "2015-10-14 13:34:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Thornbury",
      "screen_name" : "thornburyscott",
      "indices" : [ 3, 18 ],
      "id_str" : "23090474",
      "id" : 23090474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/tWNZhv3swt",
      "expanded_url" : "http:\/\/www.regents.ac.uk\/events\/the-future-of-english-language-teaching.aspx",
      "display_url" : "regents.ac.uk\/events\/the-fut\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "654287210976538624",
  "text" : "RT @thornburyscott: Coming soon: The Future of ELT - http:\/\/t.co\/tWNZhv3swt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 55 ],
        "url" : "http:\/\/t.co\/tWNZhv3swt",
        "expanded_url" : "http:\/\/www.regents.ac.uk\/events\/the-future-of-english-language-teaching.aspx",
        "display_url" : "regents.ac.uk\/events\/the-fut\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "654257923510693888",
    "text" : "Coming soon: The Future of ELT - http:\/\/t.co\/tWNZhv3swt",
    "id" : 654257923510693888,
    "created_at" : "2015-10-14 11:30:19 +0000",
    "user" : {
      "name" : "Scott Thornbury",
      "screen_name" : "thornburyscott",
      "protected" : false,
      "id_str" : "23090474",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892392697\/twitter03_normal.jpg",
      "id" : 23090474,
      "verified" : false
    }
  },
  "id" : 654287210976538624,
  "created_at" : "2015-10-14 13:26:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John McWhorter",
      "screen_name" : "JohnHMcWhorter",
      "indices" : [ 3, 18 ],
      "id_str" : "1306199515",
      "id" : 1306199515
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/c7P4FAQk83",
      "expanded_url" : "http:\/\/econ.st\/1L8S6gi",
      "display_url" : "econ.st\/1L8S6gi"
    } ]
  },
  "geo" : { },
  "id_str" : "654145661114449920",
  "text" : "RT @JohnHMcWhorter: Great piece even if it didn't cite me - learning languages is not just words or phrases but CHUNKS like MIGHT AS WELL h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/c7P4FAQk83",
        "expanded_url" : "http:\/\/econ.st\/1L8S6gi",
        "display_url" : "econ.st\/1L8S6gi"
      } ]
    },
    "geo" : { },
    "id_str" : "651001842801860609",
    "text" : "Great piece even if it didn't cite me - learning languages is not just words or phrases but CHUNKS like MIGHT AS WELL http:\/\/t.co\/c7P4FAQk83",
    "id" : 651001842801860609,
    "created_at" : "2015-10-05 11:51:49 +0000",
    "user" : {
      "name" : "John McWhorter",
      "screen_name" : "JohnHMcWhorter",
      "protected" : false,
      "id_str" : "1306199515",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/467518886448230400\/qE5Zy-V6_normal.jpeg",
      "id" : 1306199515,
      "verified" : false
    }
  },
  "id" : 654145661114449920,
  "created_at" : "2015-10-14 04:04:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 3, 18 ],
      "id_str" : "285614027",
      "id" : 285614027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/ZJ8P66B1jp",
      "expanded_url" : "http:\/\/ift.tt\/1G4bniN",
      "display_url" : "ift.tt\/1G4bniN"
    } ]
  },
  "geo" : { },
  "id_str" : "654136637794971648",
  "text" : "RT @AnthonyTeacher: Riding the ARC: Experiences with Academic Reading Circles http:\/\/t.co\/ZJ8P66B1jp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/ZJ8P66B1jp",
        "expanded_url" : "http:\/\/ift.tt\/1G4bniN",
        "display_url" : "ift.tt\/1G4bniN"
      } ]
    },
    "geo" : { },
    "id_str" : "654094267028213760",
    "text" : "Riding the ARC: Experiences with Academic Reading Circles http:\/\/t.co\/ZJ8P66B1jp",
    "id" : 654094267028213760,
    "created_at" : "2015-10-14 00:40:00 +0000",
    "user" : {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "protected" : false,
      "id_str" : "285614027",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/412336845658132481\/Om5kKuMQ_normal.jpeg",
      "id" : 285614027,
      "verified" : false
    }
  },
  "id" : 654136637794971648,
  "created_at" : "2015-10-14 03:28:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenys Hanson",
      "screen_name" : "GlenysHanson",
      "indices" : [ 0, 13 ],
      "id_str" : "527238447",
      "id" : 527238447
    }, {
      "name" : "Nurph",
      "screen_name" : "Nurph",
      "indices" : [ 14, 20 ],
      "id_str" : "164768029",
      "id" : 164768029
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "653672464715784192",
  "geo" : { },
  "id_str" : "653674756873584640",
  "in_reply_to_user_id" : 527238447,
  "text" : "@GlenysHanson @Nurph will check out thx",
  "id" : 653674756873584640,
  "in_reply_to_status_id" : 653672464715784192,
  "created_at" : "2015-10-12 20:53:01 +0000",
  "in_reply_to_screen_name" : "GlenysHanson",
  "in_reply_to_user_id_str" : "527238447",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchinwag",
      "indices" : [ 13, 24 ]
    }, {
      "text" : "rememberingtoolatetoaddhashtag",
      "indices" : [ 25, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "653671503037341697",
  "text" : "thanks folks #eltchinwag #rememberingtoolatetoaddhashtag",
  "id" : 653671503037341697,
  "created_at" : "2015-10-12 20:40:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchinwag",
      "indices" : [ 77, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/81EphJ83FD",
      "expanded_url" : "http:\/\/www.pckwck.com\/",
      "display_url" : "pckwck.com"
    } ]
  },
  "geo" : { },
  "id_str" : "653668226447110144",
  "text" : "interesting online live writing http:\/\/t.co\/81EphJ83FD with live feedback :0 #eltchinwag",
  "id" : 653668226447110144,
  "created_at" : "2015-10-12 20:27:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELT IRELAND",
      "screen_name" : "ELTIreland",
      "indices" : [ 0, 11 ],
      "id_str" : "2289260958",
      "id" : 2289260958
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/akvLphqxDS",
      "expanded_url" : "https:\/\/gianfrancoconti.wordpress.com\/2015\/07\/30\/l-i-f-t-an-effective-writing-proficiency-and-metacognition-enhancer\/",
      "display_url" : "gianfrancoconti.wordpress.com\/2015\/07\/30\/l-i\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "653664752514826241",
  "geo" : { },
  "id_str" : "653665633645805568",
  "in_reply_to_user_id" : 2289260958,
  "text" : "@ELTIreland there's an interesting approach called learner initiated feedback https:\/\/t.co\/akvLphqxDS",
  "id" : 653665633645805568,
  "in_reply_to_status_id" : 653664752514826241,
  "created_at" : "2015-10-12 20:16:46 +0000",
  "in_reply_to_screen_name" : "ELTIreland",
  "in_reply_to_user_id_str" : "2289260958",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Lahiff",
      "screen_name" : "LahiffP",
      "indices" : [ 0, 8 ],
      "id_str" : "279078759",
      "id" : 279078759
    }, {
      "name" : "ELT IRELAND",
      "screen_name" : "ELTIreland",
      "indices" : [ 9, 20 ],
      "id_str" : "2289260958",
      "id" : 2289260958
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "653657810639695874",
  "geo" : { },
  "id_str" : "653662249849126912",
  "in_reply_to_user_id" : 279078759,
  "text" : "@LahiffP @ELTIreland strange not thought to think about time, conditioned for word count! will change up, thx",
  "id" : 653662249849126912,
  "in_reply_to_status_id" : 653657810639695874,
  "created_at" : "2015-10-12 20:03:19 +0000",
  "in_reply_to_screen_name" : "LahiffP",
  "in_reply_to_user_id_str" : "279078759",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nic Subtirelu",
      "screen_name" : "linguisticpulse",
      "indices" : [ 3, 19 ],
      "id_str" : "1400748798",
      "id" : 1400748798
    }, {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 62, 70 ],
      "id_str" : "807095",
      "id" : 807095
    }, {
      "name" : "nytlabs",
      "screen_name" : "nytlabs",
      "indices" : [ 101, 109 ],
      "id_str" : "673953",
      "id" : 673953
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/linguisticpulse\/status\/653655551058927616\/photo\/1",
      "indices" : [ 124, 140 ],
      "url" : "http:\/\/t.co\/lcyS5imcyR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRJAQogUsAA9gzX.png",
      "id_str" : "653655550417219584",
      "id" : 653655550417219584,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRJAQogUsAA9gzX.png",
      "sizes" : [ {
        "h" : 500,
        "resize" : "fit",
        "w" : 850
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 850
      }, {
        "h" : 353,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 200,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/lcyS5imcyR"
    } ],
    "hashtags" : [ {
      "text" : "nytchronicle",
      "indices" : [ 110, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/YacuzYhe1d",
      "expanded_url" : "http:\/\/bit.ly\/1GEozWu",
      "display_url" : "bit.ly\/1GEozWu"
    } ]
  },
  "geo" : { },
  "id_str" : "653660132316999684",
  "text" : "RT @linguisticpulse: why has the word CITIZEN declined in the @nytimes? -- http:\/\/t.co\/YacuzYhe1d -- @nytlabs #nytchronicle http:\/\/t.co\/lcy\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The New York Times",
        "screen_name" : "nytimes",
        "indices" : [ 41, 49 ],
        "id_str" : "807095",
        "id" : 807095
      }, {
        "name" : "nytlabs",
        "screen_name" : "nytlabs",
        "indices" : [ 80, 88 ],
        "id_str" : "673953",
        "id" : 673953
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/linguisticpulse\/status\/653655551058927616\/photo\/1",
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/lcyS5imcyR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CRJAQogUsAA9gzX.png",
        "id_str" : "653655550417219584",
        "id" : 653655550417219584,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRJAQogUsAA9gzX.png",
        "sizes" : [ {
          "h" : 500,
          "resize" : "fit",
          "w" : 850
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 850
        }, {
          "h" : 353,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 200,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/lcyS5imcyR"
      } ],
      "hashtags" : [ {
        "text" : "nytchronicle",
        "indices" : [ 89, 102 ]
      } ],
      "urls" : [ {
        "indices" : [ 54, 76 ],
        "url" : "http:\/\/t.co\/YacuzYhe1d",
        "expanded_url" : "http:\/\/bit.ly\/1GEozWu",
        "display_url" : "bit.ly\/1GEozWu"
      } ]
    },
    "geo" : { },
    "id_str" : "653655551058927616",
    "text" : "why has the word CITIZEN declined in the @nytimes? -- http:\/\/t.co\/YacuzYhe1d -- @nytlabs #nytchronicle http:\/\/t.co\/lcyS5imcyR",
    "id" : 653655551058927616,
    "created_at" : "2015-10-12 19:36:42 +0000",
    "user" : {
      "name" : "Nic Subtirelu",
      "screen_name" : "linguisticpulse",
      "protected" : false,
      "id_str" : "1400748798",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3609632834\/4ae2ef11e9cffa43e820f3ef7e18b016_normal.jpeg",
      "id" : 1400748798,
      "verified" : false
    }
  },
  "id" : 653660132316999684,
  "created_at" : "2015-10-12 19:54:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clare",
      "screen_name" : "languageeteach",
      "indices" : [ 0, 15 ],
      "id_str" : "2163604968",
      "id" : 2163604968
    }, {
      "name" : "AoifELT",
      "screen_name" : "aoifELT",
      "indices" : [ 16, 24 ],
      "id_str" : "2778062817",
      "id" : 2778062817
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "653658637500596224",
  "geo" : { },
  "id_str" : "653659715755462656",
  "in_reply_to_user_id" : 2163604968,
  "text" : "@languageeteach @aoifELT hoping to combine wiki with colloborative writing soonish inclass; any tips?",
  "id" : 653659715755462656,
  "in_reply_to_status_id" : 653658637500596224,
  "created_at" : "2015-10-12 19:53:15 +0000",
  "in_reply_to_screen_name" : "languageeteach",
  "in_reply_to_user_id_str" : "2163604968",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eily Murphy",
      "screen_name" : "eilymurphy",
      "indices" : [ 0, 11 ],
      "id_str" : "111091623",
      "id" : 111091623
    }, {
      "name" : "ELT IRELAND",
      "screen_name" : "ELTIreland",
      "indices" : [ 12, 23 ],
      "id_str" : "2289260958",
      "id" : 2289260958
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "653658308159623168",
  "geo" : { },
  "id_str" : "653659461152804865",
  "in_reply_to_user_id" : 111091623,
  "text" : "@eilymurphy @ELTIreland yeah and what to do with other students whilst you correct? so far only asked them to read each others",
  "id" : 653659461152804865,
  "in_reply_to_status_id" : 653658308159623168,
  "created_at" : "2015-10-12 19:52:14 +0000",
  "in_reply_to_screen_name" : "eilymurphy",
  "in_reply_to_user_id_str" : "111091623",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Lahiff",
      "screen_name" : "LahiffP",
      "indices" : [ 0, 8 ],
      "id_str" : "279078759",
      "id" : 279078759
    }, {
      "name" : "Eily Murphy",
      "screen_name" : "eilymurphy",
      "indices" : [ 9, 20 ],
      "id_str" : "111091623",
      "id" : 111091623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "653658064189566976",
  "geo" : { },
  "id_str" : "653659005152268288",
  "in_reply_to_user_id" : 279078759,
  "text" : "@LahiffP @eilymurphy also possibly more contemporary writing? social media, wikis, you tube commenting?",
  "id" : 653659005152268288,
  "in_reply_to_status_id" : 653658064189566976,
  "created_at" : "2015-10-12 19:50:25 +0000",
  "in_reply_to_screen_name" : "LahiffP",
  "in_reply_to_user_id_str" : "279078759",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "653643248540471297",
  "geo" : { },
  "id_str" : "653645932303654917",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco i knew there was a reason i was asking you thx :)",
  "id" : 653645932303654917,
  "in_reply_to_status_id" : 653643248540471297,
  "created_at" : "2015-10-12 18:58:29 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "653640126539632641",
  "geo" : { },
  "id_str" : "653641157252136960",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco if i had the time for sure :\/ is there am agreed set of standards for error tagging in learner corpora?",
  "id" : 653641157252136960,
  "in_reply_to_status_id" : 653640126539632641,
  "created_at" : "2015-10-12 18:39:30 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "653588680444112896",
  "geo" : { },
  "id_str" : "653638375883284480",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco now there's an idea :)",
  "id" : 653638375883284480,
  "in_reply_to_status_id" : 653588680444112896,
  "created_at" : "2015-10-12 18:28:27 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/etgVVwrvin",
      "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2015\/10\/a-labour-moderate.html",
      "display_url" : "thecurmudgeonly.blogspot.co.uk\/2015\/10\/a-labo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "653635829177413632",
  "text" : "RT @pchallinor: New mudgeonry: A Labour moderate http:\/\/t.co\/etgVVwrvin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 55 ],
        "url" : "http:\/\/t.co\/etgVVwrvin",
        "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2015\/10\/a-labour-moderate.html",
        "display_url" : "thecurmudgeonly.blogspot.co.uk\/2015\/10\/a-labo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "653624757586423808",
    "text" : "New mudgeonry: A Labour moderate http:\/\/t.co\/etgVVwrvin",
    "id" : 653624757586423808,
    "created_at" : "2015-10-12 17:34:20 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 653635829177413632,
  "created_at" : "2015-10-12 18:18:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "653561787040800768",
  "geo" : { },
  "id_str" : "653574439418888192",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco interested in both especially though a simple way for teachers to enter a database of tags",
  "id" : 653574439418888192,
  "in_reply_to_status_id" : 653561787040800768,
  "created_at" : "2015-10-12 14:14:23 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/MFc3p4UwHs",
      "expanded_url" : "http:\/\/www.uam.es\/proyectosinv\/treacle\/error.html",
      "display_url" : "uam.es\/proyectosinv\/t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "653555053912018944",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco do u know of any \"simple\" error tagging workflows? i found this one http:\/\/t.co\/MFc3p4UwHs uses UAMcorpustool a bit clunky thx!",
  "id" : 653555053912018944,
  "created_at" : "2015-10-12 12:57:21 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/653551152777306112\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/zxz8J2P2vW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRHhT0aWcAEeEzC.png",
      "id_str" : "653551151548362753",
      "id" : 653551151548362753,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRHhT0aWcAEeEzC.png",
      "sizes" : [ {
        "h" : 93,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 115,
        "resize" : "fit",
        "w" : 741
      }, {
        "h" : 115,
        "resize" : "fit",
        "w" : 741
      }, {
        "h" : 53,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 115,
        "resize" : "crop",
        "w" : 115
      } ],
      "display_url" : "pic.twitter.com\/zxz8J2P2vW"
    } ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 103, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/HLLZFp8e4H",
      "expanded_url" : "http:\/\/ro.ecu.edu.au\/cgi\/viewcontent.cgi?article=2558&context=ajte#14",
      "display_url" : "ro.ecu.edu.au\/cgi\/viewconten\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "653551152777306112",
  "text" : "interesting eg of \"priming\" in the wild from that Aussie teacher literacy study http:\/\/t.co\/HLLZFp8e4H #corpusmooc http:\/\/t.co\/zxz8J2P2vW",
  "id" : 653551152777306112,
  "created_at" : "2015-10-12 12:41:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Freeman",
      "screen_name" : "SnoozeInBrief",
      "indices" : [ 76, 90 ],
      "id_str" : "82947233",
      "id" : 82947233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/zWeGRcY6S6",
      "expanded_url" : "http:\/\/wp.me\/p1l5Kr-8C",
      "display_url" : "wp.me\/p1l5Kr-8C"
    } ]
  },
  "geo" : { },
  "id_str" : "653477179884445700",
  "text" : "Contractions: which are common and which aren\u2019t? http:\/\/t.co\/zWeGRcY6S6 via @SnoozeInBrief",
  "id" : 653477179884445700,
  "created_at" : "2015-10-12 07:47:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Roy Douglas",
      "screen_name" : "scottroydouglas",
      "indices" : [ 0, 16 ],
      "id_str" : "1263168308",
      "id" : 1263168308
    }, {
      "name" : "BCTEAL",
      "screen_name" : "bcteal",
      "indices" : [ 17, 24 ],
      "id_str" : "24464151",
      "id" : 24464151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/UnFPvWauFL",
      "expanded_url" : "https:\/\/www.bcteal.org\/wp-content\/uploads\/2015\/10\/BCTeal-Newsletter-Fall-2015-Final-2.pdf#16",
      "display_url" : "bcteal.org\/wp-content\/upl\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "653284710735462400",
  "geo" : { },
  "id_str" : "653286158105989120",
  "in_reply_to_user_id" : 1263168308,
  "text" : "@scottroydouglas @bcteal hi fyi u can go to pdf pages by using hashmark and page no. like so https:\/\/t.co\/UnFPvWauFL",
  "id" : 653286158105989120,
  "in_reply_to_status_id" : 653284710735462400,
  "created_at" : "2015-10-11 19:08:52 +0000",
  "in_reply_to_screen_name" : "scottroydouglas",
  "in_reply_to_user_id_str" : "1263168308",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Bennett",
      "screen_name" : "tombennett71",
      "indices" : [ 0, 13 ],
      "id_str" : "208996041",
      "id" : 208996041
    }, {
      "name" : "Daisy Christodoulou",
      "screen_name" : "daisychristo",
      "indices" : [ 14, 27 ],
      "id_str" : "220830660",
      "id" : 220830660
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "653260678132813824",
  "geo" : { },
  "id_str" : "653284870064574464",
  "in_reply_to_user_id" : 208996041,
  "text" : "@tombennett71 @daisychristo hang on do non-humans create tests? : )",
  "id" : 653284870064574464,
  "in_reply_to_status_id" : 653260678132813824,
  "created_at" : "2015-10-11 19:03:45 +0000",
  "in_reply_to_screen_name" : "tombennett71",
  "in_reply_to_user_id_str" : "208996041",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Emersberger",
      "screen_name" : "rosendo_joe",
      "indices" : [ 3, 15 ],
      "id_str" : "3351345863",
      "id" : 3351345863
    }, {
      "name" : "Jeremy Corbyn MP",
      "screen_name" : "jeremycorbyn",
      "indices" : [ 61, 74 ],
      "id_str" : "117777690",
      "id" : 117777690
    }, {
      "name" : "Rafael Correa",
      "screen_name" : "MashiRafael",
      "indices" : [ 92, 104 ],
      "id_str" : "209780362",
      "id" : 209780362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/HmVG7xCg7u",
      "expanded_url" : "http:\/\/www.telesurtv.net\/english\/opinion\/Rafael-Correa-Provides-Lessons-About-Battling-Hostile-Media-20151011-0009.html",
      "display_url" : "telesurtv.net\/english\/opinio\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "653278361712726016",
  "text" : "RT @rosendo_joe: my latest for Telesur: basically about what @jeremycorbyn could learn from @MashiRafael \nhttp:\/\/t.co\/HmVG7xCg7u",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jeremy Corbyn MP",
        "screen_name" : "jeremycorbyn",
        "indices" : [ 44, 57 ],
        "id_str" : "117777690",
        "id" : 117777690
      }, {
        "name" : "Rafael Correa",
        "screen_name" : "MashiRafael",
        "indices" : [ 75, 87 ],
        "id_str" : "209780362",
        "id" : 209780362
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/HmVG7xCg7u",
        "expanded_url" : "http:\/\/www.telesurtv.net\/english\/opinion\/Rafael-Correa-Provides-Lessons-About-Battling-Hostile-Media-20151011-0009.html",
        "display_url" : "telesurtv.net\/english\/opinio\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "653267003311063042",
    "text" : "my latest for Telesur: basically about what @jeremycorbyn could learn from @MashiRafael \nhttp:\/\/t.co\/HmVG7xCg7u",
    "id" : 653267003311063042,
    "created_at" : "2015-10-11 17:52:45 +0000",
    "user" : {
      "name" : "Joe Emersberger",
      "screen_name" : "rosendo_joe",
      "protected" : false,
      "id_str" : "3351345863",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/621112707522142209\/OGmLR1xt_normal.jpg",
      "id" : 3351345863,
      "verified" : false
    }
  },
  "id" : 653278361712726016,
  "created_at" : "2015-10-11 18:37:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Costas Gabrielatos",
      "screen_name" : "congabonga",
      "indices" : [ 0, 11 ],
      "id_str" : "187484412",
      "id" : 187484412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "653243478005153792",
  "geo" : { },
  "id_str" : "653244130651435008",
  "in_reply_to_user_id" : 187484412,
  "text" : "@congabonga true that, do you have a number for size?",
  "id" : 653244130651435008,
  "in_reply_to_status_id" : 653243478005153792,
  "created_at" : "2015-10-11 16:21:52 +0000",
  "in_reply_to_screen_name" : "congabonga",
  "in_reply_to_user_id_str" : "187484412",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Costas Gabrielatos",
      "screen_name" : "congabonga",
      "indices" : [ 0, 11 ],
      "id_str" : "187484412",
      "id" : 187484412
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/653242220926136324\/photo\/1",
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/8JIVnMHt8Q",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRDIVo0XAAA-Utb.png",
      "id_str" : "653242220028559360",
      "id" : 653242220028559360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRDIVo0XAAA-Utb.png",
      "sizes" : [ {
        "h" : 124,
        "resize" : "fit",
        "w" : 132
      }, {
        "h" : 124,
        "resize" : "fit",
        "w" : 132
      }, {
        "h" : 124,
        "resize" : "crop",
        "w" : 124
      }, {
        "h" : 124,
        "resize" : "fit",
        "w" : 132
      }, {
        "h" : 124,
        "resize" : "fit",
        "w" : 132
      } ],
      "display_url" : "pic.twitter.com\/8JIVnMHt8Q"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "653214182830120960",
  "geo" : { },
  "id_str" : "653242220926136324",
  "in_reply_to_user_id" : 187484412,
  "text" : "@congabonga r u talking about odds of association? if so which one? : ) http:\/\/t.co\/8JIVnMHt8Q",
  "id" : 653242220926136324,
  "in_reply_to_status_id" : 653214182830120960,
  "created_at" : "2015-10-11 16:14:16 +0000",
  "in_reply_to_screen_name" : "congabonga",
  "in_reply_to_user_id_str" : "187484412",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 5, 16 ]
    } ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/Vgj22dZyQT",
      "expanded_url" : "https:\/\/plus.google.com\/+MuraNava\/posts\/hE7fWK7S1ei",
      "display_url" : "plus.google.com\/+MuraNava\/post\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "653237942354317313",
  "text" : "some #corpusmooc gems https:\/\/t.co\/Vgj22dZyQT",
  "id" : 653237942354317313,
  "created_at" : "2015-10-11 15:57:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Apps 4 EFL",
      "screen_name" : "apps4efl",
      "indices" : [ 3, 12 ],
      "id_str" : "2594237072",
      "id" : 2594237072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/DGBDTy18ip",
      "expanded_url" : "https:\/\/youtu.be\/mUT4ySJARQo",
      "display_url" : "youtu.be\/mUT4ySJARQo"
    } ]
  },
  "geo" : { },
  "id_str" : "653198687481516033",
  "text" : "RT @apps4efl: Apps 4 EFL utilizes creative commons data and new web technologies to facilitate innovative online English study. https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/DGBDTy18ip",
        "expanded_url" : "https:\/\/youtu.be\/mUT4ySJARQo",
        "display_url" : "youtu.be\/mUT4ySJARQo"
      } ]
    },
    "geo" : { },
    "id_str" : "652866594377363457",
    "text" : "Apps 4 EFL utilizes creative commons data and new web technologies to facilitate innovative online English study. https:\/\/t.co\/DGBDTy18ip",
    "id" : 652866594377363457,
    "created_at" : "2015-10-10 15:21:40 +0000",
    "user" : {
      "name" : "Apps 4 EFL",
      "screen_name" : "apps4efl",
      "protected" : false,
      "id_str" : "2594237072",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/652102680504963072\/peqnCRQT_normal.png",
      "id" : 2594237072,
      "verified" : false
    }
  },
  "id" : 653198687481516033,
  "created_at" : "2015-10-11 13:21:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike S. Boyle",
      "screen_name" : "heyboyle",
      "indices" : [ 0, 9 ],
      "id_str" : "612840231",
      "id" : 612840231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "653196118059257856",
  "geo" : { },
  "id_str" : "653198364025163776",
  "in_reply_to_user_id" : 612840231,
  "text" : "@heyboyle or also never send a full-time professor to do an adjunct professor's job :\/",
  "id" : 653198364025163776,
  "in_reply_to_status_id" : 653196118059257856,
  "created_at" : "2015-10-11 13:20:00 +0000",
  "in_reply_to_screen_name" : "heyboyle",
  "in_reply_to_user_id_str" : "612840231",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 8, 19 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "652582307480641536",
  "text" : "only on #corpusmooc some 6months of motoring : )",
  "id" : 652582307480641536,
  "created_at" : "2015-10-09 20:32:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 0, 10 ],
      "id_str" : "525274103",
      "id" : 525274103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "652426186182688768",
  "geo" : { },
  "id_str" : "652449064383053824",
  "in_reply_to_user_id" : 525274103,
  "text" : "@ElkySmith yeah no big surprises here unless u are really into \"culturonomics\" ugh what a word :\/",
  "id" : 652449064383053824,
  "in_reply_to_status_id" : 652426186182688768,
  "created_at" : "2015-10-09 11:42:33 +0000",
  "in_reply_to_screen_name" : "ElkySmith",
  "in_reply_to_user_id_str" : "525274103",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reggie Ugwu",
      "screen_name" : "uugwuu",
      "indices" : [ 91, 98 ],
      "id_str" : "78956001",
      "id" : 78956001
    }, {
      "name" : "BuzzFeed",
      "screen_name" : "BuzzFeed",
      "indices" : [ 99, 108 ],
      "id_str" : "5695632",
      "id" : 5695632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/JnAu42e0Kp",
      "expanded_url" : "http:\/\/www.buzzfeed.com\/reggieugwu\/what-is-indie-pop-voice?utm_term=.ov4Wj80GW",
      "display_url" : "buzzfeed.com\/reggieugwu\/wha\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "652342281257795584",
  "text" : "Selena Gomez\u2019s \u201CGood For You\u201D And The Rise Of \u201CIndie Pop Voice\u201D http:\/\/t.co\/JnAu42e0Kp via @uugwuu @buzzfeed",
  "id" : 652342281257795584,
  "created_at" : "2015-10-09 04:38:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Collins",
      "screen_name" : "jennifer_collie",
      "indices" : [ 0, 16 ],
      "id_str" : "1172317224",
      "id" : 1172317224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "652142232217088000",
  "geo" : { },
  "id_str" : "652199547482017793",
  "in_reply_to_user_id" : 1172317224,
  "text" : "@jennifer_collie hi Jennifer yr welcome :)",
  "id" : 652199547482017793,
  "in_reply_to_status_id" : 652142232217088000,
  "created_at" : "2015-10-08 19:11:04 +0000",
  "in_reply_to_screen_name" : "jennifer_collie",
  "in_reply_to_user_id_str" : "1172317224",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EFL Magazine",
      "screen_name" : "eflmagazine",
      "indices" : [ 3, 15 ],
      "id_str" : "2879372766",
      "id" : 2879372766
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/eflmagazine\/status\/652141955887968256\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/l2AHlqd3dx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQzfpuNUwAEolIc.jpg",
      "id_str" : "652141953933426689",
      "id" : 652141953933426689,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQzfpuNUwAEolIc.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1673,
        "resize" : "fit",
        "w" : 2509
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/l2AHlqd3dx"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/khE4GY5dJI",
      "expanded_url" : "http:\/\/eflmagazine.com\/tailors-not-rich-salaries-conditions-elt-trainers-france\/",
      "display_url" : "eflmagazine.com\/tailors-not-ri\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "652143031345221634",
  "text" : "RT @eflmagazine: http:\/\/t.co\/khE4GY5dJI\nMy Tailor is not so Rich : Salaries and Conditions for ELT Trainers in France http:\/\/t.co\/l2AHlqd3dx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/eflmagazine\/status\/652141955887968256\/photo\/1",
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/l2AHlqd3dx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQzfpuNUwAEolIc.jpg",
        "id_str" : "652141953933426689",
        "id" : 652141953933426689,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQzfpuNUwAEolIc.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1673,
          "resize" : "fit",
          "w" : 2509
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/l2AHlqd3dx"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/khE4GY5dJI",
        "expanded_url" : "http:\/\/eflmagazine.com\/tailors-not-rich-salaries-conditions-elt-trainers-france\/",
        "display_url" : "eflmagazine.com\/tailors-not-ri\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "652141955887968256",
    "text" : "http:\/\/t.co\/khE4GY5dJI\nMy Tailor is not so Rich : Salaries and Conditions for ELT Trainers in France http:\/\/t.co\/l2AHlqd3dx",
    "id" : 652141955887968256,
    "created_at" : "2015-10-08 15:22:13 +0000",
    "user" : {
      "name" : "EFL Magazine",
      "screen_name" : "eflmagazine",
      "protected" : false,
      "id_str" : "2879372766",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/566909861871366144\/YQt7EAWR_normal.jpeg",
      "id" : 2879372766,
      "verified" : false
    }
  },
  "id" : 652143031345221634,
  "created_at" : "2015-10-08 15:26:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoff Jordan",
      "screen_name" : "GeoffJordan",
      "indices" : [ 40, 52 ],
      "id_str" : "29510765",
      "id" : 29510765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/NjPbz0axop",
      "expanded_url" : "http:\/\/wp.me\/p3qkCB-1nQ",
      "display_url" : "wp.me\/p3qkCB-1nQ"
    } ]
  },
  "geo" : { },
  "id_str" : "652113296234008577",
  "text" : "Three Cheers http:\/\/t.co\/NjPbz0axop via @GeoffJordan",
  "id" : 652113296234008577,
  "created_at" : "2015-10-08 13:28:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HaveUread",
      "screen_name" : "thisbyanychance",
      "indices" : [ 0, 16 ],
      "id_str" : "3416415189",
      "id" : 3416415189
    }, {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 22, 36 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edtech",
      "indices" : [ 45, 52 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "651506415778013184",
  "geo" : { },
  "id_str" : "651901381020921858",
  "in_reply_to_user_id" : 25388528,
  "text" : "@thisbyanychance tell @audreywatters to tell #edtech about Dale cone",
  "id" : 651901381020921858,
  "in_reply_to_status_id" : 651506415778013184,
  "created_at" : "2015-10-07 23:26:15 +0000",
  "in_reply_to_screen_name" : "audreywatters",
  "in_reply_to_user_id_str" : "25388528",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 3, 17 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651900924034686976",
  "text" : "RT @audreywatters: Watching the Gates Foundation edu event\u2019s live tweeting: all I can think about is sycophants-as-a-service",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "651800372957310976",
    "text" : "Watching the Gates Foundation edu event\u2019s live tweeting: all I can think about is sycophants-as-a-service",
    "id" : 651800372957310976,
    "created_at" : "2015-10-07 16:44:53 +0000",
    "user" : {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "protected" : false,
      "id_str" : "25388528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711668009723498496\/pauFZsdv_normal.jpg",
      "id" : 25388528,
      "verified" : false
    }
  },
  "id" : 651900924034686976,
  "created_at" : "2015-10-07 23:24:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bella Caledonia",
      "screen_name" : "bellacaledonia",
      "indices" : [ 78, 93 ],
      "id_str" : "103554348",
      "id" : 103554348
    }, {
      "name" : "Citizen Moodie",
      "screen_name" : "gregmoodie",
      "indices" : [ 139, 140 ],
      "id_str" : "17438575",
      "id" : 17438575
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CPC15",
      "indices" : [ 121, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/Aio9YszmFE",
      "expanded_url" : "http:\/\/bellacaledonia.org.uk\/2015\/10\/07\/moodievision-we-are-the-rich\/",
      "display_url" : "bellacaledonia.org.uk\/2015\/10\/07\/moo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "651895824843206656",
  "text" : "RT @JockistaniAnnie: MoodieVision: We Are The Rich http:\/\/t.co\/Aio9YszmFE via @bellacaledonia\n\nA Musical Distillation of #CPC15 by the geni\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bella Caledonia",
        "screen_name" : "bellacaledonia",
        "indices" : [ 57, 72 ],
        "id_str" : "103554348",
        "id" : 103554348
      }, {
        "name" : "Citizen Moodie",
        "screen_name" : "gregmoodie",
        "indices" : [ 121, 132 ],
        "id_str" : "17438575",
        "id" : 17438575
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CPC15",
        "indices" : [ 100, 106 ]
      } ],
      "urls" : [ {
        "indices" : [ 30, 52 ],
        "url" : "http:\/\/t.co\/Aio9YszmFE",
        "expanded_url" : "http:\/\/bellacaledonia.org.uk\/2015\/10\/07\/moodievision-we-are-the-rich\/",
        "display_url" : "bellacaledonia.org.uk\/2015\/10\/07\/moo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "651894281607737344",
    "text" : "MoodieVision: We Are The Rich http:\/\/t.co\/Aio9YszmFE via @bellacaledonia\n\nA Musical Distillation of #CPC15 by the genius @GregMoodie",
    "id" : 651894281607737344,
    "created_at" : "2015-10-07 22:58:03 +0000",
    "user" : {
      "name" : "Anne Thomasdottir",
      "screen_name" : "SovereignAnnie",
      "protected" : false,
      "id_str" : "866839813",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727218440948322310\/lNTkIZG3_normal.jpg",
      "id" : 866839813,
      "verified" : false
    }
  },
  "id" : 651895824843206656,
  "created_at" : "2015-10-07 23:04:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yasu",
      "screen_name" : "casualconc",
      "indices" : [ 0, 11 ],
      "id_str" : "132412691",
      "id" : 132412691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651885274415427584",
  "in_reply_to_user_id" : 132412691,
  "text" : "@casualconc hi new beta crashes when trying to use cluster function?",
  "id" : 651885274415427584,
  "created_at" : "2015-10-07 22:22:15 +0000",
  "in_reply_to_screen_name" : "casualconc",
  "in_reply_to_user_id_str" : "132412691",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Hardie",
      "screen_name" : "HardieResearch",
      "indices" : [ 3, 18 ],
      "id_str" : "970452764",
      "id" : 970452764
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CQPweb",
      "indices" : [ 20, 27 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/aJrzF7s3Fv",
      "expanded_url" : "http:\/\/cwb.sourceforge.net\/cqpweb.php#inabox",
      "display_url" : "cwb.sourceforge.net\/cqpweb.php#ina\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "651881368507580417",
  "text" : "RT @HardieResearch: #CQPweb announcement no. 2: the new version is also available as  CQPwebInABox VM image. Plus improved instructions! ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CQPweb",
        "indices" : [ 0, 7 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/aJrzF7s3Fv",
        "expanded_url" : "http:\/\/cwb.sourceforge.net\/cqpweb.php#inabox",
        "display_url" : "cwb.sourceforge.net\/cqpweb.php#ina\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "651771331067953152",
    "text" : "#CQPweb announcement no. 2: the new version is also available as  CQPwebInABox VM image. Plus improved instructions! http:\/\/t.co\/aJrzF7s3Fv",
    "id" : 651771331067953152,
    "created_at" : "2015-10-07 14:49:29 +0000",
    "user" : {
      "name" : "Andrew Hardie",
      "screen_name" : "HardieResearch",
      "protected" : false,
      "id_str" : "970452764",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2895091886\/5274f8f34de87999703c0f92adfdf465_normal.jpeg",
      "id" : 970452764,
      "verified" : false
    }
  },
  "id" : 651881368507580417,
  "created_at" : "2015-10-07 22:06:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MSF Canada",
      "screen_name" : "MSF_canada",
      "indices" : [ 3, 14 ],
      "id_str" : "14755165",
      "id" : 14755165
    }, {
      "name" : "Dr Joanne Liu",
      "screen_name" : "JoanneLiu_MSF",
      "indices" : [ 27, 41 ],
      "id_str" : "2195885540",
      "id" : 2195885540
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/MSF_canada\/status\/651792666632568832\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/0lmWolOHs7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQuh-IDWwAAnE1b.jpg",
      "id_str" : "651792659770687488",
      "id" : 651792659770687488,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQuh-IDWwAAnE1b.jpg",
      "sizes" : [ {
        "h" : 567,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 332,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 188,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 567,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/0lmWolOHs7"
    } ],
    "hashtags" : [ {
      "text" : "IndependentInvestigation",
      "indices" : [ 69, 94 ]
    }, {
      "text" : "Kunduz",
      "indices" : [ 99, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/M1qJoGDJXz",
      "expanded_url" : "http:\/\/www.msf.ca\/en\/article\/even-war-has-rules-msf-calls-for-the-international-humanitarian-fact-finding-commission-to",
      "display_url" : "msf.ca\/en\/article\/eve\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "651818130818379777",
  "text" : "RT @MSF_canada: Watch\/Read @JoanneLiu_MSF's full statement demanding #IndependentInvestigation for #Kunduz http:\/\/t.co\/M1qJoGDJXz http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dr Joanne Liu",
        "screen_name" : "JoanneLiu_MSF",
        "indices" : [ 11, 25 ],
        "id_str" : "2195885540",
        "id" : 2195885540
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/MSF_canada\/status\/651792666632568832\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/0lmWolOHs7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQuh-IDWwAAnE1b.jpg",
        "id_str" : "651792659770687488",
        "id" : 651792659770687488,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQuh-IDWwAAnE1b.jpg",
        "sizes" : [ {
          "h" : 567,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 332,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 188,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 567,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/0lmWolOHs7"
      } ],
      "hashtags" : [ {
        "text" : "IndependentInvestigation",
        "indices" : [ 53, 78 ]
      }, {
        "text" : "Kunduz",
        "indices" : [ 83, 90 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/M1qJoGDJXz",
        "expanded_url" : "http:\/\/www.msf.ca\/en\/article\/even-war-has-rules-msf-calls-for-the-international-humanitarian-fact-finding-commission-to",
        "display_url" : "msf.ca\/en\/article\/eve\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "651792666632568832",
    "text" : "Watch\/Read @JoanneLiu_MSF's full statement demanding #IndependentInvestigation for #Kunduz http:\/\/t.co\/M1qJoGDJXz http:\/\/t.co\/0lmWolOHs7",
    "id" : 651792666632568832,
    "created_at" : "2015-10-07 16:14:16 +0000",
    "user" : {
      "name" : "MSF Canada",
      "screen_name" : "MSF_canada",
      "protected" : false,
      "id_str" : "14755165",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765606620680196097\/rd6VtAvn_normal.jpg",
      "id" : 14755165,
      "verified" : true
    }
  },
  "id" : 651818130818379777,
  "created_at" : "2015-10-07 17:55:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Cook",
      "screen_name" : "Jonathan_K_Cook",
      "indices" : [ 3, 19 ],
      "id_str" : "2459644405",
      "id" : 2459644405
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Kunduz",
      "indices" : [ 127, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/bVdJjaIbPf",
      "expanded_url" : "https:\/\/shar.es\/1u13iF",
      "display_url" : "shar.es\/1u13iF"
    } ]
  },
  "geo" : { },
  "id_str" : "651817807211048960",
  "text" : "RT @Jonathan_K_Cook: My latest: US lies and excuses for bombing Afghan hospital | Jonathan Cook's Blog https:\/\/t.co\/bVdJjaIbPf #Kunduz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Kunduz",
        "indices" : [ 106, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/bVdJjaIbPf",
        "expanded_url" : "https:\/\/shar.es\/1u13iF",
        "display_url" : "shar.es\/1u13iF"
      } ]
    },
    "geo" : { },
    "id_str" : "651659536114282496",
    "text" : "My latest: US lies and excuses for bombing Afghan hospital | Jonathan Cook's Blog https:\/\/t.co\/bVdJjaIbPf #Kunduz",
    "id" : 651659536114282496,
    "created_at" : "2015-10-07 07:25:15 +0000",
    "user" : {
      "name" : "Jonathan Cook",
      "screen_name" : "Jonathan_K_Cook",
      "protected" : false,
      "id_str" : "2459644405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458948119749619713\/8ed1EDoY_normal.jpeg",
      "id" : 2459644405,
      "verified" : false
    }
  },
  "id" : 651817807211048960,
  "created_at" : "2015-10-07 17:54:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 3, 14 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "education",
      "indices" : [ 118, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/ASDaQtGYoK",
      "expanded_url" : "http:\/\/bit.ly\/1Lj3lhY",
      "display_url" : "bit.ly\/1Lj3lhY"
    } ]
  },
  "geo" : { },
  "id_str" : "651781888038842369",
  "text" : "RT @tornhalves: Why we quit teaching. Pain and pedagogy from an Unnameable teacher: \"I can't go on; I'll stop.\" Adieu #education http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "education",
        "indices" : [ 102, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/ASDaQtGYoK",
        "expanded_url" : "http:\/\/bit.ly\/1Lj3lhY",
        "display_url" : "bit.ly\/1Lj3lhY"
      } ]
    },
    "geo" : { },
    "id_str" : "651697919930843137",
    "text" : "Why we quit teaching. Pain and pedagogy from an Unnameable teacher: \"I can't go on; I'll stop.\" Adieu #education http:\/\/t.co\/ASDaQtGYoK",
    "id" : 651697919930843137,
    "created_at" : "2015-10-07 09:57:46 +0000",
    "user" : {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "protected" : false,
      "id_str" : "87902543",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3059742703\/1d3c7a2052db17d29644fa0a49af6480_normal.jpeg",
      "id" : 87902543,
      "verified" : false
    }
  },
  "id" : 651781888038842369,
  "created_at" : "2015-10-07 15:31:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WhenIWasYourAge",
      "indices" : [ 0, 16 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651616538622038016",
  "text" : "#WhenIWasYourAge nostalgia was as popular as today",
  "id" : 651616538622038016,
  "created_at" : "2015-10-07 04:34:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rohit Talwar",
      "screen_name" : "fastfuture",
      "indices" : [ 0, 11 ],
      "id_str" : "42514805",
      "id" : 42514805
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/4L8Zr9jqcq",
      "expanded_url" : "https:\/\/www.tes.com\/news\/school-news\/breaking-news\/futurologist-urges-public-schools-incorporate-kinaesthetic-learning",
      "display_url" : "tes.com\/news\/school-ne\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "651527726013280256",
  "in_reply_to_user_id" : 42514805,
  "text" : "@fastfuture hi is this an accurate report of your talk? https:\/\/t.co\/4L8Zr9jqcq thks",
  "id" : 651527726013280256,
  "created_at" : "2015-10-06 22:41:29 +0000",
  "in_reply_to_screen_name" : "fastfuture",
  "in_reply_to_user_id_str" : "42514805",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gretchen McCulloch",
      "screen_name" : "GretchenAMcC",
      "indices" : [ 3, 16 ],
      "id_str" : "920491754",
      "id" : 920491754
    }, {
      "name" : "Mental Floss",
      "screen_name" : "mental_floss",
      "indices" : [ 25, 38 ],
      "id_str" : "20065936",
      "id" : 20065936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/Is44k5hDvT",
      "expanded_url" : "http:\/\/mentalfloss.com\/article\/69147\/why-pronunciation-gif-really-can-go-either-way",
      "display_url" : "mentalfloss.com\/article\/69147\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "651509223285727232",
  "text" : "RT @GretchenAMcC: I'm on @mental_floss with corpus data explaining why people have such strong disagreements about pronouncing \"gif\" http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mental Floss",
        "screen_name" : "mental_floss",
        "indices" : [ 7, 20 ],
        "id_str" : "20065936",
        "id" : 20065936
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/Is44k5hDvT",
        "expanded_url" : "http:\/\/mentalfloss.com\/article\/69147\/why-pronunciation-gif-really-can-go-either-way",
        "display_url" : "mentalfloss.com\/article\/69147\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "651401075791151104",
    "text" : "I'm on @mental_floss with corpus data explaining why people have such strong disagreements about pronouncing \"gif\" http:\/\/t.co\/Is44k5hDvT",
    "id" : 651401075791151104,
    "created_at" : "2015-10-06 14:18:13 +0000",
    "user" : {
      "name" : "Gretchen McCulloch",
      "screen_name" : "GretchenAMcC",
      "protected" : false,
      "id_str" : "920491754",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2800002402\/fb810f2f606e0f1413ed5191e2eac190_normal.png",
      "id" : 920491754,
      "verified" : true
    }
  },
  "id" : 651509223285727232,
  "created_at" : "2015-10-06 21:27:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Spencer",
      "screen_name" : "spencerideas",
      "indices" : [ 0, 13 ],
      "id_str" : "18389166",
      "id" : 18389166
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "651406551031287808",
  "geo" : { },
  "id_str" : "651411181043904512",
  "in_reply_to_user_id" : 18389166,
  "text" : "@spencerideas school of the many-faced god? :)",
  "id" : 651411181043904512,
  "in_reply_to_status_id" : 651406551031287808,
  "created_at" : "2015-10-06 14:58:22 +0000",
  "in_reply_to_screen_name" : "spencerideas",
  "in_reply_to_user_id_str" : "18389166",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike S. Boyle",
      "screen_name" : "heyboyle",
      "indices" : [ 0, 9 ],
      "id_str" : "612840231",
      "id" : 612840231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "651230886608904192",
  "geo" : { },
  "id_str" : "651410645628383232",
  "in_reply_to_user_id" : 612840231,
  "text" : "@heyboyle what a testimonial!",
  "id" : 651410645628383232,
  "in_reply_to_status_id" : 651230886608904192,
  "created_at" : "2015-10-06 14:56:15 +0000",
  "in_reply_to_screen_name" : "heyboyle",
  "in_reply_to_user_id_str" : "612840231",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 87, 103 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/AkeR9hkP0Z",
      "expanded_url" : "http:\/\/wp.me\/p14gfm-bs",
      "display_url" : "wp.me\/p14gfm-bs"
    } ]
  },
  "geo" : { },
  "id_str" : "651354120381665280",
  "text" : "The Story of Sounds:  Episode 26: Discovering the vowel \/\u00E6\/ http:\/\/t.co\/AkeR9hkP0Z via @wordpressdotcom",
  "id" : 651354120381665280,
  "created_at" : "2015-10-06 11:11:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/JTTvzP1Sjg",
      "expanded_url" : "http:\/\/idlewords.com\/talks\/haunted_by_data.htm",
      "display_url" : "idlewords.com\/talks\/haunted_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "651349229823225856",
  "text" : "Haunted by data http:\/\/t.co\/JTTvzP1Sjg",
  "id" : 651349229823225856,
  "created_at" : "2015-10-06 10:52:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    }, {
      "name" : "BBC News (UK)",
      "screen_name" : "BBCNews",
      "indices" : [ 39, 47 ],
      "id_str" : "612473",
      "id" : 612473
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/medialens\/status\/651117418337533952\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/5XFCP3qh4S",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQk710EUsAA7KpP.jpg",
      "id_str" : "651117416827629568",
      "id" : 651117416827629568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQk710EUsAA7KpP.jpg",
      "sizes" : [ {
        "h" : 350,
        "resize" : "fit",
        "w" : 932
      }, {
        "h" : 350,
        "resize" : "fit",
        "w" : 932
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 128,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/5XFCP3qh4S"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651337380788596736",
  "text" : "RT @medialens: The political editor of @BBCNews betrays her allegiance to an ideological worldview that says 'we' are the good guys. http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BBC News (UK)",
        "screen_name" : "BBCNews",
        "indices" : [ 24, 32 ],
        "id_str" : "612473",
        "id" : 612473
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/medialens\/status\/651117418337533952\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/5XFCP3qh4S",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQk710EUsAA7KpP.jpg",
        "id_str" : "651117416827629568",
        "id" : 651117416827629568,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQk710EUsAA7KpP.jpg",
        "sizes" : [ {
          "h" : 350,
          "resize" : "fit",
          "w" : 932
        }, {
          "h" : 350,
          "resize" : "fit",
          "w" : 932
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 128,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/5XFCP3qh4S"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "651117418337533952",
    "text" : "The political editor of @BBCNews betrays her allegiance to an ideological worldview that says 'we' are the good guys. http:\/\/t.co\/5XFCP3qh4S",
    "id" : 651117418337533952,
    "created_at" : "2015-10-05 19:31:04 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 651337380788596736,
  "created_at" : "2015-10-06 10:05:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jack Seale",
      "screen_name" : "jackseale",
      "indices" : [ 3, 13 ],
      "id_str" : "37020193",
      "id" : 37020193
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/jackseale\/status\/651264755248852993\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/aoeYNUvoVj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQnB1-jVEAAoAoC.jpg",
      "id_str" : "651264754200154112",
      "id" : 651264754200154112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQnB1-jVEAAoAoC.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/aoeYNUvoVj"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/fz0QZ5jTqa",
      "expanded_url" : "https:\/\/www.facebook.com\/photo.php?fbid=10206597263706921&set=gm.870594079703678&type=3",
      "display_url" : "facebook.com\/photo.php?fbid\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "651337092597989376",
  "text" : "RT @jackseale: The crowd who couldn't get in to see unelectable disaster-clown Jeremy Corbyn in Manchester: https:\/\/t.co\/fz0QZ5jTqa http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/jackseale\/status\/651264755248852993\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/aoeYNUvoVj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQnB1-jVEAAoAoC.jpg",
        "id_str" : "651264754200154112",
        "id" : 651264754200154112,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQnB1-jVEAAoAoC.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/aoeYNUvoVj"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/fz0QZ5jTqa",
        "expanded_url" : "https:\/\/www.facebook.com\/photo.php?fbid=10206597263706921&set=gm.870594079703678&type=3",
        "display_url" : "facebook.com\/photo.php?fbid\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "651264755248852993",
    "text" : "The crowd who couldn't get in to see unelectable disaster-clown Jeremy Corbyn in Manchester: https:\/\/t.co\/fz0QZ5jTqa http:\/\/t.co\/aoeYNUvoVj",
    "id" : 651264755248852993,
    "created_at" : "2015-10-06 05:16:32 +0000",
    "user" : {
      "name" : "Jack Seale",
      "screen_name" : "jackseale",
      "protected" : false,
      "id_str" : "37020193",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/675812363673731072\/A1ubUsnF_normal.jpg",
      "id" : 37020193,
      "verified" : false
    }
  },
  "id" : 651337092597989376,
  "created_at" : "2015-10-06 10:03:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Lab",
      "screen_name" : "LexicalLab",
      "indices" : [ 3, 14 ],
      "id_str" : "857732892",
      "id" : 857732892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/DIKczqMBnG",
      "expanded_url" : "https:\/\/petition.parliament.uk\/petitions\/109495",
      "display_url" : "petition.parliament.uk\/petitions\/1094\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "651335055256723456",
  "text" : "RT @LexicalLab: Language matters! Please sign my petition about the misuse of the term Living wage. https:\/\/t.co\/DIKczqMBnG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/DIKczqMBnG",
        "expanded_url" : "https:\/\/petition.parliament.uk\/petitions\/109495",
        "display_url" : "petition.parliament.uk\/petitions\/1094\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "651172592749932544",
    "text" : "Language matters! Please sign my petition about the misuse of the term Living wage. https:\/\/t.co\/DIKczqMBnG",
    "id" : 651172592749932544,
    "created_at" : "2015-10-05 23:10:18 +0000",
    "user" : {
      "name" : "Lexical Lab",
      "screen_name" : "LexicalLab",
      "protected" : false,
      "id_str" : "857732892",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/559654844831506432\/F4HWliCf_normal.jpeg",
      "id" : 857732892,
      "verified" : false
    }
  },
  "id" : 651335055256723456,
  "created_at" : "2015-10-06 09:55:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Rosen",
      "screen_name" : "MichaelRosenYes",
      "indices" : [ 0, 16 ],
      "id_str" : "91870534",
      "id" : 91870534
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "651163827380158464",
  "geo" : { },
  "id_str" : "651167212544233472",
  "in_reply_to_user_id" : 91870534,
  "text" : "@MichaelRosenYes blimey ex ELT teacher :?",
  "id" : 651167212544233472,
  "in_reply_to_status_id" : 651163827380158464,
  "created_at" : "2015-10-05 22:48:56 +0000",
  "in_reply_to_screen_name" : "MichaelRosenYes",
  "in_reply_to_user_id_str" : "91870534",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 65, 81 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/pUaZ98oqDN",
      "expanded_url" : "http:\/\/wp.me\/p62XeB-3s",
      "display_url" : "wp.me\/p62XeB-3s"
    } ]
  },
  "geo" : { },
  "id_str" : "651149319345561600",
  "text" : "My Favorite Technology: Screencasting http:\/\/t.co\/pUaZ98oqDN via @wordpressdotcom",
  "id" : 651149319345561600,
  "created_at" : "2015-10-05 21:37:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/99gYzXbXYO",
      "expanded_url" : "http:\/\/www.theguardian.com\/world\/2015\/oct\/05\/air-france-workers-storm-meeting-protest-executives-job-losses-paris",
      "display_url" : "theguardian.com\/world\/2015\/oct\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "651040202522251265",
  "text" : "RT @pchallinor: Workers take shirts from executives' backs http:\/\/t.co\/99gYzXbXYO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 65 ],
        "url" : "http:\/\/t.co\/99gYzXbXYO",
        "expanded_url" : "http:\/\/www.theguardian.com\/world\/2015\/oct\/05\/air-france-workers-storm-meeting-protest-executives-job-losses-paris",
        "display_url" : "theguardian.com\/world\/2015\/oct\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "651036686063915009",
    "text" : "Workers take shirts from executives' backs http:\/\/t.co\/99gYzXbXYO",
    "id" : 651036686063915009,
    "created_at" : "2015-10-05 14:10:16 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 651040202522251265,
  "created_at" : "2015-10-05 14:24:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/NAn1rJxzSF",
      "expanded_url" : "http:\/\/www.speechinaction.org\/blog\/listening-cherry-13-connected-speech-rules-are-too-genteel\/",
      "display_url" : "speechinaction.org\/blog\/listening\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "651035177133703168",
  "text" : "http:\/\/t.co\/NAn1rJxzSF Listening Cherry 13 \u2013 Connected speech rules are too genteel",
  "id" : 651035177133703168,
  "created_at" : "2015-10-05 14:04:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicola Prentis",
      "screen_name" : "NicolaPrentis",
      "indices" : [ 52, 66 ],
      "id_str" : "810667033",
      "id" : 810667033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/wiz14FB0pb",
      "expanded_url" : "http:\/\/wp.me\/p1RJaO-lrf",
      "display_url" : "wp.me\/p1RJaO-lrf"
    } ]
  },
  "geo" : { },
  "id_str" : "651030207575511040",
  "text" : "Is your new school crap? http:\/\/t.co\/wiz14FB0pb via @NicolaPrentis",
  "id" : 651030207575511040,
  "created_at" : "2015-10-05 13:44:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Serveis Ling\u00FC\u00EDstics",
      "screen_name" : "SLBCoop",
      "indices" : [ 3, 11 ],
      "id_str" : "2365399801",
      "id" : 2365399801
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "worldteachersday",
      "indices" : [ 29, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651028635529412609",
  "text" : "RT @SLBCoop: All the talk on #worldteachersday is of how inspiring and valued teachers are. We'd also like to talk about what they earn ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "worldteachersday",
        "indices" : [ 16, 33 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "651011158225354752",
    "text" : "All the talk on #worldteachersday is of how inspiring and valued teachers are. We'd also like to talk about what they earn ...",
    "id" : 651011158225354752,
    "created_at" : "2015-10-05 12:28:49 +0000",
    "user" : {
      "name" : "Serveis Ling\u00FC\u00EDstics",
      "screen_name" : "SLBCoop",
      "protected" : false,
      "id_str" : "2365399801",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705151471386546176\/ECVLcba-_normal.jpg",
      "id" : 2365399801,
      "verified" : false
    }
  },
  "id" : 651028635529412609,
  "created_at" : "2015-10-05 13:38:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Sherlock",
      "screen_name" : "DavidMSherlock",
      "indices" : [ 0, 15 ],
      "id_str" : "1479898584",
      "id" : 1479898584
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "650988393204187136",
  "geo" : { },
  "id_str" : "650993053340008448",
  "in_reply_to_user_id" : 1479898584,
  "text" : "@DavidMSherlock tru that",
  "id" : 650993053340008448,
  "in_reply_to_status_id" : 650988393204187136,
  "created_at" : "2015-10-05 11:16:53 +0000",
  "in_reply_to_screen_name" : "DavidMSherlock",
  "in_reply_to_user_id_str" : "1479898584",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hana Tich\u00E1",
      "screen_name" : "HanaTicha",
      "indices" : [ 0, 10 ],
      "id_str" : "512296705",
      "id" : 512296705
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/650989255431450624\/photo\/1",
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/Rde7SmyBUc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQjHRy6WEAAeovO.png",
      "id_str" : "650989254693228544",
      "id" : 650989254693228544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQjHRy6WEAAeovO.png",
      "sizes" : [ {
        "h" : 93,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 215,
        "resize" : "fit",
        "w" : 1393
      }, {
        "h" : 158,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 52,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Rde7SmyBUc"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/pYPtsEQbtT",
      "expanded_url" : "http:\/\/corpus.byu.edu\/glowbe\/?c=glowbe&q=41858051",
      "display_url" : "corpus.byu.edu\/glowbe\/?c=glow\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "650923655317299202",
  "geo" : { },
  "id_str" : "650989255431450624",
  "in_reply_to_user_id" : 512296705,
  "text" : "@HanaTicha though wd need to consider worldwide use of English as well http:\/\/t.co\/pYPtsEQbtT http:\/\/t.co\/Rde7SmyBUc",
  "id" : 650989255431450624,
  "in_reply_to_status_id" : 650923655317299202,
  "created_at" : "2015-10-05 11:01:47 +0000",
  "in_reply_to_screen_name" : "HanaTicha",
  "in_reply_to_user_id_str" : "512296705",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Sherlock",
      "screen_name" : "DavidMSherlock",
      "indices" : [ 0, 15 ],
      "id_str" : "1479898584",
      "id" : 1479898584
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "650979688945446912",
  "geo" : { },
  "id_str" : "650987884799991808",
  "in_reply_to_user_id" : 1479898584,
  "text" : "@DavidMSherlock hmm not much of a think tank i.e. these pensioners don't have relatives of voting age? :\/",
  "id" : 650987884799991808,
  "in_reply_to_status_id" : 650979688945446912,
  "created_at" : "2015-10-05 10:56:21 +0000",
  "in_reply_to_screen_name" : "DavidMSherlock",
  "in_reply_to_user_id_str" : "1479898584",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/Z4v40H3SW1",
      "expanded_url" : "http:\/\/boingboing.net\/2015\/10\/02\/nasa-just-released-8400-apoll.html",
      "display_url" : "boingboing.net\/2015\/10\/02\/nas\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "650881007361630208",
  "text" : "Over 8,400 NASA Apollo moon mission photos just landed online, in high-resolution http:\/\/t.co\/Z4v40H3SW1",
  "id" : 650881007361630208,
  "created_at" : "2015-10-05 03:51:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenys Hanson",
      "screen_name" : "GlenysHanson",
      "indices" : [ 0, 13 ],
      "id_str" : "527238447",
      "id" : 527238447
    }, {
      "name" : "MarisaConstantinides",
      "screen_name" : "Marisa_C",
      "indices" : [ 14, 23 ],
      "id_str" : "18272500",
      "id" : 18272500
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "650771513709195264",
  "geo" : { },
  "id_str" : "650801849696657409",
  "in_reply_to_user_id" : 527238447,
  "text" : "@GlenysHanson @Marisa_C would need to investigate how sorries were used :)",
  "id" : 650801849696657409,
  "in_reply_to_status_id" : 650771513709195264,
  "created_at" : "2015-10-04 22:37:06 +0000",
  "in_reply_to_screen_name" : "GlenysHanson",
  "in_reply_to_user_id_str" : "527238447",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hana Tich\u00E1",
      "screen_name" : "HanaTicha",
      "indices" : [ 0, 10 ],
      "id_str" : "512296705",
      "id" : 512296705
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/650800895110840320\/photo\/1",
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/hQ5vLqXi9G",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQgb9wJWEAkc5T6.png",
      "id_str" : "650800893865103369",
      "id" : 650800893865103369,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQgb9wJWEAkc5T6.png",
      "sizes" : [ {
        "h" : 93,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 53,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 159,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 217,
        "resize" : "fit",
        "w" : 1397
      } ],
      "display_url" : "pic.twitter.com\/hQ5vLqXi9G"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/CjA6xTlMeX",
      "expanded_url" : "http:\/\/corpus.byu.edu\/coha\/?c=coha&q=41845745",
      "display_url" : "corpus.byu.edu\/coha\/?c=coha&q\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "650591772226265088",
  "geo" : { },
  "id_str" : "650800895110840320",
  "in_reply_to_user_id" : 512296705,
  "text" : "@HanaTicha u cld be right about it being old-fashioned http:\/\/t.co\/CjA6xTlMeX http:\/\/t.co\/hQ5vLqXi9G",
  "id" : 650800895110840320,
  "in_reply_to_status_id" : 650591772226265088,
  "created_at" : "2015-10-04 22:33:19 +0000",
  "in_reply_to_screen_name" : "HanaTicha",
  "in_reply_to_user_id_str" : "512296705",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HaveUread",
      "screen_name" : "thisbyanychance",
      "indices" : [ 0, 16 ],
      "id_str" : "3416415189",
      "id" : 3416415189
    }, {
      "name" : "Graham Andre'",
      "screen_name" : "grahamandre",
      "indices" : [ 22, 34 ],
      "id_str" : "82697426",
      "id" : 82697426
    }, {
      "name" : "Chris Farrell",
      "screen_name" : "ChrisPatrickF",
      "indices" : [ 35, 49 ],
      "id_str" : "3165431237",
      "id" : 3165431237
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "650607090814332928",
  "geo" : { },
  "id_str" : "650747590552780800",
  "in_reply_to_user_id" : 82697426,
  "text" : "@thisbyanychance tell @grahamandre @ChrisPatrickF about Dale cone",
  "id" : 650747590552780800,
  "in_reply_to_status_id" : 650607090814332928,
  "created_at" : "2015-10-04 19:01:30 +0000",
  "in_reply_to_screen_name" : "grahamandre",
  "in_reply_to_user_id_str" : "82697426",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tressie Mc",
      "screen_name" : "tressiemcphd",
      "indices" : [ 3, 16 ],
      "id_str" : "148593548",
      "id" : 148593548
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 140 ],
      "url" : "https:\/\/t.co\/NCTwpjtHui",
      "expanded_url" : "https:\/\/www.washingtonpost.com\/news\/the-intersect\/wp\/2015\/09\/30\/everyone-you-know-will-be-able-to-rate-you-on-the-terrifying-yelp-for-people-whether-you-want-them-to-or-not\/",
      "display_url" : "washingtonpost.com\/news\/the-inter\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "650731812877148161",
  "text" : "RT @tressiemcphd: How's that \"more white women in tech would be a great thing for all women\" thing working out for ya? https:\/\/t.co\/NCTwpjt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/NCTwpjtHui",
        "expanded_url" : "https:\/\/www.washingtonpost.com\/news\/the-intersect\/wp\/2015\/09\/30\/everyone-you-know-will-be-able-to-rate-you-on-the-terrifying-yelp-for-people-whether-you-want-them-to-or-not\/",
        "display_url" : "washingtonpost.com\/news\/the-inter\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "649365120041263104",
    "text" : "How's that \"more white women in tech would be a great thing for all women\" thing working out for ya? https:\/\/t.co\/NCTwpjtHui",
    "id" : 649365120041263104,
    "created_at" : "2015-09-30 23:28:03 +0000",
    "user" : {
      "name" : "Tressie Mc",
      "screen_name" : "tressiemcphd",
      "protected" : false,
      "id_str" : "148593548",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608377192331005952\/-4qqbOp2_normal.jpg",
      "id" : 148593548,
      "verified" : true
    }
  },
  "id" : 650731812877148161,
  "created_at" : "2015-10-04 17:58:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Crispin Weston",
      "screen_name" : "crispinweston",
      "indices" : [ 61, 75 ],
      "id_str" : "70624964",
      "id" : 70624964
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/3hlVSYos0p",
      "expanded_url" : "http:\/\/wp.me\/p27xY2-kI",
      "display_url" : "wp.me\/p27xY2-kI"
    } ]
  },
  "geo" : { },
  "id_str" : "650712113384693760",
  "text" : "Assessing the evidence for edtech http:\/\/t.co\/3hlVSYos0p via @crispinweston",
  "id" : 650712113384693760,
  "created_at" : "2015-10-04 16:40:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Real Media",
      "screen_name" : "RealMediaGB",
      "indices" : [ 3, 15 ],
      "id_str" : "2843630307",
      "id" : 2843630307
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "No2Austerity",
      "indices" : [ 96, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/uoDVXXYWsQ",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=D33BDnZqwHs",
      "display_url" : "youtube.com\/watch?v=D33BDn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "650658341451116544",
  "text" : "RT @RealMediaGB: Apparently the protesters are scary? Here's a video from yesterday's Flash Mob #No2Austerity https:\/\/t.co\/uoDVXXYWsQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "No2Austerity",
        "indices" : [ 79, 92 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/uoDVXXYWsQ",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=D33BDnZqwHs",
        "display_url" : "youtube.com\/watch?v=D33BDn\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "650585460360749057",
    "text" : "Apparently the protesters are scary? Here's a video from yesterday's Flash Mob #No2Austerity https:\/\/t.co\/uoDVXXYWsQ",
    "id" : 650585460360749057,
    "created_at" : "2015-10-04 08:17:15 +0000",
    "user" : {
      "name" : "Real Media",
      "screen_name" : "RealMediaGB",
      "protected" : false,
      "id_str" : "2843630307",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/667734063281799169\/kt1RkQoz_normal.png",
      "id" : 2843630307,
      "verified" : false
    }
  },
  "id" : 650658341451116544,
  "created_at" : "2015-10-04 13:06:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/CImGD3aFzo",
      "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2015\/10\/wheels-within-wheels.html",
      "display_url" : "thecurmudgeonly.blogspot.co.uk\/2015\/10\/wheels\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "650630423719112704",
  "text" : "RT @pchallinor: New mudgeonry: Wheels within wheels http:\/\/t.co\/CImGD3aFzo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 36, 58 ],
        "url" : "http:\/\/t.co\/CImGD3aFzo",
        "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2015\/10\/wheels-within-wheels.html",
        "display_url" : "thecurmudgeonly.blogspot.co.uk\/2015\/10\/wheels\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "650622094225620992",
    "text" : "New mudgeonry: Wheels within wheels http:\/\/t.co\/CImGD3aFzo",
    "id" : 650622094225620992,
    "created_at" : "2015-10-04 10:42:49 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 650630423719112704,
  "created_at" : "2015-10-04 11:15:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bonnie Stewart",
      "screen_name" : "bonstewart",
      "indices" : [ 3, 14 ],
      "id_str" : "6532522",
      "id" : 6532522
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lrt",
      "indices" : [ 143, 144 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "650450736099250176",
  "text" : "RT @bonstewart: anybody out there know Richard Branson &amp; can manage to convince him that \"disrupting ed\" means packing disruptors on his mo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "lrt",
        "indices" : [ 139, 143 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "650050278411096064",
    "text" : "anybody out there know Richard Branson &amp; can manage to convince him that \"disrupting ed\" means packing disruptors on his moon shuttle? #lrt",
    "id" : 650050278411096064,
    "created_at" : "2015-10-02 20:50:38 +0000",
    "user" : {
      "name" : "Bonnie Stewart",
      "screen_name" : "bonstewart",
      "protected" : false,
      "id_str" : "6532522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712632498807824385\/WXjGOsKg_normal.jpg",
      "id" : 6532522,
      "verified" : false
    }
  },
  "id" : 650450736099250176,
  "created_at" : "2015-10-03 23:21:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike S. Boyle",
      "screen_name" : "heyboyle",
      "indices" : [ 0, 9 ],
      "id_str" : "612840231",
      "id" : 612840231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "650358525345071105",
  "geo" : { },
  "id_str" : "650440421907255296",
  "in_reply_to_user_id" : 612840231,
  "text" : "@heyboyle yep only paypal accepted",
  "id" : 650440421907255296,
  "in_reply_to_status_id" : 650358525345071105,
  "created_at" : "2015-10-03 22:40:55 +0000",
  "in_reply_to_screen_name" : "heyboyle",
  "in_reply_to_user_id_str" : "612840231",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpuslinguistics",
      "indices" : [ 16, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "650439612381446144",
  "text" : "hmm how many FB #corpuslinguistics does it take to figure out corpus software :?",
  "id" : 650439612381446144,
  "created_at" : "2015-10-03 22:37:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MarisaConstantinides",
      "screen_name" : "Marisa_C",
      "indices" : [ 0, 9 ],
      "id_str" : "18272500",
      "id" : 18272500
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/650435015684280320\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/YUyn1jPvNH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQbPMygWwAAquVZ.png",
      "id_str" : "650435014824476672",
      "id" : 650435014824476672,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQbPMygWwAAquVZ.png",
      "sizes" : [ {
        "h" : 389,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 540,
        "resize" : "fit",
        "w" : 1420
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 129,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 228,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/YUyn1jPvNH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "650426270652743680",
  "geo" : { },
  "id_str" : "650435015684280320",
  "in_reply_to_user_id" : 18272500,
  "text" : "@Marisa_C u can use bncweb to have a look at use from 1990s e.g. &gt; 60yr olds use least, used most in business http:\/\/t.co\/YUyn1jPvNH",
  "id" : 650435015684280320,
  "in_reply_to_status_id" : 650426270652743680,
  "created_at" : "2015-10-03 22:19:26 +0000",
  "in_reply_to_screen_name" : "Marisa_C",
  "in_reply_to_user_id_str" : "18272500",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 3, 17 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/AmnA7rbPkp",
      "expanded_url" : "http:\/\/venturebeat.com\/2015\/10\/02\/mattels-google-cardboard-powered-view-master-is-now-on-sale\/",
      "display_url" : "venturebeat.com\/2015\/10\/02\/mat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "650352827852804096",
  "text" : "RT @audreywatters: Next person who tells me Google Cardboard is innovative gets punched in the view master http:\/\/t.co\/AmnA7rbPkp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/AmnA7rbPkp",
        "expanded_url" : "http:\/\/venturebeat.com\/2015\/10\/02\/mattels-google-cardboard-powered-view-master-is-now-on-sale\/",
        "display_url" : "venturebeat.com\/2015\/10\/02\/mat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "650096692927139840",
    "text" : "Next person who tells me Google Cardboard is innovative gets punched in the view master http:\/\/t.co\/AmnA7rbPkp",
    "id" : 650096692927139840,
    "created_at" : "2015-10-02 23:55:04 +0000",
    "user" : {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "protected" : false,
      "id_str" : "25388528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711668009723498496\/pauFZsdv_normal.jpg",
      "id" : 25388528,
      "verified" : false
    }
  },
  "id" : 650352827852804096,
  "created_at" : "2015-10-03 16:52:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike S. Boyle",
      "screen_name" : "heyboyle",
      "indices" : [ 0, 9 ],
      "id_str" : "612840231",
      "id" : 612840231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "650316674852352000",
  "geo" : { },
  "id_str" : "650323156926922752",
  "in_reply_to_user_id" : 612840231,
  "text" : "@heyboyle adaptive learning is so 1970s the people want learning learning \u00A9",
  "id" : 650323156926922752,
  "in_reply_to_status_id" : 650316674852352000,
  "created_at" : "2015-10-03 14:54:57 +0000",
  "in_reply_to_screen_name" : "heyboyle",
  "in_reply_to_user_id_str" : "612840231",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/2fupM5PXjC",
      "expanded_url" : "http:\/\/members5.boardhost.com\/medialens\/msg\/1443826305.html",
      "display_url" : "members5.boardhost.com\/medialens\/msg\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "650313996059439104",
  "text" : "Who is the more violent and despicable character: Bill Clinton or Chris Brown? http:\/\/t.co\/2fupM5PXjC",
  "id" : 650313996059439104,
  "created_at" : "2015-10-03 14:18:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "indices" : [ 3, 18 ],
      "id_str" : "27716419",
      "id" : 27716419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/vXu8kYoizj",
      "expanded_url" : "http:\/\/www.craigmurray.org.uk\/archives\/2015\/10\/british-state-viciously-abuses-child-fantasist\/",
      "display_url" : "craigmurray.org.uk\/archives\/2015\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "650309523207520256",
  "text" : "RT @CraigMurrayOrg: New post: British State Viciously Abuses Child Fantasist http:\/\/t.co\/vXu8kYoizj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.craigmurray.org.uk\" rel=\"nofollow\"\u003ECraig Murray posting plugin\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/vXu8kYoizj",
        "expanded_url" : "http:\/\/www.craigmurray.org.uk\/archives\/2015\/10\/british-state-viciously-abuses-child-fantasist\/",
        "display_url" : "craigmurray.org.uk\/archives\/2015\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "649921706396659712",
    "text" : "New post: British State Viciously Abuses Child Fantasist http:\/\/t.co\/vXu8kYoizj",
    "id" : 649921706396659712,
    "created_at" : "2015-10-02 12:19:44 +0000",
    "user" : {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "protected" : false,
      "id_str" : "27716419",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1388436826\/cm_normal.jpg",
      "id" : 27716419,
      "verified" : false
    }
  },
  "id" : 650309523207520256,
  "created_at" : "2015-10-03 14:00:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/1RRC5QkKnx",
      "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2015\/10\/stuff-happens.html",
      "display_url" : "thecurmudgeonly.blogspot.co.uk\/2015\/10\/stuff-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "650289959237197824",
  "text" : "RT @pchallinor: New mudgeonry: Stuff happens http:\/\/t.co\/1RRC5QkKnx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 29, 51 ],
        "url" : "http:\/\/t.co\/1RRC5QkKnx",
        "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2015\/10\/stuff-happens.html",
        "display_url" : "thecurmudgeonly.blogspot.co.uk\/2015\/10\/stuff-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "650280421712875521",
    "text" : "New mudgeonry: Stuff happens http:\/\/t.co\/1RRC5QkKnx",
    "id" : 650280421712875521,
    "created_at" : "2015-10-03 12:05:08 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 650289959237197824,
  "created_at" : "2015-10-03 12:43:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bret Taylor",
      "screen_name" : "btaylor",
      "indices" : [ 3, 11 ],
      "id_str" : "7456262",
      "id" : 7456262
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/btaylor\/status\/649984944463196161\/photo\/1",
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/tTs5qxYmWv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQU13OuUYAAQm44.png",
      "id_str" : "649984944186351616",
      "id" : 649984944186351616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQU13OuUYAAQm44.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 678,
        "resize" : "fit",
        "w" : 774
      }, {
        "h" : 298,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 678,
        "resize" : "fit",
        "w" : 774
      }, {
        "h" : 526,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/tTs5qxYmWv"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/ULTS1TRWlc",
      "expanded_url" : "http:\/\/www.mcsweeneys.net\/articles\/nihilistic-password-security-questions",
      "display_url" : "mcsweeneys.net\/articles\/nihil\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "650253168710955008",
  "text" : "RT @btaylor: Nihilistic password security questions - http:\/\/t.co\/ULTS1TRWlc http:\/\/t.co\/tTs5qxYmWv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/btaylor\/status\/649984944463196161\/photo\/1",
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/tTs5qxYmWv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQU13OuUYAAQm44.png",
        "id_str" : "649984944186351616",
        "id" : 649984944186351616,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQU13OuUYAAQm44.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 678,
          "resize" : "fit",
          "w" : 774
        }, {
          "h" : 298,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 678,
          "resize" : "fit",
          "w" : 774
        }, {
          "h" : 526,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/tTs5qxYmWv"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/ULTS1TRWlc",
        "expanded_url" : "http:\/\/www.mcsweeneys.net\/articles\/nihilistic-password-security-questions",
        "display_url" : "mcsweeneys.net\/articles\/nihil\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "649984944463196161",
    "text" : "Nihilistic password security questions - http:\/\/t.co\/ULTS1TRWlc http:\/\/t.co\/tTs5qxYmWv",
    "id" : 649984944463196161,
    "created_at" : "2015-10-02 16:31:01 +0000",
    "user" : {
      "name" : "Bret Taylor",
      "screen_name" : "btaylor",
      "protected" : false,
      "id_str" : "7456262",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458753542065385473\/5XjHzaq7_normal.jpeg",
      "id" : 7456262,
      "verified" : true
    }
  },
  "id" : 650253168710955008,
  "created_at" : "2015-10-03 10:16:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Paskale",
      "screen_name" : "speak2all",
      "indices" : [ 3, 13 ],
      "id_str" : "20900313",
      "id" : 20900313
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DirtyRhetoric",
      "indices" : [ 98, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/25RvDBtevd",
      "expanded_url" : "https:\/\/youtu.be\/ZPRp36QLIfM",
      "display_url" : "youtu.be\/ZPRp36QLIfM"
    } ]
  },
  "geo" : { },
  "id_str" : "650065967146496000",
  "text" : "RT @speak2all: Trump claims he's a rhetoric-free plain-speaker. We beg to differ. Here's why: Our #DirtyRhetoric webinar special https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DirtyRhetoric",
        "indices" : [ 83, 97 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/25RvDBtevd",
        "expanded_url" : "https:\/\/youtu.be\/ZPRp36QLIfM",
        "display_url" : "youtu.be\/ZPRp36QLIfM"
      } ]
    },
    "geo" : { },
    "id_str" : "646768513634430977",
    "text" : "Trump claims he's a rhetoric-free plain-speaker. We beg to differ. Here's why: Our #DirtyRhetoric webinar special https:\/\/t.co\/25RvDBtevd",
    "id" : 646768513634430977,
    "created_at" : "2015-09-23 19:30:04 +0000",
    "user" : {
      "name" : "Peter Paskale",
      "screen_name" : "speak2all",
      "protected" : false,
      "id_str" : "20900313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/555413218571468800\/oXbEP2Zs_normal.jpeg",
      "id" : 20900313,
      "verified" : false
    }
  },
  "id" : 650065967146496000,
  "created_at" : "2015-10-02 21:52:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "indices" : [ 0, 10 ],
      "id_str" : "577931950",
      "id" : 577931950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "650018024918020096",
  "geo" : { },
  "id_str" : "650038503020040193",
  "in_reply_to_user_id" : 577931950,
  "text" : "@RudyLoock if you have python can run commandline see github link",
  "id" : 650038503020040193,
  "in_reply_to_status_id" : 650018024918020096,
  "created_at" : "2015-10-02 20:03:50 +0000",
  "in_reply_to_screen_name" : "RudyLoock",
  "in_reply_to_user_id_str" : "577931950",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blair Teacher",
      "screen_name" : "blairteacher",
      "indices" : [ 0, 13 ],
      "id_str" : "20932918",
      "id" : 20932918
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "649713212686995456",
  "geo" : { },
  "id_str" : "649713387925016576",
  "in_reply_to_user_id" : 20932918,
  "text" : "@blairteacher i hear charlotte church is on any good?",
  "id" : 649713387925016576,
  "in_reply_to_status_id" : 649713212686995456,
  "created_at" : "2015-10-01 22:31:57 +0000",
  "in_reply_to_screen_name" : "blairteacher",
  "in_reply_to_user_id_str" : "20932918",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edward Snowden",
      "screen_name" : "Snowden",
      "indices" : [ 3, 11 ],
      "id_str" : "2916305152",
      "id" : 2916305152
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lessonlearned",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "649711544452935680",
  "text" : "RT @Snowden: I forgot to turn off notifications. Twitter sent me an email for each:\n\nFollow\nFavorite\nRetweet\nDM\n\n47 gigs of notifications. \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "lessonlearned",
        "indices" : [ 126, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "649653419620352000",
    "text" : "I forgot to turn off notifications. Twitter sent me an email for each:\n\nFollow\nFavorite\nRetweet\nDM\n\n47 gigs of notifications. #lessonlearned",
    "id" : 649653419620352000,
    "created_at" : "2015-10-01 18:33:39 +0000",
    "user" : {
      "name" : "Edward Snowden",
      "screen_name" : "Snowden",
      "protected" : false,
      "id_str" : "2916305152",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/648888480974508032\/66_cUYfj_normal.jpg",
      "id" : 2916305152,
      "verified" : true
    }
  },
  "id" : 649711544452935680,
  "created_at" : "2015-10-01 22:24:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Antony Wright)))",
      "screen_name" : "Antony_Wright",
      "indices" : [ 3, 17 ],
      "id_str" : "52716952",
      "id" : 52716952
    }, {
      "name" : "Andy Burnham",
      "screen_name" : "andyburnhammp",
      "indices" : [ 19, 33 ],
      "id_str" : "143779403",
      "id" : 143779403
    }, {
      "name" : "Hilary Benn",
      "screen_name" : "hilarybennmp",
      "indices" : [ 34, 47 ],
      "id_str" : "408454349",
      "id" : 408454349
    }, {
      "name" : "Maria Eagle MP",
      "screen_name" : "meaglemp",
      "indices" : [ 48, 57 ],
      "id_str" : "192935794",
      "id" : 192935794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "649702151724355584",
  "text" : "RT @Antony_Wright: @andyburnhammp @hilarybennmp @meaglemp Trident replacement - should we check if Biological or Chemical weapons a more co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Burnham",
        "screen_name" : "andyburnhammp",
        "indices" : [ 0, 14 ],
        "id_str" : "143779403",
        "id" : 143779403
      }, {
        "name" : "Hilary Benn",
        "screen_name" : "hilarybennmp",
        "indices" : [ 15, 28 ],
        "id_str" : "408454349",
        "id" : 408454349
      }, {
        "name" : "Maria Eagle MP",
        "screen_name" : "meaglemp",
        "indices" : [ 29, 38 ],
        "id_str" : "192935794",
        "id" : 192935794
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "649623672425156608",
    "in_reply_to_user_id" : 143779403,
    "text" : "@andyburnhammp @hilarybennmp @meaglemp Trident replacement - should we check if Biological or Chemical weapons a more cost effective option?",
    "id" : 649623672425156608,
    "created_at" : "2015-10-01 16:35:27 +0000",
    "in_reply_to_screen_name" : "andyburnhammp",
    "in_reply_to_user_id_str" : "143779403",
    "user" : {
      "name" : "(((Antony Wright)))",
      "screen_name" : "Antony_Wright",
      "protected" : false,
      "id_str" : "52716952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/674266858212732929\/u0YrutMG_normal.jpg",
      "id" : 52716952,
      "verified" : false
    }
  },
  "id" : 649702151724355584,
  "created_at" : "2015-10-01 21:47:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "649698493653774338",
  "geo" : { },
  "id_str" : "649699582658650112",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava i know these hacks got a job to do but do they ever take time to listen to themselves? :?",
  "id" : 649699582658650112,
  "in_reply_to_status_id" : 649698493653774338,
  "created_at" : "2015-10-01 21:37:05 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/649698493653774338\/photo\/1",
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/SfkJDkQ9CK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQQxVioWIAAElhJ.png",
      "id_str" : "649698492391235584",
      "id" : 649698492391235584,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQQxVioWIAAElhJ.png",
      "sizes" : [ {
        "h" : 360,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 454,
        "resize" : "fit",
        "w" : 429
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 454,
        "resize" : "fit",
        "w" : 429
      }, {
        "h" : 454,
        "resize" : "fit",
        "w" : 429
      } ],
      "display_url" : "pic.twitter.com\/SfkJDkQ9CK"
    } ],
    "hashtags" : [ {
      "text" : "Corbyn",
      "indices" : [ 59, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/f4sRKxhkk6",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=01n4YSCbkt0&feature=youtu.be&t=1m4s",
      "display_url" : "youtube.com\/watch?v=01n4YS\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "649698493653774338",
  "text" : "missing scene from Dr. Strangelove https:\/\/t.co\/f4sRKxhkk6 #Corbyn https:\/\/t.co\/SfkJDkQ9CK",
  "id" : 649698493653774338,
  "created_at" : "2015-10-01 21:32:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/eRzU4wz2cA",
      "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2015\/10\/no-fraternising-with-gooks.html",
      "display_url" : "thecurmudgeonly.blogspot.co.uk\/2015\/10\/no-fra\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "649645655737151488",
  "text" : "RT @pchallinor: New mudgeonry: No fraternising with the gooks https:\/\/t.co\/eRzU4wz2cA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 69 ],
        "url" : "https:\/\/t.co\/eRzU4wz2cA",
        "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2015\/10\/no-fraternising-with-gooks.html",
        "display_url" : "thecurmudgeonly.blogspot.co.uk\/2015\/10\/no-fra\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "649643835698606080",
    "text" : "New mudgeonry: No fraternising with the gooks https:\/\/t.co\/eRzU4wz2cA",
    "id" : 649643835698606080,
    "created_at" : "2015-10-01 17:55:34 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 649645655737151488,
  "created_at" : "2015-10-01 18:02:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/TcXKt9MLva",
      "expanded_url" : "http:\/\/www.theguardian.com\/commentisfree\/2015\/oct\/01\/britain-slavery-myths-david-cameron-jamaica",
      "display_url" : "theguardian.com\/commentisfree\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "649624145991479296",
  "text" : "RT @pchallinor: O the ingratitude http:\/\/t.co\/TcXKt9MLva",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 18, 40 ],
        "url" : "http:\/\/t.co\/TcXKt9MLva",
        "expanded_url" : "http:\/\/www.theguardian.com\/commentisfree\/2015\/oct\/01\/britain-slavery-myths-david-cameron-jamaica",
        "display_url" : "theguardian.com\/commentisfree\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "649623369990672384",
    "text" : "O the ingratitude http:\/\/t.co\/TcXKt9MLva",
    "id" : 649623369990672384,
    "created_at" : "2015-10-01 16:34:15 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 649624145991479296,
  "created_at" : "2015-10-01 16:37:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Hawksey",
      "screen_name" : "mhawksey",
      "indices" : [ 0, 9 ],
      "id_str" : "13046992",
      "id" : 13046992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "649606591478669312",
  "in_reply_to_user_id" : 13046992,
  "text" : "@mhawksey hi a googlesheets formula u gave me a while back seems to act odd each time TAGSV6 collects some tweets",
  "id" : 649606591478669312,
  "created_at" : "2015-10-01 15:27:35 +0000",
  "in_reply_to_screen_name" : "mhawksey",
  "in_reply_to_user_id_str" : "13046992",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusresources",
      "indices" : [ 5, 21 ]
    } ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/2eUiSY6OWe",
      "expanded_url" : "https:\/\/plus.google.com\/+MuraNava\/posts\/QhXG4urmApg",
      "display_url" : "plus.google.com\/+MuraNava\/post\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "649601518354739200",
  "text" : "some #corpusresources https:\/\/t.co\/2eUiSY6OWe",
  "id" : 649601518354739200,
  "created_at" : "2015-10-01 15:07:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 3, 18 ],
      "id_str" : "285614027",
      "id" : 285614027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/F2c81P4F2h",
      "expanded_url" : "https:\/\/twitter.com\/teflgeek\/status\/649577680195612672",
      "display_url" : "twitter.com\/teflgeek\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "649583338177609728",
  "text" : "RT @AnthonyTeacher: Interesting read! Shows the importance of some cultural training for natives working with NNS\n https:\/\/t.co\/F2c81P4F2h",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/F2c81P4F2h",
        "expanded_url" : "https:\/\/twitter.com\/teflgeek\/status\/649577680195612672",
        "display_url" : "twitter.com\/teflgeek\/statu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "649580244035325952",
    "text" : "Interesting read! Shows the importance of some cultural training for natives working with NNS\n https:\/\/t.co\/F2c81P4F2h",
    "id" : 649580244035325952,
    "created_at" : "2015-10-01 13:42:53 +0000",
    "user" : {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "protected" : false,
      "id_str" : "285614027",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/412336845658132481\/Om5kKuMQ_normal.jpeg",
      "id" : 285614027,
      "verified" : false
    }
  },
  "id" : 649583338177609728,
  "created_at" : "2015-10-01 13:55:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Cantarutti",
      "screen_name" : "pronbites",
      "indices" : [ 0, 10 ],
      "id_str" : "2451770871",
      "id" : 2451770871
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "649577684205486080",
  "geo" : { },
  "id_str" : "649579622267506688",
  "in_reply_to_user_id" : 2451770871,
  "text" : "@pronbites  :\/",
  "id" : 649579622267506688,
  "in_reply_to_status_id" : 649577684205486080,
  "created_at" : "2015-10-01 13:40:25 +0000",
  "in_reply_to_screen_name" : "pronbites",
  "in_reply_to_user_id_str" : "2451770871",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Cantarutti",
      "screen_name" : "pronbites",
      "indices" : [ 0, 10 ],
      "id_str" : "2451770871",
      "id" : 2451770871
    }, {
      "name" : "IATEFL Online",
      "screen_name" : "iateflonline",
      "indices" : [ 43, 56 ],
      "id_str" : "17447359",
      "id" : 17447359
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "649569328052989952",
  "geo" : { },
  "id_str" : "649577281090908161",
  "in_reply_to_user_id" : 2451770871,
  "text" : "@pronbites :\/ maybe a letter from a bod at @iateflonline?",
  "id" : 649577281090908161,
  "in_reply_to_status_id" : 649569328052989952,
  "created_at" : "2015-10-01 13:31:07 +0000",
  "in_reply_to_screen_name" : "pronbites",
  "in_reply_to_user_id_str" : "2451770871",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Cantarutti",
      "screen_name" : "pronbites",
      "indices" : [ 0, 10 ],
      "id_str" : "2451770871",
      "id" : 2451770871
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "649566265997139968",
  "geo" : { },
  "id_str" : "649568605730906112",
  "in_reply_to_user_id" : 2451770871,
  "text" : "@pronbites damn :0 what kind of school do u work for?",
  "id" : 649568605730906112,
  "in_reply_to_status_id" : 649566265997139968,
  "created_at" : "2015-10-01 12:56:38 +0000",
  "in_reply_to_screen_name" : "pronbites",
  "in_reply_to_user_id_str" : "2451770871",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VICE UK",
      "screen_name" : "VICEUK",
      "indices" : [ 3, 10 ],
      "id_str" : "15995155",
      "id" : 15995155
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/VICEUK\/status\/649551749481656320\/photo\/1",
      "indices" : [ 121, 140 ],
      "url" : "http:\/\/t.co\/b3GIdpgmZd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQOq63WWoAAi666.jpg",
      "id_str" : "649550699538325504",
      "id" : 649550699538325504,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQOq63WWoAAi666.jpg",
      "sizes" : [ {
        "h" : 289,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 544,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 544,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/b3GIdpgmZd"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/TOhSvx51e6",
      "expanded_url" : "http:\/\/bit.ly\/1L6n2O4",
      "display_url" : "bit.ly\/1L6n2O4"
    } ]
  },
  "geo" : { },
  "id_str" : "649560917001289728",
  "text" : "RT @VICEUK: Reasons why the nuclear destruction of life on Earth is good for the British economy: http:\/\/t.co\/TOhSvx51e6 http:\/\/t.co\/b3GIdp\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/VICEUK\/status\/649551749481656320\/photo\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/b3GIdpgmZd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQOq63WWoAAi666.jpg",
        "id_str" : "649550699538325504",
        "id" : 649550699538325504,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQOq63WWoAAi666.jpg",
        "sizes" : [ {
          "h" : 289,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 544,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 544,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/b3GIdpgmZd"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/TOhSvx51e6",
        "expanded_url" : "http:\/\/bit.ly\/1L6n2O4",
        "display_url" : "bit.ly\/1L6n2O4"
      } ]
    },
    "geo" : { },
    "id_str" : "649551749481656320",
    "text" : "Reasons why the nuclear destruction of life on Earth is good for the British economy: http:\/\/t.co\/TOhSvx51e6 http:\/\/t.co\/b3GIdpgmZd",
    "id" : 649551749481656320,
    "created_at" : "2015-10-01 11:49:39 +0000",
    "user" : {
      "name" : "VICE UK",
      "screen_name" : "VICEUK",
      "protected" : false,
      "id_str" : "15995155",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/742670922960805888\/_fxrTnfe_normal.jpg",
      "id" : 15995155,
      "verified" : true
    }
  },
  "id" : 649560917001289728,
  "created_at" : "2015-10-01 12:26:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "indices" : [ 65, 77 ],
      "id_str" : "849729062",
      "id" : 849729062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 0, 11 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "649558029348769792",
  "text" : "#corpusmooc come for the know-how, stay for the (Buffy) jokes by @TonyMcEnery",
  "id" : 649558029348769792,
  "created_at" : "2015-10-01 12:14:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 81, 89 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/CbeTTCb4L9",
      "expanded_url" : "https:\/\/youtu.be\/iFo5a3PFn1M",
      "display_url" : "youtu.be\/iFo5a3PFn1M"
    } ]
  },
  "geo" : { },
  "id_str" : "649487708482629632",
  "text" : "Jeremy Corbyn speech at Labour Party Conference 2015 https:\/\/t.co\/CbeTTCb4L9 via @YouTube",
  "id" : 649487708482629632,
  "created_at" : "2015-10-01 07:35:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "indices" : [ 3, 18 ],
      "id_str" : "152194866",
      "id" : 152194866
    }, {
      "name" : "Kirk Borne",
      "screen_name" : "KirkDBorne",
      "indices" : [ 50, 61 ],
      "id_str" : "534563976",
      "id" : 534563976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/w3YFY1einB",
      "expanded_url" : "http:\/\/tm.durusau.net\/?p=64734",
      "display_url" : "tm.durusau.net\/?p=64734"
    } ]
  },
  "geo" : { },
  "id_str" : "649476693535682560",
  "text" : "RT @patrickDurusau: Tracking Congressional Whores @KirkDBorne http:\/\/t.co\/w3YFY1einB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kirk Borne",
        "screen_name" : "KirkDBorne",
        "indices" : [ 30, 41 ],
        "id_str" : "534563976",
        "id" : 534563976
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/w3YFY1einB",
        "expanded_url" : "http:\/\/tm.durusau.net\/?p=64734",
        "display_url" : "tm.durusau.net\/?p=64734"
      } ]
    },
    "geo" : { },
    "id_str" : "649301331535101956",
    "text" : "Tracking Congressional Whores @KirkDBorne http:\/\/t.co\/w3YFY1einB",
    "id" : 649301331535101956,
    "created_at" : "2015-09-30 19:14:35 +0000",
    "user" : {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "protected" : false,
      "id_str" : "152194866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/961579480\/patrick_normal.jpeg",
      "id" : 152194866,
      "verified" : false
    }
  },
  "id" : 649476693535682560,
  "created_at" : "2015-10-01 06:51:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
} ]