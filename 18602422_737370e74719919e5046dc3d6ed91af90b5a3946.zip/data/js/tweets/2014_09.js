Grailbird.data.tweets_2014_09 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil Tubman",
      "screen_name" : "philtubman",
      "indices" : [ 0, 11 ],
      "id_str" : "32418010",
      "id" : 32418010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517053049848999936",
  "in_reply_to_user_id" : 32418010,
  "text" : "@philtubman hi in coursereader anyway to mark out blog posts from twitter chat automatically? thanks",
  "id" : 517053049848999936,
  "created_at" : "2014-09-30 20:47:08 +0000",
  "in_reply_to_screen_name" : "philtubman",
  "in_reply_to_user_id_str" : "32418010",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "indices" : [ 43, 58 ],
      "id_str" : "27716419",
      "id" : 27716419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/qvny8GB3ow",
      "expanded_url" : "http:\/\/www.craigmurray.org.uk\/archives\/2014\/09\/a-helot-society\/",
      "display_url" : "craigmurray.org.uk\/archives\/2014\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "516962654905061376",
  "text" : "A Helot Society http:\/\/t.co\/qvny8GB3ow via @CraigMurrayOrg",
  "id" : 516962654905061376,
  "created_at" : "2014-09-30 14:47:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "indices" : [ 3, 15 ],
      "id_str" : "849729062",
      "id" : 849729062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusMOOC",
      "indices" : [ 34, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "516900650345840640",
  "text" : "RT @TonyMcEnery: Some students on #corpusMOOC have asked for the videos to be downloadable - done! Look for the download link beneath each \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpusMOOC",
        "indices" : [ 17, 28 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "516874978986590208",
    "text" : "Some students on #corpusMOOC have asked for the videos to be downloadable - done! Look for the download link beneath each video.",
    "id" : 516874978986590208,
    "created_at" : "2014-09-30 08:59:32 +0000",
    "user" : {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "protected" : false,
      "id_str" : "849729062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2676020930\/a4a1f40d56b447c9dfca1d7b9be4f4b4_normal.jpeg",
      "id" : 849729062,
      "verified" : false
    }
  },
  "id" : 516900650345840640,
  "created_at" : "2014-09-30 10:41:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke",
      "screen_name" : "lukewrites",
      "indices" : [ 0, 11 ],
      "id_str" : "17930434",
      "id" : 17930434
    }, {
      "name" : "Scott Roy Douglas",
      "screen_name" : "scottroydouglas",
      "indices" : [ 12, 28 ],
      "id_str" : "1263168308",
      "id" : 1263168308
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/DGOJhEuLyo",
      "expanded_url" : "https:\/\/plus.google.com\/u\/0\/communities\/101266284417587206243",
      "display_url" : "plus.google.com\/u\/0\/communitie\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "516835002835668994",
  "geo" : { },
  "id_str" : "516900592959361024",
  "in_reply_to_user_id" : 17930434,
  "text" : "@lukewrites @scottroydouglas hi there you may be interested in G+ CL community https:\/\/t.co\/DGOJhEuLyo",
  "id" : 516900592959361024,
  "in_reply_to_status_id" : 516835002835668994,
  "created_at" : "2014-09-30 10:41:19 +0000",
  "in_reply_to_screen_name" : "lukewrites",
  "in_reply_to_user_id_str" : "17930434",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil Tubman",
      "screen_name" : "philtubman",
      "indices" : [ 0, 11 ],
      "id_str" : "32418010",
      "id" : 32418010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "516606427662516224",
  "geo" : { },
  "id_str" : "516669442995273728",
  "in_reply_to_user_id" : 32418010,
  "text" : "@philtubman hi right thanks :)",
  "id" : 516669442995273728,
  "in_reply_to_status_id" : 516606427662516224,
  "created_at" : "2014-09-29 19:22:49 +0000",
  "in_reply_to_screen_name" : "philtubman",
  "in_reply_to_user_id_str" : "32418010",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusMOOC",
      "indices" : [ 0, 11 ]
    } ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/XzussrMUD3",
      "expanded_url" : "http:\/\/eflnotes.wordpress.com\/2014\/09\/29\/corpusmooc-round-2\/",
      "display_url" : "eflnotes.wordpress.com\/2014\/09\/29\/cor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "516595244113350657",
  "text" : "#corpusMOOC intro post http:\/\/t.co\/XzussrMUD3 though blog aggregator does not seem so automatic? :\/",
  "id" : 516595244113350657,
  "created_at" : "2014-09-29 14:27:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Aisha Brown",
      "screen_name" : "amyaishab",
      "indices" : [ 0, 10 ],
      "id_str" : "900029641",
      "id" : 900029641
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "516592477684662273",
  "geo" : { },
  "id_str" : "516594621141774336",
  "in_reply_to_user_id" : 900029641,
  "text" : "@amyaishab hehe yeah time flies when u r corpusmoocing :)",
  "id" : 516594621141774336,
  "in_reply_to_status_id" : 516592477684662273,
  "created_at" : "2014-09-29 14:25:30 +0000",
  "in_reply_to_screen_name" : "amyaishab",
  "in_reply_to_user_id_str" : "900029641",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Aisha Brown",
      "screen_name" : "amyaishab",
      "indices" : [ 0, 10 ],
      "id_str" : "900029641",
      "id" : 900029641
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "516573776017121281",
  "geo" : { },
  "id_str" : "516589851320545280",
  "in_reply_to_user_id" : 900029641,
  "text" : "@amyaishab hi yes it's working now :)",
  "id" : 516589851320545280,
  "in_reply_to_status_id" : 516573776017121281,
  "created_at" : "2014-09-29 14:06:32 +0000",
  "in_reply_to_screen_name" : "amyaishab",
  "in_reply_to_user_id_str" : "900029641",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 13, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "516390428065943552",
  "text" : "nice, new on #corpusmooc an rss blog aggregator though registering on it seems closed?",
  "id" : 516390428065943552,
  "created_at" : "2014-09-29 00:54:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yasu",
      "screen_name" : "casualconc",
      "indices" : [ 0, 11 ],
      "id_str" : "132412691",
      "id" : 132412691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "516337183209177088",
  "geo" : { },
  "id_str" : "516348055965401089",
  "in_reply_to_user_id" : 132412691,
  "text" : "@casualconc yes have tried casualconc great program, though i am looking for a browser based concordancer, mail sent to your gmail add thx",
  "id" : 516348055965401089,
  "in_reply_to_status_id" : 516337183209177088,
  "created_at" : "2014-09-28 22:05:44 +0000",
  "in_reply_to_screen_name" : "casualconc",
  "in_reply_to_user_id_str" : "132412691",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 123, 140 ],
      "url" : "http:\/\/t.co\/NFswRZ3kVc",
      "expanded_url" : "http:\/\/www.politico.com\/blogs\/politico-live\/2014\/09\/sunni-shiaa-islamic-conflicts-now-biggest-cause-of-196210.html",
      "display_url" : "politico.com\/blogs\/politico\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "516320264351928320",
  "text" : "RT @pchallinor: I know! Let's send a drone back to the seventh century and assassinate Ali ibn Abi Talib. That'll sort 'em http:\/\/t.co\/NFsw\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/NFswRZ3kVc",
        "expanded_url" : "http:\/\/www.politico.com\/blogs\/politico-live\/2014\/09\/sunni-shiaa-islamic-conflicts-now-biggest-cause-of-196210.html",
        "display_url" : "politico.com\/blogs\/politico\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "516255531720531969",
    "text" : "I know! Let's send a drone back to the seventh century and assassinate Ali ibn Abi Talib. That'll sort 'em http:\/\/t.co\/NFswRZ3kVc",
    "id" : 516255531720531969,
    "created_at" : "2014-09-28 15:58:04 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 516320264351928320,
  "created_at" : "2014-09-28 20:15:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    }, {
      "name" : "Liberal Democrats",
      "screen_name" : "LibDems",
      "indices" : [ 34, 42 ],
      "id_str" : "5680622",
      "id" : 5680622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/24sbxHhxdw",
      "expanded_url" : "http:\/\/www.katebelgrave.com\/2014\/09\/learning-and-literacy-difficulties-no-computer-but-do-your-jobsearch-online-yourself-thanks\/",
      "display_url" : "katebelgrave.com\/2014\/09\/learni\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "516319970192801794",
  "text" : "RT @pchallinor: Aren't you proud, @LibDems? Doesn't it make you go all gooey inside, being a party to this? http:\/\/t.co\/24sbxHhxdw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Liberal Democrats",
        "screen_name" : "LibDems",
        "indices" : [ 18, 26 ],
        "id_str" : "5680622",
        "id" : 5680622
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/24sbxHhxdw",
        "expanded_url" : "http:\/\/www.katebelgrave.com\/2014\/09\/learning-and-literacy-difficulties-no-computer-but-do-your-jobsearch-online-yourself-thanks\/",
        "display_url" : "katebelgrave.com\/2014\/09\/learni\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "516254760249602048",
    "text" : "Aren't you proud, @LibDems? Doesn't it make you go all gooey inside, being a party to this? http:\/\/t.co\/24sbxHhxdw",
    "id" : 516254760249602048,
    "created_at" : "2014-09-28 15:55:01 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 516319970192801794,
  "created_at" : "2014-09-28 20:14:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yasu",
      "screen_name" : "casualconc",
      "indices" : [ 28, 39 ],
      "id_str" : "132412691",
      "id" : 132412691
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "concordancer",
      "indices" : [ 11, 24 ]
    }, {
      "text" : "CorpusMOOC",
      "indices" : [ 102, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/H2jUF3vSoi",
      "expanded_url" : "http:\/\/www.ne.jp\/asahi\/yasu\/casualconc\/casualconcpages\/conc.html",
      "display_url" : "ne.jp\/asahi\/yasu\/cas\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "516309014926598144",
  "text" : "online web #concordancer by @casualconc http:\/\/t.co\/H2jUF3vSoi a parallel concordancer also available #CorpusMOOC",
  "id" : 516309014926598144,
  "created_at" : "2014-09-28 19:30:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yasu",
      "screen_name" : "casualconc",
      "indices" : [ 0, 11 ],
      "id_str" : "132412691",
      "id" : 132412691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "516308632284463104",
  "in_reply_to_user_id" : 132412691,
  "text" : "@casualconc hi any plans to have upload file feature on web concordancer? also possible to use on own computer? thx",
  "id" : 516308632284463104,
  "created_at" : "2014-09-28 19:29:05 +0000",
  "in_reply_to_screen_name" : "casualconc",
  "in_reply_to_user_id_str" : "132412691",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u00C9oin",
      "screen_name" : "LabourEoin",
      "indices" : [ 3, 14 ],
      "id_str" : "168090600",
      "id" : 168090600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/JlZ1Xx442D",
      "expanded_url" : "http:\/\/english.alarabiya.net\/en\/News\/middle-east\/2014\/09\/27\/UK-purchases-20-Tomahawk-missiles-from-U-S-.html",
      "display_url" : "english.alarabiya.net\/en\/News\/middle\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "516142040883929088",
  "text" : "RT @LabourEoin: UK purchases 20 Cruise Missiles costing $32,000,000 from the USA in preparation for their ISIS campaign\nhttp:\/\/t.co\/JlZ1Xx4\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/JlZ1Xx442D",
        "expanded_url" : "http:\/\/english.alarabiya.net\/en\/News\/middle-east\/2014\/09\/27\/UK-purchases-20-Tomahawk-missiles-from-U-S-.html",
        "display_url" : "english.alarabiya.net\/en\/News\/middle\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "516138905377452033",
    "text" : "UK purchases 20 Cruise Missiles costing $32,000,000 from the USA in preparation for their ISIS campaign\nhttp:\/\/t.co\/JlZ1Xx442D",
    "id" : 516138905377452033,
    "created_at" : "2014-09-28 08:14:39 +0000",
    "user" : {
      "name" : "\u00C9oin",
      "screen_name" : "LabourEoin",
      "protected" : false,
      "id_str" : "168090600",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/767054309792047104\/mJQBKMcG_normal.jpg",
      "id" : 168090600,
      "verified" : false
    }
  },
  "id" : 516142040883929088,
  "created_at" : "2014-09-28 08:27:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark J Doran",
      "screen_name" : "MarkJDoran",
      "indices" : [ 3, 14 ],
      "id_str" : "19364252",
      "id" : 19364252
    }, {
      "name" : "lyse doucet",
      "screen_name" : "bbclysedoucet",
      "indices" : [ 33, 47 ],
      "id_str" : "108352527",
      "id" : 108352527
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "516131158288265216",
  "text" : "RT @MarkJDoran: Can someone tell @bbclysedoucet that re-packaging staged events as 'historic moments' just shows her to be a mouthpiece of \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "lyse doucet",
        "screen_name" : "bbclysedoucet",
        "indices" : [ 17, 31 ],
        "id_str" : "108352527",
        "id" : 108352527
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "515889847068659713",
    "geo" : { },
    "id_str" : "515890968600403969",
    "in_reply_to_user_id" : 108352527,
    "text" : "Can someone tell @bbclysedoucet that re-packaging staged events as 'historic moments' just shows her to be a mouthpiece of state propaganda?",
    "id" : 515890968600403969,
    "in_reply_to_status_id" : 515889847068659713,
    "created_at" : "2014-09-27 15:49:26 +0000",
    "in_reply_to_screen_name" : "bbclysedoucet",
    "in_reply_to_user_id_str" : "108352527",
    "user" : {
      "name" : "Mark J Doran",
      "screen_name" : "MarkJDoran",
      "protected" : false,
      "id_str" : "19364252",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747220190887239680\/1sS-3xVw_normal.jpg",
      "id" : 19364252,
      "verified" : false
    }
  },
  "id" : 516131158288265216,
  "created_at" : "2014-09-28 07:43:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "b2g",
      "indices" : [ 44, 48 ]
    }, {
      "text" : "FirefoxOS",
      "indices" : [ 49, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515886574052319232",
  "text" : "sat afternoon means another go at compiling #b2g #FirefoxOS wish me luck :)",
  "id" : 515886574052319232,
  "created_at" : "2014-09-27 15:31:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Cook",
      "screen_name" : "Jonathan_K_Cook",
      "indices" : [ 3, 19 ],
      "id_str" : "2459644405",
      "id" : 2459644405
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/FUCNiiepe1",
      "expanded_url" : "http:\/\/shar.es\/1axX4A",
      "display_url" : "shar.es\/1axX4A"
    } ]
  },
  "geo" : { },
  "id_str" : "515864189051875328",
  "text" : "RT @Jonathan_K_Cook: The ringworm children - Israel\u2019s very own history of eugenics | Jonathan Cook's Blog http:\/\/t.co\/FUCNiiepe1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/FUCNiiepe1",
        "expanded_url" : "http:\/\/shar.es\/1axX4A",
        "display_url" : "shar.es\/1axX4A"
      } ]
    },
    "geo" : { },
    "id_str" : "515620440446754818",
    "text" : "The ringworm children - Israel\u2019s very own history of eugenics | Jonathan Cook's Blog http:\/\/t.co\/FUCNiiepe1",
    "id" : 515620440446754818,
    "created_at" : "2014-09-26 21:54:27 +0000",
    "user" : {
      "name" : "Jonathan Cook",
      "screen_name" : "Jonathan_K_Cook",
      "protected" : false,
      "id_str" : "2459644405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458948119749619713\/8ed1EDoY_normal.jpeg",
      "id" : 2459644405,
      "verified" : false
    }
  },
  "id" : 515864189051875328,
  "created_at" : "2014-09-27 14:03:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u00C9oin",
      "screen_name" : "LabourEoin",
      "indices" : [ 3, 14 ],
      "id_str" : "168090600",
      "id" : 168090600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/srOUuZf5o6",
      "expanded_url" : "http:\/\/www.almanar.com.lb\/english\/adetails.php?eid=173248&cid=23&fromval=1",
      "display_url" : "almanar.com.lb\/english\/adetai\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "515825588545011712",
  "text" : "RT @LabourEoin: Last night, 7 innocent Iraqi civilians were killed in a USA bombing in Northern Iraq. 2 Children were among the dead \nhttp:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/srOUuZf5o6",
        "expanded_url" : "http:\/\/www.almanar.com.lb\/english\/adetails.php?eid=173248&cid=23&fromval=1",
        "display_url" : "almanar.com.lb\/english\/adetai\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "515822022266748929",
    "text" : "Last night, 7 innocent Iraqi civilians were killed in a USA bombing in Northern Iraq. 2 Children were among the dead \nhttp:\/\/t.co\/srOUuZf5o6",
    "id" : 515822022266748929,
    "created_at" : "2014-09-27 11:15:28 +0000",
    "user" : {
      "name" : "\u00C9oin",
      "screen_name" : "LabourEoin",
      "protected" : false,
      "id_str" : "168090600",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/767054309792047104\/mJQBKMcG_normal.jpg",
      "id" : 168090600,
      "verified" : false
    }
  },
  "id" : 515825588545011712,
  "created_at" : "2014-09-27 11:29:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 122, 138 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/SaHCdY5TEC",
      "expanded_url" : "http:\/\/wp.me\/p2CPYN-fT",
      "display_url" : "wp.me\/p2CPYN-fT"
    } ]
  },
  "geo" : { },
  "id_str" : "515821586218115072",
  "text" : "International Committee of the Red Cross: U.S. airstrikes making a bad humanitarian situation\u2026 http:\/\/t.co\/SaHCdY5TEC via @wordpressdotcom",
  "id" : 515821586218115072,
  "created_at" : "2014-09-27 11:13:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u00C9oin",
      "screen_name" : "LabourEoin",
      "indices" : [ 3, 14 ],
      "id_str" : "168090600",
      "id" : 168090600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515796508055449600",
  "text" : "RT @LabourEoin: So far 154 innocent civilians have been killed in Air Strikes on ISIS, including 40 children. Also, 255 Sunnis executed by \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "515584151211491328",
    "text" : "So far 154 innocent civilians have been killed in Air Strikes on ISIS, including 40 children. Also, 255 Sunnis executed by Iraq Government.",
    "id" : 515584151211491328,
    "created_at" : "2014-09-26 19:30:15 +0000",
    "user" : {
      "name" : "\u00C9oin",
      "screen_name" : "LabourEoin",
      "protected" : false,
      "id_str" : "168090600",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/767054309792047104\/mJQBKMcG_normal.jpg",
      "id" : 168090600,
      "verified" : false
    }
  },
  "id" : 515796508055449600,
  "created_at" : "2014-09-27 09:34:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/u9tOGd1ORX",
      "expanded_url" : "http:\/\/www.theguardian.com\/politics\/2014\/sep\/25\/mps-commons-debate-iraq-air-strikes",
      "display_url" : "theguardian.com\/politics\/2014\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "515787204237742082",
  "text" : "RT @pchallinor: We can wog-bomb in Syria too! Oh rah http:\/\/t.co\/u9tOGd1ORX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 59 ],
        "url" : "http:\/\/t.co\/u9tOGd1ORX",
        "expanded_url" : "http:\/\/www.theguardian.com\/politics\/2014\/sep\/25\/mps-commons-debate-iraq-air-strikes",
        "display_url" : "theguardian.com\/politics\/2014\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "515489988855992320",
    "text" : "We can wog-bomb in Syria too! Oh rah http:\/\/t.co\/u9tOGd1ORX",
    "id" : 515489988855992320,
    "created_at" : "2014-09-26 13:16:05 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 515787204237742082,
  "created_at" : "2014-09-27 08:57:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alan mills",
      "screen_name" : "alanmills405",
      "indices" : [ 3, 16 ],
      "id_str" : "28580345",
      "id" : 28580345
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515786114079416320",
  "text" : "RT @alanmills405: Every \u00A333k hour a Tornado flies is equivalent to hiring a nurse for a year. Fire a \u00A31m Tomahawk missile and it's a school\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "515590242225905664",
    "text" : "Every \u00A333k hour a Tornado flies is equivalent to hiring a nurse for a year. Fire a \u00A31m Tomahawk missile and it's a school full of teachers.",
    "id" : 515590242225905664,
    "created_at" : "2014-09-26 19:54:27 +0000",
    "user" : {
      "name" : "alan mills",
      "screen_name" : "alanmills405",
      "protected" : false,
      "id_str" : "28580345",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/642796535634378752\/HI-t47n6_normal.jpg",
      "id" : 28580345,
      "verified" : false
    }
  },
  "id" : 515786114079416320,
  "created_at" : "2014-09-27 08:52:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ozgur Dogan",
      "screen_name" : "ozgurdogan",
      "indices" : [ 0, 11 ],
      "id_str" : "17864760",
      "id" : 17864760
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515785423583735808",
  "in_reply_to_user_id" : 17864760,
  "text" : "@ozgurdogan thanks for rt :)",
  "id" : 515785423583735808,
  "created_at" : "2014-09-27 08:50:02 +0000",
  "in_reply_to_screen_name" : "ozgurdogan",
  "in_reply_to_user_id_str" : "17864760",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 0, 9 ],
      "id_str" : "121063600",
      "id" : 121063600
    }, {
      "name" : "corpuscall",
      "screen_name" : "corpuscall",
      "indices" : [ 10, 21 ],
      "id_str" : "50638424",
      "id" : 50638424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "515762393855823872",
  "geo" : { },
  "id_str" : "515785308978548736",
  "in_reply_to_user_id" : 121063600,
  "text" : "@whyshona @corpuscall ta for share shona :) have a good 'un",
  "id" : 515785308978548736,
  "in_reply_to_status_id" : 515762393855823872,
  "created_at" : "2014-09-27 08:49:35 +0000",
  "in_reply_to_screen_name" : "whyshona",
  "in_reply_to_user_id_str" : "121063600",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bill",
      "screen_name" : "kingbill73",
      "indices" : [ 3, 14 ],
      "id_str" : "508707283",
      "id" : 508707283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515561400069292032",
  "text" : "RT @kingbill73: I take it Tony Blair doesn't get performance related pay in his role as a peace envoy.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 53.7431845, -0.3568557 ]
    },
    "id_str" : "515507449747759104",
    "text" : "I take it Tony Blair doesn't get performance related pay in his role as a peace envoy.",
    "id" : 515507449747759104,
    "created_at" : "2014-09-26 14:25:28 +0000",
    "user" : {
      "name" : "bill",
      "screen_name" : "kingbill73",
      "protected" : false,
      "id_str" : "508707283",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3535369851\/3af77718af72f31cb990f1cee488c4bc_normal.jpeg",
      "id" : 508707283,
      "verified" : false
    }
  },
  "id" : 515561400069292032,
  "created_at" : "2014-09-26 17:59:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515560133842448385",
  "text" : "RT @medialens: 524 MPs for war and 43 against. After the lies\/catastrophes of Iraq 2003 and Libya, a good measure of the health of UK democ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "515545914711506944",
    "text" : "524 MPs for war and 43 against. After the lies\/catastrophes of Iraq 2003 and Libya, a good measure of the health of UK democracy.",
    "id" : 515545914711506944,
    "created_at" : "2014-09-26 16:58:19 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 515560133842448385,
  "created_at" : "2014-09-26 17:54:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MarisaConstantinides",
      "screen_name" : "Marisa_C",
      "indices" : [ 0, 9 ],
      "id_str" : "18272500",
      "id" : 18272500
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515518690012712961",
  "in_reply_to_user_id" : 18272500,
  "text" : "@Marisa_C thx for rt marisa have a good w\/e :)",
  "id" : 515518690012712961,
  "created_at" : "2014-09-26 15:10:08 +0000",
  "in_reply_to_screen_name" : "Marisa_C",
  "in_reply_to_user_id_str" : "18272500",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bella Caledonia",
      "screen_name" : "bellacaledonia",
      "indices" : [ 63, 78 ],
      "id_str" : "103554348",
      "id" : 103554348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/vbm7tAY6wR",
      "expanded_url" : "http:\/\/wp.me\/p93oK-4mw",
      "display_url" : "wp.me\/p93oK-4mw"
    } ]
  },
  "geo" : { },
  "id_str" : "515518507019034624",
  "text" : "An Independent Media for Scotland?  http:\/\/t.co\/vbm7tAY6wR via @bellacaledonia",
  "id" : 515518507019034624,
  "created_at" : "2014-09-26 15:09:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 45, 53 ]
    }, {
      "text" : "esl",
      "indices" : [ 54, 58 ]
    }, {
      "text" : "tefl",
      "indices" : [ 59, 64 ]
    }, {
      "text" : "eltchinwag",
      "indices" : [ 65, 76 ]
    }, {
      "text" : "videogrep",
      "indices" : [ 77, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/4TEbZSY7d6",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-OF",
      "display_url" : "wp.me\/pgHyE-OF"
    } ]
  },
  "geo" : { },
  "id_str" : "515508476554932225",
  "text" : "Easy micro-listenings http:\/\/t.co\/4TEbZSY7d6 #eltchat #esl #tefl #eltchinwag #videogrep",
  "id" : 515508476554932225,
  "created_at" : "2014-09-26 14:29:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Iraq",
      "indices" : [ 105, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515482945596194816",
  "text" : "RT @pchallinor: We must ally ourselves with the forces of responsible absolutism and Decent Decapitation #Iraq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Iraq",
        "indices" : [ 89, 94 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "515240765589819392",
    "text" : "We must ally ourselves with the forces of responsible absolutism and Decent Decapitation #Iraq",
    "id" : 515240765589819392,
    "created_at" : "2014-09-25 20:45:45 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 515482945596194816,
  "created_at" : "2014-09-26 12:48:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Patsko",
      "screen_name" : "lauraahaha",
      "indices" : [ 0, 11 ],
      "id_str" : "97957137",
      "id" : 97957137
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "515464221711417344",
  "geo" : { },
  "id_str" : "515479734558674944",
  "in_reply_to_user_id" : 97957137,
  "text" : "@lauraahaha hi-friking-larious cheers laura :)",
  "id" : 515479734558674944,
  "in_reply_to_status_id" : 515464221711417344,
  "created_at" : "2014-09-26 12:35:20 +0000",
  "in_reply_to_screen_name" : "lauraahaha",
  "in_reply_to_user_id_str" : "97957137",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/kfpUKRx7Ff",
      "expanded_url" : "http:\/\/rt.com\/op-edge\/190684-syria-coalition-airstrikes-isis\/#.VCTos_MzH44.twitter",
      "display_url" : "rt.com\/op-edge\/190684\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "515354304408858624",
  "text" : "The airwaves are still heaving with spin two days after US airstrikes against Syria \u2014 RT Op-Edge http:\/\/t.co\/kfpUKRx7Ff",
  "id" : 515354304408858624,
  "created_at" : "2014-09-26 04:16:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J",
      "screen_name" : "jimmurphymp",
      "indices" : [ 0, 12 ],
      "id_str" : "3063840999",
      "id" : 3063840999
    }, {
      "name" : "Graham",
      "screen_name" : "onalifeglug",
      "indices" : [ 13, 25 ],
      "id_str" : "19516039",
      "id" : 19516039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "515250075640283136",
  "geo" : { },
  "id_str" : "515256438940499970",
  "in_reply_to_user_id" : 32522100,
  "text" : "@jimmurphymp @onalifeglug \"complexity\" newspeak for \"white mans burden\"",
  "id" : 515256438940499970,
  "in_reply_to_status_id" : 515250075640283136,
  "created_at" : "2014-09-25 21:48:02 +0000",
  "in_reply_to_screen_name" : "GlasgowMurphy",
  "in_reply_to_user_id_str" : "32522100",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyler Schnoebelen",
      "screen_name" : "TSchnoebelen",
      "indices" : [ 0, 13 ],
      "id_str" : "14969147",
      "id" : 14969147
    }, {
      "name" : "Digital Rand",
      "screen_name" : "kenya_tweets",
      "indices" : [ 14, 27 ],
      "id_str" : "176040709",
      "id" : 176040709
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "515212994721374208",
  "geo" : { },
  "id_str" : "515242331541630976",
  "in_reply_to_user_id" : 14969147,
  "text" : "@TSchnoebelen @kenya_tweets hi the corpuscollie link is broken, also any info if that program is available anywhere? thx",
  "id" : 515242331541630976,
  "in_reply_to_status_id" : 515212994721374208,
  "created_at" : "2014-09-25 20:51:59 +0000",
  "in_reply_to_screen_name" : "TSchnoebelen",
  "in_reply_to_user_id_str" : "14969147",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515238761832390656",
  "text" : "RT @pchallinor: Been 11yrs since wog-bombing turned Iraq into the world's biggest terrorist recruiting station. Why *wouldn't* it do the ex\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "515230034836348929",
    "text" : "Been 11yrs since wog-bombing turned Iraq into the world's biggest terrorist recruiting station. Why *wouldn't* it do the exact opposite now?",
    "id" : 515230034836348929,
    "created_at" : "2014-09-25 20:03:07 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 515238761832390656,
  "created_at" : "2014-09-25 20:37:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    }, {
      "name" : "Neil Clark",
      "screen_name" : "NeilClark66",
      "indices" : [ 77, 89 ],
      "id_str" : "728039605",
      "id" : 728039605
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/mw197sCKpl",
      "expanded_url" : "http:\/\/rt.com\/op-edge\/190580-obama-coffee-military-operation-syria\/#",
      "display_url" : "rt.com\/op-edge\/190580\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "515236983044861953",
  "text" : "RT @medialens: Have not read a more insightful piece on Obama than this from @NeilClark66 http:\/\/t.co\/mw197sCKpl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Neil Clark",
        "screen_name" : "NeilClark66",
        "indices" : [ 62, 74 ],
        "id_str" : "728039605",
        "id" : 728039605
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/mw197sCKpl",
        "expanded_url" : "http:\/\/rt.com\/op-edge\/190580-obama-coffee-military-operation-syria\/#",
        "display_url" : "rt.com\/op-edge\/190580\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "515187052032569344",
    "text" : "Have not read a more insightful piece on Obama than this from @NeilClark66 http:\/\/t.co\/mw197sCKpl",
    "id" : 515187052032569344,
    "created_at" : "2014-09-25 17:12:19 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 515236983044861953,
  "created_at" : "2014-09-25 20:30:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((David Traynier)))",
      "screen_name" : "DTraynier",
      "indices" : [ 3, 13 ],
      "id_str" : "317716198",
      "id" : 317716198
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IS",
      "indices" : [ 133, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515236862483771393",
  "text" : "RT @DTraynier: The 99% of decent, peaceful capitalists need to denounce the terrorism of extremists like Cameron, Obama &amp; Blair. #IS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/seesmic.com\/\" rel=\"nofollow\"\u003ESeesmic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IS",
        "indices" : [ 118, 121 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "515217775049334785",
    "text" : "The 99% of decent, peaceful capitalists need to denounce the terrorism of extremists like Cameron, Obama &amp; Blair. #IS",
    "id" : 515217775049334785,
    "created_at" : "2014-09-25 19:14:24 +0000",
    "user" : {
      "name" : "(((David Traynier)))",
      "screen_name" : "DTraynier",
      "protected" : false,
      "id_str" : "317716198",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727929911877480451\/fLuwL370_normal.jpg",
      "id" : 317716198,
      "verified" : false
    }
  },
  "id" : 515236862483771393,
  "created_at" : "2014-09-25 20:30:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wiktorkompe",
      "screen_name" : "wiktor_k",
      "indices" : [ 0, 9 ],
      "id_str" : "733704413383168000",
      "id" : 733704413383168000
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "515231332197494785",
  "geo" : { },
  "id_str" : "515235054935867393",
  "in_reply_to_user_id" : 222498082,
  "text" : "@Wiktor_K an orphanage of cutlery? a missing drawer of teaspoons?",
  "id" : 515235054935867393,
  "in_reply_to_status_id" : 515231332197494785,
  "created_at" : "2014-09-25 20:23:04 +0000",
  "in_reply_to_screen_name" : "BRAVE_Learning",
  "in_reply_to_user_id_str" : "222498082",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 89, 105 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/HQdATFyua4",
      "expanded_url" : "http:\/\/wp.me\/p35c7d-jc",
      "display_url" : "wp.me\/p35c7d-jc"
    } ]
  },
  "geo" : { },
  "id_str" : "515062017355309057",
  "text" : "Half of the Statistics in Visible Learning are wrong (Part 2) http:\/\/t.co\/HQdATFyua4 via @wordpressdotcom",
  "id" : 515062017355309057,
  "created_at" : "2014-09-25 08:55:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 0, 14 ],
      "id_str" : "25388528",
      "id" : 25388528
    }, {
      "name" : "Neil Selwyn",
      "screen_name" : "Neil_Selwyn",
      "indices" : [ 27, 39 ],
      "id_str" : "142598896",
      "id" : 142598896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "514898077245665280",
  "geo" : { },
  "id_str" : "515020915433046018",
  "in_reply_to_user_id" : 25388528,
  "text" : "@audreywatters neil selwyn @Neil_Selwyn",
  "id" : 515020915433046018,
  "in_reply_to_status_id" : 514898077245665280,
  "created_at" : "2014-09-25 06:12:09 +0000",
  "in_reply_to_screen_name" : "audreywatters",
  "in_reply_to_user_id_str" : "25388528",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke",
      "screen_name" : "lukewrites",
      "indices" : [ 0, 11 ],
      "id_str" : "17930434",
      "id" : 17930434
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 91, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/B08ixvohXM",
      "expanded_url" : "http:\/\/www.thegrammarlab.com\/?p=411",
      "display_url" : "thegrammarlab.com\/?p=411"
    } ]
  },
  "in_reply_to_status_id_str" : "514570550211932160",
  "geo" : { },
  "id_str" : "514899835355680768",
  "in_reply_to_user_id" : 17930434,
  "text" : "@lukewrites i don't think so but this is a great post on doing this http:\/\/t.co\/B08ixvohXM #corpusmooc",
  "id" : 514899835355680768,
  "in_reply_to_status_id" : 514570550211932160,
  "created_at" : "2014-09-24 22:11:01 +0000",
  "in_reply_to_screen_name" : "lukewrites",
  "in_reply_to_user_id_str" : "17930434",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MarisaConstantinides",
      "screen_name" : "Marisa_C",
      "indices" : [ 11, 20 ],
      "id_str" : "18272500",
      "id" : 18272500
    }, {
      "name" : "Sue Annan",
      "screen_name" : "SueAnnan",
      "indices" : [ 21, 30 ],
      "id_str" : "136001411",
      "id" : 136001411
    }, {
      "name" : "Shaunwilden",
      "screen_name" : "Shaunwilden",
      "indices" : [ 31, 43 ],
      "id_str" : "15350512",
      "id" : 15350512
    }, {
      "name" : "James Taylor",
      "screen_name" : "theteacherjames",
      "indices" : [ 44, 60 ],
      "id_str" : "71746265",
      "id" : 71746265
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "514886634756509696",
  "geo" : { },
  "id_str" : "514887145019170816",
  "in_reply_to_user_id" : 44631065,
  "text" : "@HadaLitim @Marisa_C @SueAnnan @Shaunwilden @theteacherjames oh those usual suspects ;)",
  "id" : 514887145019170816,
  "in_reply_to_status_id" : 514886634756509696,
  "created_at" : "2014-09-24 21:20:36 +0000",
  "in_reply_to_screen_name" : "Hada_ELT",
  "in_reply_to_user_id_str" : "44631065",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELTchat",
      "indices" : [ 46, 54 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "514882593716588544",
  "geo" : { },
  "id_str" : "514886120866603009",
  "in_reply_to_user_id" : 44631065,
  "text" : "@HadaLitim your mod skills are outstanding :) #ELTchat",
  "id" : 514886120866603009,
  "in_reply_to_status_id" : 514882593716588544,
  "created_at" : "2014-09-24 21:16:31 +0000",
  "in_reply_to_screen_name" : "Hada_ELT",
  "in_reply_to_user_id_str" : "44631065",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Pride",
      "screen_name" : "ThomasPride",
      "indices" : [ 94, 106 ],
      "id_str" : "385867551",
      "id" : 385867551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/a9RNw7y0Ke",
      "expanded_url" : "http:\/\/wp.me\/p1U04a-84y",
      "display_url" : "wp.me\/p1U04a-84y"
    } ]
  },
  "geo" : { },
  "id_str" : "514883516304076800",
  "text" : "Cameron to recall parliament to decide which side to bomb in Syria http:\/\/t.co\/a9RNw7y0Ke via @ThomasPride",
  "id" : 514883516304076800,
  "created_at" : "2014-09-24 21:06:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELTchat",
      "indices" : [ 14, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514882441681858561",
  "text" : "thanks all :) #ELTchat",
  "id" : 514882441681858561,
  "created_at" : "2014-09-24 21:01:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 0, 9 ],
      "id_str" : "134211317",
      "id" : 134211317
    }, {
      "name" : "Vedrana Vojkovi\u0107",
      "screen_name" : "Ven_VVE",
      "indices" : [ 10, 18 ],
      "id_str" : "270839603",
      "id" : 270839603
    }, {
      "name" : "MarisaConstantinides",
      "screen_name" : "Marisa_C",
      "indices" : [ 19, 28 ],
      "id_str" : "18272500",
      "id" : 18272500
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELTchat",
      "indices" : [ 61, 69 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "514880557504032768",
  "geo" : { },
  "id_str" : "514881596168884224",
  "in_reply_to_user_id" : 134211317,
  "text" : "@josipa74 @Ven_VVE @Marisa_C just look at all the xmoocs ... #ELTchat",
  "id" : 514881596168884224,
  "in_reply_to_status_id" : 514880557504032768,
  "created_at" : "2014-09-24 20:58:33 +0000",
  "in_reply_to_screen_name" : "josipa74",
  "in_reply_to_user_id_str" : "134211317",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 132, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/eUruDQqZKH",
      "expanded_url" : "http:\/\/heloukee.wordpress.com\/2014\/09\/24\/we-are-the-audience-we-are-the-performers\/",
      "display_url" : "heloukee.wordpress.com\/2014\/09\/24\/we-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "514880965517520897",
  "text" : "Various learners often walk away from learning opportunities with tremendously different results and rewards http:\/\/t.co\/eUruDQqZKH #eltchat",
  "id" : 514880965517520897,
  "created_at" : "2014-09-24 20:56:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ccourses",
      "indices" : [ 119, 128 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 132, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514878534251446272",
  "text" : "some net courses don't make most of social e.g. forum clunky, no social media chatter, undervalue connectedness unlike #ccourses :) #eltchat",
  "id" : 514878534251446272,
  "created_at" : "2014-09-24 20:46:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "teachtheweb",
      "indices" : [ 102, 114 ]
    }, {
      "text" : "ELTchat",
      "indices" : [ 132, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514874061496008704",
  "text" : "imo if u hit on a good mix between the social &amp; yr interest in topic its a winner found this with #teachtheweb course last year #ELTchat",
  "id" : 514874061496008704,
  "created_at" : "2014-09-24 20:28:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Cook",
      "screen_name" : "Jonathan_K_Cook",
      "indices" : [ 3, 19 ],
      "id_str" : "2459644405",
      "id" : 2459644405
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/adyBcYUVyO",
      "expanded_url" : "http:\/\/shar.es\/1a5IJo",
      "display_url" : "shar.es\/1a5IJo"
    } ]
  },
  "geo" : { },
  "id_str" : "514871566648487936",
  "text" : "RT @Jonathan_K_Cook: Why Israelis are so frightened of a newborn\u2019s name it had to be censored | Jonathan Cook's Blog http:\/\/t.co\/adyBcYUVyO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/adyBcYUVyO",
        "expanded_url" : "http:\/\/shar.es\/1a5IJo",
        "display_url" : "shar.es\/1a5IJo"
      } ]
    },
    "geo" : { },
    "id_str" : "514067169223524352",
    "text" : "Why Israelis are so frightened of a newborn\u2019s name it had to be censored | Jonathan Cook's Blog http:\/\/t.co\/adyBcYUVyO",
    "id" : 514067169223524352,
    "created_at" : "2014-09-22 15:02:18 +0000",
    "user" : {
      "name" : "Jonathan Cook",
      "screen_name" : "Jonathan_K_Cook",
      "protected" : false,
      "id_str" : "2459644405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458948119749619713\/8ed1EDoY_normal.jpeg",
      "id" : 2459644405,
      "verified" : false
    }
  },
  "id" : 514871566648487936,
  "created_at" : "2014-09-24 20:18:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MarisaConstantinides",
      "screen_name" : "Marisa_C",
      "indices" : [ 0, 9 ],
      "id_str" : "18272500",
      "id" : 18272500
    }, {
      "name" : "Kate",
      "screen_name" : "KateLloyd05",
      "indices" : [ 10, 22 ],
      "id_str" : "71482132",
      "id" : 71482132
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELTchat",
      "indices" : [ 32, 40 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "514870211540189184",
  "geo" : { },
  "id_str" : "514870907312300032",
  "in_reply_to_user_id" : 18272500,
  "text" : "@Marisa_C @KateLloyd05 hi hi :) #ELTchat",
  "id" : 514870907312300032,
  "in_reply_to_status_id" : 514870211540189184,
  "created_at" : "2014-09-24 20:16:04 +0000",
  "in_reply_to_screen_name" : "Marisa_C",
  "in_reply_to_user_id_str" : "18272500",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELTchat",
      "indices" : [ 76, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514870050470506496",
  "text" : "not sure it is so neg to see familiar faces in terms of trust and learning? #ELTchat",
  "id" : 514870050470506496,
  "created_at" : "2014-09-24 20:12:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "indices" : [ 0, 12 ],
      "id_str" : "849729062",
      "id" : 849729062
    }, {
      "name" : "Paul Baker",
      "screen_name" : "_paulbaker_",
      "indices" : [ 13, 25 ],
      "id_str" : "1026683874",
      "id" : 1026683874
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "514861571399770113",
  "geo" : { },
  "id_str" : "514865915830468608",
  "in_reply_to_user_id" : 849729062,
  "text" : "@TonyMcEnery @_paulbaker_ hi did you include editorials in analysis?",
  "id" : 514865915830468608,
  "in_reply_to_status_id" : 514861571399770113,
  "created_at" : "2014-09-24 19:56:14 +0000",
  "in_reply_to_screen_name" : "TonyMcEnery",
  "in_reply_to_user_id_str" : "849729062",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "indices" : [ 3, 15 ],
      "id_str" : "849729062",
      "id" : 849729062
    }, {
      "name" : "Paul Baker",
      "screen_name" : "_paulbaker_",
      "indices" : [ 119, 131 ],
      "id_str" : "1026683874",
      "id" : 1026683874
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/CrMNc6RfhI",
      "expanded_url" : "http:\/\/cass.lancs.ac.uk\/?p=1410",
      "display_url" : "cass.lancs.ac.uk\/?p=1410"
    } ]
  },
  "geo" : { },
  "id_str" : "514865327642263554",
  "text" : "RT @TonyMcEnery: Strange bedfellows: Did the Scottish independence referendum unite the Guardian and Mail? Analysis by @_paulbaker_  http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Paul Baker",
        "screen_name" : "_paulbaker_",
        "indices" : [ 102, 114 ],
        "id_str" : "1026683874",
        "id" : 1026683874
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/CrMNc6RfhI",
        "expanded_url" : "http:\/\/cass.lancs.ac.uk\/?p=1410",
        "display_url" : "cass.lancs.ac.uk\/?p=1410"
      } ]
    },
    "geo" : { },
    "id_str" : "514861571399770113",
    "text" : "Strange bedfellows: Did the Scottish independence referendum unite the Guardian and Mail? Analysis by @_paulbaker_  http:\/\/t.co\/CrMNc6RfhI",
    "id" : 514861571399770113,
    "created_at" : "2014-09-24 19:38:58 +0000",
    "user" : {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "protected" : false,
      "id_str" : "849729062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2676020930\/a4a1f40d56b447c9dfca1d7b9be4f4b4_normal.jpeg",
      "id" : 849729062,
      "verified" : false
    }
  },
  "id" : 514865327642263554,
  "created_at" : "2014-09-24 19:53:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark J Doran",
      "screen_name" : "MarkJDoran",
      "indices" : [ 3, 14 ],
      "id_str" : "19364252",
      "id" : 19364252
    }, {
      "name" : "alan rusbridger",
      "screen_name" : "arusbridger",
      "indices" : [ 17, 29 ],
      "id_str" : "19534873",
      "id" : 19534873
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "privatised",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514862969164156929",
  "text" : "RT @MarkJDoran: .@arusbridger And of the promised NHS money, now much will vanish *instantly* -- as private shareholder payouts and CEO bon\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "alan rusbridger",
        "screen_name" : "arusbridger",
        "indices" : [ 1, 13 ],
        "id_str" : "19534873",
        "id" : 19534873
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "privatised",
        "indices" : [ 129, 140 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "514858646619308032",
    "geo" : { },
    "id_str" : "514859478315843584",
    "in_reply_to_user_id" : 19534873,
    "text" : ".@arusbridger And of the promised NHS money, now much will vanish *instantly* -- as private shareholder payouts and CEO bonuses? #privatised",
    "id" : 514859478315843584,
    "in_reply_to_status_id" : 514858646619308032,
    "created_at" : "2014-09-24 19:30:39 +0000",
    "in_reply_to_screen_name" : "arusbridger",
    "in_reply_to_user_id_str" : "19534873",
    "user" : {
      "name" : "Mark J Doran",
      "screen_name" : "MarkJDoran",
      "protected" : false,
      "id_str" : "19364252",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747220190887239680\/1sS-3xVw_normal.jpg",
      "id" : 19364252,
      "verified" : false
    }
  },
  "id" : 514862969164156929,
  "created_at" : "2014-09-24 19:44:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/od2VWopryB",
      "expanded_url" : "http:\/\/www.medialens.org\/index.php\/alerts\/alert-archive\/2014\/776-the-purpose-and.html",
      "display_url" : "medialens.org\/index.php\/aler\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "514861785888088064",
  "text" : "RT @medialens: Media Alert: The Purpose And The Pretence - Bombing Isis http:\/\/t.co\/od2VWopryB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/od2VWopryB",
        "expanded_url" : "http:\/\/www.medialens.org\/index.php\/alerts\/alert-archive\/2014\/776-the-purpose-and.html",
        "display_url" : "medialens.org\/index.php\/aler\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "514819086401155072",
    "text" : "Media Alert: The Purpose And The Pretence - Bombing Isis http:\/\/t.co\/od2VWopryB",
    "id" : 514819086401155072,
    "created_at" : "2014-09-24 16:50:09 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 514861785888088064,
  "created_at" : "2014-09-24 19:39:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 81, 89 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/iD5JbejbYo",
      "expanded_url" : "http:\/\/youtu.be\/TL7V0srlU2E",
      "display_url" : "youtu.be\/TL7V0srlU2E"
    } ]
  },
  "geo" : { },
  "id_str" : "514858506747248640",
  "text" : "Labour conference  Harry Smith on health and poverty: http:\/\/t.co\/iD5JbejbYo via @YouTube",
  "id" : 514858506747248640,
  "created_at" : "2014-09-24 19:26:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "English & Media Ctr",
      "screen_name" : "EngMediaCentre",
      "indices" : [ 0, 15 ],
      "id_str" : "432590539",
      "id" : 432590539
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "514746361783541760",
  "geo" : { },
  "id_str" : "514804323784851457",
  "in_reply_to_user_id" : 432590539,
  "text" : "@EngMediaCentre wonder what wordlist was used? as running a sample text through a vocab profiler shows words outside the 1st 1000",
  "id" : 514804323784851457,
  "in_reply_to_status_id" : 514746361783541760,
  "created_at" : "2014-09-24 15:51:30 +0000",
  "in_reply_to_screen_name" : "EngMediaCentre",
  "in_reply_to_user_id_str" : "432590539",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514802099587391488",
  "text" : "was about to correct a typo in a forum \"in a but of a hurry\" decided to leave it for comic effect :)",
  "id" : 514802099587391488,
  "created_at" : "2014-09-24 15:42:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hyperlapse",
      "indices" : [ 0, 11 ]
    }, {
      "text" : "prolapse",
      "indices" : [ 32, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514742268277059585",
  "text" : "#hyperlapse sounds too close to #prolapse for my liking :\/",
  "id" : 514742268277059585,
  "created_at" : "2014-09-24 11:44:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alannah Fitzgerald",
      "screen_name" : "AlannahFitz",
      "indices" : [ 0, 12 ],
      "id_str" : "223613160",
      "id" : 223613160
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514640560448368640",
  "in_reply_to_user_id" : 223613160,
  "text" : "@AlannahFitz hi do you know of any blogs\/tweets of talc2014?",
  "id" : 514640560448368640,
  "created_at" : "2014-09-24 05:00:45 +0000",
  "in_reply_to_screen_name" : "AlannahFitz",
  "in_reply_to_user_id_str" : "223613160",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alannah Fitzgerald",
      "screen_name" : "AlannahFitz",
      "indices" : [ 3, 15 ],
      "id_str" : "223613160",
      "id" : 223613160
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/5ukBCTTb63",
      "expanded_url" : "http:\/\/wp.me\/p4ZDSP-K9",
      "display_url" : "wp.me\/p4ZDSP-K9"
    } ]
  },
  "geo" : { },
  "id_str" : "514626490106130432",
  "text" : "RT @AlannahFitz: RADIO 3 \u2013 Research and teaching with language\u00A0corpora http:\/\/t.co\/5ukBCTTb63",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 76 ],
        "url" : "http:\/\/t.co\/5ukBCTTb63",
        "expanded_url" : "http:\/\/wp.me\/p4ZDSP-K9",
        "display_url" : "wp.me\/p4ZDSP-K9"
      } ]
    },
    "geo" : { },
    "id_str" : "514588340213936128",
    "text" : "RADIO 3 \u2013 Research and teaching with language\u00A0corpora http:\/\/t.co\/5ukBCTTb63",
    "id" : 514588340213936128,
    "created_at" : "2014-09-24 01:33:15 +0000",
    "user" : {
      "name" : "Alannah Fitzgerald",
      "screen_name" : "AlannahFitz",
      "protected" : false,
      "id_str" : "223613160",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2645381550\/e07d3b354efdac11bce2725cbc44e94e_normal.png",
      "id" : 223613160,
      "verified" : false
    }
  },
  "id" : 514626490106130432,
  "created_at" : "2014-09-24 04:04:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "seevl",
      "screen_name" : "seevl",
      "indices" : [ 3, 9 ],
      "id_str" : "190563332",
      "id" : 190563332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514536620608196608",
  "text" : "hi @seevl, play Manic Street Preachers",
  "id" : 514536620608196608,
  "created_at" : "2014-09-23 22:07:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "seevl",
      "screen_name" : "seevl",
      "indices" : [ 0, 6 ],
      "id_str" : "190563332",
      "id" : 190563332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514534928193970176",
  "in_reply_to_user_id" : 190563332,
  "text" : "@seevl play something like POS",
  "id" : 514534928193970176,
  "created_at" : "2014-09-23 22:01:01 +0000",
  "in_reply_to_screen_name" : "seevl",
  "in_reply_to_user_id_str" : "190563332",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike S. Boyle",
      "screen_name" : "heyboyle",
      "indices" : [ 0, 9 ],
      "id_str" : "612840231",
      "id" : 612840231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/aAg60CtdyC",
      "expanded_url" : "http:\/\/keenetrial.com\/blog\/2013\/10\/28\/stop-looking-at-your-smartphone-listen-to-me\/",
      "display_url" : "keenetrial.com\/blog\/2013\/10\/2\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "514521491619061760",
  "geo" : { },
  "id_str" : "514523723932901376",
  "in_reply_to_user_id" : 612840231,
  "text" : "@heyboyle more details of that study from 2013 article http:\/\/t.co\/aAg60CtdyC",
  "id" : 514523723932901376,
  "in_reply_to_status_id" : 514521491619061760,
  "created_at" : "2014-09-23 21:16:29 +0000",
  "in_reply_to_screen_name" : "heyboyle",
  "in_reply_to_user_id_str" : "612840231",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ccourses",
      "indices" : [ 121, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/b8rhrCXiPN",
      "expanded_url" : "http:\/\/members5.boardhost.com\/medialens\/msg\/1411475603.html",
      "display_url" : "members5.boardhost.com\/medialens\/msg\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "514519648248025088",
  "text" : "Universities to revamp economics courses http:\/\/t.co\/b8rhrCXiPN interesting example of student voices being listened to? #ccourses",
  "id" : 514519648248025088,
  "created_at" : "2014-09-23 21:00:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "indices" : [ 3, 18 ],
      "id_str" : "27716419",
      "id" : 27716419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/7CngPCXvR0",
      "expanded_url" : "http:\/\/bit.ly\/1wK7wOz",
      "display_url" : "bit.ly\/1wK7wOz"
    } ]
  },
  "geo" : { },
  "id_str" : "514464265873674240",
  "text" : "RT @CraigMurrayOrg: New post: Bombing Is Good For You http:\/\/t.co\/7CngPCXvR0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.craigmurray.org.uk\" rel=\"nofollow\"\u003ECraig Murray posting plugin\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 34, 56 ],
        "url" : "http:\/\/t.co\/7CngPCXvR0",
        "expanded_url" : "http:\/\/bit.ly\/1wK7wOz",
        "display_url" : "bit.ly\/1wK7wOz"
      } ]
    },
    "geo" : { },
    "id_str" : "514463936591462400",
    "text" : "New post: Bombing Is Good For You http:\/\/t.co\/7CngPCXvR0",
    "id" : 514463936591462400,
    "created_at" : "2014-09-23 17:18:55 +0000",
    "user" : {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "protected" : false,
      "id_str" : "27716419",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1388436826\/cm_normal.jpg",
      "id" : 27716419,
      "verified" : false
    }
  },
  "id" : 514464265873674240,
  "created_at" : "2014-09-23 17:20:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/medialens\/status\/514433966536138752\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/hH4fHdzAsQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ByOi9xmIUAAOjGB.png",
      "id_str" : "514433964619354112",
      "id" : 514433964619354112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByOi9xmIUAAOjGB.png",
      "sizes" : [ {
        "h" : 262,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 318,
        "resize" : "fit",
        "w" : 728
      }, {
        "h" : 318,
        "resize" : "fit",
        "w" : 728
      }, {
        "h" : 149,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/hH4fHdzAsQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514463993835290624",
  "text" : "RT @medialens: Any students out there studying Orwell's 1984? This is the kind of output George imagined from the Ministry of Truth http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/medialens\/status\/514433966536138752\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/hH4fHdzAsQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ByOi9xmIUAAOjGB.png",
        "id_str" : "514433964619354112",
        "id" : 514433964619354112,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByOi9xmIUAAOjGB.png",
        "sizes" : [ {
          "h" : 262,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 318,
          "resize" : "fit",
          "w" : 728
        }, {
          "h" : 318,
          "resize" : "fit",
          "w" : 728
        }, {
          "h" : 149,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/hH4fHdzAsQ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "514433966536138752",
    "text" : "Any students out there studying Orwell's 1984? This is the kind of output George imagined from the Ministry of Truth http:\/\/t.co\/hH4fHdzAsQ",
    "id" : 514433966536138752,
    "created_at" : "2014-09-23 15:19:50 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 514463993835290624,
  "created_at" : "2014-09-23 17:19:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "Chris Bunyan",
      "screen_name" : "bunyanchris",
      "indices" : [ 12, 24 ],
      "id_str" : "237402639",
      "id" : 237402639
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514443094125993984",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan @bunyanchris thanks leo &amp; chris for rt much appreciated!",
  "id" : 514443094125993984,
  "created_at" : "2014-09-23 15:56:06 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "514419539803504641",
  "geo" : { },
  "id_str" : "514442924080517120",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler cheers anne :) hope u r having a good start of the week",
  "id" : 514442924080517120,
  "in_reply_to_status_id" : 514419539803504641,
  "created_at" : "2014-09-23 15:55:25 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Harris",
      "screen_name" : "Harris_Bryan",
      "indices" : [ 0, 13 ],
      "id_str" : "16635335",
      "id" : 16635335
    }, {
      "name" : "Rajib Ahmed",
      "screen_name" : "kajolvomora",
      "indices" : [ 14, 26 ],
      "id_str" : "95624725",
      "id" : 95624725
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460549783099547648",
  "geo" : { },
  "id_str" : "514194178776268802",
  "in_reply_to_user_id" : 16635335,
  "text" : "@Harris_Bryan @kajolvomora the zombie pyramid rears its made-up face again!",
  "id" : 514194178776268802,
  "in_reply_to_status_id" : 460549783099547648,
  "created_at" : "2014-09-22 23:27:00 +0000",
  "in_reply_to_screen_name" : "Harris_Bryan",
  "in_reply_to_user_id_str" : "16635335",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doug Belshaw",
      "screen_name" : "dajbelshaw",
      "indices" : [ 3, 14 ],
      "id_str" : "764365",
      "id" : 764365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 125, 140 ],
      "url" : "http:\/\/t.co\/QXLvG2CJ9d",
      "expanded_url" : "http:\/\/sublevel.net",
      "display_url" : "sublevel.net"
    } ]
  },
  "geo" : { },
  "id_str" : "514167036948512769",
  "text" : "RT @dajbelshaw: Really quite smitten with Sublevel. Cross-platform, built on web standards and doesn't require Javascript. \n\nhttp:\/\/t.co\/QX\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/QXLvG2CJ9d",
        "expanded_url" : "http:\/\/sublevel.net",
        "display_url" : "sublevel.net"
      } ]
    },
    "geo" : { },
    "id_str" : "514147093813166081",
    "text" : "Really quite smitten with Sublevel. Cross-platform, built on web standards and doesn't require Javascript. \n\nhttp:\/\/t.co\/QXLvG2CJ9d",
    "id" : 514147093813166081,
    "created_at" : "2014-09-22 20:19:54 +0000",
    "user" : {
      "name" : "Doug Belshaw",
      "screen_name" : "dajbelshaw",
      "protected" : false,
      "id_str" : "764365",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/699881076026687488\/Ga5TBJ0g_normal.jpg",
      "id" : 764365,
      "verified" : false
    }
  },
  "id" : 514167036948512769,
  "created_at" : "2014-09-22 21:39:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vedrana Vojkovi\u0107",
      "screen_name" : "Ven_VVE",
      "indices" : [ 3, 11 ],
      "id_str" : "270839603",
      "id" : 270839603
    }, {
      "name" : "Sue Annan",
      "screen_name" : "SueAnnan",
      "indices" : [ 132, 140 ],
      "id_str" : "136001411",
      "id" : 136001411
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELTchat",
      "indices" : [ 13, 21 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/pUrUqtKGZD",
      "expanded_url" : "http:\/\/wp.me\/p4d1i5-22",
      "display_url" : "wp.me\/p4d1i5-22"
    } ]
  },
  "geo" : { },
  "id_str" : "514148093793533952",
  "text" : "RT @Ven_VVE: #ELTchat summary 10\/9\/14: What's the best idea\/app\/tool that you learnt since our last chat? http:\/\/t.co\/pUrUqtKGZD cc @SueAnn\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sue Annan",
        "screen_name" : "SueAnnan",
        "indices" : [ 119, 128 ],
        "id_str" : "136001411",
        "id" : 136001411
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELTchat",
        "indices" : [ 0, 8 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/pUrUqtKGZD",
        "expanded_url" : "http:\/\/wp.me\/p4d1i5-22",
        "display_url" : "wp.me\/p4d1i5-22"
      } ]
    },
    "geo" : { },
    "id_str" : "511886516038017024",
    "text" : "#ELTchat summary 10\/9\/14: What's the best idea\/app\/tool that you learnt since our last chat? http:\/\/t.co\/pUrUqtKGZD cc @SueAnnan",
    "id" : 511886516038017024,
    "created_at" : "2014-09-16 14:37:10 +0000",
    "user" : {
      "name" : "Vedrana Vojkovi\u0107",
      "screen_name" : "Ven_VVE",
      "protected" : false,
      "id_str" : "270839603",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/551061595602681856\/KylACR1R_normal.jpeg",
      "id" : 270839603,
      "verified" : false
    }
  },
  "id" : 514148093793533952,
  "created_at" : "2014-09-22 20:23:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpuslinguistics",
      "indices" : [ 0, 18 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 60, 68 ]
    }, {
      "text" : "efl",
      "indices" : [ 69, 73 ]
    }, {
      "text" : "tefl",
      "indices" : [ 74, 79 ]
    }, {
      "text" : "esl",
      "indices" : [ 80, 84 ]
    }, {
      "text" : "corpusMOOC",
      "indices" : [ 85, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/NvkiIJH9ro",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-OB",
      "display_url" : "wp.me\/pgHyE-OB"
    } ]
  },
  "geo" : { },
  "id_str" : "514147278840283138",
  "text" : "#corpuslinguistics community news 3 http:\/\/t.co\/NvkiIJH9ro  #eltchat #efl #tefl #esl #corpusMOOC",
  "id" : 514147278840283138,
  "created_at" : "2014-09-22 20:20:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "i_narrator",
      "screen_name" : "i_narrator",
      "indices" : [ 0, 11 ],
      "id_str" : "281361233",
      "id" : 281361233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/PYB1fJosCE",
      "expanded_url" : "https:\/\/plus.google.com\/104940199413423400545\/posts\/81SYnQNiPzE",
      "display_url" : "plus.google.com\/10494019941342\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "514075706507395072",
  "in_reply_to_user_id" : 281361233,
  "text" : "@i_narrator hi could you check this for errors\/omissions https:\/\/t.co\/PYB1fJosCE thanks!",
  "id" : 514075706507395072,
  "created_at" : "2014-09-22 15:36:14 +0000",
  "in_reply_to_screen_name" : "i_narrator",
  "in_reply_to_user_id_str" : "281361233",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Claire Dembry",
      "screen_name" : "ClaireDembry",
      "indices" : [ 0, 13 ],
      "id_str" : "2396240628",
      "id" : 2396240628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "514038960503672832",
  "geo" : { },
  "id_str" : "514048203759824897",
  "in_reply_to_user_id" : 2396240628,
  "text" : "@ClaireDembry OK great thanks",
  "id" : 514048203759824897,
  "in_reply_to_status_id" : 514038960503672832,
  "created_at" : "2014-09-22 13:46:56 +0000",
  "in_reply_to_screen_name" : "ClaireDembry",
  "in_reply_to_user_id_str" : "2396240628",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Claire Dembry",
      "screen_name" : "ClaireDembry",
      "indices" : [ 0, 13 ],
      "id_str" : "2396240628",
      "id" : 2396240628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "514032757727842304",
  "geo" : { },
  "id_str" : "514037828435857408",
  "in_reply_to_user_id" : 2396240628,
  "text" : "@ClaireDembry hi what formats will public release of bnc14 be in? Thanks!",
  "id" : 514037828435857408,
  "in_reply_to_status_id" : 514032757727842304,
  "created_at" : "2014-09-22 13:05:43 +0000",
  "in_reply_to_screen_name" : "ClaireDembry",
  "in_reply_to_user_id_str" : "2396240628",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Revolution News",
      "screen_name" : "NewsRevo",
      "indices" : [ 3, 12 ],
      "id_str" : "47862165",
      "id" : 47862165
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/NewsRevo\/status\/513878795125030912\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/JYJAWnqxDT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ByGqCcfCcAAbtSO.jpg",
      "id_str" : "513878791479783424",
      "id" : 513878791479783424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByGqCcfCcAAbtSO.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 193,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/JYJAWnqxDT"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/NewsRevo\/status\/513878795125030912\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/JYJAWnqxDT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ByGqCm6CQAA81wc.jpg",
      "id_str" : "513878794277371904",
      "id" : 513878794277371904,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByGqCm6CQAA81wc.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 675
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 675
      } ],
      "display_url" : "pic.twitter.com\/JYJAWnqxDT"
    } ],
    "hashtags" : [ {
      "text" : "Franse",
      "indices" : [ 101, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/9bOgh0U9Dn",
      "expanded_url" : "http:\/\/revolution-news.com\/french-farmers-set-fire-tax-insurance-offices-protest\/",
      "display_url" : "revolution-news.com\/french-farmers\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "513994880729632769",
  "text" : "RT @NewsRevo: French Farmers Set Fire to Tax and Insurance Offices in Protest http:\/\/t.co\/9bOgh0U9Dn #Franse http:\/\/t.co\/JYJAWnqxDT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/NewsRevo\/status\/513878795125030912\/photo\/1",
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/JYJAWnqxDT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ByGqCcfCcAAbtSO.jpg",
        "id_str" : "513878791479783424",
        "id" : 513878791479783424,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByGqCcfCcAAbtSO.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 193,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/JYJAWnqxDT"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/NewsRevo\/status\/513878795125030912\/photo\/1",
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/JYJAWnqxDT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ByGqCm6CQAA81wc.jpg",
        "id_str" : "513878794277371904",
        "id" : 513878794277371904,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByGqCm6CQAA81wc.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 675
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 675
        } ],
        "display_url" : "pic.twitter.com\/JYJAWnqxDT"
      } ],
      "hashtags" : [ {
        "text" : "Franse",
        "indices" : [ 87, 94 ]
      } ],
      "urls" : [ {
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/9bOgh0U9Dn",
        "expanded_url" : "http:\/\/revolution-news.com\/french-farmers-set-fire-tax-insurance-offices-protest\/",
        "display_url" : "revolution-news.com\/french-farmers\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "513878795125030912",
    "text" : "French Farmers Set Fire to Tax and Insurance Offices in Protest http:\/\/t.co\/9bOgh0U9Dn #Franse http:\/\/t.co\/JYJAWnqxDT",
    "id" : 513878795125030912,
    "created_at" : "2014-09-22 02:33:46 +0000",
    "user" : {
      "name" : "Revolution News",
      "screen_name" : "NewsRevo",
      "protected" : false,
      "id_str" : "47862165",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/573963111272570880\/lpNfTgyM_normal.jpeg",
      "id" : 47862165,
      "verified" : false
    }
  },
  "id" : 513994880729632769,
  "created_at" : "2014-09-22 10:15:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    }, {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 99, 109 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "the45",
      "indices" : [ 133, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/dZFN2EJtv2",
      "expanded_url" : "http:\/\/members5.boardhost.com\/medialens\/msg\/1411371977.html",
      "display_url" : "members5.boardhost.com\/medialens\/msg\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "513994601129332736",
  "text" : "RT @johnwhilley: Inspiring! Trident Nuclear Weapons Base Blockaded in Post Referendum Protest, via @medialens http:\/\/t.co\/dZFN2EJtv2 #the45\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Media Lens",
        "screen_name" : "medialens",
        "indices" : [ 82, 92 ],
        "id_str" : "6531902",
        "id" : 6531902
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "the45",
        "indices" : [ 116, 122 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/dZFN2EJtv2",
        "expanded_url" : "http:\/\/members5.boardhost.com\/medialens\/msg\/1411371977.html",
        "display_url" : "members5.boardhost.com\/medialens\/msg\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "513977327597125632",
    "text" : "Inspiring! Trident Nuclear Weapons Base Blockaded in Post Referendum Protest, via @medialens http:\/\/t.co\/dZFN2EJtv2 #the45 Please spread",
    "id" : 513977327597125632,
    "created_at" : "2014-09-22 09:05:18 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 513994601129332736,
  "created_at" : "2014-09-22 10:13:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Metro",
      "screen_name" : "MetroUK",
      "indices" : [ 68, 76 ],
      "id_str" : "138749160",
      "id" : 138749160
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/ysL9iBZkth",
      "expanded_url" : "http:\/\/metro.co.uk\/2014\/09\/21\/man-thrown-off-plane-for-terrorism-notepad-doodles-4876861\/",
      "display_url" : "metro.co.uk\/2014\/09\/21\/man\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "513987722562650112",
  "text" : "Man thrown off plane for notepad doodles http:\/\/t.co\/ysL9iBZkth via @MetroUK",
  "id" : 513987722562650112,
  "created_at" : "2014-09-22 09:46:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Levine",
      "screen_name" : "cogdog",
      "indices" : [ 63, 70 ],
      "id_str" : "740343",
      "id" : 740343
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ccourses",
      "indices" : [ 10, 19 ]
    } ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/9XdLmOHxwu",
      "expanded_url" : "http:\/\/connectedcourses.net\/random",
      "display_url" : "connectedcourses.net\/random"
    } ]
  },
  "geo" : { },
  "id_str" : "513984627103789057",
  "text" : "very neat #ccourses blog randomizer http:\/\/t.co\/9XdLmOHxwu via @cogdog",
  "id" : 513984627103789057,
  "created_at" : "2014-09-22 09:34:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C Rebuffet-Broadus",
      "screen_name" : "RebuffetBroadus",
      "indices" : [ 0, 16 ],
      "id_str" : "22635290",
      "id" : 22635290
    }, {
      "name" : "Seb Pearce",
      "screen_name" : "_sebu_",
      "indices" : [ 126, 133 ],
      "id_str" : "147260009",
      "id" : 147260009
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513924215905718272",
  "geo" : { },
  "id_str" : "513979782112235520",
  "in_reply_to_user_id" : 22635290,
  "text" : "@RebuffetBroadus nice post, this browserbased player could be handy for your studentshttp:\/\/sebpearce.com\/blog\/come-again\/ by @_sebu_",
  "id" : 513979782112235520,
  "in_reply_to_status_id" : 513924215905718272,
  "created_at" : "2014-09-22 09:15:04 +0000",
  "in_reply_to_screen_name" : "RebuffetBroadus",
  "in_reply_to_user_id_str" : "22635290",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Plashing Vole",
      "screen_name" : "PlashingVole",
      "indices" : [ 3, 16 ],
      "id_str" : "221104268",
      "id" : 221104268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513963279082070016",
  "text" : "RT @PlashingVole: You've got to admire Tony Blair's consistency. He consistently wants to invade repressive regimes that don't employ him.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "513945043498176512",
    "text" : "You've got to admire Tony Blair's consistency. He consistently wants to invade repressive regimes that don't employ him.",
    "id" : 513945043498176512,
    "created_at" : "2014-09-22 06:57:01 +0000",
    "user" : {
      "name" : "Plashing Vole",
      "screen_name" : "PlashingVole",
      "protected" : false,
      "id_str" : "221104268",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1233871741\/Reader_cropped.JPG_normal.jpg",
      "id" : 221104268,
      "verified" : false
    }
  },
  "id" : 513963279082070016,
  "created_at" : "2014-09-22 08:09:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bella Caledonia",
      "screen_name" : "bellacaledonia",
      "indices" : [ 56, 71 ],
      "id_str" : "103554348",
      "id" : 103554348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/rcpowYZNZC",
      "expanded_url" : "http:\/\/wp.me\/p93oK-4lN",
      "display_url" : "wp.me\/p93oK-4lN"
    } ]
  },
  "geo" : { },
  "id_str" : "513956070704689152",
  "text" : "New Media for a New Scotland http:\/\/t.co\/rcpowYZNZC via @bellacaledonia",
  "id" : 513956070704689152,
  "created_at" : "2014-09-22 07:40:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 3, 18 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/0H6lYJFBRp",
      "expanded_url" : "http:\/\/wp.me\/p3qkCB-Xz",
      "display_url" : "wp.me\/p3qkCB-Xz"
    } ]
  },
  "geo" : { },
  "id_str" : "513943475935784960",
  "text" : "RT @GeoffreyJordan: Hugh Dellar and The Lexical Approach Part\u00A02 http:\/\/t.co\/0H6lYJFBRp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/0H6lYJFBRp",
        "expanded_url" : "http:\/\/wp.me\/p3qkCB-Xz",
        "display_url" : "wp.me\/p3qkCB-Xz"
      } ]
    },
    "geo" : { },
    "id_str" : "513936516888817664",
    "text" : "Hugh Dellar and The Lexical Approach Part\u00A02 http:\/\/t.co\/0H6lYJFBRp",
    "id" : 513936516888817664,
    "created_at" : "2014-09-22 06:23:08 +0000",
    "user" : {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "protected" : false,
      "id_str" : "334332424",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/455317817537986561\/SD4wNKO3_normal.jpeg",
      "id" : 334332424,
      "verified" : false
    }
  },
  "id" : 513943475935784960,
  "created_at" : "2014-09-22 06:50:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 54, 63 ],
      "id_str" : "134211317",
      "id" : 134211317
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/wkAs60NkSe",
      "expanded_url" : "http:\/\/wp.me\/p3Wm0j-oe",
      "display_url" : "wp.me\/p3Wm0j-oe"
    } ]
  },
  "geo" : { },
  "id_str" : "513938923404263425",
  "text" : "Marker pens and kryptonite http:\/\/t.co\/wkAs60NkSe via @josipa74",
  "id" : 513938923404263425,
  "created_at" : "2014-09-22 06:32:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kathy Fagan",
      "screen_name" : "eslkathy",
      "indices" : [ 0, 9 ],
      "id_str" : "303849696",
      "id" : 303849696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "510441659474382848",
  "geo" : { },
  "id_str" : "513803933866000385",
  "in_reply_to_user_id" : 303849696,
  "text" : "@eslkathy maybe you could ask john higgins about progam availability in G+ comm though not sure how often he is on there now?",
  "id" : 513803933866000385,
  "in_reply_to_status_id" : 510441659474382848,
  "created_at" : "2014-09-21 21:36:18 +0000",
  "in_reply_to_screen_name" : "eslkathy",
  "in_reply_to_user_id_str" : "303849696",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "linkis",
      "indices" : [ 0, 7 ]
    }, {
      "text" : "scoopit",
      "indices" : [ 28, 36 ]
    }, {
      "text" : "onlinepeeve",
      "indices" : [ 55, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513799412959961088",
  "text" : "#linkis is becoming the new #scoopit :\/ hate them both #onlinepeeve",
  "id" : 513799412959961088,
  "created_at" : "2014-09-21 21:18:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robbie Love",
      "screen_name" : "lovermob",
      "indices" : [ 0, 9 ],
      "id_str" : "19469715",
      "id" : 19469715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513791462216302593",
  "in_reply_to_user_id" : 19469715,
  "text" : "@lovermob hi robbie did u get my mail about output formats for bnc14?",
  "id" : 513791462216302593,
  "created_at" : "2014-09-21 20:46:45 +0000",
  "in_reply_to_screen_name" : "lovermob",
  "in_reply_to_user_id_str" : "19469715",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "indices" : [ 3, 12 ],
      "id_str" : "167020390",
      "id" : 167020390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/SR6e6sZb10",
      "expanded_url" : "http:\/\/www.laurenceanthony.net\/software.html",
      "display_url" : "laurenceanthony.net\/software.html"
    } ]
  },
  "geo" : { },
  "id_str" : "513775386640269312",
  "text" : "RT @antlabjp: Just released AntConc 3.4.3, which fixes two small bugs. No new features, though. Get it here at my brand new domain: http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/SR6e6sZb10",
        "expanded_url" : "http:\/\/www.laurenceanthony.net\/software.html",
        "display_url" : "laurenceanthony.net\/software.html"
      } ]
    },
    "geo" : { },
    "id_str" : "513760664134107136",
    "text" : "Just released AntConc 3.4.3, which fixes two small bugs. No new features, though. Get it here at my brand new domain: http:\/\/t.co\/SR6e6sZb10",
    "id" : 513760664134107136,
    "created_at" : "2014-09-21 18:44:22 +0000",
    "user" : {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "protected" : false,
      "id_str" : "167020390",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/428183580821315584\/ocgCI7Er_normal.jpeg",
      "id" : 167020390,
      "verified" : false
    }
  },
  "id" : 513775386640269312,
  "created_at" : "2014-09-21 19:42:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anna Loseva",
      "screen_name" : "AnnLoseva",
      "indices" : [ 3, 13 ],
      "id_str" : "38822368",
      "id" : 38822368
    }, {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 121, 136 ],
      "id_str" : "285614027",
      "id" : 285614027
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 137, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/jImasUL2O0",
      "expanded_url" : "http:\/\/www.anthonyteacher.com\/blog\/listening-journals-promoting-extensive-and-intensive-listening-practice",
      "display_url" : "anthonyteacher.com\/blog\/listening\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "513721200531767297",
  "text" : "RT @AnnLoseva: Listening Journals: Promoting Extensive and Intensive Listening Practice http:\/\/t.co\/jImasUL2O0 \u0441 \u043F\u043E\u043C\u043E\u0449\u044C\u044E @AnthonyTeacher #e\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "AnthonyTeacher",
        "screen_name" : "AnthonyTeacher",
        "indices" : [ 106, 121 ],
        "id_str" : "285614027",
        "id" : 285614027
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "elt",
        "indices" : [ 122, 126 ]
      } ],
      "urls" : [ {
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/jImasUL2O0",
        "expanded_url" : "http:\/\/www.anthonyteacher.com\/blog\/listening-journals-promoting-extensive-and-intensive-listening-practice",
        "display_url" : "anthonyteacher.com\/blog\/listening\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "513702156713488385",
    "text" : "Listening Journals: Promoting Extensive and Intensive Listening Practice http:\/\/t.co\/jImasUL2O0 \u0441 \u043F\u043E\u043C\u043E\u0449\u044C\u044E @AnthonyTeacher #elt",
    "id" : 513702156713488385,
    "created_at" : "2014-09-21 14:51:52 +0000",
    "user" : {
      "name" : "Anna Loseva",
      "screen_name" : "AnnLoseva",
      "protected" : false,
      "id_str" : "38822368",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/767034457748541441\/VJrp4Jie_normal.jpg",
      "id" : 38822368,
      "verified" : false
    }
  },
  "id" : 513721200531767297,
  "created_at" : "2014-09-21 16:07:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513288571072311296",
  "geo" : { },
  "id_str" : "513289667626958848",
  "in_reply_to_user_id" : 60425505,
  "text" : "@becksdad have u looked at widgets area of your dashboard? u can add twitter publicize widget from there",
  "id" : 513289667626958848,
  "in_reply_to_status_id" : 513288571072311296,
  "created_at" : "2014-09-20 11:32:47 +0000",
  "in_reply_to_screen_name" : "neil_mcm",
  "in_reply_to_user_id_str" : "60425505",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513278781747126273",
  "geo" : { },
  "id_str" : "513284367809269760",
  "in_reply_to_user_id" : 60425505,
  "text" : "@becksdad  hehe neil activate the publicize feature in WP of twitter, g+ etc and it will put in your handle automatically",
  "id" : 513284367809269760,
  "in_reply_to_status_id" : 513278781747126273,
  "created_at" : "2014-09-20 11:11:44 +0000",
  "in_reply_to_screen_name" : "neil_mcm",
  "in_reply_to_user_id_str" : "60425505",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 56, 72 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 73, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/bmeoewGlcH",
      "expanded_url" : "http:\/\/wp.me\/p4XmN0-t",
      "display_url" : "wp.me\/p4XmN0-t"
    } ]
  },
  "geo" : { },
  "id_str" : "513242019083214849",
  "text" : "Humanism (and Other Animals) http:\/\/t.co\/bmeoewGlcH via @wordpressdotcom #corpusmooc",
  "id" : 513242019083214849,
  "created_at" : "2014-09-20 08:23:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HelloTalk App",
      "screen_name" : "HelloTalkApp",
      "indices" : [ 0, 13 ],
      "id_str" : "313078026",
      "id" : 313078026
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513181420974374912",
  "geo" : { },
  "id_str" : "513231471952551936",
  "in_reply_to_user_id" : 313078026,
  "text" : "@HelloTalkApp i use android",
  "id" : 513231471952551936,
  "in_reply_to_status_id" : 513181420974374912,
  "created_at" : "2014-09-20 07:41:32 +0000",
  "in_reply_to_screen_name" : "HelloTalkApp",
  "in_reply_to_user_id_str" : "313078026",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/513093274811506688\/photo\/1",
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/VDAyw9KsuU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bx7fnRvCYAAsviF.png",
      "id_str" : "513093273435398144",
      "id" : 513093273435398144,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bx7fnRvCYAAsviF.png",
      "sizes" : [ {
        "h" : 802,
        "resize" : "fit",
        "w" : 377
      }, {
        "h" : 802,
        "resize" : "fit",
        "w" : 377
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 802,
        "resize" : "fit",
        "w" : 377
      } ],
      "display_url" : "pic.twitter.com\/VDAyw9KsuU"
    } ],
    "hashtags" : [ {
      "text" : "ccourses",
      "indices" : [ 0, 9 ]
    } ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/naSMhVFJPi",
      "expanded_url" : "http:\/\/www.eat.rl.ac.uk\/",
      "display_url" : "eat.rl.ac.uk"
    } ]
  },
  "geo" : { },
  "id_str" : "513093274811506688",
  "text" : "#ccourses Connect associations from http:\/\/t.co\/naSMhVFJPi http:\/\/t.co\/VDAyw9KsuU",
  "id" : 513093274811506688,
  "created_at" : "2014-09-19 22:32:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Smith",
      "screen_name" : "RichardSmithELT",
      "indices" : [ 0, 16 ],
      "id_str" : "2381084346",
      "id" : 2381084346
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513088451181559809",
  "geo" : { },
  "id_str" : "513090229872627712",
  "in_reply_to_user_id" : 2381084346,
  "text" : "@RichardSmithELT great thanks working link",
  "id" : 513090229872627712,
  "in_reply_to_status_id" : 513088451181559809,
  "created_at" : "2014-09-19 22:20:18 +0000",
  "in_reply_to_screen_name" : "RichardSmithELT",
  "in_reply_to_user_id_str" : "2381084346",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/513089891949752321\/photo\/1",
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/wJKCHib1kj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bx7ciW-CQAEQ7-4.png",
      "id_str" : "513089890406252545",
      "id" : 513089890406252545,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bx7ciW-CQAEQ7-4.png",
      "sizes" : [ {
        "h" : 786,
        "resize" : "fit",
        "w" : 388
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 786,
        "resize" : "fit",
        "w" : 388
      }, {
        "h" : 786,
        "resize" : "fit",
        "w" : 388
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 336
      } ],
      "display_url" : "pic.twitter.com\/wJKCHib1kj"
    } ],
    "hashtags" : [ {
      "text" : "indeyref",
      "indices" : [ 0, 9 ]
    } ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/4ULvQcJblm",
      "expanded_url" : "http:\/\/www.eat.rl.ac.uk\/",
      "display_url" : "eat.rl.ac.uk"
    } ]
  },
  "geo" : { },
  "id_str" : "513089891949752321",
  "text" : "#indeyref Vow associations from http:\/\/t.co\/4ULvQcJblm http:\/\/t.co\/wJKCHib1kj",
  "id" : 513089891949752321,
  "created_at" : "2014-09-19 22:18:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Smith",
      "screen_name" : "RichardSmithELT",
      "indices" : [ 0, 16 ],
      "id_str" : "2381084346",
      "id" : 2381084346
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/nXTsNFDsju",
      "expanded_url" : "http:\/\/www.teachingenglish.org.uk\/sites\/teacheng\/files\/E168%20Innovations%20in%20CPD_FINAL%20web.pdf",
      "display_url" : "teachingenglish.org.uk\/sites\/teacheng\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "513065534452404224",
  "in_reply_to_user_id" : 2381084346,
  "text" : "@RichardSmithELT hi link to chpt 5 pdf brken http:\/\/t.co\/nXTsNFDsju thanks",
  "id" : 513065534452404224,
  "created_at" : "2014-09-19 20:42:10 +0000",
  "in_reply_to_screen_name" : "RichardSmithELT",
  "in_reply_to_user_id_str" : "2381084346",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Smith",
      "screen_name" : "RichardSmithELT",
      "indices" : [ 3, 19 ],
      "id_str" : "2381084346",
      "id" : 2381084346
    }, {
      "name" : "Alicia Victorio",
      "screen_name" : "AliciaVictorio",
      "indices" : [ 107, 122 ],
      "id_str" : "779787240",
      "id" : 779787240
    }, {
      "name" : "Laura Renart",
      "screen_name" : "laurarenart",
      "indices" : [ 123, 135 ],
      "id_str" : "132178306",
      "id" : 132178306
    }, {
      "name" : "Graham Stanley",
      "screen_name" : "grahamstanley",
      "indices" : [ 136, 140 ],
      "id_str" : "74143",
      "id" : 74143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/vp7InRIGOY",
      "expanded_url" : "http:\/\/ow.ly\/BEcuU",
      "display_url" : "ow.ly\/BEcuU"
    } ]
  },
  "geo" : { },
  "id_str" : "513061115065303040",
  "text" : "RT @RichardSmithELT: Video message on post-method condition for FAAPI conference  - http:\/\/t.co\/vp7InRIGOY @AliciaVictorio @laurarenart @gr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Alicia Victorio",
        "screen_name" : "AliciaVictorio",
        "indices" : [ 86, 101 ],
        "id_str" : "779787240",
        "id" : 779787240
      }, {
        "name" : "Laura Renart",
        "screen_name" : "laurarenart",
        "indices" : [ 102, 114 ],
        "id_str" : "132178306",
        "id" : 132178306
      }, {
        "name" : "Graham Stanley",
        "screen_name" : "grahamstanley",
        "indices" : [ 115, 129 ],
        "id_str" : "74143",
        "id" : 74143
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/vp7InRIGOY",
        "expanded_url" : "http:\/\/ow.ly\/BEcuU",
        "display_url" : "ow.ly\/BEcuU"
      } ]
    },
    "geo" : { },
    "id_str" : "513046954990112769",
    "text" : "Video message on post-method condition for FAAPI conference  - http:\/\/t.co\/vp7InRIGOY @AliciaVictorio @laurarenart @grahamstanley",
    "id" : 513046954990112769,
    "created_at" : "2014-09-19 19:28:20 +0000",
    "user" : {
      "name" : "Richard Smith",
      "screen_name" : "RichardSmithELT",
      "protected" : false,
      "id_str" : "2381084346",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/442784228007112704\/0oKivCvx_normal.jpeg",
      "id" : 2381084346,
      "verified" : false
    }
  },
  "id" : 513061115065303040,
  "created_at" : "2014-09-19 20:24:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 0, 11 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "512878074837602304",
  "geo" : { },
  "id_str" : "512982693521657856",
  "in_reply_to_user_id" : 87902543,
  "text" : "@tornhalves pleasure a great post, enjoy w\/e :)",
  "id" : 512982693521657856,
  "in_reply_to_status_id" : 512878074837602304,
  "created_at" : "2014-09-19 15:12:59 +0000",
  "in_reply_to_screen_name" : "tornhalves",
  "in_reply_to_user_id_str" : "87902543",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HelloTalk App",
      "screen_name" : "HelloTalkApp",
      "indices" : [ 0, 13 ],
      "id_str" : "313078026",
      "id" : 313078026
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "512850127669571584",
  "geo" : { },
  "id_str" : "512874467404812288",
  "in_reply_to_user_id" : 313078026,
  "text" : "@HelloTalkApp e.g. your tems and conditions statement?",
  "id" : 512874467404812288,
  "in_reply_to_status_id" : 512850127669571584,
  "created_at" : "2014-09-19 08:02:56 +0000",
  "in_reply_to_screen_name" : "HelloTalkApp",
  "in_reply_to_user_id_str" : "313078026",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HelloTalk App",
      "screen_name" : "HelloTalkApp",
      "indices" : [ 0, 13 ],
      "id_str" : "313078026",
      "id" : 313078026
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512698691275091969",
  "in_reply_to_user_id" : 313078026,
  "text" : "@HelloTalkApp hi where is your info on what you do with user data? thx",
  "id" : 512698691275091969,
  "created_at" : "2014-09-18 20:24:28 +0000",
  "in_reply_to_screen_name" : "HelloTalkApp",
  "in_reply_to_user_id_str" : "313078026",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Official Vidopop App",
      "screen_name" : "Vidopopapp",
      "indices" : [ 0, 11 ],
      "id_str" : "1417167817",
      "id" : 1417167817
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "512555474147749888",
  "geo" : { },
  "id_str" : "512670380540964865",
  "in_reply_to_user_id" : 1417167817,
  "text" : "@Vidopopapp no idea maybe if you link study frm Dallas Independent School District you mentioned could investigate further?",
  "id" : 512670380540964865,
  "in_reply_to_status_id" : 512555474147749888,
  "created_at" : "2014-09-18 18:31:58 +0000",
  "in_reply_to_screen_name" : "Vidopopapp",
  "in_reply_to_user_id_str" : "1417167817",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 1, 12 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edtech",
      "indices" : [ 79, 86 ]
    }, {
      "text" : "ccourses",
      "indices" : [ 111, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/4HokVCR1mi",
      "expanded_url" : "http:\/\/bit.ly\/1uTobOo",
      "display_url" : "bit.ly\/1uTobOo"
    } ]
  },
  "geo" : { },
  "id_str" : "512583219045482496",
  "text" : "\"@tornhalves: How Mary Shelley's \"Frankenstein\" illuminates the monstrosity of #edtech http:\/\/t.co\/4HokVCR1mi\" #ccourses",
  "id" : 512583219045482496,
  "created_at" : "2014-09-18 12:45:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 3, 14 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edtech",
      "indices" : [ 81, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/0eLWOuraXd",
      "expanded_url" : "http:\/\/bit.ly\/1uTobOo",
      "display_url" : "bit.ly\/1uTobOo"
    } ]
  },
  "geo" : { },
  "id_str" : "512551957106794496",
  "text" : "RT @tornhalves: How Mary Shelley's \"Frankenstein\" illuminates the monstrosity of #edtech http:\/\/t.co\/0eLWOuraXd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "edtech",
        "indices" : [ 65, 72 ]
      } ],
      "urls" : [ {
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/0eLWOuraXd",
        "expanded_url" : "http:\/\/bit.ly\/1uTobOo",
        "display_url" : "bit.ly\/1uTobOo"
      } ]
    },
    "geo" : { },
    "id_str" : "512224387458940928",
    "text" : "How Mary Shelley's \"Frankenstein\" illuminates the monstrosity of #edtech http:\/\/t.co\/0eLWOuraXd",
    "id" : 512224387458940928,
    "created_at" : "2014-09-17 12:59:45 +0000",
    "user" : {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "protected" : false,
      "id_str" : "87902543",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3059742703\/1d3c7a2052db17d29644fa0a49af6480_normal.jpeg",
      "id" : 87902543,
      "verified" : false
    }
  },
  "id" : 512551957106794496,
  "created_at" : "2014-09-18 10:41:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Parise",
      "screen_name" : "peterrenshu",
      "indices" : [ 3, 15 ],
      "id_str" : "631949549",
      "id" : 631949549
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/ucvk9UAaVF",
      "expanded_url" : "http:\/\/jalt-publications.org\/tlt\/departments\/tlt-wired\/articles\/468-take-corpus-linguistics-your-own-hands-compleat-lexical-tutor",
      "display_url" : "jalt-publications.org\/tlt\/department\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "512549145161506816",
  "text" : "RT @peterrenshu: A blast from the past...\nTake corpus linguistics into your own hands with the Compleat Lexical Tutor http:\/\/t.co\/ucvk9UAaVF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/ucvk9UAaVF",
        "expanded_url" : "http:\/\/jalt-publications.org\/tlt\/departments\/tlt-wired\/articles\/468-take-corpus-linguistics-your-own-hands-compleat-lexical-tutor",
        "display_url" : "jalt-publications.org\/tlt\/department\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "512515189569110016",
    "text" : "A blast from the past...\nTake corpus linguistics into your own hands with the Compleat Lexical Tutor http:\/\/t.co\/ucvk9UAaVF",
    "id" : 512515189569110016,
    "created_at" : "2014-09-18 08:15:17 +0000",
    "user" : {
      "name" : "Peter Parise",
      "screen_name" : "peterrenshu",
      "protected" : false,
      "id_str" : "631949549",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2390141891\/azxwx57ppddic0hnd26k_normal.jpeg",
      "id" : 631949549,
      "verified" : false
    }
  },
  "id" : 512549145161506816,
  "created_at" : "2014-09-18 10:30:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "512408337850187776",
  "geo" : { },
  "id_str" : "512471580157685760",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler ahoy anne glade ye found thar be treaure thar ...i'll get me coat :)",
  "id" : 512471580157685760,
  "in_reply_to_status_id" : 512408337850187776,
  "created_at" : "2014-09-18 05:22:00 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Every Noise at Once",
      "screen_name" : "EveryNoise",
      "indices" : [ 3, 14 ],
      "id_str" : "1415445896",
      "id" : 1415445896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/aD4AfVSVaf",
      "expanded_url" : "http:\/\/www.furia.com\/page.cgi?type=log&id=417",
      "display_url" : "furia.com\/page.cgi?type=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "512313207713976320",
  "text" : "RT @EveryNoise: The Sound of Places: an acoustic remapping of geography, and the most distinctively popular music of countries. http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/aD4AfVSVaf",
        "expanded_url" : "http:\/\/www.furia.com\/page.cgi?type=log&id=417",
        "display_url" : "furia.com\/page.cgi?type=\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "512220001252544512",
    "text" : "The Sound of Places: an acoustic remapping of geography, and the most distinctively popular music of countries. http:\/\/t.co\/aD4AfVSVaf",
    "id" : 512220001252544512,
    "created_at" : "2014-09-17 12:42:19 +0000",
    "user" : {
      "name" : "Every Noise at Once",
      "screen_name" : "EveryNoise",
      "protected" : false,
      "id_str" : "1415445896",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3736544396\/e0d7d0c8f2781c40b5f870df441e670c_normal.png",
      "id" : 1415445896,
      "verified" : false
    }
  },
  "id" : 512313207713976320,
  "created_at" : "2014-09-17 18:52:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "indices" : [ 3, 18 ],
      "id_str" : "27716419",
      "id" : 27716419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/BK47iISquk",
      "expanded_url" : "http:\/\/bit.ly\/1uGF28Q",
      "display_url" : "bit.ly\/1uGF28Q"
    } ]
  },
  "geo" : { },
  "id_str" : "512278226321047553",
  "text" : "RT @CraigMurrayOrg: Police Rebut Unionist Smears: George Robertson has been designated by the Labour Party to lead a campaign to h... http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/BK47iISquk",
        "expanded_url" : "http:\/\/bit.ly\/1uGF28Q",
        "display_url" : "bit.ly\/1uGF28Q"
      } ]
    },
    "geo" : { },
    "id_str" : "512230782945857537",
    "text" : "Police Rebut Unionist Smears: George Robertson has been designated by the Labour Party to lead a campaign to h... http:\/\/t.co\/BK47iISquk",
    "id" : 512230782945857537,
    "created_at" : "2014-09-17 13:25:10 +0000",
    "user" : {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "protected" : false,
      "id_str" : "27716419",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1388436826\/cm_normal.jpg",
      "id" : 27716419,
      "verified" : false
    }
  },
  "id" : 512278226321047553,
  "created_at" : "2014-09-17 16:33:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "511959551164555265",
  "geo" : { },
  "id_str" : "511959744924237824",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco it is very neat :)",
  "id" : 511959744924237824,
  "in_reply_to_status_id" : 511959551164555265,
  "created_at" : "2014-09-16 19:28:09 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/QNNz52VoW8",
      "expanded_url" : "http:\/\/movies.benschmidt.org\/#?%7B%22search_limits%22%3A%5B%7B%22word%22%3A%5B%22two+times%22%5D%2C%22MovieYear%22%3A%7B%22%24gte%22%3A1931%2C%22%24lte%22%3A2015%7D%2C%22primary_original_language__id%22%3A%5B%221%22%5D%7D%2C%7B%22word%22%3A%5B%22twice%22%5D%2C%22MovieYear%22%3A%7B%22%24gte%22%3A1931%2C%22%24lte%22%3A2015%7D%2C%22primary_original_language__id%22%3A%5B%221%22%5D%7D%5D%7D",
      "display_url" : "movies.benschmidt.org\/#?%7B%22search\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "511823996736643072",
  "geo" : { },
  "id_str" : "511950364690907136",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco movies and tv shows reflect this http:\/\/t.co\/QNNz52VoW8",
  "id" : 511950364690907136,
  "in_reply_to_status_id" : 511823996736643072,
  "created_at" : "2014-09-16 18:50:53 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Schmidt",
      "screen_name" : "benmschmidt",
      "indices" : [ 3, 15 ],
      "id_str" : "222618390",
      "id" : 222618390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/uay9eXbgbt",
      "expanded_url" : "http:\/\/movies.benschmidt.org\/",
      "display_url" : "movies.benschmidt.org"
    } ]
  },
  "geo" : { },
  "id_str" : "511945540213686272",
  "text" : "RT @benmschmidt: New bookworm to see change in the full dialogue of 80,000 movies\/TV shows by year, director, country, and more: http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/uay9eXbgbt",
        "expanded_url" : "http:\/\/movies.benschmidt.org\/",
        "display_url" : "movies.benschmidt.org"
      } ]
    },
    "geo" : { },
    "id_str" : "511918871205650433",
    "text" : "New bookworm to see change in the full dialogue of 80,000 movies\/TV shows by year, director, country, and more: http:\/\/t.co\/uay9eXbgbt",
    "id" : 511918871205650433,
    "created_at" : "2014-09-16 16:45:44 +0000",
    "user" : {
      "name" : "Benjamin Schmidt",
      "screen_name" : "benmschmidt",
      "protected" : false,
      "id_str" : "222618390",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1181931710\/Screen_shot_2010-12-03_at_7.00.07_PM_normal.png",
      "id" : 222618390,
      "verified" : false
    }
  },
  "id" : 511945540213686272,
  "created_at" : "2014-09-16 18:31:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 111, 127 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/YTGuSVc5WK",
      "expanded_url" : "http:\/\/wp.me\/p1GR5K-3S",
      "display_url" : "wp.me\/p1GR5K-3S"
    } ]
  },
  "geo" : { },
  "id_str" : "511838188323602432",
  "text" : "The 5 things you do in English that you might not know have actual, technical names http:\/\/t.co\/YTGuSVc5WK via @wordpressdotcom",
  "id" : 511838188323602432,
  "created_at" : "2014-09-16 11:25:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 3, 18 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/F30I5QjIaQ",
      "expanded_url" : "http:\/\/wp.me\/p3qkCB-X1",
      "display_url" : "wp.me\/p3qkCB-X1"
    } ]
  },
  "geo" : { },
  "id_str" : "511835983890096128",
  "text" : "RT @GeoffreyJordan: Hugh Dellar and The Lexical\u00A0Approach http:\/\/t.co\/F30I5QjIaQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 59 ],
        "url" : "http:\/\/t.co\/F30I5QjIaQ",
        "expanded_url" : "http:\/\/wp.me\/p3qkCB-X1",
        "display_url" : "wp.me\/p3qkCB-X1"
      } ]
    },
    "geo" : { },
    "id_str" : "511829037413453824",
    "text" : "Hugh Dellar and The Lexical\u00A0Approach http:\/\/t.co\/F30I5QjIaQ",
    "id" : 511829037413453824,
    "created_at" : "2014-09-16 10:48:46 +0000",
    "user" : {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "protected" : false,
      "id_str" : "334332424",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/455317817537986561\/SD4wNKO3_normal.jpeg",
      "id" : 334332424,
      "verified" : false
    }
  },
  "id" : 511835983890096128,
  "created_at" : "2014-09-16 11:16:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "indyref",
      "indices" : [ 43, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 123, 140 ],
      "url" : "http:\/\/t.co\/R3Hnhgux0J",
      "expanded_url" : "http:\/\/www.medialens.org\/index.php\/alerts\/alert-archive\/2014\/774-dark-omens-and-horror-shows-scottish-independence-power-and-propaganda.html",
      "display_url" : "medialens.org\/index.php\/aler\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "511773207754731520",
  "text" : "RT @medialens: Corporate media coverage of #indyref is full of establishment sophistry and cynical manipulation of voters. http:\/\/t.co\/R3Hn\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "indyref",
        "indices" : [ 28, 36 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/R3Hnhgux0J",
        "expanded_url" : "http:\/\/www.medialens.org\/index.php\/alerts\/alert-archive\/2014\/774-dark-omens-and-horror-shows-scottish-independence-power-and-propaganda.html",
        "display_url" : "medialens.org\/index.php\/aler\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "511479306816864256",
    "text" : "Corporate media coverage of #indyref is full of establishment sophistry and cynical manipulation of voters. http:\/\/t.co\/R3Hnhgux0J",
    "id" : 511479306816864256,
    "created_at" : "2014-09-15 11:39:04 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 511773207754731520,
  "created_at" : "2014-09-16 07:06:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 0, 10 ],
      "id_str" : "525274103",
      "id" : 525274103
    }, {
      "name" : "Mark Pegrum",
      "screen_name" : "OzMark17",
      "indices" : [ 11, 20 ],
      "id_str" : "15095453",
      "id" : 15095453
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/TbbIZeNXsa",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=w7RIgs3eygo",
      "display_url" : "youtube.com\/watch?v=w7RIgs\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "511769410122428416",
  "geo" : { },
  "id_str" : "511772419468824576",
  "in_reply_to_user_id" : 525274103,
  "text" : "@ElkySmith @OzMark17 Doomed, Entombed &amp; Marooned? :) https:\/\/t.co\/TbbIZeNXsa",
  "id" : 511772419468824576,
  "in_reply_to_status_id" : 511769410122428416,
  "created_at" : "2014-09-16 07:03:47 +0000",
  "in_reply_to_screen_name" : "ElkySmith",
  "in_reply_to_user_id_str" : "525274103",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 0, 10 ],
      "id_str" : "525274103",
      "id" : 525274103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "511705550078222336",
  "geo" : { },
  "id_str" : "511768759225569280",
  "in_reply_to_user_id" : 525274103,
  "text" : "@ElkySmith hehe, what's your talk on?",
  "id" : 511768759225569280,
  "in_reply_to_status_id" : 511705550078222336,
  "created_at" : "2014-09-16 06:49:15 +0000",
  "in_reply_to_screen_name" : "ElkySmith",
  "in_reply_to_user_id_str" : "525274103",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 22, 26 ]
    }, {
      "text" : "elttalkbingo",
      "indices" : [ 54, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/Ojx8p19p3E",
      "expanded_url" : "http:\/\/elttalkbingo.englishup.me\/newcard.html",
      "display_url" : "elttalkbingo.englishup.me\/newcard.html"
    } ]
  },
  "geo" : { },
  "id_str" : "511671498726469632",
  "text" : "if u are attending an #elt conference soon u cld play #elttalkbingo http:\/\/t.co\/Ojx8p19p3E",
  "id" : 511671498726469632,
  "created_at" : "2014-09-16 00:22:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen DePauw",
      "screen_name" : "kpdepauw",
      "indices" : [ 0, 9 ],
      "id_str" : "542672291",
      "id" : 542672291
    }, {
      "name" : "VT Grad School",
      "screen_name" : "VTGradCommunity",
      "indices" : [ 10, 26 ],
      "id_str" : "50643448",
      "id" : 50643448
    }, {
      "name" : "Howard Rheingold",
      "screen_name" : "hrheingold",
      "indices" : [ 27, 38 ],
      "id_str" : "5388852",
      "id" : 5388852
    }, {
      "name" : "Mike Wesch",
      "screen_name" : "mwesch",
      "indices" : [ 39, 46 ],
      "id_str" : "4906851",
      "id" : 4906851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "511626035193184256",
  "geo" : { },
  "id_str" : "511634537575874560",
  "in_reply_to_user_id" : 542672291,
  "text" : "@kpdepauw @VTGradCommunity @hrheingold @mwesch not much different if we see purpose\/content division as artificial?",
  "id" : 511634537575874560,
  "in_reply_to_status_id" : 511626035193184256,
  "created_at" : "2014-09-15 21:55:54 +0000",
  "in_reply_to_screen_name" : "kpdepauw",
  "in_reply_to_user_id_str" : "542672291",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    }, {
      "name" : "Julie Moore",
      "screen_name" : "lexicojules",
      "indices" : [ 12, 24 ],
      "id_str" : "424320799",
      "id" : 424320799
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "511630241786515456",
  "geo" : { },
  "id_str" : "511632466319527936",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco @lexicojules hehe :)",
  "id" : 511632466319527936,
  "in_reply_to_status_id" : 511630241786515456,
  "created_at" : "2014-09-15 21:47:40 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrea Rehn",
      "screen_name" : "Profrehn",
      "indices" : [ 0, 9 ],
      "id_str" : "1199595018",
      "id" : 1199595018
    }, {
      "name" : "Cathy Davidson",
      "screen_name" : "CathyNDavidson",
      "indices" : [ 10, 25 ],
      "id_str" : "15480206",
      "id" : 15480206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "511620643758936064",
  "geo" : { },
  "id_str" : "511630722172739586",
  "in_reply_to_user_id" : 1199595018,
  "text" : "@Profrehn @CathyNDavidson Plato's &amp; his dialogues originated in era of iron forges...",
  "id" : 511630722172739586,
  "in_reply_to_status_id" : 511620643758936064,
  "created_at" : "2014-09-15 21:40:44 +0000",
  "in_reply_to_screen_name" : "Profrehn",
  "in_reply_to_user_id_str" : "1199595018",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2133\u0105h\u0105 B\u0105\u2113i \u0645\u0647\u0627 \u0628\u0627\u0644\u064A",
      "screen_name" : "Bali_Maha",
      "indices" : [ 0, 10 ],
      "id_str" : "1535273520",
      "id" : 1535273520
    }, {
      "name" : "Cathy Davidson",
      "screen_name" : "CathyNDavidson",
      "indices" : [ 11, 26 ],
      "id_str" : "15480206",
      "id" : 15480206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/F1PHQmJaS7",
      "expanded_url" : "http:\/\/elttalkbingo.englishup.me\/newcard.html",
      "display_url" : "elttalkbingo.englishup.me\/newcard.html"
    } ]
  },
  "in_reply_to_status_id_str" : "511613227344871424",
  "geo" : { },
  "id_str" : "511621281058279425",
  "in_reply_to_user_id" : 1535273520,
  "text" : "@Bali_Maha @CathyNDavidson oh might add that as a variant to edu\/elt talk bingo http:\/\/t.co\/F1PHQmJaS7 :\/",
  "id" : 511621281058279425,
  "in_reply_to_status_id" : 511613227344871424,
  "created_at" : "2014-09-15 21:03:13 +0000",
  "in_reply_to_screen_name" : "Bali_Maha",
  "in_reply_to_user_id_str" : "1535273520",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jack Askew",
      "screen_name" : "eslonlinejack",
      "indices" : [ 3, 17 ],
      "id_str" : "1513170398",
      "id" : 1513170398
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 110, 114 ]
    }, {
      "text" : "tefl",
      "indices" : [ 115, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/tD5uGoG0IO",
      "expanded_url" : "http:\/\/bit.ly\/1m8crI8",
      "display_url" : "bit.ly\/1m8crI8"
    } ]
  },
  "geo" : { },
  "id_str" : "511511155932946432",
  "text" : "RT @eslonlinejack: 19 Teachers. 19 Tips for planning. 19 Resources. Don't miss this! - http:\/\/t.co\/tD5uGoG0IO #elt #tefl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "elt",
        "indices" : [ 91, 95 ]
      }, {
        "text" : "tefl",
        "indices" : [ 96, 101 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/tD5uGoG0IO",
        "expanded_url" : "http:\/\/bit.ly\/1m8crI8",
        "display_url" : "bit.ly\/1m8crI8"
      } ]
    },
    "geo" : { },
    "id_str" : "511506757550882816",
    "text" : "19 Teachers. 19 Tips for planning. 19 Resources. Don't miss this! - http:\/\/t.co\/tD5uGoG0IO #elt #tefl",
    "id" : 511506757550882816,
    "created_at" : "2014-09-15 13:28:08 +0000",
    "user" : {
      "name" : "Jack Askew",
      "screen_name" : "eslonlinejack",
      "protected" : false,
      "id_str" : "1513170398",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/484685723677638657\/aIA1Yymj_normal.png",
      "id" : 1513170398,
      "verified" : false
    }
  },
  "id" : 511511155932946432,
  "created_at" : "2014-09-15 13:45:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ALi Karaka\u015F",
      "screen_name" : "alikarakas85",
      "indices" : [ 80, 93 ],
      "id_str" : "107041072",
      "id" : 107041072
    }, {
      "name" : "Divya Madhavan",
      "screen_name" : "_divyamadhavan",
      "indices" : [ 97, 112 ],
      "id_str" : "408492806",
      "id" : 408492806
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/EJPPJqMcbw",
      "expanded_url" : "http:\/\/wp.me\/p1kDRa-7C",
      "display_url" : "wp.me\/p1kDRa-7C"
    } ]
  },
  "geo" : { },
  "id_str" : "511499932260642817",
  "text" : "Terminological ambiguity: sloppy use of the term EMI http:\/\/t.co\/EJPPJqMcbw via @alikarakas85 cc @_divyamadhavan",
  "id" : 511499932260642817,
  "created_at" : "2014-09-15 13:01:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aral Balkan",
      "screen_name" : "aral",
      "indices" : [ 3, 8 ],
      "id_str" : "48903",
      "id" : 48903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511272738728968192",
  "text" : "RT @aral: What could be better than having Google Certified Teachers pushing spyware in schools?\n\nLet\u2019s get some McDonald\u2019s Certified Teach\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "511208680344518657",
    "geo" : { },
    "id_str" : "511209372127862784",
    "in_reply_to_user_id" : 48903,
    "text" : "What could be better than having Google Certified Teachers pushing spyware in schools?\n\nLet\u2019s get some McDonald\u2019s Certified Teachers too.",
    "id" : 511209372127862784,
    "in_reply_to_status_id" : 511208680344518657,
    "created_at" : "2014-09-14 17:46:26 +0000",
    "in_reply_to_screen_name" : "aral",
    "in_reply_to_user_id_str" : "48903",
    "user" : {
      "name" : "Aral Balkan",
      "screen_name" : "aral",
      "protected" : false,
      "id_str" : "48903",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749684601707229184\/ND7M3yJx_normal.jpg",
      "id" : 48903,
      "verified" : false
    }
  },
  "id" : 511272738728968192,
  "created_at" : "2014-09-14 21:58:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angus B Grieve-Smith",
      "screen_name" : "grvsmth",
      "indices" : [ 3, 11 ],
      "id_str" : "22381639",
      "id" : 22381639
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/27JliFwxlP",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=WEWG6kSYqlY",
      "display_url" : "youtube.com\/watch?v=WEWG6k\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "511183612054876160",
  "text" : "RT @grvsmth: Lock the Taskbar https:\/\/t.co\/27JliFwxlP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 17, 40 ],
        "url" : "https:\/\/t.co\/27JliFwxlP",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=WEWG6kSYqlY",
        "display_url" : "youtube.com\/watch?v=WEWG6k\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "510864043104813057",
    "text" : "Lock the Taskbar https:\/\/t.co\/27JliFwxlP",
    "id" : 510864043104813057,
    "created_at" : "2014-09-13 18:54:13 +0000",
    "user" : {
      "name" : "Angus B Grieve-Smith",
      "screen_name" : "grvsmth",
      "protected" : false,
      "id_str" : "22381639",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/94827231\/portrait_normal.png",
      "id" : 22381639,
      "verified" : false
    }
  },
  "id" : 511183612054876160,
  "created_at" : "2014-09-14 16:04:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "williamjturkel",
      "screen_name" : "williamjturkel",
      "indices" : [ 3, 18 ],
      "id_str" : "9280142",
      "id" : 9280142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/ii8TAyCjsH",
      "expanded_url" : "http:\/\/americanyawp.com\/",
      "display_url" : "americanyawp.com"
    } ]
  },
  "geo" : { },
  "id_str" : "510902072771104768",
  "text" : "RT @williamjturkel: The American Yawp, a free, collaboratively-built American History textbook (beta) http:\/\/t.co\/ii8TAyCjsH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/ii8TAyCjsH",
        "expanded_url" : "http:\/\/americanyawp.com\/",
        "display_url" : "americanyawp.com"
      } ]
    },
    "geo" : { },
    "id_str" : "510878225266774016",
    "text" : "The American Yawp, a free, collaboratively-built American History textbook (beta) http:\/\/t.co\/ii8TAyCjsH",
    "id" : 510878225266774016,
    "created_at" : "2014-09-13 19:50:35 +0000",
    "user" : {
      "name" : "williamjturkel",
      "screen_name" : "williamjturkel",
      "protected" : false,
      "id_str" : "9280142",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/32501472\/spoka-twitter_normal.jpg",
      "id" : 9280142,
      "verified" : false
    }
  },
  "id" : 510902072771104768,
  "created_at" : "2014-09-13 21:25:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 0, 11 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/1ugtkyUfIl",
      "expanded_url" : "http:\/\/www.lexchecker.org\/hyngram\/hyngram_q.php?query=good%2Fadj&from_n=2&to_n=6&min_f=20000&page_size=40#",
      "display_url" : "lexchecker.org\/hyngram\/hyngra\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "510815478042722305",
  "geo" : { },
  "id_str" : "510841658523795456",
  "in_reply_to_user_id" : 88202140,
  "text" : "@hughdellar yes &amp; depends on how u divvyup? if using say min of 20000 examples stringnet says 5 \"constructions\" http:\/\/t.co\/1ugtkyUfIl",
  "id" : 510841658523795456,
  "in_reply_to_status_id" : 510815478042722305,
  "created_at" : "2014-09-13 17:25:17 +0000",
  "in_reply_to_screen_name" : "hughdellar",
  "in_reply_to_user_id_str" : "88202140",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    }, {
      "name" : "Jim Sillars",
      "screen_name" : "NaeFear",
      "indices" : [ 70, 78 ],
      "id_str" : "2260666053",
      "id" : 2260666053
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "indy",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/5dgPFzvvXo",
      "expanded_url" : "http:\/\/www.scotsman.com\/news\/politics\/top-stories\/day-of-reckoning-post-yes-vote-says-jim-sillars-1-3539754#.VBMIZKn_1ik.twitter",
      "display_url" : "scotsman.com\/news\/politics\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "510775503381626880",
  "text" : "RT @johnwhilley: As corporate-establishment intimidation intensifies, @NaeFear rightly says there will be a 'day of reckoning'  http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jim Sillars",
        "screen_name" : "NaeFear",
        "indices" : [ 53, 61 ],
        "id_str" : "2260666053",
        "id" : 2260666053
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "indy",
        "indices" : [ 134, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/5dgPFzvvXo",
        "expanded_url" : "http:\/\/www.scotsman.com\/news\/politics\/top-stories\/day-of-reckoning-post-yes-vote-says-jim-sillars-1-3539754#.VBMIZKn_1ik.twitter",
        "display_url" : "scotsman.com\/news\/politics\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "510709344720404480",
    "text" : "As corporate-establishment intimidation intensifies, @NaeFear rightly says there will be a 'day of reckoning'  http:\/\/t.co\/5dgPFzvvXo #indy",
    "id" : 510709344720404480,
    "created_at" : "2014-09-13 08:39:30 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 510775503381626880,
  "created_at" : "2014-09-13 13:02:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Schneider",
      "screen_name" : "davidschneider",
      "indices" : [ 3, 18 ],
      "id_str" : "20098015",
      "id" : 20098015
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/davidschneider\/status\/510733940039376896\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/dQm7sGyyFl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BxZ9zzLIcAAWFka.jpg",
      "id_str" : "510733936616828928",
      "id" : 510733936616828928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxZ9zzLIcAAWFka.jpg",
      "sizes" : [ {
        "h" : 913,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 673
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 517,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 673
      } ],
      "display_url" : "pic.twitter.com\/dQm7sGyyFl"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510771768655896576",
  "text" : "RT @davidschneider: Loch Ness monster to leave Scotland if there's a Yes vote. Full statement here http:\/\/t.co\/dQm7sGyyFl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/davidschneider\/status\/510733940039376896\/photo\/1",
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/dQm7sGyyFl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BxZ9zzLIcAAWFka.jpg",
        "id_str" : "510733936616828928",
        "id" : 510733936616828928,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxZ9zzLIcAAWFka.jpg",
        "sizes" : [ {
          "h" : 913,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 673
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 517,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 673
        } ],
        "display_url" : "pic.twitter.com\/dQm7sGyyFl"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "510733940039376896",
    "text" : "Loch Ness monster to leave Scotland if there's a Yes vote. Full statement here http:\/\/t.co\/dQm7sGyyFl",
    "id" : 510733940039376896,
    "created_at" : "2014-09-13 10:17:14 +0000",
    "user" : {
      "name" : "David Schneider",
      "screen_name" : "davidschneider",
      "protected" : false,
      "id_str" : "20098015",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/85074940\/profilepic_normal.jpg",
      "id" : 20098015,
      "verified" : true
    }
  },
  "id" : 510771768655896576,
  "created_at" : "2014-09-13 12:47:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 0, 11 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "510745950340804609",
  "geo" : { },
  "id_str" : "510753141214965760",
  "in_reply_to_user_id" : 88202140,
  "text" : "@hughdellar is there 1 colligation here - with it? or 2 - to be + good, do not + sense adj + good? or more? always confuses me colligations!",
  "id" : 510753141214965760,
  "in_reply_to_status_id" : 510745950340804609,
  "created_at" : "2014-09-13 11:33:32 +0000",
  "in_reply_to_screen_name" : "hughdellar",
  "in_reply_to_user_id_str" : "88202140",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 48, 56 ],
      "id_str" : "10228272",
      "id" : 10228272
    }, {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 60, 70 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/ZinJ1bJ99Q",
      "expanded_url" : "http:\/\/youtu.be\/DiMXuEmqAHA",
      "display_url" : "youtu.be\/DiMXuEmqAHA"
    } ]
  },
  "geo" : { },
  "id_str" : "510740415847219200",
  "text" : "Empire strikes back: http:\/\/t.co\/ZinJ1bJ99Q via @YouTube ht @medialens forum :)",
  "id" : 510740415847219200,
  "created_at" : "2014-09-13 10:42:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "indices" : [ 3, 19 ],
      "id_str" : "1326508478",
      "id" : 1326508478
    }, {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "indices" : [ 62, 74 ],
      "id_str" : "849729062",
      "id" : 849729062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusMOOC",
      "indices" : [ 25, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/gXd6cFpHVD",
      "expanded_url" : "http:\/\/cass.lancs.ac.uk\/?p=1401",
      "display_url" : "cass.lancs.ac.uk\/?p=1401"
    } ]
  },
  "geo" : { },
  "id_str" : "510603570052624384",
  "text" : "RT @CorpusSocialSci: Our #corpusMOOC begins again on 29\/9\/14. @TonyMcEnery blogs about the 1st run and how the 2nd has been enhanced: http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tony McEnery",
        "screen_name" : "TonyMcEnery",
        "indices" : [ 41, 53 ],
        "id_str" : "849729062",
        "id" : 849729062
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpusMOOC",
        "indices" : [ 4, 15 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/gXd6cFpHVD",
        "expanded_url" : "http:\/\/cass.lancs.ac.uk\/?p=1401",
        "display_url" : "cass.lancs.ac.uk\/?p=1401"
      } ]
    },
    "geo" : { },
    "id_str" : "510398377893576705",
    "text" : "Our #corpusMOOC begins again on 29\/9\/14. @TonyMcEnery blogs about the 1st run and how the 2nd has been enhanced: http:\/\/t.co\/gXd6cFpHVD",
    "id" : 510398377893576705,
    "created_at" : "2014-09-12 12:03:50 +0000",
    "user" : {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "protected" : false,
      "id_str" : "1326508478",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3493899777\/ced36fe15c32eb911cbe3d64377524dc_normal.jpeg",
      "id" : 1326508478,
      "verified" : false
    }
  },
  "id" : 510603570052624384,
  "created_at" : "2014-09-13 01:39:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Davis",
      "screen_name" : "mrkrndvs",
      "indices" : [ 3, 12 ],
      "id_str" : "372768752",
      "id" : 372768752
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "priceless",
      "indices" : [ 138, 144 ]
    }, {
      "text" : "ccourses",
      "indices" : [ 143, 144 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510592509580693504",
  "text" : "RT @mrkrndvs: Dont tell me how much ur Twitter acc is worth in $$$, tell me how much it is worth in regards to learning &amp; connections #pric\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "priceless",
        "indices" : [ 124, 134 ]
      }, {
        "text" : "ccourses",
        "indices" : [ 135, 144 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "508065688116666369",
    "text" : "Dont tell me how much ur Twitter acc is worth in $$$, tell me how much it is worth in regards to learning &amp; connections #priceless #ccourses",
    "id" : 508065688116666369,
    "created_at" : "2014-09-06 01:34:34 +0000",
    "user" : {
      "name" : "Aaron Davis",
      "screen_name" : "mrkrndvs",
      "protected" : false,
      "id_str" : "372768752",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/708552669636333569\/eIfl-Utk_normal.jpg",
      "id" : 372768752,
      "verified" : false
    }
  },
  "id" : 510592509580693504,
  "created_at" : "2014-09-13 00:55:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Caulfield",
      "screen_name" : "holden",
      "indices" : [ 3, 10 ],
      "id_str" : "1912681",
      "id" : 1912681
    }, {
      "name" : "A. Michael Berman",
      "screen_name" : "amichaelberman",
      "indices" : [ 27, 42 ],
      "id_str" : "16159736",
      "id" : 16159736
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/BEirzv06bT",
      "expanded_url" : "http:\/\/hapgood.us\/2014\/09\/12\/learning-design-pattern-121-youre-doing-it-wrong\/",
      "display_url" : "hapgood.us\/2014\/09\/12\/lea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "510574405039452160",
  "text" : "RT @holden: Got lunch with @amichaelberman and ended up producing our first learning design pattern: http:\/\/t.co\/BEirzv06bT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "A. Michael Berman",
        "screen_name" : "amichaelberman",
        "indices" : [ 15, 30 ],
        "id_str" : "16159736",
        "id" : 16159736
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/BEirzv06bT",
        "expanded_url" : "http:\/\/hapgood.us\/2014\/09\/12\/learning-design-pattern-121-youre-doing-it-wrong\/",
        "display_url" : "hapgood.us\/2014\/09\/12\/lea\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "510573518765834240",
    "text" : "Got lunch with @amichaelberman and ended up producing our first learning design pattern: http:\/\/t.co\/BEirzv06bT",
    "id" : 510573518765834240,
    "created_at" : "2014-09-12 23:39:47 +0000",
    "user" : {
      "name" : "Mike Caulfield",
      "screen_name" : "holden",
      "protected" : false,
      "id_str" : "1912681",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/752538301538545665\/mXNoIc4W_normal.jpg",
      "id" : 1912681,
      "verified" : false
    }
  },
  "id" : 510574405039452160,
  "created_at" : "2014-09-12 23:43:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Feldstein",
      "screen_name" : "mfeldstein67",
      "indices" : [ 85, 98 ],
      "id_str" : "10187072",
      "id" : 10187072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/Kl9OJMJHlj",
      "expanded_url" : "http:\/\/mfeldstein.com\/apple-watch-tells-us-future-ed-tech\/",
      "display_url" : "mfeldstein.com\/apple-watch-te\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "510571137701396480",
  "text" : "What the Apple Watch Tells Us About the Future of Ed Tech http:\/\/t.co\/Kl9OJMJHlj via @mfeldstein67",
  "id" : 510571137701396480,
  "created_at" : "2014-09-12 23:30:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Phipps",
      "screen_name" : "lousylinguist",
      "indices" : [ 3, 17 ],
      "id_str" : "48459936",
      "id" : 48459936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/WQDkAu6x8Z",
      "expanded_url" : "http:\/\/www.buzzfeed.com\/tabathaleggett\/if-we-talked-about-meat-eaters-the-way-we-talk-about-vegetar#3l18c83",
      "display_url" : "buzzfeed.com\/tabathaleggett\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "510568495357370368",
  "text" : "RT @lousylinguist: hehe, \"If We Talked About Meat Eaters The Way We Talk About Vegetarians\" http:\/\/t.co\/WQDkAu6x8Z",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/WQDkAu6x8Z",
        "expanded_url" : "http:\/\/www.buzzfeed.com\/tabathaleggett\/if-we-talked-about-meat-eaters-the-way-we-talk-about-vegetar#3l18c83",
        "display_url" : "buzzfeed.com\/tabathaleggett\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "510527177805152256",
    "text" : "hehe, \"If We Talked About Meat Eaters The Way We Talk About Vegetarians\" http:\/\/t.co\/WQDkAu6x8Z",
    "id" : 510527177805152256,
    "created_at" : "2014-09-12 20:35:38 +0000",
    "user" : {
      "name" : "Christopher Phipps",
      "screen_name" : "lousylinguist",
      "protected" : false,
      "id_str" : "48459936",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750789987113660416\/2IPugaM9_normal.jpg",
      "id" : 48459936,
      "verified" : false
    }
  },
  "id" : 510568495357370368,
  "created_at" : "2014-09-12 23:19:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol Goodey",
      "screen_name" : "cgoodey",
      "indices" : [ 0, 8 ],
      "id_str" : "26606833",
      "id" : 26606833
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "510510086696230912",
  "geo" : { },
  "id_str" : "510510848801243136",
  "in_reply_to_user_id" : 26606833,
  "text" : "@cgoodey well it has already begun whatever the actual formal outcome no?",
  "id" : 510510848801243136,
  "in_reply_to_status_id" : 510510086696230912,
  "created_at" : "2014-09-12 19:30:45 +0000",
  "in_reply_to_screen_name" : "cgoodey",
  "in_reply_to_user_id_str" : "26606833",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol Goodey",
      "screen_name" : "cgoodey",
      "indices" : [ 0, 8 ],
      "id_str" : "26606833",
      "id" : 26606833
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "510501590441406465",
  "geo" : { },
  "id_str" : "510506919023616000",
  "in_reply_to_user_id" : 26606833,
  "text" : "@cgoodey and start annoying non-scotland peeps with how great the new era is going :)",
  "id" : 510506919023616000,
  "in_reply_to_status_id" : 510501590441406465,
  "created_at" : "2014-09-12 19:15:08 +0000",
  "in_reply_to_screen_name" : "cgoodey",
  "in_reply_to_user_id_str" : "26606833",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Duygu \u00C7andarl\u0131",
      "screen_name" : "duygucandarli",
      "indices" : [ 3, 17 ],
      "id_str" : "48839094",
      "id" : 48839094
    }, {
      "name" : "British Council",
      "screen_name" : "BritishCouncil",
      "indices" : [ 20, 35 ],
      "id_str" : "14732889",
      "id" : 14732889
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Turkish",
      "indices" : [ 37, 45 ]
    }, {
      "text" : "FocusFriday",
      "indices" : [ 127, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/xfCfaTskQF",
      "expanded_url" : "http:\/\/ow.ly\/BpO1u",
      "display_url" : "ow.ly\/BpO1u"
    } ]
  },
  "geo" : { },
  "id_str" : "510493540913545216",
  "text" : "RT @duygucandarli: \u201C@BritishCouncil: #Turkish: a fascinating structure and huge influence (blog post): http:\/\/t.co\/xfCfaTskQF\u201D #FocusFriday",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "British Council",
        "screen_name" : "BritishCouncil",
        "indices" : [ 1, 16 ],
        "id_str" : "14732889",
        "id" : 14732889
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Turkish",
        "indices" : [ 18, 26 ]
      }, {
        "text" : "FocusFriday",
        "indices" : [ 108, 120 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/xfCfaTskQF",
        "expanded_url" : "http:\/\/ow.ly\/BpO1u",
        "display_url" : "ow.ly\/BpO1u"
      } ]
    },
    "in_reply_to_status_id_str" : "510373522838126592",
    "geo" : { },
    "id_str" : "510409347873406976",
    "in_reply_to_user_id" : 14732889,
    "text" : "\u201C@BritishCouncil: #Turkish: a fascinating structure and huge influence (blog post): http:\/\/t.co\/xfCfaTskQF\u201D #FocusFriday",
    "id" : 510409347873406976,
    "in_reply_to_status_id" : 510373522838126592,
    "created_at" : "2014-09-12 12:47:26 +0000",
    "in_reply_to_screen_name" : "BritishCouncil",
    "in_reply_to_user_id_str" : "14732889",
    "user" : {
      "name" : "Duygu \u00C7andarl\u0131",
      "screen_name" : "duygucandarli",
      "protected" : false,
      "id_str" : "48839094",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/473607105765576704\/DIiO0Cy7_normal.jpeg",
      "id" : 48839094,
      "verified" : false
    }
  },
  "id" : 510493540913545216,
  "created_at" : "2014-09-12 18:21:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    }, {
      "name" : "Paul Mason",
      "screen_name" : "paulmasonnews",
      "indices" : [ 81, 95 ],
      "id_str" : "19811190",
      "id" : 19811190
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "indyref",
      "indices" : [ 96, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/qRaJHcItve",
      "expanded_url" : "http:\/\/johnhilley.blogspot.co.uk\/2014\/09\/independence-taking-renton-test.html",
      "display_url" : "johnhilley.blogspot.co.uk\/2014\/09\/indepe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "510490083066404864",
  "text" : "RT @johnwhilley: Independence - taking the 'Renton test' http:\/\/t.co\/qRaJHcItve  @paulmasonnews #indyref",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Paul Mason",
        "screen_name" : "paulmasonnews",
        "indices" : [ 64, 78 ],
        "id_str" : "19811190",
        "id" : 19811190
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "indyref",
        "indices" : [ 79, 87 ]
      } ],
      "urls" : [ {
        "indices" : [ 40, 62 ],
        "url" : "http:\/\/t.co\/qRaJHcItve",
        "expanded_url" : "http:\/\/johnhilley.blogspot.co.uk\/2014\/09\/independence-taking-renton-test.html",
        "display_url" : "johnhilley.blogspot.co.uk\/2014\/09\/indepe\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "510475434384179200",
    "text" : "Independence - taking the 'Renton test' http:\/\/t.co\/qRaJHcItve  @paulmasonnews #indyref",
    "id" : 510475434384179200,
    "created_at" : "2014-09-12 17:10:02 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 510490083066404864,
  "created_at" : "2014-09-12 18:08:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Pilger",
      "screen_name" : "johnpilger",
      "indices" : [ 3, 14 ],
      "id_str" : "869825995",
      "id" : 869825995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 143, 144 ],
      "url" : "http:\/\/t.co\/JAMcG3OkaE",
      "expanded_url" : "http:\/\/bit.ly\/1tAClmD",
      "display_url" : "bit.ly\/1tAClmD"
    } ]
  },
  "geo" : { },
  "id_str" : "510429014734155777",
  "text" : "RT @johnpilger: \u201CThere is a taboo,\u201D said Edward Said, \u201Con telling the truth about Palestine &amp; the destructive force behind Israel\"... http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/JAMcG3OkaE",
        "expanded_url" : "http:\/\/bit.ly\/1tAClmD",
        "display_url" : "bit.ly\/1tAClmD"
      } ]
    },
    "geo" : { },
    "id_str" : "509997538401734656",
    "text" : "\u201CThere is a taboo,\u201D said Edward Said, \u201Con telling the truth about Palestine &amp; the destructive force behind Israel\"... http:\/\/t.co\/JAMcG3OkaE",
    "id" : 509997538401734656,
    "created_at" : "2014-09-11 09:31:03 +0000",
    "user" : {
      "name" : "John Pilger",
      "screen_name" : "johnpilger",
      "protected" : false,
      "id_str" : "869825995",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2698807939\/9ae3deca6381c2a9e1ecfec3d7b54303_normal.jpeg",
      "id" : 869825995,
      "verified" : true
    }
  },
  "id" : 510429014734155777,
  "created_at" : "2014-09-12 14:05:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "angoid",
      "screen_name" : "angoid",
      "indices" : [ 3, 10 ],
      "id_str" : "85792851",
      "id" : 85792851
    }, {
      "name" : "Frankie Boyle",
      "screen_name" : "frankieboyle",
      "indices" : [ 12, 25 ],
      "id_str" : "17336372",
      "id" : 17336372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510426924880257025",
  "text" : "RT @angoid: @frankieboyle No one in Westminster talking about \"Broken Britain\" any more either. Must be fixed.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Frankie Boyle",
        "screen_name" : "frankieboyle",
        "indices" : [ 0, 13 ],
        "id_str" : "17336372",
        "id" : 17336372
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "510425181068992513",
    "geo" : { },
    "id_str" : "510425433335013376",
    "in_reply_to_user_id" : 17336372,
    "text" : "@frankieboyle No one in Westminster talking about \"Broken Britain\" any more either. Must be fixed.",
    "id" : 510425433335013376,
    "in_reply_to_status_id" : 510425181068992513,
    "created_at" : "2014-09-12 13:51:21 +0000",
    "in_reply_to_screen_name" : "frankieboyle",
    "in_reply_to_user_id_str" : "17336372",
    "user" : {
      "name" : "angoid",
      "screen_name" : "angoid",
      "protected" : false,
      "id_str" : "85792851",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525479874\/cerebahb_normal.GIF",
      "id" : 85792851,
      "verified" : false
    }
  },
  "id" : 510426924880257025,
  "created_at" : "2014-09-12 13:57:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MarisaConstantinides",
      "screen_name" : "Marisa_C",
      "indices" : [ 0, 9 ],
      "id_str" : "18272500",
      "id" : 18272500
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "510390600760565760",
  "geo" : { },
  "id_str" : "510413339009503233",
  "in_reply_to_user_id" : 18272500,
  "text" : "@Marisa_C thx Marisa enjoy the w\/e :)",
  "id" : 510413339009503233,
  "in_reply_to_status_id" : 510390600760565760,
  "created_at" : "2014-09-12 13:03:17 +0000",
  "in_reply_to_screen_name" : "Marisa_C",
  "in_reply_to_user_id_str" : "18272500",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "indices" : [ 0, 12 ],
      "id_str" : "849729062",
      "id" : 849729062
    }, {
      "name" : "Kathy Fagan",
      "screen_name" : "eslkathy",
      "indices" : [ 13, 22 ],
      "id_str" : "303849696",
      "id" : 303849696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/zJ3G1Q1v90",
      "expanded_url" : "http:\/\/myweb.tiscali.co.uk\/wordscape\/wordlist\/fuelforlearning.html",
      "display_url" : "myweb.tiscali.co.uk\/wordscape\/word\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "510355507136454656",
  "geo" : { },
  "id_str" : "510392427489005568",
  "in_reply_to_user_id" : 849729062,
  "text" : "@TonyMcEnery @eslkathy nice! there is a humorous pronunciation of DDL as Diddle or Doddle by John Higgens here http:\/\/t.co\/zJ3G1Q1v90",
  "id" : 510392427489005568,
  "in_reply_to_status_id" : 510355507136454656,
  "created_at" : "2014-09-12 11:40:12 +0000",
  "in_reply_to_screen_name" : "TonyMcEnery",
  "in_reply_to_user_id_str" : "849729062",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "indices" : [ 3, 15 ],
      "id_str" : "849729062",
      "id" : 849729062
    }, {
      "name" : "Kathy Fagan",
      "screen_name" : "eslkathy",
      "indices" : [ 17, 26 ],
      "id_str" : "303849696",
      "id" : 303849696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510389408802287616",
  "text" : "RT @TonyMcEnery: @eslkathy Have added a lovely reading on data driven learning by Tim Johns to wk 7 the course. Should prove of interest to\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kathy Fagan",
        "screen_name" : "eslkathy",
        "indices" : [ 0, 9 ],
        "id_str" : "303849696",
        "id" : 303849696
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "510211964917014528",
    "geo" : { },
    "id_str" : "510355507136454656",
    "in_reply_to_user_id" : 303849696,
    "text" : "@eslkathy Have added a lovely reading on data driven learning by Tim Johns to wk 7 the course. Should prove of interest to all ELT folk!",
    "id" : 510355507136454656,
    "in_reply_to_status_id" : 510211964917014528,
    "created_at" : "2014-09-12 09:13:29 +0000",
    "in_reply_to_screen_name" : "eslkathy",
    "in_reply_to_user_id_str" : "303849696",
    "user" : {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "protected" : false,
      "id_str" : "849729062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2676020930\/a4a1f40d56b447c9dfca1d7b9be4f4b4_normal.jpeg",
      "id" : 849729062,
      "verified" : false
    }
  },
  "id" : 510389408802287616,
  "created_at" : "2014-09-12 11:28:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "510362074598612992",
  "geo" : { },
  "id_str" : "510388241431007232",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco wonder what the fines for late returns at such an establishment?",
  "id" : 510388241431007232,
  "in_reply_to_status_id" : 510362074598612992,
  "created_at" : "2014-09-12 11:23:33 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike S. Boyle",
      "screen_name" : "heyboyle",
      "indices" : [ 0, 9 ],
      "id_str" : "612840231",
      "id" : 612840231
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 72, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/pCh2PmidGp",
      "expanded_url" : "https:\/\/plus.google.com\/communities\/101266284417587206243",
      "display_url" : "plus.google.com\/communities\/10\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "510217545677557760",
  "geo" : { },
  "id_str" : "510335852313321472",
  "in_reply_to_user_id" : 612840231,
  "text" : "@heyboyle hi mike do consider joining G+ corpus ling community for when #corpusmooc starts https:\/\/t.co\/pCh2PmidGp",
  "id" : 510335852313321472,
  "in_reply_to_status_id" : 510217545677557760,
  "created_at" : "2014-09-12 07:55:23 +0000",
  "in_reply_to_screen_name" : "heyboyle",
  "in_reply_to_user_id_str" : "612840231",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "indices" : [ 0, 13 ],
      "id_str" : "1685397408",
      "id" : 1685397408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "510200302046547968",
  "geo" : { },
  "id_str" : "510202873414967296",
  "in_reply_to_user_id" : 1685397408,
  "text" : "@harrisonmike u got the crackle &amp; the pop missing the snap :) - frying,stream,kettle, hoover?",
  "id" : 510202873414967296,
  "in_reply_to_status_id" : 510200302046547968,
  "created_at" : "2014-09-11 23:06:58 +0000",
  "in_reply_to_screen_name" : "harrisonmike",
  "in_reply_to_user_id_str" : "1685397408",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kathy Fagan",
      "screen_name" : "eslkathy",
      "indices" : [ 85, 94 ],
      "id_str" : "303849696",
      "id" : 303849696
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 14, 25 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/7brRkMCOxa",
      "expanded_url" : "http:\/\/freerangekef.blogspot.fr\/2014\/09\/join-me.html",
      "display_url" : "freerangekef.blogspot.fr\/2014\/09\/join-m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "510197714731413504",
  "text" : "first spotted #corpusmooc post of the new start - Join me? http:\/\/t.co\/7brRkMCOxa by @eslkathy",
  "id" : 510197714731413504,
  "created_at" : "2014-09-11 22:46:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike S. Boyle",
      "screen_name" : "heyboyle",
      "indices" : [ 0, 9 ],
      "id_str" : "612840231",
      "id" : 612840231
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 82, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/FYDp1bLhBI",
      "expanded_url" : "https:\/\/plus.google.com\/104940199413423400545\/posts\/1HGHyCeHMt8",
      "display_url" : "plus.google.com\/10494019941342\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "509088470766473216",
  "geo" : { },
  "id_str" : "510194840806895616",
  "in_reply_to_user_id" : 612840231,
  "text" : "@heyboyle u may find this interesting if not seen already https:\/\/t.co\/FYDp1bLhBI #corpusmooc",
  "id" : 510194840806895616,
  "in_reply_to_status_id" : 509088470766473216,
  "created_at" : "2014-09-11 22:35:03 +0000",
  "in_reply_to_screen_name" : "heyboyle",
  "in_reply_to_user_id_str" : "612840231",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lu Hersey",
      "screen_name" : "LuWrites",
      "indices" : [ 3, 12 ],
      "id_str" : "516580064",
      "id" : 516580064
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/LuWrites\/status\/504698550987784193\/photo\/1",
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/khvf3l9Ahm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BwEMp7MCMAAnpvH.jpg",
      "id_str" : "504698547644542976",
      "id" : 504698547644542976,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwEMp7MCMAAnpvH.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/khvf3l9Ahm"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510091805816520705",
  "text" : "RT @LuWrites: Best thesaurus joke I've seen all day :) http:\/\/t.co\/khvf3l9Ahm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/LuWrites\/status\/504698550987784193\/photo\/1",
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/khvf3l9Ahm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BwEMp7MCMAAnpvH.jpg",
        "id_str" : "504698547644542976",
        "id" : 504698547644542976,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwEMp7MCMAAnpvH.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/khvf3l9Ahm"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "504698550987784193",
    "text" : "Best thesaurus joke I've seen all day :) http:\/\/t.co\/khvf3l9Ahm",
    "id" : 504698550987784193,
    "created_at" : "2014-08-27 18:34:46 +0000",
    "user" : {
      "name" : "Lu Hersey",
      "screen_name" : "LuWrites",
      "protected" : false,
      "id_str" : "516580064",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/739573935092731904\/KDD8_YRg_normal.jpg",
      "id" : 516580064,
      "verified" : false
    }
  },
  "id" : 510091805816520705,
  "created_at" : "2014-09-11 15:45:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 98, 114 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/eKELumBvOK",
      "expanded_url" : "http:\/\/wp.me\/p2CPYN-fs",
      "display_url" : "wp.me\/p2CPYN-fs"
    } ]
  },
  "geo" : { },
  "id_str" : "510082265439686657",
  "text" : "The U.S.'s 'successful' counter-terror campaigns in Somalia and Yemen. http:\/\/t.co\/eKELumBvOK via @wordpressdotcom",
  "id" : 510082265439686657,
  "created_at" : "2014-09-11 15:07:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "indyref",
      "indices" : [ 118, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/qSdIL2es5r",
      "expanded_url" : "http:\/\/johnhilley.blogspot.co.uk\/2014\/09\/banking-on-corporate-blackmail-resist.html",
      "display_url" : "johnhilley.blogspot.co.uk\/2014\/09\/bankin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "510080678466433025",
  "text" : "RT @johnwhilley: Banking on corporate blackmail - resist the fear and safely deposit your Yes  http:\/\/t.co\/qSdIL2es5r #indyref",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "indyref",
        "indices" : [ 101, 109 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/qSdIL2es5r",
        "expanded_url" : "http:\/\/johnhilley.blogspot.co.uk\/2014\/09\/banking-on-corporate-blackmail-resist.html",
        "display_url" : "johnhilley.blogspot.co.uk\/2014\/09\/bankin\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "510043201504567296",
    "text" : "Banking on corporate blackmail - resist the fear and safely deposit your Yes  http:\/\/t.co\/qSdIL2es5r #indyref",
    "id" : 510043201504567296,
    "created_at" : "2014-09-11 12:32:30 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 510080678466433025,
  "created_at" : "2014-09-11 15:01:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "williamjturkel",
      "screen_name" : "williamjturkel",
      "indices" : [ 0, 15 ],
      "id_str" : "9280142",
      "id" : 9280142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "509912796126257152",
  "geo" : { },
  "id_str" : "509995021681315840",
  "in_reply_to_user_id" : 9280142,
  "text" : "@williamjturkel torrent?",
  "id" : 509995021681315840,
  "in_reply_to_status_id" : 509912796126257152,
  "created_at" : "2014-09-11 09:21:03 +0000",
  "in_reply_to_screen_name" : "williamjturkel",
  "in_reply_to_user_id_str" : "9280142",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yutaka Ishii (\u77F3\u4E95\u96C4\u9686)",
      "screen_name" : "yishii_0207",
      "indices" : [ 108, 120 ],
      "id_str" : "171376048",
      "id" : 171376048
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/1qHjR3koOl",
      "expanded_url" : "http:\/\/eltj.oxfordjournals.org\/content\/68\/4\/376.full",
      "display_url" : "eltj.oxfordjournals.org\/content\/68\/4\/3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "509994610098438144",
  "text" : "Moving beyond accuracy: from tests of English to tests of \u2018Englishing\u2019 http:\/\/t.co\/1qHjR3koOl full text h\/t @yishii_0207",
  "id" : 509994610098438144,
  "created_at" : "2014-09-11 09:19:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StudyBundles",
      "screen_name" : "StudyBundles",
      "indices" : [ 0, 13 ],
      "id_str" : "2558614093",
      "id" : 2558614093
    }, {
      "name" : "Laura Phelps",
      "screen_name" : "pterolaur",
      "indices" : [ 14, 24 ],
      "id_str" : "90093887",
      "id" : 90093887
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "509983714487848960",
  "geo" : { },
  "id_str" : "509984403960131584",
  "in_reply_to_user_id" : 2558614093,
  "text" : "@StudyBundles @pterolaur \"authentic\" is problematic word someone suggested the word \"plausible\" as a better one?",
  "id" : 509984403960131584,
  "in_reply_to_status_id" : 509983714487848960,
  "created_at" : "2014-09-11 08:38:51 +0000",
  "in_reply_to_screen_name" : "StudyBundles",
  "in_reply_to_user_id_str" : "2558614093",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vocable Education",
      "screen_name" : "VocableEduc",
      "indices" : [ 3, 15 ],
      "id_str" : "714414703",
      "id" : 714414703
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "num\u00E9rique",
      "indices" : [ 61, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/KUGHuv7BTN",
      "expanded_url" : "http:\/\/ow.ly\/Bhwje",
      "display_url" : "ow.ly\/Bhwje"
    } ]
  },
  "geo" : { },
  "id_str" : "509980149631430656",
  "text" : "RT @VocableEduc: Les pratiques des enseignants en mati\u00E8re de #num\u00E9rique : d\u00E9couvrez  les r\u00E9sultats de l'enqu\u00EAte  http:\/\/t.co\/KUGHuv7BTN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "num\u00E9rique",
        "indices" : [ 44, 54 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/KUGHuv7BTN",
        "expanded_url" : "http:\/\/ow.ly\/Bhwje",
        "display_url" : "ow.ly\/Bhwje"
      } ]
    },
    "geo" : { },
    "id_str" : "509714227897327616",
    "text" : "Les pratiques des enseignants en mati\u00E8re de #num\u00E9rique : d\u00E9couvrez  les r\u00E9sultats de l'enqu\u00EAte  http:\/\/t.co\/KUGHuv7BTN",
    "id" : 509714227897327616,
    "created_at" : "2014-09-10 14:45:16 +0000",
    "user" : {
      "name" : "Vocable Education",
      "screen_name" : "VocableEduc",
      "protected" : false,
      "id_str" : "714414703",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2428801148\/cx82eco0zonm3051nvhz_normal.jpeg",
      "id" : 714414703,
      "verified" : false
    }
  },
  "id" : 509980149631430656,
  "created_at" : "2014-09-11 08:21:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yasmin Nair",
      "screen_name" : "NairYasmin",
      "indices" : [ 3, 14 ],
      "id_str" : "917680644",
      "id" : 917680644
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/zJiqLTMxCN",
      "expanded_url" : "http:\/\/tinyurl.com\/lqmzjn9",
      "display_url" : "tinyurl.com\/lqmzjn9"
    } ]
  },
  "geo" : { },
  "id_str" : "509977578808307712",
  "text" : "RT @NairYasmin: I wrote a short piece on \"Steven Salaita and the Myth of Academic Freedom.\" Please repost widely. \nhttp:\/\/t.co\/zJiqLTMxCN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/zJiqLTMxCN",
        "expanded_url" : "http:\/\/tinyurl.com\/lqmzjn9",
        "display_url" : "tinyurl.com\/lqmzjn9"
      } ]
    },
    "geo" : { },
    "id_str" : "509202000291307520",
    "text" : "I wrote a short piece on \"Steven Salaita and the Myth of Academic Freedom.\" Please repost widely. \nhttp:\/\/t.co\/zJiqLTMxCN",
    "id" : 509202000291307520,
    "created_at" : "2014-09-09 04:49:52 +0000",
    "user" : {
      "name" : "Yasmin Nair",
      "screen_name" : "NairYasmin",
      "protected" : false,
      "id_str" : "917680644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2790504033\/fd4b80c229d3c8eca1e5e77fde4afb52_normal.png",
      "id" : 917680644,
      "verified" : false
    }
  },
  "id" : 509977578808307712,
  "created_at" : "2014-09-11 08:11:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Inside Higher Ed",
      "screen_name" : "insidehighered",
      "indices" : [ 3, 18 ],
      "id_str" : "16045268",
      "id" : 16045268
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/insidehighered\/status\/509684066141364224\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/3JG8SJThGs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BxLC9P8CYAAj47k.jpg",
      "id_str" : "509684065352441856",
      "id" : 509684065352441856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxLC9P8CYAAj47k.jpg",
      "sizes" : [ {
        "h" : 219,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 413,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 387,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 413,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/3JG8SJThGs"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/HDh9bseDGq",
      "expanded_url" : "https:\/\/www.insidehighered.com\/news\/2014\/09\/10\/steven-salaita-speaks-out-about-lost-job-offer-illinois",
      "display_url" : "insidehighered.com\/news\/2014\/09\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "509976973020790784",
  "text" : "RT @insidehighered: Steven Salaita breaks his silence on rescinded U. of Illinois job offer:\n\nhttps:\/\/t.co\/HDh9bseDGq http:\/\/t.co\/3JG8SJThGs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/insidehighered\/status\/509684066141364224\/photo\/1",
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/3JG8SJThGs",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BxLC9P8CYAAj47k.jpg",
        "id_str" : "509684065352441856",
        "id" : 509684065352441856,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxLC9P8CYAAj47k.jpg",
        "sizes" : [ {
          "h" : 219,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 413,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 387,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 413,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/3JG8SJThGs"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/HDh9bseDGq",
        "expanded_url" : "https:\/\/www.insidehighered.com\/news\/2014\/09\/10\/steven-salaita-speaks-out-about-lost-job-offer-illinois",
        "display_url" : "insidehighered.com\/news\/2014\/09\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "509684066141364224",
    "text" : "Steven Salaita breaks his silence on rescinded U. of Illinois job offer:\n\nhttps:\/\/t.co\/HDh9bseDGq http:\/\/t.co\/3JG8SJThGs",
    "id" : 509684066141364224,
    "created_at" : "2014-09-10 12:45:25 +0000",
    "user" : {
      "name" : "Inside Higher Ed",
      "screen_name" : "insidehighered",
      "protected" : false,
      "id_str" : "16045268",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/695280471572357123\/Wc-6PxUA_normal.png",
      "id" : 16045268,
      "verified" : true
    }
  },
  "id" : 509976973020790784,
  "created_at" : "2014-09-11 08:09:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Szab\u00F3",
      "screen_name" : "RobertASzabo",
      "indices" : [ 3, 16 ],
      "id_str" : "145285777",
      "id" : 145285777
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/IPRHaHqxPr",
      "expanded_url" : "http:\/\/www.theguardian.com\/science\/brain-flapping\/2014\/sep\/10\/wild-extrapolation-classification-system-science-media-scepticism?CMP=fb_guWARNING",
      "display_url" : "theguardian.com\/science\/brain-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "509973082837381120",
  "text" : "RT @RobertASzabo: WARNING: Wild Extrapolation (one of many possible classifications for science articles) http:\/\/t.co\/IPRHaHqxPr:",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/IPRHaHqxPr",
        "expanded_url" : "http:\/\/www.theguardian.com\/science\/brain-flapping\/2014\/sep\/10\/wild-extrapolation-classification-system-science-media-scepticism?CMP=fb_guWARNING",
        "display_url" : "theguardian.com\/science\/brain-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "509972322351345664",
    "text" : "WARNING: Wild Extrapolation (one of many possible classifications for science articles) http:\/\/t.co\/IPRHaHqxPr:",
    "id" : 509972322351345664,
    "created_at" : "2014-09-11 07:50:51 +0000",
    "user" : {
      "name" : "Rob Szab\u00F3",
      "screen_name" : "RobertASzabo",
      "protected" : false,
      "id_str" : "145285777",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666724461559812096\/XTsQWxw6_normal.jpg",
      "id" : 145285777,
      "verified" : false
    }
  },
  "id" : 509973082837381120,
  "created_at" : "2014-09-11 07:53:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 106, 116 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/AAjIFrEvpg",
      "expanded_url" : "http:\/\/www.indymedia.org.uk\/en\/regions\/world\/2014\/09\/518098.html",
      "display_url" : "indymedia.org.uk\/en\/regions\/wor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "509962707249139712",
  "text" : "Report with media analysis of march on NATO Newport Thursday 4th September 2014 http:\/\/t.co\/AAjIFrEvpg ht @medialens",
  "id" : 509962707249139712,
  "created_at" : "2014-09-11 07:12:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "natiserhost197",
      "screen_name" : "esl_robert",
      "indices" : [ 0, 11 ],
      "id_str" : "2982357761",
      "id" : 2982357761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/ydV54XNSsi",
      "expanded_url" : "http:\/\/www.corpus4u.org",
      "display_url" : "corpus4u.org"
    } ]
  },
  "geo" : { },
  "id_str" : "509852707042394112",
  "in_reply_to_user_id" : 18526186,
  "text" : "@esl_robert check http:\/\/t.co\/ydV54XNSsi post titled  Small Topics for Doing Corpus Research Work",
  "id" : 509852707042394112,
  "created_at" : "2014-09-10 23:55:32 +0000",
  "in_reply_to_screen_name" : "RobertEPoole",
  "in_reply_to_user_id_str" : "18526186",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Rayson",
      "screen_name" : "perayson",
      "indices" : [ 0, 9 ],
      "id_str" : "263108959",
      "id" : 263108959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "509774683890544640",
  "geo" : { },
  "id_str" : "509825891271475200",
  "in_reply_to_user_id" : 263108959,
  "text" : "@perayson hehe :) i suspect the bigger one is bank of english as lodge was prof in brum",
  "id" : 509825891271475200,
  "in_reply_to_status_id" : 509774683890544640,
  "created_at" : "2014-09-10 22:08:59 +0000",
  "in_reply_to_screen_name" : "perayson",
  "in_reply_to_user_id_str" : "263108959",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vedrana Vojkovi\u0107",
      "screen_name" : "Ven_VVE",
      "indices" : [ 0, 8 ],
      "id_str" : "270839603",
      "id" : 270839603
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "509810981665783808",
  "geo" : { },
  "id_str" : "509812689871585280",
  "in_reply_to_user_id" : 270839603,
  "text" : "@Ven_VVE ok will keep it in mind :)",
  "id" : 509812689871585280,
  "in_reply_to_status_id" : 509810981665783808,
  "created_at" : "2014-09-10 21:16:31 +0000",
  "in_reply_to_screen_name" : "Ven_VVE",
  "in_reply_to_user_id_str" : "270839603",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Caulfield",
      "screen_name" : "holden",
      "indices" : [ 3, 10 ],
      "id_str" : "1912681",
      "id" : 1912681
    }, {
      "name" : "Mike Wesch",
      "screen_name" : "mwesch",
      "indices" : [ 116, 123 ],
      "id_str" : "4906851",
      "id" : 4906851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/MlZ0qdzKMM",
      "expanded_url" : "http:\/\/hapgood.us\/2014\/09\/10\/learning-design-patterns-as-an-alternative-model-of-course-design\/",
      "display_url" : "hapgood.us\/2014\/09\/10\/lea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "509811231499513856",
  "text" : "RT @holden: Learning Design Patterns as an Alternative Model of Course Design: http:\/\/t.co\/MlZ0qdzKMM interested in @mwesch's take on this.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mike Wesch",
        "screen_name" : "mwesch",
        "indices" : [ 104, 111 ],
        "id_str" : "4906851",
        "id" : 4906851
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/MlZ0qdzKMM",
        "expanded_url" : "http:\/\/hapgood.us\/2014\/09\/10\/learning-design-patterns-as-an-alternative-model-of-course-design\/",
        "display_url" : "hapgood.us\/2014\/09\/10\/lea\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "509777951575924736",
    "text" : "Learning Design Patterns as an Alternative Model of Course Design: http:\/\/t.co\/MlZ0qdzKMM interested in @mwesch's take on this.",
    "id" : 509777951575924736,
    "created_at" : "2014-09-10 18:58:29 +0000",
    "user" : {
      "name" : "Mike Caulfield",
      "screen_name" : "holden",
      "protected" : false,
      "id_str" : "1912681",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/752538301538545665\/mXNoIc4W_normal.jpg",
      "id" : 1912681,
      "verified" : false
    }
  },
  "id" : 509811231499513856,
  "created_at" : "2014-09-10 21:10:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 0, 8 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509809579010818048",
  "text" : "#eltchat thanks all :)",
  "id" : 509809579010818048,
  "created_at" : "2014-09-10 21:04:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vedrana Vojkovi\u0107",
      "screen_name" : "Ven_VVE",
      "indices" : [ 0, 8 ],
      "id_str" : "270839603",
      "id" : 270839603
    }, {
      "name" : "Sue Annan",
      "screen_name" : "SueAnnan",
      "indices" : [ 9, 18 ],
      "id_str" : "136001411",
      "id" : 136001411
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "piratebox",
      "indices" : [ 38, 48 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "509808971612712960",
  "geo" : { },
  "id_str" : "509809443757096961",
  "in_reply_to_user_id" : 270839603,
  "text" : "@Ven_VVE @SueAnnan great though a new #piratebox post is forthcoming as present one maybe confusing to some teachers :\/",
  "id" : 509809443757096961,
  "in_reply_to_status_id" : 509808971612712960,
  "created_at" : "2014-09-10 21:03:37 +0000",
  "in_reply_to_screen_name" : "Ven_VVE",
  "in_reply_to_user_id_str" : "270839603",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sue Annan",
      "screen_name" : "SueAnnan",
      "indices" : [ 0, 9 ],
      "id_str" : "136001411",
      "id" : 136001411
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 47, 55 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "509804457673367552",
  "geo" : { },
  "id_str" : "509808531093344256",
  "in_reply_to_user_id" : 136001411,
  "text" : "@SueAnnan will have to remember to suggest it! #eltchat",
  "id" : 509808531093344256,
  "in_reply_to_status_id" : 509804457673367552,
  "created_at" : "2014-09-10 21:00:00 +0000",
  "in_reply_to_screen_name" : "SueAnnan",
  "in_reply_to_user_id_str" : "136001411",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 0, 8 ]
    }, {
      "text" : "piratebox",
      "indices" : [ 52, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509807774642229249",
  "text" : "#eltchat one tool that i have used and recommend is #piratebox as a way to share files in class",
  "id" : 509807774642229249,
  "created_at" : "2014-09-10 20:56:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StudyBundles",
      "screen_name" : "StudyBundles",
      "indices" : [ 3, 16 ],
      "id_str" : "2558614093",
      "id" : 2558614093
    }, {
      "name" : "Dolphin Comp. Access",
      "screen_name" : "yourdolphin",
      "indices" : [ 113, 125 ],
      "id_str" : "20426024",
      "id" : 20426024
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edtech",
      "indices" : [ 32, 39 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509805777406943233",
  "text" : "RT @StudyBundles: Any ideas for #edtech to assist a completely blind EFL student? Currently using SuperNova from @yourdolphin as a screen r\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dolphin Comp. Access",
        "screen_name" : "yourdolphin",
        "indices" : [ 95, 107 ],
        "id_str" : "20426024",
        "id" : 20426024
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "edtech",
        "indices" : [ 14, 21 ]
      }, {
        "text" : "eltchat",
        "indices" : [ 127, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "509805617142575104",
    "text" : "Any ideas for #edtech to assist a completely blind EFL student? Currently using SuperNova from @yourdolphin as a screen reader #eltchat",
    "id" : 509805617142575104,
    "created_at" : "2014-09-10 20:48:25 +0000",
    "user" : {
      "name" : "StudyBundles",
      "screen_name" : "StudyBundles",
      "protected" : false,
      "id_str" : "2558614093",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/649212558017196032\/77rDOMHe_normal.png",
      "id" : 2558614093,
      "verified" : false
    }
  },
  "id" : 509805777406943233,
  "created_at" : "2014-09-10 20:49:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sue Annan",
      "screen_name" : "SueAnnan",
      "indices" : [ 0, 9 ],
      "id_str" : "136001411",
      "id" : 136001411
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "audacity",
      "indices" : [ 65, 74 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 98, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/LKXHb1AEEe",
      "expanded_url" : "http:\/\/audacity.sourceforge.net\/help\/faq_i18n?s=files&i=burn-cd",
      "display_url" : "audacity.sourceforge.net\/help\/faq_i18n?\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "509804174159400960",
  "geo" : { },
  "id_str" : "509804983882383362",
  "in_reply_to_user_id" : 136001411,
  "text" : "@SueAnnan some basic tips (if that's what u r looking fo?r) from #audacity http:\/\/t.co\/LKXHb1AEEe #eltchat",
  "id" : 509804983882383362,
  "in_reply_to_status_id" : 509804174159400960,
  "created_at" : "2014-09-10 20:45:54 +0000",
  "in_reply_to_screen_name" : "SueAnnan",
  "in_reply_to_user_id_str" : "136001411",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 0, 8 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509803067643297792",
  "text" : "#eltchat Q what extent if any do issues of what happens to student data when they sign up for various language tools enter into the mix?",
  "id" : 509803067643297792,
  "created_at" : "2014-09-10 20:38:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Raine",
      "screen_name" : "paul_sensei",
      "indices" : [ 36, 48 ],
      "id_str" : "176429301",
      "id" : 176429301
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "apps4efl",
      "indices" : [ 0, 9 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 92, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/pTjQ7G7pII",
      "expanded_url" : "http:\/\/www.apps4efl.com\/",
      "display_url" : "apps4efl.com"
    } ]
  },
  "geo" : { },
  "id_str" : "509799640833982468",
  "text" : "#apps4efl http:\/\/t.co\/pTjQ7G7pII by @paul_sensei is worth checking even if it is still beta #eltchat",
  "id" : 509799640833982468,
  "created_at" : "2014-09-10 20:24:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 0, 8 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509795712528572416",
  "text" : "#eltchat hi all will mainly be lurking",
  "id" : 509795712528572416,
  "created_at" : "2014-09-10 20:09:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Phelps",
      "screen_name" : "pterolaur",
      "indices" : [ 0, 10 ],
      "id_str" : "90093887",
      "id" : 90093887
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BNCspoken",
      "indices" : [ 21, 31 ]
    }, {
      "text" : "corpus",
      "indices" : [ 32, 39 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "509727418719150080",
  "geo" : { },
  "id_str" : "509728843171917825",
  "in_reply_to_user_id" : 90093887,
  "text" : "@pterolaur nice post #BNCspoken #corpus even if somewhat outdated 1 way to get \"authentic\" listenings that can be searched by keywords",
  "id" : 509728843171917825,
  "in_reply_to_status_id" : 509727418719150080,
  "created_at" : "2014-09-10 15:43:21 +0000",
  "in_reply_to_screen_name" : "pterolaur",
  "in_reply_to_user_id_str" : "90093887",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 142 ],
      "url" : "http:\/\/t.co\/QxoR5id9ve",
      "expanded_url" : "http:\/\/learnercenteredteaching.wordpress.com\/articles-and-books\/evaluating-teacher-effectiveness-%E2%80%94research-summary\/",
      "display_url" : "learnercenteredteaching.wordpress.com\/articles-and-b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "509727116158853121",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl wow &gt;2000 studies 80yrs! did u read them all? :) btw is this post out of date regarding what u said in video? http:\/\/t.co\/QxoR5id9ve",
  "id" : 509727116158853121,
  "created_at" : "2014-09-10 15:36:29 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 102, 112 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/sg04DR6GFh",
      "expanded_url" : "http:\/\/members5.boardhost.com\/medialens\/msg\/1410360966.html",
      "display_url" : "members5.boardhost.com\/medialens\/msg\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "509723329855762432",
  "text" : "Devastating comments from ex-Reuters bureau chief in Iraq on role of media http:\/\/t.co\/sg04DR6GFh via @medialens",
  "id" : 509723329855762432,
  "created_at" : "2014-09-10 15:21:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roseli Serra",
      "screen_name" : "SerraRoseli",
      "indices" : [ 0, 12 ],
      "id_str" : "387102854",
      "id" : 387102854
    }, {
      "name" : "Kieran Donaghy",
      "screen_name" : "kierandonaghy",
      "indices" : [ 13, 27 ],
      "id_str" : "135272434",
      "id" : 135272434
    }, {
      "name" : "stevemuir",
      "screen_name" : "steve_muir",
      "indices" : [ 70, 81 ],
      "id_str" : "18537988",
      "id" : 18537988
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/8fQsM1lDWV",
      "expanded_url" : "http:\/\/allatc.wordpress.com\/tag\/mobile\/",
      "display_url" : "allatc.wordpress.com\/tag\/mobile\/"
    } ]
  },
  "in_reply_to_status_id_str" : "509720219494154240",
  "geo" : { },
  "id_str" : "509722009514020865",
  "in_reply_to_user_id" : 387102854,
  "text" : "@SerraRoseli @kierandonaghy very similar to http:\/\/t.co\/8fQsM1lDWV by @steve_muir &amp; allatC? must the spanish air :)",
  "id" : 509722009514020865,
  "in_reply_to_status_id" : 509720219494154240,
  "created_at" : "2014-09-10 15:16:11 +0000",
  "in_reply_to_screen_name" : "SerraRoseli",
  "in_reply_to_user_id_str" : "387102854",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "indices" : [ 3, 19 ],
      "id_str" : "1326508478",
      "id" : 1326508478
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 124, 140 ],
      "url" : "http:\/\/t.co\/kPfvJXeGrG",
      "expanded_url" : "http:\/\/cass.lancs.ac.uk\/?p=1397",
      "display_url" : "cass.lancs.ac.uk\/?p=1397"
    } ]
  },
  "geo" : { },
  "id_str" : "509719049149087744",
  "text" : "RT @CorpusSocialSci: Introducing the Corpus of Translational English (COTE), one million words of translated English texts: http:\/\/t.co\/kPf\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/kPfvJXeGrG",
        "expanded_url" : "http:\/\/cass.lancs.ac.uk\/?p=1397",
        "display_url" : "cass.lancs.ac.uk\/?p=1397"
      } ]
    },
    "geo" : { },
    "id_str" : "509708612974166016",
    "text" : "Introducing the Corpus of Translational English (COTE), one million words of translated English texts: http:\/\/t.co\/kPfvJXeGrG",
    "id" : 509708612974166016,
    "created_at" : "2014-09-10 14:22:57 +0000",
    "user" : {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "protected" : false,
      "id_str" : "1326508478",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3493899777\/ced36fe15c32eb911cbe3d64377524dc_normal.jpeg",
      "id" : 1326508478,
      "verified" : false
    }
  },
  "id" : 509719049149087744,
  "created_at" : "2014-09-10 15:04:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PirateBox",
      "indices" : [ 12, 22 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 45, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/HTQFZgRchd",
      "expanded_url" : "http:\/\/eflnotes.wordpress.com\/2012\/06\/01\/piratebox-a-way-to-share-files-in-class\/#update5",
      "display_url" : "eflnotes.wordpress.com\/2012\/06\/01\/pir\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "509703922173620224",
  "text" : "update 5 on #PirateBox in time for tonight's #eltchat http:\/\/t.co\/HTQFZgRchd",
  "id" : 509703922173620224,
  "created_at" : "2014-09-10 14:04:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "indices" : [ 3, 15 ],
      "id_str" : "849729062",
      "id" : 849729062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/agi4f57YRw",
      "expanded_url" : "http:\/\/tinyurl.com\/mkrngzc",
      "display_url" : "tinyurl.com\/mkrngzc"
    } ]
  },
  "geo" : { },
  "id_str" : "509669438078337024",
  "text" : "RT @TonyMcEnery: Language Matters! A free event in central London, 4\/11\/14, looking at the impact of language on society. Details at: http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/agi4f57YRw",
        "expanded_url" : "http:\/\/tinyurl.com\/mkrngzc",
        "display_url" : "tinyurl.com\/mkrngzc"
      } ]
    },
    "geo" : { },
    "id_str" : "509657590012596224",
    "text" : "Language Matters! A free event in central London, 4\/11\/14, looking at the impact of language on society. Details at: http:\/\/t.co\/agi4f57YRw",
    "id" : 509657590012596224,
    "created_at" : "2014-09-10 11:00:13 +0000",
    "user" : {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "protected" : false,
      "id_str" : "849729062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2676020930\/a4a1f40d56b447c9dfca1d7b9be4f4b4_normal.jpeg",
      "id" : 849729062,
      "verified" : false
    }
  },
  "id" : 509669438078337024,
  "created_at" : "2014-09-10 11:47:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "teacherbandnames",
      "indices" : [ 24, 41 ]
    }, {
      "text" : "againnotreallyaband",
      "indices" : [ 42, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509523957981409281",
  "text" : "Kenny Loggins Forgotten #teacherbandnames #againnotreallyaband",
  "id" : 509523957981409281,
  "created_at" : "2014-09-10 02:09:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "teacherbandnames",
      "indices" : [ 26, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509522098214424576",
  "text" : "The Last Minute Buzzcocks #teacherbandnames",
  "id" : 509522098214424576,
  "created_at" : "2014-09-10 02:01:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "teacherbandnames",
      "indices" : [ 30, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509521189317115904",
  "text" : "Bad(adaptive learning)Company #teacherbandnames",
  "id" : 509521189317115904,
  "created_at" : "2014-09-10 01:58:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "teacherbandnames",
      "indices" : [ 24, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509520667805773824",
  "text" : "Zodiac Knewton Mindwarp #teacherbandnames",
  "id" : 509520667805773824,
  "created_at" : "2014-09-10 01:56:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "teacherbandnames",
      "indices" : [ 14, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509518401493270530",
  "text" : "The Clashroom #teacherbandnames",
  "id" : 509518401493270530,
  "created_at" : "2014-09-10 01:47:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "teacherbandnames",
      "indices" : [ 26, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509517931529895937",
  "text" : "Massive Enrollment Attack #teacherbandnames",
  "id" : 509517931529895937,
  "created_at" : "2014-09-10 01:45:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "teacherbandnames",
      "indices" : [ 5, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509516952281579521",
  "text" : "MCQ5 #teacherbandnames",
  "id" : 509516952281579521,
  "created_at" : "2014-09-10 01:41:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "teacherbandnames",
      "indices" : [ 35, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509516208555966464",
  "text" : "No extensions to Deadline Kennedys #teacherbandnames",
  "id" : 509516208555966464,
  "created_at" : "2014-09-10 01:38:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "teacherbandnames",
      "indices" : [ 15, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509512058359271424",
  "text" : "The Black IWBs #teacherbandnames",
  "id" : 509512058359271424,
  "created_at" : "2014-09-10 01:21:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "teacherbandnames",
      "indices" : [ 17, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509511045011226625",
  "text" : "The Moodle Blues #teacherbandnames",
  "id" : 509511045011226625,
  "created_at" : "2014-09-10 01:17:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "teacherbandnames",
      "indices" : [ 19, 36 ]
    }, {
      "text" : "wellnottechnicalyaband",
      "indices" : [ 37, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509509970162106368",
  "text" : "Eddi Graded Reader #teacherbandnames #wellnottechnicalyaband",
  "id" : 509509970162106368,
  "created_at" : "2014-09-10 01:13:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "teacherbandnames",
      "indices" : [ 19, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509508934500372480",
  "text" : "The Sex Ed Pistols #teacherbandnames",
  "id" : 509508934500372480,
  "created_at" : "2014-09-10 01:09:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "teacherbandnames",
      "indices" : [ 12, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509506256672141313",
  "text" : "Yes and...? #teacherbandnames",
  "id" : 509506256672141313,
  "created_at" : "2014-09-10 00:58:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "teacherbandnames",
      "indices" : [ 38, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509501427329540098",
  "text" : "Pop will eat itself not your homework #teacherbandnames",
  "id" : 509501427329540098,
  "created_at" : "2014-09-10 00:39:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "teacherbandnames",
      "indices" : [ 20, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509499680875892736",
  "text" : "Art &amp; Kraftwerk #teacherbandnames",
  "id" : 509499680875892736,
  "created_at" : "2014-09-10 00:32:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "teacherbandnames",
      "indices" : [ 21, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509494535446343680",
  "text" : "Crowded School House #teacherbandnames",
  "id" : 509494535446343680,
  "created_at" : "2014-09-10 00:12:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tressie Mc",
      "screen_name" : "tressiemcphd",
      "indices" : [ 81, 94 ],
      "id_str" : "148593548",
      "id" : 148593548
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/Mc6D4FZy7h",
      "expanded_url" : "http:\/\/wp.me\/p28iGT-13l",
      "display_url" : "wp.me\/p28iGT-13l"
    } ]
  },
  "geo" : { },
  "id_str" : "509492232341041152",
  "text" : "Debbie Downerism: John Oliver and For-Profit Colleges http:\/\/t.co\/Mc6D4FZy7h via @tressiemcphd",
  "id" : 509492232341041152,
  "created_at" : "2014-09-10 00:03:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Rayson",
      "screen_name" : "perayson",
      "indices" : [ 0, 9 ],
      "id_str" : "263108959",
      "id" : 263108959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/Mna2iUEBjv",
      "expanded_url" : "https:\/\/plus.google.com\/104940199413423400545\/posts\/HF8hWXAUZfh",
      "display_url" : "plus.google.com\/10494019941342\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "509469233751674880",
  "in_reply_to_user_id" : 263108959,
  "text" : "@perayson hi net search says u have read deaf sentence david lodge? any idea of the corpora talked about in book? - https:\/\/t.co\/Mna2iUEBjv",
  "id" : 509469233751674880,
  "created_at" : "2014-09-09 22:31:45 +0000",
  "in_reply_to_screen_name" : "perayson",
  "in_reply_to_user_id_str" : "263108959",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin McKean",
      "screen_name" : "emckean",
      "indices" : [ 0, 8 ],
      "id_str" : "5380022",
      "id" : 5380022
    }, {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 9, 20 ],
      "id_str" : "300734173",
      "id" : 300734173
    }, {
      "name" : "threadbared",
      "screen_name" : "Threadbared",
      "indices" : [ 21, 33 ],
      "id_str" : "82527920",
      "id" : 82527920
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/J7Vh1nHPP8",
      "expanded_url" : "http:\/\/dh.library.yale.edu\/projects\/vogue\/#",
      "display_url" : "dh.library.yale.edu\/projects\/vogue\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "509443702377308160",
  "geo" : { },
  "id_str" : "509467400257822720",
  "in_reply_to_user_id" : 5380022,
  "text" : "@emckean @lexicoloco @Threadbared the tools on http:\/\/t.co\/J7Vh1nHPP8 are neat, thx :)",
  "id" : 509467400257822720,
  "in_reply_to_status_id" : 509443702377308160,
  "created_at" : "2014-09-09 22:24:28 +0000",
  "in_reply_to_screen_name" : "emckean",
  "in_reply_to_user_id_str" : "5380022",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lewis Lansford",
      "screen_name" : "LewisLansford",
      "indices" : [ 3, 17 ],
      "id_str" : "135942990",
      "id" : 135942990
    }, {
      "name" : "NISSLL",
      "screen_name" : "NISSLL",
      "indices" : [ 19, 26 ],
      "id_str" : "2437009058",
      "id" : 2437009058
    }, {
      "name" : "Heather Marsden",
      "screen_name" : "HeatherLMarsden",
      "indices" : [ 28, 44 ],
      "id_str" : "1513374288",
      "id" : 1513374288
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/PK7TI2ax9A",
      "expanded_url" : "http:\/\/eltjam.com\/language-testing-and-second-language-acquisition-research-worlds-apart\/",
      "display_url" : "eltjam.com\/language-testi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "509315528826298369",
  "text" : "RT @LewisLansford: @NISSLL, @HeatherLMarsden \nhttp:\/\/t.co\/PK7TI2ax9A",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NISSLL",
        "screen_name" : "NISSLL",
        "indices" : [ 0, 7 ],
        "id_str" : "2437009058",
        "id" : 2437009058
      }, {
        "name" : "Heather Marsden",
        "screen_name" : "HeatherLMarsden",
        "indices" : [ 9, 25 ],
        "id_str" : "1513374288",
        "id" : 1513374288
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 27, 49 ],
        "url" : "http:\/\/t.co\/PK7TI2ax9A",
        "expanded_url" : "http:\/\/eltjam.com\/language-testing-and-second-language-acquisition-research-worlds-apart\/",
        "display_url" : "eltjam.com\/language-testi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "509312750276055040",
    "in_reply_to_user_id" : 2437009058,
    "text" : "@NISSLL, @HeatherLMarsden \nhttp:\/\/t.co\/PK7TI2ax9A",
    "id" : 509312750276055040,
    "created_at" : "2014-09-09 12:09:56 +0000",
    "in_reply_to_screen_name" : "NISSLL",
    "in_reply_to_user_id_str" : "2437009058",
    "user" : {
      "name" : "Lewis Lansford",
      "screen_name" : "LewisLansford",
      "protected" : false,
      "id_str" : "135942990",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614500196148510720\/X8QTQwqP_normal.jpg",
      "id" : 135942990,
      "verified" : false
    }
  },
  "id" : 509315528826298369,
  "created_at" : "2014-09-09 12:20:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TESOL France",
      "screen_name" : "TESOLFrance",
      "indices" : [ 3, 15 ],
      "id_str" : "70341872",
      "id" : 70341872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/754XQmMLSz",
      "expanded_url" : "https:\/\/docs.google.com\/forms\/d\/1byg9auFnFGdmzk_iuRKN6NSGy4j8_P9DPYKFIY6rI8g\/viewform",
      "display_url" : "docs.google.com\/forms\/d\/1byg9a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "509300193163227136",
  "text" : "RT @TESOLFrance: Register for our November Colloquium now! https:\/\/t.co\/754XQmMLSz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 65 ],
        "url" : "https:\/\/t.co\/754XQmMLSz",
        "expanded_url" : "https:\/\/docs.google.com\/forms\/d\/1byg9auFnFGdmzk_iuRKN6NSGy4j8_P9DPYKFIY6rI8g\/viewform",
        "display_url" : "docs.google.com\/forms\/d\/1byg9a\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "509297270748377088",
    "text" : "Register for our November Colloquium now! https:\/\/t.co\/754XQmMLSz",
    "id" : 509297270748377088,
    "created_at" : "2014-09-09 11:08:26 +0000",
    "user" : {
      "name" : "TESOL France",
      "screen_name" : "TESOLFrance",
      "protected" : false,
      "id_str" : "70341872",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1789787647\/TESOL_France_logo_normal.jpg",
      "id" : 70341872,
      "verified" : false
    }
  },
  "id" : 509300193163227136,
  "created_at" : "2014-09-09 11:20:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clay (((Shirky)))",
      "screen_name" : "cshirky",
      "indices" : [ 61, 69 ],
      "id_str" : "6141832",
      "id" : 6141832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/V3oFNSqr3v",
      "expanded_url" : "https:\/\/medium.com\/@cshirky\/why-i-just-asked-my-students-to-put-their-laptops-away-7f5f7c50f368?source=tw-lo_dnt_8de11eabd130-1410260023293",
      "display_url" : "medium.com\/@cshirky\/why-i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "509293587826089985",
  "text" : "\u201CWhy I Just Asked My Students To Put Their Laptops Away\u2026\u201D by @cshirky https:\/\/t.co\/V3oFNSqr3v",
  "id" : 509293587826089985,
  "created_at" : "2014-09-09 10:53:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GRTV\/GlobalResearch",
      "screen_name" : "GRTVnews",
      "indices" : [ 68, 77 ],
      "id_str" : "128636277",
      "id" : 128636277
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/ijaHUBQEwN",
      "expanded_url" : "http:\/\/shar.es\/11EF5S",
      "display_url" : "shar.es\/11EF5S"
    } ]
  },
  "geo" : { },
  "id_str" : "509269171910086657",
  "text" : "Sidestepping Ukraine\u2019s \u2018N-Word\u2019 for Nazi http:\/\/t.co\/ijaHUBQEwN via @grtvnews",
  "id" : 509269171910086657,
  "created_at" : "2014-09-09 09:16:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Levine",
      "screen_name" : "cogdog",
      "indices" : [ 0, 7 ],
      "id_str" : "740343",
      "id" : 740343
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ccourses",
      "indices" : [ 89, 98 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "509117654729515008",
  "geo" : { },
  "id_str" : "509234117058519040",
  "in_reply_to_user_id" : 740343,
  "text" : "@cogdog thanks :) fargo make a refreshing change from wordpress, fantastic feed setup in #ccourses",
  "id" : 509234117058519040,
  "in_reply_to_status_id" : 509117654729515008,
  "created_at" : "2014-09-09 06:57:29 +0000",
  "in_reply_to_screen_name" : "cogdog",
  "in_reply_to_user_id_str" : "740343",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Li-Shih Huang, PhD",
      "screen_name" : "AppLingProf",
      "indices" : [ 0, 12 ],
      "id_str" : "128714685",
      "id" : 128714685
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 86, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/FYDp1bLhBI",
      "expanded_url" : "https:\/\/plus.google.com\/104940199413423400545\/posts\/1HGHyCeHMt8",
      "display_url" : "plus.google.com\/10494019941342\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "509009193668718592",
  "geo" : { },
  "id_str" : "509083935314546688",
  "in_reply_to_user_id" : 128714685,
  "text" : "@AppLingProf hi u may like some more info about initial study https:\/\/t.co\/FYDp1bLhBI #corpusmooc",
  "id" : 509083935314546688,
  "in_reply_to_status_id" : 509009193668718592,
  "created_at" : "2014-09-08 21:00:43 +0000",
  "in_reply_to_screen_name" : "AppLingProf",
  "in_reply_to_user_id_str" : "128714685",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Catherine Colin",
      "screen_name" : "Catherine_Colin",
      "indices" : [ 3, 19 ],
      "id_str" : "324881798",
      "id" : 324881798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/plvnrt48QE",
      "expanded_url" : "http:\/\/homes.chass.utoronto.ca\/~cpercy\/courses\/6361corrigan.htm",
      "display_url" : "homes.chass.utoronto.ca\/~cpercy\/course\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "508687410507833344",
  "text" : "RT @Catherine_Colin: Manuals for Teaching English as a Foreign Language in the 15th and 16th Centuries http:\/\/t.co\/plvnrt48QE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/plvnrt48QE",
        "expanded_url" : "http:\/\/homes.chass.utoronto.ca\/~cpercy\/courses\/6361corrigan.htm",
        "display_url" : "homes.chass.utoronto.ca\/~cpercy\/course\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "508668009368784896",
    "text" : "Manuals for Teaching English as a Foreign Language in the 15th and 16th Centuries http:\/\/t.co\/plvnrt48QE",
    "id" : 508668009368784896,
    "created_at" : "2014-09-07 17:27:58 +0000",
    "user" : {
      "name" : "Catherine Colin",
      "screen_name" : "Catherine_Colin",
      "protected" : false,
      "id_str" : "324881798",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/490455097910906880\/uuIwCRo8_normal.jpeg",
      "id" : 324881798,
      "verified" : false
    }
  },
  "id" : 508687410507833344,
  "created_at" : "2014-09-07 18:45:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olcay Sert",
      "screen_name" : "SertOlcay",
      "indices" : [ 0, 10 ],
      "id_str" : "1490695945",
      "id" : 1490695945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/FYDp1bLhBI",
      "expanded_url" : "https:\/\/plus.google.com\/104940199413423400545\/posts\/1HGHyCeHMt8",
      "display_url" : "plus.google.com\/10494019941342\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "508578580339884032",
  "in_reply_to_user_id" : 1490695945,
  "text" : "@SertOlcay hi this maybe of interest https:\/\/t.co\/FYDp1bLhBI",
  "id" : 508578580339884032,
  "created_at" : "2014-09-07 11:32:37 +0000",
  "in_reply_to_screen_name" : "SertOlcay",
  "in_reply_to_user_id_str" : "1490695945",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WikiLeaks",
      "screen_name" : "wikileaks",
      "indices" : [ 3, 13 ],
      "id_str" : "16589206",
      "id" : 16589206
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/m_cetera\/status\/294270587361193984\/photo\/1",
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/vsJAaeIcTG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BBV1ikPCcAAUfF4.png",
      "id_str" : "294270587365388288",
      "id" : 294270587365388288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BBV1ikPCcAAUfF4.png",
      "sizes" : [ {
        "h" : 742,
        "resize" : "fit",
        "w" : 330
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 742,
        "resize" : "fit",
        "w" : 330
      }, {
        "h" : 742,
        "resize" : "fit",
        "w" : 330
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 302
      } ],
      "display_url" : "pic.twitter.com\/vsJAaeIcTG"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/C7B9fkd6YS",
      "expanded_url" : "https:\/\/twitter.com\/m_cetera\/status\/506648050417164290",
      "display_url" : "twitter.com\/m_cetera\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "508577140951224320",
  "text" : "RT @wikileaks: How to write like the Guardian http:\/\/t.co\/vsJAaeIcTG see: https:\/\/t.co\/C7B9fkd6YS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/m_cetera\/status\/294270587361193984\/photo\/1",
        "indices" : [ 31, 53 ],
        "url" : "http:\/\/t.co\/vsJAaeIcTG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BBV1ikPCcAAUfF4.png",
        "id_str" : "294270587365388288",
        "id" : 294270587365388288,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BBV1ikPCcAAUfF4.png",
        "sizes" : [ {
          "h" : 742,
          "resize" : "fit",
          "w" : 330
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 742,
          "resize" : "fit",
          "w" : 330
        }, {
          "h" : 742,
          "resize" : "fit",
          "w" : 330
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 302
        } ],
        "display_url" : "pic.twitter.com\/vsJAaeIcTG"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 82 ],
        "url" : "https:\/\/t.co\/C7B9fkd6YS",
        "expanded_url" : "https:\/\/twitter.com\/m_cetera\/status\/506648050417164290",
        "display_url" : "twitter.com\/m_cetera\/statu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "506667316516782081",
    "text" : "How to write like the Guardian http:\/\/t.co\/vsJAaeIcTG see: https:\/\/t.co\/C7B9fkd6YS",
    "id" : 506667316516782081,
    "created_at" : "2014-09-02 04:57:56 +0000",
    "user" : {
      "name" : "WikiLeaks",
      "screen_name" : "wikileaks",
      "protected" : false,
      "id_str" : "16589206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/512138307870785536\/Fe00yVS2_normal.png",
      "id" : 16589206,
      "verified" : true
    }
  },
  "id" : 508577140951224320,
  "created_at" : "2014-09-07 11:26:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "metacode",
      "screen_name" : "metacode",
      "indices" : [ 3, 12 ],
      "id_str" : "18869909",
      "id" : 18869909
    }, {
      "name" : "Neil Clark",
      "screen_name" : "NeilClark66",
      "indices" : [ 96, 108 ],
      "id_str" : "728039605",
      "id" : 728039605
    }, {
      "name" : "RT",
      "screen_name" : "RT_com",
      "indices" : [ 110, 117 ],
      "id_str" : "64643056",
      "id" : 64643056
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/WAtztGaAUk",
      "expanded_url" : "http:\/\/rt.com\/op-edge\/185004-george-galloway-attack-dissenters\/",
      "display_url" : "rt.com\/op-edge\/185004\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "508574624951848960",
  "text" : "RT @metacode: \u2018George Galloway attack is an attack on all dissenters\u2019 http:\/\/t.co\/WAtztGaAUk by @NeilClark66 (@RT_com)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Neil Clark",
        "screen_name" : "NeilClark66",
        "indices" : [ 82, 94 ],
        "id_str" : "728039605",
        "id" : 728039605
      }, {
        "name" : "RT",
        "screen_name" : "RT_com",
        "indices" : [ 96, 103 ],
        "id_str" : "64643056",
        "id" : 64643056
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/WAtztGaAUk",
        "expanded_url" : "http:\/\/rt.com\/op-edge\/185004-george-galloway-attack-dissenters\/",
        "display_url" : "rt.com\/op-edge\/185004\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "508316195003842560",
    "text" : "\u2018George Galloway attack is an attack on all dissenters\u2019 http:\/\/t.co\/WAtztGaAUk by @NeilClark66 (@RT_com)",
    "id" : 508316195003842560,
    "created_at" : "2014-09-06 18:09:59 +0000",
    "user" : {
      "name" : "metacode",
      "screen_name" : "metacode",
      "protected" : false,
      "id_str" : "18869909",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614731325099102208\/eg_hKKZU_normal.png",
      "id" : 18869909,
      "verified" : false
    }
  },
  "id" : 508574624951848960,
  "created_at" : "2014-09-07 11:16:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donald Clark",
      "screen_name" : "DonaldClark",
      "indices" : [ 0, 12 ],
      "id_str" : "1632891",
      "id" : 1632891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "508562013661167616",
  "geo" : { },
  "id_str" : "508563390705713152",
  "in_reply_to_user_id" : 1632891,
  "text" : "@DonaldClark hehe \"liked the fact that I didn\u2019t get a hideous black canvas bag, that marked me out on the tube as a twat.\"",
  "id" : 508563390705713152,
  "in_reply_to_status_id" : 508562013661167616,
  "created_at" : "2014-09-07 10:32:15 +0000",
  "in_reply_to_screen_name" : "DonaldClark",
  "in_reply_to_user_id_str" : "1632891",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 3, 17 ],
      "id_str" : "25388528",
      "id" : 25388528
    }, {
      "name" : "Bill Fitzgerald",
      "screen_name" : "funnymonkey",
      "indices" : [ 31, 43 ],
      "id_str" : "12127972",
      "id" : 12127972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/OYgxtTcK9I",
      "expanded_url" : "http:\/\/funnymonkey.com\/blog\/brief-review-classdojo-privacy-policy-and-terms-service",
      "display_url" : "funnymonkey.com\/blog\/brief-rev\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "508561334565629952",
  "text" : "RT @audreywatters: Glad to see @funnymonkey taking a closer look at ed-tech TOS and privacy policies. Here, he looks at ClassDojo http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bill Fitzgerald",
        "screen_name" : "funnymonkey",
        "indices" : [ 12, 24 ],
        "id_str" : "12127972",
        "id" : 12127972
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/OYgxtTcK9I",
        "expanded_url" : "http:\/\/funnymonkey.com\/blog\/brief-review-classdojo-privacy-policy-and-terms-service",
        "display_url" : "funnymonkey.com\/blog\/brief-rev\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "508540454854737920",
    "text" : "Glad to see @funnymonkey taking a closer look at ed-tech TOS and privacy policies. Here, he looks at ClassDojo http:\/\/t.co\/OYgxtTcK9I",
    "id" : 508540454854737920,
    "created_at" : "2014-09-07 09:01:07 +0000",
    "user" : {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "protected" : false,
      "id_str" : "25388528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711668009723498496\/pauFZsdv_normal.jpg",
      "id" : 25388528,
      "verified" : false
    }
  },
  "id" : 508561334565629952,
  "created_at" : "2014-09-07 10:24:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 0, 10 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "508509341990019072",
  "geo" : { },
  "id_str" : "508539571798556672",
  "in_reply_to_user_id" : 6531902,
  "text" : "@medialens definitely confusing for him as he mixes up Wales with Scotland in first answer :)",
  "id" : 508539571798556672,
  "in_reply_to_status_id" : 508509341990019072,
  "created_at" : "2014-09-07 08:57:36 +0000",
  "in_reply_to_screen_name" : "medialens",
  "in_reply_to_user_id_str" : "6531902",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bella Caledonia",
      "screen_name" : "bellacaledonia",
      "indices" : [ 87, 102 ],
      "id_str" : "103554348",
      "id" : 103554348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/6bR4pOq5yd",
      "expanded_url" : "http:\/\/wp.me\/p93oK-4ga",
      "display_url" : "wp.me\/p93oK-4ga"
    } ]
  },
  "geo" : { },
  "id_str" : "508538469228888064",
  "text" : "Noam Chomsky on Scottish Independence : Statehood and Power http:\/\/t.co\/6bR4pOq5yd via @bellacaledonia",
  "id" : 508538469228888064,
  "created_at" : "2014-09-07 08:53:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "natiserhost197",
      "screen_name" : "esl_robert",
      "indices" : [ 0, 11 ],
      "id_str" : "2982357761",
      "id" : 2982357761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/Pnh3BIv7Pj",
      "expanded_url" : "http:\/\/eflnotes.wordpress.com\/tag\/cupofcoca\/",
      "display_url" : "eflnotes.wordpress.com\/tag\/cupofcoca\/"
    } ]
  },
  "in_reply_to_status_id_str" : "508247979531436032",
  "geo" : { },
  "id_str" : "508325006032785408",
  "in_reply_to_user_id" : 18526186,
  "text" : "@esl_robert u may find these of use http:\/\/t.co\/Pnh3BIv7Pj; maybe typical prescriptive usage claims? e.g. who says whom nowadays? good luck",
  "id" : 508325006032785408,
  "in_reply_to_status_id" : 508247979531436032,
  "created_at" : "2014-09-06 18:45:00 +0000",
  "in_reply_to_screen_name" : "RobertEPoole",
  "in_reply_to_user_id_str" : "18526186",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "key",
      "indices" : [ 21, 25 ]
    } ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/LC14oLCtpb",
      "expanded_url" : "http:\/\/tachesdesens.blogspot.com\/2014\/09\/key.html?spref=tw",
      "display_url" : "tachesdesens.blogspot.com\/2014\/09\/key.ht\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "508171761372766208",
  "text" : "touches of sense...: #key http:\/\/t.co\/LC14oLCtpb",
  "id" : 508171761372766208,
  "created_at" : "2014-09-06 08:36:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Intex Technologies",
      "screen_name" : "IntexBrand",
      "indices" : [ 15, 26 ],
      "id_str" : "70352000",
      "id" : 70352000
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FirefoxOS",
      "indices" : [ 45, 55 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "508006260214472704",
  "geo" : { },
  "id_str" : "508019422599323648",
  "in_reply_to_user_id" : 93828649,
  "text" : "@Firefox_tamil @IntexBrand you can multiboot #FirefoxOS on 1st gen moto g :)",
  "id" : 508019422599323648,
  "in_reply_to_status_id" : 508006260214472704,
  "created_at" : "2014-09-05 22:30:43 +0000",
  "in_reply_to_screen_name" : "AS5H0LE",
  "in_reply_to_user_id_str" : "93828649",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FirefoxOS",
      "indices" : [ 29, 39 ]
    }, {
      "text" : "android",
      "indices" : [ 47, 55 ]
    }, {
      "text" : "multiboot",
      "indices" : [ 56, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "508014542698594305",
  "text" : "kicking tires to pre-release #FirefoxOS no bad #android #multiboot",
  "id" : 508014542698594305,
  "created_at" : "2014-09-05 22:11:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Papahazama",
      "screen_name" : "papahazama",
      "indices" : [ 3, 14 ],
      "id_str" : "566964813",
      "id" : 566964813
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ccourses",
      "indices" : [ 94, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/uYh0swOdmC",
      "expanded_url" : "http:\/\/www.hackeducation.com\/2014\/09\/05\/beyond-the-lms-newcastle-university\/",
      "display_url" : "hackeducation.com\/2014\/09\/05\/bey\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "508005464576364545",
  "text" : "RT @papahazama: Why we need to go beyond the LMS.  What Audrey says...http:\/\/t.co\/uYh0swOdmC  #ccourses",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ccourses",
        "indices" : [ 78, 87 ]
      } ],
      "urls" : [ {
        "indices" : [ 54, 76 ],
        "url" : "http:\/\/t.co\/uYh0swOdmC",
        "expanded_url" : "http:\/\/www.hackeducation.com\/2014\/09\/05\/beyond-the-lms-newcastle-university\/",
        "display_url" : "hackeducation.com\/2014\/09\/05\/bey\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "507980770586013696",
    "text" : "Why we need to go beyond the LMS.  What Audrey says...http:\/\/t.co\/uYh0swOdmC  #ccourses",
    "id" : 507980770586013696,
    "created_at" : "2014-09-05 19:57:08 +0000",
    "user" : {
      "name" : "Papahazama",
      "screen_name" : "papahazama",
      "protected" : false,
      "id_str" : "566964813",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2422464879\/92lynsysmrtlsasxan5m_normal.jpeg",
      "id" : 566964813,
      "verified" : false
    }
  },
  "id" : 508005464576364545,
  "created_at" : "2014-09-05 21:35:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/PRx8BMCtcm",
      "expanded_url" : "http:\/\/www.alternet.org\/books\/arundhati-roy-how-corporate-power-converted-wealth-philanthropy-social-control",
      "display_url" : "alternet.org\/books\/arundhat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "507904758682632193",
  "text" : "Arundhati Roy: How Corporate Power Converted Wealth Into Philanthropy for Social Control | Alternet http:\/\/t.co\/PRx8BMCtcm",
  "id" : 507904758682632193,
  "created_at" : "2014-09-05 14:55:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "indices" : [ 0, 13 ],
      "id_str" : "1685397408",
      "id" : 1685397408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "507882862230917120",
  "geo" : { },
  "id_str" : "507883944013225984",
  "in_reply_to_user_id" : 1685397408,
  "text" : "@harrisonmike taken after u told him it needs more cowbell? :)",
  "id" : 507883944013225984,
  "in_reply_to_status_id" : 507882862230917120,
  "created_at" : "2014-09-05 13:32:22 +0000",
  "in_reply_to_screen_name" : "harrisonmike",
  "in_reply_to_user_id_str" : "1685397408",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oxford Journals",
      "screen_name" : "OxfordJournals",
      "indices" : [ 3, 18 ],
      "id_str" : "41569866",
      "id" : 41569866
    }, {
      "name" : "IATEFL ReSIG",
      "screen_name" : "IATEFLResig",
      "indices" : [ 31, 43 ],
      "id_str" : "335823604",
      "id" : 335823604
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 128, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/Vm8Mi5l8ei",
      "expanded_url" : "http:\/\/youtu.be\/Hh33hQEiRjo",
      "display_url" : "youtu.be\/Hh33hQEiRjo"
    } ]
  },
  "geo" : { },
  "id_str" : "507879163248648192",
  "text" : "MT @OxfordJournals Joining the @IATEFLResig SIG discussion 7-21 Sept? Watch authors Unpackaging the Past http:\/\/t.co\/Vm8Mi5l8ei #corpusmooc",
  "id" : 507879163248648192,
  "created_at" : "2014-09-05 13:13:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WISE Up Wales",
      "screen_name" : "WISEUpWales",
      "indices" : [ 3, 15 ],
      "id_str" : "570249991",
      "id" : 570249991
    }, {
      "name" : "WISE Up Action",
      "screen_name" : "WISEUpAction",
      "indices" : [ 101, 114 ],
      "id_str" : "568601988",
      "id" : 568601988
    }, {
      "name" : "Antiwar.com",
      "screen_name" : "Antiwarcom",
      "indices" : [ 115, 126 ],
      "id_str" : "15503210",
      "id" : 15503210
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WISEUpWales\/status\/507837770945941506\/photo\/1",
      "indices" : [ 127, 140 ],
      "url" : "http:\/\/t.co\/23p3snD33l",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BwwzwqNCcAAywP5.jpg",
      "id_str" : "507837769041735680",
      "id" : 507837769041735680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwwzwqNCcAAywP5.jpg",
      "sizes" : [ {
        "h" : 505,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 669,
        "resize" : "fit",
        "w" : 450
      }, {
        "h" : 669,
        "resize" : "fit",
        "w" : 450
      }, {
        "h" : 669,
        "resize" : "fit",
        "w" : 450
      } ],
      "display_url" : "pic.twitter.com\/23p3snD33l"
    } ],
    "hashtags" : [ {
      "text" : "NATO",
      "indices" : [ 24, 29 ]
    }, {
      "text" : "Manning",
      "indices" : [ 58, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "507868727161802753",
  "text" : "RT @WISEUpWales: Arrest #NATO war criminals.\nFree Chelsea #Manning.\n\nChalking in Newport yesterday.\n\n@WISEUpAction\n@Antiwarcom http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "WISE Up Action",
        "screen_name" : "WISEUpAction",
        "indices" : [ 84, 97 ],
        "id_str" : "568601988",
        "id" : 568601988
      }, {
        "name" : "Antiwar.com",
        "screen_name" : "Antiwarcom",
        "indices" : [ 98, 109 ],
        "id_str" : "15503210",
        "id" : 15503210
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/WISEUpWales\/status\/507837770945941506\/photo\/1",
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/23p3snD33l",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BwwzwqNCcAAywP5.jpg",
        "id_str" : "507837769041735680",
        "id" : 507837769041735680,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwwzwqNCcAAywP5.jpg",
        "sizes" : [ {
          "h" : 505,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 669,
          "resize" : "fit",
          "w" : 450
        }, {
          "h" : 669,
          "resize" : "fit",
          "w" : 450
        }, {
          "h" : 669,
          "resize" : "fit",
          "w" : 450
        } ],
        "display_url" : "pic.twitter.com\/23p3snD33l"
      } ],
      "hashtags" : [ {
        "text" : "NATO",
        "indices" : [ 7, 12 ]
      }, {
        "text" : "Manning",
        "indices" : [ 41, 49 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "507837770945941506",
    "text" : "Arrest #NATO war criminals.\nFree Chelsea #Manning.\n\nChalking in Newport yesterday.\n\n@WISEUpAction\n@Antiwarcom http:\/\/t.co\/23p3snD33l",
    "id" : 507837770945941506,
    "created_at" : "2014-09-05 10:28:54 +0000",
    "user" : {
      "name" : "WISE Up Wales",
      "screen_name" : "WISEUpWales",
      "protected" : false,
      "id_str" : "570249991",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/578583503727681536\/o-hDgGBM_normal.png",
      "id" : 570249991,
      "verified" : false
    }
  },
  "id" : 507868727161802753,
  "created_at" : "2014-09-05 12:31:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Raine",
      "screen_name" : "paul_sensei",
      "indices" : [ 3, 15 ],
      "id_str" : "176429301",
      "id" : 176429301
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "langchat",
      "indices" : [ 129, 138 ]
    }, {
      "text" : "efl",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "esl",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "tefl",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/56UjPYZHkw",
      "expanded_url" : "http:\/\/apps4efl.com",
      "display_url" : "apps4efl.com"
    } ]
  },
  "geo" : { },
  "id_str" : "507644255808942080",
  "text" : "RT @paul_sensei: I am delighted to announce my new venture, http:\/\/t.co\/56UjPYZHkw: free web-apps for English language learners! #langchat \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "langchat",
        "indices" : [ 112, 121 ]
      }, {
        "text" : "efl",
        "indices" : [ 122, 126 ]
      }, {
        "text" : "esl",
        "indices" : [ 127, 131 ]
      }, {
        "text" : "tefl",
        "indices" : [ 132, 137 ]
      } ],
      "urls" : [ {
        "indices" : [ 43, 65 ],
        "url" : "http:\/\/t.co\/56UjPYZHkw",
        "expanded_url" : "http:\/\/apps4efl.com",
        "display_url" : "apps4efl.com"
      } ]
    },
    "geo" : { },
    "id_str" : "506865884208844800",
    "text" : "I am delighted to announce my new venture, http:\/\/t.co\/56UjPYZHkw: free web-apps for English language learners! #langchat #efl #esl #tefl",
    "id" : 506865884208844800,
    "created_at" : "2014-09-02 18:06:58 +0000",
    "user" : {
      "name" : "Paul Raine",
      "screen_name" : "paul_sensei",
      "protected" : false,
      "id_str" : "176429301",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666950419248259073\/T7XVTUac_normal.jpg",
      "id" : 176429301,
      "verified" : false
    }
  },
  "id" : 507644255808942080,
  "created_at" : "2014-09-04 21:39:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Siva Vaidhyanathan",
      "screen_name" : "sivavaid",
      "indices" : [ 3, 12 ],
      "id_str" : "20406724",
      "id" : 20406724
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/LMYi58sm0Y",
      "expanded_url" : "http:\/\/www.texasobserver.org\/walter-stroup-standardized-testing-pearson\/#.VAhHdPgj8E4.twitter",
      "display_url" : "texasobserver.org\/walter-stroup-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "507620189081317376",
  "text" : "RT @sivavaid: A Prof Debunks Standardized Testing &amp; Pearson Strikes Back: http:\/\/t.co\/LMYi58sm0Y",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/LMYi58sm0Y",
        "expanded_url" : "http:\/\/www.texasobserver.org\/walter-stroup-standardized-testing-pearson\/#.VAhHdPgj8E4.twitter",
        "display_url" : "texasobserver.org\/walter-stroup-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "507486893219381248",
    "text" : "A Prof Debunks Standardized Testing &amp; Pearson Strikes Back: http:\/\/t.co\/LMYi58sm0Y",
    "id" : 507486893219381248,
    "created_at" : "2014-09-04 11:14:38 +0000",
    "user" : {
      "name" : "Siva Vaidhyanathan",
      "screen_name" : "sivavaid",
      "protected" : false,
      "id_str" : "20406724",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/767792599050649600\/aaiFpS9e_normal.jpg",
      "id" : 20406724,
      "verified" : false
    }
  },
  "id" : 507620189081317376,
  "created_at" : "2014-09-04 20:04:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark J Doran",
      "screen_name" : "MarkJDoran",
      "indices" : [ 3, 14 ],
      "id_str" : "19364252",
      "id" : 19364252
    }, {
      "name" : "Marcus Edwards",
      "screen_name" : "c4marcus",
      "indices" : [ 17, 26 ],
      "id_str" : "95973642",
      "id" : 95973642
    }, {
      "name" : "Channel 4 News",
      "screen_name" : "Channel4News",
      "indices" : [ 27, 40 ],
      "id_str" : "14569869",
      "id" : 14569869
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NATOSummitUK",
      "indices" : [ 122, 135 ]
    }, {
      "text" : "natowales",
      "indices" : [ 136, 140 ]
    }, {
      "text" : "c4news",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "507509456125825024",
  "text" : "RT @MarkJDoran: .@c4marcus @Channel4News An amazing set of defences! That stuff will *definitely* keep the terrorists in. #NATOSummitUK #na\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Marcus Edwards",
        "screen_name" : "c4marcus",
        "indices" : [ 1, 10 ],
        "id_str" : "95973642",
        "id" : 95973642
      }, {
        "name" : "Channel 4 News",
        "screen_name" : "Channel4News",
        "indices" : [ 11, 24 ],
        "id_str" : "14569869",
        "id" : 14569869
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NATOSummitUK",
        "indices" : [ 106, 119 ]
      }, {
        "text" : "natowales",
        "indices" : [ 120, 130 ]
      }, {
        "text" : "c4news",
        "indices" : [ 131, 138 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "507450072897167360",
    "geo" : { },
    "id_str" : "507456433735360512",
    "in_reply_to_user_id" : 95973642,
    "text" : ".@c4marcus @Channel4News An amazing set of defences! That stuff will *definitely* keep the terrorists in. #NATOSummitUK #natowales #c4news",
    "id" : 507456433735360512,
    "in_reply_to_status_id" : 507450072897167360,
    "created_at" : "2014-09-04 09:13:36 +0000",
    "in_reply_to_screen_name" : "c4marcus",
    "in_reply_to_user_id_str" : "95973642",
    "user" : {
      "name" : "Mark J Doran",
      "screen_name" : "MarkJDoran",
      "protected" : false,
      "id_str" : "19364252",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747220190887239680\/1sS-3xVw_normal.jpg",
      "id" : 19364252,
      "verified" : false
    }
  },
  "id" : 507509456125825024,
  "created_at" : "2014-09-04 12:44:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/xo3QjoaRX0",
      "expanded_url" : "http:\/\/www.theguardian.com\/commentisfree\/2014\/sep\/03\/nato-peace-threat-ukraine-military-conflict",
      "display_url" : "theguardian.com\/commentisfree\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "507509180430045184",
  "text" : "RT @medialens: Excellent from Seumas Milne: 'Instead of keeping the peace, Nato has been the cause of escalating tension and war' http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/xo3QjoaRX0",
        "expanded_url" : "http:\/\/www.theguardian.com\/commentisfree\/2014\/sep\/03\/nato-peace-threat-ukraine-military-conflict",
        "display_url" : "theguardian.com\/commentisfree\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "507463219712376832",
    "text" : "Excellent from Seumas Milne: 'Instead of keeping the peace, Nato has been the cause of escalating tension and war' http:\/\/t.co\/xo3QjoaRX0",
    "id" : 507463219712376832,
    "created_at" : "2014-09-04 09:40:34 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 507509180430045184,
  "created_at" : "2014-09-04 12:43:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ccourses",
      "indices" : [ 0, 9 ]
    } ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/EX6oyb4a2U",
      "expanded_url" : "http:\/\/connectedcoursesbymura.smallpict.com\/2014\/09\/04\/connectedCoursesIntroPost.html",
      "display_url" : "connectedcoursesbymura.smallpict.com\/2014\/09\/04\/con\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "507493802123464705",
  "text" : "#ccourses intro post http:\/\/t.co\/EX6oyb4a2U",
  "id" : 507493802123464705,
  "created_at" : "2014-09-04 11:42:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thesaurusland",
      "indices" : [ 9, 23 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 47, 55 ]
    }, {
      "text" : "efl",
      "indices" : [ 56, 60 ]
    }, {
      "text" : "esl",
      "indices" : [ 61, 65 ]
    }, {
      "text" : "tefl",
      "indices" : [ 66, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/IkKadsv303",
      "expanded_url" : "http:\/\/thesaurus.land\/",
      "display_url" : "thesaurus.land"
    } ]
  },
  "geo" : { },
  "id_str" : "507473703085830144",
  "text" : "fun tool #thesaurusland http:\/\/t.co\/IkKadsv303 #eltchat #efl #esl #tefl",
  "id" : 507473703085830144,
  "created_at" : "2014-09-04 10:22:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Harbinson",
      "screen_name" : "DavidHarbinson",
      "indices" : [ 0, 15 ],
      "id_str" : "853078675",
      "id" : 853078675
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/cMpT9uJIQh",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=cX8szNPgrEs",
      "display_url" : "youtube.com\/watch?v=cX8szN\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "507402514564521984",
  "geo" : { },
  "id_str" : "507406635170803712",
  "in_reply_to_user_id" : 853078675,
  "text" : "@DavidHarbinson for some reason was hearing this in background when watching this https:\/\/t.co\/cMpT9uJIQh :\/",
  "id" : 507406635170803712,
  "in_reply_to_status_id" : 507402514564521984,
  "created_at" : "2014-09-04 05:55:43 +0000",
  "in_reply_to_screen_name" : "DavidHarbinson",
  "in_reply_to_user_id_str" : "853078675",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George Galloway",
      "screen_name" : "georgegalloway",
      "indices" : [ 3, 18 ],
      "id_str" : "15484198",
      "id" : 15484198
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "507403050420805634",
  "text" : "RT @georgegalloway: Labour leader Miliband just passed me, struggling on the stairs with my walking stick, looked straight at me and walked\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "507163741230997505",
    "text" : "Labour leader Miliband just passed me, struggling on the stairs with my walking stick, looked straight at me and walked on without a word...",
    "id" : 507163741230997505,
    "created_at" : "2014-09-03 13:50:33 +0000",
    "user" : {
      "name" : "George Galloway",
      "screen_name" : "georgegalloway",
      "protected" : false,
      "id_str" : "15484198",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746211361793802244\/cMbIcHMP_normal.jpg",
      "id" : 15484198,
      "verified" : true
    }
  },
  "id" : 507403050420805634,
  "created_at" : "2014-09-04 05:41:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Claire Hardaker",
      "screen_name" : "DrClaireH",
      "indices" : [ 3, 13 ],
      "id_str" : "237842162",
      "id" : 237842162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/leVyqAx5BF",
      "expanded_url" : "http:\/\/wse1.webcorp.org.uk\/home\/",
      "display_url" : "wse1.webcorp.org.uk\/home\/"
    } ]
  },
  "geo" : { },
  "id_str" : "507264946137481216",
  "text" : "RT @DrClaireH: If you like readymade corpora, try WebCorp Linguist's Search Engine for studying language on the web. http:\/\/t.co\/leVyqAx5BF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/leVyqAx5BF",
        "expanded_url" : "http:\/\/wse1.webcorp.org.uk\/home\/",
        "display_url" : "wse1.webcorp.org.uk\/home\/"
      } ]
    },
    "in_reply_to_status_id_str" : "345886209597399041",
    "geo" : { },
    "id_str" : "507242477238386689",
    "in_reply_to_user_id" : 237842162,
    "text" : "If you like readymade corpora, try WebCorp Linguist's Search Engine for studying language on the web. http:\/\/t.co\/leVyqAx5BF",
    "id" : 507242477238386689,
    "in_reply_to_status_id" : 345886209597399041,
    "created_at" : "2014-09-03 19:03:25 +0000",
    "in_reply_to_screen_name" : "DrClaireH",
    "in_reply_to_user_id_str" : "237842162",
    "user" : {
      "name" : "Dr Claire Hardaker",
      "screen_name" : "DrClaireH",
      "protected" : false,
      "id_str" : "237842162",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744470254177390592\/ZhYTy0JE_normal.jpg",
      "id" : 237842162,
      "verified" : false
    }
  },
  "id" : 507264946137481216,
  "created_at" : "2014-09-03 20:32:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "indices" : [ 3, 14 ],
      "id_str" : "87902543",
      "id" : 87902543
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kenrobinson",
      "indices" : [ 88, 100 ]
    }, {
      "text" : "luddite",
      "indices" : [ 103, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 125, 140 ],
      "url" : "http:\/\/t.co\/6yo3AgPJez",
      "expanded_url" : "http:\/\/bit.ly\/1tsLLEt",
      "display_url" : "bit.ly\/1tsLLEt"
    } ]
  },
  "geo" : { },
  "id_str" : "507099979622924288",
  "text" : "RT @tornhalves: Sir Ken Robinson and the Luddites oppose the tyranny of industry. So is #kenrobinson a #luddite? Our answer. http:\/\/t.co\/6y\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "kenrobinson",
        "indices" : [ 72, 84 ]
      }, {
        "text" : "luddite",
        "indices" : [ 87, 95 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/6yo3AgPJez",
        "expanded_url" : "http:\/\/bit.ly\/1tsLLEt",
        "display_url" : "bit.ly\/1tsLLEt"
      } ]
    },
    "geo" : { },
    "id_str" : "507088473657200640",
    "text" : "Sir Ken Robinson and the Luddites oppose the tyranny of industry. So is #kenrobinson a #luddite? Our answer. http:\/\/t.co\/6yo3AgPJez",
    "id" : 507088473657200640,
    "created_at" : "2014-09-03 08:51:28 +0000",
    "user" : {
      "name" : "Torn Halves",
      "screen_name" : "tornhalves",
      "protected" : false,
      "id_str" : "87902543",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3059742703\/1d3c7a2052db17d29644fa0a49af6480_normal.jpeg",
      "id" : 87902543,
      "verified" : false
    }
  },
  "id" : 507099979622924288,
  "created_at" : "2014-09-03 09:37:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Hawksey",
      "screen_name" : "mhawksey",
      "indices" : [ 3, 12 ],
      "id_str" : "13046992",
      "id" : 13046992
    }, {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 43, 57 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/0Sq99LWsKv",
      "expanded_url" : "http:\/\/altc.alt.ac.uk\/conference\/2014\/sessions\/keynote-speech-from-audrey-watters-703\/",
      "display_url" : "altc.alt.ac.uk\/conference\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "507084535423840256",
  "text" : "RT @mhawksey: LIVE NOW Keynote speech from @audreywatters \u2013 Ed-Tech, Frankenstein\u2019s Monster, and Teacher Machines (703) http:\/\/t.co\/0Sq99LW\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Audrey Watters",
        "screen_name" : "audreywatters",
        "indices" : [ 29, 43 ],
        "id_str" : "25388528",
        "id" : 25388528
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/0Sq99LWsKv",
        "expanded_url" : "http:\/\/altc.alt.ac.uk\/conference\/2014\/sessions\/keynote-speech-from-audrey-watters-703\/",
        "display_url" : "altc.alt.ac.uk\/conference\/201\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "507082897925619712",
    "text" : "LIVE NOW Keynote speech from @audreywatters \u2013 Ed-Tech, Frankenstein\u2019s Monster, and Teacher Machines (703) http:\/\/t.co\/0Sq99LWsKv",
    "id" : 507082897925619712,
    "created_at" : "2014-09-03 08:29:18 +0000",
    "user" : {
      "name" : "Martin Hawksey",
      "screen_name" : "mhawksey",
      "protected" : false,
      "id_str" : "13046992",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2390851993\/xu6aptqy6a8rb2h2w5by_normal.jpeg",
      "id" : 13046992,
      "verified" : false
    }
  },
  "id" : 507084535423840256,
  "created_at" : "2014-09-03 08:35:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/pkEWTYg5Gj",
      "expanded_url" : "http:\/\/www.informationisbeautiful.net\/visualizations\/worlds-biggest-data-breaches-hacks\/static\/",
      "display_url" : "informationisbeautiful.net\/visualizations\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "506899741267853312",
  "text" : "World's Biggest Data Breaches - Static | Information Is Beautiful http:\/\/t.co\/pkEWTYg5Gj",
  "id" : 506899741267853312,
  "created_at" : "2014-09-02 20:21:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AcademiaEFL",
      "screen_name" : "AcademiaEFL",
      "indices" : [ 3, 15 ],
      "id_str" : "1268461357",
      "id" : 1268461357
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/cbwsBuUKoy",
      "expanded_url" : "http:\/\/schoolingtheworld.org\/altedfilmfest\/",
      "display_url" : "schoolingtheworld.org\/altedfilmfest\/"
    } ]
  },
  "geo" : { },
  "id_str" : "506799323515224064",
  "text" : "RT @AcademiaEFL: Schooling the World, an interesting documentary film exploring education, imperialism, and culture. http:\/\/t.co\/cbwsBuUKoy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/cbwsBuUKoy",
        "expanded_url" : "http:\/\/schoolingtheworld.org\/altedfilmfest\/",
        "display_url" : "schoolingtheworld.org\/altedfilmfest\/"
      } ]
    },
    "geo" : { },
    "id_str" : "506795198001582080",
    "text" : "Schooling the World, an interesting documentary film exploring education, imperialism, and culture. http:\/\/t.co\/cbwsBuUKoy",
    "id" : 506795198001582080,
    "created_at" : "2014-09-02 13:26:05 +0000",
    "user" : {
      "name" : "AcademiaEFL",
      "screen_name" : "AcademiaEFL",
      "protected" : false,
      "id_str" : "1268461357",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3381047434\/5a384376af819a37168cd3c873aca084_normal.jpeg",
      "id" : 1268461357,
      "verified" : false
    }
  },
  "id" : 506799323515224064,
  "created_at" : "2014-09-02 13:42:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AcademiaEFL",
      "screen_name" : "AcademiaEFL",
      "indices" : [ 0, 12 ],
      "id_str" : "1268461357",
      "id" : 1268461357
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "506795198001582080",
  "geo" : { },
  "id_str" : "506796632982421504",
  "in_reply_to_user_id" : 1268461357,
  "text" : "@AcademiaEFL the subtitle is on point \"the whiteman's last burden\"",
  "id" : 506796632982421504,
  "in_reply_to_status_id" : 506795198001582080,
  "created_at" : "2014-09-02 13:31:47 +0000",
  "in_reply_to_screen_name" : "AcademiaEFL",
  "in_reply_to_user_id_str" : "1268461357",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "506792185191092224",
  "geo" : { },
  "id_str" : "506794551181598720",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin need keep healthy skepticism of corporate tech, who knows in the future there could well be public funded social media :)",
  "id" : 506794551181598720,
  "in_reply_to_status_id" : 506792185191092224,
  "created_at" : "2014-09-02 13:23:31 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "506781672549785600",
  "geo" : { },
  "id_str" : "506791712585691136",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin why? do u think  twitter is eating itself? :\/",
  "id" : 506791712585691136,
  "in_reply_to_status_id" : 506781672549785600,
  "created_at" : "2014-09-02 13:12:14 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "indices" : [ 0, 11 ],
      "id_str" : "152051625",
      "id" : 152051625
    }, {
      "name" : "Joe McVeigh",
      "screen_name" : "EvilJoeMcVeigh",
      "indices" : [ 12, 27 ],
      "id_str" : "1327355143",
      "id" : 1327355143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "506728266237894656",
  "geo" : { },
  "id_str" : "506734078469885952",
  "in_reply_to_user_id" : 152051625,
  "text" : "@heatherfro @EvilJoeMcVeigh could foolish be synonymous with mad for that time period?",
  "id" : 506734078469885952,
  "in_reply_to_status_id" : 506728266237894656,
  "created_at" : "2014-09-02 09:23:13 +0000",
  "in_reply_to_screen_name" : "heatherfro",
  "in_reply_to_user_id_str" : "152051625",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corpora Journal",
      "screen_name" : "CorporaJournal",
      "indices" : [ 3, 18 ],
      "id_str" : "2340183050",
      "id" : 2340183050
    }, {
      "name" : "Corpora Journal",
      "screen_name" : "CorporaJournal",
      "indices" : [ 75, 90 ],
      "id_str" : "2340183050",
      "id" : 2340183050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/0VVtYJ67b0",
      "expanded_url" : "http:\/\/tinyurl.com\/ndvex7z",
      "display_url" : "tinyurl.com\/ndvex7z"
    } ]
  },
  "geo" : { },
  "id_str" : "506726288233869312",
  "text" : "RT @CorporaJournal: This just in! We have a new full, free sample issue of @CorporaJournal (Volume 8 Issue 1, 2013) on our website! http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Corpora Journal",
        "screen_name" : "CorporaJournal",
        "indices" : [ 55, 70 ],
        "id_str" : "2340183050",
        "id" : 2340183050
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/0VVtYJ67b0",
        "expanded_url" : "http:\/\/tinyurl.com\/ndvex7z",
        "display_url" : "tinyurl.com\/ndvex7z"
      } ]
    },
    "geo" : { },
    "id_str" : "506724839462567936",
    "text" : "This just in! We have a new full, free sample issue of @CorporaJournal (Volume 8 Issue 1, 2013) on our website! http:\/\/t.co\/0VVtYJ67b0",
    "id" : 506724839462567936,
    "created_at" : "2014-09-02 08:46:30 +0000",
    "user" : {
      "name" : "Corpora Journal",
      "screen_name" : "CorporaJournal",
      "protected" : false,
      "id_str" : "2340183050",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/433564609379700736\/d4vW52wm_normal.png",
      "id" : 2340183050,
      "verified" : false
    }
  },
  "id" : 506726288233869312,
  "created_at" : "2014-09-02 08:52:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/kJDGpgpXYc",
      "expanded_url" : "http:\/\/timholmesblog.wordpress.com\/2014\/08\/30\/it-was-blind-prejudice-not-political-correctness-that-failed-rotherhams-child-abuse-victims\/",
      "display_url" : "timholmesblog.wordpress.com\/2014\/08\/30\/it-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "506724857925877762",
  "text" : "@_FTaylor_ here's a more informed analysis based on independent inquiry report http:\/\/t.co\/kJDGpgpXYc",
  "id" : 506724857925877762,
  "created_at" : "2014-09-02 08:46:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 0, 9 ],
      "id_str" : "121063600",
      "id" : 121063600
    }, {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 38, 53 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "506550370995548160",
  "geo" : { },
  "id_str" : "506554981781368832",
  "in_reply_to_user_id" : 121063600,
  "text" : "@whyshona post seems to have gone? cc @GeoffreyJordan",
  "id" : 506554981781368832,
  "in_reply_to_status_id" : 506550370995548160,
  "created_at" : "2014-09-01 21:31:33 +0000",
  "in_reply_to_screen_name" : "whyshona",
  "in_reply_to_user_id_str" : "121063600",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/cknsvA7fgG",
      "expanded_url" : "http:\/\/random-idea-english.blogspot.com\/2014\/08\/exploring-concession-and-contrast.html?spref=tw",
      "display_url" : "random-idea-english.blogspot.com\/2014\/08\/explor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "506554450257784833",
  "text" : "Random Idea English: Exploring concession and contrast http:\/\/t.co\/cknsvA7fgG",
  "id" : 506554450257784833,
  "created_at" : "2014-09-01 21:29:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 127, 140 ],
      "url" : "http:\/\/t.co\/C3NRNxaC40",
      "expanded_url" : "http:\/\/medialens.org\/index.php\/alerts\/alert-archive\/2014\/773-damascene-conversions.html",
      "display_url" : "medialens.org\/index.php\/aler\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "506454217805275136",
  "text" : "RT @medialens: The Assad atrocity stories splashed across front pages and TV broadcasts for so long have mysteriously dried up http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/C3NRNxaC40",
        "expanded_url" : "http:\/\/medialens.org\/index.php\/alerts\/alert-archive\/2014\/773-damascene-conversions.html",
        "display_url" : "medialens.org\/index.php\/aler\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "506442284062478337",
    "text" : "The Assad atrocity stories splashed across front pages and TV broadcasts for so long have mysteriously dried up http:\/\/t.co\/C3NRNxaC40",
    "id" : 506442284062478337,
    "created_at" : "2014-09-01 14:03:44 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 506454217805275136,
  "created_at" : "2014-09-01 14:51:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefania Spina",
      "screen_name" : "sspina",
      "indices" : [ 3, 10 ],
      "id_str" : "10975952",
      "id" : 10975952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/9hIpaeCK2l",
      "expanded_url" : "http:\/\/www.ft.com\/cms\/s\/2\/82f41202-27f3-11e4-ae44-00144feabdc0.html",
      "display_url" : "ft.com\/cms\/s\/2\/82f412\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "506442584643100672",
  "text" : "RT @sspina: 'We analysed thousands of US menus and found we could predict prices just from the words\u2019 The secret language of food http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/9hIpaeCK2l",
        "expanded_url" : "http:\/\/www.ft.com\/cms\/s\/2\/82f41202-27f3-11e4-ae44-00144feabdc0.html",
        "display_url" : "ft.com\/cms\/s\/2\/82f412\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "506439587195916288",
    "text" : "'We analysed thousands of US menus and found we could predict prices just from the words\u2019 The secret language of food http:\/\/t.co\/9hIpaeCK2l",
    "id" : 506439587195916288,
    "created_at" : "2014-09-01 13:53:01 +0000",
    "user" : {
      "name" : "Stefania Spina",
      "screen_name" : "sspina",
      "protected" : false,
      "id_str" : "10975952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747133791576203264\/MvL6GfjN_normal.jpg",
      "id" : 10975952,
      "verified" : false
    }
  },
  "id" : 506442584643100672,
  "created_at" : "2014-09-01 14:04:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iwona",
      "screen_name" : "yvetteinmb",
      "indices" : [ 3, 14 ],
      "id_str" : "90695737",
      "id" : 90695737
    }, {
      "name" : "Adi Rajan",
      "screen_name" : "adi_rajan",
      "indices" : [ 82, 92 ],
      "id_str" : "1011323449",
      "id" : 1011323449
    }, {
      "name" : "IATEFL BESIG",
      "screen_name" : "iatefl_besig",
      "indices" : [ 120, 133 ],
      "id_str" : "146913655",
      "id" : 146913655
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cdnelt",
      "indices" : [ 134, 140 ]
    }, {
      "text" : "eltindia",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/Nubg5OlUll",
      "expanded_url" : "http:\/\/www.besig.org\/events\/online\/workshops\/Workshop_41.aspx",
      "display_url" : "besig.org\/events\/online\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "506439682008551424",
  "text" : "RT @yvetteinmb: Developing bespoke performance support apps - Sep 14 webinar with @adi_rajan http:\/\/t.co\/Nubg5OlUll via @iatefl_besig #cdne\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Adi Rajan",
        "screen_name" : "adi_rajan",
        "indices" : [ 66, 76 ],
        "id_str" : "1011323449",
        "id" : 1011323449
      }, {
        "name" : "IATEFL BESIG",
        "screen_name" : "iatefl_besig",
        "indices" : [ 104, 117 ],
        "id_str" : "146913655",
        "id" : 146913655
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "cdnelt",
        "indices" : [ 118, 125 ]
      }, {
        "text" : "eltindia",
        "indices" : [ 126, 135 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/Nubg5OlUll",
        "expanded_url" : "http:\/\/www.besig.org\/events\/online\/workshops\/Workshop_41.aspx",
        "display_url" : "besig.org\/events\/online\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "506414007503585280",
    "text" : "Developing bespoke performance support apps - Sep 14 webinar with @adi_rajan http:\/\/t.co\/Nubg5OlUll via @iatefl_besig #cdnelt #eltindia",
    "id" : 506414007503585280,
    "created_at" : "2014-09-01 12:11:22 +0000",
    "user" : {
      "name" : "Iwona",
      "screen_name" : "yvetteinmb",
      "protected" : false,
      "id_str" : "90695737",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/557709684782542848\/F-hkOiI5_normal.jpeg",
      "id" : 90695737,
      "verified" : false
    }
  },
  "id" : 506439682008551424,
  "created_at" : "2014-09-01 13:53:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Szab\u00F3",
      "screen_name" : "RobertASzabo",
      "indices" : [ 0, 13 ],
      "id_str" : "145285777",
      "id" : 145285777
    }, {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 130, 140 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/iIV5mfItOZ",
      "expanded_url" : "http:\/\/medialens.org\/index.php\/alerts\/alert-archive\/alerts-2013\/715-eyes-like-blank-discs-the-guardian-s-steven-poole-on-george-orwell-s-politics-and-the-english-language.html",
      "display_url" : "medialens.org\/index.php\/aler\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "506373569769906176",
  "geo" : { },
  "id_str" : "506393113821450240",
  "in_reply_to_user_id" : 145285777,
  "text" : "@RobertASzabo Politics&amp; the English Language essay seems to be misread a lot, i prefer this reading http:\/\/t.co\/iIV5mfItOZ by @medialens",
  "id" : 506393113821450240,
  "in_reply_to_status_id" : 506373569769906176,
  "created_at" : "2014-09-01 10:48:21 +0000",
  "in_reply_to_screen_name" : "RobertASzabo",
  "in_reply_to_user_id_str" : "145285777",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "506379791717908480",
  "text" : "@_FTaylor_ \"We teach modern learning techniques, such as spaced repetition\" strange definition of modern :)",
  "id" : 506379791717908480,
  "created_at" : "2014-09-01 09:55:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tommy Sawyer",
      "screen_name" : "dw_english",
      "indices" : [ 77, 88 ],
      "id_str" : "3341784177",
      "id" : 3341784177
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/gLDmEgoixS",
      "expanded_url" : "http:\/\/dw.de\/p\/1Cwrz",
      "display_url" : "dw.de\/p\/1Cwrz"
    } ]
  },
  "geo" : { },
  "id_str" : "506346297570250752",
  "text" : "Binney: 'The NSA's main motives: power and money' http:\/\/t.co\/gLDmEgoixS via @dw_english",
  "id" : 506346297570250752,
  "created_at" : "2014-09-01 07:42:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 50, 66 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 67, 75 ]
    }, {
      "text" : "tefl",
      "indices" : [ 76, 81 ]
    }, {
      "text" : "esl",
      "indices" : [ 82, 86 ]
    }, {
      "text" : "efl",
      "indices" : [ 87, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/GqOj7iXLKs",
      "expanded_url" : "http:\/\/wp.me\/p3vQZV-tz",
      "display_url" : "wp.me\/p3vQZV-tz"
    } ]
  },
  "geo" : { },
  "id_str" : "506203022188236800",
  "text" : "Rebeats (music videos) http:\/\/t.co\/GqOj7iXLKs via @wordpressdotcom #eltchat #tefl #esl #efl",
  "id" : 506203022188236800,
  "created_at" : "2014-08-31 22:12:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
} ]