Grailbird.data.tweets_2016_07 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Bunyan",
      "screen_name" : "bunyanchris",
      "indices" : [ 3, 15 ],
      "id_str" : "237402639",
      "id" : 237402639
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELT",
      "indices" : [ 17, 21 ]
    } ],
    "urls" : [ {
      "indices" : [ 122, 140 ],
      "url" : "https:\/\/t.co\/ERbINiqh5X",
      "expanded_url" : "https:\/\/bunyanchris.typeform.com\/to\/LGHFSQ",
      "display_url" : "bunyanchris.typeform.com\/to\/LGHFSQ"
    } ]
  },
  "geo" : { },
  "id_str" : "759699549921214464",
  "text" : "RT @bunyanchris: #ELT teachers, want to help with research on feedback? Got 5-10mins for 27 multi-choice Qs? Many thanks!\nhttps:\/\/t.co\/ERbI\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELT",
        "indices" : [ 0, 4 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/ERbINiqh5X",
        "expanded_url" : "https:\/\/bunyanchris.typeform.com\/to\/LGHFSQ",
        "display_url" : "bunyanchris.typeform.com\/to\/LGHFSQ"
      } ]
    },
    "geo" : { },
    "id_str" : "756500928526704641",
    "text" : "#ELT teachers, want to help with research on feedback? Got 5-10mins for 27 multi-choice Qs? Many thanks!\nhttps:\/\/t.co\/ERbINiqh5X",
    "id" : 756500928526704641,
    "created_at" : "2016-07-22 14:47:31 +0000",
    "user" : {
      "name" : "Chris Bunyan",
      "screen_name" : "bunyanchris",
      "protected" : false,
      "id_str" : "237402639",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/554586048504688640\/nlCbeuHQ_normal.jpeg",
      "id" : 237402639,
      "verified" : false
    }
  },
  "id" : 759699549921214464,
  "created_at" : "2016-07-31 10:37:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hancock McDonald ELT",
      "screen_name" : "HancockMcDonald",
      "indices" : [ 3, 19 ],
      "id_str" : "552929354",
      "id" : 552929354
    }, {
      "name" : "ShareThis",
      "screen_name" : "ShareThis",
      "indices" : [ 107, 117 ],
      "id_str" : "14116807",
      "id" : 14116807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/EFROxn1Hqu",
      "expanded_url" : "https:\/\/shar.es\/1ZcQWj",
      "display_url" : "shar.es\/1ZcQWj"
    } ]
  },
  "geo" : { },
  "id_str" : "759696522413940740",
  "text" : "RT @HancockMcDonald: Mark: Materials Writing - Turning constraints into assets https:\/\/t.co\/EFROxn1Hqu via @sharethis",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ShareThis",
        "screen_name" : "ShareThis",
        "indices" : [ 86, 96 ],
        "id_str" : "14116807",
        "id" : 14116807
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/EFROxn1Hqu",
        "expanded_url" : "https:\/\/shar.es\/1ZcQWj",
        "display_url" : "shar.es\/1ZcQWj"
      } ]
    },
    "geo" : { },
    "id_str" : "759685956223897600",
    "text" : "Mark: Materials Writing - Turning constraints into assets https:\/\/t.co\/EFROxn1Hqu via @sharethis",
    "id" : 759685956223897600,
    "created_at" : "2016-07-31 09:43:40 +0000",
    "user" : {
      "name" : "Hancock McDonald ELT",
      "screen_name" : "HancockMcDonald",
      "protected" : false,
      "id_str" : "552929354",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2158919436\/HM_portrait_normal.jpg",
      "id" : 552929354,
      "verified" : false
    }
  },
  "id" : 759696522413940740,
  "created_at" : "2016-07-31 10:25:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Asumadu",
      "screen_name" : "honestlyAbroad",
      "indices" : [ 3, 18 ],
      "id_str" : "178661646",
      "id" : 178661646
    }, {
      "name" : "The Guardian",
      "screen_name" : "guardian",
      "indices" : [ 54, 63 ],
      "id_str" : "87818409",
      "id" : 87818409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 125, 140 ],
      "url" : "https:\/\/t.co\/cWLnIUf0fq",
      "expanded_url" : "https:\/\/www.theguardian.com\/commentisfree\/2016\/jul\/30\/jeremy-corbyn-strengthening-workers-rights-labour-priority",
      "display_url" : "theguardian.com\/commentisfree\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "759695740117458944",
  "text" : "RT @honestlyAbroad: Corbyn has written an article for @guardian. It's very good. I wonder how his critics will undermine it. https:\/\/t.co\/c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Guardian",
        "screen_name" : "guardian",
        "indices" : [ 34, 43 ],
        "id_str" : "87818409",
        "id" : 87818409
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/cWLnIUf0fq",
        "expanded_url" : "https:\/\/www.theguardian.com\/commentisfree\/2016\/jul\/30\/jeremy-corbyn-strengthening-workers-rights-labour-priority",
        "display_url" : "theguardian.com\/commentisfree\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "759655906770640896",
    "text" : "Corbyn has written an article for @guardian. It's very good. I wonder how his critics will undermine it. https:\/\/t.co\/cWLnIUf0fq",
    "id" : 759655906770640896,
    "created_at" : "2016-07-31 07:44:16 +0000",
    "user" : {
      "name" : "Samantha Asumadu",
      "screen_name" : "honestlyAbroad",
      "protected" : false,
      "id_str" : "178661646",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747017020722581505\/zKNOaiJv_normal.jpg",
      "id" : 178661646,
      "verified" : false
    }
  },
  "id" : 759695740117458944,
  "created_at" : "2016-07-31 10:22:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DisappointedIdealist",
      "screen_name" : "DisIdealist",
      "indices" : [ 0, 12 ],
      "id_str" : "2596710302",
      "id" : 2596710302
    }, {
      "name" : "Diane Leedham",
      "screen_name" : "DiLeed",
      "indices" : [ 13, 20 ],
      "id_str" : "2335217159",
      "id" : 2335217159
    }, {
      "name" : "The Guardian",
      "screen_name" : "guardian",
      "indices" : [ 21, 30 ],
      "id_str" : "87818409",
      "id" : 87818409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "759672629016031232",
  "geo" : { },
  "id_str" : "759682969518899200",
  "in_reply_to_user_id" : 2596710302,
  "text" : "@DisIdealist @DiLeed @guardian par for course for this alleged journalist",
  "id" : 759682969518899200,
  "in_reply_to_status_id" : 759672629016031232,
  "created_at" : "2016-07-31 09:31:48 +0000",
  "in_reply_to_screen_name" : "DisIdealist",
  "in_reply_to_user_id_str" : "2596710302",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "indices" : [ 3, 13 ],
      "id_str" : "577931950",
      "id" : 577931950
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusresource",
      "indices" : [ 20, 35 ]
    }, {
      "text" : "english",
      "indices" : [ 36, 44 ]
    }, {
      "text" : "japanese",
      "indices" : [ 45, 54 ]
    }, {
      "text" : "ddl",
      "indices" : [ 55, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/FHDYqXrLt4",
      "expanded_url" : "https:\/\/twitter.com\/za_maikeru\/status\/759647136795414528",
      "display_url" : "twitter.com\/za_maikeru\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "759679372152496128",
  "text" : "RT @RudyLoock: Nice #corpusresource #english #japanese #ddl  https:\/\/t.co\/FHDYqXrLt4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpusresource",
        "indices" : [ 5, 20 ]
      }, {
        "text" : "english",
        "indices" : [ 21, 29 ]
      }, {
        "text" : "japanese",
        "indices" : [ 30, 39 ]
      }, {
        "text" : "ddl",
        "indices" : [ 40, 44 ]
      } ],
      "urls" : [ {
        "indices" : [ 46, 69 ],
        "url" : "https:\/\/t.co\/FHDYqXrLt4",
        "expanded_url" : "https:\/\/twitter.com\/za_maikeru\/status\/759647136795414528",
        "display_url" : "twitter.com\/za_maikeru\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "759651420790464512",
    "text" : "Nice #corpusresource #english #japanese #ddl  https:\/\/t.co\/FHDYqXrLt4",
    "id" : 759651420790464512,
    "created_at" : "2016-07-31 07:26:27 +0000",
    "user" : {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "protected" : false,
      "id_str" : "577931950",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2370874884\/qm10et5v1fyzwixh651s_normal.jpeg",
      "id" : 577931950,
      "verified" : false
    }
  },
  "id" : 759679372152496128,
  "created_at" : "2016-07-31 09:17:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Sheen",
      "screen_name" : "davidsheen",
      "indices" : [ 3, 14 ],
      "id_str" : "45901207",
      "id" : 45901207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 143, 144 ],
      "url" : "https:\/\/t.co\/Ol13BBJLTn",
      "expanded_url" : "http:\/\/bit.ly\/2aRSWAH",
      "display_url" : "bit.ly\/2aRSWAH"
    } ]
  },
  "geo" : { },
  "id_str" : "759448218791010305",
  "text" : "RT @davidsheen: Now in English: Israeli Jews can force anyone speaking Arabic 2 get off public transit &amp; be abused 4 their amusement https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/Ol13BBJLTn",
        "expanded_url" : "http:\/\/bit.ly\/2aRSWAH",
        "display_url" : "bit.ly\/2aRSWAH"
      } ]
    },
    "in_reply_to_status_id_str" : "757234234780188672",
    "geo" : { },
    "id_str" : "759392513862078464",
    "in_reply_to_user_id" : 45901207,
    "text" : "Now in English: Israeli Jews can force anyone speaking Arabic 2 get off public transit &amp; be abused 4 their amusement https:\/\/t.co\/Ol13BBJLTn",
    "id" : 759392513862078464,
    "in_reply_to_status_id" : 757234234780188672,
    "created_at" : "2016-07-30 14:17:38 +0000",
    "in_reply_to_screen_name" : "davidsheen",
    "in_reply_to_user_id_str" : "45901207",
    "user" : {
      "name" : "David Sheen",
      "screen_name" : "davidsheen",
      "protected" : false,
      "id_str" : "45901207",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/764828520665214976\/35dkiOmE_normal.jpg",
      "id" : 45901207,
      "verified" : true
    }
  },
  "id" : 759448218791010305,
  "created_at" : "2016-07-30 17:58:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/wjWHFVrtpe",
      "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2016\/07\/approved-techniques.html",
      "display_url" : "thecurmudgeonly.blogspot.co.uk\/2016\/07\/approv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "759428710676267009",
  "text" : "RT @pchallinor: New mudgeonry: Approved techniques https:\/\/t.co\/wjWHFVrtpe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 58 ],
        "url" : "https:\/\/t.co\/wjWHFVrtpe",
        "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2016\/07\/approved-techniques.html",
        "display_url" : "thecurmudgeonly.blogspot.co.uk\/2016\/07\/approv\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "759423922643271680",
    "text" : "New mudgeonry: Approved techniques https:\/\/t.co\/wjWHFVrtpe",
    "id" : 759423922643271680,
    "created_at" : "2016-07-30 16:22:27 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 759428710676267009,
  "created_at" : "2016-07-30 16:41:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Sinclair",
      "screen_name" : "IanJSinclair",
      "indices" : [ 3, 16 ],
      "id_str" : "270100506",
      "id" : 270100506
    }, {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 120, 130 ],
      "id_str" : "6531902",
      "id" : 6531902
    }, {
      "name" : "CP MacLochlainn",
      "screen_name" : "CPMacL2008",
      "indices" : [ 131, 140 ],
      "id_str" : "733617661",
      "id" : 733617661
    }, {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 139, 140 ],
      "id_str" : "223771625",
      "id" : 223771625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/v5AC0PyNYR",
      "expanded_url" : "https:\/\/morningstaronline.co.uk\/a-3926-Public-backs-Corbyns-left-wing-policies#.V5xvQI-cF9B",
      "display_url" : "morningstaronline.co.uk\/a-3926-Public-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "759323723879022595",
  "text" : "RT @IanJSinclair: My new article may be of interest: 'Public backs Corbyn\u2019s left-wing policies' https:\/\/t.co\/v5AC0PyNYR @medialens @CPMacL2\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Media Lens",
        "screen_name" : "medialens",
        "indices" : [ 102, 112 ],
        "id_str" : "6531902",
        "id" : 6531902
      }, {
        "name" : "CP MacLochlainn",
        "screen_name" : "CPMacL2008",
        "indices" : [ 113, 124 ],
        "id_str" : "733617661",
        "id" : 733617661
      }, {
        "name" : "John Hilley",
        "screen_name" : "johnwhilley",
        "indices" : [ 125, 137 ],
        "id_str" : "223771625",
        "id" : 223771625
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/v5AC0PyNYR",
        "expanded_url" : "https:\/\/morningstaronline.co.uk\/a-3926-Public-backs-Corbyns-left-wing-policies#.V5xvQI-cF9B",
        "display_url" : "morningstaronline.co.uk\/a-3926-Public-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "759315573209694208",
    "text" : "My new article may be of interest: 'Public backs Corbyn\u2019s left-wing policies' https:\/\/t.co\/v5AC0PyNYR @medialens @CPMacL2008 @johnwhilley",
    "id" : 759315573209694208,
    "created_at" : "2016-07-30 09:11:54 +0000",
    "user" : {
      "name" : "Ian Sinclair",
      "screen_name" : "IanJSinclair",
      "protected" : false,
      "id_str" : "270100506",
      "profile_image_url_https" : "https:\/\/abs.twimg.com\/sticky\/default_profile_images\/default_profile_4_normal.png",
      "id" : 270100506,
      "verified" : false
    }
  },
  "id" : 759323723879022595,
  "created_at" : "2016-07-30 09:44:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 0, 12 ],
      "id_str" : "223771625",
      "id" : 223771625
    }, {
      "name" : "The Guardian",
      "screen_name" : "guardian",
      "indices" : [ 13, 22 ],
      "id_str" : "87818409",
      "id" : 87818409
    }, {
      "name" : "Hadley Freeman",
      "screen_name" : "HadleyFreeman",
      "indices" : [ 23, 37 ],
      "id_str" : "333615851",
      "id" : 333615851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "759322112167440384",
  "geo" : { },
  "id_str" : "759322277234221057",
  "in_reply_to_user_id" : 18602422,
  "text" : "@johnwhilley @guardian @HadleyFreeman that's assuming good faith in writer which I do not",
  "id" : 759322277234221057,
  "in_reply_to_status_id" : 759322112167440384,
  "created_at" : "2016-07-30 09:38:33 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 0, 12 ],
      "id_str" : "223771625",
      "id" : 223771625
    }, {
      "name" : "The Guardian",
      "screen_name" : "guardian",
      "indices" : [ 13, 22 ],
      "id_str" : "87818409",
      "id" : 87818409
    }, {
      "name" : "Hadley Freeman",
      "screen_name" : "HadleyFreeman",
      "indices" : [ 23, 37 ],
      "id_str" : "333615851",
      "id" : 333615851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "759312206165057536",
  "geo" : { },
  "id_str" : "759322112167440384",
  "in_reply_to_user_id" : 223771625,
  "text" : "@johnwhilley @guardian @HadleyFreeman amazing how cultist this writing on cults is; reducing messy reality to a simple message",
  "id" : 759322112167440384,
  "in_reply_to_status_id" : 759312206165057536,
  "created_at" : "2016-07-30 09:37:53 +0000",
  "in_reply_to_screen_name" : "johnwhilley",
  "in_reply_to_user_id_str" : "223771625",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 63, 79 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/0fEQQesjaj",
      "expanded_url" : "https:\/\/eltcation.wordpress.com\/2016\/07\/30\/crafty-teaching-pocket-study-tool\/",
      "display_url" : "eltcation.wordpress.com\/2016\/07\/30\/cra\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "759306920121470976",
  "text" : "CRAFTY TEACHING: POCKET STUDY TOOL https:\/\/t.co\/0fEQQesjaj via @wordpressdotcom",
  "id" : 759306920121470976,
  "created_at" : "2016-07-30 08:37:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    }, {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "indices" : [ 12, 24 ],
      "id_str" : "849729062",
      "id" : 849729062
    }, {
      "name" : "umasslinguistics",
      "screen_name" : "umasslinguistic",
      "indices" : [ 25, 41 ],
      "id_str" : "149239362",
      "id" : 149239362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "759041381587386369",
  "geo" : { },
  "id_str" : "759075129808781312",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco @TonyMcEnery @umasslinguistic played with interface &amp; good value added; if u r not affiliated learner corpora out if reach",
  "id" : 759075129808781312,
  "in_reply_to_status_id" : 759041381587386369,
  "created_at" : "2016-07-29 17:16:28 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "indices" : [ 0, 12 ],
      "id_str" : "849729062",
      "id" : 849729062
    }, {
      "name" : "umasslinguistics",
      "screen_name" : "umasslinguistic",
      "indices" : [ 13, 29 ],
      "id_str" : "149239362",
      "id" : 149239362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "759034926415147008",
  "geo" : { },
  "id_str" : "759036455645741057",
  "in_reply_to_user_id" : 849729062,
  "text" : "@TonyMcEnery @umasslinguistic original data from a Cam learner corpus?",
  "id" : 759036455645741057,
  "in_reply_to_status_id" : 759034926415147008,
  "created_at" : "2016-07-29 14:42:47 +0000",
  "in_reply_to_screen_name" : "TonyMcEnery",
  "in_reply_to_user_id_str" : "849729062",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELTjam",
      "screen_name" : "eltjam",
      "indices" : [ 3, 10 ],
      "id_str" : "1356363686",
      "id" : 1356363686
    }, {
      "name" : "MIT",
      "screen_name" : "MIT",
      "indices" : [ 65, 69 ],
      "id_str" : "15460048",
      "id" : 15460048
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/eltjam\/status\/758996924405952512\/photo\/1",
      "indices" : [ 126, 140 ],
      "url" : "https:\/\/t.co\/sDKtCJU48E",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Coh_rj2UEAUyugu.jpg",
      "id_str" : "758996923546079237",
      "id" : 758996923546079237,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Coh_rj2UEAUyugu.jpg",
      "sizes" : [ {
        "h" : 419,
        "resize" : "fit",
        "w" : 633
      }, {
        "h" : 419,
        "resize" : "fit",
        "w" : 633
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 419,
        "resize" : "fit",
        "w" : 633
      }, {
        "h" : 419,
        "resize" : "fit",
        "w" : 633
      } ],
      "display_url" : "pic.twitter.com\/sDKtCJU48E"
    } ],
    "hashtags" : [ {
      "text" : "English",
      "indices" : [ 23, 31 ]
    }, {
      "text" : "machinelearning",
      "indices" : [ 44, 60 ]
    }, {
      "text" : "ELT",
      "indices" : [ 121, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/H5r46JXh0r",
      "expanded_url" : "http:\/\/ow.ly\/NiDR302J5Wv",
      "display_url" : "ow.ly\/NiDR302J5Wv"
    } ]
  },
  "geo" : { },
  "id_str" : "759015250649690117",
  "text" : "RT @eltjam: Non-native #English can improve #machinelearning and @MIT created its first database https:\/\/t.co\/H5r46JXh0r #ELT https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "MIT",
        "screen_name" : "MIT",
        "indices" : [ 53, 57 ],
        "id_str" : "15460048",
        "id" : 15460048
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/eltjam\/status\/758996924405952512\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/sDKtCJU48E",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Coh_rj2UEAUyugu.jpg",
        "id_str" : "758996923546079237",
        "id" : 758996923546079237,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Coh_rj2UEAUyugu.jpg",
        "sizes" : [ {
          "h" : 419,
          "resize" : "fit",
          "w" : 633
        }, {
          "h" : 419,
          "resize" : "fit",
          "w" : 633
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 419,
          "resize" : "fit",
          "w" : 633
        }, {
          "h" : 419,
          "resize" : "fit",
          "w" : 633
        } ],
        "display_url" : "pic.twitter.com\/sDKtCJU48E"
      } ],
      "hashtags" : [ {
        "text" : "English",
        "indices" : [ 11, 19 ]
      }, {
        "text" : "machinelearning",
        "indices" : [ 32, 48 ]
      }, {
        "text" : "ELT",
        "indices" : [ 109, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/H5r46JXh0r",
        "expanded_url" : "http:\/\/ow.ly\/NiDR302J5Wv",
        "display_url" : "ow.ly\/NiDR302J5Wv"
      } ]
    },
    "geo" : { },
    "id_str" : "758996924405952512",
    "text" : "Non-native #English can improve #machinelearning and @MIT created its first database https:\/\/t.co\/H5r46JXh0r #ELT https:\/\/t.co\/sDKtCJU48E",
    "id" : 758996924405952512,
    "created_at" : "2016-07-29 12:05:42 +0000",
    "user" : {
      "name" : "ELTjam",
      "screen_name" : "eltjam",
      "protected" : false,
      "id_str" : "1356363686",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700706017441554432\/vqyiSHTx_normal.png",
      "id" : 1356363686,
      "verified" : false
    }
  },
  "id" : 759015250649690117,
  "created_at" : "2016-07-29 13:18:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    }, {
      "name" : "Sarah Grieves",
      "screen_name" : "SarahGrieves3",
      "indices" : [ 12, 26 ],
      "id_str" : "2657741101",
      "id" : 2657741101
    }, {
      "name" : "ELTjam",
      "screen_name" : "eltjam",
      "indices" : [ 27, 34 ],
      "id_str" : "1356363686",
      "id" : 1356363686
    }, {
      "name" : "MIT",
      "screen_name" : "MIT",
      "indices" : [ 35, 39 ],
      "id_str" : "15460048",
      "id" : 15460048
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "759000190212726784",
  "geo" : { },
  "id_str" : "759013899068805120",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco @SarahGrieves3 @eltjam @MIT neat thx",
  "id" : 759013899068805120,
  "in_reply_to_status_id" : 759000190212726784,
  "created_at" : "2016-07-29 13:13:09 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/dZEM6GaXZe",
      "expanded_url" : "http:\/\/www.truthdig.com\/report\/item\/the_1_percents_useful_idiots_20160726#.V5p9pR-XzI4.twitter",
      "display_url" : "truthdig.com\/report\/item\/th\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "758781350946205696",
  "text" : "The 1 Percent\u2019s Useful Idiots: Chris Hedges https:\/\/t.co\/dZEM6GaXZe",
  "id" : 758781350946205696,
  "created_at" : "2016-07-28 21:49:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShareThis",
      "screen_name" : "ShareThis",
      "indices" : [ 77, 87 ],
      "id_str" : "14116807",
      "id" : 14116807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/fEIZz5co2N",
      "expanded_url" : "https:\/\/shar.es\/1ZtJ56",
      "display_url" : "shar.es\/1ZtJ56"
    } ]
  },
  "geo" : { },
  "id_str" : "758778300705697795",
  "text" : "Donald Trump and Hillary Clinton, By Their Words https:\/\/t.co\/fEIZz5co2N via @sharethis",
  "id" : 758778300705697795,
  "created_at" : "2016-07-28 21:36:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 3, 18 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/GeoffreyJordan\/status\/758750180174729216\/photo\/1",
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/wIH2CfkFjk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoefQ7WVMAAr4BE.jpg",
      "id_str" : "758750175393296384",
      "id" : 758750175393296384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoefQ7WVMAAr4BE.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 283,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/wIH2CfkFjk"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/WrP2jwALfj",
      "expanded_url" : "https:\/\/criticalelt.wordpress.com\/2016\/07\/28\/materials-evaluation",
      "display_url" : "criticalelt.wordpress.com\/2016\/07\/28\/mat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "758764300093820929",
  "text" : "RT @GeoffreyJordan: Materials Evaluation https:\/\/t.co\/WrP2jwALfj https:\/\/t.co\/wIH2CfkFjk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/GeoffreyJordan\/status\/758750180174729216\/photo\/1",
        "indices" : [ 45, 68 ],
        "url" : "https:\/\/t.co\/wIH2CfkFjk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CoefQ7WVMAAr4BE.jpg",
        "id_str" : "758750175393296384",
        "id" : 758750175393296384,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoefQ7WVMAAr4BE.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 283,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/wIH2CfkFjk"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 21, 44 ],
        "url" : "https:\/\/t.co\/WrP2jwALfj",
        "expanded_url" : "https:\/\/criticalelt.wordpress.com\/2016\/07\/28\/materials-evaluation",
        "display_url" : "criticalelt.wordpress.com\/2016\/07\/28\/mat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "758750180174729216",
    "text" : "Materials Evaluation https:\/\/t.co\/WrP2jwALfj https:\/\/t.co\/wIH2CfkFjk",
    "id" : 758750180174729216,
    "created_at" : "2016-07-28 19:45:14 +0000",
    "user" : {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "protected" : false,
      "id_str" : "334332424",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/455317817537986561\/SD4wNKO3_normal.jpeg",
      "id" : 334332424,
      "verified" : false
    }
  },
  "id" : 758764300093820929,
  "created_at" : "2016-07-28 20:41:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "boycottbyron",
      "indices" : [ 51, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/b6gXBvOWf3",
      "expanded_url" : "https:\/\/twitter.com\/AsaWinstanley\/status\/758348488698626048",
      "display_url" : "twitter.com\/AsaWinstanley\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "758614532814168065",
  "text" : "RT @johnwhilley: 'Corporate responsibility', yeah. #boycottbyron https:\/\/t.co\/b6gXBvOWf3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "boycottbyron",
        "indices" : [ 34, 47 ]
      } ],
      "urls" : [ {
        "indices" : [ 48, 71 ],
        "url" : "https:\/\/t.co\/b6gXBvOWf3",
        "expanded_url" : "https:\/\/twitter.com\/AsaWinstanley\/status\/758348488698626048",
        "display_url" : "twitter.com\/AsaWinstanley\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "758613614744010752",
    "text" : "'Corporate responsibility', yeah. #boycottbyron https:\/\/t.co\/b6gXBvOWf3",
    "id" : 758613614744010752,
    "created_at" : "2016-07-28 10:42:34 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 758614532814168065,
  "created_at" : "2016-07-28 10:46:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stanford Engineering",
      "screen_name" : "StanfordEng",
      "indices" : [ 3, 15 ],
      "id_str" : "19425169",
      "id" : 19425169
    }, {
      "name" : "Christopher Manning",
      "screen_name" : "chrmanning",
      "indices" : [ 84, 95 ],
      "id_str" : "2815077014",
      "id" : 2815077014
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/StanfordEng\/status\/758331630264213504\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/7s4TY8uOJL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoYimK8W8AEpK7e.jpg",
      "id_str" : "758331626426396673",
      "id" : 758331626426396673,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoYimK8W8AEpK7e.jpg",
      "sizes" : [ {
        "h" : 579,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 579,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 579,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 579,
        "resize" : "fit",
        "w" : 575
      } ],
      "display_url" : "pic.twitter.com\/7s4TY8uOJL"
    } ],
    "hashtags" : [ {
      "text" : "FutureofAI",
      "indices" : [ 121, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/IXaXDrGtXS",
      "expanded_url" : "http:\/\/stanford.io\/2a46Mio",
      "display_url" : "stanford.io\/2a46Mio"
    } ]
  },
  "geo" : { },
  "id_str" : "758612621251710976",
  "text" : "RT @StanfordEng: We need computers that can really understand human language argues @chrmanning: https:\/\/t.co\/IXaXDrGtXS #FutureofAI https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Christopher Manning",
        "screen_name" : "chrmanning",
        "indices" : [ 67, 78 ],
        "id_str" : "2815077014",
        "id" : 2815077014
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/StanfordEng\/status\/758331630264213504\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/7s4TY8uOJL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CoYimK8W8AEpK7e.jpg",
        "id_str" : "758331626426396673",
        "id" : 758331626426396673,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoYimK8W8AEpK7e.jpg",
        "sizes" : [ {
          "h" : 579,
          "resize" : "fit",
          "w" : 575
        }, {
          "h" : 579,
          "resize" : "fit",
          "w" : 575
        }, {
          "h" : 579,
          "resize" : "fit",
          "w" : 575
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 579,
          "resize" : "fit",
          "w" : 575
        } ],
        "display_url" : "pic.twitter.com\/7s4TY8uOJL"
      } ],
      "hashtags" : [ {
        "text" : "FutureofAI",
        "indices" : [ 104, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/IXaXDrGtXS",
        "expanded_url" : "http:\/\/stanford.io\/2a46Mio",
        "display_url" : "stanford.io\/2a46Mio"
      } ]
    },
    "geo" : { },
    "id_str" : "758331630264213504",
    "text" : "We need computers that can really understand human language argues @chrmanning: https:\/\/t.co\/IXaXDrGtXS #FutureofAI https:\/\/t.co\/7s4TY8uOJL",
    "id" : 758331630264213504,
    "created_at" : "2016-07-27 16:02:04 +0000",
    "user" : {
      "name" : "Stanford Engineering",
      "screen_name" : "StanfordEng",
      "protected" : false,
      "id_str" : "19425169",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3376254557\/7e68314473cbea5210458600bce9acdf_normal.png",
      "id" : 19425169,
      "verified" : true
    }
  },
  "id" : 758612621251710976,
  "created_at" : "2016-07-28 10:38:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    }, {
      "name" : "Asa Winstanley",
      "screen_name" : "AsaWinstanley",
      "indices" : [ 111, 125 ],
      "id_str" : "75033178",
      "id" : 75033178
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Corbyn",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 126, 140 ],
      "url" : "https:\/\/t.co\/nC3eMsf4Dh",
      "expanded_url" : "https:\/\/electronicintifada.net\/blogs\/asa-winstanley\/millionaire-donor-uk-court-bid-fix-labour-leadership-election",
      "display_url" : "electronicintifada.net\/blogs\/asa-wins\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "758611588618256384",
  "text" : "RT @johnwhilley: Millionaire, Blairite, Israel apologist, fixer. The zealous activities of Michael Foster, via @AsaWinstanley https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Asa Winstanley",
        "screen_name" : "AsaWinstanley",
        "indices" : [ 94, 108 ],
        "id_str" : "75033178",
        "id" : 75033178
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Corbyn",
        "indices" : [ 133, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/nC3eMsf4Dh",
        "expanded_url" : "https:\/\/electronicintifada.net\/blogs\/asa-winstanley\/millionaire-donor-uk-court-bid-fix-labour-leadership-election",
        "display_url" : "electronicintifada.net\/blogs\/asa-wins\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "758610961196515329",
    "text" : "Millionaire, Blairite, Israel apologist, fixer. The zealous activities of Michael Foster, via @AsaWinstanley https:\/\/t.co\/nC3eMsf4Dh #Corbyn",
    "id" : 758610961196515329,
    "created_at" : "2016-07-28 10:32:02 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 758611588618256384,
  "created_at" : "2016-07-28 10:34:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sierra Williams",
      "screen_name" : "sn_will",
      "indices" : [ 3, 11 ],
      "id_str" : "77295594",
      "id" : 77295594
    }, {
      "name" : "LSE Impact Blog",
      "screen_name" : "LSEImpactBlog",
      "indices" : [ 33, 47 ],
      "id_str" : "273935884",
      "id" : 273935884
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 140 ],
      "url" : "https:\/\/t.co\/AdHkiPMGEQ",
      "expanded_url" : "http:\/\/blogs.lse.ac.uk\/impactofsocialsciences\/2016\/07\/27\/blogging-platforms-are-not-neutral-challenging-the-underlying-assumptions-of-our-digital-infrastructure\/",
      "display_url" : "blogs.lse.ac.uk\/impactofsocial\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "758427875833892865",
  "text" : "RT @sn_will: It\u2019s my last day on @LSEImpactBlog so I wrote a reflection on the conscious uncoupling of human and machine. https:\/\/t.co\/AdHk\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "LSE Impact Blog",
        "screen_name" : "LSEImpactBlog",
        "indices" : [ 20, 34 ],
        "id_str" : "273935884",
        "id" : 273935884
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/AdHkiPMGEQ",
        "expanded_url" : "http:\/\/blogs.lse.ac.uk\/impactofsocialsciences\/2016\/07\/27\/blogging-platforms-are-not-neutral-challenging-the-underlying-assumptions-of-our-digital-infrastructure\/",
        "display_url" : "blogs.lse.ac.uk\/impactofsocial\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "758245204268900352",
    "text" : "It\u2019s my last day on @LSEImpactBlog so I wrote a reflection on the conscious uncoupling of human and machine. https:\/\/t.co\/AdHkiPMGEQ",
    "id" : 758245204268900352,
    "created_at" : "2016-07-27 10:18:38 +0000",
    "user" : {
      "name" : "Sierra Williams",
      "screen_name" : "sn_will",
      "protected" : false,
      "id_str" : "77295594",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/722510783805054976\/N8D0JaQw_normal.jpg",
      "id" : 77295594,
      "verified" : false
    }
  },
  "id" : 758427875833892865,
  "created_at" : "2016-07-27 22:24:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/4X9h8pEwS7",
      "expanded_url" : "https:\/\/www.english.com\/blog\/21st-century-skills",
      "display_url" : "english.com\/blog\/21st-cent\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "758419833000198144",
  "text" : "this is a pretty good ELT trope bingo &amp; more : 0 https:\/\/t.co\/4X9h8pEwS7 21stC check Mitra check amazing case studies check Pearson check",
  "id" : 758419833000198144,
  "created_at" : "2016-07-27 21:52:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S'",
      "screen_name" : "Sher_han_",
      "indices" : [ 0, 10 ],
      "id_str" : "18523388",
      "id" : 18523388
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "758410829574369283",
  "geo" : { },
  "id_str" : "758411069341765632",
  "in_reply_to_user_id" : 18523388,
  "text" : "@Sher_han_ oh er who's keith kelly?",
  "id" : 758411069341765632,
  "in_reply_to_status_id" : 758410829574369283,
  "created_at" : "2016-07-27 21:17:44 +0000",
  "in_reply_to_screen_name" : "Sher_han_",
  "in_reply_to_user_id_str" : "18523388",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/G87pekifal",
      "expanded_url" : "https:\/\/twitter.com\/muranava\/status\/757288489721405440",
      "display_url" : "twitter.com\/muranava\/statu\u2026"
    }, {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/cOBN6amDA5",
      "expanded_url" : "https:\/\/twitter.com\/muranava\/status\/751383471340355585",
      "display_url" : "twitter.com\/muranava\/statu\u2026"
    }, {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/Kq8ePEESVC",
      "expanded_url" : "https:\/\/twitter.com\/muranava\/status\/751167637170913280",
      "display_url" : "twitter.com\/muranava\/statu\u2026"
    }, {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/iewhiloG7Q",
      "expanded_url" : "https:\/\/twitter.com\/muranava\/status\/751126596451438592",
      "display_url" : "twitter.com\/muranava\/statu\u2026"
    }, {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/1wJi8JBaKW",
      "expanded_url" : "https:\/\/twitter.com\/muranava\/status\/751065221956001792",
      "display_url" : "twitter.com\/muranava\/statu\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "758382290338713600",
  "geo" : { },
  "id_str" : "758406757811126272",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl meh https:\/\/t.co\/G87pekifal, https:\/\/t.co\/cOBN6amDA5, https:\/\/t.co\/Kq8ePEESVC, https:\/\/t.co\/iewhiloG7Q, https:\/\/t.co\/1wJi8JBaKW",
  "id" : 758406757811126272,
  "in_reply_to_status_id" : 758382290338713600,
  "created_at" : "2016-07-27 21:00:36 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S'",
      "screen_name" : "Sher_han_",
      "indices" : [ 0, 10 ],
      "id_str" : "18523388",
      "id" : 18523388
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "758354966096515072",
  "geo" : { },
  "id_str" : "758405153498202116",
  "in_reply_to_user_id" : 18523388,
  "text" : "@Sher_han_ hi sorry wot?",
  "id" : 758405153498202116,
  "in_reply_to_status_id" : 758354966096515072,
  "created_at" : "2016-07-27 20:54:13 +0000",
  "in_reply_to_screen_name" : "Sher_han_",
  "in_reply_to_user_id_str" : "18523388",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "indices" : [ 3, 18 ],
      "id_str" : "27716419",
      "id" : 27716419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/LFxfPpelIO",
      "expanded_url" : "http:\/\/www.craigmurray.org.uk\/archives\/2016\/07\/killings-tony-blair\/",
      "display_url" : "craigmurray.org.uk\/archives\/2016\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "758355942706651136",
  "text" : "RT @CraigMurrayOrg: Updated: The Killings of Tony Blair - Tonight I am appearing at a panel discussion following the screening of the https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.craigmurray.org.uk\" rel=\"nofollow\"\u003ECraig Murray posting plugin\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/LFxfPpelIO",
        "expanded_url" : "http:\/\/www.craigmurray.org.uk\/archives\/2016\/07\/killings-tony-blair\/",
        "display_url" : "craigmurray.org.uk\/archives\/2016\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "758266503926013952",
    "text" : "Updated: The Killings of Tony Blair - Tonight I am appearing at a panel discussion following the screening of the https:\/\/t.co\/LFxfPpelIO",
    "id" : 758266503926013952,
    "created_at" : "2016-07-27 11:43:17 +0000",
    "user" : {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "protected" : false,
      "id_str" : "27716419",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1388436826\/cm_normal.jpg",
      "id" : 27716419,
      "verified" : false
    }
  },
  "id" : 758355942706651136,
  "created_at" : "2016-07-27 17:38:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 3, 18 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/GeoffreyJordan\/status\/758309620611846145\/photo\/1",
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/574emF6lpO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoYOlDvVYAAGy_q.jpg",
      "id_str" : "758309617080295424",
      "id" : 758309617080295424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoYOlDvVYAAGy_q.jpg",
      "sizes" : [ {
        "h" : 812,
        "resize" : "fit",
        "w" : 974
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 567,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 812,
        "resize" : "fit",
        "w" : 974
      }, {
        "h" : 812,
        "resize" : "fit",
        "w" : 974
      } ],
      "display_url" : "pic.twitter.com\/574emF6lpO"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/hDEo7mRAoL",
      "expanded_url" : "https:\/\/criticalelt.wordpress.com\/2016\/07\/27\/dumb-bells-in-the-language-gym",
      "display_url" : "criticalelt.wordpress.com\/2016\/07\/27\/dum\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "758349334089961472",
  "text" : "RT @GeoffreyJordan: Dumb bells in the Language\u00A0Gym https:\/\/t.co\/hDEo7mRAoL https:\/\/t.co\/574emF6lpO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/GeoffreyJordan\/status\/758309620611846145\/photo\/1",
        "indices" : [ 55, 78 ],
        "url" : "https:\/\/t.co\/574emF6lpO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CoYOlDvVYAAGy_q.jpg",
        "id_str" : "758309617080295424",
        "id" : 758309617080295424,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoYOlDvVYAAGy_q.jpg",
        "sizes" : [ {
          "h" : 812,
          "resize" : "fit",
          "w" : 974
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 567,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 812,
          "resize" : "fit",
          "w" : 974
        }, {
          "h" : 812,
          "resize" : "fit",
          "w" : 974
        } ],
        "display_url" : "pic.twitter.com\/574emF6lpO"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 31, 54 ],
        "url" : "https:\/\/t.co\/hDEo7mRAoL",
        "expanded_url" : "https:\/\/criticalelt.wordpress.com\/2016\/07\/27\/dumb-bells-in-the-language-gym",
        "display_url" : "criticalelt.wordpress.com\/2016\/07\/27\/dum\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "758309620611846145",
    "text" : "Dumb bells in the Language\u00A0Gym https:\/\/t.co\/hDEo7mRAoL https:\/\/t.co\/574emF6lpO",
    "id" : 758309620611846145,
    "created_at" : "2016-07-27 14:34:36 +0000",
    "user" : {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "protected" : false,
      "id_str" : "334332424",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/455317817537986561\/SD4wNKO3_normal.jpeg",
      "id" : 334332424,
      "verified" : false
    }
  },
  "id" : 758349334089961472,
  "created_at" : "2016-07-27 17:12:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Bastani",
      "screen_name" : "AaronBastani",
      "indices" : [ 3, 16 ],
      "id_str" : "63082578",
      "id" : 63082578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/99pQJhf83g",
      "expanded_url" : "https:\/\/twitter.com\/georgeeaton\/status\/758252359441145856",
      "display_url" : "twitter.com\/georgeeaton\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "758288426626088960",
  "text" : "RT @AaronBastani: Corbyn has been so 'incompetent' that he might as well have written Smith's policy agenda. https:\/\/t.co\/99pQJhf83g",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/99pQJhf83g",
        "expanded_url" : "https:\/\/twitter.com\/georgeeaton\/status\/758252359441145856",
        "display_url" : "twitter.com\/georgeeaton\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "758255795318493184",
    "text" : "Corbyn has been so 'incompetent' that he might as well have written Smith's policy agenda. https:\/\/t.co\/99pQJhf83g",
    "id" : 758255795318493184,
    "created_at" : "2016-07-27 11:00:43 +0000",
    "user" : {
      "name" : "Aaron Bastani",
      "screen_name" : "AaronBastani",
      "protected" : false,
      "id_str" : "63082578",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/607541942570872832\/8qjuXLFj_normal.jpg",
      "id" : 63082578,
      "verified" : false
    }
  },
  "id" : 758288426626088960,
  "created_at" : "2016-07-27 13:10:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Emersberger",
      "screen_name" : "rosendo_joe",
      "indices" : [ 0, 12 ],
      "id_str" : "3351345863",
      "id" : 3351345863
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ChickenCoup",
      "indices" : [ 83, 95 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "758001162071203842",
  "geo" : { },
  "id_str" : "758038994315776000",
  "in_reply_to_user_id" : 3351345863,
  "text" : "@rosendo_joe let's hope it brings about significantly marginalisation of Bitterite #ChickenCoup bods",
  "id" : 758038994315776000,
  "in_reply_to_status_id" : 758001162071203842,
  "created_at" : "2016-07-26 20:39:14 +0000",
  "in_reply_to_screen_name" : "rosendo_joe",
  "in_reply_to_user_id_str" : "3351345863",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Emersberger",
      "screen_name" : "rosendo_joe",
      "indices" : [ 0, 12 ],
      "id_str" : "3351345863",
      "id" : 3351345863
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "757989688825249792",
  "geo" : { },
  "id_str" : "757999907731042304",
  "in_reply_to_user_id" : 3351345863,
  "text" : "@rosendo_joe along with unresignations could signal a turning point?",
  "id" : 757999907731042304,
  "in_reply_to_status_id" : 757989688825249792,
  "created_at" : "2016-07-26 18:03:55 +0000",
  "in_reply_to_screen_name" : "rosendo_joe",
  "in_reply_to_user_id_str" : "3351345863",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Emersberger",
      "screen_name" : "rosendo_joe",
      "indices" : [ 3, 15 ],
      "id_str" : "3351345863",
      "id" : 3351345863
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "757998231729078272",
  "text" : "RT @rosendo_joe: How does Corbyn win Labour's civil war? Winning another vote in September won't do it.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "757989688825249792",
    "text" : "How does Corbyn win Labour's civil war? Winning another vote in September won't do it.",
    "id" : 757989688825249792,
    "created_at" : "2016-07-26 17:23:19 +0000",
    "user" : {
      "name" : "Joe Emersberger",
      "screen_name" : "rosendo_joe",
      "protected" : false,
      "id_str" : "3351345863",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/621112707522142209\/OGmLR1xt_normal.jpg",
      "id" : 3351345863,
      "verified" : false
    }
  },
  "id" : 757998231729078272,
  "created_at" : "2016-07-26 17:57:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "indices" : [ 55, 70 ],
      "id_str" : "27716419",
      "id" : 27716419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/AnPZ9N3710",
      "expanded_url" : "https:\/\/www.craigmurray.org.uk\/archives\/2016\/07\/barbarians-at-the-gates\/",
      "display_url" : "craigmurray.org.uk\/archives\/2016\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "757968260486852608",
  "text" : "Barbarians at the Gates: https:\/\/t.co\/AnPZ9N3710 - via:@CraigMurrayOrg",
  "id" : 757968260486852608,
  "created_at" : "2016-07-26 15:58:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Sivier",
      "screen_name" : "MidWalesMike",
      "indices" : [ 97, 110 ],
      "id_str" : "217600910",
      "id" : 217600910
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/SKE4Vsy2UT",
      "expanded_url" : "http:\/\/voxpoliticalonline.com\/2016\/07\/22\/heres-why-owen-smith-really-shouldnt-kick-up-a-fuss-about-bullying\/",
      "display_url" : "voxpoliticalonline.com\/2016\/07\/22\/her\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "757967087889444864",
  "text" : "Here's why Owen Smith really shouldn't kick up a fuss about bullying https:\/\/t.co\/SKE4Vsy2UT via @MidWalesMike",
  "id" : 757967087889444864,
  "created_at" : "2016-07-26 15:53:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol Goodey",
      "screen_name" : "carol_goodey",
      "indices" : [ 0, 13 ],
      "id_str" : "2814555865",
      "id" : 2814555865
    }, {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 14, 23 ],
      "id_str" : "134211317",
      "id" : 134211317
    }, {
      "name" : "Steve Brown",
      "screen_name" : "sbrowntweets",
      "indices" : [ 24, 37 ],
      "id_str" : "885343459",
      "id" : 885343459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "757955235700678656",
  "geo" : { },
  "id_str" : "757961418712965120",
  "in_reply_to_user_id" : 2814555865,
  "text" : "@carol_goodey @josipa74 @sbrowntweets grt thanks",
  "id" : 757961418712965120,
  "in_reply_to_status_id" : 757955235700678656,
  "created_at" : "2016-07-26 15:30:59 +0000",
  "in_reply_to_screen_name" : "carol_goodey",
  "in_reply_to_user_id_str" : "2814555865",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 0, 9 ],
      "id_str" : "134211317",
      "id" : 134211317
    }, {
      "name" : "Carol Goodey",
      "screen_name" : "carol_goodey",
      "indices" : [ 10, 23 ],
      "id_str" : "2814555865",
      "id" : 2814555865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "757710391757697024",
  "geo" : { },
  "id_str" : "757711107586920448",
  "in_reply_to_user_id" : 134211317,
  "text" : "@josipa74 @carol_goodey am pretty ignorant of his works, just that vid caught my attention",
  "id" : 757711107586920448,
  "in_reply_to_status_id" : 757710391757697024,
  "created_at" : "2016-07-25 22:56:20 +0000",
  "in_reply_to_screen_name" : "josipa74",
  "in_reply_to_user_id_str" : "134211317",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 0, 9 ],
      "id_str" : "134211317",
      "id" : 134211317
    }, {
      "name" : "Carol Goodey",
      "screen_name" : "carol_goodey",
      "indices" : [ 55, 68 ],
      "id_str" : "2814555865",
      "id" : 2814555865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "757707598401601536",
  "geo" : { },
  "id_str" : "757708802246541316",
  "in_reply_to_user_id" : 134211317,
  "text" : "@josipa74 there's a great video of Foucault tweeted by @carol_goodey which glosses his thoughts on subjectivity",
  "id" : 757708802246541316,
  "in_reply_to_status_id" : 757707598401601536,
  "created_at" : "2016-07-25 22:47:10 +0000",
  "in_reply_to_screen_name" : "josipa74",
  "in_reply_to_user_id_str" : "134211317",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 0, 9 ],
      "id_str" : "134211317",
      "id" : 134211317
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "757707062579171337",
  "geo" : { },
  "id_str" : "757707445770805248",
  "in_reply_to_user_id" : 134211317,
  "text" : "@josipa74 ah ok i get ref ; )",
  "id" : 757707445770805248,
  "in_reply_to_status_id" : 757707062579171337,
  "created_at" : "2016-07-25 22:41:47 +0000",
  "in_reply_to_screen_name" : "josipa74",
  "in_reply_to_user_id_str" : "134211317",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sleaford Mods",
      "screen_name" : "sleafordmods",
      "indices" : [ 0, 13 ],
      "id_str" : "23674486",
      "id" : 23674486
    }, {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 14, 29 ],
      "id_str" : "285614027",
      "id" : 285614027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "757569842048274432",
  "geo" : { },
  "id_str" : "757705761984245760",
  "in_reply_to_user_id" : 23674486,
  "text" : "@sleafordmods @AnthonyTeacher lol writer seems to have a thing for Putin",
  "id" : 757705761984245760,
  "in_reply_to_status_id" : 757569842048274432,
  "created_at" : "2016-07-25 22:35:05 +0000",
  "in_reply_to_screen_name" : "sleafordmods",
  "in_reply_to_user_id_str" : "23674486",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/NSCFl8AhtV",
      "expanded_url" : "http:\/\/www.ifs.org.uk\/publications\/6899",
      "display_url" : "ifs.org.uk\/publications\/6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "757691301030748160",
  "text" : "EU Commission labels UK Patent Box harmful tax competition https:\/\/t.co\/NSCFl8AhtV",
  "id" : 757691301030748160,
  "created_at" : "2016-07-25 21:37:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JSTOR Daily",
      "screen_name" : "JSTOR_Daily",
      "indices" : [ 3, 15 ],
      "id_str" : "2696503964",
      "id" : 2696503964
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/JDtdmnIzBD",
      "expanded_url" : "http:\/\/bit.ly\/1Xwfdpi",
      "display_url" : "bit.ly\/1Xwfdpi"
    } ]
  },
  "geo" : { },
  "id_str" : "757676753460596736",
  "text" : "RT @JSTOR_Daily: The \"pun\" is both reviled and ubiquitous in our culture. We try to understand why: https:\/\/t.co\/JDtdmnIzBD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/JDtdmnIzBD",
        "expanded_url" : "http:\/\/bit.ly\/1Xwfdpi",
        "display_url" : "bit.ly\/1Xwfdpi"
      } ]
    },
    "geo" : { },
    "id_str" : "659016454373675008",
    "text" : "The \"pun\" is both reviled and ubiquitous in our culture. We try to understand why: https:\/\/t.co\/JDtdmnIzBD",
    "id" : 659016454373675008,
    "created_at" : "2015-10-27 14:39:01 +0000",
    "user" : {
      "name" : "JSTOR Daily",
      "screen_name" : "JSTOR_Daily",
      "protected" : false,
      "id_str" : "2696503964",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/501726599402647553\/x_l-p4OD_normal.png",
      "id" : 2696503964,
      "verified" : false
    }
  },
  "id" : 757676753460596736,
  "created_at" : "2016-07-25 20:39:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Englicious - Grammar",
      "screen_name" : "EngliciousUCL",
      "indices" : [ 3, 17 ],
      "id_str" : "3187104424",
      "id" : 3187104424
    }, {
      "name" : "The Conversation",
      "screen_name" : "ConversationUK",
      "indices" : [ 123, 138 ],
      "id_str" : "1241258612",
      "id" : 1241258612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/S4b8XRjsPL",
      "expanded_url" : "https:\/\/theconversation.com\/the-bfg-reminds-us-that-wordplay-is-part-of-learning-and-mastering-language-62788",
      "display_url" : "theconversation.com\/the-bfg-remind\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "757671967994613761",
  "text" : "RT @EngliciousUCL: The BFG reminds us that wordplay is part of learning and mastering language https:\/\/t.co\/S4b8XRjsPL via @ConversationUK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Conversation",
        "screen_name" : "ConversationUK",
        "indices" : [ 104, 119 ],
        "id_str" : "1241258612",
        "id" : 1241258612
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/S4b8XRjsPL",
        "expanded_url" : "https:\/\/theconversation.com\/the-bfg-reminds-us-that-wordplay-is-part-of-learning-and-mastering-language-62788",
        "display_url" : "theconversation.com\/the-bfg-remind\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "757670385122963456",
    "text" : "The BFG reminds us that wordplay is part of learning and mastering language https:\/\/t.co\/S4b8XRjsPL via @ConversationUK",
    "id" : 757670385122963456,
    "created_at" : "2016-07-25 20:14:31 +0000",
    "user" : {
      "name" : "Englicious - Grammar",
      "screen_name" : "EngliciousUCL",
      "protected" : false,
      "id_str" : "3187104424",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/591994524966252544\/90gpU8R9_normal.png",
      "id" : 3187104424,
      "verified" : false
    }
  },
  "id" : 757671967994613761,
  "created_at" : "2016-07-25 20:20:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 0, 9 ],
      "id_str" : "134211317",
      "id" : 134211317
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "757640236717445120",
  "geo" : { },
  "id_str" : "757641716270788609",
  "in_reply_to_user_id" : 134211317,
  "text" : "@josipa74 doesn't sound it, what r u referring to?",
  "id" : 757641716270788609,
  "in_reply_to_status_id" : 757640236717445120,
  "created_at" : "2016-07-25 18:20:36 +0000",
  "in_reply_to_screen_name" : "josipa74",
  "in_reply_to_user_id_str" : "134211317",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MaWSIG",
      "screen_name" : "MaWSIG",
      "indices" : [ 0, 7 ],
      "id_str" : "1096618700",
      "id" : 1096618700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/kJViR47hyJ",
      "expanded_url" : "http:\/\/www.online-utility.org\/english\/index.jsp",
      "display_url" : "online-utility.org\/english\/index.\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "755840143924211712",
  "geo" : { },
  "id_str" : "757640751274684416",
  "in_reply_to_user_id" : 1096618700,
  "text" : "@MaWSIG here's a nice set of online tools https:\/\/t.co\/kJViR47hyJ",
  "id" : 757640751274684416,
  "in_reply_to_status_id" : 755840143924211712,
  "created_at" : "2016-07-25 18:16:46 +0000",
  "in_reply_to_screen_name" : "MaWSIG",
  "in_reply_to_user_id_str" : "1096618700",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "umasslinguistics",
      "screen_name" : "umasslinguistic",
      "indices" : [ 3, 19 ],
      "id_str" : "149239362",
      "id" : 149239362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/4Lae5WKDwj",
      "expanded_url" : "http:\/\/ow.ly\/8nZF302vug9",
      "display_url" : "ow.ly\/8nZF302vug9"
    } ]
  },
  "geo" : { },
  "id_str" : "757638995169992704",
  "text" : "RT @umasslinguistic: We Uncovered the Hidden Patterns in Clinton and Trump's Most Common Phrases https:\/\/t.co\/4Lae5WKDwj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/4Lae5WKDwj",
        "expanded_url" : "http:\/\/ow.ly\/8nZF302vug9",
        "display_url" : "ow.ly\/8nZF302vug9"
      } ]
    },
    "geo" : { },
    "id_str" : "757630322712408064",
    "text" : "We Uncovered the Hidden Patterns in Clinton and Trump's Most Common Phrases https:\/\/t.co\/4Lae5WKDwj",
    "id" : 757630322712408064,
    "created_at" : "2016-07-25 17:35:19 +0000",
    "user" : {
      "name" : "umasslinguistics",
      "screen_name" : "umasslinguistic",
      "protected" : false,
      "id_str" : "149239362",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/427811597969408000\/oKGU1_Yi_normal.png",
      "id" : 149239362,
      "verified" : false
    }
  },
  "id" : 757638995169992704,
  "created_at" : "2016-07-25 18:09:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 92, 107 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/q2os07w5G7",
      "expanded_url" : "https:\/\/criticalelt.wordpress.com\/2016\/07\/25\/selivan-explains-trump-speech-similarities-no-pigs-seen-flying\/",
      "display_url" : "criticalelt.wordpress.com\/2016\/07\/25\/sel\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "757638033353179136",
  "text" : "Selivan explains Trump speech similarities. No pigs seen flying https:\/\/t.co\/q2os07w5G7 via @GeoffreyJordan",
  "id" : 757638033353179136,
  "created_at" : "2016-07-25 18:05:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Andrews",
      "screen_name" : "PatrickAndrews",
      "indices" : [ 0, 15 ],
      "id_str" : "29999737",
      "id" : 29999737
    }, {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "indices" : [ 16, 29 ],
      "id_str" : "1685397408",
      "id" : 1685397408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/BiFG9ullD2",
      "expanded_url" : "https:\/\/vimeo.com\/176052489",
      "display_url" : "vimeo.com\/176052489"
    } ]
  },
  "in_reply_to_status_id_str" : "757581129922801665",
  "geo" : { },
  "id_str" : "757587565117632513",
  "in_reply_to_user_id" : 29999737,
  "text" : "@PatrickAndrews @harrisonmike his haters just can't stand his bling yo : ) https:\/\/t.co\/BiFG9ullD2",
  "id" : 757587565117632513,
  "in_reply_to_status_id" : 757581129922801665,
  "created_at" : "2016-07-25 14:45:25 +0000",
  "in_reply_to_screen_name" : "PatrickAndrews",
  "in_reply_to_user_id_str" : "29999737",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Corbyn for PM",
      "screen_name" : "JeremyCorbyn4PM",
      "indices" : [ 3, 19 ],
      "id_str" : "3307929149",
      "id" : 3307929149
    }, {
      "name" : "Neil Findlay MSP",
      "screen_name" : "NeilFindlay_MSP",
      "indices" : [ 40, 56 ],
      "id_str" : "1088726953",
      "id" : 1088726953
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/JeremyCorbyn4PM\/status\/757487662337056768\/photo\/1",
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/hvKLQp2aRw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoMi-h7WgAASUZQ.jpg",
      "id_str" : "757487619982917632",
      "id" : 757487619982917632,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoMi-h7WgAASUZQ.jpg",
      "sizes" : [ {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1192
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 698
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 396
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1192
      } ],
      "display_url" : "pic.twitter.com\/hvKLQp2aRw"
    } ],
    "hashtags" : [ {
      "text" : "jeremy4leader",
      "indices" : [ 58, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/WD3axNOHWe",
      "expanded_url" : "http:\/\/stv.tv\/news\/politics\/1361608-neil-findlay-makes-case-for-jeremy-corbyn-ahead-of-labour-leadership-ballot\/",
      "display_url" : "stv.tv\/news\/politics\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "757585831045525504",
  "text" : "RT @JeremyCorbyn4PM: Great article from @NeilFindlay_MSP \n#jeremy4leader \nhttps:\/\/t.co\/WD3axNOHWe https:\/\/t.co\/hvKLQp2aRw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Neil Findlay MSP",
        "screen_name" : "NeilFindlay_MSP",
        "indices" : [ 19, 35 ],
        "id_str" : "1088726953",
        "id" : 1088726953
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/JeremyCorbyn4PM\/status\/757487662337056768\/photo\/1",
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/hvKLQp2aRw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CoMi-h7WgAASUZQ.jpg",
        "id_str" : "757487619982917632",
        "id" : 757487619982917632,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoMi-h7WgAASUZQ.jpg",
        "sizes" : [ {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1192
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 698
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 396
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1192
        } ],
        "display_url" : "pic.twitter.com\/hvKLQp2aRw"
      } ],
      "hashtags" : [ {
        "text" : "jeremy4leader",
        "indices" : [ 37, 51 ]
      } ],
      "urls" : [ {
        "indices" : [ 53, 76 ],
        "url" : "https:\/\/t.co\/WD3axNOHWe",
        "expanded_url" : "http:\/\/stv.tv\/news\/politics\/1361608-neil-findlay-makes-case-for-jeremy-corbyn-ahead-of-labour-leadership-ballot\/",
        "display_url" : "stv.tv\/news\/politics\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "757487662337056768",
    "text" : "Great article from @NeilFindlay_MSP \n#jeremy4leader \nhttps:\/\/t.co\/WD3axNOHWe https:\/\/t.co\/hvKLQp2aRw",
    "id" : 757487662337056768,
    "created_at" : "2016-07-25 08:08:26 +0000",
    "user" : {
      "name" : "Jeremy Corbyn for PM",
      "screen_name" : "JeremyCorbyn4PM",
      "protected" : false,
      "id_str" : "3307929149",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746982653350445056\/UHNiRVhu_normal.jpg",
      "id" : 3307929149,
      "verified" : false
    }
  },
  "id" : 757585831045525504,
  "created_at" : "2016-07-25 14:38:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "757324775890915328",
  "geo" : { },
  "id_str" : "757326561586675712",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler wow nice database thing : ) thx",
  "id" : 757326561586675712,
  "in_reply_to_status_id" : 757324775890915328,
  "created_at" : "2016-07-24 21:28:17 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : " Pulse",
      "screen_name" : "ExplosivePulse",
      "indices" : [ 3, 18 ],
      "id_str" : "3719454922",
      "id" : 3719454922
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MSM",
      "indices" : [ 61, 65 ]
    }, {
      "text" : "BlameCorbyn",
      "indices" : [ 91, 103 ]
    }, {
      "text" : "BlamePutin",
      "indices" : [ 127, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "757291310327930880",
  "text" : "RT @ExplosivePulse: I've just worked something out about the #MSM. For domestic problems,  #BlameCorbyn. For foreign problems, #BlamePutin.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MSM",
        "indices" : [ 41, 45 ]
      }, {
        "text" : "BlameCorbyn",
        "indices" : [ 71, 83 ]
      }, {
        "text" : "BlamePutin",
        "indices" : [ 107, 118 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "757282461411835904",
    "text" : "I've just worked something out about the #MSM. For domestic problems,  #BlameCorbyn. For foreign problems, #BlamePutin.",
    "id" : 757282461411835904,
    "created_at" : "2016-07-24 18:33:03 +0000",
    "user" : {
      "name" : " Pulse",
      "screen_name" : "ExplosivePulse",
      "protected" : false,
      "id_str" : "3719454922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/669258311682957316\/l9ZBOSm9_normal.png",
      "id" : 3719454922,
      "verified" : false
    }
  },
  "id" : 757291310327930880,
  "created_at" : "2016-07-24 19:08:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Corbyn",
      "indices" : [ 48, 55 ]
    }, {
      "text" : "CorbynStays",
      "indices" : [ 56, 68 ]
    }, {
      "text" : "Owen2016",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/BiFG9ullD2",
      "expanded_url" : "https:\/\/vimeo.com\/176052489",
      "display_url" : "vimeo.com\/176052489"
    } ]
  },
  "geo" : { },
  "id_str" : "757288489721405440",
  "text" : "Retranslation. Bitches. https:\/\/t.co\/BiFG9ullD2 #Corbyn #CorbynStays #Owen2016",
  "id" : 757288489721405440,
  "created_at" : "2016-07-24 18:57:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/uqydrYUgKe",
      "expanded_url" : "https:\/\/speechevents.wordpress.com\/2016\/07\/22\/melania-trump-plagiarism-the-boss\/",
      "display_url" : "speechevents.wordpress.com\/2016\/07\/22\/mel\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "757258044388638720",
  "geo" : { },
  "id_str" : "757261839516504064",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan hi Leo have u read this? https:\/\/t.co\/uqydrYUgKe",
  "id" : 757261839516504064,
  "in_reply_to_status_id" : 757258044388638720,
  "created_at" : "2016-07-24 17:11:06 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 3, 14 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/leoselivan\/status\/757258044388638720\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/JCWDoRSKAB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoJSLR6WAAAhqUy.jpg",
      "id_str" : "757258041091817472",
      "id" : 757258041091817472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoJSLR6WAAAhqUy.jpg",
      "sizes" : [ {
        "h" : 234,
        "resize" : "fit",
        "w" : 445
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 234,
        "resize" : "fit",
        "w" : 445
      }, {
        "h" : 234,
        "resize" : "fit",
        "w" : 445
      }, {
        "h" : 234,
        "resize" : "fit",
        "w" : 445
      } ],
      "display_url" : "pic.twitter.com\/JCWDoRSKAB"
    } ],
    "hashtags" : [ {
      "text" : "langchat",
      "indices" : [ 114, 123 ]
    }, {
      "text" : "elt",
      "indices" : [ 124, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/8NriTHSFOx",
      "expanded_url" : "http:\/\/buff.ly\/2a9T9Rf",
      "display_url" : "buff.ly\/2a9T9Rf"
    } ]
  },
  "geo" : { },
  "id_str" : "757261718951198720",
  "text" : "RT @leoselivan: New on my blog: Does the chunk argument trump the plagiarism allegations? https:\/\/t.co\/8NriTHSFOx #langchat #elt https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/leoselivan\/status\/757258044388638720\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/JCWDoRSKAB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CoJSLR6WAAAhqUy.jpg",
        "id_str" : "757258041091817472",
        "id" : 757258041091817472,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoJSLR6WAAAhqUy.jpg",
        "sizes" : [ {
          "h" : 234,
          "resize" : "fit",
          "w" : 445
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 234,
          "resize" : "fit",
          "w" : 445
        }, {
          "h" : 234,
          "resize" : "fit",
          "w" : 445
        }, {
          "h" : 234,
          "resize" : "fit",
          "w" : 445
        } ],
        "display_url" : "pic.twitter.com\/JCWDoRSKAB"
      } ],
      "hashtags" : [ {
        "text" : "langchat",
        "indices" : [ 98, 107 ]
      }, {
        "text" : "elt",
        "indices" : [ 108, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/8NriTHSFOx",
        "expanded_url" : "http:\/\/buff.ly\/2a9T9Rf",
        "display_url" : "buff.ly\/2a9T9Rf"
      } ]
    },
    "geo" : { },
    "id_str" : "757258044388638720",
    "text" : "New on my blog: Does the chunk argument trump the plagiarism allegations? https:\/\/t.co\/8NriTHSFOx #langchat #elt https:\/\/t.co\/JCWDoRSKAB",
    "id" : 757258044388638720,
    "created_at" : "2016-07-24 16:56:01 +0000",
    "user" : {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "protected" : false,
      "id_str" : "408365496",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/460546508601819136\/12ivDBb__normal.jpeg",
      "id" : 408365496,
      "verified" : false
    }
  },
  "id" : 757261718951198720,
  "created_at" : "2016-07-24 17:10:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roberto Greco",
      "screen_name" : "rogre",
      "indices" : [ 3, 9 ],
      "id_str" : "31337253",
      "id" : 31337253
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/guwkqkSCmd",
      "expanded_url" : "http:\/\/bb9.berlinbiennale.de\/all-problems-can-be-illuminated-not-all-problems-can-be-solved\/",
      "display_url" : "bb9.berlinbiennale.de\/all-problems-c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "757223670351798272",
  "text" : "RT @rogre: \u201CThere is no technology for justice. There is only justice.\u201D \u2014Ursula Franklin https:\/\/t.co\/guwkqkSCmd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/guwkqkSCmd",
        "expanded_url" : "http:\/\/bb9.berlinbiennale.de\/all-problems-can-be-illuminated-not-all-problems-can-be-solved\/",
        "display_url" : "bb9.berlinbiennale.de\/all-problems-c\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "756975345908101122",
    "text" : "\u201CThere is no technology for justice. There is only justice.\u201D \u2014Ursula Franklin https:\/\/t.co\/guwkqkSCmd",
    "id" : 756975345908101122,
    "created_at" : "2016-07-23 22:12:41 +0000",
    "user" : {
      "name" : "Roberto Greco",
      "screen_name" : "rogre",
      "protected" : false,
      "id_str" : "31337253",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/592067065709600768\/Bl8BbAgF_normal.png",
      "id" : 31337253,
      "verified" : false
    }
  },
  "id" : 757223670351798272,
  "created_at" : "2016-07-24 14:39:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/i2zkh2vcbg",
      "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2016\/07\/blips-in-nation-building.html",
      "display_url" : "thecurmudgeonly.blogspot.co.uk\/2016\/07\/blips-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "757190222547447808",
  "text" : "RT @pchallinor: New mudgeonry: Blips in the nation-building https:\/\/t.co\/i2zkh2vcbg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 67 ],
        "url" : "https:\/\/t.co\/i2zkh2vcbg",
        "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2016\/07\/blips-in-nation-building.html",
        "display_url" : "thecurmudgeonly.blogspot.co.uk\/2016\/07\/blips-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "757188945499291649",
    "text" : "New mudgeonry: Blips in the nation-building https:\/\/t.co\/i2zkh2vcbg",
    "id" : 757188945499291649,
    "created_at" : "2016-07-24 12:21:27 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 757190222547447808,
  "created_at" : "2016-07-24 12:26:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OffGuardian",
      "screen_name" : "OffGuardian",
      "indices" : [ 128, 140 ],
      "id_str" : "3023553183",
      "id" : 3023553183
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/nEQX29Ulff",
      "expanded_url" : "https:\/\/off-guardian.org\/2016\/07\/24\/the-encirclement-of-china-is-well-underway-france-prepares-to-lead-eu-missions-in-the-south-china-sea\/",
      "display_url" : "off-guardian.org\/2016\/07\/24\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "757189046951182337",
  "text" : "The Encirclement of China is Well Underway: France Prepares to Lead EU Missions in the South China\u2026 https:\/\/t.co\/nEQX29Ulff via @OffGuardian",
  "id" : 757189046951182337,
  "created_at" : "2016-07-24 12:21:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bella Caledonia",
      "screen_name" : "bellacaledonia",
      "indices" : [ 3, 18 ],
      "id_str" : "103554348",
      "id" : 103554348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/IkiYBjIPMt",
      "expanded_url" : "http:\/\/bellacaledonia.org.uk\/2016\/07\/24\/the-corbynite-manoeuvre\/",
      "display_url" : "bellacaledonia.org.uk\/2016\/07\/24\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "757183704238264320",
  "text" : "RT @bellacaledonia: The Corbynite Manoeuvre\n https:\/\/t.co\/IkiYBjIPMt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 25, 48 ],
        "url" : "https:\/\/t.co\/IkiYBjIPMt",
        "expanded_url" : "http:\/\/bellacaledonia.org.uk\/2016\/07\/24\/the-corbynite-manoeuvre\/",
        "display_url" : "bellacaledonia.org.uk\/2016\/07\/24\/the\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "757171155778273280",
    "text" : "The Corbynite Manoeuvre\n https:\/\/t.co\/IkiYBjIPMt",
    "id" : 757171155778273280,
    "created_at" : "2016-07-24 11:10:45 +0000",
    "user" : {
      "name" : "Bella Caledonia",
      "screen_name" : "bellacaledonia",
      "protected" : false,
      "id_str" : "103554348",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/732831340194897925\/WGVyJGiO_normal.jpg",
      "id" : 103554348,
      "verified" : false
    }
  },
  "id" : 757183704238264320,
  "created_at" : "2016-07-24 12:00:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rebecca Long-Bailey",
      "screen_name" : "RLong_Bailey",
      "indices" : [ 18, 31 ],
      "id_str" : "385306338",
      "id" : 385306338
    }, {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 93, 101 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/pVbB6Wr8Zo",
      "expanded_url" : "https:\/\/youtu.be\/5-sVAWqnNDM",
      "display_url" : "youtu.be\/5-sVAWqnNDM"
    } ]
  },
  "geo" : { },
  "id_str" : "757164006712938496",
  "text" : "Jeremy Corbyn and @RLong_Bailey speak to a full house in Salford https:\/\/t.co\/pVbB6Wr8Zo via @YouTube",
  "id" : 757164006712938496,
  "created_at" : "2016-07-24 10:42:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Verso Books",
      "screen_name" : "VersoBooks",
      "indices" : [ 109, 120 ],
      "id_str" : "23187207",
      "id" : 23187207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/AzFCLLY67D",
      "expanded_url" : "http:\/\/www.versobooks.com\/blogs\/2783-free-ebook-richard-seymour-on-the-coup-against-corbyn-and-the-future-of-labour",
      "display_url" : "versobooks.com\/blogs\/2783-fre\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "757156334408200192",
  "text" : "FREE EBOOK - Richard Seymour on the coup against Corbyn and the future of Labour https:\/\/t.co\/AzFCLLY67D via @VersoBooks",
  "id" : 757156334408200192,
  "created_at" : "2016-07-24 10:11:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 124, 140 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/chj2DjrbAb",
      "expanded_url" : "https:\/\/ioelondonblog.wordpress.com\/2016\/07\/24\/changing-the-subject-why-pushing-pupils-from-disadvantaged-backgrounds-to-take-more-academic-subjects-may-not-be-such-a-bad-thing\/",
      "display_url" : "ioelondonblog.wordpress.com\/2016\/07\/24\/cha\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "757151515811385344",
  "text" : "Changing the subject: why pushing pupils from disadvantaged backgrounds to take more academic \u2026 https:\/\/t.co\/chj2DjrbAb via @wordpressdotcom",
  "id" : 757151515811385344,
  "created_at" : "2016-07-24 09:52:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cryptome",
      "screen_name" : "Cryptomeorg",
      "indices" : [ 0, 12 ],
      "id_str" : "116966175",
      "id" : 116966175
    }, {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "indices" : [ 13, 28 ],
      "id_str" : "152194866",
      "id" : 152194866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "756979460835082240",
  "geo" : { },
  "id_str" : "757140594699436032",
  "in_reply_to_user_id" : 116966175,
  "text" : "@Cryptomeorg @patrickDurusau if it's a game then seems the public are the always the losers",
  "id" : 757140594699436032,
  "in_reply_to_status_id" : 756979460835082240,
  "created_at" : "2016-07-24 09:09:19 +0000",
  "in_reply_to_screen_name" : "Cryptomeorg",
  "in_reply_to_user_id_str" : "116966175",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "EngConnectTeachers",
      "screen_name" : "eng_teachers",
      "indices" : [ 10, 23 ],
      "id_str" : "2861318566",
      "id" : 2861318566
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "755040456010981377",
  "geo" : { },
  "id_str" : "757140184794222592",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava @eng_teachers thanks for sharing : )",
  "id" : 757140184794222592,
  "in_reply_to_status_id" : 755040456010981377,
  "created_at" : "2016-07-24 09:07:41 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Field",
      "screen_name" : "John__Field",
      "indices" : [ 68, 80 ],
      "id_str" : "126258726",
      "id" : 126258726
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/NaiAjQG0kW",
      "expanded_url" : "https:\/\/thelearningprofessor.wordpress.com\/2016\/07\/24\/should-we-mourn-a-uk-exit-from-erasmus\/",
      "display_url" : "thelearningprofessor.wordpress.com\/2016\/07\/24\/sho\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "757139771470807040",
  "text" : "Should we mourn a UK exit from Erasmus? https:\/\/t.co\/NaiAjQG0kW via @John__Field",
  "id" : 757139771470807040,
  "created_at" : "2016-07-24 09:06:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cryptome",
      "screen_name" : "Cryptomeorg",
      "indices" : [ 0, 12 ],
      "id_str" : "116966175",
      "id" : 116966175
    }, {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "indices" : [ 13, 28 ],
      "id_str" : "152194866",
      "id" : 152194866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "756977743850463232",
  "geo" : { },
  "id_str" : "756978088106418176",
  "in_reply_to_user_id" : 116966175,
  "text" : "@Cryptomeorg @patrickDurusau name, social sec etc",
  "id" : 756978088106418176,
  "in_reply_to_status_id" : 756977743850463232,
  "created_at" : "2016-07-23 22:23:34 +0000",
  "in_reply_to_screen_name" : "Cryptomeorg",
  "in_reply_to_user_id_str" : "116966175",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "indices" : [ 0, 15 ],
      "id_str" : "152194866",
      "id" : 152194866
    }, {
      "name" : "Cryptome",
      "screen_name" : "Cryptomeorg",
      "indices" : [ 16, 28 ],
      "id_str" : "116966175",
      "id" : 116966175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "756968279424499712",
  "geo" : { },
  "id_str" : "756975257844678656",
  "in_reply_to_user_id" : 152194866,
  "text" : "@patrickDurusau @Cryptomeorg what r thoughts on personal details on leak?",
  "id" : 756975257844678656,
  "in_reply_to_status_id" : 756968279424499712,
  "created_at" : "2016-07-23 22:12:20 +0000",
  "in_reply_to_screen_name" : "patrickDurusau",
  "in_reply_to_user_id_str" : "152194866",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mr. Driscoll",
      "screen_name" : "e_d_driscoll",
      "indices" : [ 3, 16 ],
      "id_str" : "381086898",
      "id" : 381086898
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/kQjHAEGCfZ",
      "expanded_url" : "https:\/\/www.good.is\/articles\/major-brands-infographic?utm_content=inf_11_81_2&utm_source=TSE&utm_medium=FB&utm_campaign=pd&tse_id=INF_15d2f8b050d611e6b64f236881c19eed",
      "display_url" : "good.is\/articles\/major\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "756962843400994816",
  "text" : "RT @e_d_driscoll: There's your actual sovereignty, right there https:\/\/t.co\/kQjHAEGCfZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 68 ],
        "url" : "https:\/\/t.co\/kQjHAEGCfZ",
        "expanded_url" : "https:\/\/www.good.is\/articles\/major-brands-infographic?utm_content=inf_11_81_2&utm_source=TSE&utm_medium=FB&utm_campaign=pd&tse_id=INF_15d2f8b050d611e6b64f236881c19eed",
        "display_url" : "good.is\/articles\/major\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "756962070495694848",
    "text" : "There's your actual sovereignty, right there https:\/\/t.co\/kQjHAEGCfZ",
    "id" : 756962070495694848,
    "created_at" : "2016-07-23 21:19:55 +0000",
    "user" : {
      "name" : "Mr. Driscoll",
      "screen_name" : "e_d_driscoll",
      "protected" : false,
      "id_str" : "381086898",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656584309415895040\/sBLrsGsl_normal.jpg",
      "id" : 381086898,
      "verified" : false
    }
  },
  "id" : 756962843400994816,
  "created_at" : "2016-07-23 21:23:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Bunker",
      "screen_name" : "davidjslbunker",
      "indices" : [ 0, 15 ],
      "id_str" : "297907467",
      "id" : 297907467
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/lJk4BiZaDD",
      "expanded_url" : "https:\/\/plus.google.com\/+MuraNava\/posts\/CzJ4gD72U8B",
      "display_url" : "plus.google.com\/+MuraNava\/post\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "756818534592761856",
  "geo" : { },
  "id_str" : "756824111838556160",
  "in_reply_to_user_id" : 297907467,
  "text" : "@davidjslbunker thks! do keep checking G+ CL community e.g. latest post is on email corpora https:\/\/t.co\/lJk4BiZaDD",
  "id" : 756824111838556160,
  "in_reply_to_status_id" : 756818534592761856,
  "created_at" : "2016-07-23 12:11:44 +0000",
  "in_reply_to_screen_name" : "davidjslbunker",
  "in_reply_to_user_id_str" : "297907467",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "indices" : [ 3, 18 ],
      "id_str" : "152194866",
      "id" : 152194866
    }, {
      "name" : "WikiLeaks",
      "screen_name" : "wikileaks",
      "indices" : [ 85, 95 ],
      "id_str" : "16589206",
      "id" : 16589206
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DNC",
      "indices" : [ 80, 84 ]
    }, {
      "text" : "emoji",
      "indices" : [ 96, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/0ESdDTL0zz",
      "expanded_url" : "http:\/\/wp.me\/pSoaD-ilo",
      "display_url" : "wp.me\/pSoaD-ilo"
    } ]
  },
  "geo" : { },
  "id_str" : "756800817190043648",
  "text" : "RT @patrickDurusau: Yes Luis, There Is A Fuck You Emoji https:\/\/t.co\/0ESdDTL0zz #DNC @wikileaks #emoji",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "WikiLeaks",
        "screen_name" : "wikileaks",
        "indices" : [ 65, 75 ],
        "id_str" : "16589206",
        "id" : 16589206
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DNC",
        "indices" : [ 60, 64 ]
      }, {
        "text" : "emoji",
        "indices" : [ 76, 82 ]
      } ],
      "urls" : [ {
        "indices" : [ 36, 59 ],
        "url" : "https:\/\/t.co\/0ESdDTL0zz",
        "expanded_url" : "http:\/\/wp.me\/pSoaD-ilo",
        "display_url" : "wp.me\/pSoaD-ilo"
      } ]
    },
    "geo" : { },
    "id_str" : "756662527967301632",
    "text" : "Yes Luis, There Is A Fuck You Emoji https:\/\/t.co\/0ESdDTL0zz #DNC @wikileaks #emoji",
    "id" : 756662527967301632,
    "created_at" : "2016-07-23 01:29:39 +0000",
    "user" : {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "protected" : false,
      "id_str" : "152194866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/961579480\/patrick_normal.jpeg",
      "id" : 152194866,
      "verified" : false
    }
  },
  "id" : 756800817190043648,
  "created_at" : "2016-07-23 10:39:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Adele Soracco",
      "screen_name" : "LauraSoracco",
      "indices" : [ 0, 13 ],
      "id_str" : "15663328",
      "id" : 15663328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/Erscakecze",
      "expanded_url" : "https:\/\/wikileaks.org\/dnc-emails\/",
      "display_url" : "wikileaks.org\/dnc-emails\/"
    } ]
  },
  "geo" : { },
  "id_str" : "756800244122284032",
  "in_reply_to_user_id" : 15663328,
  "text" : "@LauraSoracco another email database this time from DNC https:\/\/t.co\/Erscakecze",
  "id" : 756800244122284032,
  "created_at" : "2016-07-23 10:36:53 +0000",
  "in_reply_to_screen_name" : "LauraSoracco",
  "in_reply_to_user_id_str" : "15663328",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Kriss",
      "screen_name" : "sam_kriss",
      "indices" : [ 51, 61 ],
      "id_str" : "588771213",
      "id" : 588771213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/Amv0o7cGpm",
      "expanded_url" : "https:\/\/samkriss.wordpress.com\/2016\/07\/22\/corbynism-or-barbarism\/",
      "display_url" : "samkriss.wordpress.com\/2016\/07\/22\/cor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "756786107992379392",
  "text" : "Corbynism or barbarism https:\/\/t.co\/Amv0o7cGpm via @sam_kriss",
  "id" : 756786107992379392,
  "created_at" : "2016-07-23 09:40:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Bunker",
      "screen_name" : "davidjslbunker",
      "indices" : [ 0, 15 ],
      "id_str" : "297907467",
      "id" : 297907467
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "756628516083412993",
  "geo" : { },
  "id_str" : "756785369383854080",
  "in_reply_to_user_id" : 297907467,
  "text" : "@davidjslbunker hi cheers \uD83D\uDE03",
  "id" : 756785369383854080,
  "in_reply_to_status_id" : 756628516083412993,
  "created_at" : "2016-07-23 09:37:47 +0000",
  "in_reply_to_screen_name" : "davidjslbunker",
  "in_reply_to_user_id_str" : "297907467",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 10, 26 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "755040456010981377",
  "geo" : { },
  "id_str" : "756594516694593536",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava @getgreatenglish cheers bud, have a cool w\/e : )",
  "id" : 756594516694593536,
  "in_reply_to_status_id" : 755040456010981377,
  "created_at" : "2016-07-22 20:59:24 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Patricia Brenes",
      "screen_name" : "patriciambr",
      "indices" : [ 10, 22 ],
      "id_str" : "35764443",
      "id" : 35764443
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "756550954279956481",
  "geo" : { },
  "id_str" : "756590229105106944",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava @patriciambr thx! have a good w\/e : )",
  "id" : 756590229105106944,
  "in_reply_to_status_id" : 756550954279956481,
  "created_at" : "2016-07-22 20:42:22 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Speech Events",
      "screen_name" : "SpeechEvents",
      "indices" : [ 64, 77 ],
      "id_str" : "1468444922",
      "id" : 1468444922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/uqydrYUgKe",
      "expanded_url" : "https:\/\/speechevents.wordpress.com\/2016\/07\/22\/melania-trump-plagiarism-the-boss\/",
      "display_url" : "speechevents.wordpress.com\/2016\/07\/22\/mel\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "756589909092229120",
  "text" : "Melania Trump, Plagiarism, The Boss https:\/\/t.co\/uqydrYUgKe via @speechevents",
  "id" : 756589909092229120,
  "created_at" : "2016-07-22 20:41:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/756550954279956481\/photo\/1",
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/lBV4ObRp0a",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cn_O9F6XYAEbrDj.png",
      "id_str" : "756550811375853569",
      "id" : 756550811375853569,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cn_O9F6XYAEbrDj.png",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 378
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 378
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 378
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 378
      } ],
      "display_url" : "pic.twitter.com\/lBV4ObRp0a"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/feVV1F8lKr",
      "expanded_url" : "http:\/\/phave-dictionary.englishup.me\/",
      "display_url" : "phave-dictionary.englishup.me"
    } ]
  },
  "geo" : { },
  "id_str" : "756550954279956481",
  "text" : "looks like an encouraging trend for us small timers : ) https:\/\/t.co\/feVV1F8lKr https:\/\/t.co\/lBV4ObRp0a",
  "id" : 756550954279956481,
  "created_at" : "2016-07-22 18:06:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "P\u00E9rez-Paredes",
      "screen_name" : "perezparedes",
      "indices" : [ 0, 13 ],
      "id_str" : "28528850",
      "id" : 28528850
    }, {
      "name" : "TaLC 12",
      "screen_name" : "TaLCGiessen",
      "indices" : [ 14, 26 ],
      "id_str" : "4008371734",
      "id" : 4008371734
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/T2T65YhT2A",
      "expanded_url" : "http:\/\/www.netcollo.info\/netcollo",
      "display_url" : "netcollo.info\/netcollo"
    } ]
  },
  "in_reply_to_status_id_str" : "756501082147291137",
  "geo" : { },
  "id_str" : "756533886826508288",
  "in_reply_to_user_id" : 28528850,
  "text" : "@perezparedes @TaLCGiessen ah there is a missing o https:\/\/t.co\/T2T65YhT2A",
  "id" : 756533886826508288,
  "in_reply_to_status_id" : 756501082147291137,
  "created_at" : "2016-07-22 16:58:28 +0000",
  "in_reply_to_screen_name" : "perezparedes",
  "in_reply_to_user_id_str" : "28528850",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 0, 6 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    }, {
      "name" : "TEFLology Podcast",
      "screen_name" : "TEFLology",
      "indices" : [ 7, 17 ],
      "id_str" : "2882870444",
      "id" : 2882870444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "756507836776062976",
  "geo" : { },
  "id_str" : "756533603736096768",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@ebefl @TEFLology true that!",
  "id" : 756533603736096768,
  "in_reply_to_status_id" : 756507836776062976,
  "created_at" : "2016-07-22 16:57:21 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TEFLology Podcast",
      "screen_name" : "TEFLology",
      "indices" : [ 0, 10 ],
      "id_str" : "2882870444",
      "id" : 2882870444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "756506779094134785",
  "geo" : { },
  "id_str" : "756533555988140032",
  "in_reply_to_user_id" : 2882870444,
  "text" : "@TEFLology yr welcome :)",
  "id" : 756533555988140032,
  "in_reply_to_status_id" : 756506779094134785,
  "created_at" : "2016-07-22 16:57:10 +0000",
  "in_reply_to_screen_name" : "TEFLology",
  "in_reply_to_user_id_str" : "2882870444",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/UVLjRdbllj",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=X0fVj_yVxUE",
      "display_url" : "youtube.com\/watch?v=X0fVj_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "756533355202633729",
  "text" : "summer flip-flop fix, cheap &amp; cheerful nice https:\/\/t.co\/UVLjRdbllj",
  "id" : 756533355202633729,
  "created_at" : "2016-07-22 16:56:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "P\u00E9rez-Paredes",
      "screen_name" : "perezparedes",
      "indices" : [ 0, 13 ],
      "id_str" : "28528850",
      "id" : 28528850
    }, {
      "name" : "TaLC 12",
      "screen_name" : "TaLCGiessen",
      "indices" : [ 14, 26 ],
      "id_str" : "4008371734",
      "id" : 4008371734
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/0JBv5PWGN6",
      "expanded_url" : "http:\/\/netcollo.stringnet.org\/",
      "display_url" : "netcollo.stringnet.org"
    } ]
  },
  "in_reply_to_status_id_str" : "756483567421718528",
  "geo" : { },
  "id_str" : "756484172022251520",
  "in_reply_to_user_id" : 28528850,
  "text" : "@perezparedes @TaLCGiessen is it this link? https:\/\/t.co\/0JBv5PWGN6",
  "id" : 756484172022251520,
  "in_reply_to_status_id" : 756483567421718528,
  "created_at" : "2016-07-22 13:40:56 +0000",
  "in_reply_to_screen_name" : "perezparedes",
  "in_reply_to_user_id_str" : "28528850",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 0, 12 ],
      "id_str" : "223771625",
      "id" : 223771625
    }, {
      "name" : "Jonathan Cook",
      "screen_name" : "Jonathan_K_Cook",
      "indices" : [ 13, 29 ],
      "id_str" : "2459644405",
      "id" : 2459644405
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "756418379691491328",
  "geo" : { },
  "id_str" : "756423725743046657",
  "in_reply_to_user_id" : 223771625,
  "text" : "@johnwhilley @Jonathan_K_Cook hmm less Kuhn paradigm shift next time : )",
  "id" : 756423725743046657,
  "in_reply_to_status_id" : 756418379691491328,
  "created_at" : "2016-07-22 09:40:44 +0000",
  "in_reply_to_screen_name" : "johnwhilley",
  "in_reply_to_user_id_str" : "223771625",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kris Davies",
      "screen_name" : "kris_81",
      "indices" : [ 0, 8 ],
      "id_str" : "18943932",
      "id" : 18943932
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "756156766002384896",
  "geo" : { },
  "id_str" : "756157053387804672",
  "in_reply_to_user_id" : 18943932,
  "text" : "@kris_81 cool will await eagerly, getting my tomatoes ready ; )",
  "id" : 756157053387804672,
  "in_reply_to_status_id" : 756156766002384896,
  "created_at" : "2016-07-21 16:01:04 +0000",
  "in_reply_to_screen_name" : "kris_81",
  "in_reply_to_user_id_str" : "18943932",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kris Davies",
      "screen_name" : "kris_81",
      "indices" : [ 0, 8 ],
      "id_str" : "18943932",
      "id" : 18943932
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "756156247062085632",
  "geo" : { },
  "id_str" : "756156566236045313",
  "in_reply_to_user_id" : 18943932,
  "text" : "@kris_81 yeah i recall a poster u tweeted; did you record any of it? hi five Costas for me ;;)",
  "id" : 756156566236045313,
  "in_reply_to_status_id" : 756156247062085632,
  "created_at" : "2016-07-21 15:59:08 +0000",
  "in_reply_to_screen_name" : "kris_81",
  "in_reply_to_user_id_str" : "18943932",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kris Davies",
      "screen_name" : "kris_81",
      "indices" : [ 0, 8 ],
      "id_str" : "18943932",
      "id" : 18943932
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "756155823609384960",
  "geo" : { },
  "id_str" : "756156100584628224",
  "in_reply_to_user_id" : 18943932,
  "text" : "@kris_81 yep hitting summer hols : ) how r u doing?",
  "id" : 756156100584628224,
  "in_reply_to_status_id" : 756155823609384960,
  "created_at" : "2016-07-21 15:57:17 +0000",
  "in_reply_to_screen_name" : "kris_81",
  "in_reply_to_user_id_str" : "18943932",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kris Davies",
      "screen_name" : "kris_81",
      "indices" : [ 0, 8 ],
      "id_str" : "18943932",
      "id" : 18943932
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "756154933859196928",
  "geo" : { },
  "id_str" : "756155629559885824",
  "in_reply_to_user_id" : 18943932,
  "text" : "@kris_81 fair enough, seem a lot of locals used in film?",
  "id" : 756155629559885824,
  "in_reply_to_status_id" : 756154933859196928,
  "created_at" : "2016-07-21 15:55:25 +0000",
  "in_reply_to_screen_name" : "kris_81",
  "in_reply_to_user_id_str" : "18943932",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kris Davies",
      "screen_name" : "kris_81",
      "indices" : [ 0, 8 ],
      "id_str" : "18943932",
      "id" : 18943932
    }, {
      "name" : "Amazon Studios",
      "screen_name" : "AmazonStudios",
      "indices" : [ 9, 23 ],
      "id_str" : "186222238",
      "id" : 186222238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "756153522454802433",
  "geo" : { },
  "id_str" : "756154480106676225",
  "in_reply_to_user_id" : 18943932,
  "text" : "@kris_81 @AmazonStudios neato : ) u seen Bridgend?",
  "id" : 756154480106676225,
  "in_reply_to_status_id" : 756153522454802433,
  "created_at" : "2016-07-21 15:50:51 +0000",
  "in_reply_to_screen_name" : "kris_81",
  "in_reply_to_user_id_str" : "18943932",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy for PM",
      "screen_name" : "jeremyforlab",
      "indices" : [ 3, 16 ],
      "id_str" : "3327849574",
      "id" : 3327849574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "756143681002803201",
  "text" : "RT @jeremyforlab: Jeremy Corbyn today finally threw his support behind a very popular democratic idea across the country: mandatory re-sele\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "756087726395514880",
    "text" : "Jeremy Corbyn today finally threw his support behind a very popular democratic idea across the country: mandatory re-selection of MPs.",
    "id" : 756087726395514880,
    "created_at" : "2016-07-21 11:25:36 +0000",
    "user" : {
      "name" : "Jeremy for PM",
      "screen_name" : "jeremyforlab",
      "protected" : false,
      "id_str" : "3327849574",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/610533394888413184\/23psG-qd_normal.jpg",
      "id" : 3327849574,
      "verified" : false
    }
  },
  "id" : 756143681002803201,
  "created_at" : "2016-07-21 15:07:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carl fletcher",
      "screen_name" : "Carlfletcher15",
      "indices" : [ 3, 18 ],
      "id_str" : "2330998107",
      "id" : 2330998107
    }, {
      "name" : "Scott Nelson \u262D",
      "screen_name" : "SocialistVoice",
      "indices" : [ 20, 35 ],
      "id_str" : "1833919200",
      "id" : 1833919200
    }, {
      "name" : "Aubrey Allegretti",
      "screen_name" : "breeallegretti",
      "indices" : [ 36, 51 ],
      "id_str" : "92127426",
      "id" : 92127426
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Carlfletcher15\/status\/756052874795347968\/photo\/1",
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/EnE7lwv0Cu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cn4KE1VWcAABuEO.jpg",
      "id_str" : "756052865597206528",
      "id" : 756052865597206528,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cn4KE1VWcAABuEO.jpg",
      "sizes" : [ {
        "h" : 426,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 426,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 426,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 426,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/EnE7lwv0Cu"
    } ],
    "hashtags" : [ {
      "text" : "KeepCorbyn",
      "indices" : [ 52, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "756140243204476928",
  "text" : "RT @Carlfletcher15: @SocialistVoice @breeallegretti #KeepCorbyn https:\/\/t.co\/EnE7lwv0Cu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Scott Nelson \u262D",
        "screen_name" : "SocialistVoice",
        "indices" : [ 0, 15 ],
        "id_str" : "1833919200",
        "id" : 1833919200
      }, {
        "name" : "Aubrey Allegretti",
        "screen_name" : "breeallegretti",
        "indices" : [ 16, 31 ],
        "id_str" : "92127426",
        "id" : 92127426
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Carlfletcher15\/status\/756052874795347968\/photo\/1",
        "indices" : [ 44, 67 ],
        "url" : "https:\/\/t.co\/EnE7lwv0Cu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cn4KE1VWcAABuEO.jpg",
        "id_str" : "756052865597206528",
        "id" : 756052865597206528,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cn4KE1VWcAABuEO.jpg",
        "sizes" : [ {
          "h" : 426,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 426,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 426,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 426,
          "resize" : "fit",
          "w" : 480
        } ],
        "display_url" : "pic.twitter.com\/EnE7lwv0Cu"
      } ],
      "hashtags" : [ {
        "text" : "KeepCorbyn",
        "indices" : [ 32, 43 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "756052689516109824",
    "geo" : { },
    "id_str" : "756052874795347968",
    "in_reply_to_user_id" : 2330998107,
    "text" : "@SocialistVoice @breeallegretti #KeepCorbyn https:\/\/t.co\/EnE7lwv0Cu",
    "id" : 756052874795347968,
    "in_reply_to_status_id" : 756052689516109824,
    "created_at" : "2016-07-21 09:07:06 +0000",
    "in_reply_to_screen_name" : "Carlfletcher15",
    "in_reply_to_user_id_str" : "2330998107",
    "user" : {
      "name" : "Carl fletcher",
      "screen_name" : "Carlfletcher15",
      "protected" : false,
      "id_str" : "2330998107",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/433557106399408128\/AbrmfHnZ_normal.jpeg",
      "id" : 2330998107,
      "verified" : false
    }
  },
  "id" : 756140243204476928,
  "created_at" : "2016-07-21 14:54:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "756137420576350208",
  "geo" : { },
  "id_str" : "756139782426722304",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish ha hehe : ) am sure yr diss will be de-tedded as much as possible : )",
  "id" : 756139782426722304,
  "in_reply_to_status_id" : 756137420576350208,
  "created_at" : "2016-07-21 14:52:27 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "756136048673951744",
  "geo" : { },
  "id_str" : "756136701920022528",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish TEDtastic mate : )",
  "id" : 756136701920022528,
  "in_reply_to_status_id" : 756136048673951744,
  "created_at" : "2016-07-21 14:40:12 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "756134811287195648",
  "geo" : { },
  "id_str" : "756135243090759680",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish ah sounds neat what is yr diss on?",
  "id" : 756135243090759680,
  "in_reply_to_status_id" : 756134811287195648,
  "created_at" : "2016-07-21 14:34:24 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Kennard",
      "screen_name" : "KennardMatt",
      "indices" : [ 3, 15 ],
      "id_str" : "591982810",
      "id" : 591982810
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/m59ipUFLSy",
      "expanded_url" : "https:\/\/twitter.com\/bbclaurak\/status\/755725264831864832",
      "display_url" : "twitter.com\/bbclaurak\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "756133245654216705",
  "text" : "RT @KennardMatt: In a civilised country, taunting + mocking in parliament when discussing destitution in country would be outrage https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/m59ipUFLSy",
        "expanded_url" : "https:\/\/twitter.com\/bbclaurak\/status\/755725264831864832",
        "display_url" : "twitter.com\/bbclaurak\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "756120188739780609",
    "text" : "In a civilised country, taunting + mocking in parliament when discussing destitution in country would be outrage https:\/\/t.co\/m59ipUFLSy",
    "id" : 756120188739780609,
    "created_at" : "2016-07-21 13:34:35 +0000",
    "user" : {
      "name" : "Matt Kennard",
      "screen_name" : "KennardMatt",
      "protected" : false,
      "id_str" : "591982810",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/643397871342104576\/Jye9hA9S_normal.jpg",
      "id" : 591982810,
      "verified" : false
    }
  },
  "id" : 756133245654216705,
  "created_at" : "2016-07-21 14:26:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "755618461384966144",
  "geo" : { },
  "id_str" : "756132791633469440",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish it was a fine gallivant : )",
  "id" : 756132791633469440,
  "in_reply_to_status_id" : 755618461384966144,
  "created_at" : "2016-07-21 14:24:40 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Douglas Carnall",
      "screen_name" : "JuliuzBeezer",
      "indices" : [ 3, 16 ],
      "id_str" : "25936824",
      "id" : 25936824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/V7KgFEIs8P",
      "expanded_url" : "https:\/\/www.crowdjustice.co.uk\/case\/chilcot\/",
      "display_url" : "crowdjustice.co.uk\/case\/chilcot\/"
    } ]
  },
  "geo" : { },
  "id_str" : "756098710430416897",
  "text" : "RT @JuliuzBeezer: \"to deter state officials from ever again abusing their positions with such tragic and far-reaching consequences\" https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/V7KgFEIs8P",
        "expanded_url" : "https:\/\/www.crowdjustice.co.uk\/case\/chilcot\/",
        "display_url" : "crowdjustice.co.uk\/case\/chilcot\/"
      } ]
    },
    "geo" : { },
    "id_str" : "756093084518195200",
    "text" : "\"to deter state officials from ever again abusing their positions with such tragic and far-reaching consequences\" https:\/\/t.co\/V7KgFEIs8P",
    "id" : 756093084518195200,
    "created_at" : "2016-07-21 11:46:53 +0000",
    "user" : {
      "name" : "Douglas Carnall",
      "screen_name" : "JuliuzBeezer",
      "protected" : false,
      "id_str" : "25936824",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/114211651\/robert_burns247x165_normal.jpg",
      "id" : 25936824,
      "verified" : false
    }
  },
  "id" : 756098710430416897,
  "created_at" : "2016-07-21 12:09:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Huw Jarvis",
      "screen_name" : "TESOLacademic",
      "indices" : [ 0, 14 ],
      "id_str" : "43409552",
      "id" : 43409552
    }, {
      "name" : "Angelos Bollas",
      "screen_name" : "angelos_bollas",
      "indices" : [ 15, 30 ],
      "id_str" : "309578964",
      "id" : 309578964
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "756062853732392960",
  "geo" : { },
  "id_str" : "756096644400152576",
  "in_reply_to_user_id" : 43409552,
  "text" : "@TESOLacademic @angelos_bollas 3 assertions not well supported; 2nd - availabiity outside class confuses performance with learning",
  "id" : 756096644400152576,
  "in_reply_to_status_id" : 756062853732392960,
  "created_at" : "2016-07-21 12:01:02 +0000",
  "in_reply_to_screen_name" : "TESOLacademic",
  "in_reply_to_user_id_str" : "43409552",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Messenger",
      "screen_name" : "thomasmessenger",
      "indices" : [ 0, 16 ],
      "id_str" : "284105951",
      "id" : 284105951
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "756066325894668288",
  "geo" : { },
  "id_str" : "756095006159605760",
  "in_reply_to_user_id" : 284105951,
  "text" : "@thomasmessenger if anti-corbyn bods want Labour to win election unity is required no?",
  "id" : 756095006159605760,
  "in_reply_to_status_id" : 756066325894668288,
  "created_at" : "2016-07-21 11:54:31 +0000",
  "in_reply_to_screen_name" : "thomasmessenger",
  "in_reply_to_user_id_str" : "284105951",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    }, {
      "name" : "Ian Sinclair",
      "screen_name" : "IanJSinclair",
      "indices" : [ 35, 48 ],
      "id_str" : "270100506",
      "id" : 270100506
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/RKmkKpir6Z",
      "expanded_url" : "https:\/\/twitter.com\/IanJSinclair\/status\/756047763041841152",
      "display_url" : "twitter.com\/IanJSinclair\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "756094586095804416",
  "text" : "RT @johnwhilley: Great letter from @IanJSinclair https:\/\/t.co\/RKmkKpir6Z",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ian Sinclair",
        "screen_name" : "IanJSinclair",
        "indices" : [ 18, 31 ],
        "id_str" : "270100506",
        "id" : 270100506
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 32, 55 ],
        "url" : "https:\/\/t.co\/RKmkKpir6Z",
        "expanded_url" : "https:\/\/twitter.com\/IanJSinclair\/status\/756047763041841152",
        "display_url" : "twitter.com\/IanJSinclair\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "756077882141708288",
    "text" : "Great letter from @IanJSinclair https:\/\/t.co\/RKmkKpir6Z",
    "id" : 756077882141708288,
    "created_at" : "2016-07-21 10:46:29 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 756094586095804416,
  "created_at" : "2016-07-21 11:52:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen LaBont\u00E9",
      "screen_name" : "klbz",
      "indices" : [ 0, 5 ],
      "id_str" : "14811876",
      "id" : 14811876
    }, {
      "name" : "Tania Sheko",
      "screen_name" : "taniatorikova",
      "indices" : [ 6, 20 ],
      "id_str" : "91079515",
      "id" : 91079515
    }, {
      "name" : "CLMOOC",
      "screen_name" : "CLMOOC",
      "indices" : [ 21, 28 ],
      "id_str" : "2479023120",
      "id" : 2479023120
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "756060102596104192",
  "geo" : { },
  "id_str" : "756080000772833281",
  "in_reply_to_user_id" : 14811876,
  "text" : "@klbz @taniatorikova @CLMOOC ah yeah pigs flying and all",
  "id" : 756080000772833281,
  "in_reply_to_status_id" : 756060102596104192,
  "created_at" : "2016-07-21 10:54:54 +0000",
  "in_reply_to_screen_name" : "klbz",
  "in_reply_to_user_id_str" : "14811876",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Cantarutti",
      "screen_name" : "pronbites",
      "indices" : [ 0, 10 ],
      "id_str" : "2451770871",
      "id" : 2451770871
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "755945301077262336",
  "geo" : { },
  "id_str" : "756025030912409600",
  "in_reply_to_user_id" : 2451770871,
  "text" : "@pronbites ah okay thx",
  "id" : 756025030912409600,
  "in_reply_to_status_id" : 755945301077262336,
  "created_at" : "2016-07-21 07:16:28 +0000",
  "in_reply_to_screen_name" : "pronbites",
  "in_reply_to_user_id_str" : "2451770871",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tania Sheko",
      "screen_name" : "taniatorikova",
      "indices" : [ 0, 14 ],
      "id_str" : "91079515",
      "id" : 91079515
    }, {
      "name" : "CLMOOC",
      "screen_name" : "CLMOOC",
      "indices" : [ 15, 22 ],
      "id_str" : "2479023120",
      "id" : 2479023120
    }, {
      "name" : "Karen LaBont\u00E9",
      "screen_name" : "klbz",
      "indices" : [ 23, 28 ],
      "id_str" : "14811876",
      "id" : 14811876
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "755890776828018688",
  "geo" : { },
  "id_str" : "755896836259475460",
  "in_reply_to_user_id" : 91079515,
  "text" : "@taniatorikova @CLMOOC @klbz the Trump case cld be a remix if sources was initially credited?",
  "id" : 755896836259475460,
  "in_reply_to_status_id" : 755890776828018688,
  "created_at" : "2016-07-20 22:47:04 +0000",
  "in_reply_to_screen_name" : "taniatorikova",
  "in_reply_to_user_id_str" : "91079515",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "john johnston",
      "screen_name" : "johnjohnston",
      "indices" : [ 3, 16 ],
      "id_str" : "7484192",
      "id" : 7484192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/dBDH0VQVsl",
      "expanded_url" : "https:\/\/tmblr.co\/ZcpzDu29aazqz",
      "display_url" : "tmblr.co\/ZcpzDu29aazqz"
    } ]
  },
  "geo" : { },
  "id_str" : "755884432452714496",
  "text" : "RT @johnjohnston: \uD83D\uDCF7  https:\/\/t.co\/dBDH0VQVsl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 3, 26 ],
        "url" : "https:\/\/t.co\/dBDH0VQVsl",
        "expanded_url" : "https:\/\/tmblr.co\/ZcpzDu29aazqz",
        "display_url" : "tmblr.co\/ZcpzDu29aazqz"
      } ]
    },
    "geo" : { },
    "id_str" : "755884061755863040",
    "text" : "\uD83D\uDCF7  https:\/\/t.co\/dBDH0VQVsl",
    "id" : 755884061755863040,
    "created_at" : "2016-07-20 21:56:18 +0000",
    "user" : {
      "name" : "john johnston",
      "screen_name" : "johnjohnston",
      "protected" : false,
      "id_str" : "7484192",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/764409646526427136\/wENlgXJ3_normal.jpg",
      "id" : 7484192,
      "verified" : false
    }
  },
  "id" : 755884432452714496,
  "created_at" : "2016-07-20 21:57:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arika Okrent",
      "screen_name" : "arikaokrent",
      "indices" : [ 0, 12 ],
      "id_str" : "47226743",
      "id" : 47226743
    }, {
      "name" : "Marina Cantarutti",
      "screen_name" : "pronbites",
      "indices" : [ 13, 23 ],
      "id_str" : "2451770871",
      "id" : 2451770871
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "755841767073718272",
  "geo" : { },
  "id_str" : "755872387128786948",
  "in_reply_to_user_id" : 47226743,
  "text" : "@arikaokrent @pronbites woah what a tattoo! what do the red rings represent?",
  "id" : 755872387128786948,
  "in_reply_to_status_id" : 755841767073718272,
  "created_at" : "2016-07-20 21:09:55 +0000",
  "in_reply_to_screen_name" : "arikaokrent",
  "in_reply_to_user_id_str" : "47226743",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemma",
      "screen_name" : "GemmaELT",
      "indices" : [ 0, 9 ],
      "id_str" : "3380674715",
      "id" : 3380674715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "755859724751532033",
  "geo" : { },
  "id_str" : "755862403565379585",
  "in_reply_to_user_id" : 3380674715,
  "text" : "@GemmaELT or maybe better Neil Selwyn's pessimism phasers : )",
  "id" : 755862403565379585,
  "in_reply_to_status_id" : 755859724751532033,
  "created_at" : "2016-07-20 20:30:14 +0000",
  "in_reply_to_screen_name" : "GemmaELT",
  "in_reply_to_user_id_str" : "3380674715",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemma",
      "screen_name" : "GemmaELT",
      "indices" : [ 0, 9 ],
      "id_str" : "3380674715",
      "id" : 3380674715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "755859724751532033",
  "geo" : { },
  "id_str" : "755862018377322496",
  "in_reply_to_user_id" : 3380674715,
  "text" : "@GemmaELT skepticism phasers on high for sure : )",
  "id" : 755862018377322496,
  "in_reply_to_status_id" : 755859724751532033,
  "created_at" : "2016-07-20 20:28:43 +0000",
  "in_reply_to_screen_name" : "GemmaELT",
  "in_reply_to_user_id_str" : "3380674715",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Smith",
      "screen_name" : "smithsmm",
      "indices" : [ 0, 9 ],
      "id_str" : "28532658",
      "id" : 28532658
    }, {
      "name" : "Phil Beadle",
      "screen_name" : "PhilBeadle",
      "indices" : [ 10, 21 ],
      "id_str" : "50624721",
      "id" : 50624721
    }, {
      "name" : "Cristina Milos",
      "screen_name" : "surreallyno",
      "indices" : [ 22, 34 ],
      "id_str" : "87532319",
      "id" : 87532319
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "755858411263135744",
  "geo" : { },
  "id_str" : "755861298898931712",
  "in_reply_to_user_id" : 28532658,
  "text" : "@smithsmm @PhilBeadle @surreallyno given the record of the Eton educated bods we should be demanding less privately educated bods : )",
  "id" : 755861298898931712,
  "in_reply_to_status_id" : 755858411263135744,
  "created_at" : "2016-07-20 20:25:51 +0000",
  "in_reply_to_screen_name" : "smithsmm",
  "in_reply_to_user_id_str" : "28532658",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemma",
      "screen_name" : "GemmaELT",
      "indices" : [ 0, 9 ],
      "id_str" : "3380674715",
      "id" : 3380674715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "755856317005172737",
  "geo" : { },
  "id_str" : "755857542408835072",
  "in_reply_to_user_id" : 3380674715,
  "text" : "@GemmaELT blimey what did you do?",
  "id" : 755857542408835072,
  "in_reply_to_status_id" : 755856317005172737,
  "created_at" : "2016-07-20 20:10:55 +0000",
  "in_reply_to_screen_name" : "GemmaELT",
  "in_reply_to_user_id_str" : "3380674715",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MaWSIG",
      "screen_name" : "MaWSIG",
      "indices" : [ 0, 7 ],
      "id_str" : "1096618700",
      "id" : 1096618700
    }, {
      "name" : "Gemma",
      "screen_name" : "GemmaELT",
      "indices" : [ 8, 17 ],
      "id_str" : "3380674715",
      "id" : 3380674715
    }, {
      "name" : "MaWSIG",
      "screen_name" : "MaWSIG",
      "indices" : [ 18, 25 ],
      "id_str" : "1096618700",
      "id" : 1096618700
    }, {
      "name" : "Gemma",
      "screen_name" : "GemmaELT",
      "indices" : [ 26, 35 ],
      "id_str" : "3380674715",
      "id" : 3380674715
    }, {
      "name" : "Apps 4 EFL",
      "screen_name" : "apps4efl",
      "indices" : [ 68, 77 ],
      "id_str" : "2594237072",
      "id" : 2594237072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "755840143924211712",
  "geo" : { },
  "id_str" : "755854180435099648",
  "in_reply_to_user_id" : 1096618700,
  "text" : "@MaWSIG @GemmaELT @MaWSIG @GemmaELT offline:Antwordprofiler online: @apps4efl TextGenie",
  "id" : 755854180435099648,
  "in_reply_to_status_id" : 755840143924211712,
  "created_at" : "2016-07-20 19:57:34 +0000",
  "in_reply_to_screen_name" : "MaWSIG",
  "in_reply_to_user_id_str" : "1096618700",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/YBYpRI9o48",
      "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2016\/07\/cultural-minefields.html",
      "display_url" : "thecurmudgeonly.blogspot.co.uk\/2016\/07\/cultur\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "755842128534614017",
  "text" : "RT @pchallinor: New mudgeonry: Cultural minefields https:\/\/t.co\/YBYpRI9o48",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 58 ],
        "url" : "https:\/\/t.co\/YBYpRI9o48",
        "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2016\/07\/cultural-minefields.html",
        "display_url" : "thecurmudgeonly.blogspot.co.uk\/2016\/07\/cultur\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "755840946592284672",
    "text" : "New mudgeonry: Cultural minefields https:\/\/t.co\/YBYpRI9o48",
    "id" : 755840946592284672,
    "created_at" : "2016-07-20 19:04:59 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 755842128534614017,
  "created_at" : "2016-07-20 19:09:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "755833231015043072",
  "geo" : { },
  "id_str" : "755837081537155073",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava lol at comment on pre-process \"It\u2019s just a series of hard choices someone will criticize down the road.\"",
  "id" : 755837081537155073,
  "in_reply_to_status_id" : 755833231015043072,
  "created_at" : "2016-07-20 18:49:37 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Master Trainer",
      "screen_name" : "MasterTrainerPG",
      "indices" : [ 0, 16 ],
      "id_str" : "754972913011306496",
      "id" : 754972913011306496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "755832050968432640",
  "geo" : { },
  "id_str" : "755834148951040002",
  "in_reply_to_user_id" : 754972913011306496,
  "text" : "@MasterTrainerPG maybe you r thinking of teachers who want to prevent pokemon being used unprincipally in class?",
  "id" : 755834148951040002,
  "in_reply_to_status_id" : 755832050968432640,
  "created_at" : "2016-07-20 18:37:58 +0000",
  "in_reply_to_screen_name" : "MasterTrainerPG",
  "in_reply_to_user_id_str" : "754972913011306496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/H6NEIz9PC1",
      "expanded_url" : "http:\/\/sappingattention.blogspot.com\/2016\/07\/why-digital-humanists-dont-need-to.html?spref=tw",
      "display_url" : "sappingattention.blogspot.com\/2016\/07\/why-di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "755833231015043072",
  "text" : "Why Digital Humanists don't need to understand algorithms, but do need to understand transformations https:\/\/t.co\/H6NEIz9PC1",
  "id" : 755833231015043072,
  "created_at" : "2016-07-20 18:34:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "755831711703961600",
  "text" : "@MasterTrainerPG what is it teachers might prevent?",
  "id" : 755831711703961600,
  "created_at" : "2016-07-20 18:28:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "755830891314806784",
  "text" : "@MasterTrainerPG that seems to underestimate children's intelligence somwhat, and limit their agency?",
  "id" : 755830891314806784,
  "created_at" : "2016-07-20 18:25:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "755829522956689412",
  "text" : "@MasterTrainerPG I say that is a strident statement, what makes u so sure?",
  "id" : 755829522956689412,
  "created_at" : "2016-07-20 18:19:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/QMREbJY1pY",
      "expanded_url" : "http:\/\/giaklamata.blogspot.fr\/2016\/07\/fear-no-more-heat-o-sun.html",
      "display_url" : "giaklamata.blogspot.fr\/2016\/07\/fear-n\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "755826974505984000",
  "text" : "Fear no more the heat o' the sun. https:\/\/t.co\/QMREbJY1pY",
  "id" : 755826974505984000,
  "created_at" : "2016-07-20 18:09:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/ZLWSkzZBwS",
      "expanded_url" : "https:\/\/twitter.com\/LindseyAGerman\/status\/755774496854900737",
      "display_url" : "twitter.com\/LindseyAGerman\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "755823933501341697",
  "text" : "RT @johnwhilley: 85 lives snuffed out, but no mass media coverage of this terror act or probing of the perpetrators. https:\/\/t.co\/ZLWSkzZBwS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/ZLWSkzZBwS",
        "expanded_url" : "https:\/\/twitter.com\/LindseyAGerman\/status\/755774496854900737",
        "display_url" : "twitter.com\/LindseyAGerman\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "755820114457554944",
    "text" : "85 lives snuffed out, but no mass media coverage of this terror act or probing of the perpetrators. https:\/\/t.co\/ZLWSkzZBwS",
    "id" : 755820114457554944,
    "created_at" : "2016-07-20 17:42:12 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 755823933501341697,
  "created_at" : "2016-07-20 17:57:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 67, 83 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/LHMrnONGwc",
      "expanded_url" : "https:\/\/deangroom.wordpress.com\/2016\/07\/20\/should-teachers-care-about-pokemon-go\/",
      "display_url" : "deangroom.wordpress.com\/2016\/07\/20\/sho\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "755823493175009280",
  "text" : "Should teachers care about Pok\u00E9mon Go? https:\/\/t.co\/LHMrnONGwc via @wordpressdotcom",
  "id" : 755823493175009280,
  "created_at" : "2016-07-20 17:55:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Robinson",
      "screen_name" : "Trivium21c",
      "indices" : [ 83, 94 ],
      "id_str" : "99895700",
      "id" : 99895700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/N2JhkkgD3R",
      "expanded_url" : "https:\/\/martinrobborobinson.wordpress.com\/2016\/07\/20\/pokemon-go-must-we-be-servants-of-the-present-moment\/",
      "display_url" : "martinrobborobinson.wordpress.com\/2016\/07\/20\/pok\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "755820725160796160",
  "text" : "Pok\u00E9mon Go! Must We be Servants of the Present Moment? https:\/\/t.co\/N2JhkkgD3R via @trivium21c",
  "id" : 755820725160796160,
  "created_at" : "2016-07-20 17:44:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 3, 13 ],
      "id_str" : "525274103",
      "id" : 525274103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 125, 140 ],
      "url" : "https:\/\/t.co\/Xe5KoG2lrE",
      "expanded_url" : "https:\/\/twitter.com\/synthesiastica\/status\/755327722776305664",
      "display_url" : "twitter.com\/synthesiastica\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "755755723661934592",
  "text" : "RT @ElkySmith: Please, teachers, for goodness sake, read this before you start plugging or using Pokemon Go in your classes. https:\/\/t.co\/X\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/Xe5KoG2lrE",
        "expanded_url" : "https:\/\/twitter.com\/synthesiastica\/status\/755327722776305664",
        "display_url" : "twitter.com\/synthesiastica\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "755335182652022784",
    "text" : "Please, teachers, for goodness sake, read this before you start plugging or using Pokemon Go in your classes. https:\/\/t.co\/Xe5KoG2lrE",
    "id" : 755335182652022784,
    "created_at" : "2016-07-19 09:35:15 +0000",
    "user" : {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "protected" : false,
      "id_str" : "525274103",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/690658566370263041\/qggTYEb3_normal.jpg",
      "id" : 525274103,
      "verified" : false
    }
  },
  "id" : 755755723661934592,
  "created_at" : "2016-07-20 13:26:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    }, {
      "name" : "John Chrimes",
      "screen_name" : "ELTwriter",
      "indices" : [ 17, 27 ],
      "id_str" : "2464809235",
      "id" : 2464809235
    }, {
      "name" : "Julie Moore",
      "screen_name" : "lexicojules",
      "indices" : [ 28, 40 ],
      "id_str" : "424320799",
      "id" : 424320799
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "755746057674366976",
  "geo" : { },
  "id_str" : "755747726772625408",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish @ELTwriter @lexicojules oh yeah doh getting staging &amp; scaffolding mixed up thx! was associating breakdown w tasks not texts",
  "id" : 755747726772625408,
  "in_reply_to_status_id" : 755746057674366976,
  "created_at" : "2016-07-20 12:54:33 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    }, {
      "name" : "Dr Nafeez Ahmed",
      "screen_name" : "NafeezAhmed",
      "indices" : [ 109, 121 ],
      "id_str" : "110692399",
      "id" : 110692399
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Nice",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 122, 140 ],
      "url" : "https:\/\/t.co\/xQmz9pzJqh",
      "expanded_url" : "http:\/\/www.middleeasteye.net\/columns\/nice-attacks-2054902305",
      "display_url" : "middleeasteye.net\/columns\/nice-a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "755745483893698560",
  "text" : "RT @johnwhilley: Anyone can condemn, but if you want to see the contextual why, read this fine analysis from @NafeezAhmed https:\/\/t.co\/xQmz\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dr Nafeez Ahmed",
        "screen_name" : "NafeezAhmed",
        "indices" : [ 92, 104 ],
        "id_str" : "110692399",
        "id" : 110692399
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Nice",
        "indices" : [ 129, 134 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/xQmz9pzJqh",
        "expanded_url" : "http:\/\/www.middleeasteye.net\/columns\/nice-attacks-2054902305",
        "display_url" : "middleeasteye.net\/columns\/nice-a\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "755743071334178816",
    "text" : "Anyone can condemn, but if you want to see the contextual why, read this fine analysis from @NafeezAhmed https:\/\/t.co\/xQmz9pzJqh #Nice",
    "id" : 755743071334178816,
    "created_at" : "2016-07-20 12:36:03 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 755745483893698560,
  "created_at" : "2016-07-20 12:45:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    }, {
      "name" : "John Chrimes",
      "screen_name" : "ELTwriter",
      "indices" : [ 17, 27 ],
      "id_str" : "2464809235",
      "id" : 2464809235
    }, {
      "name" : "Julie Moore",
      "screen_name" : "lexicojules",
      "indices" : [ 28, 40 ],
      "id_str" : "424320799",
      "id" : 424320799
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "755743607328387072",
  "geo" : { },
  "id_str" : "755745179013873665",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish @ELTwriter @lexicojules yes an element? e.g. see article ex 3 - \"By reformulating, simplifying or exemplifying key points\"",
  "id" : 755745179013873665,
  "in_reply_to_status_id" : 755743607328387072,
  "created_at" : "2016-07-20 12:44:26 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Chrimes",
      "screen_name" : "ELTwriter",
      "indices" : [ 3, 13 ],
      "id_str" : "2464809235",
      "id" : 2464809235
    }, {
      "name" : "Julie Moore",
      "screen_name" : "lexicojules",
      "indices" : [ 119, 131 ],
      "id_str" : "424320799",
      "id" : 424320799
    }, {
      "name" : "ModernEnglishTeacher",
      "screen_name" : "ModEngTeacher",
      "indices" : [ 135, 140 ],
      "id_str" : "2364458912",
      "id" : 2364458912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/mtvvUhT0nv",
      "expanded_url" : "http:\/\/tinyurl.com\/jufbhf8",
      "display_url" : "tinyurl.com\/jufbhf8"
    } ]
  },
  "geo" : { },
  "id_str" : "755743439602520066",
  "text" : "RT @ELTwriter: Making Auth. Texts More Manageable : https:\/\/t.co\/mtvvUhT0nv \ninteresting + useful for ELT writers from @lexicojules in @Mod\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Julie Moore",
        "screen_name" : "lexicojules",
        "indices" : [ 104, 116 ],
        "id_str" : "424320799",
        "id" : 424320799
      }, {
        "name" : "ModernEnglishTeacher",
        "screen_name" : "ModEngTeacher",
        "indices" : [ 120, 134 ],
        "id_str" : "2364458912",
        "id" : 2364458912
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 60 ],
        "url" : "https:\/\/t.co\/mtvvUhT0nv",
        "expanded_url" : "http:\/\/tinyurl.com\/jufbhf8",
        "display_url" : "tinyurl.com\/jufbhf8"
      } ]
    },
    "geo" : { },
    "id_str" : "755683482689540096",
    "text" : "Making Auth. Texts More Manageable : https:\/\/t.co\/mtvvUhT0nv \ninteresting + useful for ELT writers from @lexicojules in @ModEngTeacher",
    "id" : 755683482689540096,
    "created_at" : "2016-07-20 08:39:16 +0000",
    "user" : {
      "name" : "John Chrimes",
      "screen_name" : "ELTwriter",
      "protected" : false,
      "id_str" : "2464809235",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/460507349728260097\/lvDvuOIE_normal.jpeg",
      "id" : 2464809235,
      "verified" : false
    }
  },
  "id" : 755743439602520066,
  "created_at" : "2016-07-20 12:37:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Moore",
      "screen_name" : "lexicojules",
      "indices" : [ 0, 12 ],
      "id_str" : "424320799",
      "id" : 424320799
    }, {
      "name" : "John Chrimes",
      "screen_name" : "ELTwriter",
      "indices" : [ 13, 23 ],
      "id_str" : "2464809235",
      "id" : 2464809235
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "755740797815910400",
  "geo" : { },
  "id_str" : "755742511939874817",
  "in_reply_to_user_id" : 424320799,
  "text" : "@lexicojules @ELTwriter i think staging looks like a more general term; elaborated input could be an element in staging?",
  "id" : 755742511939874817,
  "in_reply_to_status_id" : 755740797815910400,
  "created_at" : "2016-07-20 12:33:50 +0000",
  "in_reply_to_screen_name" : "lexicojules",
  "in_reply_to_user_id_str" : "424320799",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Magnus Nissel",
      "screen_name" : "u203d",
      "indices" : [ 0, 6 ],
      "id_str" : "533114985",
      "id" : 533114985
    }, {
      "name" : "TaLC 12",
      "screen_name" : "TaLCGiessen",
      "indices" : [ 7, 19 ],
      "id_str" : "4008371734",
      "id" : 4008371734
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "755725672677515265",
  "geo" : { },
  "id_str" : "755726029180772352",
  "in_reply_to_user_id" : 533114985,
  "text" : "@u203d @TaLCGiessen hope so!",
  "id" : 755726029180772352,
  "in_reply_to_status_id" : 755725672677515265,
  "created_at" : "2016-07-20 11:28:20 +0000",
  "in_reply_to_screen_name" : "u203d",
  "in_reply_to_user_id_str" : "533114985",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Poynder",
      "screen_name" : "RickyPo",
      "indices" : [ 3, 11 ],
      "id_str" : "20298671",
      "id" : 20298671
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rickypo",
      "indices" : [ 74, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/cA8V3QYwRd",
      "expanded_url" : "https:\/\/svpow.com\/2016\/07\/18\/elsevier-has-started-destroying-ssrn\/",
      "display_url" : "svpow.com\/2016\/07\/18\/els\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "755721637765476352",
  "text" : "RT @RickyPo: Elsevier has started destroying SSRN https:\/\/t.co\/cA8V3QYwRd #rickypo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "rickypo",
        "indices" : [ 61, 69 ]
      } ],
      "urls" : [ {
        "indices" : [ 37, 60 ],
        "url" : "https:\/\/t.co\/cA8V3QYwRd",
        "expanded_url" : "https:\/\/svpow.com\/2016\/07\/18\/elsevier-has-started-destroying-ssrn\/",
        "display_url" : "svpow.com\/2016\/07\/18\/els\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "755711042127265792",
    "text" : "Elsevier has started destroying SSRN https:\/\/t.co\/cA8V3QYwRd #rickypo",
    "id" : 755711042127265792,
    "created_at" : "2016-07-20 10:28:47 +0000",
    "user" : {
      "name" : "Richard Poynder",
      "screen_name" : "RickyPo",
      "protected" : false,
      "id_str" : "20298671",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3717767146\/403a01e00544bcb47a5e179a068ab4ef_normal.jpeg",
      "id" : 20298671,
      "verified" : false
    }
  },
  "id" : 755721637765476352,
  "created_at" : "2016-07-20 11:10:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    }, {
      "name" : "Roy Greenslade",
      "screen_name" : "GreensladeR",
      "indices" : [ 18, 30 ],
      "id_str" : "20326751",
      "id" : 20326751
    }, {
      "name" : "The Guardian",
      "screen_name" : "guardian",
      "indices" : [ 104, 113 ],
      "id_str" : "87818409",
      "id" : 87818409
    }, {
      "name" : "Jonathan Cook",
      "screen_name" : "Jonathan_K_Cook",
      "indices" : [ 114, 130 ],
      "id_str" : "2459644405",
      "id" : 2459644405
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Corbyn",
      "indices" : [ 87, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/6GDvOgaik6",
      "expanded_url" : "https:\/\/www.facebook.com\/Jonathan.Cook.journalist\/posts\/925066354268679",
      "display_url" : "facebook.com\/Jonathan.Cook.\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "755691967397363712",
  "text" : "RT @medialens: Hi @GreensladeR. Will you respond to criticism of your recent column on #Corbyn? E.g. ex-@guardian @Jonathan_K_Cook https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Roy Greenslade",
        "screen_name" : "GreensladeR",
        "indices" : [ 3, 15 ],
        "id_str" : "20326751",
        "id" : 20326751
      }, {
        "name" : "The Guardian",
        "screen_name" : "guardian",
        "indices" : [ 89, 98 ],
        "id_str" : "87818409",
        "id" : 87818409
      }, {
        "name" : "Jonathan Cook",
        "screen_name" : "Jonathan_K_Cook",
        "indices" : [ 99, 115 ],
        "id_str" : "2459644405",
        "id" : 2459644405
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Corbyn",
        "indices" : [ 72, 79 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/6GDvOgaik6",
        "expanded_url" : "https:\/\/www.facebook.com\/Jonathan.Cook.journalist\/posts\/925066354268679",
        "display_url" : "facebook.com\/Jonathan.Cook.\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "755685423201054720",
    "text" : "Hi @GreensladeR. Will you respond to criticism of your recent column on #Corbyn? E.g. ex-@guardian @Jonathan_K_Cook https:\/\/t.co\/6GDvOgaik6",
    "id" : 755685423201054720,
    "created_at" : "2016-07-20 08:46:59 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 755691967397363712,
  "created_at" : "2016-07-20 09:12:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aleksandra Grabowska",
      "screen_name" : "ola_grabowska8",
      "indices" : [ 0, 15 ],
      "id_str" : "746430785851428864",
      "id" : 746430785851428864
    }, {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 16, 32 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    }, {
      "name" : "Gosia Kwiatkowska",
      "screen_name" : "LessonPlansDig",
      "indices" : [ 33, 48 ],
      "id_str" : "3293928293",
      "id" : 3293928293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "755672410855202816",
  "geo" : { },
  "id_str" : "755690279542358016",
  "in_reply_to_user_id" : 746430785851428864,
  "text" : "@ola_grabowska8 @getgreatenglish @LessonPlansDig wonder about relative importance of linking vs reduced forms?",
  "id" : 755690279542358016,
  "in_reply_to_status_id" : 755672410855202816,
  "created_at" : "2016-07-20 09:06:17 +0000",
  "in_reply_to_screen_name" : "ola_grabowska8",
  "in_reply_to_user_id_str" : "746430785851428864",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aleksandra Grabowska",
      "screen_name" : "ola_grabowska8",
      "indices" : [ 3, 18 ],
      "id_str" : "746430785851428864",
      "id" : 746430785851428864
    }, {
      "name" : "Gosia Kwiatkowska",
      "screen_name" : "LessonPlansDig",
      "indices" : [ 133, 140 ],
      "id_str" : "3293928293",
      "id" : 3293928293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/VNOLFz85Ah",
      "expanded_url" : "http:\/\/www.lessonplansdigger.com\/2016\/07\/20\/pronunciation-warm-up-useless-and-useful-activities-guest-post-by-elena-mutonono\/",
      "display_url" : "lessonplansdigger.com\/2016\/07\/20\/pro\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "755689180546629632",
  "text" : "RT @ola_grabowska8: Pronunciation Warm-up: Useless and Useful Activities. Guest post by Elena Mutonono https:\/\/t.co\/VNOLFz85Ah przez @Lesso\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gosia Kwiatkowska",
        "screen_name" : "LessonPlansDig",
        "indices" : [ 113, 128 ],
        "id_str" : "3293928293",
        "id" : 3293928293
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/VNOLFz85Ah",
        "expanded_url" : "http:\/\/www.lessonplansdigger.com\/2016\/07\/20\/pronunciation-warm-up-useless-and-useful-activities-guest-post-by-elena-mutonono\/",
        "display_url" : "lessonplansdigger.com\/2016\/07\/20\/pro\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "755672410855202816",
    "text" : "Pronunciation Warm-up: Useless and Useful Activities. Guest post by Elena Mutonono https:\/\/t.co\/VNOLFz85Ah przez @LessonPlansDig",
    "id" : 755672410855202816,
    "created_at" : "2016-07-20 07:55:17 +0000",
    "user" : {
      "name" : "Aleksandra Grabowska",
      "screen_name" : "ola_grabowska8",
      "protected" : false,
      "id_str" : "746430785851428864",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/768398277226143744\/J14ZU06W_normal.jpg",
      "id" : 746430785851428864,
      "verified" : false
    }
  },
  "id" : 755689180546629632,
  "created_at" : "2016-07-20 09:01:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Chrimes",
      "screen_name" : "ELTwriter",
      "indices" : [ 0, 10 ],
      "id_str" : "2464809235",
      "id" : 2464809235
    }, {
      "name" : "Julie Moore",
      "screen_name" : "lexicojules",
      "indices" : [ 11, 23 ],
      "id_str" : "424320799",
      "id" : 424320799
    }, {
      "name" : "ModernEnglishTeacher",
      "screen_name" : "ModEngTeacher",
      "indices" : [ 24, 38 ],
      "id_str" : "2364458912",
      "id" : 2364458912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "755683482689540096",
  "geo" : { },
  "id_str" : "755684866503696384",
  "in_reply_to_user_id" : 2464809235,
  "text" : "@ELTwriter @lexicojules @ModEngTeacher is staging same as elaborated input?",
  "id" : 755684866503696384,
  "in_reply_to_status_id" : 755683482689540096,
  "created_at" : "2016-07-20 08:44:46 +0000",
  "in_reply_to_screen_name" : "ELTwriter",
  "in_reply_to_user_id_str" : "2464809235",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TEFLology Podcast",
      "screen_name" : "TEFLology",
      "indices" : [ 103, 113 ],
      "id_str" : "2882870444",
      "id" : 2882870444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/vHjtzTbmf9",
      "expanded_url" : "https:\/\/teflology-podcast.com\/2016\/07\/20\/tefl-interviews-21-shawn-loewen-on-instructed-second-language-acquisition\/",
      "display_url" : "teflology-podcast.com\/2016\/07\/20\/tef\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "755683628559073280",
  "text" : "TEFL Interviews 21: Shawn Loewen on Instructed Second Language Acquisition https:\/\/t.co\/vHjtzTbmf9 via @TEFLology",
  "id" : 755683628559073280,
  "created_at" : "2016-07-20 08:39:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "oliver caviglioli",
      "screen_name" : "olivercavigliol",
      "indices" : [ 0, 16 ],
      "id_str" : "571989515",
      "id" : 571989515
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "755533256087437316",
  "geo" : { },
  "id_str" : "755533812466065408",
  "in_reply_to_user_id" : 18602422,
  "text" : "@olivercavigliol &amp; indepedent of subject matter?",
  "id" : 755533812466065408,
  "in_reply_to_status_id" : 755533256087437316,
  "created_at" : "2016-07-19 22:44:32 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "oliver caviglioli",
      "screen_name" : "olivercavigliol",
      "indices" : [ 0, 16 ],
      "id_str" : "571989515",
      "id" : 571989515
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "755528139216982016",
  "geo" : { },
  "id_str" : "755533256087437316",
  "in_reply_to_user_id" : 571989515,
  "text" : "@olivercavigliol can u be prescriptive indept of audience of visual? specialised audience single words enough, non specialised 'syntax' req?",
  "id" : 755533256087437316,
  "in_reply_to_status_id" : 755528139216982016,
  "created_at" : "2016-07-19 22:42:20 +0000",
  "in_reply_to_screen_name" : "olivercavigliol",
  "in_reply_to_user_id_str" : "571989515",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "755523712238034944",
  "geo" : { },
  "id_str" : "755528705317953537",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish yr welcome great pic for pron post : )",
  "id" : 755528705317953537,
  "in_reply_to_status_id" : 755523712238034944,
  "created_at" : "2016-07-19 22:24:15 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "indices" : [ 0, 11 ],
      "id_str" : "152051625",
      "id" : 152051625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/96C6trtI2r",
      "expanded_url" : "https:\/\/juxtapose.knightlab.com\/",
      "display_url" : "juxtapose.knightlab.com"
    }, {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/RCasYdKq5P",
      "expanded_url" : "https:\/\/twitter.com\/muranava\/status\/755492735621140480",
      "display_url" : "twitter.com\/muranava\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "755528455467462656",
  "in_reply_to_user_id" : 152051625,
  "text" : "@heatherfro hi this could be of interest to you for dispersion plots? - https:\/\/t.co\/96C6trtI2r https:\/\/t.co\/RCasYdKq5P",
  "id" : 755528455467462656,
  "created_at" : "2016-07-19 22:23:15 +0000",
  "in_reply_to_screen_name" : "heatherfro",
  "in_reply_to_user_id_str" : "152051625",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "oliver caviglioli",
      "screen_name" : "olivercavigliol",
      "indices" : [ 0, 16 ],
      "id_str" : "571989515",
      "id" : 571989515
    }, {
      "name" : "Diane Leedham",
      "screen_name" : "DiLeed",
      "indices" : [ 17, 24 ],
      "id_str" : "2335217159",
      "id" : 2335217159
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "755520858471469056",
  "geo" : { },
  "id_str" : "755521816618237961",
  "in_reply_to_user_id" : 571989515,
  "text" : "@olivercavigliol @DiLeed is text not visual? a lot of text in that visual : )",
  "id" : 755521816618237961,
  "in_reply_to_status_id" : 755520858471469056,
  "created_at" : "2016-07-19 21:56:52 +0000",
  "in_reply_to_screen_name" : "olivercavigliol",
  "in_reply_to_user_id_str" : "571989515",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Claudie Graner",
      "screen_name" : "thespreadingoak",
      "indices" : [ 0, 16 ],
      "id_str" : "22363581",
      "id" : 22363581
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/755518317637566464\/photo\/1",
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/0fgnhIKZsY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cnwj4ULWgAA-I4s.jpg",
      "id_str" : "755518287887368192",
      "id" : 755518287887368192,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cnwj4ULWgAA-I4s.jpg",
      "sizes" : [ {
        "h" : 283,
        "resize" : "fit",
        "w" : 648
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 283,
        "resize" : "fit",
        "w" : 648
      }, {
        "h" : 283,
        "resize" : "fit",
        "w" : 648
      }, {
        "h" : 283,
        "resize" : "fit",
        "w" : 648
      } ],
      "display_url" : "pic.twitter.com\/0fgnhIKZsY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "755497121093214209",
  "geo" : { },
  "id_str" : "755518317637566464",
  "in_reply_to_user_id" : 22363581,
  "text" : "@thespreadingoak could use criteria by Skehan to look for differences? https:\/\/t.co\/0fgnhIKZsY",
  "id" : 755518317637566464,
  "in_reply_to_status_id" : 755497121093214209,
  "created_at" : "2016-07-19 21:42:58 +0000",
  "in_reply_to_screen_name" : "thespreadingoak",
  "in_reply_to_user_id_str" : "22363581",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Theobald",
      "screen_name" : "JamesTheo",
      "indices" : [ 0, 10 ],
      "id_str" : "87903271",
      "id" : 87903271
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/755506917632606208\/photo\/1",
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/FyyuHWv9EQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnwZaoAWIAA2aL6.jpg",
      "id_str" : "755506782697562112",
      "id" : 755506782697562112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnwZaoAWIAA2aL6.jpg",
      "sizes" : [ {
        "h" : 743,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 421,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 778,
        "resize" : "fit",
        "w" : 1256
      }, {
        "h" : 778,
        "resize" : "fit",
        "w" : 1256
      } ],
      "display_url" : "pic.twitter.com\/FyyuHWv9EQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "755493779604463616",
  "geo" : { },
  "id_str" : "755506917632606208",
  "in_reply_to_user_id" : 87903271,
  "text" : "@JamesTheo blimey letter writer reminds me of Pauline... https:\/\/t.co\/FyyuHWv9EQ",
  "id" : 755506917632606208,
  "in_reply_to_status_id" : 755493779604463616,
  "created_at" : "2016-07-19 20:57:40 +0000",
  "in_reply_to_screen_name" : "JamesTheo",
  "in_reply_to_user_id_str" : "87903271",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "grist",
      "screen_name" : "grist",
      "indices" : [ 129, 135 ],
      "id_str" : "7215512",
      "id" : 7215512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/pXdwrMBpAq",
      "expanded_url" : "http:\/\/grist.org\/business-technology\/none-of-the-worlds-top-industries-would-be-profitable-if-they-paid-for-the-natural-capital-they-use\/",
      "display_url" : "grist.org\/business-techn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "755494571082129408",
  "text" : "None of the world\u2019s top industries would be profitable if they paid for the natural capital they use https:\/\/t.co\/pXdwrMBpAq via @grist",
  "id" : 755494571082129408,
  "created_at" : "2016-07-19 20:08:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Chilcot",
      "indices" : [ 69, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/BWNBWugL09",
      "expanded_url" : "https:\/\/cdn.knightlab.com\/libs\/juxtapose\/latest\/embed\/index.html?uid=5f281f38-4deb-11e6-8309-0e7075bba956",
      "display_url" : "cdn.knightlab.com\/libs\/juxtapose\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "755488143307046912",
  "geo" : { },
  "id_str" : "755492735621140480",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava Blair vs WMD dispersion difference https:\/\/t.co\/BWNBWugL09 #Chilcot",
  "id" : 755492735621140480,
  "in_reply_to_status_id" : 755488143307046912,
  "created_at" : "2016-07-19 20:01:19 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/WuirTjuJjC",
      "expanded_url" : "https:\/\/cdn.knightlab.com\/libs\/juxtapose\/latest\/embed\/index.html?uid=f3006c36-4de8-11e6-8309-0e7075bba956",
      "display_url" : "cdn.knightlab.com\/libs\/juxtapose\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "755482847440465920",
  "geo" : { },
  "id_str" : "755488143307046912",
  "in_reply_to_user_id" : 18602422,
  "text" : "spot the difference test 2 https:\/\/t.co\/WuirTjuJjC",
  "id" : 755488143307046912,
  "in_reply_to_status_id" : 755482847440465920,
  "created_at" : "2016-07-19 19:43:04 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "indices" : [ 94, 109 ],
      "id_str" : "152194866",
      "id" : 152194866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltpics",
      "indices" : [ 34, 42 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/xnsTGSTDkm",
      "expanded_url" : "https:\/\/cdn.knightlab.com\/libs\/juxtapose\/latest\/embed\/index.html?uid=e4d1e2a0-4de5-11e6-8309-0e7075bba956",
      "display_url" : "cdn.knightlab.com\/libs\/juxtapose\u2026"
    }, {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/96C6trtI2r",
      "expanded_url" : "https:\/\/juxtapose.knightlab.com\/",
      "display_url" : "juxtapose.knightlab.com"
    } ]
  },
  "geo" : { },
  "id_str" : "755482847440465920",
  "text" : "https:\/\/t.co\/xnsTGSTDkm neato thx #eltpics playing with juxtapose https:\/\/t.co\/96C6trtI2r h\/t @patrickDurusau",
  "id" : 755482847440465920,
  "created_at" : "2016-07-19 19:22:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "indices" : [ 0, 10 ],
      "id_str" : "577931950",
      "id" : 577931950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "755457695826710528",
  "geo" : { },
  "id_str" : "755460246781456385",
  "in_reply_to_user_id" : 577931950,
  "text" : "@RudyLoock avec plaisir : )",
  "id" : 755460246781456385,
  "in_reply_to_status_id" : 755457695826710528,
  "created_at" : "2016-07-19 17:52:13 +0000",
  "in_reply_to_screen_name" : "RudyLoock",
  "in_reply_to_user_id_str" : "577931950",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "indices" : [ 3, 13 ],
      "id_str" : "577931950",
      "id" : 577931950
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/RudyLoock\/status\/755307777724190721\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/Chq0rZMqb4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CntkRGrWYAEh-55.jpg",
      "id_str" : "755307607527677953",
      "id" : 755307607527677953,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CntkRGrWYAEh-55.jpg",
      "sizes" : [ {
        "h" : 692,
        "resize" : "fit",
        "w" : 458
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 450
      }, {
        "h" : 692,
        "resize" : "fit",
        "w" : 458
      }, {
        "h" : 692,
        "resize" : "fit",
        "w" : 458
      } ],
      "display_url" : "pic.twitter.com\/Chq0rZMqb4"
    } ],
    "hashtags" : [ {
      "text" : "Traductologie",
      "indices" : [ 19, 33 ]
    }, {
      "text" : "Corpus",
      "indices" : [ 37, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/3SsU9gRwb7",
      "expanded_url" : "https:\/\/www.amazon.fr\/dp\/2757413910\/ref=cm_sw_r_tw_dp_3PDJxbFZVCQ00",
      "display_url" : "amazon.fr\/dp\/2757413910\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "755456021720694784",
  "text" : "RT @RudyLoock: \"La #Traductologie de #Corpus\" est d\u00E9sormais en pr\u00E9commande sur Amazon (sortie octobre) :  https:\/\/t.co\/3SsU9gRwb7 https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/RudyLoock\/status\/755307777724190721\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/Chq0rZMqb4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CntkRGrWYAEh-55.jpg",
        "id_str" : "755307607527677953",
        "id" : 755307607527677953,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CntkRGrWYAEh-55.jpg",
        "sizes" : [ {
          "h" : 692,
          "resize" : "fit",
          "w" : 458
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 450
        }, {
          "h" : 692,
          "resize" : "fit",
          "w" : 458
        }, {
          "h" : 692,
          "resize" : "fit",
          "w" : 458
        } ],
        "display_url" : "pic.twitter.com\/Chq0rZMqb4"
      } ],
      "hashtags" : [ {
        "text" : "Traductologie",
        "indices" : [ 4, 18 ]
      }, {
        "text" : "Corpus",
        "indices" : [ 22, 29 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/3SsU9gRwb7",
        "expanded_url" : "https:\/\/www.amazon.fr\/dp\/2757413910\/ref=cm_sw_r_tw_dp_3PDJxbFZVCQ00",
        "display_url" : "amazon.fr\/dp\/2757413910\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "755307777724190721",
    "text" : "\"La #Traductologie de #Corpus\" est d\u00E9sormais en pr\u00E9commande sur Amazon (sortie octobre) :  https:\/\/t.co\/3SsU9gRwb7 https:\/\/t.co\/Chq0rZMqb4",
    "id" : 755307777724190721,
    "created_at" : "2016-07-19 07:46:21 +0000",
    "user" : {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "protected" : false,
      "id_str" : "577931950",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2370874884\/qm10et5v1fyzwixh651s_normal.jpeg",
      "id" : 577931950,
      "verified" : false
    }
  },
  "id" : 755456021720694784,
  "created_at" : "2016-07-19 17:35:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 48, 64 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/noU00pGJp8",
      "expanded_url" : "https:\/\/freelanceteacherselfdevelopment.wordpress.com\/2016\/07\/19\/pro-nun-see-haitian\/",
      "display_url" : "\u2026eteacherselfdevelopment.wordpress.com\/2016\/07\/19\/pro\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "755444426412032000",
  "text" : "Pro-Nun See Haitian https:\/\/t.co\/noU00pGJp8 via @getgreatenglish",
  "id" : 755444426412032000,
  "created_at" : "2016-07-19 16:49:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 0, 9 ],
      "id_str" : "134211317",
      "id" : 134211317
    }, {
      "name" : "Roy Greenslade",
      "screen_name" : "RoyGreenslade",
      "indices" : [ 10, 24 ],
      "id_str" : "3233996196",
      "id" : 3233996196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/Ku8pQdZcTf",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=8M6x1H08aFc",
      "display_url" : "youtube.com\/watch?v=8M6x1H\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "755411121012703233",
  "geo" : { },
  "id_str" : "755441867307773952",
  "in_reply_to_user_id" : 134211317,
  "text" : "@josipa74 @RoyGreenslade guess he believes all that negative coverage is \"just words\" https:\/\/t.co\/Ku8pQdZcTf",
  "id" : 755441867307773952,
  "in_reply_to_status_id" : 755411121012703233,
  "created_at" : "2016-07-19 16:39:11 +0000",
  "in_reply_to_screen_name" : "josipa74",
  "in_reply_to_user_id_str" : "134211317",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/GriXWvDlCT",
      "expanded_url" : "https:\/\/www.theguardian.com\/uk-news\/2016\/jul\/19\/iraq-war-families-crowdsource-for-funds-to-sue-tony-blair",
      "display_url" : "theguardian.com\/uk-news\/2016\/j\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "755387067941748736",
  "text" : "RT @pchallinor: Soldiers' families crowdsource for funds to sue the Ascended Incarnation of the Reverend Blair https:\/\/t.co\/GriXWvDlCT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/GriXWvDlCT",
        "expanded_url" : "https:\/\/www.theguardian.com\/uk-news\/2016\/jul\/19\/iraq-war-families-crowdsource-for-funds-to-sue-tony-blair",
        "display_url" : "theguardian.com\/uk-news\/2016\/j\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "755386007936262144",
    "text" : "Soldiers' families crowdsource for funds to sue the Ascended Incarnation of the Reverend Blair https:\/\/t.co\/GriXWvDlCT",
    "id" : 755386007936262144,
    "created_at" : "2016-07-19 12:57:13 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 755387067941748736,
  "created_at" : "2016-07-19 13:01:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 0, 9 ],
      "id_str" : "121063600",
      "id" : 121063600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "755374282247667712",
  "geo" : { },
  "id_str" : "755380855359627264",
  "in_reply_to_user_id" : 121063600,
  "text" : "@whyshona ha that's delightfully random \uD83E\uDD23",
  "id" : 755380855359627264,
  "in_reply_to_status_id" : 755374282247667712,
  "created_at" : "2016-07-19 12:36:44 +0000",
  "in_reply_to_screen_name" : "whyshona",
  "in_reply_to_user_id_str" : "121063600",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 0, 9 ],
      "id_str" : "121063600",
      "id" : 121063600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "755366197584097280",
  "geo" : { },
  "id_str" : "755367972810661888",
  "in_reply_to_user_id" : 121063600,
  "text" : "@whyshona ah that was error checking on BYU site",
  "id" : 755367972810661888,
  "in_reply_to_status_id" : 755366197584097280,
  "created_at" : "2016-07-19 11:45:33 +0000",
  "in_reply_to_screen_name" : "whyshona",
  "in_reply_to_user_id_str" : "121063600",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 0, 9 ],
      "id_str" : "121063600",
      "id" : 121063600
    }, {
      "name" : "Patricia Brenes",
      "screen_name" : "patriciambr",
      "indices" : [ 82, 94 ],
      "id_str" : "35764443",
      "id" : 35764443
    }, {
      "name" : "Maria Pia Montoro",
      "screen_name" : "WordLo",
      "indices" : [ 95, 102 ],
      "id_str" : "190569306",
      "id" : 190569306
    }, {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "indices" : [ 103, 113 ],
      "id_str" : "577931950",
      "id" : 577931950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "755360539409252352",
  "geo" : { },
  "id_str" : "755362705872125953",
  "in_reply_to_user_id" : 121063600,
  "text" : "@whyshona hi nice Q, top of my head apart from Wikipedia can't think of one maybe @patriciambr @WordLo @RudyLoock can help?",
  "id" : 755362705872125953,
  "in_reply_to_status_id" : 755360539409252352,
  "created_at" : "2016-07-19 11:24:37 +0000",
  "in_reply_to_screen_name" : "whyshona",
  "in_reply_to_user_id_str" : "121063600",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "indices" : [ 3, 13 ],
      "id_str" : "577931950",
      "id" : 577931950
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/RudyLoock\/status\/755308701385420802\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/tTf3SC35Ee",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cntk3ixXYAACKzt.jpg",
      "id_str" : "755308267904131072",
      "id" : 755308267904131072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cntk3ixXYAACKzt.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 511
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 511
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 511
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 511
      } ],
      "display_url" : "pic.twitter.com\/tTf3SC35Ee"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/RudyLoock\/status\/755308701385420802\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/tTf3SC35Ee",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cntk4tzWEAEocFX.jpg",
      "id_str" : "755308288045092865",
      "id" : 755308288045092865,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cntk4tzWEAEocFX.jpg",
      "sizes" : [ {
        "h" : 362,
        "resize" : "fit",
        "w" : 531
      }, {
        "h" : 362,
        "resize" : "fit",
        "w" : 531
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 362,
        "resize" : "fit",
        "w" : 531
      }, {
        "h" : 362,
        "resize" : "fit",
        "w" : 531
      } ],
      "display_url" : "pic.twitter.com\/tTf3SC35Ee"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "755345041451786240",
  "text" : "RT @RudyLoock: canicule vs chaleur: quel environnement linguistique pour quelle prosodie s\u00E9mantique? (via corpus fran\u00E7ais Leipzig) https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/RudyLoock\/status\/755308701385420802\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/tTf3SC35Ee",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cntk3ixXYAACKzt.jpg",
        "id_str" : "755308267904131072",
        "id" : 755308267904131072,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cntk3ixXYAACKzt.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 511
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 511
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 511
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 511
        } ],
        "display_url" : "pic.twitter.com\/tTf3SC35Ee"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/RudyLoock\/status\/755308701385420802\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/tTf3SC35Ee",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cntk4tzWEAEocFX.jpg",
        "id_str" : "755308288045092865",
        "id" : 755308288045092865,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cntk4tzWEAEocFX.jpg",
        "sizes" : [ {
          "h" : 362,
          "resize" : "fit",
          "w" : 531
        }, {
          "h" : 362,
          "resize" : "fit",
          "w" : 531
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 362,
          "resize" : "fit",
          "w" : 531
        }, {
          "h" : 362,
          "resize" : "fit",
          "w" : 531
        } ],
        "display_url" : "pic.twitter.com\/tTf3SC35Ee"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "755308701385420802",
    "text" : "canicule vs chaleur: quel environnement linguistique pour quelle prosodie s\u00E9mantique? (via corpus fran\u00E7ais Leipzig) https:\/\/t.co\/tTf3SC35Ee",
    "id" : 755308701385420802,
    "created_at" : "2016-07-19 07:50:02 +0000",
    "user" : {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "protected" : false,
      "id_str" : "577931950",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2370874884\/qm10et5v1fyzwixh651s_normal.jpeg",
      "id" : 577931950,
      "verified" : false
    }
  },
  "id" : 755345041451786240,
  "created_at" : "2016-07-19 10:14:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 3, 18 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/GeoffreyJordan\/status\/755169404925513728\/photo\/1",
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/2QSouHAKhw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnrmkdxVUAIlv35.jpg",
      "id_str" : "755169401679204354",
      "id" : 755169401679204354,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnrmkdxVUAIlv35.jpg",
      "sizes" : [ {
        "h" : 193,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 291,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 291,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 291,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/2QSouHAKhw"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/gFU09GV0Yl",
      "expanded_url" : "https:\/\/criticalelt.wordpress.com\/2016\/07\/18\/mura-navas-quick-cups-of-coca",
      "display_url" : "criticalelt.wordpress.com\/2016\/07\/18\/mur\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "755339894642343936",
  "text" : "RT @GeoffreyJordan: Mura Nava\u2019s \u201CQuick Cups of\u00A0COCA\u201D https:\/\/t.co\/gFU09GV0Yl https:\/\/t.co\/2QSouHAKhw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/GeoffreyJordan\/status\/755169404925513728\/photo\/1",
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/2QSouHAKhw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnrmkdxVUAIlv35.jpg",
        "id_str" : "755169401679204354",
        "id" : 755169401679204354,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnrmkdxVUAIlv35.jpg",
        "sizes" : [ {
          "h" : 193,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 291,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 291,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 291,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/2QSouHAKhw"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 56 ],
        "url" : "https:\/\/t.co\/gFU09GV0Yl",
        "expanded_url" : "https:\/\/criticalelt.wordpress.com\/2016\/07\/18\/mura-navas-quick-cups-of-coca",
        "display_url" : "criticalelt.wordpress.com\/2016\/07\/18\/mur\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "755169404925513728",
    "text" : "Mura Nava\u2019s \u201CQuick Cups of\u00A0COCA\u201D https:\/\/t.co\/gFU09GV0Yl https:\/\/t.co\/2QSouHAKhw",
    "id" : 755169404925513728,
    "created_at" : "2016-07-18 22:36:31 +0000",
    "user" : {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "protected" : false,
      "id_str" : "334332424",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/455317817537986561\/SD4wNKO3_normal.jpeg",
      "id" : 334332424,
      "verified" : false
    }
  },
  "id" : 755339894642343936,
  "created_at" : "2016-07-19 09:53:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caroline Lucas",
      "screen_name" : "CarolineLucas",
      "indices" : [ 3, 17 ],
      "id_str" : "80802900",
      "id" : 80802900
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Trident",
      "indices" : [ 42, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/rhpzr2V10g",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/651a5588-5539-4702-87d8-8b5aeabbbd13",
      "display_url" : "amp.twimg.com\/v\/651a5588-553\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "755154260308951041",
  "text" : "RT @CarolineLucas: 472 MPs voted to renew #Trident tonight. 117 against, shockingly few Labour. Disappointed but the fight must go on\nhttps\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Trident",
        "indices" : [ 23, 31 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/rhpzr2V10g",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/651a5588-5539-4702-87d8-8b5aeabbbd13",
        "display_url" : "amp.twimg.com\/v\/651a5588-553\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "755151895631532032",
    "text" : "472 MPs voted to renew #Trident tonight. 117 against, shockingly few Labour. Disappointed but the fight must go on\nhttps:\/\/t.co\/rhpzr2V10g",
    "id" : 755151895631532032,
    "created_at" : "2016-07-18 21:26:56 +0000",
    "user" : {
      "name" : "Caroline Lucas",
      "screen_name" : "CarolineLucas",
      "protected" : false,
      "id_str" : "80802900",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/752787789003919361\/sFY2c3sK_normal.jpg",
      "id" : 80802900,
      "verified" : true
    }
  },
  "id" : 755154260308951041,
  "created_at" : "2016-07-18 21:36:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mhairi Black MP",
      "screen_name" : "MhairiBlack",
      "indices" : [ 3, 15 ],
      "id_str" : "120236641",
      "id" : 120236641
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/XVHOYcvgNN",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/558e9f3d-f7d2-4ecc-8f17-49a0db563360",
      "display_url" : "amp.twimg.com\/v\/558e9f3d-f7d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "755150019943100417",
  "text" : "RT @MhairiBlack: My reasons for voting against Trident renewal.\nhttps:\/\/t.co\/XVHOYcvgNN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 70 ],
        "url" : "https:\/\/t.co\/XVHOYcvgNN",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/558e9f3d-f7d2-4ecc-8f17-49a0db563360",
        "display_url" : "amp.twimg.com\/v\/558e9f3d-f7d\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "755129093859840000",
    "text" : "My reasons for voting against Trident renewal.\nhttps:\/\/t.co\/XVHOYcvgNN",
    "id" : 755129093859840000,
    "created_at" : "2016-07-18 19:56:20 +0000",
    "user" : {
      "name" : "Mhairi Black MP",
      "screen_name" : "MhairiBlack",
      "protected" : false,
      "id_str" : "120236641",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/717419655141396480\/M3t91jp6_normal.jpg",
      "id" : 120236641,
      "verified" : true
    }
  },
  "id" : 755150019943100417,
  "created_at" : "2016-07-18 21:19:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Salmond",
      "screen_name" : "AlexSalmond",
      "indices" : [ 3, 15 ],
      "id_str" : "236786367",
      "id" : 236786367
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Trident",
      "indices" : [ 106, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 125, 140 ],
      "url" : "https:\/\/t.co\/eZ22BmpBVe",
      "expanded_url" : "https:\/\/twitter.com\/thesnp\/status\/755069168907681792",
      "display_url" : "twitter.com\/thesnp\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "755133946871021568",
  "text" : "RT @AlexSalmond: The lifetime cost is just one of the reasons why I will be voting against the renewal of #Trident tonight.  https:\/\/t.co\/e\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Trident",
        "indices" : [ 89, 97 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/eZ22BmpBVe",
        "expanded_url" : "https:\/\/twitter.com\/thesnp\/status\/755069168907681792",
        "display_url" : "twitter.com\/thesnp\/status\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "755087706825297920",
    "text" : "The lifetime cost is just one of the reasons why I will be voting against the renewal of #Trident tonight.  https:\/\/t.co\/eZ22BmpBVe",
    "id" : 755087706825297920,
    "created_at" : "2016-07-18 17:11:52 +0000",
    "user" : {
      "name" : "Alex Salmond",
      "screen_name" : "AlexSalmond",
      "protected" : false,
      "id_str" : "236786367",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/757945154762379264\/tVrMVv2T_normal.jpg",
      "id" : 236786367,
      "verified" : true
    }
  },
  "id" : 755133946871021568,
  "created_at" : "2016-07-18 20:15:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grant Costello",
      "screen_name" : "GrantDCostello",
      "indices" : [ 3, 18 ],
      "id_str" : "342805351",
      "id" : 342805351
    }, {
      "name" : "Angus Robertson",
      "screen_name" : "AngusRobertson",
      "indices" : [ 21, 36 ],
      "id_str" : "31373289",
      "id" : 31373289
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/GrantDCostello\/status\/755079935979577345\/video\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/Y44gZWpZ69",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/755079459410210816\/pu\/img\/oPORQDA7JgiWaxS6.jpg",
      "id_str" : "755079459410210816",
      "id" : 755079459410210816,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/755079459410210816\/pu\/img\/oPORQDA7JgiWaxS6.jpg",
      "sizes" : [ {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Y44gZWpZ69"
    } ],
    "hashtags" : [ {
      "text" : "ScrapTrident",
      "indices" : [ 118, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "755131914290360320",
  "text" : "RT @GrantDCostello: .@AngusRobertson asks \"again and again and again\" for figures on Trident renewal, with no answer. #ScrapTrident https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Angus Robertson",
        "screen_name" : "AngusRobertson",
        "indices" : [ 1, 16 ],
        "id_str" : "31373289",
        "id" : 31373289
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/GrantDCostello\/status\/755079935979577345\/video\/1",
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/Y44gZWpZ69",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/755079459410210816\/pu\/img\/oPORQDA7JgiWaxS6.jpg",
        "id_str" : "755079459410210816",
        "id" : 755079459410210816,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/755079459410210816\/pu\/img\/oPORQDA7JgiWaxS6.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/Y44gZWpZ69"
      } ],
      "hashtags" : [ {
        "text" : "ScrapTrident",
        "indices" : [ 98, 111 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "755079935979577345",
    "text" : ".@AngusRobertson asks \"again and again and again\" for figures on Trident renewal, with no answer. #ScrapTrident https:\/\/t.co\/Y44gZWpZ69",
    "id" : 755079935979577345,
    "created_at" : "2016-07-18 16:41:00 +0000",
    "user" : {
      "name" : "Grant Costello",
      "screen_name" : "GrantDCostello",
      "protected" : false,
      "id_str" : "342805351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/753989588683747328\/O1pih3E3_normal.jpg",
      "id" : 342805351,
      "verified" : false
    }
  },
  "id" : 755131914290360320,
  "created_at" : "2016-07-18 20:07:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Kelly",
      "screen_name" : "JamesKelly",
      "indices" : [ 3, 14 ],
      "id_str" : "20165841",
      "id" : 20165841
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Trident",
      "indices" : [ 131, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "755130736320081920",
  "text" : "RT @JamesKelly: Corbyn : \"I do not consider the threat of mass murder as a legitimate way of conducting international relations.\"  #Trident",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Trident",
        "indices" : [ 115, 123 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "755069422512070656",
    "text" : "Corbyn : \"I do not consider the threat of mass murder as a legitimate way of conducting international relations.\"  #Trident",
    "id" : 755069422512070656,
    "created_at" : "2016-07-18 15:59:13 +0000",
    "user" : {
      "name" : "James Kelly",
      "screen_name" : "JamesKelly",
      "protected" : false,
      "id_str" : "20165841",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/513075256735444993\/JnuKVp0-_normal.jpeg",
      "id" : 20165841,
      "verified" : false
    }
  },
  "id" : 755130736320081920,
  "created_at" : "2016-07-18 20:02:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/XmyfeZ1hsO",
      "expanded_url" : "https:\/\/twitter.com\/sam_lavigne\/status\/755120173879885825",
      "display_url" : "twitter.com\/sam_lavigne\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "755121321705607168",
  "text" : "brill, maybe next time you could train classifier on death and taxes : ) https:\/\/t.co\/XmyfeZ1hsO",
  "id" : 755121321705607168,
  "created_at" : "2016-07-18 19:25:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate Finegan",
      "screen_name" : "kehfinegan",
      "indices" : [ 0, 11 ],
      "id_str" : "3236117203",
      "id" : 3236117203
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "755118996106739713",
  "geo" : { },
  "id_str" : "755119399904940033",
  "in_reply_to_user_id" : 3236117203,
  "text" : "@kehfinegan closer than 'festival' : )",
  "id" : 755119399904940033,
  "in_reply_to_status_id" : 755118996106739713,
  "created_at" : "2016-07-18 19:17:49 +0000",
  "in_reply_to_screen_name" : "kehfinegan",
  "in_reply_to_user_id_str" : "3236117203",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Theobald",
      "screen_name" : "JamesTheo",
      "indices" : [ 0, 10 ],
      "id_str" : "87903271",
      "id" : 87903271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "755118304268849152",
  "geo" : { },
  "id_str" : "755118561861967873",
  "in_reply_to_user_id" : 87903271,
  "text" : "@JamesTheo ah okay well at least you got time off? : )",
  "id" : 755118561861967873,
  "in_reply_to_status_id" : 755118304268849152,
  "created_at" : "2016-07-18 19:14:29 +0000",
  "in_reply_to_screen_name" : "JamesTheo",
  "in_reply_to_user_id_str" : "87903271",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Theobald",
      "screen_name" : "JamesTheo",
      "indices" : [ 0, 10 ],
      "id_str" : "87903271",
      "id" : 87903271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "755117428858839040",
  "geo" : { },
  "id_str" : "755118086341156866",
  "in_reply_to_user_id" : 87903271,
  "text" : "@JamesTheo what was context? teaching school subjects?",
  "id" : 755118086341156866,
  "in_reply_to_status_id" : 755117428858839040,
  "created_at" : "2016-07-18 19:12:35 +0000",
  "in_reply_to_screen_name" : "JamesTheo",
  "in_reply_to_user_id_str" : "87903271",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Theobald",
      "screen_name" : "JamesTheo",
      "indices" : [ 0, 10 ],
      "id_str" : "87903271",
      "id" : 87903271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "755115895714934785",
  "geo" : { },
  "id_str" : "755116794763964416",
  "in_reply_to_user_id" : 87903271,
  "text" : "@JamesTheo seems it's taken from passage on lang aquisition? if so not much debate about default process for lang acq is implicit",
  "id" : 755116794763964416,
  "in_reply_to_status_id" : 755115895714934785,
  "created_at" : "2016-07-18 19:07:27 +0000",
  "in_reply_to_screen_name" : "JamesTheo",
  "in_reply_to_user_id_str" : "87903271",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Michael Brown",
      "screen_name" : "Za_Maikeru",
      "indices" : [ 10, 21 ],
      "id_str" : "703598479944208384",
      "id" : 703598479944208384
    }, {
      "name" : "umasslinguistics",
      "screen_name" : "umasslinguistic",
      "indices" : [ 22, 38 ],
      "id_str" : "149239362",
      "id" : 149239362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "755040456010981377",
  "geo" : { },
  "id_str" : "755115146578657280",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava @Za_Maikeru @umasslinguistic thanks for sharing : )",
  "id" : 755115146578657280,
  "in_reply_to_status_id" : 755040456010981377,
  "created_at" : "2016-07-18 19:00:54 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Glenn Hadikin",
      "screen_name" : "Glenn_Hadikin",
      "indices" : [ 0, 14 ],
      "id_str" : "24455799",
      "id" : 24455799
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "755089108473610240",
  "geo" : { },
  "id_str" : "755115037086347264",
  "in_reply_to_user_id" : 24455799,
  "text" : "@Glenn_Hadikin a pleasure, code seem reasonably modifiable",
  "id" : 755115037086347264,
  "in_reply_to_status_id" : 755089108473610240,
  "created_at" : "2016-07-18 19:00:28 +0000",
  "in_reply_to_screen_name" : "Glenn_Hadikin",
  "in_reply_to_user_id_str" : "24455799",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 94, 102 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/jS84FbSG8W",
      "expanded_url" : "https:\/\/youtu.be\/rH1zeUMT6Wg",
      "display_url" : "youtu.be\/rH1zeUMT6Wg"
    } ]
  },
  "geo" : { },
  "id_str" : "755114603495976960",
  "text" : "Duncan Campbell, Secret Society, Secret Cabinet Committees (1987) https:\/\/t.co\/jS84FbSG8W via @YouTube",
  "id" : 755114603495976960,
  "created_at" : "2016-07-18 18:58:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/sJ1d01g1vg",
      "expanded_url" : "http:\/\/www.bbc.com\/news\/world-europe-36823431",
      "display_url" : "bbc.com\/news\/world-eur\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "755078310628040704",
  "text" : "BBC News - Attack on Nice: French PM Valls booed at commemoration https:\/\/t.co\/sJ1d01g1vg",
  "id" : 755078310628040704,
  "created_at" : "2016-07-18 16:34:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul johnson",
      "screen_name" : "paul__johnson",
      "indices" : [ 3, 17 ],
      "id_str" : "35720019",
      "id" : 35720019
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/W2QGmUmk6E",
      "expanded_url" : "http:\/\/www.theguardian.com\/politics\/blog\/live\/2016\/jul\/18\/trident-debate-renewal-corbyn-may-idealism-as-mps-prepare-for-trident-vote-politics-live",
      "display_url" : "theguardian.com\/politics\/blog\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "755077275150942209",
  "text" : "RT @paul__johnson: PM asked: Are you prepared to authorise nuclear strike that could kill 100k men, women and children?  May: Yes\nhttps:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/W2QGmUmk6E",
        "expanded_url" : "http:\/\/www.theguardian.com\/politics\/blog\/live\/2016\/jul\/18\/trident-debate-renewal-corbyn-may-idealism-as-mps-prepare-for-trident-vote-politics-live",
        "display_url" : "theguardian.com\/politics\/blog\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "755066373089464320",
    "text" : "PM asked: Are you prepared to authorise nuclear strike that could kill 100k men, women and children?  May: Yes\nhttps:\/\/t.co\/W2QGmUmk6E",
    "id" : 755066373089464320,
    "created_at" : "2016-07-18 15:47:06 +0000",
    "user" : {
      "name" : "Paul johnson",
      "screen_name" : "paul__johnson",
      "protected" : false,
      "id_str" : "35720019",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/980322993\/Paul_Johnson_normal.jpg",
      "id" : 35720019,
      "verified" : false
    }
  },
  "id" : 755077275150942209,
  "created_at" : "2016-07-18 16:30:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u00C9oin",
      "screen_name" : "LabourEoin",
      "indices" : [ 3, 14 ],
      "id_str" : "168090600",
      "id" : 168090600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/icEPZ9ikSD",
      "expanded_url" : "https:\/\/donate.labour.org.uk\/leadership\/1",
      "display_url" : "donate.labour.org.uk\/leadership\/1"
    } ]
  },
  "geo" : { },
  "id_str" : "755076861500264449",
  "text" : "RT @LabourEoin: Okay, you can become a registered supporter of the Labour Party by clicking this link....  )Please share widely) https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/icEPZ9ikSD",
        "expanded_url" : "https:\/\/donate.labour.org.uk\/leadership\/1",
        "display_url" : "donate.labour.org.uk\/leadership\/1"
      } ]
    },
    "geo" : { },
    "id_str" : "755076146195210240",
    "text" : "Okay, you can become a registered supporter of the Labour Party by clicking this link....  )Please share widely) https:\/\/t.co\/icEPZ9ikSD",
    "id" : 755076146195210240,
    "created_at" : "2016-07-18 16:25:56 +0000",
    "user" : {
      "name" : "\u00C9oin",
      "screen_name" : "LabourEoin",
      "protected" : false,
      "id_str" : "168090600",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/767054309792047104\/mJQBKMcG_normal.jpg",
      "id" : 168090600,
      "verified" : false
    }
  },
  "id" : 755076861500264449,
  "created_at" : "2016-07-18 16:28:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "M.K",
      "screen_name" : "usage_based",
      "indices" : [ 0, 12 ],
      "id_str" : "1479290418",
      "id" : 1479290418
    }, {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "indices" : [ 13, 23 ],
      "id_str" : "577931950",
      "id" : 577931950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "755040456010981377",
  "geo" : { },
  "id_str" : "755073020427919361",
  "in_reply_to_user_id" : 18602422,
  "text" : "@usage_based @RudyLoock thanks for RT and like : )",
  "id" : 755073020427919361,
  "in_reply_to_status_id" : 755040456010981377,
  "created_at" : "2016-07-18 16:13:31 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Glenn Hadikin",
      "screen_name" : "Glenn_Hadikin",
      "indices" : [ 0, 14 ],
      "id_str" : "24455799",
      "id" : 24455799
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/uTVPdisrUv",
      "expanded_url" : "https:\/\/twitter.com\/algoritmic\/status\/755050640490041345",
      "display_url" : "twitter.com\/algoritmic\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "755072750742564864",
  "in_reply_to_user_id" : 24455799,
  "text" : "@Glenn_Hadikin hi seen this? maybe cld simulate yr ideas of memes using code? https:\/\/t.co\/uTVPdisrUv",
  "id" : 755072750742564864,
  "created_at" : "2016-07-18 16:12:27 +0000",
  "in_reply_to_screen_name" : "Glenn_Hadikin",
  "in_reply_to_user_id_str" : "24455799",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "umasslinguistics",
      "screen_name" : "umasslinguistic",
      "indices" : [ 3, 19 ],
      "id_str" : "149239362",
      "id" : 149239362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/rvnx40pP2K",
      "expanded_url" : "http:\/\/ow.ly\/JKRL302hnyB",
      "display_url" : "ow.ly\/JKRL302hnyB"
    } ]
  },
  "geo" : { },
  "id_str" : "755049905174052866",
  "text" : "RT @umasslinguistic: The Linguistics of My Next Band Name https:\/\/t.co\/rvnx40pP2K",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 60 ],
        "url" : "https:\/\/t.co\/rvnx40pP2K",
        "expanded_url" : "http:\/\/ow.ly\/JKRL302hnyB",
        "display_url" : "ow.ly\/JKRL302hnyB"
      } ]
    },
    "geo" : { },
    "id_str" : "755036991138463744",
    "text" : "The Linguistics of My Next Band Name https:\/\/t.co\/rvnx40pP2K",
    "id" : 755036991138463744,
    "created_at" : "2016-07-18 13:50:21 +0000",
    "user" : {
      "name" : "umasslinguistics",
      "screen_name" : "umasslinguistic",
      "protected" : false,
      "id_str" : "149239362",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/427811597969408000\/oKGU1_Yi_normal.png",
      "id" : 149239362,
      "verified" : false
    }
  },
  "id" : 755049905174052866,
  "created_at" : "2016-07-18 14:41:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kenzo",
      "screen_name" : "KenzoShibata",
      "indices" : [ 3, 16 ],
      "id_str" : "348166536",
      "id" : 348166536
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/KenzoShibata\/status\/755007106688745472\/photo\/1",
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/joxmbdavux",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnpS9L8VUAAepB0.jpg",
      "id_str" : "755007098669322240",
      "id" : 755007098669322240,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnpS9L8VUAAepB0.jpg",
      "sizes" : [ {
        "h" : 519,
        "resize" : "fit",
        "w" : 703
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 502,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 519,
        "resize" : "fit",
        "w" : 703
      }, {
        "h" : 519,
        "resize" : "fit",
        "w" : 703
      } ],
      "display_url" : "pic.twitter.com\/joxmbdavux"
    } ],
    "hashtags" : [ {
      "text" : "AllLivesMatter",
      "indices" : [ 39, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "755045893221576704",
  "text" : "RT @KenzoShibata: Look, it's the first #AllLivesMatter rally. https:\/\/t.co\/joxmbdavux",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/KenzoShibata\/status\/755007106688745472\/photo\/1",
        "indices" : [ 44, 67 ],
        "url" : "https:\/\/t.co\/joxmbdavux",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnpS9L8VUAAepB0.jpg",
        "id_str" : "755007098669322240",
        "id" : 755007098669322240,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnpS9L8VUAAepB0.jpg",
        "sizes" : [ {
          "h" : 519,
          "resize" : "fit",
          "w" : 703
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 502,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 519,
          "resize" : "fit",
          "w" : 703
        }, {
          "h" : 519,
          "resize" : "fit",
          "w" : 703
        } ],
        "display_url" : "pic.twitter.com\/joxmbdavux"
      } ],
      "hashtags" : [ {
        "text" : "AllLivesMatter",
        "indices" : [ 21, 36 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "755007106688745472",
    "text" : "Look, it's the first #AllLivesMatter rally. https:\/\/t.co\/joxmbdavux",
    "id" : 755007106688745472,
    "created_at" : "2016-07-18 11:51:36 +0000",
    "user" : {
      "name" : "Kenzo",
      "screen_name" : "KenzoShibata",
      "protected" : false,
      "id_str" : "348166536",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/752327009808900096\/vFRIHP3H_normal.jpg",
      "id" : 348166536,
      "verified" : false
    }
  },
  "id" : 755045893221576704,
  "created_at" : "2016-07-18 14:25:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/pOHVKlgFzb",
      "expanded_url" : "https:\/\/eflnotes.wordpress.com\/2016\/07\/18\/corpus-linguistics-community-news-7",
      "display_url" : "eflnotes.wordpress.com\/2016\/07\/18\/cor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "755040456010981377",
  "text" : "Corpus linguistics community news 7 https:\/\/t.co\/pOHVKlgFzb",
  "id" : 755040456010981377,
  "created_at" : "2016-07-18 14:04:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "indices" : [ 3, 18 ],
      "id_str" : "27716419",
      "id" : 27716419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/TAgTanIILl",
      "expanded_url" : "http:\/\/www.craigmurray.org.uk\/archives\/2016\/07\/far-left-entryist-takeover-labour-party\/",
      "display_url" : "craigmurray.org.uk\/archives\/2016\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "755023115252555776",
  "text" : "RT @CraigMurrayOrg: That Far Left Entryist Takeover of the Labour Party - At its height in the 1980's, Militant claimed 8,000 members. http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.craigmurray.org.uk\" rel=\"nofollow\"\u003ECraig Murray posting plugin\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/TAgTanIILl",
        "expanded_url" : "http:\/\/www.craigmurray.org.uk\/archives\/2016\/07\/far-left-entryist-takeover-labour-party\/",
        "display_url" : "craigmurray.org.uk\/archives\/2016\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "754801056555622401",
    "text" : "That Far Left Entryist Takeover of the Labour Party - At its height in the 1980's, Militant claimed 8,000 members. https:\/\/t.co\/TAgTanIILl",
    "id" : 754801056555622401,
    "created_at" : "2016-07-17 22:12:50 +0000",
    "user" : {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "protected" : false,
      "id_str" : "27716419",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1388436826\/cm_normal.jpg",
      "id" : 27716419,
      "verified" : false
    }
  },
  "id" : 755023115252555776,
  "created_at" : "2016-07-18 12:55:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "damon_tokyo",
      "screen_name" : "damon_tokyo",
      "indices" : [ 0, 12 ],
      "id_str" : "17856980",
      "id" : 17856980
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "754969157804761088",
  "geo" : { },
  "id_str" : "755009943497998336",
  "in_reply_to_user_id" : 17856980,
  "text" : "@damon_tokyo ah that explains pic \uD83D\uDE00",
  "id" : 755009943497998336,
  "in_reply_to_status_id" : 754969157804761088,
  "created_at" : "2016-07-18 12:02:52 +0000",
  "in_reply_to_screen_name" : "damon_tokyo",
  "in_reply_to_user_id_str" : "17856980",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 0, 11 ],
      "id_str" : "14663837",
      "id" : 14663837
    }, {
      "name" : "Hannah McGrath",
      "screen_name" : "Hannah_McGrath",
      "indices" : [ 12, 27 ],
      "id_str" : "373956325",
      "id" : 373956325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "755008318817636352",
  "geo" : { },
  "id_str" : "755009225089220609",
  "in_reply_to_user_id" : 14663837,
  "text" : "@pchallinor @Hannah_McGrath no doubt this unleaderly leader is pre-empting any sartorial insults by undressing so",
  "id" : 755009225089220609,
  "in_reply_to_status_id" : 755008318817636352,
  "created_at" : "2016-07-18 12:00:01 +0000",
  "in_reply_to_screen_name" : "pchallinor",
  "in_reply_to_user_id_str" : "14663837",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    }, {
      "name" : "The Sun",
      "screen_name" : "TheSun",
      "indices" : [ 50, 57 ],
      "id_str" : "34655603",
      "id" : 34655603
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BoycottTheSun",
      "indices" : [ 98, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/2urswWtaYE",
      "expanded_url" : "https:\/\/www.thesun.co.uk\/news\/1459893\/why-did-channel-4-have-a-presenter-in-a-hijab-to-front-coverage-of-muslim-terror-in-nice\/?CMP=spklr-_-Editorial-_-TWITTER-_-TheSunNewspaper-_-20160718-_-Opinion\/Columnists-_-519046507",
      "display_url" : "thesun.co.uk\/news\/1459893\/w\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "754988590661263360",
  "text" : "RT @johnwhilley: Shameless racist incitement. Can @TheSun get any uglier? https:\/\/t.co\/2urswWtaYE #BoycottTheSun",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Sun",
        "screen_name" : "TheSun",
        "indices" : [ 33, 40 ],
        "id_str" : "34655603",
        "id" : 34655603
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BoycottTheSun",
        "indices" : [ 81, 95 ]
      } ],
      "urls" : [ {
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/2urswWtaYE",
        "expanded_url" : "https:\/\/www.thesun.co.uk\/news\/1459893\/why-did-channel-4-have-a-presenter-in-a-hijab-to-front-coverage-of-muslim-terror-in-nice\/?CMP=spklr-_-Editorial-_-TWITTER-_-TheSunNewspaper-_-20160718-_-Opinion\/Columnists-_-519046507",
        "display_url" : "thesun.co.uk\/news\/1459893\/w\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "754987574117236740",
    "text" : "Shameless racist incitement. Can @TheSun get any uglier? https:\/\/t.co\/2urswWtaYE #BoycottTheSun",
    "id" : 754987574117236740,
    "created_at" : "2016-07-18 10:33:59 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 754988590661263360,
  "created_at" : "2016-07-18 10:38:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 0, 10 ],
      "id_str" : "6531902",
      "id" : 6531902
    }, {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 11, 23 ],
      "id_str" : "223771625",
      "id" : 223771625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "754950065345658880",
  "geo" : { },
  "id_str" : "754981581337554944",
  "in_reply_to_user_id" : 6531902,
  "text" : "@medialens @johnwhilley i guess it is marginally better than calling it an accident :\/",
  "id" : 754981581337554944,
  "in_reply_to_status_id" : 754950065345658880,
  "created_at" : "2016-07-18 10:10:10 +0000",
  "in_reply_to_screen_name" : "medialens",
  "in_reply_to_user_id_str" : "6531902",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "damon_tokyo",
      "screen_name" : "damon_tokyo",
      "indices" : [ 0, 12 ],
      "id_str" : "17856980",
      "id" : 17856980
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "754963153096626176",
  "geo" : { },
  "id_str" : "754965422609489920",
  "in_reply_to_user_id" : 17856980,
  "text" : "@damon_tokyo are those big hands or a small aubergine? \uD83D\uDE00",
  "id" : 754965422609489920,
  "in_reply_to_status_id" : 754963153096626176,
  "created_at" : "2016-07-18 09:05:57 +0000",
  "in_reply_to_screen_name" : "damon_tokyo",
  "in_reply_to_user_id_str" : "17856980",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harry Leslie Smith",
      "screen_name" : "Harryslaststand",
      "indices" : [ 3, 19 ],
      "id_str" : "209176493",
      "id" : 209176493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/mAiQXOKPFS",
      "expanded_url" : "https:\/\/www.theguardian.com\/commentisfree\/2016\/jul\/17\/the-guardian-view-on-the-labour-leadership-parliament-matters-most?CMP=twt_gu",
      "display_url" : "theguardian.com\/commentisfree\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "754772633254846468",
  "text" : "RT @Harryslaststand: And now an editorial for those who are comfortably off b\/c politics works for them. https:\/\/t.co\/mAiQXOKPFS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/mAiQXOKPFS",
        "expanded_url" : "https:\/\/www.theguardian.com\/commentisfree\/2016\/jul\/17\/the-guardian-view-on-the-labour-leadership-parliament-matters-most?CMP=twt_gu",
        "display_url" : "theguardian.com\/commentisfree\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "754752913730330624",
    "text" : "And now an editorial for those who are comfortably off b\/c politics works for them. https:\/\/t.co\/mAiQXOKPFS",
    "id" : 754752913730330624,
    "created_at" : "2016-07-17 19:01:31 +0000",
    "user" : {
      "name" : "Harry Leslie Smith",
      "screen_name" : "Harryslaststand",
      "protected" : false,
      "id_str" : "209176493",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/466967124255072256\/qlM2P2Lo_normal.jpeg",
      "id" : 209176493,
      "verified" : false
    }
  },
  "id" : 754772633254846468,
  "created_at" : "2016-07-17 20:19:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/754771964485595136\/photo\/1",
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/p2Ev5of4Ot",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cnl9FF4XgAU-yj7.jpg",
      "id_str" : "754771938992685061",
      "id" : 754771938992685061,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cnl9FF4XgAU-yj7.jpg",
      "sizes" : [ {
        "h" : 397,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 756,
        "resize" : "fit",
        "w" : 1295
      }, {
        "h" : 756,
        "resize" : "fit",
        "w" : 1295
      }, {
        "h" : 701,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/p2Ev5of4Ot"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/MoAttt3iVT",
      "expanded_url" : "http:\/\/corpus.byu.edu\/now\/?c=now&q=49156547",
      "display_url" : "corpus.byu.edu\/now\/?c=now&q=4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "754771964485595136",
  "text" : "crazes on the web https:\/\/t.co\/MoAttt3iVT https:\/\/t.co\/p2Ev5of4Ot",
  "id" : 754771964485595136,
  "created_at" : "2016-07-17 20:17:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Momentum",
      "screen_name" : "PeoplesMomentum",
      "indices" : [ 3, 19 ],
      "id_str" : "3751450582",
      "id" : 3751450582
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/PeoplesMomentum\/status\/754741037155946496\/video\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/QHusFNgJnz",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/754739524794781696\/pu\/img\/uajOvVtYBSx9f5Cg.jpg",
      "id_str" : "754739524794781696",
      "id" : 754739524794781696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/754739524794781696\/pu\/img\/uajOvVtYBSx9f5Cg.jpg",
      "sizes" : [ {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/QHusFNgJnz"
    } ],
    "hashtags" : [ {
      "text" : "Register4Change",
      "indices" : [ 96, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/iqe4Njs5vA",
      "expanded_url" : "http:\/\/votecheck.jeremyforlabour.com",
      "display_url" : "votecheck.jeremyforlabour.com"
    } ]
  },
  "geo" : { },
  "id_str" : "754755018415337472",
  "text" : "RT @PeoplesMomentum: Democracy should never have a price tag, but we can't afford to lose this. #Register4Change\nhttps:\/\/t.co\/iqe4Njs5vA ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/PeoplesMomentum\/status\/754741037155946496\/video\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/QHusFNgJnz",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/754739524794781696\/pu\/img\/uajOvVtYBSx9f5Cg.jpg",
        "id_str" : "754739524794781696",
        "id" : 754739524794781696,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/754739524794781696\/pu\/img\/uajOvVtYBSx9f5Cg.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/QHusFNgJnz"
      } ],
      "hashtags" : [ {
        "text" : "Register4Change",
        "indices" : [ 75, 91 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/iqe4Njs5vA",
        "expanded_url" : "http:\/\/votecheck.jeremyforlabour.com",
        "display_url" : "votecheck.jeremyforlabour.com"
      } ]
    },
    "geo" : { },
    "id_str" : "754741037155946496",
    "text" : "Democracy should never have a price tag, but we can't afford to lose this. #Register4Change\nhttps:\/\/t.co\/iqe4Njs5vA https:\/\/t.co\/QHusFNgJnz",
    "id" : 754741037155946496,
    "created_at" : "2016-07-17 18:14:20 +0000",
    "user" : {
      "name" : "Momentum",
      "screen_name" : "PeoplesMomentum",
      "protected" : false,
      "id_str" : "3751450582",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/652151443177259008\/Xv-Vm0Lo_normal.jpg",
      "id" : 3751450582,
      "verified" : false
    }
  },
  "id" : 754755018415337472,
  "created_at" : "2016-07-17 19:09:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clive Lewis MP",
      "screen_name" : "labourlewis",
      "indices" : [ 3, 15 ],
      "id_str" : "36924726",
      "id" : 36924726
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 142, 143 ],
      "url" : "https:\/\/t.co\/Ag00vz2wSC",
      "expanded_url" : "http:\/\/www.theguardian.com\/commentisfree\/2016\/jul\/15\/politics-brick-through-window-civility-fairness-debate?CMP=Share_iOSApp_Other",
      "display_url" : "theguardian.com\/commentisfree\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "754738045098729473",
  "text" : "RT @labourlewis: Politics doesn't need bricks through Windows' or civility. It needs basic fairness&gt;Best article on 'abuse' I've read https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 143 ],
        "url" : "https:\/\/t.co\/Ag00vz2wSC",
        "expanded_url" : "http:\/\/www.theguardian.com\/commentisfree\/2016\/jul\/15\/politics-brick-through-window-civility-fairness-debate?CMP=Share_iOSApp_Other",
        "display_url" : "theguardian.com\/commentisfree\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "754097105522876416",
    "text" : "Politics doesn't need bricks through Windows' or civility. It needs basic fairness&gt;Best article on 'abuse' I've read https:\/\/t.co\/Ag00vz2wSC",
    "id" : 754097105522876416,
    "created_at" : "2016-07-15 23:35:35 +0000",
    "user" : {
      "name" : "Clive Lewis MP",
      "screen_name" : "labourlewis",
      "protected" : false,
      "id_str" : "36924726",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/740905111006773248\/yPMSm87q_normal.jpg",
      "id" : 36924726,
      "verified" : true
    }
  },
  "id" : 754738045098729473,
  "created_at" : "2016-07-17 18:02:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "southwarkmomentum",
      "screen_name" : "swarkmomentum",
      "indices" : [ 3, 17 ],
      "id_str" : "4004038161",
      "id" : 4004038161
    }, {
      "name" : "Momentum",
      "screen_name" : "PeoplesMomentum",
      "indices" : [ 42, 58 ],
      "id_str" : "3751450582",
      "id" : 3751450582
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/swarkmomentum\/status\/754641480069898240\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/jZz0sf5HmT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnkGaC7XgAAK-Ah.jpg",
      "id_str" : "754641457093509120",
      "id" : 754641457093509120,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnkGaC7XgAAK-Ah.jpg",
      "sizes" : [ {
        "h" : 1530,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 1530,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 896,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 508,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/jZz0sf5HmT"
    } ],
    "hashtags" : [ {
      "text" : "babybumps",
      "indices" : [ 19, 29 ]
    }, {
      "text" : "KeepCorbyn",
      "indices" : [ 30, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "754730196859781120",
  "text" : "RT @swarkmomentum: #babybumps #KeepCorbyn @PeoplesMomentum phone banking today. Apparently this is what scary militants look like! https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Momentum",
        "screen_name" : "PeoplesMomentum",
        "indices" : [ 23, 39 ],
        "id_str" : "3751450582",
        "id" : 3751450582
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/swarkmomentum\/status\/754641480069898240\/photo\/1",
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/jZz0sf5HmT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnkGaC7XgAAK-Ah.jpg",
        "id_str" : "754641457093509120",
        "id" : 754641457093509120,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnkGaC7XgAAK-Ah.jpg",
        "sizes" : [ {
          "h" : 1530,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 1530,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 896,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 508,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/jZz0sf5HmT"
      } ],
      "hashtags" : [ {
        "text" : "babybumps",
        "indices" : [ 0, 10 ]
      }, {
        "text" : "KeepCorbyn",
        "indices" : [ 11, 22 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "754641480069898240",
    "text" : "#babybumps #KeepCorbyn @PeoplesMomentum phone banking today. Apparently this is what scary militants look like! https:\/\/t.co\/jZz0sf5HmT",
    "id" : 754641480069898240,
    "created_at" : "2016-07-17 11:38:44 +0000",
    "user" : {
      "name" : "southwarkmomentum",
      "screen_name" : "swarkmomentum",
      "protected" : false,
      "id_str" : "4004038161",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656548312594649088\/qEwl1Et3_normal.jpg",
      "id" : 4004038161,
      "verified" : false
    }
  },
  "id" : 754730196859781120,
  "created_at" : "2016-07-17 17:31:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Heraclitus",
      "screen_name" : "DreamboatSlim",
      "indices" : [ 3, 17 ],
      "id_str" : "367331132",
      "id" : 367331132
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/DreamboatSlim\/status\/754610041618038784\/video\/1",
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/MagNI1kewh",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/754609445460729860\/pu\/img\/-NX5qCZcLskgbGbV.jpg",
      "id_str" : "754609445460729860",
      "id" : 754609445460729860,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/754609445460729860\/pu\/img\/-NX5qCZcLskgbGbV.jpg",
      "sizes" : [ {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/MagNI1kewh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "754727955721547776",
  "text" : "RT @DreamboatSlim: \"austerity is good\"\n\"i agree, austerity is bad, also I am a woman\" https:\/\/t.co\/MagNI1kewh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/DreamboatSlim\/status\/754610041618038784\/video\/1",
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/MagNI1kewh",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/754609445460729860\/pu\/img\/-NX5qCZcLskgbGbV.jpg",
        "id_str" : "754609445460729860",
        "id" : 754609445460729860,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/754609445460729860\/pu\/img\/-NX5qCZcLskgbGbV.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/MagNI1kewh"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "754610041618038784",
    "text" : "\"austerity is good\"\n\"i agree, austerity is bad, also I am a woman\" https:\/\/t.co\/MagNI1kewh",
    "id" : 754610041618038784,
    "created_at" : "2016-07-17 09:33:48 +0000",
    "user" : {
      "name" : "Young Heraclitus",
      "screen_name" : "DreamboatSlim",
      "protected" : false,
      "id_str" : "367331132",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/457650079721984000\/_Os3GE-s_normal.jpeg",
      "id" : 367331132,
      "verified" : false
    }
  },
  "id" : 754727955721547776,
  "created_at" : "2016-07-17 17:22:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yasu",
      "screen_name" : "casualconc",
      "indices" : [ 0, 11 ],
      "id_str" : "132412691",
      "id" : 132412691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "754669148471308289",
  "geo" : { },
  "id_str" : "754727104407801856",
  "in_reply_to_user_id" : 132412691,
  "text" : "@casualconc yeah good idea",
  "id" : 754727104407801856,
  "in_reply_to_status_id" : 754669148471308289,
  "created_at" : "2016-07-17 17:18:58 +0000",
  "in_reply_to_screen_name" : "casualconc",
  "in_reply_to_user_id_str" : "132412691",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yasu",
      "screen_name" : "casualconc",
      "indices" : [ 0, 11 ],
      "id_str" : "132412691",
      "id" : 132412691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "754629168634048512",
  "geo" : { },
  "id_str" : "754632676666138624",
  "in_reply_to_user_id" : 132412691,
  "text" : "@casualconc ah i did not install treetagger, seems to be working now",
  "id" : 754632676666138624,
  "in_reply_to_status_id" : 754629168634048512,
  "created_at" : "2016-07-17 11:03:45 +0000",
  "in_reply_to_screen_name" : "casualconc",
  "in_reply_to_user_id_str" : "132412691",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yasu",
      "screen_name" : "casualconc",
      "indices" : [ 0, 11 ],
      "id_str" : "132412691",
      "id" : 132412691
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/754632123328372736\/photo\/1",
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/oNPKErnPnt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cnj96EtWgAEfg6r.jpg",
      "id_str" : "754632111722758145",
      "id" : 754632111722758145,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cnj96EtWgAEfg6r.jpg",
      "sizes" : [ {
        "h" : 531,
        "resize" : "fit",
        "w" : 598
      }, {
        "h" : 531,
        "resize" : "fit",
        "w" : 598
      }, {
        "h" : 531,
        "resize" : "fit",
        "w" : 598
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 531,
        "resize" : "fit",
        "w" : 598
      } ],
      "display_url" : "pic.twitter.com\/oNPKErnPnt"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "754628970553810944",
  "geo" : { },
  "id_str" : "754632123328372736",
  "in_reply_to_user_id" : 132412691,
  "text" : "@casualconc screenshot https:\/\/t.co\/oNPKErnPnt",
  "id" : 754632123328372736,
  "in_reply_to_status_id" : 754628970553810944,
  "created_at" : "2016-07-17 11:01:33 +0000",
  "in_reply_to_screen_name" : "casualconc",
  "in_reply_to_user_id_str" : "132412691",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Danny McDonald",
      "screen_name" : "interro_gator",
      "indices" : [ 0, 14 ],
      "id_str" : "2896075806",
      "id" : 2896075806
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "754618757687934977",
  "geo" : { },
  "id_str" : "754622469458239489",
  "in_reply_to_user_id" : 2896075806,
  "text" : "@interro_gator sounds good : )",
  "id" : 754622469458239489,
  "in_reply_to_status_id" : 754618757687934977,
  "created_at" : "2016-07-17 10:23:11 +0000",
  "in_reply_to_screen_name" : "interro_gator",
  "in_reply_to_user_id_str" : "2896075806",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yasu",
      "screen_name" : "casualconc",
      "indices" : [ 0, 11 ],
      "id_str" : "132412691",
      "id" : 132412691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "752019003674013698",
  "geo" : { },
  "id_str" : "754622409337085952",
  "in_reply_to_user_id" : 132412691,
  "text" : "@casualconc yes can preview files, all the file infor functions work, collocation, cluster, concord all work; just falls over in word count?",
  "id" : 754622409337085952,
  "in_reply_to_status_id" : 752019003674013698,
  "created_at" : "2016-07-17 10:22:57 +0000",
  "in_reply_to_screen_name" : "casualconc",
  "in_reply_to_user_id_str" : "132412691",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/WOIekpNmqh",
      "expanded_url" : "https:\/\/www.theguardian.com\/commentisfree\/2016\/jul\/12\/theresa-may-has-vowed-to-unite-britain-my-guess-is-against-the-poor?CMP=share_btn_tw",
      "display_url" : "theguardian.com\/commentisfree\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "754340481518145536",
  "text" : "Theresa May has vowed to unite Britain \u2013 my guess is against the poor https:\/\/t.co\/WOIekpNmqh",
  "id" : 754340481518145536,
  "created_at" : "2016-07-16 15:42:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Cook",
      "screen_name" : "Jonathan_K_Cook",
      "indices" : [ 3, 19 ],
      "id_str" : "2459644405",
      "id" : 2459644405
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/I3QCVFVbum",
      "expanded_url" : "http:\/\/mondoweiss.net\/2016\/07\/visit-dareen-tatour\/",
      "display_url" : "mondoweiss.net\/2016\/07\/visit-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "754337143053508609",
  "text" : "RT @Jonathan_K_Cook: Powerful piece on poet Dareen Tatour, arrested for writing of her fears that she would be next on Israel's hit list ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/I3QCVFVbum",
        "expanded_url" : "http:\/\/mondoweiss.net\/2016\/07\/visit-dareen-tatour\/",
        "display_url" : "mondoweiss.net\/2016\/07\/visit-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "753504679959691264",
    "text" : "Powerful piece on poet Dareen Tatour, arrested for writing of her fears that she would be next on Israel's hit list https:\/\/t.co\/I3QCVFVbum",
    "id" : 753504679959691264,
    "created_at" : "2016-07-14 08:21:29 +0000",
    "user" : {
      "name" : "Jonathan Cook",
      "screen_name" : "Jonathan_K_Cook",
      "protected" : false,
      "id_str" : "2459644405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458948119749619713\/8ed1EDoY_normal.jpeg",
      "id" : 2459644405,
      "verified" : false
    }
  },
  "id" : 754337143053508609,
  "created_at" : "2016-07-16 15:29:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "754319793633660929",
  "geo" : { },
  "id_str" : "754334411294961664",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish prisms are breakable : )",
  "id" : 754334411294961664,
  "in_reply_to_status_id" : 754319793633660929,
  "created_at" : "2016-07-16 15:18:33 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/Myq2Qx1rvU",
      "expanded_url" : "http:\/\/members5.boardhost.com\/xxxxx\/msg\/1468666104.html",
      "display_url" : "members5.boardhost.com\/xxxxx\/msg\/1468\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "754315655067815937",
  "text" : "Good Coup Bad Coup https:\/\/t.co\/Myq2Qx1rvU",
  "id" : 754315655067815937,
  "created_at" : "2016-07-16 14:04:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/rtnPeG8VlT",
      "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2016\/07\/tackling-problem-at-its-source.html",
      "display_url" : "thecurmudgeonly.blogspot.co.uk\/2016\/07\/tackli\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "754295740344786945",
  "text" : "RT @pchallinor: New mudgeonry: Tackling the problem at its source https:\/\/t.co\/rtnPeG8VlT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 73 ],
        "url" : "https:\/\/t.co\/rtnPeG8VlT",
        "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2016\/07\/tackling-problem-at-its-source.html",
        "display_url" : "thecurmudgeonly.blogspot.co.uk\/2016\/07\/tackli\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "754287861646622720",
    "text" : "New mudgeonry: Tackling the problem at its source https:\/\/t.co\/rtnPeG8VlT",
    "id" : 754287861646622720,
    "created_at" : "2016-07-16 12:13:34 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 754295740344786945,
  "created_at" : "2016-07-16 12:44:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "754288710745661441",
  "geo" : { },
  "id_str" : "754290319714295808",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin pleasure, thanks for the related links good stuff : )",
  "id" : 754290319714295808,
  "in_reply_to_status_id" : 754288710745661441,
  "created_at" : "2016-07-16 12:23:20 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 61, 77 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/OHfFbg2Ogw",
      "expanded_url" : "https:\/\/eltrantsreviewsreflections.wordpress.com\/2016\/07\/16\/get-your-linguistic-landscape-on\/",
      "display_url" : "\u2026rantsreviewsreflections.wordpress.com\/2016\/07\/16\/get\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "754288384311488512",
  "text" : "Get your Linguistic Landscape on https:\/\/t.co\/OHfFbg2Ogw via @michaelegriffin",
  "id" : 754288384311488512,
  "created_at" : "2016-07-16 12:15:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Guest",
      "screen_name" : "IaninSheffield",
      "indices" : [ 3, 18 ],
      "id_str" : "21324520",
      "id" : 21324520
    }, {
      "name" : "Matt Daniels",
      "screen_name" : "matthew_daniels",
      "indices" : [ 68, 84 ],
      "id_str" : "14328463",
      "id" : 14328463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 143, 144 ],
      "url" : "https:\/\/t.co\/X6IblnpLfp",
      "expanded_url" : "http:\/\/polygraph.cool\/history\/",
      "display_url" : "polygraph.cool\/history\/"
    } ]
  },
  "geo" : { },
  "id_str" : "754284307619913728",
  "text" : "RT @IaninSheffield: Quite stunning multimedia data visualisation by @matthew_daniels. Get your headphones on &amp; step back thro' the years ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Matt Daniels",
        "screen_name" : "matthew_daniels",
        "indices" : [ 48, 64 ],
        "id_str" : "14328463",
        "id" : 14328463
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/X6IblnpLfp",
        "expanded_url" : "http:\/\/polygraph.cool\/history\/",
        "display_url" : "polygraph.cool\/history\/"
      } ]
    },
    "geo" : { },
    "id_str" : "754242633933975552",
    "text" : "Quite stunning multimedia data visualisation by @matthew_daniels. Get your headphones on &amp; step back thro' the years https:\/\/t.co\/X6IblnpLfp",
    "id" : 754242633933975552,
    "created_at" : "2016-07-16 09:13:51 +0000",
    "user" : {
      "name" : "Ian Guest",
      "screen_name" : "IaninSheffield",
      "protected" : false,
      "id_str" : "21324520",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/476823938568163328\/boGjK4q1_normal.jpeg",
      "id" : 21324520,
      "verified" : false
    }
  },
  "id" : 754284307619913728,
  "created_at" : "2016-07-16 11:59:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/IvtgUshmLm",
      "expanded_url" : "https:\/\/www.opendemocracy.net\/uk\/bart-cammaerts-brooks-decillia-joa-o-magalha-es-and-ce-sar-jimenez-marti-nez\/when-our-watchdog-be",
      "display_url" : "opendemocracy.net\/uk\/bart-cammae\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "754270334761766912",
  "text" : "When our watchdog becomes a bloodthirsty attackdog, be wary https:\/\/t.co\/IvtgUshmLm",
  "id" : 754270334761766912,
  "created_at" : "2016-07-16 11:03:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 53, 69 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/PpXxpVTBdF",
      "expanded_url" : "https:\/\/historicalchaos.wordpress.com\/2016\/07\/15\/corbyn-the-new-puritan\/",
      "display_url" : "historicalchaos.wordpress.com\/2016\/07\/15\/cor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "754006508069879810",
  "text" : "Corbyn: The New Puritan? https:\/\/t.co\/PpXxpVTBdF via @wordpressdotcom",
  "id" : 754006508069879810,
  "created_at" : "2016-07-15 17:35:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vedrana Vojkovi\u0107",
      "screen_name" : "Ven_VVE",
      "indices" : [ 0, 8 ],
      "id_str" : "270839603",
      "id" : 270839603
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "753998352426143744",
  "geo" : { },
  "id_str" : "753999822819065856",
  "in_reply_to_user_id" : 270839603,
  "text" : "@Ven_VVE no words left after using all the swear words? : )",
  "id" : 753999822819065856,
  "in_reply_to_status_id" : 753998352426143744,
  "created_at" : "2016-07-15 17:09:01 +0000",
  "in_reply_to_screen_name" : "Ven_VVE",
  "in_reply_to_user_id_str" : "270839603",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charlotte Taylor",
      "screen_name" : "_ctaylor_",
      "indices" : [ 0, 10 ],
      "id_str" : "1428024560",
      "id" : 1428024560
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "753950342258229248",
  "geo" : { },
  "id_str" : "753950667962593280",
  "in_reply_to_user_id" : 1428024560,
  "text" : "@_ctaylor_ thanks : )",
  "id" : 753950667962593280,
  "in_reply_to_status_id" : 753950342258229248,
  "created_at" : "2016-07-15 13:53:41 +0000",
  "in_reply_to_screen_name" : "_ctaylor_",
  "in_reply_to_user_id_str" : "1428024560",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charlotte Taylor",
      "screen_name" : "_ctaylor_",
      "indices" : [ 0, 10 ],
      "id_str" : "1428024560",
      "id" : 1428024560
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/4bfP9UTaKx",
      "expanded_url" : "http:\/\/htl.linguist.univ-paris-diderot.fr\/_media\/leon\/leon_hs.pdf",
      "display_url" : "htl.linguist.univ-paris-diderot.fr\/_media\/leon\/le\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "753941310156005376",
  "geo" : { },
  "id_str" : "753949230205538304",
  "in_reply_to_user_id" : 1428024560,
  "text" : "@_ctaylor_ btw have u read this re history of CL? https:\/\/t.co\/4bfP9UTaKx",
  "id" : 753949230205538304,
  "in_reply_to_status_id" : 753941310156005376,
  "created_at" : "2016-07-15 13:47:58 +0000",
  "in_reply_to_screen_name" : "_ctaylor_",
  "in_reply_to_user_id_str" : "1428024560",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charlotte Taylor",
      "screen_name" : "_ctaylor_",
      "indices" : [ 0, 10 ],
      "id_str" : "1428024560",
      "id" : 1428024560
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "753941310156005376",
  "geo" : { },
  "id_str" : "753944646213001216",
  "in_reply_to_user_id" : 1428024560,
  "text" : "@_ctaylor_ great thanks : )",
  "id" : 753944646213001216,
  "in_reply_to_status_id" : 753941310156005376,
  "created_at" : "2016-07-15 13:29:45 +0000",
  "in_reply_to_screen_name" : "_ctaylor_",
  "in_reply_to_user_id_str" : "1428024560",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Antonio Ruiz Tinoco",
      "screen_name" : "aruiztinoco",
      "indices" : [ 0, 12 ],
      "id_str" : "26511350",
      "id" : 26511350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "753936772124454912",
  "geo" : { },
  "id_str" : "753940169603051520",
  "in_reply_to_user_id" : 26511350,
  "text" : "@aruiztinoco neat, what timezone is that graph for?",
  "id" : 753940169603051520,
  "in_reply_to_status_id" : 753936772124454912,
  "created_at" : "2016-07-15 13:11:58 +0000",
  "in_reply_to_screen_name" : "aruiztinoco",
  "in_reply_to_user_id_str" : "26511350",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Danny McDonald",
      "screen_name" : "interro_gator",
      "indices" : [ 0, 14 ],
      "id_str" : "2896075806",
      "id" : 2896075806
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "753939680471740416",
  "in_reply_to_user_id" : 2896075806,
  "text" : "@interro_gator hi have u thought about a UI that displays corpkit features according to Basic\/Intermediate\/Advanced CL use?",
  "id" : 753939680471740416,
  "created_at" : "2016-07-15 13:10:02 +0000",
  "in_reply_to_screen_name" : "interro_gator",
  "in_reply_to_user_id_str" : "2896075806",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charlotte Taylor",
      "screen_name" : "_ctaylor_",
      "indices" : [ 0, 10 ],
      "id_str" : "1428024560",
      "id" : 1428024560
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "753924087454588928",
  "geo" : { },
  "id_str" : "753937476427874305",
  "in_reply_to_user_id" : 1428024560,
  "text" : "@_ctaylor_ thks! i was wondering if there is any elaboration i can read of slide 15, the Svartik quote alongside the pic of Chomsky?",
  "id" : 753937476427874305,
  "in_reply_to_status_id" : 753924087454588928,
  "created_at" : "2016-07-15 13:01:16 +0000",
  "in_reply_to_screen_name" : "_ctaylor_",
  "in_reply_to_user_id_str" : "1428024560",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirill Soloviev",
      "screen_name" : "double_u_d",
      "indices" : [ 3, 14 ],
      "id_str" : "202274921",
      "id" : 202274921
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UK",
      "indices" : [ 20, 23 ]
    }, {
      "text" : "multilingual",
      "indices" : [ 48, 61 ]
    }, {
      "text" : "BRexit",
      "indices" : [ 68, 75 ]
    }, {
      "text" : "translation",
      "indices" : [ 118, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/aGb6JFTvue",
      "expanded_url" : "https:\/\/twitter.com\/britta_aagaard\/status\/753886748057436160",
      "display_url" : "twitter.com\/britta_aagaard\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "753925214828949504",
  "text" : "RT @double_u_d: new #UK PM wants to ditch being #multilingual after #BRexit?! what an example of missing the point of #translation! https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UK",
        "indices" : [ 4, 7 ]
      }, {
        "text" : "multilingual",
        "indices" : [ 32, 45 ]
      }, {
        "text" : "BRexit",
        "indices" : [ 52, 59 ]
      }, {
        "text" : "translation",
        "indices" : [ 102, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/aGb6JFTvue",
        "expanded_url" : "https:\/\/twitter.com\/britta_aagaard\/status\/753886748057436160",
        "display_url" : "twitter.com\/britta_aagaard\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "753921877173731328",
    "text" : "new #UK PM wants to ditch being #multilingual after #BRexit?! what an example of missing the point of #translation! https:\/\/t.co\/aGb6JFTvue",
    "id" : 753921877173731328,
    "created_at" : "2016-07-15 11:59:17 +0000",
    "user" : {
      "name" : "Kirill Soloviev",
      "screen_name" : "double_u_d",
      "protected" : false,
      "id_str" : "202274921",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/654686938528505857\/u8d4NQLe_normal.jpg",
      "id" : 202274921,
      "verified" : false
    }
  },
  "id" : 753925214828949504,
  "created_at" : "2016-07-15 12:12:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Seymour",
      "screen_name" : "leninology",
      "indices" : [ 3, 14 ],
      "id_str" : "15557246",
      "id" : 15557246
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 126, 140 ],
      "url" : "https:\/\/t.co\/CjK4ACXBVN",
      "expanded_url" : "https:\/\/twitter.com\/AaronBastani\/status\/753878645421252608",
      "display_url" : "twitter.com\/AaronBastani\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "753903596111101952",
  "text" : "RT @leninology: Politicians are very bad at Twitter. Sometimes they confuse this with the idea that they're being victimised. https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/CjK4ACXBVN",
        "expanded_url" : "https:\/\/twitter.com\/AaronBastani\/status\/753878645421252608",
        "display_url" : "twitter.com\/AaronBastani\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "753898724372471808",
    "text" : "Politicians are very bad at Twitter. Sometimes they confuse this with the idea that they're being victimised. https:\/\/t.co\/CjK4ACXBVN",
    "id" : 753898724372471808,
    "created_at" : "2016-07-15 10:27:17 +0000",
    "user" : {
      "name" : "Richard Seymour",
      "screen_name" : "leninology",
      "protected" : false,
      "id_str" : "15557246",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762344914583781377\/UDn8tMrp_normal.jpg",
      "id" : 15557246,
      "verified" : false
    }
  },
  "id" : 753903596111101952,
  "created_at" : "2016-07-15 10:46:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 3, 17 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "753895899743580160",
  "text" : "RT @audreywatters: \u201CCritics of Pokemon Go in education are bad because criticism is bad.\u201D Congrats, ed-tech bloggers. You are really winnin\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "753444278282620928",
    "text" : "\u201CCritics of Pokemon Go in education are bad because criticism is bad.\u201D Congrats, ed-tech bloggers. You are really winning with this one.",
    "id" : 753444278282620928,
    "created_at" : "2016-07-14 04:21:28 +0000",
    "user" : {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "protected" : false,
      "id_str" : "25388528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711668009723498496\/pauFZsdv_normal.jpg",
      "id" : 25388528,
      "verified" : false
    }
  },
  "id" : 753895899743580160,
  "created_at" : "2016-07-15 10:16:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Emersberger",
      "screen_name" : "rosendo_joe",
      "indices" : [ 3, 15 ],
      "id_str" : "3351345863",
      "id" : 3351345863
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/1PWe22ioBI",
      "expanded_url" : "https:\/\/twitter.com\/leninology\/status\/753543373391265792",
      "display_url" : "twitter.com\/leninology\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "753700359512662017",
  "text" : "RT @rosendo_joe: very well argued https:\/\/t.co\/1PWe22ioBI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 17, 40 ],
        "url" : "https:\/\/t.co\/1PWe22ioBI",
        "expanded_url" : "https:\/\/twitter.com\/leninology\/status\/753543373391265792",
        "display_url" : "twitter.com\/leninology\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "753699109073199106",
    "text" : "very well argued https:\/\/t.co\/1PWe22ioBI",
    "id" : 753699109073199106,
    "created_at" : "2016-07-14 21:14:05 +0000",
    "user" : {
      "name" : "Joe Emersberger",
      "screen_name" : "rosendo_joe",
      "protected" : false,
      "id_str" : "3351345863",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/621112707522142209\/OGmLR1xt_normal.jpg",
      "id" : 3351345863,
      "verified" : false
    }
  },
  "id" : 753700359512662017,
  "created_at" : "2016-07-14 21:19:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Seymour",
      "screen_name" : "leninology",
      "indices" : [ 3, 14 ],
      "id_str" : "15557246",
      "id" : 15557246
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/nZVyT48Hww",
      "expanded_url" : "https:\/\/twitter.com\/jeremyforlabour\/status\/753523306653949952",
      "display_url" : "twitter.com\/jeremyforlabou\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "753697865755684864",
  "text" : "RT @leninology: Look, let's not play this silly political game where you ask me questions about my record and I'm expected to answer https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/nZVyT48Hww",
        "expanded_url" : "https:\/\/twitter.com\/jeremyforlabour\/status\/753523306653949952",
        "display_url" : "twitter.com\/jeremyforlabou\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "753569215731339264",
    "text" : "Look, let's not play this silly political game where you ask me questions about my record and I'm expected to answer https:\/\/t.co\/nZVyT48Hww",
    "id" : 753569215731339264,
    "created_at" : "2016-07-14 12:37:56 +0000",
    "user" : {
      "name" : "Richard Seymour",
      "screen_name" : "leninology",
      "protected" : false,
      "id_str" : "15557246",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762344914583781377\/UDn8tMrp_normal.jpg",
      "id" : 15557246,
      "verified" : false
    }
  },
  "id" : 753697865755684864,
  "created_at" : "2016-07-14 21:09:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/Wyf5ZzN0Pu",
      "expanded_url" : "https:\/\/www.craigmurray.org.uk\/archives\/2016\/07\/entirely-fake-owen-smith\/",
      "display_url" : "craigmurray.org.uk\/archives\/2016\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "753546685918437378",
  "text" : "RT @pchallinor: A Labour moderate https:\/\/t.co\/Wyf5ZzN0Pu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 18, 41 ],
        "url" : "https:\/\/t.co\/Wyf5ZzN0Pu",
        "expanded_url" : "https:\/\/www.craigmurray.org.uk\/archives\/2016\/07\/entirely-fake-owen-smith\/",
        "display_url" : "craigmurray.org.uk\/archives\/2016\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "753541231062417408",
    "text" : "A Labour moderate https:\/\/t.co\/Wyf5ZzN0Pu",
    "id" : 753541231062417408,
    "created_at" : "2016-07-14 10:46:44 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 753546685918437378,
  "created_at" : "2016-07-14 11:08:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rebecca Jackson",
      "screen_name" : "chasing_ling",
      "indices" : [ 0, 13 ],
      "id_str" : "63632882",
      "id" : 63632882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "753511317965770752",
  "geo" : { },
  "id_str" : "753523684871118848",
  "in_reply_to_user_id" : 63632882,
  "text" : "@chasing_ling NOW, GLOWBE, CORE, Monco monitor corpus?",
  "id" : 753523684871118848,
  "in_reply_to_status_id" : 753511317965770752,
  "created_at" : "2016-07-14 09:37:00 +0000",
  "in_reply_to_screen_name" : "chasing_ling",
  "in_reply_to_user_id_str" : "63632882",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Chesnut",
      "screen_name" : "MichaelChesnut2",
      "indices" : [ 0, 16 ],
      "id_str" : "820940430",
      "id" : 820940430
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "753376652399251456",
  "geo" : { },
  "id_str" : "753378458248613888",
  "in_reply_to_user_id" : 820940430,
  "text" : "@MichaelChesnut2 they've no doubt written an operating manual on that under psyops :\/",
  "id" : 753378458248613888,
  "in_reply_to_status_id" : 753376652399251456,
  "created_at" : "2016-07-13 23:59:56 +0000",
  "in_reply_to_screen_name" : "MichaelChesnut2",
  "in_reply_to_user_id_str" : "820940430",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Channel 4 News",
      "screen_name" : "Channel4News",
      "indices" : [ 3, 16 ],
      "id_str" : "14569869",
      "id" : 14569869
    }, {
      "name" : "Boris Johnson",
      "screen_name" : "BorisJohnson",
      "indices" : [ 77, 90 ],
      "id_str" : "3131144855",
      "id" : 3131144855
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 126, 140 ],
      "url" : "https:\/\/t.co\/XFkfeoo8UL",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/0f9fd1e5-2a28-4aa4-9665-8068288c3c90",
      "display_url" : "amp.twimg.com\/v\/0f9fd1e5-2a2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "753374248358518784",
  "text" : "RT @Channel4News: \u201CIt\u2019s the day irony died, isn\u2019t it?\" Ken Loach responds to @BorisJohnson\u2019s appointment as Foreign Secretary\nhttps:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Boris Johnson",
        "screen_name" : "BorisJohnson",
        "indices" : [ 59, 72 ],
        "id_str" : "3131144855",
        "id" : 3131144855
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/XFkfeoo8UL",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/0f9fd1e5-2a28-4aa4-9665-8068288c3c90",
        "display_url" : "amp.twimg.com\/v\/0f9fd1e5-2a2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "753323683603558400",
    "text" : "\u201CIt\u2019s the day irony died, isn\u2019t it?\" Ken Loach responds to @BorisJohnson\u2019s appointment as Foreign Secretary\nhttps:\/\/t.co\/XFkfeoo8UL",
    "id" : 753323683603558400,
    "created_at" : "2016-07-13 20:22:16 +0000",
    "user" : {
      "name" : "Channel 4 News",
      "screen_name" : "Channel4News",
      "protected" : false,
      "id_str" : "14569869",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/670009107924037634\/D7bwdn6Q_normal.png",
      "id" : 14569869,
      "verified" : true
    }
  },
  "id" : 753374248358518784,
  "created_at" : "2016-07-13 23:43:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UnionNewsUK",
      "screen_name" : "Union_NewsUK",
      "indices" : [ 3, 16 ],
      "id_str" : "293402908",
      "id" : 293402908
    }, {
      "name" : "Unite the union",
      "screen_name" : "unitetheunion",
      "indices" : [ 74, 88 ],
      "id_str" : "20593641",
      "id" : 20593641
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Union_NewsUK\/status\/752447421142052865\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/vmR3WhiEMY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnE68H7VYAQnRrj.jpg",
      "id_str" : "752447417342058500",
      "id" : 752447417342058500,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnE68H7VYAQnRrj.jpg",
      "sizes" : [ {
        "h" : 327,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 327,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 327,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 327,
        "resize" : "fit",
        "w" : 300
      } ],
      "display_url" : "pic.twitter.com\/vmR3WhiEMY"
    } ],
    "hashtags" : [ {
      "text" : "Corbyn",
      "indices" : [ 89, 96 ]
    }, {
      "text" : "Labour",
      "indices" : [ 97, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/bjN8MDQFZn",
      "expanded_url" : "http:\/\/www.union-news.co.uk\/read-the-full-transcript-of-len-mccluskeys-speech-here\/",
      "display_url" : "union-news.co.uk\/read-the-full-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "753371960957075456",
  "text" : "RT @Union_NewsUK: Read the full transcript of Len McCluskey's speech here @unitetheunion #Corbyn #Labour https:\/\/t.co\/bjN8MDQFZn https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Unite the union",
        "screen_name" : "unitetheunion",
        "indices" : [ 56, 70 ],
        "id_str" : "20593641",
        "id" : 20593641
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Union_NewsUK\/status\/752447421142052865\/photo\/1",
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/vmR3WhiEMY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnE68H7VYAQnRrj.jpg",
        "id_str" : "752447417342058500",
        "id" : 752447417342058500,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnE68H7VYAQnRrj.jpg",
        "sizes" : [ {
          "h" : 327,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 327,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 327,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 327,
          "resize" : "fit",
          "w" : 300
        } ],
        "display_url" : "pic.twitter.com\/vmR3WhiEMY"
      } ],
      "hashtags" : [ {
        "text" : "Corbyn",
        "indices" : [ 71, 78 ]
      }, {
        "text" : "Labour",
        "indices" : [ 79, 86 ]
      } ],
      "urls" : [ {
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/bjN8MDQFZn",
        "expanded_url" : "http:\/\/www.union-news.co.uk\/read-the-full-transcript-of-len-mccluskeys-speech-here\/",
        "display_url" : "union-news.co.uk\/read-the-full-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "752447421142052865",
    "text" : "Read the full transcript of Len McCluskey's speech here @unitetheunion #Corbyn #Labour https:\/\/t.co\/bjN8MDQFZn https:\/\/t.co\/vmR3WhiEMY",
    "id" : 752447421142052865,
    "created_at" : "2016-07-11 10:20:19 +0000",
    "user" : {
      "name" : "UnionNewsUK",
      "screen_name" : "Union_NewsUK",
      "protected" : false,
      "id_str" : "293402908",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/640850696779206656\/1jed3uJq_normal.jpg",
      "id" : 293402908,
      "verified" : false
    }
  },
  "id" : 753371960957075456,
  "created_at" : "2016-07-13 23:34:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Turner",
      "screen_name" : "MattTurner4L",
      "indices" : [ 3, 16 ],
      "id_str" : "85080476",
      "id" : 85080476
    }, {
      "name" : "Novara Media",
      "screen_name" : "novaramedia",
      "indices" : [ 139, 140 ],
      "id_str" : "601148365",
      "id" : 601148365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/I1DIotn2Sv",
      "expanded_url" : "http:\/\/wire.novaramedia.com\/2016\/07\/how-can-i-deselect-my-labour-mp-a-short-guide-to-reselection-and-democratic-accountability\/",
      "display_url" : "wire.novaramedia.com\/2016\/07\/how-ca\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "753316302413062145",
  "text" : "RT @MattTurner4L: \u2018How Can I Deselect My Labour MP?\u2019 A Short Guide to Reselection and Democratic Accountability https:\/\/t.co\/I1DIotn2Sv via\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Novara Media",
        "screen_name" : "novaramedia",
        "indices" : [ 122, 134 ],
        "id_str" : "601148365",
        "id" : 601148365
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/I1DIotn2Sv",
        "expanded_url" : "http:\/\/wire.novaramedia.com\/2016\/07\/how-can-i-deselect-my-labour-mp-a-short-guide-to-reselection-and-democratic-accountability\/",
        "display_url" : "wire.novaramedia.com\/2016\/07\/how-ca\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "753259802378264576",
    "text" : "\u2018How Can I Deselect My Labour MP?\u2019 A Short Guide to Reselection and Democratic Accountability https:\/\/t.co\/I1DIotn2Sv via @novaramedia",
    "id" : 753259802378264576,
    "created_at" : "2016-07-13 16:08:26 +0000",
    "user" : {
      "name" : "Matt Turner",
      "screen_name" : "MattTurner4L",
      "protected" : false,
      "id_str" : "85080476",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/768157127588192256\/GTgRopjN_normal.jpg",
      "id" : 85080476,
      "verified" : false
    }
  },
  "id" : 753316302413062145,
  "created_at" : "2016-07-13 19:52:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/XVUwL80zfn",
      "expanded_url" : "http:\/\/www.theguardian.com\/politics\/ng-interactive\/2016\/jul\/13\/theresa-mays-speech-what-she-said-and-what-she-meant",
      "display_url" : "theguardian.com\/politics\/ng-in\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "753315559689883648",
  "text" : "RT @pchallinor: Apparently Theresa May's speech was utterly sincere. You know, the way politicians usually are https:\/\/t.co\/XVUwL80zfn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/XVUwL80zfn",
        "expanded_url" : "http:\/\/www.theguardian.com\/politics\/ng-interactive\/2016\/jul\/13\/theresa-mays-speech-what-she-said-and-what-she-meant",
        "display_url" : "theguardian.com\/politics\/ng-in\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "753298817563430912",
    "text" : "Apparently Theresa May's speech was utterly sincere. You know, the way politicians usually are https:\/\/t.co\/XVUwL80zfn",
    "id" : 753298817563430912,
    "created_at" : "2016-07-13 18:43:28 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 753315559689883648,
  "created_at" : "2016-07-13 19:50:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil Clark",
      "screen_name" : "NeilClark66",
      "indices" : [ 3, 15 ],
      "id_str" : "728039605",
      "id" : 728039605
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ChickenCoup",
      "indices" : [ 92, 104 ]
    }, {
      "text" : "Corbyn",
      "indices" : [ 105, 112 ]
    }, {
      "text" : "TheresaMay",
      "indices" : [ 113, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 125, 140 ],
      "url" : "https:\/\/t.co\/cJTSWgjk3l",
      "expanded_url" : "http:\/\/bit.ly\/29IxD6b",
      "display_url" : "bit.ly\/29IxD6b"
    } ]
  },
  "geo" : { },
  "id_str" : "753284307238719489",
  "text" : "RT @NeilClark66: My latest piece: British politics -It's The Establishment versus Democracy #ChickenCoup #Corbyn #TheresaMay https:\/\/t.co\/c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ChickenCoup",
        "indices" : [ 75, 87 ]
      }, {
        "text" : "Corbyn",
        "indices" : [ 88, 95 ]
      }, {
        "text" : "TheresaMay",
        "indices" : [ 96, 107 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/cJTSWgjk3l",
        "expanded_url" : "http:\/\/bit.ly\/29IxD6b",
        "display_url" : "bit.ly\/29IxD6b"
      } ]
    },
    "geo" : { },
    "id_str" : "753280656109625344",
    "text" : "My latest piece: British politics -It's The Establishment versus Democracy #ChickenCoup #Corbyn #TheresaMay https:\/\/t.co\/cJTSWgjk3l",
    "id" : 753280656109625344,
    "created_at" : "2016-07-13 17:31:18 +0000",
    "user" : {
      "name" : "Neil Clark",
      "screen_name" : "NeilClark66",
      "protected" : false,
      "id_str" : "728039605",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2451450991\/neil_clark_normal.png",
      "id" : 728039605,
      "verified" : false
    }
  },
  "id" : 753284307238719489,
  "created_at" : "2016-07-13 17:45:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Glenn Hadikin",
      "screen_name" : "Glenn_Hadikin",
      "indices" : [ 0, 14 ],
      "id_str" : "24455799",
      "id" : 24455799
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "753261450626490368",
  "geo" : { },
  "id_str" : "753262707487498240",
  "in_reply_to_user_id" : 24455799,
  "text" : "@Glenn_Hadikin they'd be deported before they got a chance to ask :\/",
  "id" : 753262707487498240,
  "in_reply_to_status_id" : 753261450626490368,
  "created_at" : "2016-07-13 16:19:59 +0000",
  "in_reply_to_screen_name" : "Glenn_Hadikin",
  "in_reply_to_user_id_str" : "24455799",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KOOL A.D.",
      "screen_name" : "veeveeveeveevee",
      "indices" : [ 3, 19 ],
      "id_str" : "87320284",
      "id" : 87320284
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "753259991017062400",
  "text" : "RT @veeveeveeveevee: WEIRD THAT POKEMON GO, BASICALLY A MASS SURVEILLANCE TOOL, IS BEING RELEASED AND CELEBRATED AT A TIME LIKE THIS BUT HE\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "752160537790648320",
    "text" : "WEIRD THAT POKEMON GO, BASICALLY A MASS SURVEILLANCE TOOL, IS BEING RELEASED AND CELEBRATED AT A TIME LIKE THIS BUT HEY, GOTA CATCH EM ALL",
    "id" : 752160537790648320,
    "created_at" : "2016-07-10 15:20:21 +0000",
    "user" : {
      "name" : "KOOL A.D.",
      "screen_name" : "veeveeveeveevee",
      "protected" : false,
      "id_str" : "87320284",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3290278496\/63e6e6ef113610b95961f0a5436adf5d_normal.jpeg",
      "id" : 87320284,
      "verified" : true
    }
  },
  "id" : 753259991017062400,
  "created_at" : "2016-07-13 16:09:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Faten Romdhani",
      "screen_name" : "Romdhanifaten",
      "indices" : [ 0, 14 ],
      "id_str" : "304559688",
      "id" : 304559688
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "753222690933248000",
  "geo" : { },
  "id_str" : "753223170195329025",
  "in_reply_to_user_id" : 304559688,
  "text" : "@Romdhanifaten no worries good luck : )",
  "id" : 753223170195329025,
  "in_reply_to_status_id" : 753222690933248000,
  "created_at" : "2016-07-13 13:42:52 +0000",
  "in_reply_to_screen_name" : "Romdhanifaten",
  "in_reply_to_user_id_str" : "304559688",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Faten Romdhani",
      "screen_name" : "Romdhanifaten",
      "indices" : [ 0, 14 ],
      "id_str" : "304559688",
      "id" : 304559688
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "753222025368440832",
  "geo" : { },
  "id_str" : "753222485299044352",
  "in_reply_to_user_id" : 304559688,
  "text" : "@Romdhanifaten you could use smashwords word template and their online convertor?",
  "id" : 753222485299044352,
  "in_reply_to_status_id" : 753222025368440832,
  "created_at" : "2016-07-13 13:40:09 +0000",
  "in_reply_to_screen_name" : "Romdhanifaten",
  "in_reply_to_user_id_str" : "304559688",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Brexit",
      "indices" : [ 31, 38 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/FytRItx5gT",
      "expanded_url" : "https:\/\/www.theguardian.com\/world\/2016\/jul\/13\/european-court-backs-french-women-sacked-hijab-asma-bougnaoui",
      "display_url" : "theguardian.com\/world\/2016\/jul\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "753221950990934016",
  "text" : "RT @pchallinor: Thank goodness #Brexit will enable Mad Tessie May to deal with headgear extremists https:\/\/t.co\/FytRItx5gT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Brexit",
        "indices" : [ 15, 22 ]
      } ],
      "urls" : [ {
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/FytRItx5gT",
        "expanded_url" : "https:\/\/www.theguardian.com\/world\/2016\/jul\/13\/european-court-backs-french-women-sacked-hijab-asma-bougnaoui",
        "display_url" : "theguardian.com\/world\/2016\/jul\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "753221189217189888",
    "text" : "Thank goodness #Brexit will enable Mad Tessie May to deal with headgear extremists https:\/\/t.co\/FytRItx5gT",
    "id" : 753221189217189888,
    "created_at" : "2016-07-13 13:35:00 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 753221950990934016,
  "created_at" : "2016-07-13 13:38:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/iaFpnCmexA",
      "expanded_url" : "https:\/\/hapgood.us\/2016\/07\/12\/choral-explanations-and-oer-a-summary-of-thinking-to-date\/",
      "display_url" : "hapgood.us\/2016\/07\/12\/cho\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "753170736710291456",
  "text" : "Choral Explanations and OER: A Summary of Thinking to Date https:\/\/t.co\/iaFpnCmexA",
  "id" : 753170736710291456,
  "created_at" : "2016-07-13 10:14:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/753167517737181184\/photo\/1",
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/NSQKdHR1zA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnPJ2EdWEAA9BQU.jpg",
      "id_str" : "753167493447946240",
      "id" : 753167493447946240,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnPJ2EdWEAA9BQU.jpg",
      "sizes" : [ {
        "h" : 674,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1150,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1150,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 382,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/NSQKdHR1zA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "753167517737181184",
  "text" : "Selfie-storique, the rise of the selfie continues \uD83E\uDD23 https:\/\/t.co\/NSQKdHR1zA",
  "id" : 753167517737181184,
  "created_at" : "2016-07-13 10:01:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 0, 9 ],
      "id_str" : "134211317",
      "id" : 134211317
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "752993390044778496",
  "geo" : { },
  "id_str" : "752994913164427264",
  "in_reply_to_user_id" : 134211317,
  "text" : "@josipa74 i do wonder grimly though how long they will try to bring back the dead",
  "id" : 752994913164427264,
  "in_reply_to_status_id" : 752993390044778496,
  "created_at" : "2016-07-12 22:35:51 +0000",
  "in_reply_to_screen_name" : "josipa74",
  "in_reply_to_user_id_str" : "134211317",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 0, 9 ],
      "id_str" : "134211317",
      "id" : 134211317
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "752993390044778496",
  "geo" : { },
  "id_str" : "752994391854383104",
  "in_reply_to_user_id" : 134211317,
  "text" : "@josipa74  hehe : )",
  "id" : 752994391854383104,
  "in_reply_to_status_id" : 752993390044778496,
  "created_at" : "2016-07-12 22:33:47 +0000",
  "in_reply_to_screen_name" : "josipa74",
  "in_reply_to_user_id_str" : "134211317",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Tatman",
      "screen_name" : "rctatman",
      "indices" : [ 74, 83 ],
      "id_str" : "101609102",
      "id" : 101609102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/gVjUSxsfF3",
      "expanded_url" : "https:\/\/makingnoiseandhearingthings.com\/2016\/07\/12\/googles-speech-recognition-has-a-gender-bias\/",
      "display_url" : "makingnoiseandhearingthings.com\/2016\/07\/12\/goo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "752994109330165760",
  "text" : "Google's speech recognition has a gender bias https:\/\/t.co\/gVjUSxsfF3 via @rctatman",
  "id" : 752994109330165760,
  "created_at" : "2016-07-12 22:32:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 0, 9 ],
      "id_str" : "134211317",
      "id" : 134211317
    }, {
      "name" : "Marina Hyde",
      "screen_name" : "MarinaHyde",
      "indices" : [ 10, 21 ],
      "id_str" : "308379387",
      "id" : 308379387
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "labour",
      "indices" : [ 51, 58 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "752990535401472000",
  "geo" : { },
  "id_str" : "752992129190924288",
  "in_reply_to_user_id" : 134211317,
  "text" : "@josipa74 @MarinaHyde maybe she meant the blairite #labour party?",
  "id" : 752992129190924288,
  "in_reply_to_status_id" : 752990535401472000,
  "created_at" : "2016-07-12 22:24:48 +0000",
  "in_reply_to_screen_name" : "josipa74",
  "in_reply_to_user_id_str" : "134211317",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/1P6LfIHYai",
      "expanded_url" : "https:\/\/twitter.com\/xychelsea\/status\/752676465443942401",
      "display_url" : "twitter.com\/xychelsea\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "752991242724773890",
  "text" : "RT @pchallinor: Chelsea Manning attempted to end her life, but is recovering and being brave. Again. https:\/\/t.co\/1P6LfIHYai",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/1P6LfIHYai",
        "expanded_url" : "https:\/\/twitter.com\/xychelsea\/status\/752676465443942401",
        "display_url" : "twitter.com\/xychelsea\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "752983843007819776",
    "text" : "Chelsea Manning attempted to end her life, but is recovering and being brave. Again. https:\/\/t.co\/1P6LfIHYai",
    "id" : 752983843007819776,
    "created_at" : "2016-07-12 21:51:52 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 752991242724773890,
  "created_at" : "2016-07-12 22:21:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 3, 14 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELT",
      "indices" : [ 35, 39 ]
    }, {
      "text" : "ETAI2016",
      "indices" : [ 53, 62 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 115, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/tkjY0XBYiq",
      "expanded_url" : "http:\/\/bit.ly\/29NLbfV",
      "display_url" : "bit.ly\/29NLbfV"
    } ]
  },
  "geo" : { },
  "id_str" : "752973888112427008",
  "text" : "RT @leoselivan: Leoxicon: the L in #ELT: report from #ETAI2016 which took place last week: https:\/\/t.co\/tkjY0XBYiq #eltchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELT",
        "indices" : [ 19, 23 ]
      }, {
        "text" : "ETAI2016",
        "indices" : [ 37, 46 ]
      }, {
        "text" : "eltchat",
        "indices" : [ 99, 107 ]
      } ],
      "urls" : [ {
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/tkjY0XBYiq",
        "expanded_url" : "http:\/\/bit.ly\/29NLbfV",
        "display_url" : "bit.ly\/29NLbfV"
      } ]
    },
    "geo" : { },
    "id_str" : "752967740697083904",
    "text" : "Leoxicon: the L in #ELT: report from #ETAI2016 which took place last week: https:\/\/t.co\/tkjY0XBYiq #eltchat",
    "id" : 752967740697083904,
    "created_at" : "2016-07-12 20:47:53 +0000",
    "user" : {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "protected" : false,
      "id_str" : "408365496",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/460546508601819136\/12ivDBb__normal.jpeg",
      "id" : 408365496,
      "verified" : false
    }
  },
  "id" : 752973888112427008,
  "created_at" : "2016-07-12 21:12:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FEED THE TEACHER",
      "screen_name" : "feedtheteacher",
      "indices" : [ 3, 18 ],
      "id_str" : "58839737",
      "id" : 58839737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/3HfHsRvINx",
      "expanded_url" : "https:\/\/lnkd.in\/dFAtZwx",
      "display_url" : "lnkd.in\/dFAtZwx"
    } ]
  },
  "geo" : { },
  "id_str" : "752972751678369792",
  "text" : "RT @feedtheteacher: Scientists Create Successful Biohybrid Being Using 3-D Printing and  Genetic Engineering https:\/\/t.co\/3HfHsRvINx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.linkedin.com\/\" rel=\"nofollow\"\u003ELinkedIn\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/3HfHsRvINx",
        "expanded_url" : "https:\/\/lnkd.in\/dFAtZwx",
        "display_url" : "lnkd.in\/dFAtZwx"
      } ]
    },
    "geo" : { },
    "id_str" : "752970990884360192",
    "text" : "Scientists Create Successful Biohybrid Being Using 3-D Printing and  Genetic Engineering https:\/\/t.co\/3HfHsRvINx",
    "id" : 752970990884360192,
    "created_at" : "2016-07-12 21:00:48 +0000",
    "user" : {
      "name" : "FEED THE TEACHER",
      "screen_name" : "feedtheteacher",
      "protected" : false,
      "id_str" : "58839737",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/755722190717190144\/86hxGYCb_normal.jpg",
      "id" : 58839737,
      "verified" : false
    }
  },
  "id" : 752972751678369792,
  "created_at" : "2016-07-12 21:07:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Novara Media",
      "screen_name" : "novaramedia",
      "indices" : [ 3, 15 ],
      "id_str" : "601148365",
      "id" : 601148365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/jdMbGexnpT",
      "expanded_url" : "http:\/\/novara.media\/29AGjZe",
      "display_url" : "novara.media\/29AGjZe"
    } ]
  },
  "geo" : { },
  "id_str" : "752951891315875840",
  "text" : "RT @novaramedia: 7 Tips for Corbynistas Looking to Get Stuck Into the New Leadership Campaign https:\/\/t.co\/jdMbGexnpT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/jdMbGexnpT",
        "expanded_url" : "http:\/\/novara.media\/29AGjZe",
        "display_url" : "novara.media\/29AGjZe"
      } ]
    },
    "geo" : { },
    "id_str" : "752841830434299904",
    "text" : "7 Tips for Corbynistas Looking to Get Stuck Into the New Leadership Campaign https:\/\/t.co\/jdMbGexnpT",
    "id" : 752841830434299904,
    "created_at" : "2016-07-12 12:27:34 +0000",
    "user" : {
      "name" : "Novara Media",
      "screen_name" : "novaramedia",
      "protected" : false,
      "id_str" : "601148365",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3320552679\/30bfbea4808585d60b9231291c7e65fe_normal.png",
      "id" : 601148365,
      "verified" : true
    }
  },
  "id" : 752951891315875840,
  "created_at" : "2016-07-12 19:44:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CarolineJMolloy",
      "screen_name" : "carolinejmolloy",
      "indices" : [ 3, 19 ],
      "id_str" : "62550664",
      "id" : 62550664
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LabourNEC",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "https:\/\/t.co\/mdV9uaHcvn",
      "expanded_url" : "https:\/\/www.opendemocracy.net\/ournhs\/caroline-molloy\/labour-mp-brings-bill-to-parliament-to-stop-nhs-privatisation",
      "display_url" : "opendemocracy.net\/ournhs\/carolin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "752940255733579777",
  "text" : "RT @carolinejmolloy: THIS is what Labour MPs should be prioritising, not scuppering the leader their membership wants https:\/\/t.co\/mdV9uaHc\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LabourNEC",
        "indices" : [ 121, 131 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/mdV9uaHcvn",
        "expanded_url" : "https:\/\/www.opendemocracy.net\/ournhs\/caroline-molloy\/labour-mp-brings-bill-to-parliament-to-stop-nhs-privatisation",
        "display_url" : "opendemocracy.net\/ournhs\/carolin\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "752931035353079808",
    "text" : "THIS is what Labour MPs should be prioritising, not scuppering the leader their membership wants https:\/\/t.co\/mdV9uaHcvn #LabourNEC",
    "id" : 752931035353079808,
    "created_at" : "2016-07-12 18:22:02 +0000",
    "user" : {
      "name" : "CarolineJMolloy",
      "screen_name" : "carolinejmolloy",
      "protected" : false,
      "id_str" : "62550664",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705509377818664960\/b1sUMkqD_normal.jpg",
      "id" : 62550664,
      "verified" : false
    }
  },
  "id" : 752940255733579777,
  "created_at" : "2016-07-12 18:58:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "I'm alright Jack",
      "screen_name" : "IamalrightJack",
      "indices" : [ 3, 18 ],
      "id_str" : "127666780",
      "id" : 127666780
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/jeremyforlabour\/status\/749159530408341504\/video\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/jh48et0mtY",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/749158932652912640\/pu\/img\/p6XXdU6eLYhNRzOr.jpg",
      "id_str" : "749158932652912640",
      "id" : 749158932652912640,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/749158932652912640\/pu\/img\/p6XXdU6eLYhNRzOr.jpg",
      "sizes" : [ {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/jh48et0mtY"
    } ],
    "hashtags" : [ {
      "text" : "LabourNEC",
      "indices" : [ 20, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752939999578947584",
  "text" : "RT @IamalrightJack: #LabourNEC Chair of Angela Eagle's Constituency Party Says She Must Accept Democratic Will of Members - Everyone RT htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/jeremyforlabour\/status\/749159530408341504\/video\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/jh48et0mtY",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/749158932652912640\/pu\/img\/p6XXdU6eLYhNRzOr.jpg",
        "id_str" : "749158932652912640",
        "id" : 749158932652912640,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/749158932652912640\/pu\/img\/p6XXdU6eLYhNRzOr.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/jh48et0mtY"
      } ],
      "hashtags" : [ {
        "text" : "LabourNEC",
        "indices" : [ 0, 10 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "752910664390279168",
    "text" : "#LabourNEC Chair of Angela Eagle's Constituency Party Says She Must Accept Democratic Will of Members - Everyone RT https:\/\/t.co\/jh48et0mtY",
    "id" : 752910664390279168,
    "created_at" : "2016-07-12 17:01:05 +0000",
    "user" : {
      "name" : "I'm alright Jack",
      "screen_name" : "IamalrightJack",
      "protected" : false,
      "id_str" : "127666780",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481628435706413056\/VxDCuE8J_normal.jpeg",
      "id" : 127666780,
      "verified" : false
    }
  },
  "id" : 752939999578947584,
  "created_at" : "2016-07-12 18:57:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/R3EEOz9abk",
      "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2016\/07\/last-rah-rah.html",
      "display_url" : "thecurmudgeonly.blogspot.co.uk\/2016\/07\/last-r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "752934620010778624",
  "text" : "RT @pchallinor: New mudgeonry: Last rah-rah https:\/\/t.co\/R3EEOz9abk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 28, 51 ],
        "url" : "https:\/\/t.co\/R3EEOz9abk",
        "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2016\/07\/last-rah-rah.html",
        "display_url" : "thecurmudgeonly.blogspot.co.uk\/2016\/07\/last-r\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "752922496710631424",
    "text" : "New mudgeonry: Last rah-rah https:\/\/t.co\/R3EEOz9abk",
    "id" : 752922496710631424,
    "created_at" : "2016-07-12 17:48:06 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 752934620010778624,
  "created_at" : "2016-07-12 18:36:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S'",
      "screen_name" : "Sher_han_",
      "indices" : [ 0, 10 ],
      "id_str" : "18523388",
      "id" : 18523388
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "752820840715194368",
  "geo" : { },
  "id_str" : "752892861885059072",
  "in_reply_to_user_id" : 18523388,
  "text" : "@Sher_han_ one body of people who are native speakerist i guess",
  "id" : 752892861885059072,
  "in_reply_to_status_id" : 752820840715194368,
  "created_at" : "2016-07-12 15:50:21 +0000",
  "in_reply_to_screen_name" : "Sher_han_",
  "in_reply_to_user_id_str" : "18523388",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Field",
      "screen_name" : "John__Field",
      "indices" : [ 0, 12 ],
      "id_str" : "126258726",
      "id" : 126258726
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "752778070935953408",
  "geo" : { },
  "id_str" : "752785709040304128",
  "in_reply_to_user_id" : 126258726,
  "text" : "@John__Field yr welcome : )",
  "id" : 752785709040304128,
  "in_reply_to_status_id" : 752778070935953408,
  "created_at" : "2016-07-12 08:44:33 +0000",
  "in_reply_to_screen_name" : "John__Field",
  "in_reply_to_user_id_str" : "126258726",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Field",
      "screen_name" : "John__Field",
      "indices" : [ 119, 131 ],
      "id_str" : "126258726",
      "id" : 126258726
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/4bESD7oXc1",
      "expanded_url" : "https:\/\/thelearningprofessor.wordpress.com\/2016\/07\/12\/research-and-education-are-the-sinews-of-economic-war-trying-to-build-a-european-spirit\/",
      "display_url" : "thelearningprofessor.wordpress.com\/2016\/07\/12\/res\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "752777814450069505",
  "text" : "\"Research and education are the sinews of economic war\": trying to build a European spirit https:\/\/t.co\/4bESD7oXc1 via @John__Field",
  "id" : 752777814450069505,
  "created_at" : "2016-07-12 08:13:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S'",
      "screen_name" : "Sher_han_",
      "indices" : [ 0, 10 ],
      "id_str" : "18523388",
      "id" : 18523388
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "752770068136730624",
  "geo" : { },
  "id_str" : "752773569814421505",
  "in_reply_to_user_id" : 18523388,
  "text" : "@Sher_han_ maybe notional concord is at work; i.e. \"standards\" point to grammatical plural but \"whose standards\" notionally = 1 person?",
  "id" : 752773569814421505,
  "in_reply_to_status_id" : 752770068136730624,
  "created_at" : "2016-07-12 07:56:19 +0000",
  "in_reply_to_screen_name" : "Sher_han_",
  "in_reply_to_user_id_str" : "18523388",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S'",
      "screen_name" : "Sher_han_",
      "indices" : [ 0, 10 ],
      "id_str" : "18523388",
      "id" : 18523388
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "752769789848846336",
  "geo" : { },
  "id_str" : "752772631796080640",
  "in_reply_to_user_id" : 18523388,
  "text" : "@Sher_han_ in your example u also have \"these\" \"changes\" all plurals",
  "id" : 752772631796080640,
  "in_reply_to_status_id" : 752769789848846336,
  "created_at" : "2016-07-12 07:52:35 +0000",
  "in_reply_to_screen_name" : "Sher_han_",
  "in_reply_to_user_id_str" : "18523388",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S'",
      "screen_name" : "Sher_han_",
      "indices" : [ 0, 10 ],
      "id_str" : "18523388",
      "id" : 18523388
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "752766200225169409",
  "geo" : { },
  "id_str" : "752767561377472512",
  "in_reply_to_user_id" : 18523388,
  "text" : "@Sher_han_ yes &amp; consider how often phrase is used at end of sentence with question mark; maybe fixed phrase effect overrides sub-verb agr?",
  "id" : 752767561377472512,
  "in_reply_to_status_id" : 752766200225169409,
  "created_at" : "2016-07-12 07:32:27 +0000",
  "in_reply_to_screen_name" : "Sher_han_",
  "in_reply_to_user_id_str" : "18523388",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S'",
      "screen_name" : "Sher_han_",
      "indices" : [ 0, 10 ],
      "id_str" : "18523388",
      "id" : 18523388
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "752765161124007936",
  "geo" : { },
  "id_str" : "752765827976396801",
  "in_reply_to_user_id" : 18523388,
  "text" : "@Sher_han_ that's another thing i think there is also effect of fixed phrase \"by whose standards\"",
  "id" : 752765827976396801,
  "in_reply_to_status_id" : 752765161124007936,
  "created_at" : "2016-07-12 07:25:33 +0000",
  "in_reply_to_screen_name" : "Sher_han_",
  "in_reply_to_user_id_str" : "18523388",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S'",
      "screen_name" : "Sher_han_",
      "indices" : [ 0, 10 ],
      "id_str" : "18523388",
      "id" : 18523388
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "752763868032663552",
  "geo" : { },
  "id_str" : "752764403431399424",
  "in_reply_to_user_id" : 18523388,
  "text" : "@Sher_han_ does it refer to singular as in his\/her\/my or plural as in their\/our; compare to \"by what standards\"",
  "id" : 752764403431399424,
  "in_reply_to_status_id" : 752763868032663552,
  "created_at" : "2016-07-12 07:19:54 +0000",
  "in_reply_to_screen_name" : "Sher_han_",
  "in_reply_to_user_id_str" : "18523388",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S'",
      "screen_name" : "Sher_han_",
      "indices" : [ 0, 10 ],
      "id_str" : "18523388",
      "id" : 18523388
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "752617920778399746",
  "geo" : { },
  "id_str" : "752763723878637568",
  "in_reply_to_user_id" : 18523388,
  "text" : "@Sher_han_ i guess the indeterminancy of what \"whose\" refers has an effect",
  "id" : 752763723878637568,
  "in_reply_to_status_id" : 752617920778399746,
  "created_at" : "2016-07-12 07:17:12 +0000",
  "in_reply_to_screen_name" : "Sher_han_",
  "in_reply_to_user_id_str" : "18523388",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nelson Flores",
      "screen_name" : "nelsonlflores",
      "indices" : [ 86, 100 ],
      "id_str" : "248343882",
      "id" : 248343882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/WXBCQJwtDQ",
      "expanded_url" : "https:\/\/educationallinguist.wordpress.com\/2016\/07\/11\/bilingualism-has-cognitive-benefits-unless-you-are-latinx\/",
      "display_url" : "educationallinguist.wordpress.com\/2016\/07\/11\/bil\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "752763162462740480",
  "text" : "Bilingualism has cognitive benefits unless you are Latinx https:\/\/t.co\/WXBCQJwtDQ via @nelsonlflores",
  "id" : 752763162462740480,
  "created_at" : "2016-07-12 07:14:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Graham Jones",
      "screen_name" : "10Sentences",
      "indices" : [ 74, 86 ],
      "id_str" : "1520318594",
      "id" : 1520318594
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/kalE3YLlkf",
      "expanded_url" : "https:\/\/tensentences.com\/2016\/07\/12\/across-6500-miles-and-13-time-zones-part-2\/",
      "display_url" : "tensentences.com\/2016\/07\/12\/acr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "752761885842345984",
  "text" : "Across 6,500 miles and 13 time zones - part 2 https:\/\/t.co\/kalE3YLlkf via @10Sentences",
  "id" : 752761885842345984,
  "created_at" : "2016-07-12 07:09:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lars Trieloff",
      "screen_name" : "trieloff",
      "indices" : [ 3, 12 ],
      "id_str" : "6257282",
      "id" : 6257282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/ZqTxtRjNVG",
      "expanded_url" : "http:\/\/j.mp\/29thTQO",
      "display_url" : "j.mp\/29thTQO"
    } ]
  },
  "geo" : { },
  "id_str" : "752617414790119424",
  "text" : "RT @trieloff: Amazon\u2019s Mechanical Turkers are college-educated millennials making less than minimum wage https:\/\/t.co\/ZqTxtRjNVG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/ZqTxtRjNVG",
        "expanded_url" : "http:\/\/j.mp\/29thTQO",
        "display_url" : "j.mp\/29thTQO"
      } ]
    },
    "geo" : { },
    "id_str" : "752616128443191296",
    "text" : "Amazon\u2019s Mechanical Turkers are college-educated millennials making less than minimum wage https:\/\/t.co\/ZqTxtRjNVG",
    "id" : 752616128443191296,
    "created_at" : "2016-07-11 21:30:42 +0000",
    "user" : {
      "name" : "Lars Trieloff",
      "screen_name" : "trieloff",
      "protected" : false,
      "id_str" : "6257282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/708651245561585664\/6xwsfP4M_normal.jpg",
      "id" : 6257282,
      "verified" : false
    }
  },
  "id" : 752617414790119424,
  "created_at" : "2016-07-11 21:35:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/3Q1ZzrK7s1",
      "expanded_url" : "https:\/\/www.theguardian.com\/business\/2016\/jul\/11\/hsbc-us-money-laundering-george-osborne-report",
      "display_url" : "theguardian.com\/business\/2016\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "752616736743100416",
  "text" : "RT @pchallinor: Coke-snorting, wog-bombing Osborne certainly would never condone money laundering for drug smugglers and terrorists https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/3Q1ZzrK7s1",
        "expanded_url" : "https:\/\/www.theguardian.com\/business\/2016\/jul\/11\/hsbc-us-money-laundering-george-osborne-report",
        "display_url" : "theguardian.com\/business\/2016\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "752615723437006848",
    "text" : "Coke-snorting, wog-bombing Osborne certainly would never condone money laundering for drug smugglers and terrorists https:\/\/t.co\/3Q1ZzrK7s1",
    "id" : 752615723437006848,
    "created_at" : "2016-07-11 21:29:06 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 752616736743100416,
  "created_at" : "2016-07-11 21:33:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S'",
      "screen_name" : "Sher_han_",
      "indices" : [ 0, 10 ],
      "id_str" : "18523388",
      "id" : 18523388
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "752599400476708864",
  "geo" : { },
  "id_str" : "752610694328115200",
  "in_reply_to_user_id" : 18523388,
  "text" : "@Sher_han_ Correctness is judged by whose standards?",
  "id" : 752610694328115200,
  "in_reply_to_status_id" : 752599400476708864,
  "created_at" : "2016-07-11 21:09:07 +0000",
  "in_reply_to_screen_name" : "Sher_han_",
  "in_reply_to_user_id_str" : "18523388",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Cook",
      "screen_name" : "Jonathan_K_Cook",
      "indices" : [ 3, 19 ],
      "id_str" : "2459644405",
      "id" : 2459644405
    }, {
      "name" : "David Aaronovitch",
      "screen_name" : "DAaronovitch",
      "indices" : [ 22, 35 ],
      "id_str" : "140955302",
      "id" : 140955302
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Jonathan_K_Cook\/status\/751003133048946691\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/OWVPWOV9Ok",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmwZV4KWYAAmch8.jpg",
      "id_str" : "751003101507772416",
      "id" : 751003101507772416,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmwZV4KWYAAmch8.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 940
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 328,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 940
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 940
      } ],
      "display_url" : "pic.twitter.com\/OWVPWOV9Ok"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752605940243988480",
  "text" : "RT @Jonathan_K_Cook: .@DAaronovitch The Times columnist proud of the fact he lacks both hindsight and foresight https:\/\/t.co\/OWVPWOV9Ok",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "David Aaronovitch",
        "screen_name" : "DAaronovitch",
        "indices" : [ 1, 14 ],
        "id_str" : "140955302",
        "id" : 140955302
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Jonathan_K_Cook\/status\/751003133048946691\/photo\/1",
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/OWVPWOV9Ok",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmwZV4KWYAAmch8.jpg",
        "id_str" : "751003101507772416",
        "id" : 751003101507772416,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmwZV4KWYAAmch8.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 940
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 328,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 940
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 940
        } ],
        "display_url" : "pic.twitter.com\/OWVPWOV9Ok"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "751003133048946691",
    "text" : ".@DAaronovitch The Times columnist proud of the fact he lacks both hindsight and foresight https:\/\/t.co\/OWVPWOV9Ok",
    "id" : 751003133048946691,
    "created_at" : "2016-07-07 10:41:14 +0000",
    "user" : {
      "name" : "Jonathan Cook",
      "screen_name" : "Jonathan_K_Cook",
      "protected" : false,
      "id_str" : "2459644405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458948119749619713\/8ed1EDoY_normal.jpeg",
      "id" : 2459644405,
      "verified" : false
    }
  },
  "id" : 752605940243988480,
  "created_at" : "2016-07-11 20:50:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S'",
      "screen_name" : "Sher_han_",
      "indices" : [ 0, 10 ],
      "id_str" : "18523388",
      "id" : 18523388
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "752603347484631041",
  "geo" : { },
  "id_str" : "752604376179421188",
  "in_reply_to_user_id" : 18523388,
  "text" : "@Sher_han_ yeah seems writer using fixed phrase to add persuasive flair?",
  "id" : 752604376179421188,
  "in_reply_to_status_id" : 752603347484631041,
  "created_at" : "2016-07-11 20:44:00 +0000",
  "in_reply_to_screen_name" : "Sher_han_",
  "in_reply_to_user_id_str" : "18523388",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S'",
      "screen_name" : "Sher_han_",
      "indices" : [ 0, 10 ],
      "id_str" : "18523388",
      "id" : 18523388
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/VgipVNyYJ1",
      "expanded_url" : "http:\/\/corpus.byu.edu\/now\/?c=now&q=49055308",
      "display_url" : "corpus.byu.edu\/now\/?c=now&q=4\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "752599400476708864",
  "geo" : { },
  "id_str" : "752603752373379072",
  "in_reply_to_user_id" : 18523388,
  "text" : "@Sher_han_ not many examples in NOW corpus https:\/\/t.co\/VgipVNyYJ1; maybe effect of fixed phrase \"by whose standard|s\" as rhetorical device?",
  "id" : 752603752373379072,
  "in_reply_to_status_id" : 752599400476708864,
  "created_at" : "2016-07-11 20:41:31 +0000",
  "in_reply_to_screen_name" : "Sher_han_",
  "in_reply_to_user_id_str" : "18523388",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S'",
      "screen_name" : "Sher_han_",
      "indices" : [ 0, 10 ],
      "id_str" : "18523388",
      "id" : 18523388
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "752599400476708864",
  "geo" : { },
  "id_str" : "752602537795149824",
  "in_reply_to_user_id" : 18523388,
  "text" : "@Sher_han_ is there a fuller extract for quote?",
  "id" : 752602537795149824,
  "in_reply_to_status_id" : 752599400476708864,
  "created_at" : "2016-07-11 20:36:42 +0000",
  "in_reply_to_screen_name" : "Sher_han_",
  "in_reply_to_user_id_str" : "18523388",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S'",
      "screen_name" : "Sher_han_",
      "indices" : [ 0, 10 ],
      "id_str" : "18523388",
      "id" : 18523388
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "752601027766001664",
  "geo" : { },
  "id_str" : "752602137784381440",
  "in_reply_to_user_id" : 18523388,
  "text" : "@Sher_han_ ah ok maybe depends if you consider 'whose' as singular or plural subject?",
  "id" : 752602137784381440,
  "in_reply_to_status_id" : 752601027766001664,
  "created_at" : "2016-07-11 20:35:06 +0000",
  "in_reply_to_screen_name" : "Sher_han_",
  "in_reply_to_user_id_str" : "18523388",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S'",
      "screen_name" : "Sher_han_",
      "indices" : [ 0, 10 ],
      "id_str" : "18523388",
      "id" : 18523388
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "752599400476708864",
  "geo" : { },
  "id_str" : "752600436616691713",
  "in_reply_to_user_id" : 18523388,
  "text" : "@Sher_han_ hi seems okay to me, what do u see as problematic?",
  "id" : 752600436616691713,
  "in_reply_to_status_id" : 752599400476708864,
  "created_at" : "2016-07-11 20:28:21 +0000",
  "in_reply_to_screen_name" : "Sher_han_",
  "in_reply_to_user_id_str" : "18523388",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Corbyn MP",
      "screen_name" : "jeremycorbyn",
      "indices" : [ 3, 16 ],
      "id_str" : "117777690",
      "id" : 117777690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/DCyCnlFzuE",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/84e57b6d-e6a8-4cd1-9bb8-c5d29a82b833",
      "display_url" : "amp.twimg.com\/v\/84e57b6d-e6a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "752595597002215425",
  "text" : "RT @jeremycorbyn: If you want to help shape Labour's future - take part in the elections for our National Executive Committee, the NEC\nhttp\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/DCyCnlFzuE",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/84e57b6d-e6a8-4cd1-9bb8-c5d29a82b833",
        "display_url" : "amp.twimg.com\/v\/84e57b6d-e6a\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "752458962755133442",
    "text" : "If you want to help shape Labour's future - take part in the elections for our National Executive Committee, the NEC\nhttps:\/\/t.co\/DCyCnlFzuE",
    "id" : 752458962755133442,
    "created_at" : "2016-07-11 11:06:11 +0000",
    "user" : {
      "name" : "Jeremy Corbyn MP",
      "screen_name" : "jeremycorbyn",
      "protected" : false,
      "id_str" : "117777690",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746717575522959360\/3adKV8CC_normal.jpg",
      "id" : 117777690,
      "verified" : true
    }
  },
  "id" : 752595597002215425,
  "created_at" : "2016-07-11 20:09:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Chrimes",
      "screen_name" : "ELTwriter",
      "indices" : [ 0, 10 ],
      "id_str" : "2464809235",
      "id" : 2464809235
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "752537201116868608",
  "geo" : { },
  "id_str" : "752547174043512832",
  "in_reply_to_user_id" : 2464809235,
  "text" : "@ELTwriter one route would be to do a web app then use something like phonegap to get a mobile version; there are many such \"frameworks\"",
  "id" : 752547174043512832,
  "in_reply_to_status_id" : 752537201116868608,
  "created_at" : "2016-07-11 16:56:42 +0000",
  "in_reply_to_screen_name" : "ELTwriter",
  "in_reply_to_user_id_str" : "2464809235",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Chrimes",
      "screen_name" : "ELTwriter",
      "indices" : [ 0, 10 ],
      "id_str" : "2464809235",
      "id" : 2464809235
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "752504786956804097",
  "geo" : { },
  "id_str" : "752525026012848130",
  "in_reply_to_user_id" : 2464809235,
  "text" : "@ELTwriter hi not used any app makers as such; u want to make a mobile app?",
  "id" : 752525026012848130,
  "in_reply_to_status_id" : 752504786956804097,
  "created_at" : "2016-07-11 15:28:42 +0000",
  "in_reply_to_screen_name" : "ELTwriter",
  "in_reply_to_user_id_str" : "2464809235",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Emersberger",
      "screen_name" : "rosendo_joe",
      "indices" : [ 3, 15 ],
      "id_str" : "3351345863",
      "id" : 3351345863
    }, {
      "name" : "The Guardian",
      "screen_name" : "guardian",
      "indices" : [ 27, 36 ],
      "id_str" : "87818409",
      "id" : 87818409
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/rosendo_joe\/status\/752005268637093888\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/xvhCfNbU0H",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cm-oixTXgAEDsYS.jpg",
      "id_str" : "752004978097750017",
      "id" : 752004978097750017,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cm-oixTXgAEDsYS.jpg",
      "sizes" : [ {
        "h" : 384,
        "resize" : "fit",
        "w" : 658
      }, {
        "h" : 384,
        "resize" : "fit",
        "w" : 658
      }, {
        "h" : 384,
        "resize" : "fit",
        "w" : 658
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 384,
        "resize" : "fit",
        "w" : 658
      } ],
      "display_url" : "pic.twitter.com\/xvhCfNbU0H"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/58I0pWx3Ew",
      "expanded_url" : "http:\/\/www.theguardian.com\/politics\/2016\/jul\/08\/labour-jeremy-corbyn-and-the-search-for-the-partys-henry-vii",
      "display_url" : "theguardian.com\/politics\/2016\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "752072733576527873",
  "text" : "RT @rosendo_joe: letter in @guardian signed by Chomksy, Pilger etc denounces media bias against Jeremy Corbyn\nhttps:\/\/t.co\/58I0pWx3Ew https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Guardian",
        "screen_name" : "guardian",
        "indices" : [ 10, 19 ],
        "id_str" : "87818409",
        "id" : 87818409
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/rosendo_joe\/status\/752005268637093888\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/xvhCfNbU0H",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cm-oixTXgAEDsYS.jpg",
        "id_str" : "752004978097750017",
        "id" : 752004978097750017,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cm-oixTXgAEDsYS.jpg",
        "sizes" : [ {
          "h" : 384,
          "resize" : "fit",
          "w" : 658
        }, {
          "h" : 384,
          "resize" : "fit",
          "w" : 658
        }, {
          "h" : 384,
          "resize" : "fit",
          "w" : 658
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 384,
          "resize" : "fit",
          "w" : 658
        } ],
        "display_url" : "pic.twitter.com\/xvhCfNbU0H"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/58I0pWx3Ew",
        "expanded_url" : "http:\/\/www.theguardian.com\/politics\/2016\/jul\/08\/labour-jeremy-corbyn-and-the-search-for-the-partys-henry-vii",
        "display_url" : "theguardian.com\/politics\/2016\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "752005268637093888",
    "text" : "letter in @guardian signed by Chomksy, Pilger etc denounces media bias against Jeremy Corbyn\nhttps:\/\/t.co\/58I0pWx3Ew https:\/\/t.co\/xvhCfNbU0H",
    "id" : 752005268637093888,
    "created_at" : "2016-07-10 05:03:22 +0000",
    "user" : {
      "name" : "Joe Emersberger",
      "screen_name" : "rosendo_joe",
      "protected" : false,
      "id_str" : "3351345863",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/621112707522142209\/OGmLR1xt_normal.jpg",
      "id" : 3351345863,
      "verified" : false
    }
  },
  "id" : 752072733576527873,
  "created_at" : "2016-07-10 09:31:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenn Greenwald",
      "screen_name" : "ggreenwald",
      "indices" : [ 3, 14 ],
      "id_str" : "16076032",
      "id" : 16076032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 134, 148 ],
      "url" : "https:\/\/t.co\/XiSjfa6zV0",
      "expanded_url" : "https:\/\/twitter.com\/LabourEoin\/status\/751739043617054720",
      "display_url" : "twitter.com\/LabourEoin\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "751889092091273220",
  "text" : "RT @ggreenwald: Anti-Corbyn campaign will have a united British media behind it &amp; be unprecedentedly ugly &amp; full of smears... https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 141 ],
        "url" : "https:\/\/t.co\/XiSjfa6zV0",
        "expanded_url" : "https:\/\/twitter.com\/LabourEoin\/status\/751739043617054720",
        "display_url" : "twitter.com\/LabourEoin\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "751773595790151680",
    "text" : "Anti-Corbyn campaign will have a united British media behind it &amp; be unprecedentedly ugly &amp; full of smears... https:\/\/t.co\/XiSjfa6zV0",
    "id" : 751773595790151680,
    "created_at" : "2016-07-09 13:42:47 +0000",
    "user" : {
      "name" : "Glenn Greenwald",
      "screen_name" : "ggreenwald",
      "protected" : false,
      "id_str" : "16076032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/659383028771364869\/G9HHnjiI_normal.jpg",
      "id" : 16076032,
      "verified" : true
    }
  },
  "id" : 751889092091273220,
  "created_at" : "2016-07-09 21:21:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Jones",
      "screen_name" : "ELTResearch",
      "indices" : [ 3, 15 ],
      "id_str" : "3308043417",
      "id" : 3308043417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/3bJDc7s5yp",
      "expanded_url" : "https:\/\/twitter.com\/SAGEmedia_comm\/status\/751763164170248192",
      "display_url" : "twitter.com\/SAGEmedia_comm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "751820783136206848",
  "text" : "RT @ELTResearch: Nice review of a book I co-authored. https:\/\/t.co\/3bJDc7s5yp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 60 ],
        "url" : "https:\/\/t.co\/3bJDc7s5yp",
        "expanded_url" : "https:\/\/twitter.com\/SAGEmedia_comm\/status\/751763164170248192",
        "display_url" : "twitter.com\/SAGEmedia_comm\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "751782336828694528",
    "text" : "Nice review of a book I co-authored. https:\/\/t.co\/3bJDc7s5yp",
    "id" : 751782336828694528,
    "created_at" : "2016-07-09 14:17:31 +0000",
    "user" : {
      "name" : "Chris Jones",
      "screen_name" : "ELTResearch",
      "protected" : false,
      "id_str" : "3308043417",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/720360015383654400\/Zq4CQgZv_normal.jpg",
      "id" : 3308043417,
      "verified" : false
    }
  },
  "id" : 751820783136206848,
  "created_at" : "2016-07-09 16:50:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Smerity",
      "screen_name" : "Smerity",
      "indices" : [ 3, 11 ],
      "id_str" : "15363432",
      "id" : 15363432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/Fv6bYe033m",
      "expanded_url" : "http:\/\/smerity.com\/articles\/2016\/ml_not_magic.html",
      "display_url" : "smerity.com\/articles\/2016\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "751746650687897600",
  "text" : "RT @Smerity: It's ML, not magic: simple questions you should ask that will help reduce AI hype\n(minimal ML\/AI knowledge required)\nhttps:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/Fv6bYe033m",
        "expanded_url" : "http:\/\/smerity.com\/articles\/2016\/ml_not_magic.html",
        "display_url" : "smerity.com\/articles\/2016\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "751491020529864704",
    "text" : "It's ML, not magic: simple questions you should ask that will help reduce AI hype\n(minimal ML\/AI knowledge required)\nhttps:\/\/t.co\/Fv6bYe033m",
    "id" : 751491020529864704,
    "created_at" : "2016-07-08 18:59:55 +0000",
    "user" : {
      "name" : "Smerity",
      "screen_name" : "Smerity",
      "protected" : false,
      "id_str" : "15363432",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/659176854801149952\/ks02TVUX_normal.jpg",
      "id" : 15363432,
      "verified" : false
    }
  },
  "id" : 751746650687897600,
  "created_at" : "2016-07-09 11:55:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Knight",
      "screen_name" : "nakanotim",
      "indices" : [ 3, 13 ],
      "id_str" : "295968758",
      "id" : 295968758
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "brexit",
      "indices" : [ 36, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/PDtJgtWloz",
      "expanded_url" : "http:\/\/www.versobooks.com\/blogs\/2761-brexit-the-decision-of-a-divided-country",
      "display_url" : "versobooks.com\/blogs\/2761-bre\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "751733398981533697",
  "text" : "RT @nakanotim: Danny with the stats #brexit https:\/\/t.co\/PDtJgtWloz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "brexit",
        "indices" : [ 21, 28 ]
      } ],
      "urls" : [ {
        "indices" : [ 29, 52 ],
        "url" : "https:\/\/t.co\/PDtJgtWloz",
        "expanded_url" : "http:\/\/www.versobooks.com\/blogs\/2761-brexit-the-decision-of-a-divided-country",
        "display_url" : "versobooks.com\/blogs\/2761-bre\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "751731751710445568",
    "text" : "Danny with the stats #brexit https:\/\/t.co\/PDtJgtWloz",
    "id" : 751731751710445568,
    "created_at" : "2016-07-09 10:56:30 +0000",
    "user" : {
      "name" : "Tim Knight",
      "screen_name" : "nakanotim",
      "protected" : false,
      "id_str" : "295968758",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/580948241912467456\/sMVJpibc_normal.jpg",
      "id" : 295968758,
      "verified" : false
    }
  },
  "id" : 751733398981533697,
  "created_at" : "2016-07-09 11:03:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yasu",
      "screen_name" : "casualconc",
      "indices" : [ 0, 11 ],
      "id_str" : "132412691",
      "id" : 132412691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751642127637946368",
  "geo" : { },
  "id_str" : "751722282771419136",
  "in_reply_to_user_id" : 132412691,
  "text" : "@casualconc yes was on external drive tried moving to internal same crash",
  "id" : 751722282771419136,
  "in_reply_to_status_id" : 751642127637946368,
  "created_at" : "2016-07-09 10:18:53 +0000",
  "in_reply_to_screen_name" : "casualconc",
  "in_reply_to_user_id_str" : "132412691",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BLM",
      "indices" : [ 19, 23 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/ABwIW07PMx",
      "expanded_url" : "http:\/\/www.languagejones.com\/blog-1\/2016\/7\/8\/the-linguistics-of-blm-scalar-implicature-and-social-controversy",
      "display_url" : "languagejones.com\/blog-1\/2016\/7\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "751531159188824064",
  "text" : "The linguistics of #BLM: Scalar Implicature and Social Controversy https:\/\/t.co\/ABwIW07PMx",
  "id" : 751531159188824064,
  "created_at" : "2016-07-08 21:39:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 91, 107 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/9YqWbAtnTb",
      "expanded_url" : "https:\/\/ianjsinclair.wordpress.com\/2016\/07\/08\/responding-to-chilcot-more-deceptions-from-tony-blair-on-iraq\/",
      "display_url" : "ianjsinclair.wordpress.com\/2016\/07\/08\/res\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "751386101240266752",
  "text" : "Responding to Chilcot: more deceptions from Tony Blair on Iraq https:\/\/t.co\/9YqWbAtnTb via @wordpressdotcom",
  "id" : 751386101240266752,
  "created_at" : "2016-07-08 12:03:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liam T",
      "screen_name" : "Liam_ELT",
      "indices" : [ 0, 9 ],
      "id_str" : "3165901457",
      "id" : 3165901457
    }, {
      "name" : "The TEFL Show",
      "screen_name" : "TheTeflShow",
      "indices" : [ 10, 22 ],
      "id_str" : "3996937557",
      "id" : 3996937557
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "techat",
      "indices" : [ 95, 102 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751378648851058688",
  "geo" : { },
  "id_str" : "751384163350183936",
  "in_reply_to_user_id" : 3165901457,
  "text" : "@Liam_ELT @TheTeflShow students aside to keep working in this industry need such qualities : \/ #techat",
  "id" : 751384163350183936,
  "in_reply_to_status_id" : 751378648851058688,
  "created_at" : "2016-07-08 11:55:19 +0000",
  "in_reply_to_screen_name" : "Liam_ELT",
  "in_reply_to_user_id_str" : "3165901457",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "indices" : [ 100, 115 ],
      "id_str" : "152194866",
      "id" : 152194866
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/751383471340355585\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/dR7Wz2yyfJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cm1yyZYWIAAJi0X.jpg",
      "id_str" : "751382922972766208",
      "id" : 751382922972766208,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cm1yyZYWIAAJi0X.jpg",
      "sizes" : [ {
        "h" : 656,
        "resize" : "fit",
        "w" : 762
      }, {
        "h" : 656,
        "resize" : "fit",
        "w" : 762
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 585,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 656,
        "resize" : "fit",
        "w" : 762
      } ],
      "display_url" : "pic.twitter.com\/dR7Wz2yyfJ"
    } ],
    "hashtags" : [ {
      "text" : "chilcot",
      "indices" : [ 27, 35 ]
    }, {
      "text" : "chilcotgrammar",
      "indices" : [ 36, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/SQV1Vzr6b5",
      "expanded_url" : "http:\/\/tm.durusau.net\/?p=70316",
      "display_url" : "tm.durusau.net\/?p=70316"
    } ]
  },
  "geo" : { },
  "id_str" : "751383471340355585",
  "text" : "43 mentions David Kelly in #chilcot #chilcotgrammar from https:\/\/t.co\/SQV1Vzr6b5 collected texts by @patrickDurusau https:\/\/t.co\/dR7Wz2yyfJ",
  "id" : 751383471340355585,
  "created_at" : "2016-07-08 11:52:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/68hb6l7Wiz",
      "expanded_url" : "https:\/\/www.theguardian.com\/commentisfree\/2016\/jul\/08\/chilcot-iraq-war-gchq-inquiry",
      "display_url" : "theguardian.com\/commentisfree\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "751380740273766400",
  "text" : "RT @pchallinor: Why didn't Chilcot talk to Katharine Gun? https:\/\/t.co\/68hb6l7Wiz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 65 ],
        "url" : "https:\/\/t.co\/68hb6l7Wiz",
        "expanded_url" : "https:\/\/www.theguardian.com\/commentisfree\/2016\/jul\/08\/chilcot-iraq-war-gchq-inquiry",
        "display_url" : "theguardian.com\/commentisfree\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "751376906902183936",
    "text" : "Why didn't Chilcot talk to Katharine Gun? https:\/\/t.co\/68hb6l7Wiz",
    "id" : 751376906902183936,
    "created_at" : "2016-07-08 11:26:29 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 751380740273766400,
  "created_at" : "2016-07-08 11:41:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yasu",
      "screen_name" : "casualconc",
      "indices" : [ 0, 11 ],
      "id_str" : "132412691",
      "id" : 132412691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751198466785763328",
  "geo" : { },
  "id_str" : "751199155566051328",
  "in_reply_to_user_id" : 132412691,
  "text" : "@casualconc mode is File?",
  "id" : 751199155566051328,
  "in_reply_to_status_id" : 751198466785763328,
  "created_at" : "2016-07-07 23:40:09 +0000",
  "in_reply_to_screen_name" : "casualconc",
  "in_reply_to_user_id_str" : "132412691",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yasu",
      "screen_name" : "casualconc",
      "indices" : [ 0, 11 ],
      "id_str" : "132412691",
      "id" : 132412691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751198466785763328",
  "geo" : { },
  "id_str" : "751198908966137857",
  "in_reply_to_user_id" : 132412691,
  "text" : "@casualconc all default settings, txt files",
  "id" : 751198908966137857,
  "in_reply_to_status_id" : 751198466785763328,
  "created_at" : "2016-07-07 23:39:11 +0000",
  "in_reply_to_screen_name" : "casualconc",
  "in_reply_to_user_id_str" : "132412691",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yasu",
      "screen_name" : "casualconc",
      "indices" : [ 0, 11 ],
      "id_str" : "132412691",
      "id" : 132412691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751196220261961728",
  "geo" : { },
  "id_str" : "751197447234416640",
  "in_reply_to_user_id" : 132412691,
  "text" : "@casualconc yes happens with other files",
  "id" : 751197447234416640,
  "in_reply_to_status_id" : 751196220261961728,
  "created_at" : "2016-07-07 23:33:22 +0000",
  "in_reply_to_screen_name" : "casualconc",
  "in_reply_to_user_id_str" : "132412691",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yasu",
      "screen_name" : "casualconc",
      "indices" : [ 0, 11 ],
      "id_str" : "132412691",
      "id" : 132412691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/Sx3WrOWzrt",
      "expanded_url" : "http:\/\/pastebin.com\/R2mnEB10",
      "display_url" : "pastebin.com\/R2mnEB10"
    } ]
  },
  "geo" : { },
  "id_str" : "751195500318253057",
  "in_reply_to_user_id" : 132412691,
  "text" : "@casualconc hi getting crash when trying to word count https:\/\/t.co\/Sx3WrOWzrt",
  "id" : 751195500318253057,
  "created_at" : "2016-07-07 23:25:38 +0000",
  "in_reply_to_screen_name" : "casualconc",
  "in_reply_to_user_id_str" : "132412691",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "indices" : [ 3, 13 ],
      "id_str" : "577931950",
      "id" : 577931950
    }, {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "indices" : [ 15, 25 ],
      "id_str" : "577931950",
      "id" : 577931950
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusresources",
      "indices" : [ 87, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/5NqaWwgUjC",
      "expanded_url" : "http:\/\/www.oxforddictionaries.com\/words\/oxford-new-words-corpus",
      "display_url" : "oxforddictionaries.com\/words\/oxford-n\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "751185412635459584",
  "text" : "RT @RudyLoock: @RudyLoock Based on Oxford New Monitor Corpus : https:\/\/t.co\/5NqaWwgUjC\n#corpusresources",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rudy Loock",
        "screen_name" : "RudyLoock",
        "indices" : [ 0, 10 ],
        "id_str" : "577931950",
        "id" : 577931950
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpusresources",
        "indices" : [ 72, 88 ]
      } ],
      "urls" : [ {
        "indices" : [ 48, 71 ],
        "url" : "https:\/\/t.co\/5NqaWwgUjC",
        "expanded_url" : "http:\/\/www.oxforddictionaries.com\/words\/oxford-new-words-corpus",
        "display_url" : "oxforddictionaries.com\/words\/oxford-n\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "744914202758942720",
    "geo" : { },
    "id_str" : "744924962750894081",
    "in_reply_to_user_id" : 577931950,
    "text" : "@RudyLoock Based on Oxford New Monitor Corpus : https:\/\/t.co\/5NqaWwgUjC\n#corpusresources",
    "id" : 744924962750894081,
    "in_reply_to_status_id" : 744914202758942720,
    "created_at" : "2016-06-20 16:08:45 +0000",
    "in_reply_to_screen_name" : "RudyLoock",
    "in_reply_to_user_id_str" : "577931950",
    "user" : {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "protected" : false,
      "id_str" : "577931950",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2370874884\/qm10et5v1fyzwixh651s_normal.jpeg",
      "id" : 577931950,
      "verified" : false
    }
  },
  "id" : 751185412635459584,
  "created_at" : "2016-07-07 22:45:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Loock",
      "screen_name" : "RudyLoock",
      "indices" : [ 0, 10 ],
      "id_str" : "577931950",
      "id" : 577931950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/G4idmPBd4E",
      "expanded_url" : "https:\/\/plus.google.com\/+MuraNava\/posts\/BBF6aPXY4dZ",
      "display_url" : "plus.google.com\/+MuraNava\/post\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "744924962750894081",
  "geo" : { },
  "id_str" : "751185370717491200",
  "in_reply_to_user_id" : 577931950,
  "text" : "@RudyLoock thks! very neat, this is basically a mini CL course : ) https:\/\/t.co\/G4idmPBd4E",
  "id" : 751185370717491200,
  "in_reply_to_status_id" : 744924962750894081,
  "created_at" : "2016-07-07 22:45:23 +0000",
  "in_reply_to_screen_name" : "RudyLoock",
  "in_reply_to_user_id_str" : "577931950",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusresources",
      "indices" : [ 0, 16 ]
    } ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/pv51QGUPiR",
      "expanded_url" : "https:\/\/twitter.com\/patrickDurusau\/status\/750787038291558400",
      "display_url" : "twitter.com\/patrickDurusau\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "751179575330271232",
  "text" : "#corpusresources https:\/\/t.co\/pv51QGUPiR",
  "id" : 751179575330271232,
  "created_at" : "2016-07-07 22:22:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "indices" : [ 3, 18 ],
      "id_str" : "152194866",
      "id" : 152194866
    }, {
      "name" : "GIJN",
      "screen_name" : "gijn",
      "indices" : [ 95, 100 ],
      "id_str" : "130596773",
      "id" : 130596773
    }, {
      "name" : "Guardian news",
      "screen_name" : "guardiannews",
      "indices" : [ 101, 114 ],
      "id_str" : "788524",
      "id" : 788524
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IraqInquiry",
      "indices" : [ 115, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/Wg5WUNEcZy",
      "expanded_url" : "http:\/\/wp.me\/pSoaD-iii",
      "display_url" : "wp.me\/pSoaD-iii"
    } ]
  },
  "geo" : { },
  "id_str" : "751177656943644672",
  "text" : "RT @patrickDurusau: Faking Government Transparency: The Chilcot Report https:\/\/t.co\/Wg5WUNEcZy @gijn @guardiannews #IraqInquiry",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "GIJN",
        "screen_name" : "gijn",
        "indices" : [ 75, 80 ],
        "id_str" : "130596773",
        "id" : 130596773
      }, {
        "name" : "Guardian news",
        "screen_name" : "guardiannews",
        "indices" : [ 81, 94 ],
        "id_str" : "788524",
        "id" : 788524
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IraqInquiry",
        "indices" : [ 95, 107 ]
      } ],
      "urls" : [ {
        "indices" : [ 51, 74 ],
        "url" : "https:\/\/t.co\/Wg5WUNEcZy",
        "expanded_url" : "http:\/\/wp.me\/pSoaD-iii",
        "display_url" : "wp.me\/pSoaD-iii"
      } ]
    },
    "geo" : { },
    "id_str" : "751119916485447680",
    "text" : "Faking Government Transparency: The Chilcot Report https:\/\/t.co\/Wg5WUNEcZy @gijn @guardiannews #IraqInquiry",
    "id" : 751119916485447680,
    "created_at" : "2016-07-07 18:25:17 +0000",
    "user" : {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "protected" : false,
      "id_str" : "152194866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/961579480\/patrick_normal.jpeg",
      "id" : 152194866,
      "verified" : false
    }
  },
  "id" : 751177656943644672,
  "created_at" : "2016-07-07 22:14:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 0, 9 ],
      "id_str" : "134211317",
      "id" : 134211317
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/751176192959676416\/photo\/1",
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/NkzI8IvVWM",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Cmy2vHpWEAAFslE.jpg",
      "id_str" : "751176158486597632",
      "id" : 751176158486597632,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Cmy2vHpWEAAFslE.jpg",
      "sizes" : [ {
        "h" : 218,
        "resize" : "fit",
        "w" : 268
      }, {
        "h" : 218,
        "resize" : "fit",
        "w" : 268
      }, {
        "h" : 218,
        "resize" : "fit",
        "w" : 268
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 218,
        "resize" : "fit",
        "w" : 268
      } ],
      "display_url" : "pic.twitter.com\/NkzI8IvVWM"
    } ],
    "hashtags" : [ {
      "text" : "blairopath",
      "indices" : [ 10, 21 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751174970466770945",
  "geo" : { },
  "id_str" : "751176192959676416",
  "in_reply_to_user_id" : 134211317,
  "text" : "@josipa74 #blairopath indeed https:\/\/t.co\/NkzI8IvVWM",
  "id" : 751176192959676416,
  "in_reply_to_status_id" : 751174970466770945,
  "created_at" : "2016-07-07 22:08:55 +0000",
  "in_reply_to_screen_name" : "josipa74",
  "in_reply_to_user_id_str" : "134211317",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/751167637170913280\/photo\/1",
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/lSaXedzPR9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cmyuzb-XgAAlhOs.jpg",
      "id_str" : "751167436569935872",
      "id" : 751167436569935872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cmyuzb-XgAAlhOs.jpg",
      "sizes" : [ {
        "h" : 390,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 759,
        "resize" : "fit",
        "w" : 1325
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 687,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 759,
        "resize" : "fit",
        "w" : 1325
      } ],
      "display_url" : "pic.twitter.com\/lSaXedzPR9"
    } ],
    "hashtags" : [ {
      "text" : "chilcotgrammar",
      "indices" : [ 65, 80 ]
    }, {
      "text" : "chilcot",
      "indices" : [ 81, 89 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751126596451438592",
  "geo" : { },
  "id_str" : "751167637170913280",
  "in_reply_to_user_id" : 18602422,
  "text" : "Larry Bush &amp; Blair - I say whatever, you say no matter what. #chilcotgrammar #chilcot https:\/\/t.co\/lSaXedzPR9",
  "id" : 751167637170913280,
  "in_reply_to_status_id" : 751126596451438592,
  "created_at" : "2016-07-07 21:34:55 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    }, {
      "name" : "AndrewBuncombe",
      "screen_name" : "AndrewBuncombe",
      "indices" : [ 24, 39 ],
      "id_str" : "105998402",
      "id" : 105998402
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Iraq",
      "indices" : [ 74, 79 ]
    }, {
      "text" : "Chilcot",
      "indices" : [ 80, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/omo9mTtNcy",
      "expanded_url" : "https:\/\/twitter.com\/AndrewBuncombe\/status\/750808019013775362",
      "display_url" : "twitter.com\/AndrewBuncombe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "751143515707543552",
  "text" : "RT @medialens: Kudos to @AndrewBuncombe for focusing on this vital issue. #Iraq #Chilcot https:\/\/t.co\/omo9mTtNcy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "AndrewBuncombe",
        "screen_name" : "AndrewBuncombe",
        "indices" : [ 9, 24 ],
        "id_str" : "105998402",
        "id" : 105998402
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Iraq",
        "indices" : [ 59, 64 ]
      }, {
        "text" : "Chilcot",
        "indices" : [ 65, 73 ]
      } ],
      "urls" : [ {
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/omo9mTtNcy",
        "expanded_url" : "https:\/\/twitter.com\/AndrewBuncombe\/status\/750808019013775362",
        "display_url" : "twitter.com\/AndrewBuncombe\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "751067702278647808",
    "text" : "Kudos to @AndrewBuncombe for focusing on this vital issue. #Iraq #Chilcot https:\/\/t.co\/omo9mTtNcy",
    "id" : 751067702278647808,
    "created_at" : "2016-07-07 14:57:49 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 751143515707543552,
  "created_at" : "2016-07-07 19:59:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Electronic Intifada",
      "screen_name" : "intifada",
      "indices" : [ 3, 12 ],
      "id_str" : "6721522",
      "id" : 6721522
    }, {
      "name" : "Exxelia Group",
      "screen_name" : "Exxelia",
      "indices" : [ 29, 37 ],
      "id_str" : "2320860896",
      "id" : 2320860896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/72f54EZUXD",
      "expanded_url" : "http:\/\/bit.ly\/29rwwX5",
      "display_url" : "bit.ly\/29rwwX5"
    } ]
  },
  "geo" : { },
  "id_str" : "751142348051058688",
  "text" : "RT @intifada: French company @Exxelia made component of Israeli missile that killed three children in Gaza https:\/\/t.co\/72f54EZUXD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Exxelia Group",
        "screen_name" : "Exxelia",
        "indices" : [ 15, 23 ],
        "id_str" : "2320860896",
        "id" : 2320860896
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/72f54EZUXD",
        "expanded_url" : "http:\/\/bit.ly\/29rwwX5",
        "display_url" : "bit.ly\/29rwwX5"
      } ]
    },
    "geo" : { },
    "id_str" : "751053496867258369",
    "text" : "French company @Exxelia made component of Israeli missile that killed three children in Gaza https:\/\/t.co\/72f54EZUXD",
    "id" : 751053496867258369,
    "created_at" : "2016-07-07 14:01:22 +0000",
    "user" : {
      "name" : "Electronic Intifada",
      "screen_name" : "intifada",
      "protected" : false,
      "id_str" : "6721522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608132742224568320\/x3yrArdT_normal.png",
      "id" : 6721522,
      "verified" : false
    }
  },
  "id" : 751142348051058688,
  "created_at" : "2016-07-07 19:54:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abby Martin",
      "screen_name" : "AbbyMartin",
      "indices" : [ 3, 14 ],
      "id_str" : "24258355",
      "id" : 24258355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/UlPgVKBai4",
      "expanded_url" : "https:\/\/twitter.com\/ssssamanthaamua\/status\/751039217241772032",
      "display_url" : "twitter.com\/ssssamanthaamu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "751141798823727104",
  "text" : "RT @AbbyMartin: \"Always told my son to survive being stopped by police is to comply. What's the difference if you get killed anyway\" https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/UlPgVKBai4",
        "expanded_url" : "https:\/\/twitter.com\/ssssamanthaamua\/status\/751039217241772032",
        "display_url" : "twitter.com\/ssssamanthaamu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "751101391721070592",
    "text" : "\"Always told my son to survive being stopped by police is to comply. What's the difference if you get killed anyway\" https:\/\/t.co\/UlPgVKBai4",
    "id" : 751101391721070592,
    "created_at" : "2016-07-07 17:11:41 +0000",
    "user" : {
      "name" : "Abby Martin",
      "screen_name" : "AbbyMartin",
      "protected" : false,
      "id_str" : "24258355",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/603329766834348032\/hTdd19lv_normal.jpg",
      "id" : 24258355,
      "verified" : false
    }
  },
  "id" : 751141798823727104,
  "created_at" : "2016-07-07 19:52:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Nelson \u262D",
      "screen_name" : "SocialistVoice",
      "indices" : [ 3, 18 ],
      "id_str" : "1833919200",
      "id" : 1833919200
    }, {
      "name" : "Ian Austin",
      "screen_name" : "IanAustinMP",
      "indices" : [ 21, 33 ],
      "id_str" : "261782937",
      "id" : 261782937
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/SocialistVoice\/status\/750721719569092608\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/IQKI7cvofy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmsZas0WIAA5Kh-.jpg",
      "id_str" : "750721709385326592",
      "id" : 750721709385326592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmsZas0WIAA5Kh-.jpg",
      "sizes" : [ {
        "h" : 288,
        "resize" : "fit",
        "w" : 460
      }, {
        "h" : 288,
        "resize" : "fit",
        "w" : 460
      }, {
        "h" : 288,
        "resize" : "fit",
        "w" : 460
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 288,
        "resize" : "fit",
        "w" : 460
      } ],
      "display_url" : "pic.twitter.com\/IQKI7cvofy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "751141536876863488",
  "text" : "RT @SocialistVoice: .@IanAustinMP heckled Jeremy Corbyn while he paid tribute to Iraq's war dead. RT if you agree he should be expelled htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ian Austin",
        "screen_name" : "IanAustinMP",
        "indices" : [ 1, 13 ],
        "id_str" : "261782937",
        "id" : 261782937
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/SocialistVoice\/status\/750721719569092608\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/IQKI7cvofy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmsZas0WIAA5Kh-.jpg",
        "id_str" : "750721709385326592",
        "id" : 750721709385326592,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmsZas0WIAA5Kh-.jpg",
        "sizes" : [ {
          "h" : 288,
          "resize" : "fit",
          "w" : 460
        }, {
          "h" : 288,
          "resize" : "fit",
          "w" : 460
        }, {
          "h" : 288,
          "resize" : "fit",
          "w" : 460
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 288,
          "resize" : "fit",
          "w" : 460
        } ],
        "display_url" : "pic.twitter.com\/IQKI7cvofy"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "750721719569092608",
    "text" : ".@IanAustinMP heckled Jeremy Corbyn while he paid tribute to Iraq's war dead. RT if you agree he should be expelled https:\/\/t.co\/IQKI7cvofy",
    "id" : 750721719569092608,
    "created_at" : "2016-07-06 16:03:00 +0000",
    "user" : {
      "name" : "Scott Nelson \u262D",
      "screen_name" : "SocialistVoice",
      "protected" : false,
      "id_str" : "1833919200",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751042573318303744\/7OU1QgkU_normal.jpg",
      "id" : 1833919200,
      "verified" : false
    }
  },
  "id" : 751141536876863488,
  "created_at" : "2016-07-07 19:51:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/751126596451438592\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/HPlinMDsGm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmyJeQAXgAEZPKj.jpg",
      "id_str" : "751126390649618433",
      "id" : 751126390649618433,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmyJeQAXgAEZPKj.jpg",
      "sizes" : [ {
        "h" : 764,
        "resize" : "fit",
        "w" : 1440
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 637,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 361,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 764,
        "resize" : "fit",
        "w" : 1440
      } ],
      "display_url" : "pic.twitter.com\/HPlinMDsGm"
    } ],
    "hashtags" : [ {
      "text" : "chilcotgrammar",
      "indices" : [ 66, 81 ]
    }, {
      "text" : "chilcot",
      "indices" : [ 82, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/XjjzWJoKOd",
      "expanded_url" : "http:\/\/www.hansard-corpus.org\/x.asp?c=hans&q=48990338",
      "display_url" : "hansard-corpus.org\/x.asp?c=hans&q\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "751126596451438592",
  "text" : "Blair does not use \"whatever\" sentence final in his parl speeches #chilcotgrammar #chilcot https:\/\/t.co\/XjjzWJoKOd https:\/\/t.co\/HPlinMDsGm",
  "id" : 751126596451438592,
  "created_at" : "2016-07-07 18:51:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "...david jones",
      "screen_name" : "_dpaj",
      "indices" : [ 3, 9 ],
      "id_str" : "289148078",
      "id" : 289148078
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/_dpaj\/status\/751041177395265536\/photo\/1",
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/C1d9XgLSaf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cmw79-qXEAQ8JQx.jpg",
      "id_str" : "751041173842759684",
      "id" : 751041173842759684,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cmw79-qXEAQ8JQx.jpg",
      "sizes" : [ {
        "h" : 608,
        "resize" : "fit",
        "w" : 608
      }, {
        "h" : 608,
        "resize" : "fit",
        "w" : 608
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 608,
        "resize" : "fit",
        "w" : 608
      }, {
        "h" : 608,
        "resize" : "fit",
        "w" : 608
      } ],
      "display_url" : "pic.twitter.com\/C1d9XgLSaf"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/aEcjJYw1bh",
      "expanded_url" : "http:\/\/buff.ly\/29kgexb",
      "display_url" : "buff.ly\/29kgexb"
    } ]
  },
  "geo" : { },
  "id_str" : "751075215522889728",
  "text" : "RT @_dpaj: Matt https:\/\/t.co\/aEcjJYw1bh https:\/\/t.co\/C1d9XgLSaf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/_dpaj\/status\/751041177395265536\/photo\/1",
        "indices" : [ 29, 52 ],
        "url" : "https:\/\/t.co\/C1d9XgLSaf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cmw79-qXEAQ8JQx.jpg",
        "id_str" : "751041173842759684",
        "id" : 751041173842759684,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cmw79-qXEAQ8JQx.jpg",
        "sizes" : [ {
          "h" : 608,
          "resize" : "fit",
          "w" : 608
        }, {
          "h" : 608,
          "resize" : "fit",
          "w" : 608
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 608,
          "resize" : "fit",
          "w" : 608
        }, {
          "h" : 608,
          "resize" : "fit",
          "w" : 608
        } ],
        "display_url" : "pic.twitter.com\/C1d9XgLSaf"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 5, 28 ],
        "url" : "https:\/\/t.co\/aEcjJYw1bh",
        "expanded_url" : "http:\/\/buff.ly\/29kgexb",
        "display_url" : "buff.ly\/29kgexb"
      } ]
    },
    "geo" : { },
    "id_str" : "751041177395265536",
    "text" : "Matt https:\/\/t.co\/aEcjJYw1bh https:\/\/t.co\/C1d9XgLSaf",
    "id" : 751041177395265536,
    "created_at" : "2016-07-07 13:12:25 +0000",
    "user" : {
      "name" : "...david jones",
      "screen_name" : "_dpaj",
      "protected" : false,
      "id_str" : "289148078",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714317505574125568\/0czf-vIE_normal.jpg",
      "id" : 289148078,
      "verified" : false
    }
  },
  "id" : 751075215522889728,
  "created_at" : "2016-07-07 15:27:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/751065221956001792\/photo\/1",
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/bHAXDnV3lG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmxR0KLXgAAW8pv.jpg",
      "id_str" : "751065194391109632",
      "id" : 751065194391109632,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmxR0KLXgAAW8pv.jpg",
      "sizes" : [ {
        "h" : 421,
        "resize" : "fit",
        "w" : 788
      }, {
        "h" : 421,
        "resize" : "fit",
        "w" : 788
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 421,
        "resize" : "fit",
        "w" : 788
      }, {
        "h" : 363,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/bHAXDnV3lG"
    } ],
    "hashtags" : [ {
      "text" : "chilcotgrammar",
      "indices" : [ 55, 70 ]
    }, {
      "text" : "chilcot",
      "indices" : [ 71, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/rFjJHMWCH3",
      "expanded_url" : "https:\/\/youtu.be\/iW2z5V1Y0ok?t=58s",
      "display_url" : "youtu.be\/iW2z5V1Y0ok?t=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "751065221956001792",
  "text" : "...what Sadamm had had in the recent past. Jack Straw. #chilcotgrammar #chilcot https:\/\/t.co\/rFjJHMWCH3 https:\/\/t.co\/bHAXDnV3lG",
  "id" : 751065221956001792,
  "created_at" : "2016-07-07 14:47:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 0, 15 ],
      "id_str" : "285614027",
      "id" : 285614027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751051537447813120",
  "geo" : { },
  "id_str" : "751054347652456449",
  "in_reply_to_user_id" : 285614027,
  "text" : "@AnthonyTeacher neat tip for the labelling thx \uD83D\uDE03",
  "id" : 751054347652456449,
  "in_reply_to_status_id" : 751051537447813120,
  "created_at" : "2016-07-07 14:04:45 +0000",
  "in_reply_to_screen_name" : "AnthonyTeacher",
  "in_reply_to_user_id_str" : "285614027",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 3, 18 ],
      "id_str" : "285614027",
      "id" : 285614027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/OX4UxqV7rL",
      "expanded_url" : "http:\/\/ift.tt\/29kp5OI",
      "display_url" : "ift.tt\/29kp5OI"
    } ]
  },
  "geo" : { },
  "id_str" : "751053935310467072",
  "text" : "RT @AnthonyTeacher: How to Use Audacity to Quickly Make Audio Clips https:\/\/t.co\/OX4UxqV7rL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 71 ],
        "url" : "https:\/\/t.co\/OX4UxqV7rL",
        "expanded_url" : "http:\/\/ift.tt\/29kp5OI",
        "display_url" : "ift.tt\/29kp5OI"
      } ]
    },
    "geo" : { },
    "id_str" : "751051537447813120",
    "text" : "How to Use Audacity to Quickly Make Audio Clips https:\/\/t.co\/OX4UxqV7rL",
    "id" : 751051537447813120,
    "created_at" : "2016-07-07 13:53:35 +0000",
    "user" : {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "protected" : false,
      "id_str" : "285614027",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/412336845658132481\/Om5kKuMQ_normal.jpeg",
      "id" : 285614027,
      "verified" : false
    }
  },
  "id" : 751053935310467072,
  "created_at" : "2016-07-07 14:03:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sec News Bot",
      "screen_name" : "SecNewsBot",
      "indices" : [ 3, 14 ],
      "id_str" : "4148888299",
      "id" : 4148888299
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/f7LgtjgRbh",
      "expanded_url" : "http:\/\/ift.tt\/29k6OFP",
      "display_url" : "ift.tt\/29k6OFP"
    } ]
  },
  "geo" : { },
  "id_str" : "751050390712553472",
  "text" : "RT @SecNewsBot: Hacker News - A Few Useful Mental Tools from Richard Feynman https:\/\/t.co\/f7LgtjgRbh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/f7LgtjgRbh",
        "expanded_url" : "http:\/\/ift.tt\/29k6OFP",
        "display_url" : "ift.tt\/29k6OFP"
      } ]
    },
    "geo" : { },
    "id_str" : "750809224708517898",
    "text" : "Hacker News - A Few Useful Mental Tools from Richard Feynman https:\/\/t.co\/f7LgtjgRbh",
    "id" : 750809224708517898,
    "created_at" : "2016-07-06 21:50:43 +0000",
    "user" : {
      "name" : "Sec News Bot",
      "screen_name" : "SecNewsBot",
      "protected" : false,
      "id_str" : "4148888299",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662701599769231360\/XUc4W7Xm_normal.jpg",
      "id" : 4148888299,
      "verified" : false
    }
  },
  "id" : 751050390712553472,
  "created_at" : "2016-07-07 13:49:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 3, 12 ],
      "id_str" : "134211317",
      "id" : 134211317
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Farage",
      "indices" : [ 14, 21 ]
    } ],
    "urls" : [ {
      "indices" : [ 126, 140 ],
      "url" : "https:\/\/t.co\/t12GJYkr9y",
      "expanded_url" : "https:\/\/goo.gl\/gjDlD7",
      "display_url" : "goo.gl\/gjDlD7"
    } ]
  },
  "geo" : { },
  "id_str" : "751027004074590209",
  "text" : "RT @josipa74: #Farage, having turned his racist-slime-spurting ray-gun onto the people of Britain, now \u2018wants his life back\u2019. https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Farage",
        "indices" : [ 0, 7 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/t12GJYkr9y",
        "expanded_url" : "https:\/\/goo.gl\/gjDlD7",
        "display_url" : "goo.gl\/gjDlD7"
      } ]
    },
    "geo" : { },
    "id_str" : "751025292303532032",
    "text" : "#Farage, having turned his racist-slime-spurting ray-gun onto the people of Britain, now \u2018wants his life back\u2019. https:\/\/t.co\/t12GJYkr9y",
    "id" : 751025292303532032,
    "created_at" : "2016-07-07 12:09:17 +0000",
    "user" : {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "protected" : false,
      "id_str" : "134211317",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/526853654377021441\/MtEFhYIs_normal.jpeg",
      "id" : 134211317,
      "verified" : false
    }
  },
  "id" : 751027004074590209,
  "created_at" : "2016-07-07 12:16:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Knight",
      "screen_name" : "nakanotim",
      "indices" : [ 0, 10 ],
      "id_str" : "295968758",
      "id" : 295968758
    }, {
      "name" : "GregMyers",
      "screen_name" : "GregMyers",
      "indices" : [ 11, 21 ],
      "id_str" : "16855808",
      "id" : 16855808
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751015011909337088",
  "geo" : { },
  "id_str" : "751015241455136768",
  "in_reply_to_user_id" : 295968758,
  "text" : "@nakanotim @GregMyers yeah i was thinking start of second gulf war; as many predicted then what has come to pass now",
  "id" : 751015241455136768,
  "in_reply_to_status_id" : 751015011909337088,
  "created_at" : "2016-07-07 11:29:21 +0000",
  "in_reply_to_screen_name" : "nakanotim",
  "in_reply_to_user_id_str" : "295968758",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GregMyers",
      "screen_name" : "GregMyers",
      "indices" : [ 0, 10 ],
      "id_str" : "16855808",
      "id" : 16855808
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "750597361093705728",
  "geo" : { },
  "id_str" : "751012318172090368",
  "in_reply_to_user_id" : 16855808,
  "text" : "@GregMyers Consideration: seminar was 13 years long? ; )",
  "id" : 751012318172090368,
  "in_reply_to_status_id" : 750597361093705728,
  "created_at" : "2016-07-07 11:17:44 +0000",
  "in_reply_to_screen_name" : "GregMyers",
  "in_reply_to_user_id_str" : "16855808",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TBLTchat",
      "screen_name" : "TBLT_chat",
      "indices" : [ 3, 13 ],
      "id_str" : "742333546421846016",
      "id" : 742333546421846016
    }, {
      "name" : "Laura Edwards",
      "screen_name" : "EdLaur",
      "indices" : [ 89, 96 ],
      "id_str" : "1834826917",
      "id" : 1834826917
    }, {
      "name" : "Helen Legge",
      "screen_name" : "ITLegge",
      "indices" : [ 143, 144 ],
      "id_str" : "2201561838",
      "id" : 2201561838
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tbltchat",
      "indices" : [ 15, 24 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/AivW4u1MeM",
      "expanded_url" : "https:\/\/padlet.com\/getgreatenglish\/tbltchat",
      "display_url" : "padlet.com\/getgreatenglis\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "750971538564931584",
  "text" : "RT @TBLT_chat: #tbltchat 2 Storified soon. Thanks all who took part. We have Padlet (thx @EdLaur) https:\/\/t.co\/AivW4u1MeM &amp; soon a task wik\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Laura Edwards",
        "screen_name" : "EdLaur",
        "indices" : [ 74, 81 ],
        "id_str" : "1834826917",
        "id" : 1834826917
      }, {
        "name" : "Helen Legge",
        "screen_name" : "ITLegge",
        "indices" : [ 135, 143 ],
        "id_str" : "2201561838",
        "id" : 2201561838
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tbltchat",
        "indices" : [ 0, 9 ]
      } ],
      "urls" : [ {
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/AivW4u1MeM",
        "expanded_url" : "https:\/\/padlet.com\/getgreatenglish\/tbltchat",
        "display_url" : "padlet.com\/getgreatenglis\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "750667458302783488",
    "text" : "#tbltchat 2 Storified soon. Thanks all who took part. We have Padlet (thx @EdLaur) https:\/\/t.co\/AivW4u1MeM &amp; soon a task wiki (thx @ITLegge)",
    "id" : 750667458302783488,
    "created_at" : "2016-07-06 12:27:23 +0000",
    "user" : {
      "name" : "TBLTchat",
      "screen_name" : "TBLT_chat",
      "protected" : false,
      "id_str" : "742333546421846016",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/742335422508896256\/Fh5Df1hw_normal.jpg",
      "id" : 742333546421846016,
      "verified" : false
    }
  },
  "id" : 750971538564931584,
  "created_at" : "2016-07-07 08:35:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "750763211239153664",
  "geo" : { },
  "id_str" : "750779795680718848",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco many happy returns Diane \uD83C\uDF82",
  "id" : 750779795680718848,
  "in_reply_to_status_id" : 750763211239153664,
  "created_at" : "2016-07-06 19:53:46 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harry Leslie Smith",
      "screen_name" : "Harryslaststand",
      "indices" : [ 3, 19 ],
      "id_str" : "209176493",
      "id" : 209176493
    }, {
      "name" : "Ian Austin",
      "screen_name" : "IanAustinMP",
      "indices" : [ 31, 43 ],
      "id_str" : "261782937",
      "id" : 261782937
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Chilcot",
      "indices" : [ 129, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/CMDc2i0mMi",
      "expanded_url" : "http:\/\/www.independent.co.uk\/news\/uk\/politics\/jeremy-corbyn-told-to-sit-down-and-shut-up-in-commons-as-he-criticises-iraq-war-after-publication-of-a7122871.html",
      "display_url" : "independent.co.uk\/news\/uk\/politi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "750747931272241153",
  "text" : "RT @Harryslaststand: Labour MP @IanAustinMP shames Labour and demeans all those who died in the Iraq War https:\/\/t.co\/CMDc2i0mMi #Chilcot",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ian Austin",
        "screen_name" : "IanAustinMP",
        "indices" : [ 10, 22 ],
        "id_str" : "261782937",
        "id" : 261782937
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Chilcot",
        "indices" : [ 108, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/CMDc2i0mMi",
        "expanded_url" : "http:\/\/www.independent.co.uk\/news\/uk\/politics\/jeremy-corbyn-told-to-sit-down-and-shut-up-in-commons-as-he-criticises-iraq-war-after-publication-of-a7122871.html",
        "display_url" : "independent.co.uk\/news\/uk\/politi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "750711217530949632",
    "text" : "Labour MP @IanAustinMP shames Labour and demeans all those who died in the Iraq War https:\/\/t.co\/CMDc2i0mMi #Chilcot",
    "id" : 750711217530949632,
    "created_at" : "2016-07-06 15:21:16 +0000",
    "user" : {
      "name" : "Harry Leslie Smith",
      "screen_name" : "Harryslaststand",
      "protected" : false,
      "id_str" : "209176493",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/466967124255072256\/qlM2P2Lo_normal.jpeg",
      "id" : 209176493,
      "verified" : false
    }
  },
  "id" : 750747931272241153,
  "created_at" : "2016-07-06 17:47:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vicky Loras",
      "screen_name" : "vickyloras",
      "indices" : [ 3, 14 ],
      "id_str" : "95957241",
      "id" : 95957241
    }, {
      "name" : "Andrew Campbell",
      "screen_name" : "acampbell99",
      "indices" : [ 30, 42 ],
      "id_str" : "54886076",
      "id" : 54886076
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Welsh",
      "indices" : [ 43, 49 ]
    }, {
      "text" : "languages",
      "indices" : [ 50, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/Rgi2hd6GfL",
      "expanded_url" : "https:\/\/twitter.com\/ProperSport\/status\/750706567499120641",
      "display_url" : "twitter.com\/ProperSport\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "750727199284666368",
  "text" : "RT @vickyloras: Go Wales! Via @acampbell99 #Welsh #languages https:\/\/t.co\/Rgi2hd6GfL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Campbell",
        "screen_name" : "acampbell99",
        "indices" : [ 14, 26 ],
        "id_str" : "54886076",
        "id" : 54886076
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Welsh",
        "indices" : [ 27, 33 ]
      }, {
        "text" : "languages",
        "indices" : [ 34, 44 ]
      } ],
      "urls" : [ {
        "indices" : [ 45, 68 ],
        "url" : "https:\/\/t.co\/Rgi2hd6GfL",
        "expanded_url" : "https:\/\/twitter.com\/ProperSport\/status\/750706567499120641",
        "display_url" : "twitter.com\/ProperSport\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "750717948592005121",
    "text" : "Go Wales! Via @acampbell99 #Welsh #languages https:\/\/t.co\/Rgi2hd6GfL",
    "id" : 750717948592005121,
    "created_at" : "2016-07-06 15:48:01 +0000",
    "user" : {
      "name" : "Vicky Loras",
      "screen_name" : "vickyloras",
      "protected" : false,
      "id_str" : "95957241",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/649856172317519872\/zNL8t04-_normal.jpg",
      "id" : 95957241,
      "verified" : false
    }
  },
  "id" : 750727199284666368,
  "created_at" : "2016-07-06 16:24:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ITV News",
      "screen_name" : "itvnews",
      "indices" : [ 3, 11 ],
      "id_str" : "21866939",
      "id" : 21866939
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Chilcot",
      "indices" : [ 100, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/1f9wZ9OKQR",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/5270741d-2953-4c4b-820e-b18f6fe8599c",
      "display_url" : "amp.twimg.com\/v\/5270741d-295\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "750675127206019072",
  "text" : "RT @itvnews: Sister of soldier killed in Iraq brands Tony Blair the 'world's worst terrorist' after #Chilcot report\nhttps:\/\/t.co\/1f9wZ9OKQR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Chilcot",
        "indices" : [ 87, 95 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/1f9wZ9OKQR",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/5270741d-2953-4c4b-820e-b18f6fe8599c",
        "display_url" : "amp.twimg.com\/v\/5270741d-295\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "750663449823186945",
    "text" : "Sister of soldier killed in Iraq brands Tony Blair the 'world's worst terrorist' after #Chilcot report\nhttps:\/\/t.co\/1f9wZ9OKQR",
    "id" : 750663449823186945,
    "created_at" : "2016-07-06 12:11:27 +0000",
    "user" : {
      "name" : "ITV News",
      "screen_name" : "itvnews",
      "protected" : false,
      "id_str" : "21866939",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3105933720\/17bab587f151975ca4ae9f6a1cab7c56_normal.png",
      "id" : 21866939,
      "verified" : true
    }
  },
  "id" : 750675127206019072,
  "created_at" : "2016-07-06 12:57:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Mason",
      "screen_name" : "paulmasonnews",
      "indices" : [ 3, 17 ],
      "id_str" : "19811190",
      "id" : 19811190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "https:\/\/t.co\/fxrZ3mx67z",
      "expanded_url" : "http:\/\/www.theyworkforyou.com\/mp\/11553\/ian_austin\/dudley_north\/divisions?policy=975",
      "display_url" : "theyworkforyou.com\/mp\/11553\/ian_a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "750673456291864576",
  "text" : "RT @paulmasonnews: Ian Austin MP - the Labour warmonger who heckled Corbyn - voted 3 times against an Inquiry into Iraq https:\/\/t.co\/fxrZ3m\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/fxrZ3mx67z",
        "expanded_url" : "http:\/\/www.theyworkforyou.com\/mp\/11553\/ian_austin\/dudley_north\/divisions?policy=975",
        "display_url" : "theyworkforyou.com\/mp\/11553\/ian_a\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "750662173760876545",
    "text" : "Ian Austin MP - the Labour warmonger who heckled Corbyn - voted 3 times against an Inquiry into Iraq https:\/\/t.co\/fxrZ3mx67z",
    "id" : 750662173760876545,
    "created_at" : "2016-07-06 12:06:23 +0000",
    "user" : {
      "name" : "Paul Mason",
      "screen_name" : "paulmasonnews",
      "protected" : false,
      "id_str" : "19811190",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/659751288452837376\/LCEtJkZT_normal.png",
      "id" : 19811190,
      "verified" : true
    }
  },
  "id" : 750673456291864576,
  "created_at" : "2016-07-06 12:51:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "indices" : [ 3, 18 ],
      "id_str" : "27716419",
      "id" : 27716419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "750647052565118976",
  "text" : "RT @CraigMurrayOrg: Chilcot has provided excellent ammunition. Look to Alex Salmond and Jeremy Corbyn to fire it.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "750645176620703744",
    "text" : "Chilcot has provided excellent ammunition. Look to Alex Salmond and Jeremy Corbyn to fire it.",
    "id" : 750645176620703744,
    "created_at" : "2016-07-06 10:58:51 +0000",
    "user" : {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "protected" : false,
      "id_str" : "27716419",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1388436826\/cm_normal.jpg",
      "id" : 27716419,
      "verified" : false
    }
  },
  "id" : 750647052565118976,
  "created_at" : "2016-07-06 11:06:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((David Traynier)))",
      "screen_name" : "DTraynier",
      "indices" : [ 3, 13 ],
      "id_str" : "317716198",
      "id" : 317716198
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Chilcot",
      "indices" : [ 61, 69 ]
    }, {
      "text" : "ImpeachBlair",
      "indices" : [ 119, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "750646256247181312",
  "text" : "RT @DTraynier: This is not hindsight. Pretty much everything #Chilcot has said, opponents of the war said at the time. #ImpeachBlair",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Chilcot",
        "indices" : [ 46, 54 ]
      }, {
        "text" : "ImpeachBlair",
        "indices" : [ 104, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "750644724625801216",
    "text" : "This is not hindsight. Pretty much everything #Chilcot has said, opponents of the war said at the time. #ImpeachBlair",
    "id" : 750644724625801216,
    "created_at" : "2016-07-06 10:57:03 +0000",
    "user" : {
      "name" : "(((David Traynier)))",
      "screen_name" : "DTraynier",
      "protected" : false,
      "id_str" : "317716198",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727929911877480451\/fLuwL370_normal.jpg",
      "id" : 317716198,
      "verified" : false
    }
  },
  "id" : 750646256247181312,
  "created_at" : "2016-07-06 11:03:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ashok Ahir",
      "screen_name" : "ashokahir",
      "indices" : [ 3, 13 ],
      "id_str" : "109241335",
      "id" : 109241335
    }, {
      "name" : "Gareth Davies Author",
      "screen_name" : "GarethCZ",
      "indices" : [ 81, 90 ],
      "id_str" : "53616024",
      "id" : 53616024
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 103, 112 ],
      "id_str" : "18602422",
      "id" : 18602422
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Wal",
      "indices" : [ 115, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 140 ],
      "url" : "https:\/\/t.co\/ygxBuTHIS3",
      "expanded_url" : "https:\/\/vimeo.com\/173387156",
      "display_url" : "vimeo.com\/173387156"
    } ]
  },
  "geo" : { },
  "id_str" : "750619068311465985",
  "text" : "RT @ashokahir: Dwli ar hwn! \nAbsolutely love this!\n'Joe Ledley's Super Beard' by @GarethCZ animated by @muranava  \n#Wal \nhttps:\/\/t.co\/ygxBu\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gareth Davies Author",
        "screen_name" : "GarethCZ",
        "indices" : [ 66, 75 ],
        "id_str" : "53616024",
        "id" : 53616024
      }, {
        "name" : "Mura Nava",
        "screen_name" : "muranava",
        "indices" : [ 88, 97 ],
        "id_str" : "18602422",
        "id" : 18602422
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Wal",
        "indices" : [ 100, 104 ]
      } ],
      "urls" : [ {
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/ygxBuTHIS3",
        "expanded_url" : "https:\/\/vimeo.com\/173387156",
        "display_url" : "vimeo.com\/173387156"
      } ]
    },
    "geo" : { },
    "id_str" : "750358917855711232",
    "text" : "Dwli ar hwn! \nAbsolutely love this!\n'Joe Ledley's Super Beard' by @GarethCZ animated by @muranava  \n#Wal \nhttps:\/\/t.co\/ygxBuTHIS3",
    "id" : 750358917855711232,
    "created_at" : "2016-07-05 16:01:21 +0000",
    "user" : {
      "name" : "Ashok Ahir",
      "screen_name" : "ashokahir",
      "protected" : false,
      "id_str" : "109241335",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2033396148\/rsz_twitpic_normal.jpg",
      "id" : 109241335,
      "verified" : false
    }
  },
  "id" : 750619068311465985,
  "created_at" : "2016-07-06 09:15:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/eZFfR4B1KA",
      "expanded_url" : "https:\/\/www.craigmurray.org.uk\/archives\/2016\/07\/blair-can-tried-war-crimes\/",
      "display_url" : "craigmurray.org.uk\/archives\/2016\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "750565223787028480",
  "text" : "RT @pchallinor: \"Nobody who fails to meet those criteria will ever be tried at the Hague\" https:\/\/t.co\/eZFfR4B1KA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/eZFfR4B1KA",
        "expanded_url" : "https:\/\/www.craigmurray.org.uk\/archives\/2016\/07\/blair-can-tried-war-crimes\/",
        "display_url" : "craigmurray.org.uk\/archives\/2016\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "750462814477774849",
    "text" : "\"Nobody who fails to meet those criteria will ever be tried at the Hague\" https:\/\/t.co\/eZFfR4B1KA",
    "id" : 750462814477774849,
    "created_at" : "2016-07-05 22:54:12 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 750565223787028480,
  "created_at" : "2016-07-06 05:41:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Adele Soracco",
      "screen_name" : "LauraSoracco",
      "indices" : [ 0, 13 ],
      "id_str" : "15663328",
      "id" : 15663328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/ZAcXHfJCMR",
      "expanded_url" : "https:\/\/wikileaks.org\/clinton-emails\/",
      "display_url" : "wikileaks.org\/clinton-emails\/"
    } ]
  },
  "geo" : { },
  "id_str" : "750405816671502336",
  "in_reply_to_user_id" : 15663328,
  "text" : "@LauraSoracco this interface to Clinton emails could be handy https:\/\/t.co\/ZAcXHfJCMR",
  "id" : 750405816671502336,
  "created_at" : "2016-07-05 19:07:43 +0000",
  "in_reply_to_screen_name" : "LauraSoracco",
  "in_reply_to_user_id_str" : "15663328",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "patrick",
      "screen_name" : "patrickamon",
      "indices" : [ 3, 15 ],
      "id_str" : "46382179",
      "id" : 46382179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/JbxquwfQBw",
      "expanded_url" : "http:\/\/www.thecanary.co\/2016\/07\/05\/fresh-revelations-show-blairite-pr-company-manufactured-labour-coup-exclusive\/",
      "display_url" : "thecanary.co\/2016\/07\/05\/fre\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "750403193981562880",
  "text" : "RT @patrickamon: https:\/\/t.co\/JbxquwfQBw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/JbxquwfQBw",
        "expanded_url" : "http:\/\/www.thecanary.co\/2016\/07\/05\/fresh-revelations-show-blairite-pr-company-manufactured-labour-coup-exclusive\/",
        "display_url" : "thecanary.co\/2016\/07\/05\/fre\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "750391246233952256",
    "text" : "https:\/\/t.co\/JbxquwfQBw",
    "id" : 750391246233952256,
    "created_at" : "2016-07-05 18:09:49 +0000",
    "user" : {
      "name" : "patrick",
      "screen_name" : "patrickamon",
      "protected" : false,
      "id_str" : "46382179",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749896637603012609\/VxzFoEDQ_normal.jpg",
      "id" : 46382179,
      "verified" : false
    }
  },
  "id" : 750403193981562880,
  "created_at" : "2016-07-05 18:57:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian",
      "screen_name" : "IanHopkinson_",
      "indices" : [ 3, 17 ],
      "id_str" : "68139427",
      "id" : 68139427
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "750336158610186240",
  "text" : "RT @IanHopkinson_: I think there needs to be a full investigation into Eton School into how it radicalises young men leading to destructive\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "749861809507667968",
    "text" : "I think there needs to be a full investigation into Eton School into how it radicalises young men leading to destructive behaviour",
    "id" : 749861809507667968,
    "created_at" : "2016-07-04 07:06:01 +0000",
    "user" : {
      "name" : "Ian",
      "screen_name" : "IanHopkinson_",
      "protected" : false,
      "id_str" : "68139427",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746390420637290500\/p8PdWJnv_normal.jpg",
      "id" : 68139427,
      "verified" : false
    }
  },
  "id" : 750336158610186240,
  "created_at" : "2016-07-05 14:30:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    }, {
      "name" : "Huw Jarvis",
      "screen_name" : "TESOLacademic",
      "indices" : [ 17, 31 ],
      "id_str" : "43409552",
      "id" : 43409552
    }, {
      "name" : "Jane Cohen",
      "screen_name" : "JaneCohenEFL",
      "indices" : [ 32, 45 ],
      "id_str" : "705261589",
      "id" : 705261589
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tbltchat",
      "indices" : [ 81, 90 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "750321157983772676",
  "geo" : { },
  "id_str" : "750324601373224960",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish @TESOLacademic @JaneCohenEFL maybe Ur suggested an alternative? #tbltchat",
  "id" : 750324601373224960,
  "in_reply_to_status_id" : 750321157983772676,
  "created_at" : "2016-07-05 13:44:59 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    }, {
      "name" : "Huw Jarvis",
      "screen_name" : "TESOLacademic",
      "indices" : [ 17, 31 ],
      "id_str" : "43409552",
      "id" : 43409552
    }, {
      "name" : "Jane Cohen",
      "screen_name" : "JaneCohenEFL",
      "indices" : [ 32, 45 ],
      "id_str" : "705261589",
      "id" : 705261589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "750300433587982336",
  "geo" : { },
  "id_str" : "750319845539975168",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish @TESOLacademic @JaneCohenEFL for assessment Ur has a point I think re rubrics not based on learner performance?",
  "id" : 750319845539975168,
  "in_reply_to_status_id" : 750300433587982336,
  "created_at" : "2016-07-05 13:26:06 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Patsko",
      "screen_name" : "lauraahaha",
      "indices" : [ 3, 14 ],
      "id_str" : "97957137",
      "id" : 97957137
    }, {
      "name" : "Rolf Tynan",
      "screen_name" : "profrolf1",
      "indices" : [ 32, 42 ],
      "id_str" : "269808662",
      "id" : 269808662
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 98, 102 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 103, 111 ]
    }, {
      "text" : "edtech",
      "indices" : [ 112, 119 ]
    }, {
      "text" : "efl",
      "indices" : [ 120, 124 ]
    }, {
      "text" : "ebooks",
      "indices" : [ 125, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/qKbxWURKgm",
      "expanded_url" : "https:\/\/twitter.com\/CambridgeUPELT\/status\/749197221120401409",
      "display_url" : "twitter.com\/CambridgeUPELT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "750319420648648704",
  "text" : "RT @lauraahaha: My webinar with @profrolf1 is coming up in under an hour - hope to see you there! #elt #eltchat #edtech #efl #ebooks https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rolf Tynan",
        "screen_name" : "profrolf1",
        "indices" : [ 16, 26 ],
        "id_str" : "269808662",
        "id" : 269808662
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "elt",
        "indices" : [ 82, 86 ]
      }, {
        "text" : "eltchat",
        "indices" : [ 87, 95 ]
      }, {
        "text" : "edtech",
        "indices" : [ 96, 103 ]
      }, {
        "text" : "efl",
        "indices" : [ 104, 108 ]
      }, {
        "text" : "ebooks",
        "indices" : [ 109, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/qKbxWURKgm",
        "expanded_url" : "https:\/\/twitter.com\/CambridgeUPELT\/status\/749197221120401409",
        "display_url" : "twitter.com\/CambridgeUPELT\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "750314682548948992",
    "text" : "My webinar with @profrolf1 is coming up in under an hour - hope to see you there! #elt #eltchat #edtech #efl #ebooks https:\/\/t.co\/qKbxWURKgm",
    "id" : 750314682548948992,
    "created_at" : "2016-07-05 13:05:35 +0000",
    "user" : {
      "name" : "Laura Patsko",
      "screen_name" : "lauraahaha",
      "protected" : false,
      "id_str" : "97957137",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/659005852477714432\/xfuJsW6q_normal.jpg",
      "id" : 97957137,
      "verified" : false
    }
  },
  "id" : 750319420648648704,
  "created_at" : "2016-07-05 13:24:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Jones",
      "screen_name" : "getgreatenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "2273617656",
      "id" : 2273617656
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tbltchat",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "750316981757157380",
  "geo" : { },
  "id_str" : "750318274110451712",
  "in_reply_to_user_id" : 2273617656,
  "text" : "@getgreatenglish for exam classes often, heard gd things about Ur book #tbltchat",
  "id" : 750318274110451712,
  "in_reply_to_status_id" : 750316981757157380,
  "created_at" : "2016-07-05 13:19:51 +0000",
  "in_reply_to_screen_name" : "getgreatenglish",
  "in_reply_to_user_id_str" : "2273617656",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "williamjturkel",
      "screen_name" : "williamjturkel",
      "indices" : [ 3, 18 ],
      "id_str" : "9280142",
      "id" : 9280142
    }, {
      "name" : "Gavagai",
      "screen_name" : "gavagai_corp",
      "indices" : [ 60, 73 ],
      "id_str" : "44869788",
      "id" : 44869788
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/iv09zb87pa",
      "expanded_url" : "http:\/\/lexicon.gavagai.se\/",
      "display_url" : "lexicon.gavagai.se"
    } ]
  },
  "geo" : { },
  "id_str" : "750316911540465664",
  "text" : "RT @williamjturkel: Exploring the Living Lexicon created by @gavagai_corp https:\/\/t.co\/iv09zb87pa Fascinating resource",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gavagai",
        "screen_name" : "gavagai_corp",
        "indices" : [ 40, 53 ],
        "id_str" : "44869788",
        "id" : 44869788
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 77 ],
        "url" : "https:\/\/t.co\/iv09zb87pa",
        "expanded_url" : "http:\/\/lexicon.gavagai.se\/",
        "display_url" : "lexicon.gavagai.se"
      } ]
    },
    "geo" : { },
    "id_str" : "750312533534334978",
    "text" : "Exploring the Living Lexicon created by @gavagai_corp https:\/\/t.co\/iv09zb87pa Fascinating resource",
    "id" : 750312533534334978,
    "created_at" : "2016-07-05 12:57:02 +0000",
    "user" : {
      "name" : "williamjturkel",
      "screen_name" : "williamjturkel",
      "protected" : false,
      "id_str" : "9280142",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/32501472\/spoka-twitter_normal.jpg",
      "id" : 9280142,
      "verified" : false
    }
  },
  "id" : 750316911540465664,
  "created_at" : "2016-07-05 13:14:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Emersberger",
      "screen_name" : "rosendo_joe",
      "indices" : [ 3, 15 ],
      "id_str" : "3351345863",
      "id" : 3351345863
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/rosendo_joe\/status\/750272620319371264\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/a5ZKWR4tQv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmmA8vdW8AAyc4-.jpg",
      "id_str" : "750272593954009088",
      "id" : 750272593954009088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmmA8vdW8AAyc4-.jpg",
      "sizes" : [ {
        "h" : 499,
        "resize" : "fit",
        "w" : 653
      }, {
        "h" : 499,
        "resize" : "fit",
        "w" : 653
      }, {
        "h" : 499,
        "resize" : "fit",
        "w" : 653
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 499,
        "resize" : "fit",
        "w" : 653
      } ],
      "display_url" : "pic.twitter.com\/a5ZKWR4tQv"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/fwUFOZmY9w",
      "expanded_url" : "https:\/\/www.theguardian.com\/commentisfree\/2016\/jul\/05\/political-establishment-momentum-jeremy-corbyn",
      "display_url" : "theguardian.com\/commentisfree\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "750273322118701056",
  "text" : "RT @rosendo_joe: I am not a David Graeber fan at all but this piece is really on target\nhttps:\/\/t.co\/fwUFOZmY9w https:\/\/t.co\/a5ZKWR4tQv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/rosendo_joe\/status\/750272620319371264\/photo\/1",
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/a5ZKWR4tQv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmmA8vdW8AAyc4-.jpg",
        "id_str" : "750272593954009088",
        "id" : 750272593954009088,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmmA8vdW8AAyc4-.jpg",
        "sizes" : [ {
          "h" : 499,
          "resize" : "fit",
          "w" : 653
        }, {
          "h" : 499,
          "resize" : "fit",
          "w" : 653
        }, {
          "h" : 499,
          "resize" : "fit",
          "w" : 653
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 499,
          "resize" : "fit",
          "w" : 653
        } ],
        "display_url" : "pic.twitter.com\/a5ZKWR4tQv"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/fwUFOZmY9w",
        "expanded_url" : "https:\/\/www.theguardian.com\/commentisfree\/2016\/jul\/05\/political-establishment-momentum-jeremy-corbyn",
        "display_url" : "theguardian.com\/commentisfree\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "750272620319371264",
    "text" : "I am not a David Graeber fan at all but this piece is really on target\nhttps:\/\/t.co\/fwUFOZmY9w https:\/\/t.co\/a5ZKWR4tQv",
    "id" : 750272620319371264,
    "created_at" : "2016-07-05 10:18:26 +0000",
    "user" : {
      "name" : "Joe Emersberger",
      "screen_name" : "rosendo_joe",
      "protected" : false,
      "id_str" : "3351345863",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/621112707522142209\/OGmLR1xt_normal.jpg",
      "id" : 3351345863,
      "verified" : false
    }
  },
  "id" : 750273322118701056,
  "created_at" : "2016-07-05 10:21:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greg Borenstein",
      "screen_name" : "atduskgreg",
      "indices" : [ 104, 115 ],
      "id_str" : "26853",
      "id" : 26853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/uMSfBPh6M9",
      "expanded_url" : "https:\/\/medium.com\/@atduskgreg\/power-to-the-people-how-one-unknown-group-of-researchers-holds-the-key-to-using-ai-to-solve-real-cc9e75b1f334#.5j37tks1l",
      "display_url" : "medium.com\/@atduskgreg\/po\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "750267245469765632",
  "text" : "\u201CPower to the People: How One Unknown Group of Researchers Holds the Key to Using AI to Solve Real\u2026\u201D by @atduskgreg https:\/\/t.co\/uMSfBPh6M9",
  "id" : 750267245469765632,
  "created_at" : "2016-07-05 09:57:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gareth davies",
      "screen_name" : "reasons4",
      "indices" : [ 27, 36 ],
      "id_str" : "413454135",
      "id" : 413454135
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wal",
      "indices" : [ 61, 65 ]
    }, {
      "text" : "EURO2016",
      "indices" : [ 66, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/ExrxUhI4bs",
      "expanded_url" : "https:\/\/vimeo.com\/173387156",
      "display_url" : "vimeo.com\/173387156"
    } ]
  },
  "geo" : { },
  "id_str" : "750082959898730496",
  "text" : "Joe Ledleys Super Beard by @reasons4 https:\/\/t.co\/ExrxUhI4bs #wal #EURO2016",
  "id" : 750082959898730496,
  "created_at" : "2016-07-04 21:44:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alexis anais",
      "screen_name" : "holyurl",
      "indices" : [ 3, 11 ],
      "id_str" : "172227116",
      "id" : 172227116
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/holyurl\/status\/750060560692211712\/photo\/1",
      "indices" : [ 126, 140 ],
      "url" : "https:\/\/t.co\/4RFpWhPhUN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmjAGWdWcAA5uoN.jpg",
      "id_str" : "750060553297620992",
      "id" : 750060553297620992,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmjAGWdWcAA5uoN.jpg",
      "sizes" : [ {
        "h" : 540,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 540,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 540,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/4RFpWhPhUN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "750079141114941441",
  "text" : "RT @holyurl: a 4th of july appropriate meme i made a while ago; god bless addiction and the soon to burst student loan bubble https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/holyurl\/status\/750060560692211712\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/4RFpWhPhUN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmjAGWdWcAA5uoN.jpg",
        "id_str" : "750060553297620992",
        "id" : 750060553297620992,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmjAGWdWcAA5uoN.jpg",
        "sizes" : [ {
          "h" : 540,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 540,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 540,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/4RFpWhPhUN"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "750060560692211712",
    "text" : "a 4th of july appropriate meme i made a while ago; god bless addiction and the soon to burst student loan bubble https:\/\/t.co\/4RFpWhPhUN",
    "id" : 750060560692211712,
    "created_at" : "2016-07-04 20:15:47 +0000",
    "user" : {
      "name" : "alexis anais",
      "screen_name" : "holyurl",
      "protected" : false,
      "id_str" : "172227116",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766152358158008321\/zYWrbtr3_normal.jpg",
      "id" : 172227116,
      "verified" : false
    }
  },
  "id" : 750079141114941441,
  "created_at" : "2016-07-04 21:29:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan L. Sink",
      "screen_name" : "YourBusinessInE",
      "indices" : [ 0, 16 ],
      "id_str" : "3003970257",
      "id" : 3003970257
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "750041569991032832",
  "geo" : { },
  "id_str" : "750045543301312516",
  "in_reply_to_user_id" : 3003970257,
  "text" : "@YourBusinessInE you know i have noticed u keep posting this : ) there could be an abstainer bias working here?",
  "id" : 750045543301312516,
  "in_reply_to_status_id" : 750041569991032832,
  "created_at" : "2016-07-04 19:16:07 +0000",
  "in_reply_to_screen_name" : "YourBusinessInE",
  "in_reply_to_user_id_str" : "3003970257",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 0, 9 ],
      "id_str" : "134211317",
      "id" : 134211317
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "750037473573605376",
  "geo" : { },
  "id_str" : "750044873521266688",
  "in_reply_to_user_id" : 134211317,
  "text" : "@josipa74 wld not qualify as a pilot, wld struggle to get on a primary school play",
  "id" : 750044873521266688,
  "in_reply_to_status_id" : 750037473573605376,
  "created_at" : "2016-07-04 19:13:27 +0000",
  "in_reply_to_screen_name" : "josipa74",
  "in_reply_to_user_id_str" : "134211317",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/zSR3BgrLkC",
      "expanded_url" : "http:\/\/www.washingtonsblog.com\/2016\/07\/mumia-abu-jamals-fourth-of-july.html",
      "display_url" : "washingtonsblog.com\/2016\/07\/mumia-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "750014409179791360",
  "text" : "Mumia Abu-Jamal\u2019s Fourth of July https:\/\/t.co\/zSR3BgrLkC",
  "id" : 750014409179791360,
  "created_at" : "2016-07-04 17:12:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/POEjBKKdSB",
      "expanded_url" : "http:\/\/www.independent.co.uk\/news\/uk\/politics\/chilcot-report-tony-blair-iraq-war-inquiry-saddam-hussein-evidence-weapons-mass-destruction-lord-a7118696.html",
      "display_url" : "independent.co.uk\/news\/uk\/politi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "749987281453350912",
  "text" : "RT @pchallinor: Reverend Tony believed in his belief in what Reverend Tony believed, says psychic Lord Butler https:\/\/t.co\/POEjBKKdSB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/POEjBKKdSB",
        "expanded_url" : "http:\/\/www.independent.co.uk\/news\/uk\/politics\/chilcot-report-tony-blair-iraq-war-inquiry-saddam-hussein-evidence-weapons-mass-destruction-lord-a7118696.html",
        "display_url" : "independent.co.uk\/news\/uk\/politi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "749985034992517120",
    "text" : "Reverend Tony believed in his belief in what Reverend Tony believed, says psychic Lord Butler https:\/\/t.co\/POEjBKKdSB",
    "id" : 749985034992517120,
    "created_at" : "2016-07-04 15:15:41 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 749987281453350912,
  "created_at" : "2016-07-04 15:24:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Noble",
      "screen_name" : "tesolmatthew",
      "indices" : [ 0, 13 ],
      "id_str" : "1519875330",
      "id" : 1519875330
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/749811800028409857\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/QorXwntC1I",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmfdarGWgAQ72Dh.jpg",
      "id_str" : "749811313296179204",
      "id" : 749811313296179204,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmfdarGWgAQ72Dh.jpg",
      "sizes" : [ {
        "h" : 120,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 133,
        "resize" : "fit",
        "w" : 754
      }, {
        "h" : 133,
        "resize" : "fit",
        "w" : 754
      }, {
        "h" : 133,
        "resize" : "fit",
        "w" : 754
      }, {
        "h" : 133,
        "resize" : "crop",
        "w" : 133
      } ],
      "display_url" : "pic.twitter.com\/QorXwntC1I"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "728046647486226433",
  "geo" : { },
  "id_str" : "749811800028409857",
  "in_reply_to_user_id" : 1519875330,
  "text" : "@tesolmatthew saw this in recent reading from English Prepositions Explained which reminded me of this thread https:\/\/t.co\/QorXwntC1I",
  "id" : 749811800028409857,
  "in_reply_to_status_id" : 728046647486226433,
  "created_at" : "2016-07-04 03:47:18 +0000",
  "in_reply_to_screen_name" : "tesolmatthew",
  "in_reply_to_user_id_str" : "1519875330",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gareth davies",
      "screen_name" : "reasons4",
      "indices" : [ 3, 12 ],
      "id_str" : "413454135",
      "id" : 413454135
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JoeLedley",
      "indices" : [ 46, 56 ]
    }, {
      "text" : "amwriting",
      "indices" : [ 97, 107 ]
    }, {
      "text" : "sundayblogshare",
      "indices" : [ 108, 124 ]
    }, {
      "text" : "TogetherStronger",
      "indices" : [ 125, 140 ]
    }, {
      "text" : "WAL",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "Wales",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/EtBjIkFIm3",
      "expanded_url" : "http:\/\/garethsshortstoryblog.blogspot.co.uk\/2016\/07\/joe-ledleys-super-beard.html",
      "display_url" : "garethsshortstoryblog.blogspot.co.uk\/2016\/07\/joe-le\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "749546033223458816",
  "text" : "RT @reasons4: Just added audio to my hit poem #JoeLedley's Super Beard - https:\/\/t.co\/EtBjIkFIm3 #amwriting #sundayblogshare #TogetherStron\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JoeLedley",
        "indices" : [ 32, 42 ]
      }, {
        "text" : "amwriting",
        "indices" : [ 83, 93 ]
      }, {
        "text" : "sundayblogshare",
        "indices" : [ 94, 110 ]
      }, {
        "text" : "TogetherStronger",
        "indices" : [ 111, 128 ]
      }, {
        "text" : "WAL",
        "indices" : [ 129, 133 ]
      }, {
        "text" : "Wales",
        "indices" : [ 134, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 59, 82 ],
        "url" : "https:\/\/t.co\/EtBjIkFIm3",
        "expanded_url" : "http:\/\/garethsshortstoryblog.blogspot.co.uk\/2016\/07\/joe-ledleys-super-beard.html",
        "display_url" : "garethsshortstoryblog.blogspot.co.uk\/2016\/07\/joe-le\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "749543561922748416",
    "text" : "Just added audio to my hit poem #JoeLedley's Super Beard - https:\/\/t.co\/EtBjIkFIm3 #amwriting #sundayblogshare #TogetherStronger #WAL #Wales",
    "id" : 749543561922748416,
    "created_at" : "2016-07-03 10:01:25 +0000",
    "user" : {
      "name" : "gareth davies",
      "screen_name" : "reasons4",
      "protected" : false,
      "id_str" : "413454135",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1640992210\/image_normal.jpg",
      "id" : 413454135,
      "verified" : false
    }
  },
  "id" : 749546033223458816,
  "created_at" : "2016-07-03 10:11:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 96, 104 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/LBn8u7uBZU",
      "expanded_url" : "https:\/\/youtu.be\/vmlVROxdKBQ",
      "display_url" : "youtu.be\/vmlVROxdKBQ"
    } ]
  },
  "geo" : { },
  "id_str" : "749361726236360705",
  "text" : "Barbara Ntumy and Graham Jones MP on BBC World News - July 30, 2016 https:\/\/t.co\/LBn8u7uBZU via @YouTube",
  "id" : 749361726236360705,
  "created_at" : "2016-07-02 21:58:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Krashen",
      "screen_name" : "skrashen",
      "indices" : [ 0, 9 ],
      "id_str" : "25624708",
      "id" : 25624708
    }, {
      "name" : "Diane Leedham",
      "screen_name" : "DiLeed",
      "indices" : [ 10, 17 ],
      "id_str" : "2335217159",
      "id" : 2335217159
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "749107131169648640",
  "geo" : { },
  "id_str" : "749357259260592129",
  "in_reply_to_user_id" : 25624708,
  "text" : "@skrashen @DiLeed skill building is not (Long's) interaction hypothesis?",
  "id" : 749357259260592129,
  "in_reply_to_status_id" : 749107131169648640,
  "created_at" : "2016-07-02 21:41:07 +0000",
  "in_reply_to_screen_name" : "skrashen",
  "in_reply_to_user_id_str" : "25624708",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Speech Events",
      "screen_name" : "SpeechEvents",
      "indices" : [ 62, 75 ],
      "id_str" : "1468444922",
      "id" : 1468444922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/T2jRkbqZxf",
      "expanded_url" : "https:\/\/speechevents.wordpress.com\/2016\/07\/02\/dear-2016-please-die-love-2016\/",
      "display_url" : "speechevents.wordpress.com\/2016\/07\/02\/dea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "749344436333715456",
  "text" : "Dear 2016, Please Die. Love, 2016 https:\/\/t.co\/T2jRkbqZxf via @speechevents",
  "id" : 749344436333715456,
  "created_at" : "2016-07-02 20:50:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Leedham",
      "screen_name" : "DiLeed",
      "indices" : [ 3, 10 ],
      "id_str" : "2335217159",
      "id" : 2335217159
    }, {
      "name" : "Sue Cowley",
      "screen_name" : "Sue_Cowley",
      "indices" : [ 30, 41 ],
      "id_str" : "1094790043",
      "id" : 1094790043
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/DiLeed\/status\/746257583816716288\/photo\/1",
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/hFQKLVN9C1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cls9Tf_XEAQnbDt.jpg",
      "id_str" : "746257568474009604",
      "id" : 746257568474009604,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cls9Tf_XEAQnbDt.jpg",
      "sizes" : [ {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/hFQKLVN9C1"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/DiLeed\/status\/746257583816716288\/photo\/1",
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/hFQKLVN9C1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cls9TonWEAATyMG.jpg",
      "id_str" : "746257570789199872",
      "id" : 746257570789199872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cls9TonWEAATyMG.jpg",
      "sizes" : [ {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/hFQKLVN9C1"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/DiLeed\/status\/746257583816716288\/photo\/1",
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/hFQKLVN9C1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cls9TpFXIAAhLPH.jpg",
      "id_str" : "746257570915098624",
      "id" : 746257570915098624,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cls9TpFXIAAhLPH.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/hFQKLVN9C1"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/DiLeed\/status\/746257583816716288\/photo\/1",
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/hFQKLVN9C1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cls9TpzWAAAQ7s_.jpg",
      "id_str" : "746257571107962880",
      "id" : 746257571107962880,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cls9TpzWAAAQ7s_.jpg",
      "sizes" : [ {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/hFQKLVN9C1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "749339145647120384",
  "text" : "RT @DiLeed: Did you see this? @Sue_Cowley A London schoolboy's tale https:\/\/t.co\/hFQKLVN9C1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sue Cowley",
        "screen_name" : "Sue_Cowley",
        "indices" : [ 18, 29 ],
        "id_str" : "1094790043",
        "id" : 1094790043
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/DiLeed\/status\/746257583816716288\/photo\/1",
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/hFQKLVN9C1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cls9Tf_XEAQnbDt.jpg",
        "id_str" : "746257568474009604",
        "id" : 746257568474009604,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cls9Tf_XEAQnbDt.jpg",
        "sizes" : [ {
          "h" : 1136,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 1136,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 383
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1136,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/hFQKLVN9C1"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/DiLeed\/status\/746257583816716288\/photo\/1",
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/hFQKLVN9C1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cls9TonWEAATyMG.jpg",
        "id_str" : "746257570789199872",
        "id" : 746257570789199872,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cls9TonWEAATyMG.jpg",
        "sizes" : [ {
          "h" : 1136,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 1136,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 383
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1136,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/hFQKLVN9C1"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/DiLeed\/status\/746257583816716288\/photo\/1",
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/hFQKLVN9C1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cls9TpFXIAAhLPH.jpg",
        "id_str" : "746257570915098624",
        "id" : 746257570915098624,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cls9TpFXIAAhLPH.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 383
        }, {
          "h" : 1136,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1136,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 1136,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/hFQKLVN9C1"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/DiLeed\/status\/746257583816716288\/photo\/1",
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/hFQKLVN9C1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cls9TpzWAAAQ7s_.jpg",
        "id_str" : "746257571107962880",
        "id" : 746257571107962880,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cls9TpzWAAAQ7s_.jpg",
        "sizes" : [ {
          "h" : 1136,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 1136,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 383
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1136,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/hFQKLVN9C1"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "746257583816716288",
    "text" : "Did you see this? @Sue_Cowley A London schoolboy's tale https:\/\/t.co\/hFQKLVN9C1",
    "id" : 746257583816716288,
    "created_at" : "2016-06-24 08:24:07 +0000",
    "user" : {
      "name" : "Diane Leedham",
      "screen_name" : "DiLeed",
      "protected" : false,
      "id_str" : "2335217159",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531591034740826112\/jFKHAmex_normal.jpeg",
      "id" : 2335217159,
      "verified" : false
    }
  },
  "id" : 749339145647120384,
  "created_at" : "2016-07-02 20:29:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "pip roberts",
      "screen_name" : "pipnotes",
      "indices" : [ 10, 19 ],
      "id_str" : "349594057",
      "id" : 349594057
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/749338365871398912\/photo\/1",
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/AkdNymS6Pc",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CmYvQ_kWcAAJc4R.jpg",
      "id_str" : "749338356992077824",
      "id" : 749338356992077824,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CmYvQ_kWcAAJc4R.jpg",
      "sizes" : [ {
        "h" : 200,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 200,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 200,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 200,
        "resize" : "fit",
        "w" : 300
      } ],
      "display_url" : "pic.twitter.com\/AkdNymS6Pc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "749321856847605760",
  "geo" : { },
  "id_str" : "749338365871398912",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava @pipnotes hi thx https:\/\/t.co\/AkdNymS6Pc",
  "id" : 749338365871398912,
  "in_reply_to_status_id" : 749321856847605760,
  "created_at" : "2016-07-02 20:26:03 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Charlie Stross)))",
      "screen_name" : "cstross",
      "indices" : [ 3, 11 ],
      "id_str" : "390039185",
      "id" : 390039185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/14RqSIOXkl",
      "expanded_url" : "http:\/\/www.gove2016.co.uk",
      "display_url" : "gove2016.co.uk"
    } ]
  },
  "geo" : { },
  "id_str" : "749329551906443269",
  "text" : "RT @cstross: Why you should ALWAYS register the domain BEFORE you announce the name of your election campaign: https:\/\/t.co\/14RqSIOXkl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/14RqSIOXkl",
        "expanded_url" : "http:\/\/www.gove2016.co.uk",
        "display_url" : "gove2016.co.uk"
      } ]
    },
    "geo" : { },
    "id_str" : "748916816638947328",
    "text" : "Why you should ALWAYS register the domain BEFORE you announce the name of your election campaign: https:\/\/t.co\/14RqSIOXkl",
    "id" : 748916816638947328,
    "created_at" : "2016-07-01 16:30:57 +0000",
    "user" : {
      "name" : "(((Charlie Stross)))",
      "screen_name" : "cstross",
      "protected" : false,
      "id_str" : "390039185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/646597762923016192\/ZzldboeL_normal.jpg",
      "id" : 390039185,
      "verified" : true
    }
  },
  "id" : 749329551906443269,
  "created_at" : "2016-07-02 19:51:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "749321856847605760",
  "geo" : { },
  "id_str" : "749323330109509632",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava \"appears to turn\" does not have the same theatrical appeal no doubt",
  "id" : 749323330109509632,
  "in_reply_to_status_id" : 749321856847605760,
  "created_at" : "2016-07-02 19:26:18 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/749321856847605760\/photo\/1",
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/kIsuqYFy6x",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmYgQC7WEAAw_38.jpg",
      "id_str" : "749321848039542784",
      "id" : 749321848039542784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmYgQC7WEAAw_38.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 675
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 720
      } ],
      "display_url" : "pic.twitter.com\/kIsuqYFy6x"
    } ],
    "hashtags" : [ {
      "text" : "corbynconcordancing",
      "indices" : [ 42, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/rPrfvRt5kv",
      "expanded_url" : "http:\/\/corpus.byu.edu\/coca\/?c=coca&q=48897746",
      "display_url" : "corpus.byu.edu\/coca\/?c=coca&q\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "749321856847605760",
  "text" : "Synonyms of lunge https:\/\/t.co\/rPrfvRt5kv #corbynconcordancing https:\/\/t.co\/kIsuqYFy6x",
  "id" : 749321856847605760,
  "created_at" : "2016-07-02 19:20:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/8gL4P0NxsI",
      "expanded_url" : "http:\/\/curmudgucation.blogspot.com\/2016\/07\/writing-junk.html?spref=tw",
      "display_url" : "curmudgucation.blogspot.com\/2016\/07\/writin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "749284158929825794",
  "text" : "CURMUDGUCATION: Writing Junk https:\/\/t.co\/8gL4P0NxsI",
  "id" : 749284158929825794,
  "created_at" : "2016-07-02 16:50:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 37, 45 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wal",
      "indices" : [ 47, 51 ]
    }, {
      "text" : "euro2016",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/URxeFiVZ4E",
      "expanded_url" : "https:\/\/youtu.be\/fqXpWvEW3ZU",
      "display_url" : "youtu.be\/fqXpWvEW3ZU"
    } ]
  },
  "geo" : { },
  "id_str" : "749278562243506176",
  "text" : "BingBong https:\/\/t.co\/URxeFiVZ4E via @YouTube  #wal #euro2016",
  "id" : 749278562243506176,
  "created_at" : "2016-07-02 16:28:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Lavigne",
      "screen_name" : "sam_lavigne",
      "indices" : [ 0, 12 ],
      "id_str" : "6428702",
      "id" : 6428702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "749251978564243457",
  "geo" : { },
  "id_str" : "749253669728751617",
  "in_reply_to_user_id" : 6428702,
  "text" : "@sam_lavigne Dishonest answer, no problem at all. Carry on business as usual. :\/",
  "id" : 749253669728751617,
  "in_reply_to_status_id" : 749251978564243457,
  "created_at" : "2016-07-02 14:49:29 +0000",
  "in_reply_to_screen_name" : "sam_lavigne",
  "in_reply_to_user_id_str" : "6428702",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 3, 18 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/GeoffreyJordan\/status\/749229500752203776\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/E4Y8I3bETe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmXMQgmUkAAn-W6.jpg",
      "id_str" : "749229497027694592",
      "id" : 749229497027694592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmXMQgmUkAAn-W6.jpg",
      "sizes" : [ {
        "h" : 499,
        "resize" : "fit",
        "w" : 347
      }, {
        "h" : 499,
        "resize" : "fit",
        "w" : 347
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 499,
        "resize" : "fit",
        "w" : 347
      }, {
        "h" : 499,
        "resize" : "fit",
        "w" : 347
      } ],
      "display_url" : "pic.twitter.com\/E4Y8I3bETe"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/y1NAyjRWaM",
      "expanded_url" : "https:\/\/criticalelt.wordpress.com\/2016\/07\/02\/rastellis-discontinuity-hypothesis-a-new-challenge-for-sla-researchers",
      "display_url" : "criticalelt.wordpress.com\/2016\/07\/02\/ras\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "749240730514784256",
  "text" : "RT @GeoffreyJordan: Rastelli\u2019s Discontinuity Hypothesis: a new challenge for SLA\u00A0researchers https:\/\/t.co\/y1NAyjRWaM https:\/\/t.co\/E4Y8I3bETe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/GeoffreyJordan\/status\/749229500752203776\/photo\/1",
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/E4Y8I3bETe",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmXMQgmUkAAn-W6.jpg",
        "id_str" : "749229497027694592",
        "id" : 749229497027694592,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmXMQgmUkAAn-W6.jpg",
        "sizes" : [ {
          "h" : 499,
          "resize" : "fit",
          "w" : 347
        }, {
          "h" : 499,
          "resize" : "fit",
          "w" : 347
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 499,
          "resize" : "fit",
          "w" : 347
        }, {
          "h" : 499,
          "resize" : "fit",
          "w" : 347
        } ],
        "display_url" : "pic.twitter.com\/E4Y8I3bETe"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/y1NAyjRWaM",
        "expanded_url" : "https:\/\/criticalelt.wordpress.com\/2016\/07\/02\/rastellis-discontinuity-hypothesis-a-new-challenge-for-sla-researchers",
        "display_url" : "criticalelt.wordpress.com\/2016\/07\/02\/ras\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "749229500752203776",
    "text" : "Rastelli\u2019s Discontinuity Hypothesis: a new challenge for SLA\u00A0researchers https:\/\/t.co\/y1NAyjRWaM https:\/\/t.co\/E4Y8I3bETe",
    "id" : 749229500752203776,
    "created_at" : "2016-07-02 13:13:27 +0000",
    "user" : {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "protected" : false,
      "id_str" : "334332424",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/455317817537986561\/SD4wNKO3_normal.jpeg",
      "id" : 334332424,
      "verified" : false
    }
  },
  "id" : 749240730514784256,
  "created_at" : "2016-07-02 13:58:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "indices" : [ 3, 14 ],
      "id_str" : "14663837",
      "id" : 14663837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/KpJVQAe1Sx",
      "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2016\/07\/significant-respect.html",
      "display_url" : "thecurmudgeonly.blogspot.co.uk\/2016\/07\/signif\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "749228145908350977",
  "text" : "RT @pchallinor: New mudgeonry: Significant respect https:\/\/t.co\/KpJVQAe1Sx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 58 ],
        "url" : "https:\/\/t.co\/KpJVQAe1Sx",
        "expanded_url" : "http:\/\/thecurmudgeonly.blogspot.co.uk\/2016\/07\/significant-respect.html",
        "display_url" : "thecurmudgeonly.blogspot.co.uk\/2016\/07\/signif\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "749224770982535168",
    "text" : "New mudgeonry: Significant respect https:\/\/t.co\/KpJVQAe1Sx",
    "id" : 749224770982535168,
    "created_at" : "2016-07-02 12:54:39 +0000",
    "user" : {
      "name" : "Philip Challinor",
      "screen_name" : "pchallinor",
      "protected" : false,
      "id_str" : "14663837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53829328\/davros_copy_normal.jpg",
      "id" : 14663837,
      "verified" : false
    }
  },
  "id" : 749228145908350977,
  "created_at" : "2016-07-02 13:08:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/E2CPQZ7tnO",
      "expanded_url" : "http:\/\/literacyblog.blogspot.com\/2016\/07\/castles-in-air.html",
      "display_url" : "literacyblog.blogspot.com\/2016\/07\/castle\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "749226718355984384",
  "text" : "Castles in the air - https:\/\/t.co\/E2CPQZ7tnO",
  "id" : 749226718355984384,
  "created_at" : "2016-07-02 13:02:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jewish Voice",
      "screen_name" : "J_VoiceUK",
      "indices" : [ 3, 13 ],
      "id_str" : "3532479797",
      "id" : 3532479797
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/J_VoiceUK\/status\/748516373744222209\/photo\/1",
      "indices" : [ 143, 144 ],
      "url" : "https:\/\/t.co\/ashPLTYmNM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmNDbbBWEAALLPm.jpg",
      "id_str" : "748516101462560768",
      "id" : 748516101462560768,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmNDbbBWEAALLPm.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/ashPLTYmNM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "749215793934700544",
  "text" : "RT @J_VoiceUK: as some dont read what Corbyn actually said &amp; think he did compare Israel to ISIS, we've written this in big letters https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/J_VoiceUK\/status\/748516373744222209\/photo\/1",
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/ashPLTYmNM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmNDbbBWEAALLPm.jpg",
        "id_str" : "748516101462560768",
        "id" : 748516101462560768,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmNDbbBWEAALLPm.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/ashPLTYmNM"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "748516373744222209",
    "text" : "as some dont read what Corbyn actually said &amp; think he did compare Israel to ISIS, we've written this in big letters https:\/\/t.co\/ashPLTYmNM",
    "id" : 748516373744222209,
    "created_at" : "2016-06-30 13:59:44 +0000",
    "user" : {
      "name" : "Jewish Voice",
      "screen_name" : "J_VoiceUK",
      "protected" : false,
      "id_str" : "3532479797",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/735903339066626049\/67drZczC_normal.jpg",
      "id" : 3532479797,
      "verified" : false
    }
  },
  "id" : 749215793934700544,
  "created_at" : "2016-07-02 12:18:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eily Murphy",
      "screen_name" : "eilymurphy",
      "indices" : [ 3, 14 ],
      "id_str" : "111091623",
      "id" : 111091623
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TBLTchat",
      "indices" : [ 16, 25 ]
    } ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/4y3Nks2D7z",
      "expanded_url" : "https:\/\/twitter.com\/RachaelTESOL\/status\/748837591437414400",
      "display_url" : "twitter.com\/RachaelTESOL\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "749201018395713536",
  "text" : "RT @eilymurphy: #TBLTchat https:\/\/t.co\/4y3Nks2D7z",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TBLTchat",
        "indices" : [ 0, 9 ]
      } ],
      "urls" : [ {
        "indices" : [ 10, 33 ],
        "url" : "https:\/\/t.co\/4y3Nks2D7z",
        "expanded_url" : "https:\/\/twitter.com\/RachaelTESOL\/status\/748837591437414400",
        "display_url" : "twitter.com\/RachaelTESOL\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "748838114744012800",
    "text" : "#TBLTchat https:\/\/t.co\/4y3Nks2D7z",
    "id" : 748838114744012800,
    "created_at" : "2016-07-01 11:18:13 +0000",
    "user" : {
      "name" : "Eily Murphy",
      "screen_name" : "eilymurphy",
      "protected" : false,
      "id_str" : "111091623",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746422529405894656\/gSFQlPqA_normal.jpg",
      "id" : 111091623,
      "verified" : false
    }
  },
  "id" : 749201018395713536,
  "created_at" : "2016-07-02 11:20:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wal",
      "indices" : [ 27, 31 ]
    }, {
      "text" : "bel",
      "indices" : [ 55, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "749190929131696128",
  "text" : "in the pub last night  for #wal game,  a disappointed  #bel fan screamed Fk Margaret Thatcher, quite : ) I wld add and Fk her offspring",
  "id" : 749190929131696128,
  "created_at" : "2016-07-02 10:40:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lynn Cherny",
      "screen_name" : "arnicas",
      "indices" : [ 3, 11 ],
      "id_str" : "6146692",
      "id" : 6146692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/cVI4j9b8qD",
      "expanded_url" : "https:\/\/twitter.com\/jessicahagy\/status\/748959850818785280",
      "display_url" : "twitter.com\/jessicahagy\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "749183458149302272",
  "text" : "RT @arnicas: From a text-generation view, this is pretty amazing. https:\/\/t.co\/cVI4j9b8qD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 76 ],
        "url" : "https:\/\/t.co\/cVI4j9b8qD",
        "expanded_url" : "https:\/\/twitter.com\/jessicahagy\/status\/748959850818785280",
        "display_url" : "twitter.com\/jessicahagy\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "748981767424663552",
    "text" : "From a text-generation view, this is pretty amazing. https:\/\/t.co\/cVI4j9b8qD",
    "id" : 748981767424663552,
    "created_at" : "2016-07-01 20:49:03 +0000",
    "user" : {
      "name" : "Lynn Cherny",
      "screen_name" : "arnicas",
      "protected" : false,
      "id_str" : "6146692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/53142956\/Saw-whet_Owl_10_normal.jpg",
      "id" : 6146692,
      "verified" : false
    }
  },
  "id" : 749183458149302272,
  "created_at" : "2016-07-02 10:10:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol Nichols",
      "screen_name" : "Carols10cents",
      "indices" : [ 3, 17 ],
      "id_str" : "194688433",
      "id" : 194688433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "749181228667011076",
  "text" : "RT @Carols10cents: 1998:\n- Don't get in strangers' cars\n- Don't meet ppl from internet\n\n2016:\n- Literally summon strangers from internet to\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mvilla.it\/fenix\" rel=\"nofollow\"\u003EFenix for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "749109677431021568",
    "text" : "1998:\n- Don't get in strangers' cars\n- Don't meet ppl from internet\n\n2016:\n- Literally summon strangers from internet to get in their car",
    "id" : 749109677431021568,
    "created_at" : "2016-07-02 05:17:19 +0000",
    "user" : {
      "name" : "Carol Nichols",
      "screen_name" : "Carols10cents",
      "protected" : false,
      "id_str" : "194688433",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/446291681252364288\/_okxMUY1_normal.jpeg",
      "id" : 194688433,
      "verified" : false
    }
  },
  "id" : 749181228667011076,
  "created_at" : "2016-07-02 10:01:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Match of the Day",
      "screen_name" : "BBCMOTD",
      "indices" : [ 3, 11 ],
      "id_str" : "384951307",
      "id" : 384951307
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WAL",
      "indices" : [ 78, 82 ]
    }, {
      "text" : "bbceuro2016",
      "indices" : [ 83, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/MbsbxvdISS",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/21f29171-10a4-4541-b0c3-08036158f30d",
      "display_url" : "amp.twimg.com\/v\/21f29171-10a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "749168134226075648",
  "text" : "RT @BBCMOTD: Right! Time to clear up that Dean Saunders car park fine rumour! #WAL #bbceuro2016\nhttps:\/\/t.co\/MbsbxvdISS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WAL",
        "indices" : [ 65, 69 ]
      }, {
        "text" : "bbceuro2016",
        "indices" : [ 70, 82 ]
      } ],
      "urls" : [ {
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/MbsbxvdISS",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/21f29171-10a4-4541-b0c3-08036158f30d",
        "display_url" : "amp.twimg.com\/v\/21f29171-10a\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "748910754674274305",
    "text" : "Right! Time to clear up that Dean Saunders car park fine rumour! #WAL #bbceuro2016\nhttps:\/\/t.co\/MbsbxvdISS",
    "id" : 748910754674274305,
    "created_at" : "2016-07-01 16:06:52 +0000",
    "user" : {
      "name" : "Match of the Day",
      "screen_name" : "BBCMOTD",
      "protected" : false,
      "id_str" : "384951307",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/741693797382402048\/iY4D833N_normal.jpg",
      "id" : 384951307,
      "verified" : true
    }
  },
  "id" : 749168134226075648,
  "created_at" : "2016-07-02 09:09:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Adele Soracco",
      "screen_name" : "LauraSoracco",
      "indices" : [ 0, 13 ],
      "id_str" : "15663328",
      "id" : 15663328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "748923293038632962",
  "geo" : { },
  "id_str" : "749006440711553024",
  "in_reply_to_user_id" : 15663328,
  "text" : "@LauraSoracco u need to copy paste the text from the CSV file, laborious yes; do use G+ if u need any help",
  "id" : 749006440711553024,
  "in_reply_to_status_id" : 748923293038632962,
  "created_at" : "2016-07-01 22:27:05 +0000",
  "in_reply_to_screen_name" : "LauraSoracco",
  "in_reply_to_user_id_str" : "15663328",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FiveFilters.org",
      "screen_name" : "fivefilters",
      "indices" : [ 3, 15 ],
      "id_str" : "175151306",
      "id" : 175151306
    }, {
      "name" : "Joe Emersberger",
      "screen_name" : "rosendo_joe",
      "indices" : [ 40, 52 ],
      "id_str" : "3351345863",
      "id" : 3351345863
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/b8X4BFSLxa",
      "expanded_url" : "http:\/\/www.telesurtv.net\/english\/opinion\/Most-Labour-MPs-in-the-UK-Are-Revolting-20160630-0047.html",
      "display_url" : "telesurtv.net\/english\/opinio\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "748843503497646080",
  "text" : "RT @fivefilters: Excellent article from @rosendo_joe on coup against Corbyn. https:\/\/t.co\/b8X4BFSLxa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Joe Emersberger",
        "screen_name" : "rosendo_joe",
        "indices" : [ 23, 35 ],
        "id_str" : "3351345863",
        "id" : 3351345863
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/b8X4BFSLxa",
        "expanded_url" : "http:\/\/www.telesurtv.net\/english\/opinion\/Most-Labour-MPs-in-the-UK-Are-Revolting-20160630-0047.html",
        "display_url" : "telesurtv.net\/english\/opinio\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "748800608757428224",
    "text" : "Excellent article from @rosendo_joe on coup against Corbyn. https:\/\/t.co\/b8X4BFSLxa",
    "id" : 748800608757428224,
    "created_at" : "2016-07-01 08:49:11 +0000",
    "user" : {
      "name" : "FiveFilters.org",
      "screen_name" : "fivefilters",
      "protected" : false,
      "id_str" : "175151306",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1361400226\/title-twitter_normal.png",
      "id" : 175151306,
      "verified" : false
    }
  },
  "id" : 748843503497646080,
  "created_at" : "2016-07-01 11:39:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harry Leslie Smith",
      "screen_name" : "Harryslaststand",
      "indices" : [ 3, 19 ],
      "id_str" : "209176493",
      "id" : 209176493
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KeepCorbyn",
      "indices" : [ 138, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748761116797313024",
  "text" : "RT @Harryslaststand: Can you imagine what a different and a better world we would have lived in had Tony Blair's Cabinet resigned over the\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "KeepCorbyn",
        "indices" : [ 127, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "747478415909990400",
    "text" : "Can you imagine what a different and a better world we would have lived in had Tony Blair's Cabinet resigned over the Iraq War #KeepCorbyn",
    "id" : 747478415909990400,
    "created_at" : "2016-06-27 17:15:16 +0000",
    "user" : {
      "name" : "Harry Leslie Smith",
      "screen_name" : "Harryslaststand",
      "protected" : false,
      "id_str" : "209176493",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/466967124255072256\/qlM2P2Lo_normal.jpeg",
      "id" : 209176493,
      "verified" : false
    }
  },
  "id" : 748761116797313024,
  "created_at" : "2016-07-01 06:12:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ewan McGregor",
      "screen_name" : "mcgregor_ewan",
      "indices" : [ 3, 17 ],
      "id_str" : "574168493",
      "id" : 574168493
    }, {
      "name" : "Boris Johnson",
      "screen_name" : "BorisJohnson",
      "indices" : [ 19, 32 ],
      "id_str" : "3131144855",
      "id" : 3131144855
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748760566336851968",
  "text" : "RT @mcgregor_ewan: @BorisJohnson You spineless c$&amp;t You lead this ludicrous campaign to leave EU. Win, and now fuc&amp; off to let someone else\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Boris Johnson",
        "screen_name" : "BorisJohnson",
        "indices" : [ 0, 13 ],
        "id_str" : "3131144855",
        "id" : 3131144855
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "748477453631426560",
    "in_reply_to_user_id" : 3131144855,
    "text" : "@BorisJohnson You spineless c$&amp;t You lead this ludicrous campaign to leave EU. Win, and now fuc&amp; off to let someone else clear up your mess.",
    "id" : 748477453631426560,
    "created_at" : "2016-06-30 11:25:05 +0000",
    "in_reply_to_screen_name" : "BorisJohnson",
    "in_reply_to_user_id_str" : "3131144855",
    "user" : {
      "name" : "Ewan McGregor",
      "screen_name" : "mcgregor_ewan",
      "protected" : false,
      "id_str" : "574168493",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2207384876\/image_normal.jpg",
      "id" : 574168493,
      "verified" : true
    }
  },
  "id" : 748760566336851968,
  "created_at" : "2016-07-01 06:10:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Adele Soracco",
      "screen_name" : "LauraSoracco",
      "indices" : [ 0, 13 ],
      "id_str" : "15663328",
      "id" : 15663328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "748679042228891648",
  "geo" : { },
  "id_str" : "748746247905751040",
  "in_reply_to_user_id" : 15663328,
  "text" : "@LauraSoracco true i do,  will upload files &amp; link in G+ when I get a chance",
  "id" : 748746247905751040,
  "in_reply_to_status_id" : 748679042228891648,
  "created_at" : "2016-07-01 05:13:11 +0000",
  "in_reply_to_screen_name" : "LauraSoracco",
  "in_reply_to_user_id_str" : "15663328",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Adele Soracco",
      "screen_name" : "LauraSoracco",
      "indices" : [ 0, 13 ],
      "id_str" : "15663328",
      "id" : 15663328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "748664908938510336",
  "geo" : { },
  "id_str" : "748666107142230016",
  "in_reply_to_user_id" : 15663328,
  "text" : "@LauraSoracco i have Sarah Palin's email as well : )",
  "id" : 748666107142230016,
  "in_reply_to_status_id" : 748664908938510336,
  "created_at" : "2016-06-30 23:54:44 +0000",
  "in_reply_to_screen_name" : "LauraSoracco",
  "in_reply_to_user_id_str" : "15663328",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Timothy Tate",
      "screen_name" : "Timothy_Tate",
      "indices" : [ 0, 13 ],
      "id_str" : "1084531170",
      "id" : 1084531170
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/dD10X8fYFc",
      "expanded_url" : "http:\/\/www.languagejones.com\/blog-1\/2016\/6\/29\/on-stank-face",
      "display_url" : "languagejones.com\/blog-1\/2016\/6\/\u2026"
    }, {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/go40FCgHxi",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=Qky7hJUDg4M&feature=youtu.be",
      "display_url" : "youtube.com\/watch?v=Qky7hJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "748664808715718656",
  "in_reply_to_user_id" : 1084531170,
  "text" : "@Timothy_Tate On Stank Face https:\/\/t.co\/dD10X8fYFc  reminded of many faces being stank by Django's Tigers https:\/\/t.co\/go40FCgHxi : )",
  "id" : 748664808715718656,
  "created_at" : "2016-06-30 23:49:34 +0000",
  "in_reply_to_screen_name" : "Timothy_Tate",
  "in_reply_to_user_id_str" : "1084531170",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Adele Soracco",
      "screen_name" : "LauraSoracco",
      "indices" : [ 0, 13 ],
      "id_str" : "15663328",
      "id" : 15663328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/Zg3MF5rs0j",
      "expanded_url" : "https:\/\/plus.google.com\/+MuraNava\/posts\/SnBW6zQpXW7",
      "display_url" : "plus.google.com\/+MuraNava\/post\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "748346111602024448",
  "geo" : { },
  "id_str" : "748654347362394112",
  "in_reply_to_user_id" : 15663328,
  "text" : "@LauraSoracco considered using your own emails? maybe Hilary Clinton email? https:\/\/t.co\/Zg3MF5rs0j",
  "id" : 748654347362394112,
  "in_reply_to_status_id" : 748346111602024448,
  "created_at" : "2016-06-30 23:08:00 +0000",
  "in_reply_to_screen_name" : "LauraSoracco",
  "in_reply_to_user_id_str" : "15663328",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Voice Newspaper",
      "screen_name" : "TheVoiceNews",
      "indices" : [ 3, 16 ],
      "id_str" : "47591958",
      "id" : 47591958
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/TheVoiceNews\/status\/748477652034551808\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/KeNPuzl1FE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmMgTHGWkAACft7.jpg",
      "id_str" : "748477475768930304",
      "id" : 748477475768930304,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmMgTHGWkAACft7.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/KeNPuzl1FE"
    } ],
    "hashtags" : [ {
      "text" : "MarySeacole",
      "indices" : [ 98, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/BqnkLbs5ue",
      "expanded_url" : "http:\/\/bit.ly\/29aiJoM",
      "display_url" : "bit.ly\/29aiJoM"
    } ]
  },
  "geo" : { },
  "id_str" : "748643781000503296",
  "text" : "RT @TheVoiceNews: There she stands - the 1st statue of a named black woman in the UK. Her name is #MarySeacole https:\/\/t.co\/BqnkLbs5ue http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/TheVoiceNews\/status\/748477652034551808\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/KeNPuzl1FE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmMgTHGWkAACft7.jpg",
        "id_str" : "748477475768930304",
        "id" : 748477475768930304,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmMgTHGWkAACft7.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/KeNPuzl1FE"
      } ],
      "hashtags" : [ {
        "text" : "MarySeacole",
        "indices" : [ 80, 92 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/BqnkLbs5ue",
        "expanded_url" : "http:\/\/bit.ly\/29aiJoM",
        "display_url" : "bit.ly\/29aiJoM"
      } ]
    },
    "geo" : { },
    "id_str" : "748477652034551808",
    "text" : "There she stands - the 1st statue of a named black woman in the UK. Her name is #MarySeacole https:\/\/t.co\/BqnkLbs5ue https:\/\/t.co\/KeNPuzl1FE",
    "id" : 748477652034551808,
    "created_at" : "2016-06-30 11:25:52 +0000",
    "user" : {
      "name" : "The Voice Newspaper",
      "screen_name" : "TheVoiceNews",
      "protected" : false,
      "id_str" : "47591958",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/730399986630991872\/Y8zztyPO_normal.jpg",
      "id" : 47591958,
      "verified" : true
    }
  },
  "id" : 748643781000503296,
  "created_at" : "2016-06-30 22:26:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 0, 9 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Hada ELT",
      "screen_name" : "Hada_ELT",
      "indices" : [ 33, 42 ],
      "id_str" : "44631065",
      "id" : 44631065
    }, {
      "name" : "Dr. Michael Riccioli",
      "screen_name" : "curvedway",
      "indices" : [ 43, 53 ],
      "id_str" : "124707247",
      "id" : 124707247
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/748639028916928512\/photo\/1",
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/YYFkAQcIdB",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CmOzMtRWEAA_TG2.jpg",
      "id_str" : "748638993965780992",
      "id" : 748638993965780992,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CmOzMtRWEAA_TG2.jpg",
      "sizes" : [ {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 372,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 372,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 372,
        "resize" : "fit",
        "w" : 498
      } ],
      "display_url" : "pic.twitter.com\/YYFkAQcIdB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "748635954844401664",
  "geo" : { },
  "id_str" : "748639028916928512",
  "in_reply_to_user_id" : 18602422,
  "text" : "@muranava hey Hada &amp; Michael @Hada_ELT @curvedway : ) https:\/\/t.co\/YYFkAQcIdB",
  "id" : 748639028916928512,
  "in_reply_to_status_id" : 748635954844401664,
  "created_at" : "2016-06-30 22:07:08 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
} ]