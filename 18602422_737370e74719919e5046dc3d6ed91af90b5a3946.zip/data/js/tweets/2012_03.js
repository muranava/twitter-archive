Grailbird.data.tweets_2012_03 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ken Wilson",
      "screen_name" : "kenwilsonlondon",
      "indices" : [ 3, 19 ],
      "id_str" : "29030280",
      "id" : 29030280
    }, {
      "name" : "George Galloway",
      "screen_name" : "georgegalloway",
      "indices" : [ 24, 39 ],
      "id_str" : "15484198",
      "id" : 15484198
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "186005937595748352",
  "text" : "MT @kenwilsonlondon: RT @georgegalloway: Shattered but happy after the Blackburn triumph. &gt;&gt; GUESS HE WAS TIRED &lt;--he got phished i think",
  "id" : 186005937595748352,
  "created_at" : "2012-03-31 08:24:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/2pK7Z0aU",
      "expanded_url" : "http:\/\/bit.ly\/HAKHSs",
      "display_url" : "bit.ly\/HAKHSs"
    } ]
  },
  "geo" : { },
  "id_str" : "185834899708723202",
  "text" : "A stunning and political win \/ Morning Star: http:\/\/t.co\/2pK7Z0aU a chance for the left to rally? i do hope so!",
  "id" : 185834899708723202,
  "created_at" : "2012-03-30 21:04:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http:\/\/t.co\/6zUaigio",
      "expanded_url" : "http:\/\/youtu.be\/RRyNA0T7p9I",
      "display_url" : "youtu.be\/RRyNA0T7p9I"
    } ]
  },
  "geo" : { },
  "id_str" : "185779716098240512",
  "text" : "Galloway victory speech http:\/\/t.co\/6zUaigio you beauty!",
  "id" : 185779716098240512,
  "created_at" : "2012-03-30 17:25:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/p99qEHmA",
      "expanded_url" : "http:\/\/youtu.be\/BP2ywccOZ7Y",
      "display_url" : "youtu.be\/BP2ywccOZ7Y"
    } ]
  },
  "geo" : { },
  "id_str" : "185777453908758528",
  "text" : "George Galloway wins Bradford by-election http:\/\/t.co\/p99qEHmA :)",
  "id" : 185777453908758528,
  "created_at" : "2012-03-30 17:16:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Taylor",
      "screen_name" : "theteacherjames",
      "indices" : [ 0, 16 ],
      "id_str" : "71746265",
      "id" : 71746265
    }, {
      "name" : "Digital Play",
      "screen_name" : "eltdigitalplay",
      "indices" : [ 17, 32 ],
      "id_str" : "67682458",
      "id" : 67682458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/10FOQiFN",
      "expanded_url" : "http:\/\/youtu.be\/piPyfqAKf6o",
      "display_url" : "youtu.be\/piPyfqAKf6o"
    } ]
  },
  "in_reply_to_status_id_str" : "185769147148419073",
  "geo" : { },
  "id_str" : "185773612769345536",
  "in_reply_to_user_id" : 71746265,
  "text" : "@theteacherjames @eltdigitalplay re 5 levels of storytelling please say u inspired by the 5 levels of drinking http:\/\/t.co\/10FOQiFN? =\u00B0)",
  "id" : 185773612769345536,
  "in_reply_to_status_id" : 185769147148419073,
  "created_at" : "2012-03-30 17:00:55 +0000",
  "in_reply_to_screen_name" : "theteacherjames",
  "in_reply_to_user_id_str" : "71746265",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    }, {
      "name" : "Bruno Andrade",
      "screen_name" : "BrunoELT",
      "indices" : [ 48, 57 ],
      "id_str" : "39409915",
      "id" : 39409915
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 96, 103 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185749038946189312",
  "geo" : { },
  "id_str" : "185751498322481153",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow glad to help i got that site from a @BrunoELT  blog post on mobile learning talk at #IATEFL 2012",
  "id" : 185751498322481153,
  "in_reply_to_status_id" : 185749038946189312,
  "created_at" : "2012-03-30 15:33:02 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    }, {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 41, 52 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185743534857523200",
  "geo" : { },
  "id_str" : "185745712120741888",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow your welcome kevin, also yes @leoselivan have commented anon but now can use name\/url which i did not use before",
  "id" : 185745712120741888,
  "in_reply_to_status_id" : 185743534857523200,
  "created_at" : "2012-03-30 15:10:03 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    }, {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 12, 23 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185741921367490563",
  "geo" : { },
  "id_str" : "185742494154235904",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow @leoselivan great just commented looks like it sent okay?",
  "id" : 185742494154235904,
  "in_reply_to_status_id" : 185741921367490563,
  "created_at" : "2012-03-30 14:57:16 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 12, 23 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185737852473184257",
  "geo" : { },
  "id_str" : "185739684255764482",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan @kevchanwow theoretically anonymous settings should allow inputing your own name\/url hmm thx for checking",
  "id" : 185739684255764482,
  "in_reply_to_status_id" : 185737852473184257,
  "created_at" : "2012-03-30 14:46:06 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    }, {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 12, 23 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "185734920189132800",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow @leoselivan can u check if your blogger has comment settings set to Name and URL? ta",
  "id" : 185734920189132800,
  "created_at" : "2012-03-30 14:27:10 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185708606363140096",
  "geo" : { },
  "id_str" : "185709506553057280",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow thanks looking forward to checking out your blog!",
  "id" : 185709506553057280,
  "in_reply_to_status_id" : 185708606363140096,
  "created_at" : "2012-03-30 12:46:11 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Graham Stanley",
      "screen_name" : "grahamstanley",
      "indices" : [ 0, 14 ],
      "id_str" : "74143",
      "id" : 74143
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 60, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "185688108619137026",
  "in_reply_to_user_id" : 74143,
  "text" : "@grahamstanley  hey there this is mura tweeting from france #eltchat",
  "id" : 185688108619137026,
  "created_at" : "2012-03-30 11:21:09 +0000",
  "in_reply_to_screen_name" : "grahamstanley",
  "in_reply_to_user_id_str" : "74143",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian James",
      "screen_name" : "ij64",
      "indices" : [ 0, 5 ],
      "id_str" : "13726222",
      "id" : 13726222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http:\/\/t.co\/VTxH1Gik",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-6D",
      "display_url" : "wp.me\/pgHyE-6D"
    } ]
  },
  "in_reply_to_status_id_str" : "185645524572045312",
  "geo" : { },
  "id_str" : "185666029777715200",
  "in_reply_to_user_id" : 13726222,
  "text" : "@ij64 thanks for RT of http:\/\/t.co\/VTxH1Gik :)",
  "id" : 185666029777715200,
  "in_reply_to_status_id" : 185645524572045312,
  "created_at" : "2012-03-30 09:53:25 +0000",
  "in_reply_to_screen_name" : "ij64",
  "in_reply_to_user_id_str" : "13726222",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TESOL France",
      "screen_name" : "TESOLFrance",
      "indices" : [ 54, 66 ],
      "id_str" : "70341872",
      "id" : 70341872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/VTxH1Gik",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-6D",
      "display_url" : "wp.me\/pgHyE-6D"
    } ]
  },
  "geo" : { },
  "id_str" : "185621582125871104",
  "text" : "new blog post What's that sound? http:\/\/t.co\/VTxH1Gik @TESOLFrance",
  "id" : 185621582125871104,
  "created_at" : "2012-03-30 06:56:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "indices" : [ 54, 67 ],
      "id_str" : "1685397408",
      "id" : 1685397408
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELTchat",
      "indices" : [ 68, 76 ]
    }, {
      "text" : "esl",
      "indices" : [ 77, 81 ]
    }, {
      "text" : "esol",
      "indices" : [ 82, 87 ]
    }, {
      "text" : "tesol",
      "indices" : [ 88, 94 ]
    }, {
      "text" : "elt",
      "indices" : [ 95, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/VTxH1Gik",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-6D",
      "display_url" : "wp.me\/pgHyE-6D"
    } ]
  },
  "geo" : { },
  "id_str" : "185530836152614912",
  "text" : "new blog post What's that sound? http:\/\/t.co\/VTxH1Gik @harrisonmike #ELTchat #esl #esol #tesol #elt",
  "id" : 185530836152614912,
  "created_at" : "2012-03-30 00:56:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Register Hardware",
      "screen_name" : "RegHardware",
      "indices" : [ 58, 70 ],
      "id_str" : "19707379",
      "id" : 19707379
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/ku2eL44s",
      "expanded_url" : "http:\/\/reg.cx\/1UNE",
      "display_url" : "reg.cx\/1UNE"
    } ]
  },
  "geo" : { },
  "id_str" : "185476636081258497",
  "text" : "Wags unroll Twitter toilet paper http:\/\/t.co\/ku2eL44s via @reghardware hmm might make good presents :) or conference goodies parps?",
  "id" : 185476636081258497,
  "created_at" : "2012-03-29 21:20:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slashdot",
      "screen_name" : "slashdot",
      "indices" : [ 54, 63 ],
      "id_str" : "1068831",
      "id" : 1068831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/FY9mXrad",
      "expanded_url" : "http:\/\/hardware.slashdot.org\/story\/12\/03\/28\/2321210\/",
      "display_url" : "hardware.slashdot.org\/story\/12\/03\/28\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "185328434363371521",
  "text" : "Canadian Man Releases Open Source Star Trek Tricorder @slashdot http:\/\/t.co\/FY9mXrad",
  "id" : 185328434363371521,
  "created_at" : "2012-03-29 11:31:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 12, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "185110044617097217",
  "text" : "cheers all! #eltchat",
  "id" : 185110044617097217,
  "created_at" : "2012-03-28 21:04:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "185108932841312256",
  "text" : "a lot of very short 1min\/2min films by amateurs on youtube, though will need to filter the drosss! #eltchat",
  "id" : 185108932841312256,
  "created_at" : "2012-03-28 20:59:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 82, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/toQyjnKB",
      "expanded_url" : "http:\/\/documentary.net\/",
      "display_url" : "documentary.net"
    }, {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/JqAfC9Nd",
      "expanded_url" : "http:\/\/www.documentarytube.com\/",
      "display_url" : "documentarytube.com"
    } ]
  },
  "geo" : { },
  "id_str" : "185106979402948610",
  "text" : "anyone mentioned documentaries yet? http:\/\/t.co\/toQyjnKB and http:\/\/t.co\/JqAfC9Nd #eltchat",
  "id" : 185106979402948610,
  "created_at" : "2012-03-28 20:51:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wiktorkompe",
      "screen_name" : "wiktor_k",
      "indices" : [ 3, 12 ],
      "id_str" : "733704413383168000",
      "id" : 733704413383168000
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 118, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/v1cKvmyM",
      "expanded_url" : "http:\/\/wiki.creativecommons.org\/Films",
      "display_url" : "wiki.creativecommons.org\/Films"
    } ]
  },
  "geo" : { },
  "id_str" : "185106229343948801",
  "text" : "MT @Wiktor_K: Re: list of perfectly legit films http:\/\/t.co\/v1cKvmyM - nice list used Good Copy Bad Copy a lot before #eltchat",
  "id" : 185106229343948801,
  "created_at" : "2012-03-28 20:48:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mieke Kenis",
      "screen_name" : "mkofab",
      "indices" : [ 0, 7 ],
      "id_str" : "96527212",
      "id" : 96527212
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 94, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/A9nCCHXY",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-2r",
      "display_url" : "wp.me\/pgHyE-2r"
    } ]
  },
  "in_reply_to_status_id_str" : "185103465184366593",
  "geo" : { },
  "id_str" : "185103855661494272",
  "in_reply_to_user_id" : 96527212,
  "text" : "@mkofab re biz stuentds and film yes i have you can read about that here http:\/\/t.co\/A9nCCHXY #eltchat",
  "id" : 185103855661494272,
  "in_reply_to_status_id" : 185103465184366593,
  "created_at" : "2012-03-28 20:39:32 +0000",
  "in_reply_to_screen_name" : "mkofab",
  "in_reply_to_user_id_str" : "96527212",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sandy Millin",
      "screen_name" : "sandymillin",
      "indices" : [ 0, 12 ],
      "id_str" : "144236944",
      "id" : 144236944
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 51, 59 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "185099975871561728",
  "geo" : { },
  "id_str" : "185100669001285632",
  "in_reply_to_user_id" : 144236944,
  "text" : "@sandymillin is that oxford book on film any good? #eltchat",
  "id" : 185100669001285632,
  "in_reply_to_status_id" : 185099975871561728,
  "created_at" : "2012-03-28 20:26:53 +0000",
  "in_reply_to_screen_name" : "sandymillin",
  "in_reply_to_user_id_str" : "144236944",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 118, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "185096780780810241",
  "text" : "the closer the film extract is to behaviour rather than language per se the more successful using film in ELT can be? #eltchat",
  "id" : 185096780780810241,
  "created_at" : "2012-03-28 20:11:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FEED THE TEACHER",
      "screen_name" : "feedtheteacher",
      "indices" : [ 0, 15 ],
      "id_str" : "58839737",
      "id" : 58839737
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 38, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/nEYh2pFH",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-6e",
      "display_url" : "wp.me\/pgHyE-6e"
    } ]
  },
  "geo" : { },
  "id_str" : "185026386631737344",
  "in_reply_to_user_id" : 58839737,
  "text" : "@feedtheteacher thx for RT of updated #IATEFL blog post http:\/\/t.co\/nEYh2pFH",
  "id" : 185026386631737344,
  "created_at" : "2012-03-28 15:31:42 +0000",
  "in_reply_to_screen_name" : "feedtheteacher",
  "in_reply_to_user_id_str" : "58839737",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FEED THE TEACHER",
      "screen_name" : "feedtheteacher",
      "indices" : [ 0, 15 ],
      "id_str" : "58839737",
      "id" : 58839737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "184947445304803328",
  "geo" : { },
  "id_str" : "185025248004022272",
  "in_reply_to_user_id" : 58839737,
  "text" : "@feedtheteacher yes please that would be great",
  "id" : 185025248004022272,
  "in_reply_to_status_id" : 184947445304803328,
  "created_at" : "2012-03-28 15:27:11 +0000",
  "in_reply_to_screen_name" : "feedtheteacher",
  "in_reply_to_user_id_str" : "58839737",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bruno Andrade",
      "screen_name" : "BrunoELT",
      "indices" : [ 63, 72 ],
      "id_str" : "39409915",
      "id" : 39409915
    }, {
      "name" : "FEED THE TEACHER",
      "screen_name" : "feedtheteacher",
      "indices" : [ 73, 88 ],
      "id_str" : "58839737",
      "id" : 58839737
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 8, 15 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/nEYh2pFH",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-6e",
      "display_url" : "wp.me\/pgHyE-6e"
    } ]
  },
  "geo" : { },
  "id_str" : "184934206340726785",
  "text" : "updated #IATEFL mobile learning blog post http:\/\/t.co\/nEYh2pFH @BrunoELT @feedtheteacher",
  "id" : 184934206340726785,
  "created_at" : "2012-03-28 09:25:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ntchat",
      "indices" : [ 112, 119 ]
    }, {
      "text" : "lichat",
      "indices" : [ 120, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/bS9Cg5Yh",
      "expanded_url" : "http:\/\/budurl.com\/lger",
      "display_url" : "budurl.com\/lger"
    } ]
  },
  "geo" : { },
  "id_str" : "184755729327075328",
  "text" : "RT @HPTeachExchange: 5 search engines you have never heard of. Have you used these sites? http:\/\/t.co\/bS9Cg5Yh  #ntchat #lichat",
  "id" : 184755729327075328,
  "created_at" : "2012-03-27 21:36:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dale Coulter",
      "screen_name" : "dalecoulter",
      "indices" : [ 0, 12 ],
      "id_str" : "24046458",
      "id" : 24046458
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 13, 21 ]
    }, {
      "text" : "elt",
      "indices" : [ 23, 27 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "184558926216441856",
  "geo" : { },
  "id_str" : "184569666017046528",
  "in_reply_to_user_id" : 24046458,
  "text" : "@dalecoulter #eltchat  #elt it's not new new as started doing it last week - use mobile phones as a break activity -show and tell a fav pic",
  "id" : 184569666017046528,
  "in_reply_to_status_id" : 184558926216441856,
  "created_at" : "2012-03-27 09:16:52 +0000",
  "in_reply_to_screen_name" : "dalecoulter",
  "in_reply_to_user_id_str" : "24046458",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/PDI0XHO3",
      "expanded_url" : "http:\/\/www.redpepper.org.uk\/nhs-fight-goes-on\/",
      "display_url" : "redpepper.org.uk\/nhs-fight-goes\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "184394327127105537",
  "text" : "Lancet editor and doctors write: The fight for our NHS goes on http:\/\/t.co\/PDI0XHO3",
  "id" : 184394327127105537,
  "created_at" : "2012-03-26 21:40:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IATEFL Online",
      "screen_name" : "iateflonline",
      "indices" : [ 0, 13 ],
      "id_str" : "17447359",
      "id" : 17447359
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "184223408987439104",
  "in_reply_to_user_id" : 17447359,
  "text" : "@iateflonline still no luck in getting Robert O'Neill interview uploaded?",
  "id" : 184223408987439104,
  "created_at" : "2012-03-26 10:20:58 +0000",
  "in_reply_to_screen_name" : "iateflonline",
  "in_reply_to_user_id_str" : "17447359",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "183995887087927296",
  "text" : "re game of thrones, boo hiss it's somesort of \"making of\" dam!",
  "id" : 183995887087927296,
  "created_at" : "2012-03-25 19:16:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "183992435179929600",
  "text" : "woot! Game of Thrones Season 2 first episode available :)",
  "id" : 183992435179929600,
  "created_at" : "2012-03-25 19:03:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.ustream.tv\" rel=\"nofollow\"\u003EUstream.TV\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/Ze0l18YF",
      "expanded_url" : "http:\/\/ustre.am\/ISIt\/1",
      "display_url" : "ustre.am\/ISIt\/1"
    } ]
  },
  "geo" : { },
  "id_str" : "182862592090439680",
  "text" : "is this live? seems to be on a loop? (live at http:\/\/t.co\/Ze0l18YF)",
  "id" : 182862592090439680,
  "created_at" : "2012-03-22 16:13:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.ustream.tv\" rel=\"nofollow\"\u003EUstream.TV\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/cbeiENYH",
      "expanded_url" : "http:\/\/ustre.am\/ISIt\/2",
      "display_url" : "ustre.am\/ISIt\/2"
    } ]
  },
  "geo" : { },
  "id_str" : "182862413631197185",
  "text" : "I just checked into ELTCHAT Live on Ustream. Come watch and chat with me here http:\/\/t.co\/cbeiENYH",
  "id" : 182862413631197185,
  "created_at" : "2012-03-22 16:12:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heike Philp",
      "screen_name" : "heikephilp",
      "indices" : [ 3, 14 ],
      "id_str" : "14387055",
      "id" : 14387055
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/pTgBp9DK",
      "expanded_url" : "http:\/\/htwins.net\/scale2\/scale2.swf?bordercolor",
      "display_url" : "htwins.net\/scale2\/scale2.\u2026"
    }, {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/wgkFN0b0",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-2H",
      "display_url" : "wp.me\/pgHyE-2H"
    } ]
  },
  "geo" : { },
  "id_str" : "182828060222029824",
  "text" : "MT @heikephilp:the size of the universe graphical animation http:\/\/t.co\/pTgBp9DK thanks to m2012&lt;--activity http:\/\/t.co\/wgkFN0b0",
  "id" : 182828060222029824,
  "created_at" : "2012-03-22 13:56:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Patsko",
      "screen_name" : "lauraahaha",
      "indices" : [ 3, 14 ],
      "id_str" : "97957137",
      "id" : 97957137
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iatefl",
      "indices" : [ 21, 28 ]
    }, {
      "text" : "iateflconference2012",
      "indices" : [ 29, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/pVVRn6EO",
      "expanded_url" : "http:\/\/post.ly\/6AQLQ",
      "display_url" : "post.ly\/6AQLQ"
    } ]
  },
  "geo" : { },
  "id_str" : "182818812004024320",
  "text" : "RT @lauraahaha: New  #iatefl #iateflconference2012 post: Revising and recycling lexis http:\/\/t.co\/pVVRn6EO",
  "id" : 182818812004024320,
  "created_at" : "2012-03-22 13:19:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IATEFL Online",
      "screen_name" : "iateflonline",
      "indices" : [ 0, 13 ],
      "id_str" : "17447359",
      "id" : 17447359
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "182804355358003204",
  "in_reply_to_user_id" : 17447359,
  "text" : "@iateflonline looking for Robert O'Neill interview from yesterday, can't see it on website?",
  "id" : 182804355358003204,
  "created_at" : "2012-03-22 12:22:09 +0000",
  "in_reply_to_screen_name" : "iateflonline",
  "in_reply_to_user_id_str" : "17447359",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IATEFL Online",
      "screen_name" : "iateflonline",
      "indices" : [ 70, 83 ],
      "id_str" : "17447359",
      "id" : 17447359
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 0, 7 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 49, 57 ]
    }, {
      "text" : "esl",
      "indices" : [ 58, 62 ]
    }, {
      "text" : "tesol",
      "indices" : [ 63, 69 ]
    }, {
      "text" : "elt",
      "indices" : [ 84, 88 ]
    }, {
      "text" : "edtech",
      "indices" : [ 89, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/4GjZKhoM",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-6u",
      "display_url" : "wp.me\/pgHyE-6u"
    } ]
  },
  "geo" : { },
  "id_str" : "182780319974440960",
  "text" : "#IATEFL blog Robert O'Neill http:\/\/t.co\/4GjZKhoM #eltchat #esl #tesol @iateflonline #elt #edtech",
  "id" : 182780319974440960,
  "created_at" : "2012-03-22 10:46:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 9, 16 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "182775935760736257",
  "text" : "watching #IATEFL recording of Robert O'Neill acceptance speech, brilliant! thkx for not bleeping it!",
  "id" : 182775935760736257,
  "created_at" : "2012-03-22 10:29:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IATEFL Online",
      "screen_name" : "iateflonline",
      "indices" : [ 71, 84 ],
      "id_str" : "17447359",
      "id" : 17447359
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 0, 7 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 50, 58 ]
    }, {
      "text" : "esl",
      "indices" : [ 59, 63 ]
    }, {
      "text" : "tesol",
      "indices" : [ 64, 70 ]
    }, {
      "text" : "elt",
      "indices" : [ 85, 89 ]
    }, {
      "text" : "edtech",
      "indices" : [ 90, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/nEYh2pFH",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-6e",
      "display_url" : "wp.me\/pgHyE-6e"
    } ]
  },
  "geo" : { },
  "id_str" : "182772179979603969",
  "text" : "#IATEFL blog mobile learning http:\/\/t.co\/nEYh2pFH #eltchat #esl #tesol @iateflonline #elt #edtech",
  "id" : 182772179979603969,
  "created_at" : "2012-03-22 10:14:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/f3ovoRDy",
      "expanded_url" : "http:\/\/brianhaw.tv\/index.php\/blog?start=3",
      "display_url" : "brianhaw.tv\/index.php\/blog\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "182633665132630016",
  "text" : "http:\/\/t.co\/f3ovoRDy The Queen The fairytale",
  "id" : 182633665132630016,
  "created_at" : "2012-03-22 01:03:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheConsultantsE",
      "screen_name" : "TheConsultantsE",
      "indices" : [ 50, 66 ],
      "id_str" : "13435662",
      "id" : 13435662
    }, {
      "name" : "Lindsay Clandfield",
      "screen_name" : "lclandfield",
      "indices" : [ 67, 79 ],
      "id_str" : "30663558",
      "id" : 30663558
    }, {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 80, 94 ],
      "id_str" : "25388528",
      "id" : 25388528
    }, {
      "name" : "SOY GICA",
      "screen_name" : "GISELLEMSANTOS",
      "indices" : [ 95, 110 ],
      "id_str" : "54197269",
      "id" : 54197269
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/nEYh2pFH",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-6e",
      "display_url" : "wp.me\/pgHyE-6e"
    } ]
  },
  "geo" : { },
  "id_str" : "182617548360122368",
  "text" : "#IATEFL blog mobile learning http:\/\/t.co\/nEYh2pFH @theconsultantse @lclandfield @audreywatters @GISELLEMSANTOS @CoffeeAddictMe",
  "id" : 182617548360122368,
  "created_at" : "2012-03-21 23:59:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IATEFL Online",
      "screen_name" : "iateflonline",
      "indices" : [ 66, 79 ],
      "id_str" : "17447359",
      "id" : 17447359
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 0, 7 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 45, 53 ]
    }, {
      "text" : "esl",
      "indices" : [ 54, 58 ]
    }, {
      "text" : "tesol",
      "indices" : [ 59, 65 ]
    }, {
      "text" : "elt",
      "indices" : [ 80, 84 ]
    }, {
      "text" : "edtech",
      "indices" : [ 85, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http:\/\/t.co\/nEYh2pFH",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-6e",
      "display_url" : "wp.me\/pgHyE-6e"
    } ]
  },
  "geo" : { },
  "id_str" : "182611792223141888",
  "text" : "#IATEFL mobile learning http:\/\/t.co\/nEYh2pFH #eltchat #esl #tesol @iateflonline #elt #edtech",
  "id" : 182611792223141888,
  "created_at" : "2012-03-21 23:36:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Slingluff",
      "screen_name" : "lvanderzanden",
      "indices" : [ 3, 17 ],
      "id_str" : "125659700",
      "id" : 125659700
    }, {
      "name" : "EDTECH HULK",
      "screen_name" : "EDTECHHULK",
      "indices" : [ 19, 30 ],
      "id_str" : "235000147",
      "id" : 235000147
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "182578311954841600",
  "text" : "RT @lvanderzanden: @EDTECHHULK phew! i was worried about how I was going to make people seasick AND disengaged at the same time",
  "id" : 182578311954841600,
  "created_at" : "2012-03-21 21:23:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EDTECH HULK",
      "screen_name" : "EDTECHHULK",
      "indices" : [ 3, 14 ],
      "id_str" : "235000147",
      "id" : 235000147
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "182574921757630465",
  "text" : "RT @EDTECHHULK: PREZI MAKE IT EASY TO IMPORT POWERPOINT SLIDES! GREAT! THAT MEAN MAKING BAD PREZIS EASIER THAN EVER!&lt;rofl :)",
  "id" : 182574921757630465,
  "created_at" : "2012-03-21 21:10:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "182556898996920322",
  "text" : "@esolamin yr welcome!",
  "id" : 182556898996920322,
  "created_at" : "2012-03-21 19:58:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dale Coulter",
      "screen_name" : "dalecoulter",
      "indices" : [ 0, 12 ],
      "id_str" : "24046458",
      "id" : 24046458
    }, {
      "name" : "Anna Loseva",
      "screen_name" : "AnnLoseva",
      "indices" : [ 13, 23 ],
      "id_str" : "38822368",
      "id" : 38822368
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182551061205229568",
  "geo" : { },
  "id_str" : "182553865416212480",
  "in_reply_to_user_id" : 24046458,
  "text" : "@dalecoulter @AnnLoseva subcribed for - sense of something you are waiting to have\/ subscribe to has sense of already having something?",
  "id" : 182553865416212480,
  "in_reply_to_status_id" : 182551061205229568,
  "created_at" : "2012-03-21 19:46:47 +0000",
  "in_reply_to_screen_name" : "dalecoulter",
  "in_reply_to_user_id_str" : "24046458",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/USPgHWp8",
      "expanded_url" : "http:\/\/www.londonsoverthrow.org\/",
      "display_url" : "londonsoverthrow.org"
    } ]
  },
  "geo" : { },
  "id_str" : "182479364720566273",
  "text" : "China Mieville potential lesson in this photoessay on London http:\/\/t.co\/USPgHWp8",
  "id" : 182479364720566273,
  "created_at" : "2012-03-21 14:50:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tailor-made English",
      "screen_name" : "TailormadeEng",
      "indices" : [ 3, 17 ],
      "id_str" : "337766907",
      "id" : 337766907
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 64, 71 ]
    }, {
      "text" : "elt",
      "indices" : [ 94, 98 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 99, 107 ]
    }, {
      "text" : "elt",
      "indices" : [ 108, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/y6RdVfLk",
      "expanded_url" : "http:\/\/bit.ly\/vZ63ps",
      "display_url" : "bit.ly\/vZ63ps"
    } ]
  },
  "geo" : { },
  "id_str" : "182419349171216384",
  "text" : "MT @TailormadeEng Report on innovative idea 4 using Facebook at #IATEFL. http:\/\/t.co\/y6RdVfLk #elt #eltchat #elt&lt;-agr nice fake profile idea",
  "id" : 182419349171216384,
  "created_at" : "2012-03-21 10:52:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cheimi10",
      "screen_name" : "cheimi10",
      "indices" : [ 60, 69 ],
      "id_str" : "2547295525",
      "id" : 2547295525
    }, {
      "name" : "Luke Meddings",
      "screen_name" : "LukeMeddings",
      "indices" : [ 70, 83 ],
      "id_str" : "39718253",
      "id" : 39718253
    }, {
      "name" : "Lindsay Clandfield",
      "screen_name" : "lclandfield",
      "indices" : [ 84, 96 ],
      "id_str" : "30663558",
      "id" : 30663558
    }, {
      "name" : "Willy C. Cardoso",
      "screen_name" : "willycard",
      "indices" : [ 97, 107 ],
      "id_str" : "102353142",
      "id" : 102353142
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 21, 28 ]
    } ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/mAqH4zHI",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-5X",
      "display_url" : "wp.me\/pgHyE-5X"
    } ]
  },
  "geo" : { },
  "id_str" : "182412693775462400",
  "text" : "Elephant in the room #IATEFL blog post http:\/\/t.co\/mAqH4zHI @cheimi10 @LukeMeddings @lclandfield @willycard",
  "id" : 182412693775462400,
  "created_at" : "2012-03-21 10:25:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 74, 81 ]
    }, {
      "text" : "DianaLaurillard",
      "indices" : [ 82, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/CbSjJVDW",
      "expanded_url" : "http:\/\/thor.dcs.bbk.ac.uk\/projects\/LDSE\/Dejan\/ODC\/ODC.html",
      "display_url" : "thor.dcs.bbk.ac.uk\/projects\/LDSE\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "182406404609544192",
  "text" : "frm joshau on sidechat pedagogical pattern collector http:\/\/t.co\/CbSjJVDW #IATEFL #DianaLaurillard",
  "id" : 182406404609544192,
  "created_at" : "2012-03-21 10:00:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karenne Sylvester",
      "screen_name" : "kalinagoenglish",
      "indices" : [ 3, 19 ],
      "id_str" : "22755100",
      "id" : 22755100
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iatefl",
      "indices" : [ 87, 94 ]
    }, {
      "text" : "diannlaurillard",
      "indices" : [ 95, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "182401465103556608",
  "text" : "RT @kalinagoenglish: Almost all technology hasn't been \"made\" directly for education - #iatefl #diannlaurillard &lt;--has been made FROM edu :)",
  "id" : 182401465103556608,
  "created_at" : "2012-03-21 09:41:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 74, 81 ]
    }, {
      "text" : "diannlaurillard",
      "indices" : [ 82, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "182397708026388480",
  "text" : "good to see Diana Laurillard situate learing in current political context #IATEFL #diannlaurillard @diannlaurillard",
  "id" : 182397708026388480,
  "created_at" : "2012-03-21 09:26:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IATEFL Online",
      "screen_name" : "iateflonline",
      "indices" : [ 90, 103 ],
      "id_str" : "17447359",
      "id" : 17447359
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 13, 20 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 104, 112 ]
    }, {
      "text" : "esl",
      "indices" : [ 113, 117 ]
    }, {
      "text" : "efl",
      "indices" : [ 118, 122 ]
    }, {
      "text" : "IATEFL2012",
      "indices" : [ 123, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/mAqH4zHI",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-5X",
      "display_url" : "wp.me\/pgHyE-5X"
    } ]
  },
  "geo" : { },
  "id_str" : "182381376325160960",
  "text" : "Some 2nd day #IATEFL blog coverage http:\/\/t.co\/mAqH4zHI elephant in the room#iateflonline @iateflonline #eltchat #esl #efl #IATEFL2012",
  "id" : 182381376325160960,
  "created_at" : "2012-03-21 08:21:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IATEFL Online",
      "screen_name" : "iateflonline",
      "indices" : [ 91, 104 ],
      "id_str" : "17447359",
      "id" : 17447359
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 13, 20 ]
    } ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/mAqH4zHI",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-5X",
      "display_url" : "wp.me\/pgHyE-5X"
    } ]
  },
  "geo" : { },
  "id_str" : "182224302295367680",
  "text" : "Some 2nd day #IATEFL blog coverage  http:\/\/t.co\/mAqH4zHI elephant in the room#iateflonline @iateflonline",
  "id" : 182224302295367680,
  "created_at" : "2012-03-20 21:57:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/HhEWvGdt",
      "expanded_url" : "http:\/\/socialinvestigations.blogspot.co.uk\/2012\/02\/nhs-privatisation-compilation-of.html?m=1",
      "display_url" : "socialinvestigations.blogspot.co.uk\/2012\/02\/nhs-pr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "182124131112853504",
  "text" : "http:\/\/t.co\/HhEWvGdt - Comp financial interests NHS privatization",
  "id" : 182124131112853504,
  "created_at" : "2012-03-20 15:19:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Patsko",
      "screen_name" : "lauraahaha",
      "indices" : [ 0, 11 ],
      "id_str" : "97957137",
      "id" : 97957137
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 12, 19 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "182092800752488448",
  "in_reply_to_user_id" : 97957137,
  "text" : "@lauraahaha #IATEFL blogging fiend!",
  "id" : 182092800752488448,
  "created_at" : "2012-03-20 13:14:41 +0000",
  "in_reply_to_screen_name" : "lauraahaha",
  "in_reply_to_user_id_str" : "97957137",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Patsko",
      "screen_name" : "lauraahaha",
      "indices" : [ 3, 14 ],
      "id_str" : "97957137",
      "id" : 97957137
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iatefl",
      "indices" : [ 19, 26 ]
    }, {
      "text" : "iateflconference2012",
      "indices" : [ 27, 48 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/i5c2H1e6",
      "expanded_url" : "http:\/\/post.ly\/67VN3",
      "display_url" : "post.ly\/67VN3"
    } ]
  },
  "geo" : { },
  "id_str" : "182088617840222208",
  "text" : "RT @lauraahaha New #iatefl #iateflconference2012 post: Using corpora to supplement coursebook vocab http:\/\/t.co\/i5c2H1e6",
  "id" : 182088617840222208,
  "created_at" : "2012-03-20 12:58:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "182029292618776576",
  "text" : "20 March 2012 RIP NHS? or will fightback get going?",
  "id" : 182029292618776576,
  "created_at" : "2012-03-20 09:02:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chiew Pang",
      "screen_name" : "aClilToClimb",
      "indices" : [ 0, 13 ],
      "id_str" : "76160458",
      "id" : 76160458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181895754825216000",
  "geo" : { },
  "id_str" : "181898402920009729",
  "in_reply_to_user_id" : 76160458,
  "text" : "@aClilToClimb no worries and i look fwd to reading some glasgow posts from you!",
  "id" : 181898402920009729,
  "in_reply_to_status_id" : 181895754825216000,
  "created_at" : "2012-03-20 00:22:13 +0000",
  "in_reply_to_screen_name" : "aClilToClimb",
  "in_reply_to_user_id_str" : "76160458",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chiew Pang",
      "screen_name" : "aClilToClimb",
      "indices" : [ 0, 13 ],
      "id_str" : "76160458",
      "id" : 76160458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181891332523036674",
  "geo" : { },
  "id_str" : "181894546425262080",
  "in_reply_to_user_id" : 76160458,
  "text" : "@aClilToClimb yes looks like your blog needs to be added, on a different blog i get \"video forbidden this video is private\" sign",
  "id" : 181894546425262080,
  "in_reply_to_status_id" : 181891332523036674,
  "created_at" : "2012-03-20 00:06:53 +0000",
  "in_reply_to_screen_name" : "aClilToClimb",
  "in_reply_to_user_id_str" : "76160458",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chiew Pang",
      "screen_name" : "aClilToClimb",
      "indices" : [ 0, 13 ],
      "id_str" : "76160458",
      "id" : 76160458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181890104808325120",
  "geo" : { },
  "id_str" : "181890935272124417",
  "in_reply_to_user_id" : 76160458,
  "text" : "@aClilToClimb what video r you trying to embed? can test it on my wordpress account",
  "id" : 181890935272124417,
  "in_reply_to_status_id" : 181890104808325120,
  "created_at" : "2012-03-19 23:52:32 +0000",
  "in_reply_to_screen_name" : "aClilToClimb",
  "in_reply_to_user_id_str" : "76160458",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chiew Pang",
      "screen_name" : "aClilToClimb",
      "indices" : [ 0, 13 ],
      "id_str" : "76160458",
      "id" : 76160458
    }, {
      "name" : "Graham Stanley",
      "screen_name" : "grahamstanley",
      "indices" : [ 14, 28 ],
      "id_str" : "74143",
      "id" : 74143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181889291914444800",
  "geo" : { },
  "id_str" : "181889801409146880",
  "in_reply_to_user_id" : 76160458,
  "text" : "@aClilToClimb @grahamstanley have u tried all options - legacy, flash w\/HTML fallback and iframe?",
  "id" : 181889801409146880,
  "in_reply_to_status_id" : 181889291914444800,
  "created_at" : "2012-03-19 23:48:02 +0000",
  "in_reply_to_screen_name" : "aClilToClimb",
  "in_reply_to_user_id_str" : "76160458",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chiew Pang",
      "screen_name" : "aClilToClimb",
      "indices" : [ 0, 13 ],
      "id_str" : "76160458",
      "id" : 76160458
    }, {
      "name" : "Graham Stanley",
      "screen_name" : "grahamstanley",
      "indices" : [ 14, 28 ],
      "id_str" : "74143",
      "id" : 74143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "181887120586178560",
  "geo" : { },
  "id_str" : "181888767634833410",
  "in_reply_to_user_id" : 76160458,
  "text" : "@aClilToClimb @grahamstanley yes i have though there was ready made option for wordpress accounts",
  "id" : 181888767634833410,
  "in_reply_to_status_id" : 181887120586178560,
  "created_at" : "2012-03-19 23:43:56 +0000",
  "in_reply_to_screen_name" : "aClilToClimb",
  "in_reply_to_user_id_str" : "76160458",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Janet Bianchini",
      "screen_name" : "janetbianchini",
      "indices" : [ 17, 32 ],
      "id_str" : "17720032",
      "id" : 17720032
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/FSu3MQrF",
      "expanded_url" : "http:\/\/bit.ly\/GzoJmM",
      "display_url" : "bit.ly\/GzoJmM"
    }, {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/7nBCcSz3",
      "expanded_url" : "http:\/\/bit.ly\/FPIJ3K",
      "display_url" : "bit.ly\/FPIJ3K"
    } ]
  },
  "geo" : { },
  "id_str" : "181872365385428992",
  "text" : "#IATEFL roundup2:@janetbianchini: http:\/\/t.co\/FSu3MQrF chrislima: http:\/\/t.co\/7nBCcSz3",
  "id" : 181872365385428992,
  "created_at" : "2012-03-19 22:38:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mercedes Viola",
      "screen_name" : "mercedesviola",
      "indices" : [ 25, 39 ],
      "id_str" : "66825962",
      "id" : 66825962
    }, {
      "name" : "Creative Technology",
      "screen_name" : "createch1",
      "indices" : [ 62, 72 ],
      "id_str" : "253097816",
      "id" : 253097816
    }, {
      "name" : "Elmira Merve Oflaz",
      "screen_name" : "oflazmerve",
      "indices" : [ 95, 106 ],
      "id_str" : "263866847",
      "id" : 263866847
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "181867001566855169",
  "text" : "#IATEFL blogger roundup1:@mercedesviola:\/http:\/\/bit.ly\/FQu8DK\/@createch1:\/http:\/\/bit.ly\/FQ2aqX\/@oflazmerve:\/http:\/\/bit.ly\/FQom6W\/",
  "id" : 181867001566855169,
  "created_at" : "2012-03-19 22:17:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elmira Merve Oflaz",
      "screen_name" : "oflazmerve",
      "indices" : [ 0, 11 ],
      "id_str" : "263866847",
      "id" : 263866847
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "181860329800732672",
  "in_reply_to_user_id" : 263866847,
  "text" : "@oflazmerve cheers for RT! :)",
  "id" : 181860329800732672,
  "created_at" : "2012-03-19 21:50:56 +0000",
  "in_reply_to_screen_name" : "oflazmerve",
  "in_reply_to_user_id_str" : "263866847",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dudeneyge",
      "screen_name" : "dudeneyge",
      "indices" : [ 0, 10 ],
      "id_str" : "2484562308",
      "id" : 2484562308
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 71, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 19, 39 ],
      "url" : "http:\/\/t.co\/3MZJGozJ",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-5e",
      "display_url" : "wp.me\/pgHyE-5e"
    } ]
  },
  "geo" : { },
  "id_str" : "181824546188435457",
  "text" : "@dudeneyge hi here http:\/\/t.co\/3MZJGozJ is a quick and dirty review of #IATEFL 2012 conference program",
  "id" : 181824546188435457,
  "created_at" : "2012-03-19 19:28:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IATEFL Online",
      "screen_name" : "iateflonline",
      "indices" : [ 77, 90 ],
      "id_str" : "17447359",
      "id" : 17447359
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 19, 26 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 91, 99 ]
    }, {
      "text" : "TESOL",
      "indices" : [ 100, 106 ]
    }, {
      "text" : "esl",
      "indices" : [ 107, 111 ]
    }, {
      "text" : "edtech",
      "indices" : [ 112, 119 ]
    }, {
      "text" : "elt",
      "indices" : [ 120, 124 ]
    }, {
      "text" : "tefl",
      "indices" : [ 125, 130 ]
    }, {
      "text" : "besig",
      "indices" : [ 131, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/3MZJGozJ",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-5e",
      "display_url" : "wp.me\/pgHyE-5e"
    } ]
  },
  "geo" : { },
  "id_str" : "181819957770858496",
  "text" : "First blog post on #IATEFL 2012 - mobile program review http:\/\/t.co\/3MZJGozJ @iateflonline #eltchat #TESOL #esl #edtech #elt #tefl #besig",
  "id" : 181819957770858496,
  "created_at" : "2012-03-19 19:10:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Seymour",
      "screen_name" : "leninology",
      "indices" : [ 125, 136 ],
      "id_str" : "15557246",
      "id" : 15557246
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "180985103076433920",
  "text" : "\"But what is at stake now is an attempt to re-organize the social body behind a resurgent militarism.\"http:\/\/bit.ly\/zaFmny v\/@leninology",
  "id" : 180985103076433920,
  "created_at" : "2012-03-17 11:53:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian James",
      "screen_name" : "ij64",
      "indices" : [ 3, 8 ],
      "id_str" : "13726222",
      "id" : 13726222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/ANiHY0x5",
      "expanded_url" : "http:\/\/bbc.in\/x1wbZ0",
      "display_url" : "bbc.in\/x1wbZ0"
    } ]
  },
  "geo" : { },
  "id_str" : "180947406328827904",
  "text" : "RT @ij64: Victory is guaranteed! The Hoff backs Wales! http:\/\/t.co\/ANiHY0x5&lt;--kiss of death surely! :)",
  "id" : 180947406328827904,
  "created_at" : "2012-03-17 09:23:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFLResig",
      "indices" : [ 102, 114 ]
    }, {
      "text" : "ELTchat",
      "indices" : [ 115, 123 ]
    }, {
      "text" : "ESL",
      "indices" : [ 124, 128 ]
    }, {
      "text" : "EFL",
      "indices" : [ 129, 133 ]
    }, {
      "text" : "TESOL",
      "indices" : [ 134, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/SwMgtx5K",
      "expanded_url" : "http:\/\/wp.me\/p22kHp-2b",
      "display_url" : "wp.me\/p22kHp-2b"
    } ]
  },
  "geo" : { },
  "id_str" : "180775575915470848",
  "text" : "Knowledge is Moving House Again! http:\/\/t.co\/SwMgtx5K&lt;--Connectivism and other 'learning' theories #IATEFLResig #ELTchat #ESL #EFL #TESOL",
  "id" : 180775575915470848,
  "created_at" : "2012-03-16 22:00:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "indices" : [ 0, 13 ],
      "id_str" : "1685397408",
      "id" : 1685397408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/TrM6S1C1",
      "expanded_url" : "http:\/\/vimeo.com\/23904357",
      "display_url" : "vimeo.com\/23904357"
    }, {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/4CQLEt26",
      "expanded_url" : "http:\/\/soundlandscapes.wordpress.com\/",
      "display_url" : "soundlandscapes.wordpress.com"
    } ]
  },
  "geo" : { },
  "id_str" : "180736900183764992",
  "text" : "@harrisonmike enjoyed yr sound art in tesol .fr, hav u seen this proj http:\/\/t.co\/TrM6S1C1? also gd site for paris http:\/\/t.co\/4CQLEt26",
  "id" : 180736900183764992,
  "created_at" : "2012-03-16 19:26:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELT",
      "indices" : [ 72, 76 ]
    }, {
      "text" : "ELTchat",
      "indices" : [ 77, 85 ]
    }, {
      "text" : "ESL",
      "indices" : [ 86, 90 ]
    }, {
      "text" : "TESOL",
      "indices" : [ 91, 97 ]
    }, {
      "text" : "iTD",
      "indices" : [ 98, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/cDvfPctB",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-4u",
      "display_url" : "wp.me\/pgHyE-4u"
    } ]
  },
  "geo" : { },
  "id_str" : "180722595635793920",
  "text" : "Blog post:Even French students not into winemaking http:\/\/t.co\/cDvfPctB #ELT #ELTchat #ESL #TESOL #iTD i#elt",
  "id" : 180722595635793920,
  "created_at" : "2012-03-16 18:29:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Simpson",
      "screen_name" : "yearinthelifeof",
      "indices" : [ 3, 19 ],
      "id_str" : "78543378",
      "id" : 78543378
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 65, 72 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 99, 107 ]
    }, {
      "text" : "tesol",
      "indices" : [ 108, 114 ]
    }, {
      "text" : "elt",
      "indices" : [ 115, 119 ]
    }, {
      "text" : "edtech",
      "indices" : [ 120, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/PKSujQNg",
      "expanded_url" : "http:\/\/goo.gl\/fb\/VfELS",
      "display_url" : "goo.gl\/fb\/VfELS"
    } ]
  },
  "geo" : { },
  "id_str" : "180693198207848448",
  "text" : "RT @yearinthelifeof: Why you should go and see at Joe Pereira at #IATEFL 2012 http:\/\/t.co\/PKSujQNg #eltchat #tesol #elt #edtech",
  "id" : 180693198207848448,
  "created_at" : "2012-03-16 16:33:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Graham Stanley",
      "screen_name" : "grahamstanley",
      "indices" : [ 0, 14 ],
      "id_str" : "74143",
      "id" : 74143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180551263782572032",
  "geo" : { },
  "id_str" : "180552456965586945",
  "in_reply_to_user_id" : 74143,
  "text" : "@grahamstanley typo alert it's M for Mura not N for Nura! thanks",
  "id" : 180552456965586945,
  "in_reply_to_status_id" : 180551263782572032,
  "created_at" : "2012-03-16 07:13:54 +0000",
  "in_reply_to_screen_name" : "grahamstanley",
  "in_reply_to_user_id_str" : "74143",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Levine",
      "screen_name" : "cogdog",
      "indices" : [ 65, 72 ],
      "id_str" : "740343",
      "id" : 740343
    }, {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 75, 89 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 41, 48 ]
    }, {
      "text" : "IATEFLonline",
      "indices" : [ 49, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 20, 40 ],
      "url" : "http:\/\/t.co\/WHKLLSB0",
      "expanded_url" : "http:\/\/cogdogblog.com\/2012\/03\/08\/flip-more-than-classrooms\/",
      "display_url" : "cogdogblog.com\/2012\/03\/08\/fli\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "180551989212618753",
  "text" : "Flip the conference http:\/\/t.co\/WHKLLSB0 #IATEFL #IATEFLonline v\/@cogdog v\/@audreywatters",
  "id" : 180551989212618753,
  "created_at" : "2012-03-16 07:12:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "langchat",
      "indices" : [ 17, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "180452931370352641",
  "text" : "gracias y adios! #langchat",
  "id" : 180452931370352641,
  "created_at" : "2012-03-16 00:38:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "langchat",
      "indices" : [ 127, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "180450221409583104",
  "text" : "been thinking about using just sounds recently after suggestion i read in a teaching mag since i am also into field recordings #langchat",
  "id" : 180450221409583104,
  "created_at" : "2012-03-16 00:27:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Aebersold",
      "screen_name" : "klafrench",
      "indices" : [ 0, 10 ],
      "id_str" : "36466689",
      "id" : 36466689
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "langchat",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180448217631174657",
  "geo" : { },
  "id_str" : "180448616241037312",
  "in_reply_to_user_id" : 36466689,
  "text" : "@klafrench re french you can get some selection from lyrics training #langchat",
  "id" : 180448616241037312,
  "in_reply_to_status_id" : 180448217631174657,
  "created_at" : "2012-03-16 00:21:17 +0000",
  "in_reply_to_screen_name" : "klafrench",
  "in_reply_to_user_id_str" : "36466689",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "langchat",
      "indices" : [ 129, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "180447926433222657",
  "text" : "with advanced learners using a section of instrumental version, ask for thoughts mood, feeling,more open-ended than lyrics focus #langchat",
  "id" : 180447926433222657,
  "created_at" : "2012-03-16 00:18:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tamara B Caudill",
      "screen_name" : "tbcaudill",
      "indices" : [ 0, 10 ],
      "id_str" : "501826466",
      "id" : 501826466
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "langchat",
      "indices" : [ 41, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "180447249711644672",
  "in_reply_to_user_id" : 501826466,
  "text" : "@tbcaudill no English teacher lurking :) #langchat",
  "id" : 180447249711644672,
  "created_at" : "2012-03-16 00:15:51 +0000",
  "in_reply_to_screen_name" : "tbcaudill",
  "in_reply_to_user_id_str" : "501826466",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessie Jessup",
      "screen_name" : "JessieJessup",
      "indices" : [ 0, 13 ],
      "id_str" : "143313538",
      "id" : 143313538
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Bookmash",
      "indices" : [ 100, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "180431344336257024",
  "in_reply_to_user_id" : 143313538,
  "text" : "@JessieJessup great bookmash \/Waiting for the barbarians \/Outside wonderland...! you may wnt to use #Bookmash for future ones!",
  "id" : 180431344336257024,
  "created_at" : "2012-03-15 23:12:39 +0000",
  "in_reply_to_screen_name" : "JessieJessup",
  "in_reply_to_user_id_str" : "143313538",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/uDcIfjp3",
      "expanded_url" : "http:\/\/twitpic.com\/8wrvuk",
      "display_url" : "twitpic.com\/8wrvuk"
    } ]
  },
  "geo" : { },
  "id_str" : "180423980006653952",
  "text" : "http:\/\/t.co\/uDcIfjp3 - Initially I read it the other way but my wife said it sounds better this way.",
  "id" : 180423980006653952,
  "created_at" : "2012-03-15 22:43:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stan Carey",
      "screen_name" : "StanCarey",
      "indices" : [ 94, 104 ],
      "id_str" : "34347535",
      "id" : 34347535
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Bookmash",
      "indices" : [ 84, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/uDcIfjp3",
      "expanded_url" : "http:\/\/twitpic.com\/8wrvuk",
      "display_url" : "twitpic.com\/8wrvuk"
    } ]
  },
  "geo" : { },
  "id_str" : "180419815842914304",
  "text" : "French BookMash: \u00C0 la recherche de Caleb\/Le compas de No\u00E9\/L'Africain\/Le coeur glac\u00E9 #Bookmash @StanCarey http:\/\/t.co\/uDcIfjp3",
  "id" : 180419815842914304,
  "created_at" : "2012-03-15 22:26:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 3, 17 ],
      "id_str" : "25388528",
      "id" : 25388528
    }, {
      "name" : "Digital Play",
      "screen_name" : "eltdigitalplay",
      "indices" : [ 81, 96 ],
      "id_str" : "67682458",
      "id" : 67682458
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gamification",
      "indices" : [ 97, 110 ]
    }, {
      "text" : "IATEFL",
      "indices" : [ 111, 118 ]
    }, {
      "text" : "IATEFLonline",
      "indices" : [ 119, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/GnrHxfEC",
      "expanded_url" : "http:\/\/bit.ly\/xiB7e9",
      "display_url" : "bit.ly\/xiB7e9"
    } ]
  },
  "geo" : { },
  "id_str" : "180395104605966336",
  "text" : "RT @audreywatters: MinecraftEDU:Minecraft for the classroom http:\/\/t.co\/GnrHxfEC @eltdigitalplay #gamification #IATEFL #IATEFLonline",
  "id" : 180395104605966336,
  "created_at" : "2012-03-15 20:48:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stan Carey",
      "screen_name" : "StanCarey",
      "indices" : [ 3, 13 ],
      "id_str" : "34347535",
      "id" : 34347535
    }, {
      "name" : "Sarah Ditum",
      "screen_name" : "sarahditum",
      "indices" : [ 118, 129 ],
      "id_str" : "14431987",
      "id" : 14431987
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/gZ9ceVGN",
      "expanded_url" : "http:\/\/bit.ly\/A604lV",
      "display_url" : "bit.ly\/A604lV"
    } ]
  },
  "geo" : { },
  "id_str" : "180317532928999424",
  "text" : "MT @StanCarey: \"How can you change lives without being trusted?\" The Prime of Miss Jean Brodie http:\/\/t.co\/gZ9ceVGN v\/@sarahditum&lt;-grt post",
  "id" : 180317532928999424,
  "created_at" : "2012-03-15 15:40:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hakan \u015Eent\u00FCrk",
      "screen_name" : "hakan_sentrk",
      "indices" : [ 0, 13 ],
      "id_str" : "118198984",
      "id" : 118198984
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180283817217638400",
  "geo" : { },
  "id_str" : "180285664120668160",
  "in_reply_to_user_id" : 118198984,
  "text" : "@hakan_sentrk yes it would certainly get them to process the reading much more deeply, food for thought!",
  "id" : 180285664120668160,
  "in_reply_to_status_id" : 180283817217638400,
  "created_at" : "2012-03-15 13:33:46 +0000",
  "in_reply_to_screen_name" : "hakan_sentrk",
  "in_reply_to_user_id_str" : "118198984",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hakan \u015Eent\u00FCrk",
      "screen_name" : "hakan_sentrk",
      "indices" : [ 0, 13 ],
      "id_str" : "118198984",
      "id" : 118198984
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "180280660773175297",
  "in_reply_to_user_id" : 118198984,
  "text" : "@hakan_sentrk hi just read yr great post on prezi\/reading, have u tried getting sts to make the prezis after a reading?",
  "id" : 180280660773175297,
  "created_at" : "2012-03-15 13:13:53 +0000",
  "in_reply_to_screen_name" : "hakan_sentrk",
  "in_reply_to_user_id_str" : "118198984",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chadsansing",
      "screen_name" : "chadsansing",
      "indices" : [ 0, 12 ],
      "id_str" : "76810409",
      "id" : 76810409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http:\/\/t.co\/cDvfPctB",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-4u",
      "display_url" : "wp.me\/pgHyE-4u"
    } ]
  },
  "geo" : { },
  "id_str" : "180274202945929218",
  "in_reply_to_user_id" : 76810409,
  "text" : "@chadsansing thx for retweet of http:\/\/t.co\/cDvfPctB",
  "id" : 180274202945929218,
  "created_at" : "2012-03-15 12:48:13 +0000",
  "in_reply_to_screen_name" : "chadsansing",
  "in_reply_to_user_id_str" : "76810409",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anna Loseva",
      "screen_name" : "AnnLoseva",
      "indices" : [ 3, 13 ],
      "id_str" : "38822368",
      "id" : 38822368
    }, {
      "name" : "Luke Meddings",
      "screen_name" : "LukeMeddings",
      "indices" : [ 46, 59 ],
      "id_str" : "39718253",
      "id" : 39718253
    }, {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 85, 93 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/HUnha4jK",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=br8clQYcDU4&sns=tw",
      "display_url" : "youtube.com\/watch?v=br8clQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "180223857582551040",
  "text" : "MT @AnnLoseva Teaching Unplugged Austria with @lukemeddings http:\/\/t.co\/HUnha4jK via @youtube&lt;-nice meditational effects",
  "id" : 180223857582551040,
  "created_at" : "2012-03-15 09:28:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Huw Jarvis",
      "screen_name" : "TESOLacademic",
      "indices" : [ 3, 17 ],
      "id_str" : "43409552",
      "id" : 43409552
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 91, 98 ]
    }, {
      "text" : "IATEFLonline",
      "indices" : [ 99, 112 ]
    }, {
      "text" : "ELTchat",
      "indices" : [ 113, 121 ]
    }, {
      "text" : "ELT",
      "indices" : [ 122, 126 ]
    }, {
      "text" : "ESL",
      "indices" : [ 127, 131 ]
    }, {
      "text" : "TESOL",
      "indices" : [ 132, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/sQyl1TfP",
      "expanded_url" : "http:\/\/bit.ly\/x9KDTG",
      "display_url" : "bit.ly\/x9KDTG"
    } ]
  },
  "geo" : { },
  "id_str" : "180169646010404864",
  "text" : "RT @TESOLacademic: US &amp; UK policy promotes linguistic imperialism http:\/\/t.co\/sQyl1TfP #IATEFL #IATEFLonline #ELTchat #ELT #ESL #TESOL",
  "id" : 180169646010404864,
  "created_at" : "2012-03-15 05:52:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chadsansing",
      "screen_name" : "chadsansing",
      "indices" : [ 124, 136 ],
      "id_str" : "76810409",
      "id" : 76810409
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELT",
      "indices" : [ 76, 80 ]
    }, {
      "text" : "ELTchat",
      "indices" : [ 81, 89 ]
    }, {
      "text" : "ESL",
      "indices" : [ 90, 94 ]
    }, {
      "text" : "TESOL",
      "indices" : [ 95, 101 ]
    }, {
      "text" : "IATEFL",
      "indices" : [ 102, 109 ]
    }, {
      "text" : "IATEFLonline",
      "indices" : [ 110, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/cDvfPctB",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-4u",
      "display_url" : "wp.me\/pgHyE-4u"
    } ]
  },
  "geo" : { },
  "id_str" : "180098885509853184",
  "text" : "New blog post:Even French students not into winemaking http:\/\/t.co\/cDvfPctB #ELT #ELTchat #ESL #TESOL #IATEFL #IATEFLonline @chadsansing",
  "id" : 180098885509853184,
  "created_at" : "2012-03-15 01:11:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 20, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "180054237772910592",
  "text" : "cheers for chat all #eltchat",
  "id" : 180054237772910592,
  "created_at" : "2012-03-14 22:14:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Toula Sklavou",
      "screen_name" : "toulasklavou",
      "indices" : [ 3, 16 ],
      "id_str" : "137794752",
      "id" : 137794752
    }, {
      "name" : "Dale Coulter",
      "screen_name" : "dalecoulter",
      "indices" : [ 17, 29 ],
      "id_str" : "24046458",
      "id" : 24046458
    }, {
      "name" : "sharon noseley",
      "screen_name" : "shaznosel",
      "indices" : [ 30, 40 ],
      "id_str" : "140167864",
      "id" : 140167864
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 126, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "180052133666754560",
  "text" : "RT @toulasklavou @dalecoulter @shaznosel how d u retweet and write a comment at the same time?&lt;-copy paste add RT to front #eltchat",
  "id" : 180052133666754560,
  "created_at" : "2012-03-14 22:05:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaunwilden",
      "screen_name" : "Shaunwilden",
      "indices" : [ 0, 12 ],
      "id_str" : "15350512",
      "id" : 15350512
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 47, 55 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180050482318934016",
  "geo" : { },
  "id_str" : "180050720417001472",
  "in_reply_to_user_id" : 15350512,
  "text" : "@Shaunwilden how long is a piece of string? :) #eltchat",
  "id" : 180050720417001472,
  "in_reply_to_status_id" : 180050482318934016,
  "created_at" : "2012-03-14 22:00:11 +0000",
  "in_reply_to_screen_name" : "Shaunwilden",
  "in_reply_to_user_id_str" : "15350512",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 52, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "180048100470165505",
  "text" : "realising i have yet to learn grammar of twitter :) #eltchat",
  "id" : 180048100470165505,
  "created_at" : "2012-03-14 21:49:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Gaughan",
      "screen_name" : "AnthonyGaughan",
      "indices" : [ 0, 15 ],
      "id_str" : "245975798",
      "id" : 245975798
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 106, 114 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "180043887904174080",
  "geo" : { },
  "id_str" : "180044642799194112",
  "in_reply_to_user_id" : 245975798,
  "text" : "@AnthonyGaughan rarely do i base a lesson around a grammar point unless i am doing exam course or similar #eltchat",
  "id" : 180044642799194112,
  "in_reply_to_status_id" : 180043887904174080,
  "created_at" : "2012-03-14 21:36:02 +0000",
  "in_reply_to_screen_name" : "AnthonyGaughan",
  "in_reply_to_user_id_str" : "245975798",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 118, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "180043245915602944",
  "text" : "i find grammar for written form tricky to 'teach' in a communicative way e.g. passive voice for writing about process #eltchat",
  "id" : 180043245915602944,
  "created_at" : "2012-03-14 21:30:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valentina Morgana",
      "screen_name" : "vmorgana",
      "indices" : [ 0, 9 ],
      "id_str" : "62479177",
      "id" : 62479177
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 64, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/lMlPWWbK",
      "expanded_url" : "http:\/\/www.teachingenglish.org.uk\/seminars\/what-matters-grammar-teaching",
      "display_url" : "teachingenglish.org.uk\/seminars\/what-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "180041015984533505",
  "geo" : { },
  "id_str" : "180041533012197376",
  "in_reply_to_user_id" : 62479177,
  "text" : "@vmorgana What matters in grammar teaching http:\/\/t.co\/lMlPWWbK #eltchat",
  "id" : 180041533012197376,
  "in_reply_to_status_id" : 180041015984533505,
  "created_at" : "2012-03-14 21:23:41 +0000",
  "in_reply_to_screen_name" : "vmorgana",
  "in_reply_to_user_id_str" : "62479177",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 81, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "180040085113278464",
  "text" : "anyone seen Swan's seminar on grammar teching on teh BC seminar site? quite good #eltchat",
  "id" : 180040085113278464,
  "created_at" : "2012-03-14 21:17:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ira Socol",
      "screen_name" : "irasocol",
      "indices" : [ 40, 49 ],
      "id_str" : "1249711",
      "id" : 1249711
    }, {
      "name" : "chadsansing",
      "screen_name" : "chadsansing",
      "indices" : [ 54, 66 ],
      "id_str" : "76810409",
      "id" : 76810409
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELT",
      "indices" : [ 67, 71 ]
    }, {
      "text" : "ELTchat",
      "indices" : [ 72, 80 ]
    }, {
      "text" : "ESL",
      "indices" : [ 81, 85 ]
    }, {
      "text" : "TESOL",
      "indices" : [ 86, 92 ]
    }, {
      "text" : "IATEFL",
      "indices" : [ 93, 100 ]
    }, {
      "text" : "IATEFLonline",
      "indices" : [ 101, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 15, 35 ],
      "url" : "http:\/\/t.co\/7SDWDFw8",
      "expanded_url" : "http:\/\/ngm.nationalgeographic.com\/2011\/10\/teenage-brains\/dobbs-text",
      "display_url" : "ngm.nationalgeographic.com\/2011\/10\/teenag\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "179965342280450048",
  "text" : "Teenage Brains http:\/\/t.co\/7SDWDFw8 via @irasocol via @chadsansing #ELT #ELTchat #ESL #TESOL #IATEFL #IATEFLonline",
  "id" : 179965342280450048,
  "created_at" : "2012-03-14 16:20:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 90, 98 ]
    }, {
      "text" : "elt",
      "indices" : [ 99, 103 ]
    }, {
      "text" : "tefl",
      "indices" : [ 104, 109 ]
    }, {
      "text" : "esl",
      "indices" : [ 110, 114 ]
    }, {
      "text" : "efl",
      "indices" : [ 115, 119 ]
    }, {
      "text" : "TESOL",
      "indices" : [ 120, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/dKtSMAQj",
      "expanded_url" : "http:\/\/reg.cx\/1UyY",
      "display_url" : "reg.cx\/1UyY"
    } ]
  },
  "geo" : { },
  "id_str" : "179890194122686464",
  "text" : "UK kids' art project is 'biggest copyright blag ever' \u2013 photographer http:\/\/t.co\/dKtSMAQj #eltchat #elt #tefl #esl #efl #TESOL",
  "id" : 179890194122686464,
  "created_at" : "2012-03-14 11:22:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Don Williams",
      "screen_name" : "donaldthesane",
      "indices" : [ 0, 14 ],
      "id_str" : "370274508",
      "id" : 370274508
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/SOvnvytf",
      "expanded_url" : "http:\/\/www.digitaldisruption.co.uk\/",
      "display_url" : "digitaldisruption.co.uk"
    } ]
  },
  "geo" : { },
  "id_str" : "179876222011056128",
  "in_reply_to_user_id" : 370274508,
  "text" : "@donaldthesane Some useful stuff here methinks http:\/\/t.co\/SOvnvytf",
  "id" : 179876222011056128,
  "created_at" : "2012-03-14 10:26:47 +0000",
  "in_reply_to_screen_name" : "donaldthesane",
  "in_reply_to_user_id_str" : "370274508",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Graham Stanley",
      "screen_name" : "grahamstanley",
      "indices" : [ 0, 14 ],
      "id_str" : "74143",
      "id" : 74143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "179664029160189953",
  "geo" : { },
  "id_str" : "179685412380475392",
  "in_reply_to_user_id" : 74143,
  "text" : "@grahamstanley congrats! how many are bots though? :)",
  "id" : 179685412380475392,
  "in_reply_to_status_id" : 179664029160189953,
  "created_at" : "2012-03-13 21:48:35 +0000",
  "in_reply_to_screen_name" : "grahamstanley",
  "in_reply_to_user_id_str" : "74143",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Fry",
      "screen_name" : "stephenfry",
      "indices" : [ 3, 14 ],
      "id_str" : "15439395",
      "id" : 15439395
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DevilsDetails",
      "indices" : [ 61, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "179540484195233794",
  "text" : "MT @stephenfry: Fraudsters can access your details anywhere, #DevilsDetails &lt;--is it april 1st yet?",
  "id" : 179540484195233794,
  "created_at" : "2012-03-13 12:12:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josette LeBlanc",
      "screen_name" : "JosetteLB",
      "indices" : [ 0, 10 ],
      "id_str" : "33503694",
      "id" : 33503694
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELTChat",
      "indices" : [ 42, 50 ]
    }, {
      "text" : "ELT",
      "indices" : [ 52, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 11, 31 ],
      "url" : "http:\/\/t.co\/47UAm0nt",
      "expanded_url" : "http:\/\/www.esl-lab.com\/",
      "display_url" : "esl-lab.com"
    } ]
  },
  "in_reply_to_status_id_str" : "179484964633575424",
  "geo" : { },
  "id_str" : "179492016416231424",
  "in_reply_to_user_id" : 33503694,
  "text" : "@JosetteLB http:\/\/t.co\/47UAm0nt is useful #ELTChat  #ELT",
  "id" : 179492016416231424,
  "in_reply_to_status_id" : 179484964633575424,
  "created_at" : "2012-03-13 09:00:06 +0000",
  "in_reply_to_screen_name" : "JosetteLB",
  "in_reply_to_user_id_str" : "33503694",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/TTLJrP38",
      "expanded_url" : "http:\/\/userscripts.org\/50003",
      "display_url" : "userscripts.org\/50003"
    } ]
  },
  "geo" : { },
  "id_str" : "179277207850594304",
  "text" : "with TEDED launch reminder Download YouTube Captions - http:\/\/t.co\/TTLJrP38 with Greasemonkey for FireFox",
  "id" : 179277207850594304,
  "created_at" : "2012-03-12 18:46:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IATEFL ReSIG",
      "screen_name" : "IATEFLResig",
      "indices" : [ 0, 12 ],
      "id_str" : "335823604",
      "id" : 335823604
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "179241004006768641",
  "geo" : { },
  "id_str" : "179259867960315904",
  "in_reply_to_user_id" : 335823604,
  "text" : "@IATEFLResig ah great cheers!",
  "id" : 179259867960315904,
  "in_reply_to_status_id" : 179241004006768641,
  "created_at" : "2012-03-12 17:37:37 +0000",
  "in_reply_to_screen_name" : "IATEFLResig",
  "in_reply_to_user_id_str" : "335823604",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http:\/\/t.co\/LowuUCtf",
      "expanded_url" : "http:\/\/thenewinquiry.com\/essays\/death-by-twitter\/",
      "display_url" : "thenewinquiry.com\/essays\/death-b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "179238419841552385",
  "text" : "Death by Twitter http:\/\/t.co\/LowuUCtf",
  "id" : 179238419841552385,
  "created_at" : "2012-03-12 16:12:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Seymour",
      "screen_name" : "leninology",
      "indices" : [ 53, 64 ],
      "id_str" : "15557246",
      "id" : 15557246
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "stopkony",
      "indices" : [ 5, 14 ]
    } ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/LSeBeVOi",
      "expanded_url" : "http:\/\/leninology.blogspot.com\/",
      "display_url" : "leninology.blogspot.com"
    } ]
  },
  "geo" : { },
  "id_str" : "179233656638943232",
  "text" : "Stop #stopkony LENIN'S TOMB http:\/\/t.co\/LSeBeVOi via @leninology",
  "id" : 179233656638943232,
  "created_at" : "2012-03-12 15:53:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 3, 11 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/B8NI2kpg",
      "expanded_url" : "http:\/\/tesltoronto.org\/hot-off-the-e-press",
      "display_url" : "tesltoronto.org\/hot-off-the-e-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "178976256082182145",
  "text" : "RT @seburnt: Two great TESL mags \u2013 free! http:\/\/t.co\/B8NI2kpg via @TESLToronto&lt;--thx found a couple of useful articles!",
  "id" : 178976256082182145,
  "created_at" : "2012-03-11 22:50:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valentina Morgana",
      "screen_name" : "vmorgana",
      "indices" : [ 0, 9 ],
      "id_str" : "62479177",
      "id" : 62479177
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178912939846283265",
  "geo" : { },
  "id_str" : "178918152632143874",
  "in_reply_to_user_id" : 62479177,
  "text" : "@vmorgana what is reason for blogging? mine - think out ideas, reflect on classes, connect with others. practical tip use wordpress",
  "id" : 178918152632143874,
  "in_reply_to_status_id" : 178912939846283265,
  "created_at" : "2012-03-11 18:59:46 +0000",
  "in_reply_to_screen_name" : "vmorgana",
  "in_reply_to_user_id_str" : "62479177",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Pereira",
      "screen_name" : "creedpatton",
      "indices" : [ 3, 15 ],
      "id_str" : "23870533",
      "id" : 23870533
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 29, 36 ]
    }, {
      "text" : "esl",
      "indices" : [ 126, 130 ]
    }, {
      "text" : "efl",
      "indices" : [ 131, 135 ]
    }, {
      "text" : "tesol",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "tefl",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "elt",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/wZI1UFaj",
      "expanded_url" : "http:\/\/bit.ly\/w27WfO",
      "display_url" : "bit.ly\/w27WfO"
    } ]
  },
  "geo" : { },
  "id_str" : "178907182182567936",
  "text" : "RT @creedpatton: Catch me at #IATEFL Glasgow! - How to introduce and use Interactive Fiction in a lesson http:\/\/t.co\/wZI1UFaj #esl #efl  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IATEFL",
        "indices" : [ 12, 19 ]
      }, {
        "text" : "esl",
        "indices" : [ 109, 113 ]
      }, {
        "text" : "efl",
        "indices" : [ 114, 118 ]
      }, {
        "text" : "tesol",
        "indices" : [ 119, 125 ]
      }, {
        "text" : "tefl",
        "indices" : [ 126, 131 ]
      }, {
        "text" : "elt",
        "indices" : [ 132, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 108 ],
        "url" : "http:\/\/t.co\/wZI1UFaj",
        "expanded_url" : "http:\/\/bit.ly\/w27WfO",
        "display_url" : "bit.ly\/w27WfO"
      } ]
    },
    "geo" : { },
    "id_str" : "178904747967909889",
    "text" : "Catch me at #IATEFL Glasgow! - How to introduce and use Interactive Fiction in a lesson http:\/\/t.co\/wZI1UFaj #esl #efl #tesol #tefl #elt",
    "id" : 178904747967909889,
    "created_at" : "2012-03-11 18:06:30 +0000",
    "user" : {
      "name" : "Joe Pereira",
      "screen_name" : "creedpatton",
      "protected" : false,
      "id_str" : "23870533",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3289669975\/1569cfba55f20e9e64d1ac62a1ecada9_normal.jpeg",
      "id" : 23870533,
      "verified" : false
    }
  },
  "id" : 178907182182567936,
  "created_at" : "2012-03-11 18:16:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Storify",
      "screen_name" : "Storify",
      "indices" : [ 94, 102 ],
      "id_str" : "17814938",
      "id" : 17814938
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "storify",
      "indices" : [ 81, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/xiCXeMA7",
      "expanded_url" : "http:\/\/storify.com\/alexismadrigal\/teju-cole-on-kony-and-the-white-savior-industrial",
      "display_url" : "storify.com\/alexismadrigal\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "178896934843584512",
  "text" : "Teju Cole Seven thoughts on the banality of sentimentality. http:\/\/t.co\/xiCXeMA7 #storify via @Storify",
  "id" : 178896934843584512,
  "created_at" : "2012-03-11 17:35:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Teju Cole",
      "screen_name" : "tejucole",
      "indices" : [ 3, 12 ],
      "id_str" : "83876527",
      "id" : 83876527
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "178896061677568003",
  "text" : "RT @tejucole: 7- I deeply respect American sentimentality, the way one respects a wounded hippo. You must keep an eye on it, for you kno ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "177810822268067841",
    "text" : "7- I deeply respect American sentimentality, the way one respects a wounded hippo. You must keep an eye on it, for you know it is deadly.",
    "id" : 177810822268067841,
    "created_at" : "2012-03-08 17:39:38 +0000",
    "user" : {
      "name" : "Teju Cole",
      "screen_name" : "tejucole",
      "protected" : false,
      "id_str" : "83876527",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1731884703\/teju3_normal.jpg",
      "id" : 83876527,
      "verified" : true
    }
  },
  "id" : 178896061677568003,
  "created_at" : "2012-03-11 17:31:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Teju Cole",
      "screen_name" : "tejucole",
      "indices" : [ 3, 12 ],
      "id_str" : "83876527",
      "id" : 83876527
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "178895974972923904",
  "text" : "RT @tejucole: 6- Feverish worry over that awful African warlord. But close to 1.5 million Iraqis died from an American war of choice. Wo ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "177810524908687360",
    "text" : "6- Feverish worry over that awful African warlord. But close to 1.5 million Iraqis died from an American war of choice. Worry about that.",
    "id" : 177810524908687360,
    "created_at" : "2012-03-08 17:38:27 +0000",
    "user" : {
      "name" : "Teju Cole",
      "screen_name" : "tejucole",
      "protected" : false,
      "id_str" : "83876527",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1731884703\/teju3_normal.jpg",
      "id" : 83876527,
      "verified" : true
    }
  },
  "id" : 178895974972923904,
  "created_at" : "2012-03-11 17:31:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Teju Cole",
      "screen_name" : "tejucole",
      "indices" : [ 3, 12 ],
      "id_str" : "83876527",
      "id" : 83876527
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "178895914063241216",
  "text" : "RT @tejucole: 5- The White Savior Industrial Complex is not about justice. It is about having a big emotional experience that validates  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "177810262223626241",
    "text" : "5- The White Savior Industrial Complex is not about justice. It is about having a big emotional experience that validates privilege.",
    "id" : 177810262223626241,
    "created_at" : "2012-03-08 17:37:24 +0000",
    "user" : {
      "name" : "Teju Cole",
      "screen_name" : "tejucole",
      "protected" : false,
      "id_str" : "83876527",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1731884703\/teju3_normal.jpg",
      "id" : 83876527,
      "verified" : true
    }
  },
  "id" : 178895914063241216,
  "created_at" : "2012-03-11 17:31:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Teju Cole",
      "screen_name" : "tejucole",
      "indices" : [ 3, 12 ],
      "id_str" : "83876527",
      "id" : 83876527
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "178895864171986944",
  "text" : "RT @tejucole: 4- This world exists simply to satisfy the needs\u2014including, importantly, the sentimental needs\u2014of white people and Oprah.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "177810073740001281",
    "text" : "4- This world exists simply to satisfy the needs\u2014including, importantly, the sentimental needs\u2014of white people and Oprah.",
    "id" : 177810073740001281,
    "created_at" : "2012-03-08 17:36:39 +0000",
    "user" : {
      "name" : "Teju Cole",
      "screen_name" : "tejucole",
      "protected" : false,
      "id_str" : "83876527",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1731884703\/teju3_normal.jpg",
      "id" : 83876527,
      "verified" : true
    }
  },
  "id" : 178895864171986944,
  "created_at" : "2012-03-11 17:31:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Teju Cole",
      "screen_name" : "tejucole",
      "indices" : [ 3, 12 ],
      "id_str" : "83876527",
      "id" : 83876527
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "178895493944983553",
  "text" : "RT @tejucole: 3- The banality of evil transmutes into the banality of sentimentality. The world is nothing but a problem to be solved by ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "177809821712650240",
    "text" : "3- The banality of evil transmutes into the banality of sentimentality. The world is nothing but a problem to be solved by enthusiasm.",
    "id" : 177809821712650240,
    "created_at" : "2012-03-08 17:35:39 +0000",
    "user" : {
      "name" : "Teju Cole",
      "screen_name" : "tejucole",
      "protected" : false,
      "id_str" : "83876527",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1731884703\/teju3_normal.jpg",
      "id" : 83876527,
      "verified" : true
    }
  },
  "id" : 178895493944983553,
  "created_at" : "2012-03-11 17:29:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Teju Cole",
      "screen_name" : "tejucole",
      "indices" : [ 3, 12 ],
      "id_str" : "83876527",
      "id" : 83876527
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "178895422230773760",
  "text" : "RT @tejucole: 2- The white savior supports brutal policies in the morning, founds charities in the afternoon, and receives awards in the ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "177809558608150529",
    "text" : "2- The white savior supports brutal policies in the morning, founds charities in the afternoon, and receives awards in the evening.",
    "id" : 177809558608150529,
    "created_at" : "2012-03-08 17:34:36 +0000",
    "user" : {
      "name" : "Teju Cole",
      "screen_name" : "tejucole",
      "protected" : false,
      "id_str" : "83876527",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1731884703\/teju3_normal.jpg",
      "id" : 83876527,
      "verified" : true
    }
  },
  "id" : 178895422230773760,
  "created_at" : "2012-03-11 17:29:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Teju Cole",
      "screen_name" : "tejucole",
      "indices" : [ 3, 12 ],
      "id_str" : "83876527",
      "id" : 83876527
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "178895166244012034",
  "text" : "RT @tejucole: 1- From Sachs to Kristof to Invisible Children to TED, the fastest growth industry in the US is the White Savior Industria ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "177809396070498304",
    "text" : "1- From Sachs to Kristof to Invisible Children to TED, the fastest growth industry in the US is the White Savior Industrial Complex.",
    "id" : 177809396070498304,
    "created_at" : "2012-03-08 17:33:58 +0000",
    "user" : {
      "name" : "Teju Cole",
      "screen_name" : "tejucole",
      "protected" : false,
      "id_str" : "83876527",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1731884703\/teju3_normal.jpg",
      "id" : 83876527,
      "verified" : true
    }
  },
  "id" : 178895166244012034,
  "created_at" : "2012-03-11 17:28:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "178877387252039680",
  "in_reply_to_user_id" : 416886093,
  "text" : "@BobDignen hi enjoyed your BESIG webinar, any chance to use your video?",
  "id" : 178877387252039680,
  "created_at" : "2012-03-11 16:17:47 +0000",
  "in_reply_to_screen_name" : "BobDignen_YA",
  "in_reply_to_user_id_str" : "416886093",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willy C. Cardoso",
      "screen_name" : "willycard",
      "indices" : [ 3, 13 ],
      "id_str" : "102353142",
      "id" : 102353142
    }, {
      "name" : "bren brennan",
      "screen_name" : "brenbrennan",
      "indices" : [ 80, 92 ],
      "id_str" : "39806371",
      "id" : 39806371
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/1YE0P53e",
      "expanded_url" : "http:\/\/bit.ly\/ymwyI4",
      "display_url" : "bit.ly\/ymwyI4"
    } ]
  },
  "geo" : { },
  "id_str" : "178832517783228416",
  "text" : "RT @willycard: Dogme Lesson vs DELTA level requirements http:\/\/t.co\/1YE0P53e by @brenbrennan Interesting point of view, will comment later.",
  "id" : 178832517783228416,
  "created_at" : "2012-03-11 13:19:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NikPeachey",
      "screen_name" : "NikPeachey",
      "indices" : [ 0, 11 ],
      "id_str" : "14548913",
      "id" : 14548913
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EFL",
      "indices" : [ 59, 63 ]
    }, {
      "text" : "ELT",
      "indices" : [ 64, 68 ]
    }, {
      "text" : "esl",
      "indices" : [ 69, 73 ]
    }, {
      "text" : "elearn",
      "indices" : [ 74, 81 ]
    }, {
      "text" : "edtech",
      "indices" : [ 82, 89 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "178768944964968449",
  "geo" : { },
  "id_str" : "178827034070495232",
  "in_reply_to_user_id" : 14548913,
  "text" : "@NikPeachey re Lingle how does it compare to LessonWriter? #EFL #ELT #esl #elearn #edtech",
  "id" : 178827034070495232,
  "in_reply_to_status_id" : 178768944964968449,
  "created_at" : "2012-03-11 12:57:42 +0000",
  "in_reply_to_screen_name" : "NikPeachey",
  "in_reply_to_user_id_str" : "14548913",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/eXWKsEZ5",
      "expanded_url" : "http:\/\/nilebowie.blogspot.com\/2012\/03\/youth-movement-promotes-us-military.html?spref=tw",
      "display_url" : "nilebowie.blogspot.com\/2012\/03\/youth-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "178707740728897536",
  "geo" : { },
  "id_str" : "178825030380167168",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt re Kony have u read this?http:\/\/t.co\/eXWKsEZ5",
  "id" : 178825030380167168,
  "in_reply_to_status_id" : 178707740728897536,
  "created_at" : "2012-03-11 12:49:44 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharon Turner",
      "screen_name" : "Sharonzspace",
      "indices" : [ 0, 13 ],
      "id_str" : "235194378",
      "id" : 235194378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/NOuWbTfV",
      "expanded_url" : "http:\/\/i.imgur.com\/K3mgn.jpgv",
      "display_url" : "i.imgur.com\/K3mgn.jpgv"
    } ]
  },
  "in_reply_to_status_id_str" : "178640470065414144",
  "geo" : { },
  "id_str" : "178646613680586752",
  "in_reply_to_user_id" : 235194378,
  "text" : "@Sharonzspace by all accounts LRA killings\/abductions peaked in 2006 so why this video now? lol:http:\/\/t.co\/NOuWbTfV-gen buttnaked real pers",
  "id" : 178646613680586752,
  "in_reply_to_status_id" : 178640470065414144,
  "created_at" : "2012-03-11 01:00:46 +0000",
  "in_reply_to_screen_name" : "Sharonzspace",
  "in_reply_to_user_id_str" : "235194378",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharon Turner",
      "screen_name" : "Sharonzspace",
      "indices" : [ 0, 13 ],
      "id_str" : "235194378",
      "id" : 235194378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/eXWKsEZ5",
      "expanded_url" : "http:\/\/nilebowie.blogspot.com\/2012\/03\/youth-movement-promotes-us-military.html?spref=tw",
      "display_url" : "nilebowie.blogspot.com\/2012\/03\/youth-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "178625873950420992",
  "in_reply_to_user_id" : 235194378,
  "text" : "@Sharonzspace re Kony have u read this?http:\/\/t.co\/eXWKsEZ5",
  "id" : 178625873950420992,
  "created_at" : "2012-03-10 23:38:21 +0000",
  "in_reply_to_screen_name" : "Sharonzspace",
  "in_reply_to_user_id_str" : "235194378",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willy C. Cardoso",
      "screen_name" : "willycard",
      "indices" : [ 0, 10 ],
      "id_str" : "102353142",
      "id" : 102353142
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TESOLSpain",
      "indices" : [ 28, 39 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/cdVlSv8c",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-47",
      "display_url" : "wp.me\/pgHyE-47"
    } ]
  },
  "geo" : { },
  "id_str" : "178432415616860160",
  "in_reply_to_user_id" : 102353142,
  "text" : "@willycard all the best for #TESOLSpain and thanks for the like on http:\/\/t.co\/cdVlSv8c :)",
  "id" : 178432415616860160,
  "created_at" : "2012-03-10 10:49:37 +0000",
  "in_reply_to_screen_name" : "willycard",
  "in_reply_to_user_id_str" : "102353142",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "project",
      "indices" : [ 47, 55 ]
    }, {
      "text" : "kony2012",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http:\/\/t.co\/NOuWbTfV",
      "expanded_url" : "http:\/\/i.imgur.com\/K3mgn.jpgv",
      "display_url" : "i.imgur.com\/K3mgn.jpgv"
    } ]
  },
  "geo" : { },
  "id_str" : "178249992874639361",
  "text" : "Kony virus: the antidote. http:\/\/t.co\/NOuWbTfV #project #kony2012",
  "id" : 178249992874639361,
  "created_at" : "2012-03-09 22:44:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EdTech",
      "screen_name" : "EdTech",
      "indices" : [ 77, 84 ],
      "id_str" : "10197402",
      "id" : 10197402
    }, {
      "name" : "Digital Play",
      "screen_name" : "eltdigitalplay",
      "indices" : [ 86, 101 ],
      "id_str" : "67682458",
      "id" : 67682458
    }, {
      "name" : "elton naicker",
      "screen_name" : "elt",
      "indices" : [ 102, 106 ],
      "id_str" : "131938942",
      "id" : 131938942
    }, {
      "name" : "ESL",
      "screen_name" : "ESL",
      "indices" : [ 107, 111 ],
      "id_str" : "16905329",
      "id" : 16905329
    }, {
      "name" : "edupunk",
      "screen_name" : "edupunk",
      "indices" : [ 112, 120 ],
      "id_str" : "15388670",
      "id" : 15388670
    }, {
      "name" : "Michelle",
      "screen_name" : "ict",
      "indices" : [ 121, 125 ],
      "id_str" : "14733559",
      "id" : 14733559
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/wgkFN0b0",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-2H",
      "display_url" : "wp.me\/pgHyE-2H"
    } ]
  },
  "geo" : { },
  "id_str" : "177887526277754880",
  "text" : "update to Online whiteboard to enhance reading activity http:\/\/t.co\/wgkFN0b0 @edtech, @eltdigitalplay @ELT @esl @edupunk @ict",
  "id" : 177887526277754880,
  "created_at" : "2012-03-08 22:44:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "theproject",
      "indices" : [ 87, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/eXWKsEZ5",
      "expanded_url" : "http:\/\/nilebowie.blogspot.com\/2012\/03\/youth-movement-promotes-us-military.html?spref=tw",
      "display_url" : "nilebowie.blogspot.com\/2012\/03\/youth-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "177870975206039554",
  "text" : "Nile Bowie: Youth Movement Promotes US Military Presence in Ce... http:\/\/t.co\/eXWKsEZ5 #theproject",
  "id" : 177870975206039554,
  "created_at" : "2012-03-08 21:38:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Libya 360\u00B0",
      "screen_name" : "libya360",
      "indices" : [ 88, 97 ],
      "id_str" : "332507058",
      "id" : 332507058
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/44Ff7oZx",
      "expanded_url" : "http:\/\/wp.me\/p1GGxO-3tm",
      "display_url" : "wp.me\/p1GGxO-3tm"
    } ]
  },
  "geo" : { },
  "id_str" : "177865780992552960",
  "text" : "YOUTH MOVEMENT PROMOTES US MILITARY PRESENCE IN CENTRAL AFRICA http:\/\/t.co\/44Ff7oZx via @libya360",
  "id" : 177865780992552960,
  "created_at" : "2012-03-08 21:18:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IATEFL Online",
      "screen_name" : "iateflonline",
      "indices" : [ 110, 123 ],
      "id_str" : "17447359",
      "id" : 17447359
    }, {
      "name" : "IATEFL Head Office",
      "screen_name" : "iatefl",
      "indices" : [ 124, 131 ],
      "id_str" : "85042286",
      "id" : 85042286
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 88, 95 ]
    }, {
      "text" : "iateflonline",
      "indices" : [ 96, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/cdVlSv8c",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-47",
      "display_url" : "wp.me\/pgHyE-47"
    } ]
  },
  "geo" : { },
  "id_str" : "177739976094662657",
  "text" : "I went to IATEFL 2012 and all I got was this lousy conference pack http:\/\/t.co\/cdVlSv8c #IATEFL #iateflonline @iateflonline @IATEFL",
  "id" : 177739976094662657,
  "created_at" : "2012-03-08 12:58:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sara f Peralta",
      "screen_name" : "sarafperalta",
      "indices" : [ 3, 16 ],
      "id_str" : "330781668",
      "id" : 330781668
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Occupyaustin",
      "indices" : [ 18, 31 ]
    }, {
      "text" : "sxswedu",
      "indices" : [ 35, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/VrzWnLMP",
      "expanded_url" : "http:\/\/instagr.am\/p\/H44n1Zkl4k\/",
      "display_url" : "instagr.am\/p\/H44n1Zkl4k\/"
    } ]
  },
  "geo" : { },
  "id_str" : "177532430515834884",
  "text" : "RT @sarafperalta: #Occupyaustin at #sxswedu.   http:\/\/t.co\/VrzWnLMP",
  "id" : 177532430515834884,
  "created_at" : "2012-03-07 23:13:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "occupyaustin",
      "indices" : [ 21, 34 ]
    }, {
      "text" : "swswedu",
      "indices" : [ 64, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "177531585783013376",
  "text" : "RT MT@audreywatters: #occupyaustin protesting the Pearson CEO's #swswedu keynote. TX $550 million the state pays Pearson for testing",
  "id" : 177531585783013376,
  "created_at" : "2012-03-07 23:10:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 9, 17 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "177513054496497666",
  "text" : "ciao all #eltchat",
  "id" : 177513054496497666,
  "created_at" : "2012-03-07 21:56:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Sketchley",
      "screen_name" : "ELTExperiences",
      "indices" : [ 0, 15 ],
      "id_str" : "22779473",
      "id" : 22779473
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELTChat",
      "indices" : [ 53, 61 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177503941163089921",
  "geo" : { },
  "id_str" : "177504388665982976",
  "in_reply_to_user_id" : 22779473,
  "text" : "@ELTExperiences as fools and ithings krap?(afaik) ;) #ELTChat",
  "id" : 177504388665982976,
  "in_reply_to_status_id" : 177503941163089921,
  "created_at" : "2012-03-07 21:21:58 +0000",
  "in_reply_to_screen_name" : "ELTExperiences",
  "in_reply_to_user_id_str" : "22779473",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Taylor",
      "screen_name" : "theteacherjames",
      "indices" : [ 0, 16 ],
      "id_str" : "71746265",
      "id" : 71746265
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELTChat",
      "indices" : [ 72, 80 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177503435569111042",
  "geo" : { },
  "id_str" : "177503755078602753",
  "in_reply_to_user_id" : 71746265,
  "text" : "@theteacherjames a cheap android tablet can also use web based content  #ELTChat",
  "id" : 177503755078602753,
  "in_reply_to_status_id" : 177503435569111042,
  "created_at" : "2012-03-07 21:19:27 +0000",
  "in_reply_to_screen_name" : "theteacherjames",
  "in_reply_to_user_id_str" : "71746265",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dina Dobrou",
      "screen_name" : "DinaDobrou",
      "indices" : [ 0, 11 ],
      "id_str" : "152605100",
      "id" : 152605100
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELTChat",
      "indices" : [ 84, 92 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177502269137371136",
  "geo" : { },
  "id_str" : "177502713863618561",
  "in_reply_to_user_id" : 152605100,
  "text" : "@DinaDobrou also closed system == inflexibility, rapid versions = outdated programs #ELTChat",
  "id" : 177502713863618561,
  "in_reply_to_status_id" : 177502269137371136,
  "created_at" : "2012-03-07 21:15:19 +0000",
  "in_reply_to_screen_name" : "DinaDobrou",
  "in_reply_to_user_id_str" : "152605100",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naomi Epstein",
      "screen_name" : "naomishema",
      "indices" : [ 0, 11 ],
      "id_str" : "228469472",
      "id" : 228469472
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELTChat",
      "indices" : [ 39, 47 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177501522802909184",
  "geo" : { },
  "id_str" : "177501921987407873",
  "in_reply_to_user_id" : 228469472,
  "text" : "@naomishema if progam is web based yes #ELTChat",
  "id" : 177501921987407873,
  "in_reply_to_status_id" : 177501522802909184,
  "created_at" : "2012-03-07 21:12:10 +0000",
  "in_reply_to_screen_name" : "naomishema",
  "in_reply_to_user_id_str" : "228469472",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naomi Epstein",
      "screen_name" : "naomishema",
      "indices" : [ 0, 11 ],
      "id_str" : "228469472",
      "id" : 228469472
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELTChat",
      "indices" : [ 70, 78 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "177500793446998017",
  "geo" : { },
  "id_str" : "177501331249037312",
  "in_reply_to_user_id" : 228469472,
  "text" : "@naomishema highly unlikely if program just developed for  ithing UI  #ELTChat",
  "id" : 177501331249037312,
  "in_reply_to_status_id" : 177500793446998017,
  "created_at" : "2012-03-07 21:09:49 +0000",
  "in_reply_to_screen_name" : "naomishema",
  "in_reply_to_user_id_str" : "228469472",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELTChat",
      "indices" : [ 94, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http:\/\/t.co\/ebVtU2eK",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-1T",
      "display_url" : "wp.me\/pgHyE-1T"
    } ]
  },
  "geo" : { },
  "id_str" : "177499514792448001",
  "text" : "hi am ithing skeptic (e.g. http:\/\/t.co\/ebVtU2eK) but i do admit variety of apps is remarkable #ELTChat",
  "id" : 177499514792448001,
  "created_at" : "2012-03-07 21:02:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tefl",
      "indices" : [ 125, 130 ]
    }, {
      "text" : "TESOL",
      "indices" : [ 131, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "177479003559559168",
  "text" : "if you get a DM like'Hey. somebody is posting real bad things about you :[ *link removed* DONT click is a fishing site#besig #tefl #TESOL",
  "id" : 177479003559559168,
  "created_at" : "2012-03-07 19:41:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chiew Pang",
      "screen_name" : "aClilToClimb",
      "indices" : [ 0, 13 ],
      "id_str" : "76160458",
      "id" : 76160458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "177478516164665344",
  "in_reply_to_user_id" : 76160458,
  "text" : "@aClilToClimb yes don a\/c been phished, he should be able to reset p\/w",
  "id" : 177478516164665344,
  "created_at" : "2012-03-07 19:39:10 +0000",
  "in_reply_to_screen_name" : "aClilToClimb",
  "in_reply_to_user_id_str" : "76160458",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 119, 126 ]
    }, {
      "text" : "ELTchat",
      "indices" : [ 127, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "177476054456340481",
  "text" : "if you get a DM like'Hey. somebody is posting real bad things about you :[ *link removed* DONT click is a fishing site #IATEFL #ELTchat",
  "id" : 177476054456340481,
  "created_at" : "2012-03-07 19:29:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "177475532668153856",
  "text" : "if you get a DM like'Hey. somebody is posting real bad things about you :[ *link removed**' don't click it looks like fishing site",
  "id" : 177475532668153856,
  "created_at" : "2012-03-07 19:27:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NikPeachey",
      "screen_name" : "NikPeachey",
      "indices" : [ 3, 14 ],
      "id_str" : "14548913",
      "id" : 14548913
    }, {
      "name" : "Scoop.it",
      "screen_name" : "scoopit",
      "indices" : [ 43, 51 ],
      "id_str" : "209484168",
      "id" : 209484168
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "esl",
      "indices" : [ 73, 77 ]
    }, {
      "text" : "ELT",
      "indices" : [ 78, 82 ]
    }, {
      "text" : "EFL",
      "indices" : [ 83, 87 ]
    }, {
      "text" : "edtech",
      "indices" : [ 88, 95 ]
    }, {
      "text" : "edupunk",
      "indices" : [ 96, 104 ]
    }, {
      "text" : "elearn",
      "indices" : [ 105, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/JuRfeJQJ",
      "expanded_url" : "http:\/\/bit.ly\/zCnbJb",
      "display_url" : "bit.ly\/zCnbJb"
    } ]
  },
  "geo" : { },
  "id_str" : "177405988570275840",
  "text" : "RT @NikPeachey Storyboard Generator tool | @scoopit http:\/\/t.co\/JuRfeJQJ #esl #ELT #EFL #edtech #edupunk #elearn&lt;--great for my multimedia S",
  "id" : 177405988570275840,
  "created_at" : "2012-03-07 14:50:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Don Williams",
      "screen_name" : "donaldthesane",
      "indices" : [ 0, 14 ],
      "id_str" : "370274508",
      "id" : 370274508
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/0zD8sFn0",
      "expanded_url" : "http:\/\/www.creatingfreedom.info\/",
      "display_url" : "creatingfreedom.info"
    } ]
  },
  "geo" : { },
  "id_str" : "177188438796271616",
  "in_reply_to_user_id" : 370274508,
  "text" : "@donaldthesane have you seen this project? http:\/\/t.co\/0zD8sFn0 seems like good material for critical thinking",
  "id" : 177188438796271616,
  "created_at" : "2012-03-07 00:26:30 +0000",
  "in_reply_to_screen_name" : "donaldthesane",
  "in_reply_to_user_id_str" : "370274508",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "177161755133362176",
  "text" : "started MITx circuits and electronics, interface much busier than Udacity, main lecturer voice a bit grating!",
  "id" : 177161755133362176,
  "created_at" : "2012-03-06 22:40:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IATEFL Online",
      "screen_name" : "iateflonline",
      "indices" : [ 82, 95 ],
      "id_str" : "17447359",
      "id" : 17447359
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 74, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/cdVlSv8c",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-47",
      "display_url" : "wp.me\/pgHyE-47"
    } ]
  },
  "geo" : { },
  "id_str" : "177052776432545793",
  "text" : "are educational conferences past their sell by date? http:\/\/t.co\/cdVlSv8c #IATEFL @iateflonline",
  "id" : 177052776432545793,
  "created_at" : "2012-03-06 15:27:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 3, 11 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EAPchat",
      "indices" : [ 13, 21 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/igM82fYE",
      "expanded_url" : "http:\/\/fourc.ca\/eapchat_sum_mar\/",
      "display_url" : "fourc.ca\/eapchat_sum_ma\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "177023616918102016",
  "text" : "RT @seburnt: #EAPchat Summary, Mon Mar 5: The relevance of the AWL http:\/\/t.co\/igM82fYE&lt;--nice graphic and good editing!",
  "id" : 177023616918102016,
  "created_at" : "2012-03-06 13:31:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shelly Sanchez",
      "screen_name" : "ShellTerrell",
      "indices" : [ 3, 16 ],
      "id_str" : "29655018",
      "id" : 29655018
    }, {
      "name" : "Rob Haines7",
      "screen_name" : "robhaines",
      "indices" : [ 81, 91 ],
      "id_str" : "602157008",
      "id" : 602157008
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 92, 100 ]
    }, {
      "text" : "dogme",
      "indices" : [ 101, 107 ]
    }, {
      "text" : "esl",
      "indices" : [ 108, 112 ]
    }, {
      "text" : "ellchat",
      "indices" : [ 113, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/UGgaPNyk",
      "expanded_url" : "http:\/\/bit.ly\/wejMEx",
      "display_url" : "bit.ly\/wejMEx"
    } ]
  },
  "geo" : { },
  "id_str" : "176828166533431296",
  "text" : "RT @ShellTerrell: When Two Worlds Collide http:\/\/t.co\/UGgaPNyk beautiful post by @robhaines #eltchat #dogme #esl #ellchat",
  "id" : 176828166533431296,
  "created_at" : "2012-03-06 00:34:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Mearns",
      "screen_name" : "davidmearns",
      "indices" : [ 3, 15 ],
      "id_str" : "30931681",
      "id" : 30931681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "176769870485127169",
  "text" : "RT @davidmearns: Detach-ment is one of the best teacher movies I have ever seen!&lt;--good teacher film evenif one subplot a bit unrealistic!",
  "id" : 176769870485127169,
  "created_at" : "2012-03-05 20:43:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "176768864925908992",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt sent summary to your four.ca mail. eh, how come you ain't following me!=0",
  "id" : 176768864925908992,
  "created_at" : "2012-03-05 20:39:16 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 21, 29 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 46, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "176747411476193280",
  "text" : "i'll send summary to @seburnt for him to post #eapchat",
  "id" : 176747411476193280,
  "created_at" : "2012-03-05 19:14:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mieke Kenis",
      "screen_name" : "mkofab",
      "indices" : [ 7, 14 ],
      "id_str" : "96527212",
      "id" : 96527212
    }, {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 15, 26 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 27, 35 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 63, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "176746094657679360",
  "text" : "thanks @mkofab @leoselivan @seburnt will try to summarise asap #eapchat",
  "id" : 176746094657679360,
  "created_at" : "2012-03-05 19:08:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 59, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "176744721950056448",
  "text" : "i can summarise chat if you can point me to relevant tools #eapchat",
  "id" : 176744721950056448,
  "created_at" : "2012-03-05 19:03:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 84, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "176744230516035585",
  "text" : "for TOEIC i have been using single words, been meaning to review this at some time! #eapchat",
  "id" : 176744230516035585,
  "created_at" : "2012-03-05 19:01:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 15, 23 ],
      "id_str" : "20650366",
      "id" : 20650366
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 25, 34 ],
      "id_str" : "18602422",
      "id" : 18602422
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 127, 135 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "176742075654615041",
  "geo" : { },
  "id_str" : "176743693557039104",
  "in_reply_to_user_id" : 20650366,
  "text" : "as they likeRT @seburnt: @muranava then they keep these annotated flashcards somewhere for review? rwrte them into a notebook? #eapchat",
  "id" : 176743693557039104,
  "in_reply_to_status_id" : 176742075654615041,
  "created_at" : "2012-03-05 18:59:14 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 37, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/FulX7jli",
      "expanded_url" : "http:\/\/www.yearinthelifeofanenglishteacher.com\/2011\/02\/how-i-developed-an-academic-vocabulary-syllabus\/",
      "display_url" : "yearinthelifeofanenglishteacher.com\/2011\/02\/how-i-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "176742525388857344",
  "text" : "also check this http:\/\/t.co\/FulX7jli #eapchat",
  "id" : 176742525388857344,
  "created_at" : "2012-03-05 18:54:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 122, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "176741184952221697",
  "text" : "yes like flash cards, where they can note other aspects of word as well, of course adv is easier to review vocab this way #eapchat",
  "id" : 176741184952221697,
  "created_at" : "2012-03-05 18:49:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 115, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "176740288377782272",
  "text" : "i sometimes suggest using bristol cards with my TOEIC students as a another apart from notebooks to organise vocab #eapchat",
  "id" : 176740288377782272,
  "created_at" : "2012-03-05 18:45:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 14, 25 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 29, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "176739731378421760",
  "text" : "use tweetchat @leoselivan :) #eapchat",
  "id" : 176739731378421760,
  "created_at" : "2012-03-05 18:43:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 97, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/pBav33H2",
      "expanded_url" : "http:\/\/www.visualthesaurus.com\/vocabgrabber\/",
      "display_url" : "visualthesaurus.com\/vocabgrabber\/"
    } ]
  },
  "geo" : { },
  "id_str" : "176737895237943297",
  "text" : "there is also vocabgrabber but i think you need to pay to get full features?http:\/\/t.co\/pBav33H2 #eapchat",
  "id" : 176737895237943297,
  "created_at" : "2012-03-05 18:36:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 51, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "176737013293264898",
  "text" : "thanks for \"just the word\" did not know about that #eapchat",
  "id" : 176737013293264898,
  "created_at" : "2012-03-05 18:32:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 49, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 10, 30 ],
      "url" : "http:\/\/t.co\/LweXO892",
      "expanded_url" : "http:\/\/wordandphrase.info",
      "display_url" : "wordandphrase.info"
    } ]
  },
  "geo" : { },
  "id_str" : "176736139904942080",
  "text" : "COCA with http:\/\/t.co\/LweXO892 interface is good #eapchat",
  "id" : 176736139904942080,
  "created_at" : "2012-03-05 18:29:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 122, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "176735530459996160",
  "text" : "for most teachers intuition is good, and until concordance software get easier to use will need to rely on our intuition! #eapchat",
  "id" : 176735530459996160,
  "created_at" : "2012-03-05 18:26:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 91, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 13, 33 ],
      "url" : "http:\/\/t.co\/iKhOvNTD",
      "expanded_url" : "http:\/\/www.antlab.sci.waseda.ac.jp\/antconc_index.html",
      "display_url" : "antlab.sci.waseda.ac.jp\/antconc_index.\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "176734169769050112",
  "text" : "antconc here http:\/\/t.co\/iKhOvNTD i am using text like wired, smashing magazine, webmonkey #eapchat",
  "id" : 176734169769050112,
  "created_at" : "2012-03-05 18:21:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 70, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "176734065070841856",
  "text" : "this course is unusual - the goal is for sts expand multi-media vocab #eapchat",
  "id" : 176734065070841856,
  "created_at" : "2012-03-05 18:20:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 29, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "176733065819852800",
  "text" : "i am using the anticonc tool #eapchat",
  "id" : 176733065819852800,
  "created_at" : "2012-03-05 18:17:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 122, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "176732764345876480",
  "text" : "but i find them useful to structure my courses, at the moment i am trying to build up a wordlist for a multi-media course #eapchat",
  "id" : 176732764345876480,
  "created_at" : "2012-03-05 18:15:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 98, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "176732497927876609",
  "text" : "yes agreed sts should be taught words in context and as part of an interesting and relevant text\n #eapchat",
  "id" : 176732497927876609,
  "created_at" : "2012-03-05 18:14:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 62, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "176730835372871681",
  "text" : "i think wordlists are useful for teachers not so sure for sts #eapchat",
  "id" : 176730835372871681,
  "created_at" : "2012-03-05 18:08:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapchat",
      "indices" : [ 39, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "176730667848179712",
  "text" : "is there a d\/l link for that article?\n #eapchat",
  "id" : 176730667848179712,
  "created_at" : "2012-03-05 18:07:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UMANPLN",
      "indices" : [ 0, 8 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "176575772281159680",
  "text" : "#UMANPLN like any network it is as good as the people in it and in Twitter there are a lot of very good people!",
  "id" : 176575772281159680,
  "created_at" : "2012-03-05 07:51:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willy C. Cardoso",
      "screen_name" : "willycard",
      "indices" : [ 0, 10 ],
      "id_str" : "102353142",
      "id" : 102353142
    }, {
      "name" : "Scott Thornbury",
      "screen_name" : "thornburyscott",
      "indices" : [ 11, 26 ],
      "id_str" : "23090474",
      "id" : 23090474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "176568079873089536",
  "in_reply_to_user_id" : 102353142,
  "text" : "@willycard @thornburyscott Re-booting Educational Conferences",
  "id" : 176568079873089536,
  "created_at" : "2012-03-05 07:21:25 +0000",
  "in_reply_to_screen_name" : "willycard",
  "in_reply_to_user_id_str" : "102353142",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IATEFL ReSIG",
      "screen_name" : "IATEFLResig",
      "indices" : [ 0, 12 ],
      "id_str" : "335823604",
      "id" : 335823604
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "176483813860442113",
  "in_reply_to_user_id" : 335823604,
  "text" : "@IATEFLResig is it possible to get a free copy of the Nation(2011\u00E0) article referenced in \"Article discussion wk2\"?",
  "id" : 176483813860442113,
  "created_at" : "2012-03-05 01:46:34 +0000",
  "in_reply_to_screen_name" : "IATEFLResig",
  "in_reply_to_user_id_str" : "335823604",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Lester",
      "screen_name" : "davelester",
      "indices" : [ 3, 14 ],
      "id_str" : "2773111",
      "id" : 2773111
    }, {
      "name" : "Paul Bausch",
      "screen_name" : "pbausch",
      "indices" : [ 92, 100 ],
      "id_str" : "818992",
      "id" : 818992
    }, {
      "name" : "Matt Haughey",
      "screen_name" : "mathowie",
      "indices" : [ 101, 110 ],
      "id_str" : "761975",
      "id" : 761975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/7cFZK38D",
      "expanded_url" : "http:\/\/beta.branch.com\/how-do-blogs-need-to-evolve",
      "display_url" : "beta.branch.com\/how-do-blogs-n\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "176451785978945536",
  "text" : "RT @davelester important discussion on \"how do blogs need to evolve?\"by @anildash@ev@megnut @pbausch @mathowie http:\/\/t.co\/7cFZK38D",
  "id" : 176451785978945536,
  "created_at" : "2012-03-04 23:39:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 55, 59 ]
    }, {
      "text" : "esl",
      "indices" : [ 60, 64 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 65, 73 ]
    }, {
      "text" : "iTDi",
      "indices" : [ 74, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/cdVlSv8c",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-47",
      "display_url" : "wp.me\/pgHyE-47"
    } ]
  },
  "geo" : { },
  "id_str" : "176414390487224322",
  "text" : "Rebooting Educational Conferences http:\/\/t.co\/cdVlSv8c #elt #esl #eltchat #iTDi",
  "id" : 176414390487224322,
  "created_at" : "2012-03-04 21:10:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 56, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/cdVlSv8c",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-47",
      "display_url" : "wp.me\/pgHyE-47"
    } ]
  },
  "geo" : { },
  "id_str" : "176393644947947520",
  "text" : "Rebooting Educational Conferences http:\/\/t.co\/cdVlSv8c  #IATEFL",
  "id" : 176393644947947520,
  "created_at" : "2012-03-04 19:48:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chadsansing",
      "screen_name" : "chadsansing",
      "indices" : [ 0, 12 ],
      "id_str" : "76810409",
      "id" : 76810409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/cdVlSv8c",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-47",
      "display_url" : "wp.me\/pgHyE-47"
    } ]
  },
  "geo" : { },
  "id_str" : "176380103943659520",
  "in_reply_to_user_id" : 76810409,
  "text" : "@chadsansing Re-booting educational conferences http:\/\/t.co\/cdVlSv8c",
  "id" : 176380103943659520,
  "created_at" : "2012-03-04 18:54:28 +0000",
  "in_reply_to_screen_name" : "chadsansing",
  "in_reply_to_user_id_str" : "76810409",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IATEFL Online",
      "screen_name" : "iateflonline",
      "indices" : [ 55, 68 ],
      "id_str" : "17447359",
      "id" : 17447359
    }, {
      "name" : "IATEFL ReSIG",
      "screen_name" : "IATEFLResig",
      "indices" : [ 69, 81 ],
      "id_str" : "335823604",
      "id" : 335823604
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/cdVlSv8c",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-47",
      "display_url" : "wp.me\/pgHyE-47"
    } ]
  },
  "geo" : { },
  "id_str" : "176377729334259712",
  "text" : "Rebooting Educational Conferences http:\/\/t.co\/cdVlSv8c @iateflonline @IATEFLResig",
  "id" : 176377729334259712,
  "created_at" : "2012-03-04 18:45:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karenne Sylvester",
      "screen_name" : "kalinagoenglish",
      "indices" : [ 0, 16 ],
      "id_str" : "22755100",
      "id" : 22755100
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "176223113128837120",
  "geo" : { },
  "id_str" : "176332360768434177",
  "in_reply_to_user_id" : 22755100,
  "text" : "@kalinagoenglish you're welcome, hope the workshop goes great!",
  "id" : 176332360768434177,
  "in_reply_to_status_id" : 176223113128837120,
  "created_at" : "2012-03-04 15:44:45 +0000",
  "in_reply_to_screen_name" : "kalinagoenglish",
  "in_reply_to_user_id_str" : "22755100",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "itdi.pro",
      "screen_name" : "iTDipro",
      "indices" : [ 0, 8 ],
      "id_str" : "374391424",
      "id" : 374391424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "176289144929136640",
  "geo" : { },
  "id_str" : "176332171156520961",
  "in_reply_to_user_id" : 374391424,
  "text" : "@iTDipro it was a good webinar - short and sweet! though i forgot to use presenters' twitter tags in my tweets!",
  "id" : 176332171156520961,
  "in_reply_to_status_id" : 176289144929136640,
  "created_at" : "2012-03-04 15:44:00 +0000",
  "in_reply_to_screen_name" : "iTDipro",
  "in_reply_to_user_id_str" : "374391424",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "itdi",
      "indices" : [ 97, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "175935189615247360",
  "text" : "ST - uses traffic light colours analogy as a signal to teachers whether student wants correcting #itdi",
  "id" : 175935189615247360,
  "created_at" : "2012-03-03 13:26:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "itdi",
      "indices" : [ 102, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "175932313903972352",
  "text" : "ST- teachers can accelerate time to learn frm mistakes but need to accept some mistakes will continue #itdi",
  "id" : 175932313903972352,
  "created_at" : "2012-03-03 13:15:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "itdi",
      "indices" : [ 135, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "175931717327134720",
  "text" : "Charles Rei: as a learner  when I received on-the-spot correction, I wasn't sure if teacher was acutally listening to wht I ws saying. #itdi",
  "id" : 175931717327134720,
  "created_at" : "2012-03-03 13:12:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "itdi",
      "indices" : [ 86, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "175928447955238914",
  "text" : "Steven Herder - peer correction works best when students have built up trust in class #itdi",
  "id" : 175928447955238914,
  "created_at" : "2012-03-03 12:59:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "itdi",
      "indices" : [ 130, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "175927595576209408",
  "text" : "ST - we should try to balance implict and explicit correction by being aware of 'nudges' through experience in heat of the moment #itdi",
  "id" : 175927595576209408,
  "created_at" : "2012-03-03 12:56:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "itdi",
      "indices" : [ 88, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "175923778335936512",
  "text" : "Barbara Sakamoto - - if we don't make mistakes then we r not doing anything interesting #itdi",
  "id" : 175923778335936512,
  "created_at" : "2012-03-03 12:41:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "itdi",
      "indices" : [ 55, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "175922681915514881",
  "text" : "Babara Sakamoto - grades YLs on all aspects of writing #itdi",
  "id" : 175922681915514881,
  "created_at" : "2012-03-03 12:36:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "itdi",
      "indices" : [ 68, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "175921543380090880",
  "text" : "Babara Sakamoto - examples of errors with young learners in writing #itdi",
  "id" : 175921543380090880,
  "created_at" : "2012-03-03 12:32:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "itdi",
      "indices" : [ 60, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "175920619211333634",
  "text" : "ST cites Rob Ellis(2008) - Corrective feedback is effective #itdi",
  "id" : 175920619211333634,
  "created_at" : "2012-03-03 12:28:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "itdi",
      "indices" : [ 60, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "175920212363841536",
  "text" : "Scott Thornbury - implicit feedback not noticed by students #itdi",
  "id" : 175920212363841536,
  "created_at" : "2012-03-03 12:27:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "itdi",
      "indices" : [ 73, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "175919496106749954",
  "text" : "Scott Thornbury, alternative to 'No' - recasting, chance to self-correct #itdi",
  "id" : 175919496106749954,
  "created_at" : "2012-03-03 12:24:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "itdi",
      "indices" : [ 85, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "175919031856005120",
  "text" : "Scott Thornbury - should we say 'No'? - alternatives e.g. take message at face value #itdi",
  "id" : 175919031856005120,
  "created_at" : "2012-03-03 12:22:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "itdi",
      "indices" : [ 59, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "175918163844796416",
  "text" : "steven herder error correction depends on learning contect #itdi",
  "id" : 175918163844796416,
  "created_at" : "2012-03-03 12:18:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 0, 14 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "175907639438475264",
  "in_reply_to_user_id" : 25388528,
  "text" : "@audreywatters hi, can you point me to any recent survey of open source ed tech? thx!",
  "id" : 175907639438475264,
  "created_at" : "2012-03-03 11:37:04 +0000",
  "in_reply_to_screen_name" : "audreywatters",
  "in_reply_to_user_id_str" : "25388528",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/ynSMQldP",
      "expanded_url" : "http:\/\/languagelog.ldc.upenn.edu\/nll\/?p=3814",
      "display_url" : "languagelog.ldc.upenn.edu\/nll\/?p=3814"
    } ]
  },
  "geo" : { },
  "id_str" : "175743479492775936",
  "text" : "hehe this speech jammer could come in handy with ''off task'' chatter http:\/\/t.co\/ynSMQldP ;)",
  "id" : 175743479492775936,
  "created_at" : "2012-03-03 00:44:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 3, 17 ],
      "id_str" : "25388528",
      "id" : 25388528
    }, {
      "name" : "Joel Levin",
      "screen_name" : "MinecraftTeachr",
      "indices" : [ 59, 75 ],
      "id_str" : "266369226",
      "id" : 266369226
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "175719465969909761",
  "text" : "RT @audreywatters: I just got a demo of @minecraftedu from @minecraftteachr and holy crap is it awesome!!&lt;--roll on pub release!",
  "id" : 175719465969909761,
  "created_at" : "2012-03-02 23:09:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/kfCBncll",
      "expanded_url" : "http:\/\/meetu.ps\/7k30P",
      "display_url" : "meetu.ps\/7k30P"
    } ]
  },
  "geo" : { },
  "id_str" : "175677456047554562",
  "text" : "Chat about Blended Learning and other opportunities for ELT teachers with English teachers in Paris http:\/\/t.co\/kfCBncll",
  "id" : 175677456047554562,
  "created_at" : "2012-03-02 20:22:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/QNFxoACe",
      "expanded_url" : "http:\/\/leninology.blogspot.com\/2012\/03\/tories-retreat-bemoan-isolation.html",
      "display_url" : "leninology.blogspot.com\/2012\/03\/tories\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "175595115480481792",
  "text" : "interesting collective noun - melanoma of businesses coined here http:\/\/t.co\/QNFxoACe",
  "id" : 175595115480481792,
  "created_at" : "2012-03-02 14:55:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "175577452658180096",
  "text" : "just finished HW2 on Udacity CS101 course! overall seemed less difficult than HW1.",
  "id" : 175577452658180096,
  "created_at" : "2012-03-02 13:45:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Teacher Annette",
      "screen_name" : "TeacherAnnette",
      "indices" : [ 14, 29 ],
      "id_str" : "503518609",
      "id" : 503518609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "175277566540775424",
  "text" : "thanks for RT @TeacherAnnette",
  "id" : 175277566540775424,
  "created_at" : "2012-03-01 17:53:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
} ]