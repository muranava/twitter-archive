Grailbird.data.tweets_2015_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon J. Eason",
      "screen_name" : "sjeason",
      "indices" : [ 0, 8 ],
      "id_str" : "258401804",
      "id" : 258401804
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "franceestlecoinmalfam\u00E9",
      "indices" : [ 83, 106 ]
    }, {
      "text" : "StopDjihadisme",
      "indices" : [ 107, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "561449316699893761",
  "text" : "@sjeason also special attention to those who don't carry baguette under the armpit #franceestlecoinmalfam\u00E9 #StopDjihadisme",
  "id" : 561449316699893761,
  "created_at" : "2015-01-31 09:02:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Caulfield",
      "screen_name" : "holden",
      "indices" : [ 3, 10 ],
      "id_str" : "1912681",
      "id" : 1912681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/bkktYnXbG1",
      "expanded_url" : "http:\/\/journal.hapgood.net\/view\/inhospitable-blogging",
      "display_url" : "journal.hapgood.net\/view\/inhospita\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "561220662946443264",
  "text" : "RT @holden: Inhospitable Blogging: http:\/\/t.co\/bkktYnXbG1 (fedwiki article)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 23, 45 ],
        "url" : "http:\/\/t.co\/bkktYnXbG1",
        "expanded_url" : "http:\/\/journal.hapgood.net\/view\/inhospitable-blogging",
        "display_url" : "journal.hapgood.net\/view\/inhospita\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "561213275136737281",
    "text" : "Inhospitable Blogging: http:\/\/t.co\/bkktYnXbG1 (fedwiki article)",
    "id" : 561213275136737281,
    "created_at" : "2015-01-30 17:24:06 +0000",
    "user" : {
      "name" : "Mike Caulfield",
      "screen_name" : "holden",
      "protected" : false,
      "id_str" : "1912681",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/752538301538545665\/mXNoIc4W_normal.jpg",
      "id" : 1912681,
      "verified" : false
    }
  },
  "id" : 561220662946443264,
  "created_at" : "2015-01-30 17:53:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Duygu \u00C7andarl\u0131",
      "screen_name" : "duygucandarli",
      "indices" : [ 3, 17 ],
      "id_str" : "48839094",
      "id" : 48839094
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/hMvmYp10L3",
      "expanded_url" : "http:\/\/qz.com\/312464",
      "display_url" : "qz.com\/312464"
    } ]
  },
  "geo" : { },
  "id_str" : "561217533605588992",
  "text" : "RT @duygucandarli: \"In China, there are three genders: male, female, and female PhD.\" Female PhD students are seen as 'leftover women'. htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/hMvmYp10L3",
        "expanded_url" : "http:\/\/qz.com\/312464",
        "display_url" : "qz.com\/312464"
      } ]
    },
    "geo" : { },
    "id_str" : "561086226825220096",
    "text" : "\"In China, there are three genders: male, female, and female PhD.\" Female PhD students are seen as 'leftover women'. http:\/\/t.co\/hMvmYp10L3",
    "id" : 561086226825220096,
    "created_at" : "2015-01-30 08:59:15 +0000",
    "user" : {
      "name" : "Duygu \u00C7andarl\u0131",
      "screen_name" : "duygucandarli",
      "protected" : false,
      "id_str" : "48839094",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/473607105765576704\/DIiO0Cy7_normal.jpeg",
      "id" : 48839094,
      "verified" : false
    }
  },
  "id" : 561217533605588992,
  "created_at" : "2015-01-30 17:41:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "M. Van Amelsvoort",
      "screen_name" : "Marcelva",
      "indices" : [ 3, 12 ],
      "id_str" : "21634927",
      "id" : 21634927
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/8otsFRgPfB",
      "expanded_url" : "http:\/\/mozuku.edublogs.org\/2015\/01\/30\/making-efl-matter-pt-2-data-and-feedback\/",
      "display_url" : "mozuku.edublogs.org\/2015\/01\/30\/mak\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "561189078239297536",
  "text" : "RT @Marcelva: New blog post on data and formative assessment in EFL classrooms. http:\/\/t.co\/8otsFRgPfB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 88 ],
        "url" : "http:\/\/t.co\/8otsFRgPfB",
        "expanded_url" : "http:\/\/mozuku.edublogs.org\/2015\/01\/30\/making-efl-matter-pt-2-data-and-feedback\/",
        "display_url" : "mozuku.edublogs.org\/2015\/01\/30\/mak\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "561038962718822401",
    "text" : "New blog post on data and formative assessment in EFL classrooms. http:\/\/t.co\/8otsFRgPfB",
    "id" : 561038962718822401,
    "created_at" : "2015-01-30 05:51:26 +0000",
    "user" : {
      "name" : "M. Van Amelsvoort",
      "screen_name" : "Marcelva",
      "protected" : false,
      "id_str" : "21634927",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/81656891\/mountaincherryOp_normal.jpg",
      "id" : 21634927,
      "verified" : false
    }
  },
  "id" : 561189078239297536,
  "created_at" : "2015-01-30 15:47:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 60, 75 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/HJCJ3NEYej",
      "expanded_url" : "http:\/\/wp.me\/p3qkCB-15x",
      "display_url" : "wp.me\/p3qkCB-15x"
    } ]
  },
  "geo" : { },
  "id_str" : "561039489079209984",
  "text" : "Demand High: Another Dud Product http:\/\/t.co\/HJCJ3NEYej via @GeoffreyJordan",
  "id" : 561039489079209984,
  "created_at" : "2015-01-30 05:53:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "openDemocracy",
      "screen_name" : "openDemocracy",
      "indices" : [ 119, 133 ],
      "id_str" : "15876845",
      "id" : 15876845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/hhScTnhlEo",
      "expanded_url" : "https:\/\/www.opendemocracy.net\/ourkingdom\/ian-sinclair\/defending-status-quo-labour-and-leftist-responses-to-green-surge#.VMqsR6eO14s.twitter",
      "display_url" : "opendemocracy.net\/ourkingdom\/ian\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "560919184771932160",
  "text" : "Defending the status quo: Labour and leftist responses to the Green Surge | openDemocracy: https:\/\/t.co\/hhScTnhlEo via @openDemocracy",
  "id" : 560919184771932160,
  "created_at" : "2015-01-29 21:55:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Porterfield",
      "screen_name" : "awp78",
      "indices" : [ 3, 9 ],
      "id_str" : "753926628",
      "id" : 753926628
    }, {
      "name" : "Quartz",
      "screen_name" : "qz",
      "indices" : [ 98, 101 ],
      "id_str" : "573918122",
      "id" : 573918122
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tesol",
      "indices" : [ 102, 108 ]
    }, {
      "text" : "languages",
      "indices" : [ 109, 119 ]
    }, {
      "text" : "linguistics",
      "indices" : [ 120, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/4GuPAio9Ke",
      "expanded_url" : "http:\/\/qz.com\/259129",
      "display_url" : "qz.com\/259129"
    } ]
  },
  "geo" : { },
  "id_str" : "560898783509495809",
  "text" : "RT @awp78: Can you guess where people are from based on their accents? http:\/\/t.co\/4GuPAio9Ke via @qz #tesol #languages #linguistics",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Quartz",
        "screen_name" : "qz",
        "indices" : [ 87, 90 ],
        "id_str" : "573918122",
        "id" : 573918122
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tesol",
        "indices" : [ 91, 97 ]
      }, {
        "text" : "languages",
        "indices" : [ 98, 108 ]
      }, {
        "text" : "linguistics",
        "indices" : [ 109, 121 ]
      } ],
      "urls" : [ {
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/4GuPAio9Ke",
        "expanded_url" : "http:\/\/qz.com\/259129",
        "display_url" : "qz.com\/259129"
      } ]
    },
    "geo" : { },
    "id_str" : "559709999749169153",
    "text" : "Can you guess where people are from based on their accents? http:\/\/t.co\/4GuPAio9Ke via @qz #tesol #languages #linguistics",
    "id" : 559709999749169153,
    "created_at" : "2015-01-26 13:50:37 +0000",
    "user" : {
      "name" : "Andrew Porterfield",
      "screen_name" : "awp78",
      "protected" : false,
      "id_str" : "753926628",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2496975995\/mq3vsommoq7wghb6ujel_normal.jpeg",
      "id" : 753926628,
      "verified" : false
    }
  },
  "id" : 560898783509495809,
  "created_at" : "2015-01-29 20:34:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonna L.",
      "screen_name" : "ediTransla",
      "indices" : [ 3, 14 ],
      "id_str" : "2375548591",
      "id" : 2375548591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/PuJ7KIXCaH",
      "expanded_url" : "http:\/\/learnercorpus.blogspot.co.uk\/?m=1",
      "display_url" : "learnercorpus.blogspot.co.uk\/?m=1"
    } ]
  },
  "geo" : { },
  "id_str" : "560885574286839808",
  "text" : "RT @ediTransla: Learner Corpora and Corpus Studies http:\/\/t.co\/PuJ7KIXCaH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 57 ],
        "url" : "http:\/\/t.co\/PuJ7KIXCaH",
        "expanded_url" : "http:\/\/learnercorpus.blogspot.co.uk\/?m=1",
        "display_url" : "learnercorpus.blogspot.co.uk\/?m=1"
      } ]
    },
    "geo" : { },
    "id_str" : "560878394137927681",
    "text" : "Learner Corpora and Corpus Studies http:\/\/t.co\/PuJ7KIXCaH",
    "id" : 560878394137927681,
    "created_at" : "2015-01-29 19:13:24 +0000",
    "user" : {
      "name" : "Jonna L.",
      "screen_name" : "ediTransla",
      "protected" : false,
      "id_str" : "2375548591",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606084099753705472\/AQ3eN7Q9_normal.jpg",
      "id" : 2375548591,
      "verified" : false
    }
  },
  "id" : 560885574286839808,
  "created_at" : "2015-01-29 19:41:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELT MAKERS",
      "screen_name" : "ELTMAKERS",
      "indices" : [ 0, 10 ],
      "id_str" : "2894570578",
      "id" : 2894570578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "560822026026618880",
  "geo" : { },
  "id_str" : "560855249012137984",
  "in_reply_to_user_id" : 2894570578,
  "text" : "@ELTMAKERS Make it so :) lk fwd to any write-ups",
  "id" : 560855249012137984,
  "in_reply_to_status_id" : 560822026026618880,
  "created_at" : "2015-01-29 17:41:26 +0000",
  "in_reply_to_screen_name" : "ELTMAKERS",
  "in_reply_to_user_id_str" : "2894570578",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "indices" : [ 3, 14 ],
      "id_str" : "152051625",
      "id" : 152051625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/1pwEgKFEsL",
      "expanded_url" : "http:\/\/corpus.byu.edu\/wikipedia.asp",
      "display_url" : "corpus.byu.edu\/wikipedia.asp"
    } ]
  },
  "geo" : { },
  "id_str" : "560840098552365056",
  "text" : "RT @heatherfro: New Corpus announcement: Wikipedia corpus (http:\/\/t.co\/1pwEgKFEsL) \/ all BYU corpus functionality PLUS the ability to creat\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 65 ],
        "url" : "http:\/\/t.co\/1pwEgKFEsL",
        "expanded_url" : "http:\/\/corpus.byu.edu\/wikipedia.asp",
        "display_url" : "corpus.byu.edu\/wikipedia.asp"
      } ]
    },
    "geo" : { },
    "id_str" : "560829525051719681",
    "text" : "New Corpus announcement: Wikipedia corpus (http:\/\/t.co\/1pwEgKFEsL) \/ all BYU corpus functionality PLUS the ability to create subcorpora!",
    "id" : 560829525051719681,
    "created_at" : "2015-01-29 15:59:13 +0000",
    "user" : {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "protected" : false,
      "id_str" : "152051625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/688767277022494720\/KMrzOBc1_normal.jpg",
      "id" : 152051625,
      "verified" : false
    }
  },
  "id" : 560840098552365056,
  "created_at" : "2015-01-29 16:41:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Middle East Monitor",
      "screen_name" : "MiddleEastMnt",
      "indices" : [ 80, 94 ],
      "id_str" : "81136269",
      "id" : 81136269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/6W8KSGgyT9",
      "expanded_url" : "http:\/\/shar.es\/1bLOX5",
      "display_url" : "shar.es\/1bLOX5"
    } ]
  },
  "geo" : { },
  "id_str" : "560835890780856321",
  "text" : "BDS and Israel's war on Palestinian higher education http:\/\/t.co\/6W8KSGgyT9 via @middleeastmnt",
  "id" : 560835890780856321,
  "created_at" : "2015-01-29 16:24:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/Bnn9Q5ECZT",
      "expanded_url" : "http:\/\/www.counterpunch.org\/2015\/01\/28\/winston-churchill-the-imperial-monster\/#.VMnejrZrhj0.twitter",
      "display_url" : "counterpunch.org\/2015\/01\/28\/win\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "560698269375148032",
  "text" : "Winston Churchill: the Imperial Monster \u00BB CounterPunch: Tells the Facts, Names the Names http:\/\/t.co\/Bnn9Q5ECZT",
  "id" : 560698269375148032,
  "created_at" : "2015-01-29 07:17:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 70, 86 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/WRhTjHAIMx",
      "expanded_url" : "http:\/\/wp.me\/p39fMp-ti",
      "display_url" : "wp.me\/p39fMp-ti"
    } ]
  },
  "geo" : { },
  "id_str" : "560378025871933441",
  "text" : "Air Traffic Control Phraseology (Airspeak) http:\/\/t.co\/WRhTjHAIMx via @wordpressdotcom",
  "id" : 560378025871933441,
  "created_at" : "2015-01-28 10:05:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Lab",
      "screen_name" : "LexicalLab",
      "indices" : [ 3, 14 ],
      "id_str" : "857732892",
      "id" : 857732892
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EFL",
      "indices" : [ 16, 20 ]
    }, {
      "text" : "ELT",
      "indices" : [ 21, 25 ]
    } ],
    "urls" : [ {
      "indices" : [ 126, 140 ],
      "url" : "http:\/\/t.co\/D93fOeSpii",
      "expanded_url" : "http:\/\/www.lexicallab.com\/2015\/01\/exploiting-self-study-phrasal-verb-exercises-in-the-classroom\/",
      "display_url" : "lexicallab.com\/2015\/01\/exploi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "560184796551585792",
  "text" : "RT @LexicalLab: #EFL #ELT New post on Lexical Lab about exploring and exploiting a self-study phrasal verb exercise in class. http:\/\/t.co\/D\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EFL",
        "indices" : [ 0, 4 ]
      }, {
        "text" : "ELT",
        "indices" : [ 5, 9 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/D93fOeSpii",
        "expanded_url" : "http:\/\/www.lexicallab.com\/2015\/01\/exploiting-self-study-phrasal-verb-exercises-in-the-classroom\/",
        "display_url" : "lexicallab.com\/2015\/01\/exploi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "560035173904179200",
    "text" : "#EFL #ELT New post on Lexical Lab about exploring and exploiting a self-study phrasal verb exercise in class. http:\/\/t.co\/D93fOeSpii",
    "id" : 560035173904179200,
    "created_at" : "2015-01-27 11:22:45 +0000",
    "user" : {
      "name" : "Lexical Lab",
      "screen_name" : "LexicalLab",
      "protected" : false,
      "id_str" : "857732892",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/559654844831506432\/F4HWliCf_normal.jpeg",
      "id" : 857732892,
      "verified" : false
    }
  },
  "id" : 560184796551585792,
  "created_at" : "2015-01-27 21:17:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/DeJMHbwhaq",
      "expanded_url" : "http:\/\/www.alternet.org\/watch-chomsky-blasts-american-sniper-and-media-glorifies-it#.VMf5uOar_3Q.twitter",
      "display_url" : "alternet.org\/watch-chomsky-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "560177692671488001",
  "text" : "WATCH: Chomsky Blasts 'American Sniper' and the Media that Glorifies It | Alternet http:\/\/t.co\/DeJMHbwhaq",
  "id" : 560177692671488001,
  "created_at" : "2015-01-27 20:49:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "indices" : [ 3, 18 ],
      "id_str" : "152194866",
      "id" : 152194866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Twitter",
      "indices" : [ 60, 68 ]
    }, {
      "text" : "terrorism",
      "indices" : [ 69, 79 ]
    }, {
      "text" : "Delta",
      "indices" : [ 80, 86 ]
    }, {
      "text" : "SouthWestern",
      "indices" : [ 87, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/eXYzJlmw8E",
      "expanded_url" : "http:\/\/ow.ly\/HZu4q",
      "display_url" : "ow.ly\/HZu4q"
    } ]
  },
  "geo" : { },
  "id_str" : "559963922745556993",
  "text" : "RT @patrickDurusau: Cost To Be A Terrorist Hits Rock Bottom #Twitter #terrorism #Delta #SouthWestern http:\/\/t.co\/eXYzJlmw8E",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Twitter",
        "indices" : [ 40, 48 ]
      }, {
        "text" : "terrorism",
        "indices" : [ 49, 59 ]
      }, {
        "text" : "Delta",
        "indices" : [ 60, 66 ]
      }, {
        "text" : "SouthWestern",
        "indices" : [ 67, 80 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/eXYzJlmw8E",
        "expanded_url" : "http:\/\/ow.ly\/HZu4q",
        "display_url" : "ow.ly\/HZu4q"
      } ]
    },
    "geo" : { },
    "id_str" : "559923990316449792",
    "text" : "Cost To Be A Terrorist Hits Rock Bottom #Twitter #terrorism #Delta #SouthWestern http:\/\/t.co\/eXYzJlmw8E",
    "id" : 559923990316449792,
    "created_at" : "2015-01-27 04:00:56 +0000",
    "user" : {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "protected" : false,
      "id_str" : "152194866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/961579480\/patrick_normal.jpeg",
      "id" : 152194866,
      "verified" : false
    }
  },
  "id" : 559963922745556993,
  "created_at" : "2015-01-27 06:39:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/N3bcIZQJat",
      "expanded_url" : "http:\/\/bit.ly\/15DrJx6",
      "display_url" : "bit.ly\/15DrJx6"
    } ]
  },
  "geo" : { },
  "id_str" : "559854359052566530",
  "text" : "WikiLeaks Slams Google Capitulation to US Government | News | teleSUR http:\/\/t.co\/N3bcIZQJat",
  "id" : 559854359052566530,
  "created_at" : "2015-01-26 23:24:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Pride",
      "screen_name" : "ThomasPride",
      "indices" : [ 111, 123 ],
      "id_str" : "385867551",
      "id" : 385867551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/RnSD65BK1K",
      "expanded_url" : "http:\/\/wp.me\/p1U04a-94h",
      "display_url" : "wp.me\/p1U04a-94h"
    } ]
  },
  "geo" : { },
  "id_str" : "559846497991532545",
  "text" : "Breathtaking German hypocrisy: Germany owes Greece 11 billion euros in unpaid loans http:\/\/t.co\/RnSD65BK1K via @ThomasPride",
  "id" : 559846497991532545,
  "created_at" : "2015-01-26 22:53:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/leDRuC41XM",
      "expanded_url" : "http:\/\/www.informationclearinghouse.info\/article40810.htm#.VMbDfqkvuns.twitter",
      "display_url" : "informationclearinghouse.info\/article40810.h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "559844764804464642",
  "text" : "Hillary Clinton Mocks Putin, Gladly Accepts Jewels from Head-Chopping Saudi Dictator:  Information Clearing House - http:\/\/t.co\/leDRuC41XM",
  "id" : 559844764804464642,
  "created_at" : "2015-01-26 22:46:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Barnes",
      "screen_name" : "markbarnes19",
      "indices" : [ 0, 13 ],
      "id_str" : "33207582",
      "id" : 33207582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/RXFhpDqZw5",
      "expanded_url" : "https:\/\/popcorn.webmaker.org\/en-US\/editor\/",
      "display_url" : "popcorn.webmaker.org\/en-US\/editor\/"
    } ]
  },
  "in_reply_to_status_id_str" : "559710963507937281",
  "geo" : { },
  "id_str" : "559711593664364544",
  "in_reply_to_user_id" : 33207582,
  "text" : "@markbarnes19 yes they are standalone -e.g. popcorn maker https:\/\/t.co\/RXFhpDqZw5",
  "id" : 559711593664364544,
  "in_reply_to_status_id" : 559710963507937281,
  "created_at" : "2015-01-26 13:56:57 +0000",
  "in_reply_to_screen_name" : "markbarnes19",
  "in_reply_to_user_id_str" : "33207582",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2133\u0105h\u0105 B\u0105\u2113i \u0645\u0647\u0627 \u0628\u0627\u0644\u064A",
      "screen_name" : "Bali_Maha",
      "indices" : [ 0, 10 ],
      "id_str" : "1535273520",
      "id" : 1535273520
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edtecheg",
      "indices" : [ 92, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/xmVIyYABO8",
      "expanded_url" : "http:\/\/www.apps4efl.com\/",
      "display_url" : "apps4efl.com"
    }, {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/VLunZwp0xT",
      "expanded_url" : "http:\/\/www.textivate.com\/",
      "display_url" : "textivate.com"
    } ]
  },
  "in_reply_to_status_id_str" : "559704559283875841",
  "geo" : { },
  "id_str" : "559711334032744448",
  "in_reply_to_user_id" : 1535273520,
  "text" : "@Bali_Maha Apps4efl(free) - http:\/\/t.co\/xmVIyYABO8 textivate(paid) - http:\/\/t.co\/VLunZwp0xT #edtecheg",
  "id" : 559711334032744448,
  "in_reply_to_status_id" : 559704559283875841,
  "created_at" : "2015-01-26 13:55:55 +0000",
  "in_reply_to_screen_name" : "Bali_Maha",
  "in_reply_to_user_id_str" : "1535273520",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Barnes",
      "screen_name" : "markbarnes19",
      "indices" : [ 0, 13 ],
      "id_str" : "33207582",
      "id" : 33207582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "559707114219008000",
  "geo" : { },
  "id_str" : "559709047872839681",
  "in_reply_to_user_id" : 33207582,
  "text" : "@markbarnes19 not a replacement but how about mozilla range of webtools such as mozilla popcorn?",
  "id" : 559709047872839681,
  "in_reply_to_status_id" : 559707114219008000,
  "created_at" : "2015-01-26 13:46:50 +0000",
  "in_reply_to_screen_name" : "markbarnes19",
  "in_reply_to_user_id_str" : "33207582",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Field",
      "screen_name" : "John__Field",
      "indices" : [ 90, 102 ],
      "id_str" : "126258726",
      "id" : 126258726
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/mBYVnp61vk",
      "expanded_url" : "http:\/\/wp.me\/p1ZDGy-gb",
      "display_url" : "wp.me\/p1ZDGy-gb"
    } ]
  },
  "geo" : { },
  "id_str" : "559694368161161216",
  "text" : "Personal training accounts - supporting adult skills in France http:\/\/t.co\/mBYVnp61vk via @John__Field",
  "id" : 559694368161161216,
  "created_at" : "2015-01-26 12:48:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharon Hartle",
      "screen_name" : "hartle",
      "indices" : [ 0, 7 ],
      "id_str" : "20324125",
      "id" : 20324125
    }, {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 8, 19 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/ALwqgotsmF",
      "expanded_url" : "http:\/\/www.leeds.ac.uk\/arts\/profile\/20030\/288\/anthony_cowie_",
      "display_url" : "leeds.ac.uk\/arts\/profile\/2\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "559684319212756992",
  "geo" : { },
  "id_str" : "559691497541758976",
  "in_reply_to_user_id" : 20324125,
  "text" : "@hartle @leoselivan hi sorry no not read that paper any good? maybe try contacting Cowie? http:\/\/t.co\/ALwqgotsmF",
  "id" : 559691497541758976,
  "in_reply_to_status_id" : 559684319212756992,
  "created_at" : "2015-01-26 12:37:06 +0000",
  "in_reply_to_screen_name" : "hartle",
  "in_reply_to_user_id_str" : "20324125",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Petrie",
      "screen_name" : "teflgeek",
      "indices" : [ 53, 62 ],
      "id_str" : "305260555",
      "id" : 305260555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/SMVFi9Wx1k",
      "expanded_url" : "http:\/\/wp.me\/p1kzD1-Yv",
      "display_url" : "wp.me\/p1kzD1-Yv"
    } ]
  },
  "geo" : { },
  "id_str" : "559676030383046656",
  "text" : "What is \"good speaking\"?: http:\/\/t.co\/SMVFi9Wx1k via @teflgeek",
  "id" : 559676030383046656,
  "created_at" : "2015-01-26 11:35:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KingAbdullah",
      "indices" : [ 115, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/tGc9Ih61RE",
      "expanded_url" : "http:\/\/johnhilley.blogspot.co.uk\/2015\/01\/disapproval-over-honouring-saudi-despot.html",
      "display_url" : "johnhilley.blogspot.co.uk\/2015\/01\/disapp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "559452952721907714",
  "text" : "RT @johnwhilley: Disapproval over honouring Saudi despot - don't mention West's own tyranny http:\/\/t.co\/tGc9Ih61RE #KingAbdullah",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "KingAbdullah",
        "indices" : [ 98, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/tGc9Ih61RE",
        "expanded_url" : "http:\/\/johnhilley.blogspot.co.uk\/2015\/01\/disapproval-over-honouring-saudi-despot.html",
        "display_url" : "johnhilley.blogspot.co.uk\/2015\/01\/disapp\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "559431895415791618",
    "text" : "Disapproval over honouring Saudi despot - don't mention West's own tyranny http:\/\/t.co\/tGc9Ih61RE #KingAbdullah",
    "id" : 559431895415791618,
    "created_at" : "2015-01-25 19:25:32 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 559452952721907714,
  "created_at" : "2015-01-25 20:49:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Gosztola",
      "screen_name" : "kgosztola",
      "indices" : [ 3, 13 ],
      "id_str" : "15808218",
      "id" : 15808218
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/kgosztola\/status\/558386208280440833\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/GdL0SGztl9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B7_JTChIQAApAVf.png",
      "id_str" : "558386207747751936",
      "id" : 558386207747751936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B7_JTChIQAApAVf.png",
      "sizes" : [ {
        "h" : 242,
        "resize" : "fit",
        "w" : 1009
      }, {
        "h" : 144,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 82,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 242,
        "resize" : "fit",
        "w" : 1009
      } ],
      "display_url" : "pic.twitter.com\/GdL0SGztl9"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "559277843457540096",
  "text" : "RT @kgosztola: Barrett Brown after being sentenced: \"Good news!\" [US govt] now sending me to \"investigate prison-industrial complex\" http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/kgosztola\/status\/558386208280440833\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/GdL0SGztl9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B7_JTChIQAApAVf.png",
        "id_str" : "558386207747751936",
        "id" : 558386207747751936,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B7_JTChIQAApAVf.png",
        "sizes" : [ {
          "h" : 242,
          "resize" : "fit",
          "w" : 1009
        }, {
          "h" : 144,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 82,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 242,
          "resize" : "fit",
          "w" : 1009
        } ],
        "display_url" : "pic.twitter.com\/GdL0SGztl9"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "558386208280440833",
    "text" : "Barrett Brown after being sentenced: \"Good news!\" [US govt] now sending me to \"investigate prison-industrial complex\" http:\/\/t.co\/GdL0SGztl9",
    "id" : 558386208280440833,
    "created_at" : "2015-01-22 22:10:21 +0000",
    "user" : {
      "name" : "Kevin Gosztola",
      "screen_name" : "kgosztola",
      "protected" : false,
      "id_str" : "15808218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/627951363847098369\/ZwlkM7_C_normal.jpg",
      "id" : 15808218,
      "verified" : true
    }
  },
  "id" : 559277843457540096,
  "created_at" : "2015-01-25 09:13:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Citizenfour",
      "indices" : [ 52, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "559022205619937280",
  "text" : "the comprehensive existing survellience reported in #Citizenfour reveals the theatre of recent calls for mass survellience",
  "id" : 559022205619937280,
  "created_at" : "2015-01-24 16:17:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Citizenfour",
      "indices" : [ 0, 12 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "559014369053642752",
  "text" : "#Citizenfour should be seen by all citizens",
  "id" : 559014369053642752,
  "created_at" : "2015-01-24 15:46:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 0, 15 ],
      "id_str" : "285614027",
      "id" : 285614027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "558991243951476737",
  "geo" : { },
  "id_str" : "559014010163826688",
  "in_reply_to_user_id" : 285614027,
  "text" : "@AnthonyTeacher yr welcome, yah commented on post",
  "id" : 559014010163826688,
  "in_reply_to_status_id" : 558991243951476737,
  "created_at" : "2015-01-24 15:45:00 +0000",
  "in_reply_to_screen_name" : "AnthonyTeacher",
  "in_reply_to_user_id_str" : "285614027",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Speech Dudes",
      "screen_name" : "SpeechDudes",
      "indices" : [ 3, 15 ],
      "id_str" : "310919399",
      "id" : 310919399
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "slpbloggers",
      "indices" : [ 82, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/XMwcPZYT7J",
      "expanded_url" : "http:\/\/ow.ly\/HRdLp",
      "display_url" : "ow.ly\/HRdLp"
    } ]
  },
  "geo" : { },
  "id_str" : "558979177794514944",
  "text" : "RT @SpeechDudes: New Dudes blog post: \"State of the Union Address: We Are Family\" #slpbloggers http:\/\/t.co\/XMwcPZYT7J",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "slpbloggers",
        "indices" : [ 65, 77 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/XMwcPZYT7J",
        "expanded_url" : "http:\/\/ow.ly\/HRdLp",
        "display_url" : "ow.ly\/HRdLp"
      } ]
    },
    "geo" : { },
    "id_str" : "558776713195577345",
    "text" : "New Dudes blog post: \"State of the Union Address: We Are Family\" #slpbloggers http:\/\/t.co\/XMwcPZYT7J",
    "id" : 558776713195577345,
    "created_at" : "2015-01-24 00:02:04 +0000",
    "user" : {
      "name" : "Speech Dudes",
      "screen_name" : "SpeechDudes",
      "protected" : false,
      "id_str" : "310919399",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2630404839\/ded339c018067c3300f6e855e18b897b_normal.png",
      "id" : 310919399,
      "verified" : false
    }
  },
  "id" : 558979177794514944,
  "created_at" : "2015-01-24 13:26:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 111, 126 ],
      "id_str" : "285614027",
      "id" : 285614027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/LuQLVbs6xk",
      "expanded_url" : "http:\/\/www.anthonyteacher.com\/blog\/researchbites\/research-bites-take-care-of-your-concordancing-using-corpora-for-self-correction",
      "display_url" : "anthonyteacher.com\/blog\/researchb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "558933794292760576",
  "text" : "Research Bites: Take Care of Your Concordancing - Using Corpora for Self-Correction http:\/\/t.co\/LuQLVbs6xk via @AnthonyTeacher",
  "id" : 558933794292760576,
  "created_at" : "2015-01-24 10:26:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Poole",
      "screen_name" : "RobertEPoole",
      "indices" : [ 0, 13 ],
      "id_str" : "18526186",
      "id" : 18526186
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "558793013757878275",
  "geo" : { },
  "id_str" : "558924194940215296",
  "in_reply_to_user_id" : 18526186,
  "text" : "@RobertEPoole right!? though seems it has teething problems",
  "id" : 558924194940215296,
  "in_reply_to_status_id" : 558793013757878275,
  "created_at" : "2015-01-24 09:48:07 +0000",
  "in_reply_to_screen_name" : "RobertEPoole",
  "in_reply_to_user_id_str" : "18526186",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Citizenfour",
      "indices" : [ 63, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "558773970799849473",
  "text" : "looks like elevation of my jaw is going to be further moved by #Citizenfour",
  "id" : 558773970799849473,
  "created_at" : "2015-01-23 23:51:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpus",
      "indices" : [ 22, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "558769976073408514",
  "text" : "watching the BYU-WIKI #corpus vids i don't think my jaw can drop any lower",
  "id" : 558769976073408514,
  "created_at" : "2015-01-23 23:35:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "558764443283107843",
  "text" : "dang was about to hit the sack...",
  "id" : 558764443283107843,
  "created_at" : "2015-01-23 23:13:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 59, 67 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 68, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/lyM5Rpb5w8",
      "expanded_url" : "http:\/\/youtu.be\/-kzaOgrsvLk?list=PLtNiAqRdUDP5tXOs-LQ1-v_AT0eIpFCDo",
      "display_url" : "youtu.be\/-kzaOgrsvLk?li\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "558763489112502272",
  "text" : "BYU Wikipedia corpus: Overview: http:\/\/t.co\/lyM5Rpb5w8 via @YouTube #corpusmooc",
  "id" : 558763489112502272,
  "created_at" : "2015-01-23 23:09:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "558756518599069698",
  "text" : "wow the create your own corpus feature in wiki byu corpus is outtasight, fast and simple :)",
  "id" : 558756518599069698,
  "created_at" : "2015-01-23 22:41:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpus",
      "indices" : [ 16, 23 ]
    }, {
      "text" : "corpusmooc",
      "indices" : [ 75, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/hsIeof8Lpx",
      "expanded_url" : "http:\/\/corpus.byu.edu\/wiki\/?r=y",
      "display_url" : "corpus.byu.edu\/wiki\/?r=y"
    } ]
  },
  "geo" : { },
  "id_str" : "558754072950751232",
  "text" : "looks like wiki #corpus is live on BYU-COCA site http:\/\/t.co\/hsIeof8Lpx :) #corpusmooc",
  "id" : 558754072950751232,
  "created_at" : "2015-01-23 22:32:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ACLU National",
      "screen_name" : "ACLU",
      "indices" : [ 108, 113 ],
      "id_str" : "13393052",
      "id" : 13393052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/MySLjRIOix",
      "expanded_url" : "https:\/\/www.aclu.org\/blog\/free-speech-national-security-technology-and-liberty\/i-was-arrested-learning-foreign-language-t",
      "display_url" : "aclu.org\/blog\/free-spee\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "558736486129238017",
  "text" : "I Was Arrested for Learning a Foreign Language. Today, I Have Some Closure. --  https:\/\/t.co\/MySLjRIOix via @aclu",
  "id" : 558736486129238017,
  "created_at" : "2015-01-23 21:22:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Caulfield",
      "screen_name" : "holden",
      "indices" : [ 3, 10 ],
      "id_str" : "1912681",
      "id" : 1912681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/1v0KB4EJ5M",
      "expanded_url" : "http:\/\/hapgood.us\/2015\/01\/23\/users\/",
      "display_url" : "hapgood.us\/2015\/01\/23\/use\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "558706722316242944",
  "text" : "RT @holden: \"Users\": http:\/\/t.co\/1v0KB4EJ5M (I thought I gave up provocative rants a few years back, but I guess I had one left in me...)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 9, 31 ],
        "url" : "http:\/\/t.co\/1v0KB4EJ5M",
        "expanded_url" : "http:\/\/hapgood.us\/2015\/01\/23\/users\/",
        "display_url" : "hapgood.us\/2015\/01\/23\/use\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "558704267096121344",
    "text" : "\"Users\": http:\/\/t.co\/1v0KB4EJ5M (I thought I gave up provocative rants a few years back, but I guess I had one left in me...)",
    "id" : 558704267096121344,
    "created_at" : "2015-01-23 19:14:12 +0000",
    "user" : {
      "name" : "Mike Caulfield",
      "screen_name" : "holden",
      "protected" : false,
      "id_str" : "1912681",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/752538301538545665\/mXNoIc4W_normal.jpg",
      "id" : 1912681,
      "verified" : false
    }
  },
  "id" : 558706722316242944,
  "created_at" : "2015-01-23 19:23:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Pride",
      "screen_name" : "ThomasPride",
      "indices" : [ 99, 111 ],
      "id_str" : "385867551",
      "id" : 385867551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/25hn7MgcSk",
      "expanded_url" : "http:\/\/wp.me\/p1U04a-92W",
      "display_url" : "wp.me\/p1U04a-92W"
    } ]
  },
  "geo" : { },
  "id_str" : "558687140293672964",
  "text" : "Double standards flown at half mast across UK on death of King Abdullah http:\/\/t.co\/25hn7MgcSk via @ThomasPride",
  "id" : 558687140293672964,
  "created_at" : "2015-01-23 18:06:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helen Legge",
      "screen_name" : "ITLegge",
      "indices" : [ 0, 8 ],
      "id_str" : "2201561838",
      "id" : 2201561838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "558665424892862464",
  "geo" : { },
  "id_str" : "558686559483224064",
  "in_reply_to_user_id" : 2201561838,
  "text" : "@ITLegge if u have any suggestions to add to bingo let me know :)",
  "id" : 558686559483224064,
  "in_reply_to_status_id" : 558665424892862464,
  "created_at" : "2015-01-23 18:03:50 +0000",
  "in_reply_to_screen_name" : "ITLegge",
  "in_reply_to_user_id_str" : "2201561838",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jo Sayers",
      "screen_name" : "jo_sayers",
      "indices" : [ 0, 10 ],
      "id_str" : "87176766",
      "id" : 87176766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "558663977694425088",
  "geo" : { },
  "id_str" : "558665185238720513",
  "in_reply_to_user_id" : 87176766,
  "text" : "@jo_sayers i guess a better game is to find a sane quote :)",
  "id" : 558665185238720513,
  "in_reply_to_status_id" : 558663977694425088,
  "created_at" : "2015-01-23 16:38:54 +0000",
  "in_reply_to_screen_name" : "jo_sayers",
  "in_reply_to_user_id_str" : "87176766",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jo Sayers",
      "screen_name" : "jo_sayers",
      "indices" : [ 0, 10 ],
      "id_str" : "87176766",
      "id" : 87176766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/iVKuD6mScv",
      "expanded_url" : "http:\/\/elttalkbingo.englishup.me\/newcard.html",
      "display_url" : "elttalkbingo.englishup.me\/newcard.html"
    } ]
  },
  "in_reply_to_status_id_str" : "558633645846855680",
  "geo" : { },
  "id_str" : "558660511869722624",
  "in_reply_to_user_id" : 87176766,
  "text" : "@jo_sayers play some bingo, collect some new tropes for it - http:\/\/t.co\/iVKuD6mScv if all else fails augment your drinking good luck :)",
  "id" : 558660511869722624,
  "in_reply_to_status_id" : 558633645846855680,
  "created_at" : "2015-01-23 16:20:20 +0000",
  "in_reply_to_screen_name" : "jo_sayers",
  "in_reply_to_user_id_str" : "87176766",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "B. the Unbridgeable",
      "screen_name" : "usageguides",
      "indices" : [ 50, 62 ],
      "id_str" : "369478225",
      "id" : 369478225
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/FzteLOd0VT",
      "expanded_url" : "http:\/\/wp.me\/p1PkG7-1W4",
      "display_url" : "wp.me\/p1PkG7-1W4"
    } ]
  },
  "geo" : { },
  "id_str" : "558649642259202048",
  "text" : "The future of English: http:\/\/t.co\/FzteLOd0VT via @usageguides",
  "id" : 558649642259202048,
  "created_at" : "2015-01-23 15:37:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donald Clark",
      "screen_name" : "DonaldClark",
      "indices" : [ 0, 12 ],
      "id_str" : "1632891",
      "id" : 1632891
    }, {
      "name" : "Bett",
      "screen_name" : "Bett_show",
      "indices" : [ 13, 23 ],
      "id_str" : "28354758",
      "id" : 28354758
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "558608161805180928",
  "geo" : { },
  "id_str" : "558629866187522048",
  "in_reply_to_user_id" : 1632891,
  "text" : "@DonaldClark @Bett_show Know yr enemy? :\/",
  "id" : 558629866187522048,
  "in_reply_to_status_id" : 558608161805180928,
  "created_at" : "2015-01-23 14:18:33 +0000",
  "in_reply_to_screen_name" : "DonaldClark",
  "in_reply_to_user_id_str" : "1632891",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/tl2tQYqLty",
      "expanded_url" : "http:\/\/russia-insider.com\/2015\/01\/21\/2608",
      "display_url" : "russia-insider.com\/2015\/01\/21\/2608"
    } ]
  },
  "geo" : { },
  "id_str" : "558616301737091072",
  "text" : "Poroshenko Says 9,000 Russian Troops in Ukraine, High-Tech Invisibility Cloaks Prevent Detection  http:\/\/t.co\/tl2tQYqLty",
  "id" : 558616301737091072,
  "created_at" : "2015-01-23 13:24:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 116, 125 ],
      "id_str" : "121063600",
      "id" : 121063600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/fiIR5IqwnV",
      "expanded_url" : "http:\/\/wp.me\/p28EmH-69",
      "display_url" : "wp.me\/p28EmH-69"
    } ]
  },
  "geo" : { },
  "id_str" : "558592933197524992",
  "text" : "In support of a developmental sequence model of second language acquisition: Ellis, 2015 http:\/\/t.co\/fiIR5IqwnV via @whyshona",
  "id" : 558592933197524992,
  "created_at" : "2015-01-23 11:51:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Lazer",
      "screen_name" : "davidlazer",
      "indices" : [ 3, 14 ],
      "id_str" : "37213193",
      "id" : 37213193
    }, {
      "name" : "Northeastern U.",
      "screen_name" : "Northeastern",
      "indices" : [ 62, 75 ],
      "id_str" : "46477409",
      "id" : 46477409
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 53, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/Vaps8QbqCK",
      "expanded_url" : "http:\/\/www.washingtonpost.com\/blogs\/monkey-cage\/wp\/2015\/01\/21\/the-state-of-the-union-address-in-a-single-figure\/",
      "display_url" : "washingtonpost.com\/blogs\/monkey-c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "558517128396292096",
  "text" : "RT @davidlazer: Nice plot of topic movements through #SOTU by @Northeastern faculty Nick Beauchamp http:\/\/t.co\/Vaps8QbqCK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Northeastern U.",
        "screen_name" : "Northeastern",
        "indices" : [ 46, 59 ],
        "id_str" : "46477409",
        "id" : 46477409
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SOTU",
        "indices" : [ 37, 42 ]
      } ],
      "urls" : [ {
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/Vaps8QbqCK",
        "expanded_url" : "http:\/\/www.washingtonpost.com\/blogs\/monkey-cage\/wp\/2015\/01\/21\/the-state-of-the-union-address-in-a-single-figure\/",
        "display_url" : "washingtonpost.com\/blogs\/monkey-c\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "558315634174734337",
    "text" : "Nice plot of topic movements through #SOTU by @Northeastern faculty Nick Beauchamp http:\/\/t.co\/Vaps8QbqCK",
    "id" : 558315634174734337,
    "created_at" : "2015-01-22 17:29:54 +0000",
    "user" : {
      "name" : "David Lazer",
      "screen_name" : "davidlazer",
      "protected" : false,
      "id_str" : "37213193",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/192936165\/d_lazer_normal.jpg",
      "id" : 37213193,
      "verified" : false
    }
  },
  "id" : 558517128396292096,
  "created_at" : "2015-01-23 06:50:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenn Greenwald",
      "screen_name" : "ggreenwald",
      "indices" : [ 3, 14 ],
      "id_str" : "16076032",
      "id" : 16076032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/nY8Jgp5BTb",
      "expanded_url" : "https:\/\/twitter.com\/BBCBreaking\/status\/558408305241255937",
      "display_url" : "twitter.com\/BBCBreaking\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "558508876203843585",
  "text" : "RT @ggreenwald: Is this satire? I don't believe it is:  https:\/\/t.co\/nY8Jgp5BTb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 63 ],
        "url" : "https:\/\/t.co\/nY8Jgp5BTb",
        "expanded_url" : "https:\/\/twitter.com\/BBCBreaking\/status\/558408305241255937",
        "display_url" : "twitter.com\/BBCBreaking\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "558466407818870787",
    "text" : "Is this satire? I don't believe it is:  https:\/\/t.co\/nY8Jgp5BTb",
    "id" : 558466407818870787,
    "created_at" : "2015-01-23 03:29:02 +0000",
    "user" : {
      "name" : "Glenn Greenwald",
      "screen_name" : "ggreenwald",
      "protected" : false,
      "id_str" : "16076032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/659383028771364869\/G9HHnjiI_normal.jpg",
      "id" : 16076032,
      "verified" : true
    }
  },
  "id" : 558508876203843585,
  "created_at" : "2015-01-23 06:17:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 0, 15 ],
      "id_str" : "285614027",
      "id" : 285614027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "558501770012688387",
  "geo" : { },
  "id_str" : "558503009286905856",
  "in_reply_to_user_id" : 18602422,
  "text" : "@AnthonyTeacher so stuttering helps students with this aspect of reduced vowels, i think but i am learning it at mo so may well be wrong!",
  "id" : 558503009286905856,
  "in_reply_to_status_id" : 558501770012688387,
  "created_at" : "2015-01-23 05:54:28 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 0, 15 ],
      "id_str" : "285614027",
      "id" : 285614027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "558484434086002688",
  "geo" : { },
  "id_str" : "558501770012688387",
  "in_reply_to_user_id" : 285614027,
  "text" : "@AnthonyTeacher  reduced vowels (schwa,schwi,schwu) are not said but result of transition between consonants - terrain\/train, polite\/plight",
  "id" : 558501770012688387,
  "in_reply_to_status_id" : 558484434086002688,
  "created_at" : "2015-01-23 05:49:33 +0000",
  "in_reply_to_screen_name" : "AnthonyTeacher",
  "in_reply_to_user_id_str" : "285614027",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 0, 15 ],
      "id_str" : "285614027",
      "id" : 285614027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "558435717752569856",
  "geo" : { },
  "id_str" : "558437205451223041",
  "in_reply_to_user_id" : 285614027,
  "text" : "@AnthonyTeacher it's tricky to juggle listening to groups speaking!",
  "id" : 558437205451223041,
  "in_reply_to_status_id" : 558435717752569856,
  "created_at" : "2015-01-23 01:32:59 +0000",
  "in_reply_to_screen_name" : "AnthonyTeacher",
  "in_reply_to_user_id_str" : "285614027",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 0, 15 ],
      "id_str" : "285614027",
      "id" : 285614027
    }, {
      "name" : "Nicola Prentis",
      "screen_name" : "NicolaPrentis",
      "indices" : [ 16, 30 ],
      "id_str" : "810667033",
      "id" : 810667033
    }, {
      "name" : "anglophenia",
      "screen_name" : "anglophenia",
      "indices" : [ 31, 43 ],
      "id_str" : "15840139",
      "id" : 15840139
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/7qKmG8z1ui",
      "expanded_url" : "https:\/\/elt.makes.org\/popcorn\/2nog",
      "display_url" : "elt.makes.org\/popcorn\/2nog"
    } ]
  },
  "in_reply_to_status_id_str" : "558434451316023296",
  "geo" : { },
  "id_str" : "558435330026917888",
  "in_reply_to_user_id" : 285614027,
  "text" : "@AnthonyTeacher @NicolaPrentis @anglophenia get em to try the stutter technique https:\/\/t.co\/7qKmG8z1ui",
  "id" : 558435330026917888,
  "in_reply_to_status_id" : 558434451316023296,
  "created_at" : "2015-01-23 01:25:32 +0000",
  "in_reply_to_screen_name" : "AnthonyTeacher",
  "in_reply_to_user_id_str" : "285614027",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Roach",
      "screen_name" : "RoachPeterJ",
      "indices" : [ 0, 12 ],
      "id_str" : "2218138523",
      "id" : 2218138523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/ar8uvamN5K",
      "expanded_url" : "http:\/\/blog.jonudell.net\/2015\/01\/22\/a-federated-wikipedia\/",
      "display_url" : "blog.jonudell.net\/2015\/01\/22\/a-f\u2026"
    }, {
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/19HoEslyfo",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=6GbGBUugz_w",
      "display_url" : "youtube.com\/watch?v=6GbGBU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "558432821443039232",
  "in_reply_to_user_id" : 2218138523,
  "text" : "@RoachPeterJ hi u may be interested in federated wiki to avoid prblems described here http:\/\/t.co\/ar8uvamN5K &amp; c vid https:\/\/t.co\/19HoEslyfo",
  "id" : 558432821443039232,
  "created_at" : "2015-01-23 01:15:34 +0000",
  "in_reply_to_screen_name" : "RoachPeterJ",
  "in_reply_to_user_id_str" : "2218138523",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Knight",
      "screen_name" : "nakanotim",
      "indices" : [ 0, 10 ],
      "id_str" : "295968758",
      "id" : 295968758
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "558270814907531265",
  "geo" : { },
  "id_str" : "558371045552693249",
  "in_reply_to_user_id" : 18602422,
  "text" : "@nakanotim not sure i will actually enter but nice prompt to think about what one could do",
  "id" : 558371045552693249,
  "in_reply_to_status_id" : 558270814907531265,
  "created_at" : "2015-01-22 21:10:05 +0000",
  "in_reply_to_screen_name" : "muranava",
  "in_reply_to_user_id_str" : "18602422",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EVO",
      "indices" : [ 50, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/7qKmG8z1ui",
      "expanded_url" : "https:\/\/elt.makes.org\/popcorn\/2nog",
      "display_url" : "elt.makes.org\/popcorn\/2nog"
    } ]
  },
  "geo" : { },
  "id_str" : "558368436422971393",
  "text" : "trying to get my head round the stutter technique #EVO pron course https:\/\/t.co\/7qKmG8z1ui",
  "id" : 558368436422971393,
  "created_at" : "2015-01-22 20:59:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chia Suan Chong",
      "screen_name" : "chiasuan",
      "indices" : [ 0, 9 ],
      "id_str" : "71588589",
      "id" : 71588589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "558286323774418945",
  "geo" : { },
  "id_str" : "558362480251265025",
  "in_reply_to_user_id" : 71588589,
  "text" : "@chiasuan cheers :)",
  "id" : 558362480251265025,
  "in_reply_to_status_id" : 558286323774418945,
  "created_at" : "2015-01-22 20:36:03 +0000",
  "in_reply_to_screen_name" : "chiasuan",
  "in_reply_to_user_id_str" : "71588589",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/v8PzEdTvKc",
      "expanded_url" : "http:\/\/www.etprofessional.com\/listening-to-students-spoken-language.aspx",
      "display_url" : "etprofessional.com\/listening-to-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "558285829328891905",
  "text" : "Listening to students' spoken language : http:\/\/t.co\/v8PzEdTvKc",
  "id" : 558285829328891905,
  "created_at" : "2015-01-22 15:31:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chia Suan Chong",
      "screen_name" : "chiasuan",
      "indices" : [ 0, 9 ],
      "id_str" : "71588589",
      "id" : 71588589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "558214348645343235",
  "geo" : { },
  "id_str" : "558285662961827840",
  "in_reply_to_user_id" : 71588589,
  "text" : "@chiasuan hi link seems to be broken",
  "id" : 558285662961827840,
  "in_reply_to_status_id" : 558214348645343235,
  "created_at" : "2015-01-22 15:30:49 +0000",
  "in_reply_to_screen_name" : "chiasuan",
  "in_reply_to_user_id_str" : "71588589",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "indices" : [ 47, 62 ],
      "id_str" : "27716419",
      "id" : 27716419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/8WJpF3Hhox",
      "expanded_url" : "https:\/\/www.craigmurray.org.uk\/archives\/2015\/01\/inevitable-payback\/",
      "display_url" : "craigmurray.org.uk\/archives\/2015\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "558280096180867072",
  "text" : "Inevitable Payback https:\/\/t.co\/8WJpF3Hhox via @CraigMurrayOrg",
  "id" : 558280096180867072,
  "created_at" : "2015-01-22 15:08:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Knight",
      "screen_name" : "nakanotim",
      "indices" : [ 0, 10 ],
      "id_str" : "295968758",
      "id" : 295968758
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "558270814907531265",
  "in_reply_to_user_id" : 295968758,
  "text" : "@nakanotim hi are u interested in entering the memrise competition?",
  "id" : 558270814907531265,
  "created_at" : "2015-01-22 14:31:49 +0000",
  "in_reply_to_screen_name" : "nakanotim",
  "in_reply_to_user_id_str" : "295968758",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/cW3Zntz1Ms",
      "expanded_url" : "http:\/\/www.medialens.org\/index.php\/alerts\/alert-archive\/2015\/784-death-by-a-thousand-cuts-earth-enters-the-danger-zone.html",
      "display_url" : "medialens.org\/index.php\/aler\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "558233661552992257",
  "text" : "RT @medialens: Earth's vital signs scream 'red alert'. Meanwhile media coverage of climate and environment has dropped sharply. http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/cW3Zntz1Ms",
        "expanded_url" : "http:\/\/www.medialens.org\/index.php\/alerts\/alert-archive\/2015\/784-death-by-a-thousand-cuts-earth-enters-the-danger-zone.html",
        "display_url" : "medialens.org\/index.php\/aler\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "558208981735596033",
    "text" : "Earth's vital signs scream 'red alert'. Meanwhile media coverage of climate and environment has dropped sharply. http:\/\/t.co\/cW3Zntz1Ms",
    "id" : 558208981735596033,
    "created_at" : "2015-01-22 10:26:06 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 558233661552992257,
  "created_at" : "2015-01-22 12:04:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "humblebrag",
      "indices" : [ 95, 106 ]
    }, {
      "text" : "novelbuzz",
      "indices" : [ 107, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "558232927008751616",
  "text" : "buzz of showing stdt a self-hacked web tool (however hacky!) on par with buzz of a good lesson #humblebrag #novelbuzz",
  "id" : 558232927008751616,
  "created_at" : "2015-01-22 12:01:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "558210859122823168",
  "geo" : { },
  "id_str" : "558222758828867584",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson Nice :) what ya buy?",
  "id" : 558222758828867584,
  "in_reply_to_status_id" : 558210859122823168,
  "created_at" : "2015-01-22 11:20:51 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nic Subtirelu",
      "screen_name" : "linguisticpulse",
      "indices" : [ 3, 19 ],
      "id_str" : "1400748798",
      "id" : 1400748798
    }, {
      "name" : "The Onion",
      "screen_name" : "TheOnion",
      "indices" : [ 63, 72 ],
      "id_str" : "14075928",
      "id" : 14075928
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpuslinguistics",
      "indices" : [ 97, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/igDdR23VJG",
      "expanded_url" : "http:\/\/bit.ly\/1yOIDqd",
      "display_url" : "bit.ly\/1yOIDqd"
    } ]
  },
  "geo" : { },
  "id_str" : "558147768188162048",
  "text" : "RT @linguisticpulse: oh and this. http:\/\/t.co\/igDdR23VJG where @TheOnion parodies text analysis. #corpuslinguistics",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Onion",
        "screen_name" : "TheOnion",
        "indices" : [ 42, 51 ],
        "id_str" : "14075928",
        "id" : 14075928
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpuslinguistics",
        "indices" : [ 76, 94 ]
      } ],
      "urls" : [ {
        "indices" : [ 13, 35 ],
        "url" : "http:\/\/t.co\/igDdR23VJG",
        "expanded_url" : "http:\/\/bit.ly\/1yOIDqd",
        "display_url" : "bit.ly\/1yOIDqd"
      } ]
    },
    "geo" : { },
    "id_str" : "558092564898021377",
    "text" : "oh and this. http:\/\/t.co\/igDdR23VJG where @TheOnion parodies text analysis. #corpuslinguistics",
    "id" : 558092564898021377,
    "created_at" : "2015-01-22 02:43:30 +0000",
    "user" : {
      "name" : "Nic Subtirelu",
      "screen_name" : "linguisticpulse",
      "protected" : false,
      "id_str" : "1400748798",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3609632834\/4ae2ef11e9cffa43e820f3ef7e18b016_normal.jpeg",
      "id" : 1400748798,
      "verified" : false
    }
  },
  "id" : 558147768188162048,
  "created_at" : "2015-01-22 06:22:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mindhacks blog",
      "screen_name" : "mindhacksblog",
      "indices" : [ 55, 69 ],
      "id_str" : "22465084",
      "id" : 22465084
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/6pGlghza7i",
      "expanded_url" : "http:\/\/wp.me\/ptsTD-87e",
      "display_url" : "wp.me\/ptsTD-87e"
    } ]
  },
  "geo" : { },
  "id_str" : "558035795110813697",
  "text" : "pwned by a self-learning AI http:\/\/t.co\/6pGlghza7i via @mindhacksblog",
  "id" : 558035795110813697,
  "created_at" : "2015-01-21 22:57:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Ford",
      "screen_name" : "EdSacredProfane",
      "indices" : [ 0, 16 ],
      "id_str" : "2288627443",
      "id" : 2288627443
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/iVKuD6mScv",
      "expanded_url" : "http:\/\/elttalkbingo.englishup.me\/newcard.html",
      "display_url" : "elttalkbingo.englishup.me\/newcard.html"
    } ]
  },
  "in_reply_to_status_id_str" : "558028486498324482",
  "geo" : { },
  "id_str" : "558031994064732160",
  "in_reply_to_user_id" : 2288627443,
  "text" : "@EdSacredProfane an analogue system in the digital age &gt; one to add to bullshit bingo http:\/\/t.co\/iVKuD6mScv",
  "id" : 558031994064732160,
  "in_reply_to_status_id" : 558028486498324482,
  "created_at" : "2015-01-21 22:42:49 +0000",
  "in_reply_to_screen_name" : "EdSacredProfane",
  "in_reply_to_user_id_str" : "2288627443",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Parise",
      "screen_name" : "peterrenshu",
      "indices" : [ 3, 15 ],
      "id_str" : "631949549",
      "id" : 631949549
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/EvJVbx3IE1",
      "expanded_url" : "http:\/\/vuw.qualtrics.com\/SE\/?SID=SV_3TVmJT8Z4dZOZhj",
      "display_url" : "vuw.qualtrics.com\/SE\/?SID=SV_3TV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "557943775411331072",
  "text" : "RT @peterrenshu: Calling all language teachers! Please take a concordance survey  from Victoria University of Wellington, New Zealand http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/EvJVbx3IE1",
        "expanded_url" : "http:\/\/vuw.qualtrics.com\/SE\/?SID=SV_3TVmJT8Z4dZOZhj",
        "display_url" : "vuw.qualtrics.com\/SE\/?SID=SV_3TV\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "557900412938768384",
    "text" : "Calling all language teachers! Please take a concordance survey  from Victoria University of Wellington, New Zealand http:\/\/t.co\/EvJVbx3IE1",
    "id" : 557900412938768384,
    "created_at" : "2015-01-21 13:59:58 +0000",
    "user" : {
      "name" : "Peter Parise",
      "screen_name" : "peterrenshu",
      "protected" : false,
      "id_str" : "631949549",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2390141891\/azxwx57ppddic0hnd26k_normal.jpeg",
      "id" : 631949549,
      "verified" : false
    }
  },
  "id" : 557943775411331072,
  "created_at" : "2015-01-21 16:52:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Schmidt",
      "screen_name" : "benmschmidt",
      "indices" : [ 3, 15 ],
      "id_str" : "222618390",
      "id" : 222618390
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/benmschmidt\/status\/557721106564792320\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/Dj0FlGnIz0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B71sY5_CcAAngM9.png",
      "id_str" : "557721104001691648",
      "id" : 557721104001691648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B71sY5_CcAAngM9.png",
      "sizes" : [ {
        "h" : 608,
        "resize" : "fit",
        "w" : 963
      }, {
        "h" : 608,
        "resize" : "fit",
        "w" : 963
      }, {
        "h" : 215,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 379,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/Dj0FlGnIz0"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/eAUHSqo4yk",
      "expanded_url" : "http:\/\/benschmidt.org\/poli\/2015-SOTU",
      "display_url" : "benschmidt.org\/poli\/2015-SOTU"
    } ]
  },
  "geo" : { },
  "id_str" : "557838852778655744",
  "text" : "RT @benmschmidt: Brand-new, indispensable SOTU interactive: the 2015 text in context of every past speech.\nhttp:\/\/t.co\/eAUHSqo4yk http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/benmschmidt\/status\/557721106564792320\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/Dj0FlGnIz0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B71sY5_CcAAngM9.png",
        "id_str" : "557721104001691648",
        "id" : 557721104001691648,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B71sY5_CcAAngM9.png",
        "sizes" : [ {
          "h" : 608,
          "resize" : "fit",
          "w" : 963
        }, {
          "h" : 608,
          "resize" : "fit",
          "w" : 963
        }, {
          "h" : 215,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 379,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/Dj0FlGnIz0"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/eAUHSqo4yk",
        "expanded_url" : "http:\/\/benschmidt.org\/poli\/2015-SOTU",
        "display_url" : "benschmidt.org\/poli\/2015-SOTU"
      } ]
    },
    "geo" : { },
    "id_str" : "557721106564792320",
    "text" : "Brand-new, indispensable SOTU interactive: the 2015 text in context of every past speech.\nhttp:\/\/t.co\/eAUHSqo4yk http:\/\/t.co\/Dj0FlGnIz0",
    "id" : 557721106564792320,
    "created_at" : "2015-01-21 02:07:28 +0000",
    "user" : {
      "name" : "Benjamin Schmidt",
      "screen_name" : "benmschmidt",
      "protected" : false,
      "id_str" : "222618390",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1181931710\/Screen_shot_2010-12-03_at_7.00.07_PM_normal.png",
      "id" : 222618390,
      "verified" : false
    }
  },
  "id" : 557838852778655744,
  "created_at" : "2015-01-21 09:55:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "European Tribune",
      "screen_name" : "EuropeanTribune",
      "indices" : [ 63, 79 ],
      "id_str" : "568326306",
      "id" : 568326306
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/CT9wklqVdZ",
      "expanded_url" : "http:\/\/www.eurotrib.com\/story\/2015\/1\/16\/72647\/9494",
      "display_url" : "eurotrib.com\/story\/2015\/1\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "557834290399309825",
  "text" : "Time for the ECB Board to be sacked http:\/\/t.co\/CT9wklqVdZ via @EuropeanTribune",
  "id" : 557834290399309825,
  "created_at" : "2015-01-21 09:37:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 54, 62 ]
    }, {
      "text" : "eltchinwag",
      "indices" : [ 63, 74 ]
    }, {
      "text" : "tleap",
      "indices" : [ 75, 81 ]
    }, {
      "text" : "keltchat",
      "indices" : [ 82, 91 ]
    }, {
      "text" : "auselt",
      "indices" : [ 92, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/g1DEJ1D8c1",
      "expanded_url" : "http:\/\/www.memrise.com\/prize\/",
      "display_url" : "memrise.com\/prize\/"
    } ]
  },
  "geo" : { },
  "id_str" : "557525589843013632",
  "text" : "any peeps fancy a go at this? http:\/\/t.co\/g1DEJ1D8c1  #eltchat #eltchinwag #tleap #keltchat #auselt",
  "id" : 557525589843013632,
  "created_at" : "2015-01-20 13:10:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sandy Millin",
      "screen_name" : "sandymillin",
      "indices" : [ 0, 12 ],
      "id_str" : "144236944",
      "id" : 144236944
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "557287767215206400",
  "geo" : { },
  "id_str" : "557299500457676800",
  "in_reply_to_user_id" : 144236944,
  "text" : "@sandymillin a pleasure :)",
  "id" : 557299500457676800,
  "in_reply_to_status_id" : 557287767215206400,
  "created_at" : "2015-01-19 22:12:09 +0000",
  "in_reply_to_screen_name" : "sandymillin",
  "in_reply_to_user_id_str" : "144236944",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Cook",
      "screen_name" : "idc74",
      "indices" : [ 3, 9 ],
      "id_str" : "290521216",
      "id" : 290521216
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELT",
      "indices" : [ 83, 87 ]
    }, {
      "text" : "EFL",
      "indices" : [ 88, 92 ]
    }, {
      "text" : "TESOL",
      "indices" : [ 93, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/HIimT53J1U",
      "expanded_url" : "http:\/\/www.cambridge.org\/elt\/blog\/2015\/01\/interview-penny-ur-part\/",
      "display_url" : "cambridge.org\/elt\/blog\/2015\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "557281105137917952",
  "text" : "RT @idc74: An interview with Penny Ur: \"More has stayed the same than has changed\" #ELT #EFL #TESOL http:\/\/t.co\/HIimT53J1U",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELT",
        "indices" : [ 72, 76 ]
      }, {
        "text" : "EFL",
        "indices" : [ 77, 81 ]
      }, {
        "text" : "TESOL",
        "indices" : [ 82, 88 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/HIimT53J1U",
        "expanded_url" : "http:\/\/www.cambridge.org\/elt\/blog\/2015\/01\/interview-penny-ur-part\/",
        "display_url" : "cambridge.org\/elt\/blog\/2015\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "557280412591206400",
    "text" : "An interview with Penny Ur: \"More has stayed the same than has changed\" #ELT #EFL #TESOL http:\/\/t.co\/HIimT53J1U",
    "id" : 557280412591206400,
    "created_at" : "2015-01-19 20:56:18 +0000",
    "user" : {
      "name" : "Ian Cook",
      "screen_name" : "idc74",
      "protected" : false,
      "id_str" : "290521216",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/716598365597736961\/kLEOaMTk_normal.jpg",
      "id" : 290521216,
      "verified" : false
    }
  },
  "id" : 557281105137917952,
  "created_at" : "2015-01-19 20:59:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Downes",
      "screen_name" : "oldaily",
      "indices" : [ 3, 11 ],
      "id_str" : "96139902",
      "id" : 96139902
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oldaily",
      "indices" : [ 27, 35 ]
    } ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/4F25Lp8Lwu",
      "expanded_url" : "http:\/\/www.downes.ca\/post\/63315",
      "display_url" : "downes.ca\/post\/63315"
    } ]
  },
  "geo" : { },
  "id_str" : "557280633769435136",
  "text" : "RT @oldaily: Tweeps 2 OPML #oldaily http:\/\/t.co\/4F25Lp8Lwu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.downes.ca\" rel=\"nofollow\"\u003EOLDaily\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "oldaily",
        "indices" : [ 14, 22 ]
      } ],
      "urls" : [ {
        "indices" : [ 23, 45 ],
        "url" : "http:\/\/t.co\/4F25Lp8Lwu",
        "expanded_url" : "http:\/\/www.downes.ca\/post\/63315",
        "display_url" : "downes.ca\/post\/63315"
      } ]
    },
    "geo" : { },
    "id_str" : "557255642142887936",
    "text" : "Tweeps 2 OPML #oldaily http:\/\/t.co\/4F25Lp8Lwu",
    "id" : 557255642142887936,
    "created_at" : "2015-01-19 19:17:53 +0000",
    "user" : {
      "name" : "Stephen Downes",
      "screen_name" : "oldaily",
      "protected" : false,
      "id_str" : "96139902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000106238229\/f8a550530e001b52581340d3e3d8e60c_normal.jpeg",
      "id" : 96139902,
      "verified" : false
    }
  },
  "id" : 557280633769435136,
  "created_at" : "2015-01-19 20:57:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Schmidt",
      "screen_name" : "benmschmidt",
      "indices" : [ 3, 15 ],
      "id_str" : "222618390",
      "id" : 222618390
    }, {
      "name" : "Mitch Fraas",
      "screen_name" : "MitchFraas",
      "indices" : [ 74, 85 ],
      "id_str" : "613029578",
      "id" : 613029578
    }, {
      "name" : "Yoni Appelbaum",
      "screen_name" : "YAppelbaum",
      "indices" : [ 91, 102 ],
      "id_str" : "269911034",
      "id" : 269911034
    }, {
      "name" : "The Atlantic",
      "screen_name" : "TheAtlantic",
      "indices" : [ 113, 125 ],
      "id_str" : "35773039",
      "id" : 35773039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/5NFSyEY5Hf",
      "expanded_url" : "http:\/\/www.theatlantic.com\/features\/archive\/2015\/01\/the-language-of-the-state-of-the-union\/384575\/",
      "display_url" : "theatlantic.com\/features\/archi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "557271878180823040",
  "text" : "RT @benmschmidt: Explore the words of past State of the Unions: by me and @MitchFraas, and @YAppelbaum and other @TheAtlantic staff. http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mitch Fraas",
        "screen_name" : "MitchFraas",
        "indices" : [ 57, 68 ],
        "id_str" : "613029578",
        "id" : 613029578
      }, {
        "name" : "Yoni Appelbaum",
        "screen_name" : "YAppelbaum",
        "indices" : [ 74, 85 ],
        "id_str" : "269911034",
        "id" : 269911034
      }, {
        "name" : "The Atlantic",
        "screen_name" : "TheAtlantic",
        "indices" : [ 96, 108 ],
        "id_str" : "35773039",
        "id" : 35773039
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/5NFSyEY5Hf",
        "expanded_url" : "http:\/\/www.theatlantic.com\/features\/archive\/2015\/01\/the-language-of-the-state-of-the-union\/384575\/",
        "display_url" : "theatlantic.com\/features\/archi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "557268402839244800",
    "text" : "Explore the words of past State of the Unions: by me and @MitchFraas, and @YAppelbaum and other @TheAtlantic staff. http:\/\/t.co\/5NFSyEY5Hf",
    "id" : 557268402839244800,
    "created_at" : "2015-01-19 20:08:35 +0000",
    "user" : {
      "name" : "Benjamin Schmidt",
      "screen_name" : "benmschmidt",
      "protected" : false,
      "id_str" : "222618390",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1181931710\/Screen_shot_2010-12-03_at_7.00.07_PM_normal.png",
      "id" : 222618390,
      "verified" : false
    }
  },
  "id" : 557271878180823040,
  "created_at" : "2015-01-19 20:22:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Electronic Intifada",
      "screen_name" : "intifada",
      "indices" : [ 76, 85 ],
      "id_str" : "6721522",
      "id" : 6721522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/67QFiq0EFA",
      "expanded_url" : "http:\/\/electronicintifada.net\/blogs\/ali-abunimah\/france-begins-jailing-people-ironic-comments",
      "display_url" : "electronicintifada.net\/blogs\/ali-abun\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "557216663058530304",
  "text" : "France begins jailing people for ironic comments http:\/\/t.co\/67QFiq0EFA via @intifada",
  "id" : 557216663058530304,
  "created_at" : "2015-01-19 16:42:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MiLL",
      "screen_name" : "MiLL_Network",
      "indices" : [ 3, 16 ],
      "id_str" : "2976617727",
      "id" : 2976617727
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/AHOcqjClRC",
      "expanded_url" : "http:\/\/theconversation.com\/me-myself-or-i-why-its-hard-to-use-pronouns-in-the-right-way-35860",
      "display_url" : "theconversation.com\/me-myself-or-i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "557146482600857600",
  "text" : "RT @MiLL_Network: Me, myself or I? MiLL co-director Roumyana Slabakova discusses problems that language learners face with pronouns - http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/AHOcqjClRC",
        "expanded_url" : "http:\/\/theconversation.com\/me-myself-or-i-why-its-hard-to-use-pronouns-in-the-right-way-35860",
        "display_url" : "theconversation.com\/me-myself-or-i\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "557144866472603651",
    "text" : "Me, myself or I? MiLL co-director Roumyana Slabakova discusses problems that language learners face with pronouns - http:\/\/t.co\/AHOcqjClRC",
    "id" : 557144866472603651,
    "created_at" : "2015-01-19 11:57:42 +0000",
    "user" : {
      "name" : "MiLL",
      "screen_name" : "MiLL_Network",
      "protected" : false,
      "id_str" : "2976617727",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/555032763338743809\/hmErud48_normal.jpeg",
      "id" : 2976617727,
      "verified" : false
    }
  },
  "id" : 557146482600857600,
  "created_at" : "2015-01-19 12:04:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sandy Millin",
      "screen_name" : "sandymillin",
      "indices" : [ 80, 92 ],
      "id_str" : "144236944",
      "id" : 144236944
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/3TRvGRF8sr",
      "expanded_url" : "http:\/\/wp.me\/p18yiK-XN",
      "display_url" : "wp.me\/p18yiK-XN"
    } ]
  },
  "geo" : { },
  "id_str" : "557136569451442176",
  "text" : "Arabic students and spelling (IATEFL Harrogate 2014) http:\/\/t.co\/3TRvGRF8sr via @sandymillin",
  "id" : 557136569451442176,
  "created_at" : "2015-01-19 11:24:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 0, 11 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/8IvLG6I21b",
      "expanded_url" : "http:\/\/www.lextutor.ca\/freq\/train\/research.html",
      "display_url" : "lextutor.ca\/freq\/train\/res\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "557117558030352384",
  "geo" : { },
  "id_str" : "557119388307185664",
  "in_reply_to_user_id" : 88202140,
  "text" : "@hughdellar u need this link i think http:\/\/t.co\/8IvLG6I21b ?",
  "id" : 557119388307185664,
  "in_reply_to_status_id" : 557117558030352384,
  "created_at" : "2015-01-19 10:16:27 +0000",
  "in_reply_to_screen_name" : "hughdellar",
  "in_reply_to_user_id_str" : "88202140",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 0, 11 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "557117558030352384",
  "geo" : { },
  "id_str" : "557117954631147520",
  "in_reply_to_user_id" : 88202140,
  "text" : "@hughdellar the first link to McCrostie article links to Lextutor trainer not article",
  "id" : 557117954631147520,
  "in_reply_to_status_id" : 557117558030352384,
  "created_at" : "2015-01-19 10:10:45 +0000",
  "in_reply_to_screen_name" : "hughdellar",
  "in_reply_to_user_id_str" : "88202140",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 0, 11 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "557115610795364352",
  "geo" : { },
  "id_str" : "557117257974050816",
  "in_reply_to_user_id" : 88202140,
  "text" : "@hughdellar hi McCrostie link pointing to lextutor freq trainer",
  "id" : 557117257974050816,
  "in_reply_to_status_id" : 557115610795364352,
  "created_at" : "2015-01-19 10:07:59 +0000",
  "in_reply_to_screen_name" : "hughdellar",
  "in_reply_to_user_id_str" : "88202140",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 3, 14 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EFL",
      "indices" : [ 16, 20 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/85mhNcLOXb",
      "expanded_url" : "http:\/\/www.lexicallab.com\/2014\/11\/vocabulary-choice-test-post\/",
      "display_url" : "lexicallab.com\/2014\/11\/vocabu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "557117151493230592",
  "text" : "RT @hughdellar: #EFL Our first proper blog post over at our new website. Some thoughts on word frequency and availability bias: http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EFL",
        "indices" : [ 0, 4 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/85mhNcLOXb",
        "expanded_url" : "http:\/\/www.lexicallab.com\/2014\/11\/vocabulary-choice-test-post\/",
        "display_url" : "lexicallab.com\/2014\/11\/vocabu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "557115610795364352",
    "text" : "#EFL Our first proper blog post over at our new website. Some thoughts on word frequency and availability bias: http:\/\/t.co\/85mhNcLOXb",
    "id" : 557115610795364352,
    "created_at" : "2015-01-19 10:01:26 +0000",
    "user" : {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "protected" : false,
      "id_str" : "88202140",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2040881292\/Hugh_Dellar_photo_normal.jpg",
      "id" : 88202140,
      "verified" : false
    }
  },
  "id" : 557117151493230592,
  "created_at" : "2015-01-19 10:07:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 0, 9 ],
      "id_str" : "121063600",
      "id" : 121063600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "557106356323631104",
  "geo" : { },
  "id_str" : "557107462885883904",
  "in_reply_to_user_id" : 121063600,
  "text" : "@whyshona it's turning out to be one of the best online courses i have taken but that may be due to my initial ignorance as well :\/",
  "id" : 557107462885883904,
  "in_reply_to_status_id" : 557106356323631104,
  "created_at" : "2015-01-19 09:29:04 +0000",
  "in_reply_to_screen_name" : "whyshona",
  "in_reply_to_user_id_str" : "121063600",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Jordan",
      "screen_name" : "GeoffreyJordan",
      "indices" : [ 32, 47 ],
      "id_str" : "334332424",
      "id" : 334332424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 27 ],
      "url" : "http:\/\/t.co\/MG5pqNAgiP",
      "expanded_url" : "http:\/\/wp.me\/p3qkCB-13P",
      "display_url" : "wp.me\/p3qkCB-13P"
    } ]
  },
  "geo" : { },
  "id_str" : "557107140675248128",
  "text" : "CALL http:\/\/t.co\/MG5pqNAgiP via @GeoffreyJordan",
  "id" : 557107140675248128,
  "created_at" : "2015-01-19 09:27:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dayle Major",
      "screen_name" : "daylemajor",
      "indices" : [ 0, 11 ],
      "id_str" : "10052752",
      "id" : 10052752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "557106150634958848",
  "in_reply_to_user_id" : 10052752,
  "text" : "@daylemajor thx for RT :)",
  "id" : 557106150634958848,
  "created_at" : "2015-01-19 09:23:51 +0000",
  "in_reply_to_screen_name" : "daylemajor",
  "in_reply_to_user_id_str" : "10052752",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 0, 9 ],
      "id_str" : "121063600",
      "id" : 121063600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "557085134147825664",
  "geo" : { },
  "id_str" : "557106084700512256",
  "in_reply_to_user_id" : 121063600,
  "text" : "@whyshona thanks for sharing Shona :)",
  "id" : 557106084700512256,
  "in_reply_to_status_id" : 557085134147825664,
  "created_at" : "2015-01-19 09:23:35 +0000",
  "in_reply_to_screen_name" : "whyshona",
  "in_reply_to_user_id_str" : "121063600",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/1XWExHTyJK",
      "expanded_url" : "http:\/\/linguafrankly.blogspot.com\/2015\/01\/shooting-my-mouth-off.html?spref=tw",
      "display_url" : "linguafrankly.blogspot.com\/2015\/01\/shooti\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "557105606155587584",
  "text" : "Lingua Frankly: Shooting my mouth off... http:\/\/t.co\/1XWExHTyJK",
  "id" : 557105606155587584,
  "created_at" : "2015-01-19 09:21:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rania Khalek",
      "screen_name" : "RaniaKhalek",
      "indices" : [ 127, 139 ],
      "id_str" : "37501003",
      "id" : 37501003
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/KQNeukokyT",
      "expanded_url" : "https:\/\/storify.com\/RaniaKhalek\/american-sniper-chris-kyle-in-his-own-words",
      "display_url" : "storify.com\/RaniaKhalek\/am\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "556934775257440258",
  "text" : "'American Sniper' is dangerous propaganda that sanitizes a mass killer &amp; rewrites the Iraq war https:\/\/t.co\/KQNeukokyT via @raniakhalek",
  "id" : 556934775257440258,
  "created_at" : "2015-01-18 22:02:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Harbinson",
      "screen_name" : "DavidHarbinson",
      "indices" : [ 3, 18 ],
      "id_str" : "853078675",
      "id" : 853078675
    }, {
      "name" : "Peter Roach",
      "screen_name" : "RoachPeterJ",
      "indices" : [ 49, 61 ],
      "id_str" : "2218138523",
      "id" : 2218138523
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mustread",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/ofxcVItyPa",
      "expanded_url" : "http:\/\/www.peterroach.net\/blog",
      "display_url" : "peterroach.net\/blog"
    } ]
  },
  "geo" : { },
  "id_str" : "556780556252610560",
  "text" : "RT @DavidHarbinson: Fascinating new(ish) blog by @RoachPeterJ on how he's trying to edit Wikipedia's pages on phonetics http:\/\/t.co\/ofxcVIt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Peter Roach",
        "screen_name" : "RoachPeterJ",
        "indices" : [ 29, 41 ],
        "id_str" : "2218138523",
        "id" : 2218138523
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "mustread",
        "indices" : [ 123, 132 ]
      } ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/ofxcVItyPa",
        "expanded_url" : "http:\/\/www.peterroach.net\/blog",
        "display_url" : "peterroach.net\/blog"
      } ]
    },
    "geo" : { },
    "id_str" : "556779104943341568",
    "text" : "Fascinating new(ish) blog by @RoachPeterJ on how he's trying to edit Wikipedia's pages on phonetics http:\/\/t.co\/ofxcVItyPa #mustread",
    "id" : 556779104943341568,
    "created_at" : "2015-01-18 11:44:17 +0000",
    "user" : {
      "name" : "David Harbinson",
      "screen_name" : "DavidHarbinson",
      "protected" : false,
      "id_str" : "853078675",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/524830685643538432\/NdyDn_ux_normal.jpeg",
      "id" : 853078675,
      "verified" : false
    }
  },
  "id" : 556780556252610560,
  "created_at" : "2015-01-18 11:50:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EFF",
      "screen_name" : "EFF",
      "indices" : [ 79, 83 ],
      "id_str" : "4816",
      "id" : 4816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/AmPUtLcC5E",
      "expanded_url" : "https:\/\/www.eff.org\/deeplinks\/2015\/01\/security-not-crime-unless-youre-anarchist",
      "display_url" : "eff.org\/deeplinks\/2015\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "556780073878290432",
  "text" : "Security is Not a Crime\u2014Unless You're an Anarchist https:\/\/t.co\/AmPUtLcC5E via @EFF",
  "id" : 556780073878290432,
  "created_at" : "2015-01-18 11:48:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth Anne",
      "screen_name" : "eannegrenoble",
      "indices" : [ 0, 14 ],
      "id_str" : "19869781",
      "id" : 19869781
    }, {
      "name" : "umasslinguistics",
      "screen_name" : "umasslinguistic",
      "indices" : [ 34, 50 ],
      "id_str" : "149239362",
      "id" : 149239362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "556386409112952832",
  "geo" : { },
  "id_str" : "556389066586206208",
  "in_reply_to_user_id" : 19869781,
  "text" : "@eannegrenoble hi thx but dues to @umasslinguistic for this find :)",
  "id" : 556389066586206208,
  "in_reply_to_status_id" : 556386409112952832,
  "created_at" : "2015-01-17 09:54:25 +0000",
  "in_reply_to_screen_name" : "eannegrenoble",
  "in_reply_to_user_id_str" : "19869781",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Pride",
      "screen_name" : "ThomasPride",
      "indices" : [ 114, 126 ],
      "id_str" : "385867551",
      "id" : 385867551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/i17x3jt4Lm",
      "expanded_url" : "http:\/\/wp.me\/p1U04a-8Zf",
      "display_url" : "wp.me\/p1U04a-8Zf"
    } ]
  },
  "geo" : { },
  "id_str" : "556385457148526593",
  "text" : "UK contract to help train the Saudi Prison Service with their floggings and beheadings http:\/\/t.co\/i17x3jt4Lm via @ThomasPride",
  "id" : 556385457148526593,
  "created_at" : "2015-01-17 09:40:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/g1KCy9gEQg",
      "expanded_url" : "http:\/\/papers.ssrn.com\/sol3\/papers.cfm?abstract_id=1899287",
      "display_url" : "papers.ssrn.com\/sol3\/papers.cf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "556363755177926656",
  "text" : "Austerity and Anarchy: Budget Cuts and Social Unrest in Europe, 1919-2008 http:\/\/t.co\/g1KCy9gEQg",
  "id" : 556363755177926656,
  "created_at" : "2015-01-17 08:13:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2133\u0105h\u0105 B\u0105\u2113i \u0645\u0647\u0627 \u0628\u0627\u0644\u064A",
      "screen_name" : "Bali_Maha",
      "indices" : [ 3, 13 ],
      "id_str" : "1535273520",
      "id" : 1535273520
    }, {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 66, 80 ],
      "id_str" : "25388528",
      "id" : 25388528
    }, {
      "name" : "Mike Caulfield",
      "screen_name" : "holden",
      "indices" : [ 85, 92 ],
      "id_str" : "1912681",
      "id" : 1912681
    }, {
      "name" : "David A. Hale",
      "screen_name" : "_daveh70",
      "indices" : [ 117, 126 ],
      "id_str" : "1272185491",
      "id" : 1272185491
    }, {
      "name" : "Greg McVerry",
      "screen_name" : "jgmac1106",
      "indices" : [ 127, 137 ],
      "id_str" : "27620289",
      "id" : 27620289
    }, {
      "name" : "Keith Hamon",
      "screen_name" : "kwhamon",
      "indices" : [ 139, 140 ],
      "id_str" : "7971132",
      "id" : 7971132
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fedwiki",
      "indices" : [ 24, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/FaTzJtH8zI",
      "expanded_url" : "http:\/\/hapgood.us\/2015\/01\/16\/a-fedwiki-happening-on-teaching-machines-featuring-audrey-watters\/",
      "display_url" : "hapgood.us\/2015\/01\/16\/a-f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "556356145334743040",
  "text" : "RT @Bali_Maha: Upcoming #fedwiki happening on teaching machines w @audreywatters via @holden \nhttp:\/\/t.co\/FaTzJtH8zI @_daveh70 @jgmac1106 @\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Audrey Watters",
        "screen_name" : "audreywatters",
        "indices" : [ 51, 65 ],
        "id_str" : "25388528",
        "id" : 25388528
      }, {
        "name" : "Mike Caulfield",
        "screen_name" : "holden",
        "indices" : [ 70, 77 ],
        "id_str" : "1912681",
        "id" : 1912681
      }, {
        "name" : "David A. Hale",
        "screen_name" : "_daveh70",
        "indices" : [ 102, 111 ],
        "id_str" : "1272185491",
        "id" : 1272185491
      }, {
        "name" : "Greg McVerry",
        "screen_name" : "jgmac1106",
        "indices" : [ 112, 122 ],
        "id_str" : "27620289",
        "id" : 27620289
      }, {
        "name" : "Keith Hamon",
        "screen_name" : "kwhamon",
        "indices" : [ 123, 131 ],
        "id_str" : "7971132",
        "id" : 7971132
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fedwiki",
        "indices" : [ 9, 17 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/FaTzJtH8zI",
        "expanded_url" : "http:\/\/hapgood.us\/2015\/01\/16\/a-fedwiki-happening-on-teaching-machines-featuring-audrey-watters\/",
        "display_url" : "hapgood.us\/2015\/01\/16\/a-f\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "556352838105055233",
    "text" : "Upcoming #fedwiki happening on teaching machines w @audreywatters via @holden \nhttp:\/\/t.co\/FaTzJtH8zI @_daveh70 @jgmac1106 @kwhamon",
    "id" : 556352838105055233,
    "created_at" : "2015-01-17 07:30:27 +0000",
    "user" : {
      "name" : "\u2133\u0105h\u0105 B\u0105\u2113i \u0645\u0647\u0627 \u0628\u0627\u0644\u064A",
      "screen_name" : "Bali_Maha",
      "protected" : false,
      "id_str" : "1535273520",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/523419361185234944\/kWBLJiqq_normal.jpeg",
      "id" : 1535273520,
      "verified" : false
    }
  },
  "id" : 556356145334743040,
  "created_at" : "2015-01-17 07:43:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/0bBg16dgWo",
      "expanded_url" : "http:\/\/www.bbc.com\/news\/blogs-magazine-monitor-30848303",
      "display_url" : "bbc.com\/news\/blogs-mag\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "556170323796959232",
  "text" : "BBC News - How to say: Xiaomi http:\/\/t.co\/0bBg16dgWo",
  "id" : 556170323796959232,
  "created_at" : "2015-01-16 19:25:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Read",
      "screen_name" : "dreadnought001",
      "indices" : [ 0, 15 ],
      "id_str" : "83207734",
      "id" : 83207734
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "556167096531697664",
  "geo" : { },
  "id_str" : "556167334734602240",
  "in_reply_to_user_id" : 83207734,
  "text" : "@dreadnought001 nice cheers",
  "id" : 556167334734602240,
  "in_reply_to_status_id" : 556167096531697664,
  "created_at" : "2015-01-16 19:13:20 +0000",
  "in_reply_to_screen_name" : "dreadnought001",
  "in_reply_to_user_id_str" : "83207734",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Read",
      "screen_name" : "dreadnought001",
      "indices" : [ 0, 15 ],
      "id_str" : "83207734",
      "id" : 83207734
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "556163480848695296",
  "in_reply_to_user_id" : 83207734,
  "text" : "@dreadnought001 hi will u be putting up webinar recordings?",
  "id" : 556163480848695296,
  "created_at" : "2015-01-16 18:58:01 +0000",
  "in_reply_to_screen_name" : "dreadnought001",
  "in_reply_to_user_id_str" : "83207734",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fZNbqJySi0",
      "expanded_url" : "http:\/\/linguafrankly.blogspot.com\/2015\/01\/duolingo-web-20-free-labour-and-power.html",
      "display_url" : "linguafrankly.blogspot.com\/2015\/01\/duolin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "556132203084939264",
  "text" : "http:\/\/t.co\/fZNbqJySi0 Duolingo: Web 2.0, free labour and the power of ignorance",
  "id" : 556132203084939264,
  "created_at" : "2015-01-16 16:53:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Read",
      "screen_name" : "dreadnought001",
      "indices" : [ 3, 18 ],
      "id_str" : "83207734",
      "id" : 83207734
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapcultures15",
      "indices" : [ 20, 34 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 127, 135 ]
    }, {
      "text" : "eapchat",
      "indices" : [ 136, 140 ]
    }, {
      "text" : "efl",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "eap",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/7r0ieGBplT",
      "expanded_url" : "http:\/\/goo.gl\/MS5cis",
      "display_url" : "goo.gl\/MS5cis"
    } ]
  },
  "geo" : { },
  "id_str" : "556041922448719872",
  "text" : "RT @dreadnought001: #eapcultures15 2nd day of free online EAP conference starting at 11, schedule here: http:\/\/t.co\/7r0ieGBplT #eltchat #ea\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "eapcultures15",
        "indices" : [ 0, 14 ]
      }, {
        "text" : "eltchat",
        "indices" : [ 107, 115 ]
      }, {
        "text" : "eapchat",
        "indices" : [ 116, 124 ]
      }, {
        "text" : "efl",
        "indices" : [ 125, 129 ]
      }, {
        "text" : "eap",
        "indices" : [ 130, 134 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/7r0ieGBplT",
        "expanded_url" : "http:\/\/goo.gl\/MS5cis",
        "display_url" : "goo.gl\/MS5cis"
      } ]
    },
    "geo" : { },
    "id_str" : "556032751368163328",
    "text" : "#eapcultures15 2nd day of free online EAP conference starting at 11, schedule here: http:\/\/t.co\/7r0ieGBplT #eltchat #eapchat #efl #eap",
    "id" : 556032751368163328,
    "created_at" : "2015-01-16 10:18:33 +0000",
    "user" : {
      "name" : "David Read",
      "screen_name" : "dreadnought001",
      "protected" : false,
      "id_str" : "83207734",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/503606579573178370\/GqHxIpPe_normal.jpeg",
      "id" : 83207734,
      "verified" : false
    }
  },
  "id" : 556041922448719872,
  "created_at" : "2015-01-16 10:54:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 3, 12 ],
      "id_str" : "134211317",
      "id" : 134211317
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DemandHigh",
      "indices" : [ 30, 41 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/rZREkjdBSj",
      "expanded_url" : "http:\/\/wp.me\/p59670-sG",
      "display_url" : "wp.me\/p59670-sG"
    } ]
  },
  "geo" : { },
  "id_str" : "556041023366115328",
  "text" : "RT @josipa74: My criticism of #DemandHigh teaching. http:\/\/t.co\/rZREkjdBSj Comments welcome.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DemandHigh",
        "indices" : [ 16, 27 ]
      } ],
      "urls" : [ {
        "indices" : [ 38, 60 ],
        "url" : "http:\/\/t.co\/rZREkjdBSj",
        "expanded_url" : "http:\/\/wp.me\/p59670-sG",
        "display_url" : "wp.me\/p59670-sG"
      } ]
    },
    "geo" : { },
    "id_str" : "556011962363305984",
    "text" : "My criticism of #DemandHigh teaching. http:\/\/t.co\/rZREkjdBSj Comments welcome.",
    "id" : 556011962363305984,
    "created_at" : "2015-01-16 08:55:56 +0000",
    "user" : {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "protected" : false,
      "id_str" : "134211317",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/526853654377021441\/MtEFhYIs_normal.jpeg",
      "id" : 134211317,
      "verified" : false
    }
  },
  "id" : 556041023366115328,
  "created_at" : "2015-01-16 10:51:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CharlieHebdo",
      "indices" : [ 140, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/lQdielR8ux",
      "expanded_url" : "http:\/\/medialens.org\/index.php\/2015\/783-charlie-hebdo-and-the-war-for-civilisation.html",
      "display_url" : "medialens.org\/index.php\/2015\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "555989165876469760",
  "text" : "RT @medialens: Journalists &amp; politicians want you to believe that they passionately defend the right to offend.  http:\/\/t.co\/lQdielR8ux #Ch\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CharlieHebdo",
        "indices" : [ 125, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/lQdielR8ux",
        "expanded_url" : "http:\/\/medialens.org\/index.php\/2015\/783-charlie-hebdo-and-the-war-for-civilisation.html",
        "display_url" : "medialens.org\/index.php\/2015\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "555669228481966080",
    "text" : "Journalists &amp; politicians want you to believe that they passionately defend the right to offend.  http:\/\/t.co\/lQdielR8ux #CharlieHebdo",
    "id" : 555669228481966080,
    "created_at" : "2015-01-15 10:14:02 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 555989165876469760,
  "created_at" : "2015-01-16 07:25:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helen Legge",
      "screen_name" : "ITLegge",
      "indices" : [ 0, 8 ],
      "id_str" : "2201561838",
      "id" : 2201561838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "555983277090418688",
  "in_reply_to_user_id" : 2201561838,
  "text" : "@ITLegge thx for RT :)",
  "id" : 555983277090418688,
  "created_at" : "2015-01-16 07:01:57 +0000",
  "in_reply_to_screen_name" : "ITLegge",
  "in_reply_to_user_id_str" : "2201561838",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EAPsteve",
      "screen_name" : "EAPstephen",
      "indices" : [ 3, 14 ],
      "id_str" : "2717005711",
      "id" : 2717005711
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tleap",
      "indices" : [ 84, 90 ]
    }, {
      "text" : "eapchat",
      "indices" : [ 91, 99 ]
    }, {
      "text" : "eltchinwag",
      "indices" : [ 100, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/XeEV1BgiiC",
      "expanded_url" : "http:\/\/eaping.blogspot.ie\/2015\/01\/nominalisation-part-2-cause-and-effect.html",
      "display_url" : "eaping.blogspot.ie\/2015\/01\/nomina\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "555830762692685824",
  "text" : "RT @EAPstephen: Does nominalisation deserve a second lesson? http:\/\/t.co\/XeEV1BgiiC #tleap #eapchat #eltchinwag",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tleap",
        "indices" : [ 68, 74 ]
      }, {
        "text" : "eapchat",
        "indices" : [ 75, 83 ]
      }, {
        "text" : "eltchinwag",
        "indices" : [ 84, 95 ]
      } ],
      "urls" : [ {
        "indices" : [ 45, 67 ],
        "url" : "http:\/\/t.co\/XeEV1BgiiC",
        "expanded_url" : "http:\/\/eaping.blogspot.ie\/2015\/01\/nominalisation-part-2-cause-and-effect.html",
        "display_url" : "eaping.blogspot.ie\/2015\/01\/nomina\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "555786154826424320",
    "text" : "Does nominalisation deserve a second lesson? http:\/\/t.co\/XeEV1BgiiC #tleap #eapchat #eltchinwag",
    "id" : 555786154826424320,
    "created_at" : "2015-01-15 17:58:39 +0000",
    "user" : {
      "name" : "EAPsteve",
      "screen_name" : "EAPstephen",
      "protected" : false,
      "id_str" : "2717005711",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/541999119812681728\/dHDIC_gW_normal.jpeg",
      "id" : 2717005711,
      "verified" : false
    }
  },
  "id" : 555830762692685824,
  "created_at" : "2015-01-15 20:55:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Seymour",
      "screen_name" : "leninology",
      "indices" : [ 66, 77 ],
      "id_str" : "15557246",
      "id" : 15557246
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/y1Nkwh7jN0",
      "expanded_url" : "http:\/\/www.leninology.co.uk\/2015\/01\/those-who-arent-charlie.html",
      "display_url" : "leninology.co.uk\/2015\/01\/those-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "555672292945317888",
  "text" : "LENIN'S TOMB: Those who aren't Charlie http:\/\/t.co\/y1Nkwh7jN0 via @leninology",
  "id" : 555672292945317888,
  "created_at" : "2015-01-15 10:26:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth Anne",
      "screen_name" : "eannegrenoble",
      "indices" : [ 3, 17 ],
      "id_str" : "19869781",
      "id" : 19869781
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eapcultures15",
      "indices" : [ 115, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/ctPf5h8ITZ",
      "expanded_url" : "http:\/\/goo.gl\/MS5cis",
      "display_url" : "goo.gl\/MS5cis"
    } ]
  },
  "geo" : { },
  "id_str" : "555669446556385281",
  "text" : "RT @eannegrenoble: OUP\/Sheffield Uni 'Cultures of EAP' free online conference starts today: http:\/\/t.co\/ctPf5h8ITZ #eapcultures15\" keeping \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "eapcultures15",
        "indices" : [ 96, 110 ]
      } ],
      "urls" : [ {
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/ctPf5h8ITZ",
        "expanded_url" : "http:\/\/goo.gl\/MS5cis",
        "display_url" : "goo.gl\/MS5cis"
      } ]
    },
    "geo" : { },
    "id_str" : "555659649190739968",
    "text" : "OUP\/Sheffield Uni 'Cultures of EAP' free online conference starts today: http:\/\/t.co\/ctPf5h8ITZ #eapcultures15\" keeping quiet but ready 2 go",
    "id" : 555659649190739968,
    "created_at" : "2015-01-15 09:35:58 +0000",
    "user" : {
      "name" : "Elizabeth Anne",
      "screen_name" : "eannegrenoble",
      "protected" : false,
      "id_str" : "19869781",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/486151060419907584\/DQRq7qOi_normal.jpeg",
      "id" : 19869781,
      "verified" : false
    }
  },
  "id" : 555669446556385281,
  "created_at" : "2015-01-15 10:14:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Thornbury",
      "screen_name" : "thornburyscott",
      "indices" : [ 3, 18 ],
      "id_str" : "23090474",
      "id" : 23090474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/btv1L4I3Ye",
      "expanded_url" : "https:\/\/firstlook.org\/theintercept\/2015\/01\/14\/days-hosting-massive-free-speech-march-france-arrests-comedian-facebook-comments\/",
      "display_url" : "firstlook.org\/theintercept\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "555654502771331072",
  "text" : "RT @thornburyscott: I can insult u but u can't insult me, it seems. More 'free speech' double-think: https:\/\/t.co\/btv1L4I3Ye",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/btv1L4I3Ye",
        "expanded_url" : "https:\/\/firstlook.org\/theintercept\/2015\/01\/14\/days-hosting-massive-free-speech-march-france-arrests-comedian-facebook-comments\/",
        "display_url" : "firstlook.org\/theintercept\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "555651418871566336",
    "text" : "I can insult u but u can't insult me, it seems. More 'free speech' double-think: https:\/\/t.co\/btv1L4I3Ye",
    "id" : 555651418871566336,
    "created_at" : "2015-01-15 09:03:16 +0000",
    "user" : {
      "name" : "Scott Thornbury",
      "screen_name" : "thornburyscott",
      "protected" : false,
      "id_str" : "23090474",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892392697\/twitter03_normal.jpg",
      "id" : 23090474,
      "verified" : false
    }
  },
  "id" : 555654502771331072,
  "created_at" : "2015-01-15 09:15:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "555423096698851328",
  "geo" : { },
  "id_str" : "555425409840738304",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan very nice thx :)",
  "id" : 555425409840738304,
  "in_reply_to_status_id" : 555423096698851328,
  "created_at" : "2015-01-14 18:05:11 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 70, 78 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/gilGOFX5gu",
      "expanded_url" : "http:\/\/youtu.be\/l_otxqoSGgA",
      "display_url" : "youtu.be\/l_otxqoSGgA"
    } ]
  },
  "geo" : { },
  "id_str" : "555422472427032576",
  "text" : "Real Grammar: Is impact a noun or a verb?: http:\/\/t.co\/gilGOFX5gu via @YouTube",
  "id" : 555422472427032576,
  "created_at" : "2015-01-14 17:53:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katy Simpson",
      "screen_name" : "KatyELT",
      "indices" : [ 3, 11 ],
      "id_str" : "357785615",
      "id" : 357785615
    }, {
      "name" : "ELF Pron",
      "screen_name" : "ELF_Pron",
      "indices" : [ 24, 33 ],
      "id_str" : "2222993041",
      "id" : 2222993041
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "efl",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/LYrhmzAR3X",
      "expanded_url" : "https:\/\/elfpron.wordpress.com\/2015\/01\/13\/english-outside-the-classroom\/",
      "display_url" : "elfpron.wordpress.com\/2015\/01\/13\/eng\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "555419918968299521",
  "text" : "RT @KatyELT: Our latest @ELF_Pron post with audio resources and handout about learning English outside the classroom https:\/\/t.co\/LYrhmzAR3\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ELF Pron",
        "screen_name" : "ELF_Pron",
        "indices" : [ 11, 20 ],
        "id_str" : "2222993041",
        "id" : 2222993041
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "elt",
        "indices" : [ 128, 132 ]
      }, {
        "text" : "efl",
        "indices" : [ 133, 137 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/LYrhmzAR3X",
        "expanded_url" : "https:\/\/elfpron.wordpress.com\/2015\/01\/13\/english-outside-the-classroom\/",
        "display_url" : "elfpron.wordpress.com\/2015\/01\/13\/eng\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "555416294200057858",
    "text" : "Our latest @ELF_Pron post with audio resources and handout about learning English outside the classroom https:\/\/t.co\/LYrhmzAR3X #elt #efl",
    "id" : 555416294200057858,
    "created_at" : "2015-01-14 17:28:58 +0000",
    "user" : {
      "name" : "Katy Simpson",
      "screen_name" : "KatyELT",
      "protected" : false,
      "id_str" : "357785615",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3525711987\/eeb01458d4856135c08edba71c938325_normal.jpeg",
      "id" : 357785615,
      "verified" : false
    }
  },
  "id" : 555419918968299521,
  "created_at" : "2015-01-14 17:43:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dustin Hosseini",
      "screen_name" : "DustinAcEd",
      "indices" : [ 0, 11 ],
      "id_str" : "1066619394",
      "id" : 1066619394
    }, {
      "name" : "Margarita Hornillos",
      "screen_name" : "mhornillos",
      "indices" : [ 12, 23 ],
      "id_str" : "459124614",
      "id" : 459124614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "555407143944609793",
  "in_reply_to_user_id" : 1066619394,
  "text" : "@DustinAcEd @mhornillos @HadaLitim thank you all very much for RT :)",
  "id" : 555407143944609793,
  "created_at" : "2015-01-14 16:52:36 +0000",
  "in_reply_to_screen_name" : "DustinAcEd",
  "in_reply_to_user_id_str" : "1066619394",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon J. Eason",
      "screen_name" : "sjeason",
      "indices" : [ 0, 8 ],
      "id_str" : "258401804",
      "id" : 258401804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "555406443768446976",
  "text" : "@sjeason ok will report any interesting findings, not sure about re-reruns will ask",
  "id" : 555406443768446976,
  "created_at" : "2015-01-14 16:49:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon J. Eason",
      "screen_name" : "sjeason",
      "indices" : [ 0, 8 ],
      "id_str" : "258401804",
      "id" : 258401804
    }, {
      "name" : "Ljiljana Havran",
      "screen_name" : "LjiljanaHavran",
      "indices" : [ 9, 24 ],
      "id_str" : "1395825290",
      "id" : 1395825290
    }, {
      "name" : "Tara Benwell",
      "screen_name" : "tarabenwell",
      "indices" : [ 25, 37 ],
      "id_str" : "121766002",
      "id" : 121766002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "555323541307281408",
  "text" : "@sjeason @LjiljanaHavran @tarabenwell appreciate the RTs a lot guys, thanks :)",
  "id" : 555323541307281408,
  "created_at" : "2015-01-14 11:20:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Harbinson",
      "screen_name" : "DavidHarbinson",
      "indices" : [ 0, 15 ],
      "id_str" : "853078675",
      "id" : 853078675
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "555232861519749120",
  "geo" : { },
  "id_str" : "555323288105525248",
  "in_reply_to_user_id" : 853078675,
  "text" : "@DavidHarbinson cheers for sharing :)",
  "id" : 555323288105525248,
  "in_reply_to_status_id" : 555232861519749120,
  "created_at" : "2015-01-14 11:19:23 +0000",
  "in_reply_to_screen_name" : "DavidHarbinson",
  "in_reply_to_user_id_str" : "853078675",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 17, 25 ]
    }, {
      "text" : "eltchinwag",
      "indices" : [ 26, 37 ]
    }, {
      "text" : "tesol",
      "indices" : [ 38, 44 ]
    }, {
      "text" : "langchat",
      "indices" : [ 45, 54 ]
    }, {
      "text" : "evo",
      "indices" : [ 55, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/VDgS62M8dA",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-Sp",
      "display_url" : "wp.me\/pgHyE-Sp"
    } ]
  },
  "geo" : { },
  "id_str" : "555154306039443456",
  "text" : "A Pron Chart Zoo #eltchat #eltchinwag #tesol #langchat #evo http:\/\/t.co\/VDgS62M8dA",
  "id" : 555154306039443456,
  "created_at" : "2015-01-14 00:07:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 3, 17 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/suIoXRxwbq",
      "expanded_url" : "http:\/\/hackeducation.com\/2015\/01\/13\/speak-and-spell\/",
      "display_url" : "hackeducation.com\/2015\/01\/13\/spe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "555113022654803968",
  "text" : "RT @audreywatters: Speak &amp; Spell: A History http:\/\/t.co\/suIoXRxwbq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 29, 51 ],
        "url" : "http:\/\/t.co\/suIoXRxwbq",
        "expanded_url" : "http:\/\/hackeducation.com\/2015\/01\/13\/speak-and-spell\/",
        "display_url" : "hackeducation.com\/2015\/01\/13\/spe\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "555073451157749760",
    "text" : "Speak &amp; Spell: A History http:\/\/t.co\/suIoXRxwbq",
    "id" : 555073451157749760,
    "created_at" : "2015-01-13 18:46:38 +0000",
    "user" : {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "protected" : false,
      "id_str" : "25388528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711668009723498496\/pauFZsdv_normal.jpg",
      "id" : 25388528,
      "verified" : false
    }
  },
  "id" : 555113022654803968,
  "created_at" : "2015-01-13 21:23:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Douglas Carnall",
      "screen_name" : "JuliuzBeezer",
      "indices" : [ 3, 16 ],
      "id_str" : "25936824",
      "id" : 25936824
    }, {
      "name" : "Douglas Carnall",
      "screen_name" : "JuliuzBeezer",
      "indices" : [ 121, 134 ],
      "id_str" : "25936824",
      "id" : 25936824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/HP6MPk0Sk9",
      "expanded_url" : "https:\/\/storify.com\/DouglasCarnall\/l-affaire-charliehebdo",
      "display_url" : "storify.com\/DouglasCarnall\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "555102856798560257",
  "text" : "RT @JuliuzBeezer: Reconstructing a personal timeline of l'affaire CharlieHebdo: Storify test https:\/\/t.co\/HP6MPk0Sk9 via @juliuzbeezer",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Douglas Carnall",
        "screen_name" : "JuliuzBeezer",
        "indices" : [ 103, 116 ],
        "id_str" : "25936824",
        "id" : 25936824
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/HP6MPk0Sk9",
        "expanded_url" : "https:\/\/storify.com\/DouglasCarnall\/l-affaire-charliehebdo",
        "display_url" : "storify.com\/DouglasCarnall\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "555087253304004608",
    "text" : "Reconstructing a personal timeline of l'affaire CharlieHebdo: Storify test https:\/\/t.co\/HP6MPk0Sk9 via @juliuzbeezer",
    "id" : 555087253304004608,
    "created_at" : "2015-01-13 19:41:28 +0000",
    "user" : {
      "name" : "Douglas Carnall",
      "screen_name" : "JuliuzBeezer",
      "protected" : false,
      "id_str" : "25936824",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/114211651\/robert_burns247x165_normal.jpg",
      "id" : 25936824,
      "verified" : false
    }
  },
  "id" : 555102856798560257,
  "created_at" : "2015-01-13 20:43:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MaWSIG",
      "screen_name" : "MaWSIG",
      "indices" : [ 3, 10 ],
      "id_str" : "1096618700",
      "id" : 1096618700
    }, {
      "name" : "Julie Moore",
      "screen_name" : "lexicojules",
      "indices" : [ 62, 74 ],
      "id_str" : "424320799",
      "id" : 424320799
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELT",
      "indices" : [ 12, 16 ]
    }, {
      "text" : "IATEFL15",
      "indices" : [ 47, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/UJo3e7iEov",
      "expanded_url" : "http:\/\/ow.ly\/He0e7",
      "display_url" : "ow.ly\/He0e7"
    } ]
  },
  "geo" : { },
  "id_str" : "555041275016392704",
  "text" : "RT @MaWSIG: #ELT materials writer? Come to our #IATEFL15 PCE. @lexicojules trails her session on using corpus tools for writing: http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Julie Moore",
        "screen_name" : "lexicojules",
        "indices" : [ 50, 62 ],
        "id_str" : "424320799",
        "id" : 424320799
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELT",
        "indices" : [ 0, 4 ]
      }, {
        "text" : "IATEFL15",
        "indices" : [ 35, 44 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/UJo3e7iEov",
        "expanded_url" : "http:\/\/ow.ly\/He0e7",
        "display_url" : "ow.ly\/He0e7"
      } ]
    },
    "geo" : { },
    "id_str" : "554911621383208960",
    "text" : "#ELT materials writer? Come to our #IATEFL15 PCE. @lexicojules trails her session on using corpus tools for writing: http:\/\/t.co\/UJo3e7iEov",
    "id" : 554911621383208960,
    "created_at" : "2015-01-13 08:03:34 +0000",
    "user" : {
      "name" : "MaWSIG",
      "screen_name" : "MaWSIG",
      "protected" : false,
      "id_str" : "1096618700",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3471592092\/75c231ab25fa45330c0cf95a5763d27f_normal.jpeg",
      "id" : 1096618700,
      "verified" : false
    }
  },
  "id" : 555041275016392704,
  "created_at" : "2015-01-13 16:38:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Harbinson",
      "screen_name" : "DavidHarbinson",
      "indices" : [ 0, 15 ],
      "id_str" : "853078675",
      "id" : 853078675
    }, {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 16, 31 ],
      "id_str" : "285614027",
      "id" : 285614027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/UUPn6yHiDJ",
      "expanded_url" : "https:\/\/literalminded.wordpress.com\/category\/elementary-school-linguistics\/",
      "display_url" : "literalminded.wordpress.com\/category\/eleme\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "555020083307622402",
  "geo" : { },
  "id_str" : "555024798087380992",
  "in_reply_to_user_id" : 853078675,
  "text" : "@DavidHarbinson @AnthonyTeacher good idea, some related posts here https:\/\/t.co\/UUPn6yHiDJ",
  "id" : 555024798087380992,
  "in_reply_to_status_id" : 555020083307622402,
  "created_at" : "2015-01-13 15:33:18 +0000",
  "in_reply_to_screen_name" : "DavidHarbinson",
  "in_reply_to_user_id_str" : "853078675",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 0, 15 ],
      "id_str" : "285614027",
      "id" : 285614027
    }, {
      "name" : "David Harbinson",
      "screen_name" : "DavidHarbinson",
      "indices" : [ 16, 31 ],
      "id_str" : "853078675",
      "id" : 853078675
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "555019016033808384",
  "geo" : { },
  "id_str" : "555020799187615744",
  "in_reply_to_user_id" : 285614027,
  "text" : "@AnthonyTeacher @DavidHarbinson so close but no sourleaf :0",
  "id" : 555020799187615744,
  "in_reply_to_status_id" : 555019016033808384,
  "created_at" : "2015-01-13 15:17:24 +0000",
  "in_reply_to_screen_name" : "AnthonyTeacher",
  "in_reply_to_user_id_str" : "285614027",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 0, 15 ],
      "id_str" : "285614027",
      "id" : 285614027
    }, {
      "name" : "David Harbinson",
      "screen_name" : "DavidHarbinson",
      "indices" : [ 16, 31 ],
      "id_str" : "853078675",
      "id" : 853078675
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "555017410059964418",
  "geo" : { },
  "id_str" : "555018179400192001",
  "in_reply_to_user_id" : 285614027,
  "text" : "@AnthonyTeacher @DavidHarbinson hmm how come valar is nor valir?",
  "id" : 555018179400192001,
  "in_reply_to_status_id" : 555017410059964418,
  "created_at" : "2015-01-13 15:07:00 +0000",
  "in_reply_to_screen_name" : "AnthonyTeacher",
  "in_reply_to_user_id_str" : "285614027",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "indices" : [ 3, 19 ],
      "id_str" : "1326508478",
      "id" : 1326508478
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/lTcJz4B56W",
      "expanded_url" : "http:\/\/cass.lancs.ac.uk\/?p=1520",
      "display_url" : "cass.lancs.ac.uk\/?p=1520"
    } ]
  },
  "geo" : { },
  "id_str" : "555009718301646848",
  "text" : "RT @CorpusSocialSci: Video: What can corpora tell us about learning a foreign language? Presented by Vaclav Brezina http:\/\/t.co\/lTcJz4B56W",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/lTcJz4B56W",
        "expanded_url" : "http:\/\/cass.lancs.ac.uk\/?p=1520",
        "display_url" : "cass.lancs.ac.uk\/?p=1520"
      } ]
    },
    "geo" : { },
    "id_str" : "555008665997291520",
    "text" : "Video: What can corpora tell us about learning a foreign language? Presented by Vaclav Brezina http:\/\/t.co\/lTcJz4B56W",
    "id" : 555008665997291520,
    "created_at" : "2015-01-13 14:29:12 +0000",
    "user" : {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "protected" : false,
      "id_str" : "1326508478",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3493899777\/ced36fe15c32eb911cbe3d64377524dc_normal.jpeg",
      "id" : 1326508478,
      "verified" : false
    }
  },
  "id" : 555009718301646848,
  "created_at" : "2015-01-13 14:33:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hancock McDonald ELT",
      "screen_name" : "HancockMcDonald",
      "indices" : [ 0, 16 ],
      "id_str" : "552929354",
      "id" : 552929354
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EVO2015",
      "indices" : [ 84, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/JHgOjyoLII",
      "expanded_url" : "http:\/\/www.pronunciationscience.com\/charts\/",
      "display_url" : "pronunciationscience.com\/charts\/"
    } ]
  },
  "geo" : { },
  "id_str" : "554995861886095360",
  "in_reply_to_user_id" : 552929354,
  "text" : "@HancockMcDonald have you seen these pretty funky charts http:\/\/t.co\/JHgOjyoLII h\/t #EVO2015",
  "id" : 554995861886095360,
  "created_at" : "2015-01-13 13:38:19 +0000",
  "in_reply_to_screen_name" : "HancockMcDonald",
  "in_reply_to_user_id_str" : "552929354",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Compassionate Lang",
      "screen_name" : "compassionlang",
      "indices" : [ 3, 18 ],
      "id_str" : "2798247866",
      "id" : 2798247866
    }, {
      "name" : "GdnLanguageLearning ",
      "screen_name" : "gdnlanglearn",
      "indices" : [ 35, 48 ],
      "id_str" : "1926508098",
      "id" : 1926508098
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "langchat",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 123, 140 ],
      "url" : "http:\/\/t.co\/cxs2BjcQBa",
      "expanded_url" : "http:\/\/gu.com\/p\/44jy5\/stw",
      "display_url" : "gu.com\/p\/44jy5\/stw"
    } ]
  },
  "geo" : { },
  "id_str" : "554973403699236864",
  "text" : "RT @compassionlang: My article for @gdnlanglearn (!!!) - Learning a language helps me talk back to the voice of depression http:\/\/t.co\/cxs2\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "GdnLanguageLearning ",
        "screen_name" : "gdnlanglearn",
        "indices" : [ 15, 28 ],
        "id_str" : "1926508098",
        "id" : 1926508098
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "langchat",
        "indices" : [ 126, 135 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/cxs2BjcQBa",
        "expanded_url" : "http:\/\/gu.com\/p\/44jy5\/stw",
        "display_url" : "gu.com\/p\/44jy5\/stw"
      } ]
    },
    "geo" : { },
    "id_str" : "554967820459855872",
    "text" : "My article for @gdnlanglearn (!!!) - Learning a language helps me talk back to the voice of depression http:\/\/t.co\/cxs2BjcQBa #langchat",
    "id" : 554967820459855872,
    "created_at" : "2015-01-13 11:46:53 +0000",
    "user" : {
      "name" : "Compassionate Lang",
      "screen_name" : "compassionlang",
      "protected" : false,
      "id_str" : "2798247866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/509022276952395776\/16R-fRW8_normal.jpeg",
      "id" : 2798247866,
      "verified" : false
    }
  },
  "id" : 554973403699236864,
  "created_at" : "2015-01-13 12:09:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/jVzseGBPsQ",
      "expanded_url" : "http:\/\/bit.ly\/14uxWuv",
      "display_url" : "bit.ly\/14uxWuv"
    } ]
  },
  "geo" : { },
  "id_str" : "554950985538633729",
  "text" : "The Great Greek-German Game of Chicken Has Begun | Opinion | teleSUR http:\/\/t.co\/jVzseGBPsQ",
  "id" : 554950985538633729,
  "created_at" : "2015-01-13 10:40:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angus B Grieve-Smith",
      "screen_name" : "grvsmth",
      "indices" : [ 3, 11 ],
      "id_str" : "22381639",
      "id" : 22381639
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/grvsmth\/status\/554889011165401088\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/4mnfqylhEI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B7NY8k8CQAALPKe.jpg",
      "id_str" : "554884976827580416",
      "id" : 554884976827580416,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B7NY8k8CQAALPKe.jpg",
      "sizes" : [ {
        "h" : 675,
        "resize" : "fit",
        "w" : 512
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 512
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 512
      } ],
      "display_url" : "pic.twitter.com\/4mnfqylhEI"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/rL0dDSivrn",
      "expanded_url" : "http:\/\/grieve-smith.com\/blog\/2015\/01\/sometimes-bugs-are-not-insects\/",
      "display_url" : "grieve-smith.com\/blog\/2015\/01\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "554948547473580032",
  "text" : "RT @grvsmth: New post: Sometimes bugs are not insects http:\/\/t.co\/rL0dDSivrn On respecting other people's categories http:\/\/t.co\/4mnfqylhEI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/grvsmth\/status\/554889011165401088\/photo\/1",
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/4mnfqylhEI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B7NY8k8CQAALPKe.jpg",
        "id_str" : "554884976827580416",
        "id" : 554884976827580416,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B7NY8k8CQAALPKe.jpg",
        "sizes" : [ {
          "h" : 675,
          "resize" : "fit",
          "w" : 512
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 512
        }, {
          "h" : 448,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 512
        } ],
        "display_url" : "pic.twitter.com\/4mnfqylhEI"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/rL0dDSivrn",
        "expanded_url" : "http:\/\/grieve-smith.com\/blog\/2015\/01\/sometimes-bugs-are-not-insects\/",
        "display_url" : "grieve-smith.com\/blog\/2015\/01\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "554889011165401088",
    "text" : "New post: Sometimes bugs are not insects http:\/\/t.co\/rL0dDSivrn On respecting other people's categories http:\/\/t.co\/4mnfqylhEI",
    "id" : 554889011165401088,
    "created_at" : "2015-01-13 06:33:44 +0000",
    "user" : {
      "name" : "Angus B Grieve-Smith",
      "screen_name" : "grvsmth",
      "protected" : false,
      "id_str" : "22381639",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/94827231\/portrait_normal.png",
      "id" : 22381639,
      "verified" : false
    }
  },
  "id" : 554948547473580032,
  "created_at" : "2015-01-13 10:30:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cory Doctorow",
      "screen_name" : "doctorow",
      "indices" : [ 3, 12 ],
      "id_str" : "2729061",
      "id" : 2729061
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/doctorow\/status\/554885244642680832\/photo\/1",
      "indices" : [ 119, 140 ],
      "url" : "http:\/\/t.co\/bQu9yo87lj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B7NZMHWIcAAr3VT.png",
      "id_str" : "554885243761881088",
      "id" : 554885243761881088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B7NZMHWIcAAr3VT.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/bQu9yo87lj"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/NTZovDcbPL",
      "expanded_url" : "http:\/\/boingboing.net\/2015\/01\/12\/30-shockingly-amazing-linkbait.html",
      "display_url" : "boingboing.net\/2015\/01\/12\/30-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "554943948368904192",
  "text" : "RT @doctorow: 30 shockingly amazing linkbait phrases Buzzfeed uses to get you to click on stuff http:\/\/t.co\/NTZovDcbPL http:\/\/t.co\/bQu9yo87\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/doctorow\/status\/554885244642680832\/photo\/1",
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/bQu9yo87lj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B7NZMHWIcAAr3VT.png",
        "id_str" : "554885243761881088",
        "id" : 554885243761881088,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B7NZMHWIcAAr3VT.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/bQu9yo87lj"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/NTZovDcbPL",
        "expanded_url" : "http:\/\/boingboing.net\/2015\/01\/12\/30-shockingly-amazing-linkbait.html",
        "display_url" : "boingboing.net\/2015\/01\/12\/30-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "554885244642680832",
    "text" : "30 shockingly amazing linkbait phrases Buzzfeed uses to get you to click on stuff http:\/\/t.co\/NTZovDcbPL http:\/\/t.co\/bQu9yo87lj",
    "id" : 554885244642680832,
    "created_at" : "2015-01-13 06:18:46 +0000",
    "user" : {
      "name" : "Cory Doctorow",
      "screen_name" : "doctorow",
      "protected" : false,
      "id_str" : "2729061",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/675023052812378112\/Ly7VsGa6_normal.jpg",
      "id" : 2729061,
      "verified" : true
    }
  },
  "id" : 554943948368904192,
  "created_at" : "2015-01-13 10:12:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Terence Eden \u23FB",
      "screen_name" : "edent",
      "indices" : [ 3, 9 ],
      "id_str" : "14054507",
      "id" : 14054507
    }, {
      "name" : "A dreadful start",
      "screen_name" : "wnd_go",
      "indices" : [ 111, 118 ],
      "id_str" : "2940072513",
      "id" : 2940072513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "554943391856091136",
  "text" : "RT @edent: You should probably be asleep.\n\nI've created a \"Choose You Own Adventure\" on Twitter.\n\nStart here \u27A1 @wnd_go\n\nPleasant dreams.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/play.google.com\/store\/apps\/details?id=org.mariotaku.twidere\" rel=\"nofollow\"\u003ETwidere for Android #2\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "A dreadful start",
        "screen_name" : "wnd_go",
        "indices" : [ 100, 107 ],
        "id_str" : "2940072513",
        "id" : 2940072513
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "554772317738659840",
    "text" : "You should probably be asleep.\n\nI've created a \"Choose You Own Adventure\" on Twitter.\n\nStart here \u27A1 @wnd_go\n\nPleasant dreams.",
    "id" : 554772317738659840,
    "created_at" : "2015-01-12 22:50:02 +0000",
    "user" : {
      "name" : "Terence Eden \u23FB",
      "screen_name" : "edent",
      "protected" : false,
      "id_str" : "14054507",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/687638251939753984\/V_ykmwaR_normal.png",
      "id" : 14054507,
      "verified" : true
    }
  },
  "id" : 554943391856091136,
  "created_at" : "2015-01-13 10:09:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "indices" : [ 3, 18 ],
      "id_str" : "152194866",
      "id" : 152194866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CharlieHebdo",
      "indices" : [ 64, 77 ]
    }, {
      "text" : "Security",
      "indices" : [ 78, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/YsPS3Maq5L",
      "expanded_url" : "http:\/\/ow.ly\/HdqiN",
      "display_url" : "ow.ly\/HdqiN"
    } ]
  },
  "geo" : { },
  "id_str" : "554939564079738880",
  "text" : "RT @patrickDurusau: Charlie Hebdo Attack Inspires Digital Stasi #CharlieHebdo #Security http:\/\/t.co\/YsPS3Maq5L",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CharlieHebdo",
        "indices" : [ 44, 57 ]
      }, {
        "text" : "Security",
        "indices" : [ 58, 67 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/YsPS3Maq5L",
        "expanded_url" : "http:\/\/ow.ly\/HdqiN",
        "display_url" : "ow.ly\/HdqiN"
      } ]
    },
    "geo" : { },
    "id_str" : "554835530475905024",
    "text" : "Charlie Hebdo Attack Inspires Digital Stasi #CharlieHebdo #Security http:\/\/t.co\/YsPS3Maq5L",
    "id" : 554835530475905024,
    "created_at" : "2015-01-13 03:01:13 +0000",
    "user" : {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "protected" : false,
      "id_str" : "152194866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/961579480\/patrick_normal.jpeg",
      "id" : 152194866,
      "verified" : false
    }
  },
  "id" : 554939564079738880,
  "created_at" : "2015-01-13 09:54:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 0, 9 ],
      "id_str" : "121063600",
      "id" : 121063600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "554931300025769984",
  "geo" : { },
  "id_str" : "554936734585462784",
  "in_reply_to_user_id" : 121063600,
  "text" : "@whyshona i like how ACEDLE have named the pdfs saves on me renaming some faceless number nice :)",
  "id" : 554936734585462784,
  "in_reply_to_status_id" : 554931300025769984,
  "created_at" : "2015-01-13 09:43:22 +0000",
  "in_reply_to_screen_name" : "whyshona",
  "in_reply_to_user_id_str" : "121063600",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 0, 9 ],
      "id_str" : "121063600",
      "id" : 121063600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "554930023812300800",
  "geo" : { },
  "id_str" : "554930824567873536",
  "in_reply_to_user_id" : 121063600,
  "text" : "@whyshona thanks just bookmarked yr previous tweet on issue, looks good :)",
  "id" : 554930824567873536,
  "in_reply_to_status_id" : 554930023812300800,
  "created_at" : "2015-01-13 09:19:53 +0000",
  "in_reply_to_screen_name" : "whyshona",
  "in_reply_to_user_id_str" : "121063600",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 46, 62 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/tVmWTc93jC",
      "expanded_url" : "http:\/\/wp.me\/psr3-12j",
      "display_url" : "wp.me\/psr3-12j"
    } ]
  },
  "geo" : { },
  "id_str" : "554928646604226560",
  "text" : "Thoughts in motion http:\/\/t.co\/tVmWTc93jC via @wordpressdotcom",
  "id" : 554928646604226560,
  "created_at" : "2015-01-13 09:11:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELT MAKERS",
      "screen_name" : "ELTMAKERS",
      "indices" : [ 0, 10 ],
      "id_str" : "2894570578",
      "id" : 2894570578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "554697760990318592",
  "geo" : { },
  "id_str" : "554712988578766848",
  "in_reply_to_user_id" : 2894570578,
  "text" : "@ELTMAKERS i hacked it together :), original code and original research not mine",
  "id" : 554712988578766848,
  "in_reply_to_status_id" : 554697760990318592,
  "created_at" : "2015-01-12 18:54:17 +0000",
  "in_reply_to_screen_name" : "ELTMAKERS",
  "in_reply_to_user_id_str" : "2894570578",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frankie Boyle",
      "screen_name" : "frankieboyle",
      "indices" : [ 3, 16 ],
      "id_str" : "17336372",
      "id" : 17336372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "554317110600806400",
  "text" : "RT @frankieboyle: Glad everyone's celebrating free speech in Trafalgar Square, and not in Parliament Square where they'd be arrested.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "554297245471092736",
    "text" : "Glad everyone's celebrating free speech in Trafalgar Square, and not in Parliament Square where they'd be arrested.",
    "id" : 554297245471092736,
    "created_at" : "2015-01-11 15:22:16 +0000",
    "user" : {
      "name" : "Frankie Boyle",
      "screen_name" : "frankieboyle",
      "protected" : false,
      "id_str" : "17336372",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/743772932892131328\/ZcekAc_1_normal.jpg",
      "id" : 17336372,
      "verified" : true
    }
  },
  "id" : 554317110600806400,
  "created_at" : "2015-01-11 16:41:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Harbinson",
      "screen_name" : "DavidHarbinson",
      "indices" : [ 66, 81 ],
      "id_str" : "853078675",
      "id" : 853078675
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/X2Aj0IhJfn",
      "expanded_url" : "http:\/\/wp.me\/p5xSWM-2b",
      "display_url" : "wp.me\/p5xSWM-2b"
    } ]
  },
  "geo" : { },
  "id_str" : "554316427516080128",
  "text" : "Day 11: Charlie Hebdo: Behind the name http:\/\/t.co\/X2Aj0IhJfn via @DavidHarbinson",
  "id" : 554316427516080128,
  "created_at" : "2015-01-11 16:38:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Asaf Bitton",
      "screen_name" : "Asaf_Bitton",
      "indices" : [ 3, 15 ],
      "id_str" : "376476158",
      "id" : 376476158
    }, {
      "name" : "Edward Tufte",
      "screen_name" : "EdwardTufte",
      "indices" : [ 61, 73 ],
      "id_str" : "152862026",
      "id" : 152862026
    }, {
      "name" : "Simon Pampena",
      "screen_name" : "mathemaniac",
      "indices" : [ 79, 91 ],
      "id_str" : "33852840",
      "id" : 33852840
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/mathemaniac\/status\/554205168149884928\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/df7RDonmvI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B7Duqf-CYAAHnmb.jpg",
      "id_str" : "554205168070189056",
      "id" : 554205168070189056,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B7Duqf-CYAAHnmb.jpg",
      "sizes" : [ {
        "h" : 384,
        "resize" : "fit",
        "w" : 487
      }, {
        "h" : 384,
        "resize" : "fit",
        "w" : 487
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 268,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 384,
        "resize" : "fit",
        "w" : 487
      } ],
      "display_url" : "pic.twitter.com\/df7RDonmvI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "554309598346485761",
  "text" : "RT @Asaf_Bitton: Fantastic visual representation of data (cc @EdwardTufte ) RT @mathemaniac: Letter Frequency Keyboard Histogram http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Edward Tufte",
        "screen_name" : "EdwardTufte",
        "indices" : [ 44, 56 ],
        "id_str" : "152862026",
        "id" : 152862026
      }, {
        "name" : "Simon Pampena",
        "screen_name" : "mathemaniac",
        "indices" : [ 62, 74 ],
        "id_str" : "33852840",
        "id" : 33852840
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/mathemaniac\/status\/554205168149884928\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/df7RDonmvI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B7Duqf-CYAAHnmb.jpg",
        "id_str" : "554205168070189056",
        "id" : 554205168070189056,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B7Duqf-CYAAHnmb.jpg",
        "sizes" : [ {
          "h" : 384,
          "resize" : "fit",
          "w" : 487
        }, {
          "h" : 384,
          "resize" : "fit",
          "w" : 487
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 268,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 384,
          "resize" : "fit",
          "w" : 487
        } ],
        "display_url" : "pic.twitter.com\/df7RDonmvI"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "554205168149884928",
    "geo" : { },
    "id_str" : "554301885281480704",
    "in_reply_to_user_id" : 33852840,
    "text" : "Fantastic visual representation of data (cc @EdwardTufte ) RT @mathemaniac: Letter Frequency Keyboard Histogram http:\/\/t.co\/df7RDonmvI",
    "id" : 554301885281480704,
    "in_reply_to_status_id" : 554205168149884928,
    "created_at" : "2015-01-11 15:40:42 +0000",
    "in_reply_to_screen_name" : "mathemaniac",
    "in_reply_to_user_id_str" : "33852840",
    "user" : {
      "name" : "Asaf Bitton",
      "screen_name" : "Asaf_Bitton",
      "protected" : false,
      "id_str" : "376476158",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2828873204\/b81c88e24a4a09105bdee56c47410b3d_normal.png",
      "id" : 376476158,
      "verified" : false
    }
  },
  "id" : 554309598346485761,
  "created_at" : "2015-01-11 16:11:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 0, 11 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "554263655488176128",
  "geo" : { },
  "id_str" : "554271589844668416",
  "in_reply_to_user_id" : 88202140,
  "text" : "@hughdellar congrats :) are you able to archive the posts Andrew did at Westminster CELT?",
  "id" : 554271589844668416,
  "in_reply_to_status_id" : 554263655488176128,
  "created_at" : "2015-01-11 13:40:19 +0000",
  "in_reply_to_screen_name" : "hughdellar",
  "in_reply_to_user_id_str" : "88202140",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "indices" : [ 3, 14 ],
      "id_str" : "88202140",
      "id" : 88202140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/rkxpWRZPEK",
      "expanded_url" : "http:\/\/www.lexicallab.com",
      "display_url" : "lexicallab.com"
    } ]
  },
  "geo" : { },
  "id_str" : "554264663203266560",
  "text" : "RT @hughdellar: Delighted to announce that our new website is finally up and running: http:\/\/t.co\/rkxpWRZPEK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/rkxpWRZPEK",
        "expanded_url" : "http:\/\/www.lexicallab.com",
        "display_url" : "lexicallab.com"
      } ]
    },
    "geo" : { },
    "id_str" : "554263655488176128",
    "text" : "Delighted to announce that our new website is finally up and running: http:\/\/t.co\/rkxpWRZPEK",
    "id" : 554263655488176128,
    "created_at" : "2015-01-11 13:08:47 +0000",
    "user" : {
      "name" : "hugh dellar",
      "screen_name" : "hughdellar",
      "protected" : false,
      "id_str" : "88202140",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2040881292\/Hugh_Dellar_photo_normal.jpg",
      "id" : 88202140,
      "verified" : false
    }
  },
  "id" : 554264663203266560,
  "created_at" : "2015-01-11 13:12:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/amYiBqRKaH",
      "expanded_url" : "https:\/\/zcomm.org\/znetarticle\/we-are-all-fill-in-the-blank\/",
      "display_url" : "zcomm.org\/znetarticle\/we\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "554229466239889409",
  "text" : "RT @medialens: Must-read from Noam Chomsky on Paris attacks https:\/\/t.co\/amYiBqRKaH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 68 ],
        "url" : "https:\/\/t.co\/amYiBqRKaH",
        "expanded_url" : "https:\/\/zcomm.org\/znetarticle\/we-are-all-fill-in-the-blank\/",
        "display_url" : "zcomm.org\/znetarticle\/we\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "554197839182823424",
    "text" : "Must-read from Noam Chomsky on Paris attacks https:\/\/t.co\/amYiBqRKaH",
    "id" : 554197839182823424,
    "created_at" : "2015-01-11 08:47:16 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 554229466239889409,
  "created_at" : "2015-01-11 10:52:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/9Qb0UoBY2e",
      "expanded_url" : "http:\/\/fw.to\/getR6fC",
      "display_url" : "fw.to\/getR6fC"
    } ]
  },
  "geo" : { },
  "id_str" : "554227858319478785",
  "text" : "In the Mideast, as in France, satire is a weapon against extremists http:\/\/t.co\/9Qb0UoBY2e",
  "id" : 554227858319478785,
  "created_at" : "2015-01-11 10:46:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Fry",
      "screen_name" : "stephenfry",
      "indices" : [ 12, 23 ],
      "id_str" : "15439395",
      "id" : 15439395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "554225943460732929",
  "text" : "i wonder if @StephenFry  would be offended by saying he knows sod all about technology?",
  "id" : 554225943460732929,
  "created_at" : "2015-01-11 10:38:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "554063798722899968",
  "geo" : { },
  "id_str" : "554216132815908864",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco thanks for sharing :)",
  "id" : 554216132815908864,
  "in_reply_to_status_id" : 554063798722899968,
  "created_at" : "2015-01-11 09:59:57 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Douglas Carnall",
      "screen_name" : "JuliuzBeezer",
      "indices" : [ 3, 16 ],
      "id_str" : "25936824",
      "id" : 25936824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/MFldhu3H6x",
      "expanded_url" : "http:\/\/www.twitlonger.com\/show\/n_1sjsjkl",
      "display_url" : "twitlonger.com\/show\/n_1sjsjkl"
    } ]
  },
  "geo" : { },
  "id_str" : "554215738282885121",
  "text" : "RT @JuliuzBeezer: Malgr\u00E9 notre fameuse libert\u00E9 d'expression, je n'ai pas vu une critique aussi dur des forces de s\u00E9curit\u00E9 en fran\u00E7ais\u2026 http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/MFldhu3H6x",
        "expanded_url" : "http:\/\/www.twitlonger.com\/show\/n_1sjsjkl",
        "display_url" : "twitlonger.com\/show\/n_1sjsjkl"
      } ]
    },
    "geo" : { },
    "id_str" : "554213331620618240",
    "text" : "Malgr\u00E9 notre fameuse libert\u00E9 d'expression, je n'ai pas vu une critique aussi dur des forces de s\u00E9curit\u00E9 en fran\u00E7ais\u2026 http:\/\/t.co\/MFldhu3H6x",
    "id" : 554213331620618240,
    "created_at" : "2015-01-11 09:48:49 +0000",
    "user" : {
      "name" : "Douglas Carnall",
      "screen_name" : "JuliuzBeezer",
      "protected" : false,
      "id_str" : "25936824",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/114211651\/robert_burns247x165_normal.jpg",
      "id" : 25936824,
      "verified" : false
    }
  },
  "id" : 554215738282885121,
  "created_at" : "2015-01-11 09:58:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Welsh not British",
      "screen_name" : "welshnotbritish",
      "indices" : [ 3, 19 ],
      "id_str" : "303429700",
      "id" : 303429700
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/welshnotbritish\/status\/554010873992589313\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/kYTbQ1u6Oe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B7A99CxIUAMi2WR.jpg",
      "id_str" : "554010873090822147",
      "id" : 554010873090822147,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B7A99CxIUAMi2WR.jpg",
      "sizes" : [ {
        "h" : 532,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 550,
        "resize" : "fit",
        "w" : 620
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 302,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 550,
        "resize" : "fit",
        "w" : 620
      } ],
      "display_url" : "pic.twitter.com\/kYTbQ1u6Oe"
    } ],
    "hashtags" : [ {
      "text" : "RoyalParasites",
      "indices" : [ 38, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/uP4kZEAf0T",
      "expanded_url" : "http:\/\/www.bbc.co.uk\/news\/uk-england-30759303",
      "display_url" : "bbc.co.uk\/news\/uk-englan\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "554014516997275649",
  "text" : "RT @welshnotbritish: We've bought the #RoyalParasites a \u00A313m ski lodge. Well done everyone! http:\/\/t.co\/uP4kZEAf0T http:\/\/t.co\/kYTbQ1u6Oe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/welshnotbritish\/status\/554010873992589313\/photo\/1",
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/kYTbQ1u6Oe",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B7A99CxIUAMi2WR.jpg",
        "id_str" : "554010873090822147",
        "id" : 554010873090822147,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B7A99CxIUAMi2WR.jpg",
        "sizes" : [ {
          "h" : 532,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 550,
          "resize" : "fit",
          "w" : 620
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 302,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 550,
          "resize" : "fit",
          "w" : 620
        } ],
        "display_url" : "pic.twitter.com\/kYTbQ1u6Oe"
      } ],
      "hashtags" : [ {
        "text" : "RoyalParasites",
        "indices" : [ 17, 32 ]
      } ],
      "urls" : [ {
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/uP4kZEAf0T",
        "expanded_url" : "http:\/\/www.bbc.co.uk\/news\/uk-england-30759303",
        "display_url" : "bbc.co.uk\/news\/uk-englan\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "554010873992589313",
    "text" : "We've bought the #RoyalParasites a \u00A313m ski lodge. Well done everyone! http:\/\/t.co\/uP4kZEAf0T http:\/\/t.co\/kYTbQ1u6Oe",
    "id" : 554010873992589313,
    "created_at" : "2015-01-10 20:24:20 +0000",
    "user" : {
      "name" : "Welsh not British",
      "screen_name" : "welshnotbritish",
      "protected" : false,
      "id_str" : "303429700",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/639477893924564992\/MZGR5nLW_normal.png",
      "id" : 303429700,
      "verified" : false
    }
  },
  "id" : 554014516997275649,
  "created_at" : "2015-01-10 20:38:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELT MAKERS",
      "screen_name" : "ELTMAKERS",
      "indices" : [ 0, 10 ],
      "id_str" : "2894570578",
      "id" : 2894570578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/7ZgbU45VI0",
      "expanded_url" : "http:\/\/phave-dictionary.englishup.me",
      "display_url" : "phave-dictionary.englishup.me"
    } ]
  },
  "in_reply_to_status_id_str" : "553968492576509952",
  "geo" : { },
  "id_str" : "553995902671912960",
  "in_reply_to_user_id" : 2894570578,
  "text" : "@ELTMAKERS oh forgot to say u may also like PHaVE phrasal verb dictionary http:\/\/t.co\/7ZgbU45VI0",
  "id" : 553995902671912960,
  "in_reply_to_status_id" : 553968492576509952,
  "created_at" : "2015-01-10 19:24:50 +0000",
  "in_reply_to_screen_name" : "ELTMAKERS",
  "in_reply_to_user_id_str" : "2894570578",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELT MAKERS",
      "screen_name" : "ELTMAKERS",
      "indices" : [ 3, 13 ],
      "id_str" : "2894570578",
      "id" : 2894570578
    }, {
      "name" : "Mura Nava",
      "screen_name" : "muranava",
      "indices" : [ 98, 107 ],
      "id_str" : "18602422",
      "id" : 18602422
    }, {
      "name" : "Hancock McDonald ELT",
      "screen_name" : "HancockMcDonald",
      "indices" : [ 112, 128 ],
      "id_str" : "552929354",
      "id" : 552929354
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/7me6uCV74g",
      "expanded_url" : "http:\/\/hancockmcdonald.com\/blog\/marks-vowel-sound-chart",
      "display_url" : "hancockmcdonald.com\/blog\/marks-vow\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "553984080870924289",
  "text" : "RT @ELTMAKERS: http:\/\/t.co\/7me6uCV74g This Make-Your-Own Phonemic Chart is catching on. Well done @muranava and @HancockMcDonald",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mura Nava",
        "screen_name" : "muranava",
        "indices" : [ 83, 92 ],
        "id_str" : "18602422",
        "id" : 18602422
      }, {
        "name" : "Hancock McDonald ELT",
        "screen_name" : "HancockMcDonald",
        "indices" : [ 97, 113 ],
        "id_str" : "552929354",
        "id" : 552929354
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/7me6uCV74g",
        "expanded_url" : "http:\/\/hancockmcdonald.com\/blog\/marks-vowel-sound-chart",
        "display_url" : "hancockmcdonald.com\/blog\/marks-vow\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "553968492576509952",
    "text" : "http:\/\/t.co\/7me6uCV74g This Make-Your-Own Phonemic Chart is catching on. Well done @muranava and @HancockMcDonald",
    "id" : 553968492576509952,
    "created_at" : "2015-01-10 17:35:55 +0000",
    "user" : {
      "name" : "ELT MAKERS",
      "screen_name" : "ELTMAKERS",
      "protected" : false,
      "id_str" : "2894570578",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/537944364534611969\/BegFDTeR_normal.png",
      "id" : 2894570578,
      "verified" : false
    }
  },
  "id" : 553984080870924289,
  "created_at" : "2015-01-10 18:37:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ELT MAKERS",
      "screen_name" : "ELTMAKERS",
      "indices" : [ 0, 10 ],
      "id_str" : "2894570578",
      "id" : 2894570578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "553968492576509952",
  "geo" : { },
  "id_str" : "553984060394340352",
  "in_reply_to_user_id" : 2894570578,
  "text" : "@ELTMAKERS cheers for share hope your Sat is going well :)",
  "id" : 553984060394340352,
  "in_reply_to_status_id" : 553968492576509952,
  "created_at" : "2015-01-10 18:37:47 +0000",
  "in_reply_to_screen_name" : "ELTMAKERS",
  "in_reply_to_user_id_str" : "2894570578",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Ford",
      "screen_name" : "EdSacredProfane",
      "indices" : [ 100, 116 ],
      "id_str" : "2288627443",
      "id" : 2288627443
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/wm07gbt9sX",
      "expanded_url" : "http:\/\/wp.me\/p4c373-wI",
      "display_url" : "wp.me\/p4c373-wI"
    } ]
  },
  "geo" : { },
  "id_str" : "553914966223237120",
  "text" : "Is growth mind set the power of \"not yet\" or the politics of \"not ever\"? http:\/\/t.co\/wm07gbt9sX via @EdSacredProfane",
  "id" : 553914966223237120,
  "created_at" : "2015-01-10 14:03:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 0, 12 ],
      "id_str" : "223771625",
      "id" : 223771625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "553847246505402368",
  "geo" : { },
  "id_str" : "553910923279474688",
  "in_reply_to_user_id" : 223771625,
  "text" : "@johnwhilley some good points by will self but use of \"Islamic terrorism\" plays into state narrative why not just terrorism?",
  "id" : 553910923279474688,
  "in_reply_to_status_id" : 553847246505402368,
  "created_at" : "2015-01-10 13:47:09 +0000",
  "in_reply_to_screen_name" : "johnwhilley",
  "in_reply_to_user_id_str" : "223771625",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JeSuisCharlie",
      "indices" : [ 28, 42 ]
    }, {
      "text" : "WillSelf",
      "indices" : [ 86, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/kEC6e2V7rK",
      "expanded_url" : "http:\/\/www.channel4.com\/news\/will-self-martin-rowson-cartoon-charlie-hebdo-satire-video",
      "display_url" : "channel4.com\/news\/will-self\u2026"
    }, {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/zVmWzgjlHz",
      "expanded_url" : "http:\/\/www.theguardian.com\/world\/ng-interactive\/2015\/jan\/09\/joe-sacco-on-satire-a-response-to-the-attacks?CMP=twt_gu",
      "display_url" : "theguardian.com\/world\/ng-inter\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "553909112388747264",
  "text" : "RT @johnwhilley: Beyond the #JeSuisCharlie and Voltairian hype, essential truths from #WillSelf http:\/\/t.co\/kEC6e2V7rK and Joe Sacco http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JeSuisCharlie",
        "indices" : [ 11, 25 ]
      }, {
        "text" : "WillSelf",
        "indices" : [ 69, 78 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/kEC6e2V7rK",
        "expanded_url" : "http:\/\/www.channel4.com\/news\/will-self-martin-rowson-cartoon-charlie-hebdo-satire-video",
        "display_url" : "channel4.com\/news\/will-self\u2026"
      }, {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/zVmWzgjlHz",
        "expanded_url" : "http:\/\/www.theguardian.com\/world\/ng-interactive\/2015\/jan\/09\/joe-sacco-on-satire-a-response-to-the-attacks?CMP=twt_gu",
        "display_url" : "theguardian.com\/world\/ng-inter\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "553847246505402368",
    "text" : "Beyond the #JeSuisCharlie and Voltairian hype, essential truths from #WillSelf http:\/\/t.co\/kEC6e2V7rK and Joe Sacco http:\/\/t.co\/zVmWzgjlHz",
    "id" : 553847246505402368,
    "created_at" : "2015-01-10 09:34:08 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 553909112388747264,
  "created_at" : "2015-01-10 13:39:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "553683378545774593",
  "geo" : { },
  "id_str" : "553683719324958721",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow yeah gonna be a strange w\/e and few weeks i think over here",
  "id" : 553683719324958721,
  "in_reply_to_status_id" : 553683378545774593,
  "created_at" : "2015-01-09 22:44:20 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 55, 66 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/9vCZoHwstl",
      "expanded_url" : "http:\/\/wp.me\/p4dmjk-cC",
      "display_url" : "wp.me\/p4dmjk-cC"
    } ]
  },
  "geo" : { },
  "id_str" : "553683040132538368",
  "text" : "Why not leave it up to them http:\/\/t.co\/9vCZoHwstl via @kevchanwow",
  "id" : 553683040132538368,
  "created_at" : "2015-01-09 22:41:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vedrana Vojkovi\u0107",
      "screen_name" : "Ven_VVE",
      "indices" : [ 0, 8 ],
      "id_str" : "270839603",
      "id" : 270839603
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "553660623218049024",
  "geo" : { },
  "id_str" : "553674372268195840",
  "in_reply_to_user_id" : 270839603,
  "text" : "@Ven_VVE hi fine thanks was at work all day so missed everything",
  "id" : 553674372268195840,
  "in_reply_to_status_id" : 553660623218049024,
  "created_at" : "2015-01-09 22:07:11 +0000",
  "in_reply_to_screen_name" : "Ven_VVE",
  "in_reply_to_user_id_str" : "270839603",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/553659225361350657\/photo\/1",
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/GgZYRuYUUn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B67-IW1IMAEzU2u.jpg",
      "id_str" : "553659223733972993",
      "id" : 553659223733972993,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B67-IW1IMAEzU2u.jpg",
      "sizes" : [ {
        "h" : 1824,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1150
      }, {
        "h" : 1069,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 605,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/GgZYRuYUUn"
    } ],
    "hashtags" : [ {
      "text" : "prisedotage",
      "indices" : [ 36, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "553659225361350657",
  "text" : "aftermath afterwork down the street #prisedotage http:\/\/t.co\/GgZYRuYUUn",
  "id" : 553659225361350657,
  "created_at" : "2015-01-09 21:07:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 0, 9 ],
      "id_str" : "121063600",
      "id" : 121063600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "552815599307743232",
  "geo" : { },
  "id_str" : "552886054748188672",
  "in_reply_to_user_id" : 121063600,
  "text" : "@whyshona hi actually use web interface and just happened to catch that tweet :)",
  "id" : 552886054748188672,
  "in_reply_to_status_id" : 552815599307743232,
  "created_at" : "2015-01-07 17:54:42 +0000",
  "in_reply_to_screen_name" : "whyshona",
  "in_reply_to_user_id_str" : "121063600",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patricia Daniels",
      "screen_name" : "trishiels",
      "indices" : [ 0, 10 ],
      "id_str" : "477667955",
      "id" : 477667955
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpora",
      "indices" : [ 43, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "552558986877489152",
  "in_reply_to_user_id" : 477667955,
  "text" : "@trishiels @JournalETAS thanks for sharing #corpora in ELT survey G+ post :)",
  "id" : 552558986877489152,
  "created_at" : "2015-01-06 20:15:03 +0000",
  "in_reply_to_screen_name" : "trishiels",
  "in_reply_to_user_id_str" : "477667955",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 18, 22 ]
    }, {
      "text" : "corpora",
      "indices" : [ 57, 65 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 74, 82 ]
    }, {
      "text" : "eltchinwag",
      "indices" : [ 83, 94 ]
    }, {
      "text" : "TEFL",
      "indices" : [ 95, 100 ]
    }, {
      "text" : "besig",
      "indices" : [ 101, 107 ]
    }, {
      "text" : "tleap",
      "indices" : [ 108, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/2HYzIUON2U",
      "expanded_url" : "https:\/\/plus.google.com\/104940199413423400545\/posts\/T1g8vYXtRSJ",
      "display_url" : "plus.google.com\/10494019941342\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "552467487489810432",
  "text" : "find out what 560 #elt bods from 63 countries thought of #corpora in 2012 #eltchat #eltchinwag #TEFL #besig #tleap https:\/\/t.co\/2HYzIUON2U",
  "id" : 552467487489810432,
  "created_at" : "2015-01-06 14:11:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 13, 24 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "552445756682956800",
  "geo" : { },
  "id_str" : "552456674586660865",
  "in_reply_to_user_id" : 1558541821,
  "text" : "@JournalETAS @kevchanwow i often use this great story highly recommended :)",
  "id" : 552456674586660865,
  "in_reply_to_status_id" : 552445756682956800,
  "created_at" : "2015-01-06 13:28:30 +0000",
  "in_reply_to_screen_name" : "ETAS_CH",
  "in_reply_to_user_id_str" : "1558541821",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "neurobollocks",
      "screen_name" : "neurobollocks",
      "indices" : [ 0, 14 ],
      "id_str" : "1221025892",
      "id" : 1221025892
    }, {
      "name" : "AnthonyTeacher",
      "screen_name" : "AnthonyTeacher",
      "indices" : [ 26, 41 ],
      "id_str" : "285614027",
      "id" : 285614027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "552240837128904704",
  "geo" : { },
  "id_str" : "552249583083212800",
  "in_reply_to_user_id" : 1221025892,
  "text" : "@neurobollocks @_FTaylor_ @AnthonyTeacher like crit thinking, creativity can it be taught? if so is it worth teaching over subject matter?",
  "id" : 552249583083212800,
  "in_reply_to_status_id" : 552240837128904704,
  "created_at" : "2015-01-05 23:45:35 +0000",
  "in_reply_to_screen_name" : "neurobollocks",
  "in_reply_to_user_id_str" : "1221025892",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chiew Pang",
      "screen_name" : "aClilToClimb",
      "indices" : [ 3, 16 ],
      "id_str" : "76160458",
      "id" : 76160458
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Linguistics",
      "indices" : [ 18, 30 ]
    }, {
      "text" : "efl",
      "indices" : [ 109, 113 ]
    }, {
      "text" : "esl",
      "indices" : [ 114, 118 ]
    }, {
      "text" : "grammar",
      "indices" : [ 119, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/RIPbDuN8TB",
      "expanded_url" : "http:\/\/linguistics-research-digest.blogspot.com\/2015\/01\/the-truth-about-british-tag-questions.html?spref=tw",
      "display_url" : "\u2026guistics-research-digest.blogspot.com\/2015\/01\/the-tr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "552213143888601089",
  "text" : "RT @aClilToClimb: #Linguistics Research Digest: The truth about British tag questions http:\/\/t.co\/RIPbDuN8TB #efl #esl #grammar",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Linguistics",
        "indices" : [ 0, 12 ]
      }, {
        "text" : "efl",
        "indices" : [ 91, 95 ]
      }, {
        "text" : "esl",
        "indices" : [ 96, 100 ]
      }, {
        "text" : "grammar",
        "indices" : [ 101, 109 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/RIPbDuN8TB",
        "expanded_url" : "http:\/\/linguistics-research-digest.blogspot.com\/2015\/01\/the-truth-about-british-tag-questions.html?spref=tw",
        "display_url" : "\u2026guistics-research-digest.blogspot.com\/2015\/01\/the-tr\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "552183383078338560",
    "text" : "#Linguistics Research Digest: The truth about British tag questions http:\/\/t.co\/RIPbDuN8TB #efl #esl #grammar",
    "id" : 552183383078338560,
    "created_at" : "2015-01-05 19:22:32 +0000",
    "user" : {
      "name" : "Chiew Pang",
      "screen_name" : "aClilToClimb",
      "protected" : false,
      "id_str" : "76160458",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/501473384681578496\/DUT-NmBS_normal.jpeg",
      "id" : 76160458,
      "verified" : false
    }
  },
  "id" : 552213143888601089,
  "created_at" : "2015-01-05 21:20:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 83, 92 ],
      "id_str" : "121063600",
      "id" : 121063600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/OBAqSqhEsY",
      "expanded_url" : "http:\/\/wp.me\/p28EmH-5z",
      "display_url" : "wp.me\/p28EmH-5z"
    } ]
  },
  "geo" : { },
  "id_str" : "552056297470709762",
  "text" : "Analysing learners' language: a method to their madness http:\/\/t.co\/OBAqSqhEsY via @whyshona",
  "id" : 552056297470709762,
  "created_at" : "2015-01-05 10:57:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Google OS",
      "screen_name" : "googleos",
      "indices" : [ 3, 12 ],
      "id_str" : "7882062",
      "id" : 7882062
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/googleos\/status\/551691803435741184\/photo\/1",
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/Z6CI7gbdCR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B6gAxa2IEAAxkUU.png",
      "id_str" : "551691803372818432",
      "id" : 551691803372818432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B6gAxa2IEAAxkUU.png",
      "sizes" : [ {
        "h" : 523,
        "resize" : "fit",
        "w" : 526
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 523,
        "resize" : "fit",
        "w" : 526
      }, {
        "h" : 523,
        "resize" : "fit",
        "w" : 526
      } ],
      "display_url" : "pic.twitter.com\/Z6CI7gbdCR"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/qaZXCnaDJ5",
      "expanded_url" : "http:\/\/ift.tt\/1IbqIJe",
      "display_url" : "ift.tt\/1IbqIJe"
    } ]
  },
  "geo" : { },
  "id_str" : "551996356014129154",
  "text" : "RT @googleos: Find In-Depth Articles http:\/\/t.co\/qaZXCnaDJ5 http:\/\/t.co\/Z6CI7gbdCR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/googleos\/status\/551691803435741184\/photo\/1",
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/Z6CI7gbdCR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B6gAxa2IEAAxkUU.png",
        "id_str" : "551691803372818432",
        "id" : 551691803372818432,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B6gAxa2IEAAxkUU.png",
        "sizes" : [ {
          "h" : 523,
          "resize" : "fit",
          "w" : 526
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 523,
          "resize" : "fit",
          "w" : 526
        }, {
          "h" : 523,
          "resize" : "fit",
          "w" : 526
        } ],
        "display_url" : "pic.twitter.com\/Z6CI7gbdCR"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 23, 45 ],
        "url" : "http:\/\/t.co\/qaZXCnaDJ5",
        "expanded_url" : "http:\/\/ift.tt\/1IbqIJe",
        "display_url" : "ift.tt\/1IbqIJe"
      } ]
    },
    "geo" : { },
    "id_str" : "551691803435741184",
    "text" : "Find In-Depth Articles http:\/\/t.co\/qaZXCnaDJ5 http:\/\/t.co\/Z6CI7gbdCR",
    "id" : 551691803435741184,
    "created_at" : "2015-01-04 10:49:10 +0000",
    "user" : {
      "name" : "Google OS",
      "screen_name" : "googleos",
      "protected" : false,
      "id_str" : "7882062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000547329752\/f5983f1690922b6292a581837fd4bba0_normal.png",
      "id" : 7882062,
      "verified" : false
    }
  },
  "id" : 551996356014129154,
  "created_at" : "2015-01-05 06:59:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Strong Language",
      "screen_name" : "stronglang",
      "indices" : [ 89, 100 ],
      "id_str" : "2918426355",
      "id" : 2918426355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/XfB8flmuiX",
      "expanded_url" : "http:\/\/stronglang.wordpress.com\/2015\/01\/05\/getting-a-grip-on-masturbation\/",
      "display_url" : "stronglang.wordpress.com\/2015\/01\/05\/get\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "551986917198540800",
  "text" : "It\u2019s hard to get a grip on the corpus data for\u00A0masturbate  :) http:\/\/t.co\/XfB8flmuiX via @stronglang",
  "id" : 551986917198540800,
  "created_at" : "2015-01-05 06:21:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Swindon",
      "screen_name" : "jon_swindon",
      "indices" : [ 0, 12 ],
      "id_str" : "240848324",
      "id" : 240848324
    }, {
      "name" : "Bella Caledonia",
      "screen_name" : "bellacaledonia",
      "indices" : [ 13, 28 ],
      "id_str" : "103554348",
      "id" : 103554348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "551713266159079424",
  "geo" : { },
  "id_str" : "551822850056007680",
  "in_reply_to_user_id" : 240848324,
  "text" : "@jon_swindon @bellacaledonia debt +repayments+ is lower than in past",
  "id" : 551822850056007680,
  "in_reply_to_status_id" : 551713266159079424,
  "created_at" : "2015-01-04 19:29:54 +0000",
  "in_reply_to_screen_name" : "jon_swindon",
  "in_reply_to_user_id_str" : "240848324",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicola Prentis",
      "screen_name" : "NicolaPrentis",
      "indices" : [ 0, 14 ],
      "id_str" : "810667033",
      "id" : 810667033
    }, {
      "name" : "Vedrana Vojkovi\u0107",
      "screen_name" : "Ven_VVE",
      "indices" : [ 15, 23 ],
      "id_str" : "270839603",
      "id" : 270839603
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "551707127166038017",
  "geo" : { },
  "id_str" : "551726200234995712",
  "in_reply_to_user_id" : 810667033,
  "text" : "@NicolaPrentis @Ven_VVE can a funded study be 'independent' from its funders? interesting result on travel reasons having major effect",
  "id" : 551726200234995712,
  "in_reply_to_status_id" : 551707127166038017,
  "created_at" : "2015-01-04 13:05:51 +0000",
  "in_reply_to_screen_name" : "NicolaPrentis",
  "in_reply_to_user_id_str" : "810667033",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/dRhPwKWAez",
      "expanded_url" : "http:\/\/www.counterpunch.org\/2015\/01\/02\/the-true-relationship-between-crime-and-law-enforcement\/#.VKkVv0LCXa0.twitter",
      "display_url" : "counterpunch.org\/2015\/01\/02\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "551686577257066497",
  "text" : "The True Relationship Between Crime and Law Enforcement \u00BB CounterPunch: Tells the Facts, Names the Names http:\/\/t.co\/dRhPwKWAez",
  "id" : 551686577257066497,
  "created_at" : "2015-01-04 10:28:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon J. Eason",
      "screen_name" : "sjeason",
      "indices" : [ 0, 8 ],
      "id_str" : "258401804",
      "id" : 258401804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "551521961076359169",
  "text" : "@sjeason cheers let me know if u have any suggestions on how to improve interface",
  "id" : 551521961076359169,
  "created_at" : "2015-01-03 23:34:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon J. Eason",
      "screen_name" : "sjeason",
      "indices" : [ 0, 8 ],
      "id_str" : "258401804",
      "id" : 258401804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "551521793530691584",
  "text" : "@sjeason i think head scratching and the accompanying thinking may burn as many if not more calories than gym work :)",
  "id" : 551521793530691584,
  "created_at" : "2015-01-03 23:33:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon J. Eason",
      "screen_name" : "sjeason",
      "indices" : [ 44, 52 ],
      "id_str" : "258401804",
      "id" : 258401804
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/551513397440032771\/photo\/1",
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/W4wjb5uipj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B6deguaCMAAXWlL.png",
      "id_str" : "551513395682226176",
      "id" : 551513395682226176,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B6deguaCMAAXWlL.png",
      "sizes" : [ {
        "h" : 282,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 773
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 773
      }, {
        "h" : 497,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/W4wjb5uipj"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/h7CwAgQZ2b",
      "expanded_url" : "http:\/\/phave-dictionary.englishup.me\/",
      "display_url" : "phave-dictionary.englishup.me"
    } ]
  },
  "geo" : { },
  "id_str" : "551513397440032771",
  "text" : "and are we sure of the meaning of work out? @sjeason :) http:\/\/t.co\/h7CwAgQZ2b http:\/\/t.co\/W4wjb5uipj",
  "id" : 551513397440032771,
  "created_at" : "2015-01-03 23:00:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CPFA",
      "screen_name" : "cpfa_forum",
      "indices" : [ 3, 14 ],
      "id_str" : "213526636",
      "id" : 213526636
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/GJ29KA8hpv",
      "expanded_url" : "http:\/\/bit.ly\/13Pdswg",
      "display_url" : "bit.ly\/13Pdswg"
    } ]
  },
  "geo" : { },
  "id_str" : "551490702627311616",
  "text" : "RT @cpfa_forum: Leftists Must Expose Budget Deficit Scams | Opinion | teleSUR http:\/\/t.co\/GJ29KA8hpv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 84 ],
        "url" : "http:\/\/t.co\/GJ29KA8hpv",
        "expanded_url" : "http:\/\/bit.ly\/13Pdswg",
        "display_url" : "bit.ly\/13Pdswg"
      } ]
    },
    "geo" : { },
    "id_str" : "551462019476381696",
    "text" : "Leftists Must Expose Budget Deficit Scams | Opinion | teleSUR http:\/\/t.co\/GJ29KA8hpv",
    "id" : 551462019476381696,
    "created_at" : "2015-01-03 19:36:05 +0000",
    "user" : {
      "name" : "CPFA",
      "screen_name" : "cpfa_forum",
      "protected" : false,
      "id_str" : "213526636",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1163005517\/cpfa_logo_layout_top_normal.gif",
      "id" : 213526636,
      "verified" : false
    }
  },
  "id" : 551490702627311616,
  "created_at" : "2015-01-03 21:30:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Adele Soracco",
      "screen_name" : "LauraSoracco",
      "indices" : [ 0, 13 ],
      "id_str" : "15663328",
      "id" : 15663328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "551477759990439938",
  "geo" : { },
  "id_str" : "551482997548253185",
  "in_reply_to_user_id" : 15663328,
  "text" : "@LauraSoracco that is the best resolution in this or any year, no bias, happy new year Laura :)",
  "id" : 551482997548253185,
  "in_reply_to_status_id" : 551477759990439938,
  "created_at" : "2015-01-03 20:59:27 +0000",
  "in_reply_to_screen_name" : "LauraSoracco",
  "in_reply_to_user_id_str" : "15663328",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 0, 9 ],
      "id_str" : "121063600",
      "id" : 121063600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "551415089853906944",
  "geo" : { },
  "id_str" : "551418420500393985",
  "in_reply_to_user_id" : 121063600,
  "text" : "@whyshona thanks i'll have a look",
  "id" : 551418420500393985,
  "in_reply_to_status_id" : 551415089853906944,
  "created_at" : "2015-01-03 16:42:50 +0000",
  "in_reply_to_screen_name" : "whyshona",
  "in_reply_to_user_id_str" : "121063600",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 0, 9 ],
      "id_str" : "121063600",
      "id" : 121063600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "551413145538158592",
  "geo" : { },
  "id_str" : "551413824650506240",
  "in_reply_to_user_id" : 121063600,
  "text" : "@whyshona that would be well cool! look fwd to any such news :)",
  "id" : 551413824650506240,
  "in_reply_to_status_id" : 551413145538158592,
  "created_at" : "2015-01-03 16:24:35 +0000",
  "in_reply_to_screen_name" : "whyshona",
  "in_reply_to_user_id_str" : "121063600",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 0, 9 ],
      "id_str" : "121063600",
      "id" : 121063600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "551317076145872897",
  "geo" : { },
  "id_str" : "551407187655155712",
  "in_reply_to_user_id" : 121063600,
  "text" : "@whyshona thanks v much for the share Shona, happy new year :)",
  "id" : 551407187655155712,
  "in_reply_to_status_id" : 551317076145872897,
  "created_at" : "2015-01-03 15:58:12 +0000",
  "in_reply_to_screen_name" : "whyshona",
  "in_reply_to_user_id_str" : "121063600",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wiktorkompe",
      "screen_name" : "wiktor_k",
      "indices" : [ 3, 12 ],
      "id_str" : "733704413383168000",
      "id" : 733704413383168000
    }, {
      "name" : "Jacobin",
      "screen_name" : "jacobinmag",
      "indices" : [ 36, 47 ],
      "id_str" : "170254080",
      "id" : 170254080
    }, {
      "name" : "Krytyka Polityczna",
      "screen_name" : "krytyka",
      "indices" : [ 54, 62 ],
      "id_str" : "26047562",
      "id" : 26047562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/L2GCcrxMC9",
      "expanded_url" : "http:\/\/buff.ly\/1wAXoVI",
      "display_url" : "buff.ly\/1wAXoVI"
    } ]
  },
  "geo" : { },
  "id_str" : "551294713601728512",
  "text" : "RT @Wiktor_K: In the Name of Love | @jacobinmag &amp; @krytyka http:\/\/t.co\/L2GCcrxMC9 - Send this to folks who urge you to \"do what you love.\" \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jacobin",
        "screen_name" : "jacobinmag",
        "indices" : [ 22, 33 ],
        "id_str" : "170254080",
        "id" : 170254080
      }, {
        "name" : "Krytyka Polityczna",
        "screen_name" : "krytyka",
        "indices" : [ 40, 48 ],
        "id_str" : "26047562",
        "id" : 26047562
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/L2GCcrxMC9",
        "expanded_url" : "http:\/\/buff.ly\/1wAXoVI",
        "display_url" : "buff.ly\/1wAXoVI"
      } ]
    },
    "geo" : { },
    "id_str" : "551122774933377024",
    "text" : "In the Name of Love | @jacobinmag &amp; @krytyka http:\/\/t.co\/L2GCcrxMC9 - Send this to folks who urge you to \"do what you love.\" Strong stuff.",
    "id" : 551122774933377024,
    "created_at" : "2015-01-02 21:08:03 +0000",
    "user" : {
      "name" : "BRAVE Learning",
      "screen_name" : "BRAVE_Learning",
      "protected" : false,
      "id_str" : "222498082",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714724460461473792\/_xHUkSmB_normal.jpg",
      "id" : 222498082,
      "verified" : false
    }
  },
  "id" : 551294713601728512,
  "created_at" : "2015-01-03 08:31:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "indices" : [ 3, 18 ],
      "id_str" : "152194866",
      "id" : 152194866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ODG",
      "indices" : [ 69, 73 ]
    }, {
      "text" : "reality",
      "indices" : [ 74, 82 ]
    }, {
      "text" : "topicmaps",
      "indices" : [ 83, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/lqtAqGcukq",
      "expanded_url" : "http:\/\/ow.ly\/GIUK7",
      "display_url" : "ow.ly\/GIUK7"
    } ]
  },
  "geo" : { },
  "id_str" : "551287687983161345",
  "text" : "RT @patrickDurusau: Augmented Reality or Same Old Sh*t (just closer) #ODG #reality #topicmaps http:\/\/t.co\/lqtAqGcukq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ODG",
        "indices" : [ 49, 53 ]
      }, {
        "text" : "reality",
        "indices" : [ 54, 62 ]
      }, {
        "text" : "topicmaps",
        "indices" : [ 63, 73 ]
      } ],
      "urls" : [ {
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/lqtAqGcukq",
        "expanded_url" : "http:\/\/ow.ly\/GIUK7",
        "display_url" : "ow.ly\/GIUK7"
      } ]
    },
    "geo" : { },
    "id_str" : "551271837108539392",
    "text" : "Augmented Reality or Same Old Sh*t (just closer) #ODG #reality #topicmaps http:\/\/t.co\/lqtAqGcukq",
    "id" : 551271837108539392,
    "created_at" : "2015-01-03 07:00:22 +0000",
    "user" : {
      "name" : "Patrick Durusau",
      "screen_name" : "patrickDurusau",
      "protected" : false,
      "id_str" : "152194866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/961579480\/patrick_normal.jpeg",
      "id" : 152194866,
      "verified" : false
    }
  },
  "id" : 551287687983161345,
  "created_at" : "2015-01-03 08:03:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 0, 13 ],
      "id_str" : "88655243",
      "id" : 88655243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "551283556610506753",
  "in_reply_to_user_id" : 88655243,
  "text" : "@rosemerebard thx v much for RT and happy new year Rose :)",
  "id" : 551283556610506753,
  "created_at" : "2015-01-03 07:46:56 +0000",
  "in_reply_to_screen_name" : "rosemerebard",
  "in_reply_to_user_id_str" : "88655243",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clare",
      "screen_name" : "languageeteach",
      "indices" : [ 0, 15 ],
      "id_str" : "2163604968",
      "id" : 2163604968
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "551131955342114817",
  "in_reply_to_user_id" : 2163604968,
  "text" : "@languageeteach thanks for sharing :) hope u had a good break",
  "id" : 551131955342114817,
  "created_at" : "2015-01-02 21:44:32 +0000",
  "in_reply_to_screen_name" : "languageeteach",
  "in_reply_to_user_id_str" : "2163604968",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jack Grieve",
      "screen_name" : "JWGrieve",
      "indices" : [ 3, 12 ],
      "id_str" : "2950391813",
      "id" : 2950391813
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "twitter",
      "indices" : [ 121, 129 ]
    }, {
      "text" : "bigdata",
      "indices" : [ 130, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/BqpsNwHst8",
      "expanded_url" : "https:\/\/sites.google.com\/site\/jackgrieveaston\/treesandtweets",
      "display_url" : "sites.google.com\/site\/jackgriev\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "551112992616902656",
  "text" : "RT @JWGrieve: Top 10 Newly Emerging Words of 2014: unbothered, gmfu, joggers, fuckboys, rekt,... https:\/\/t.co\/BqpsNwHst8 #twitter #bigdata",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "twitter",
        "indices" : [ 107, 115 ]
      }, {
        "text" : "bigdata",
        "indices" : [ 116, 124 ]
      } ],
      "urls" : [ {
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/BqpsNwHst8",
        "expanded_url" : "https:\/\/sites.google.com\/site\/jackgrieveaston\/treesandtweets",
        "display_url" : "sites.google.com\/site\/jackgriev\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "550836960517185536",
    "text" : "Top 10 Newly Emerging Words of 2014: unbothered, gmfu, joggers, fuckboys, rekt,... https:\/\/t.co\/BqpsNwHst8 #twitter #bigdata",
    "id" : 550836960517185536,
    "created_at" : "2015-01-02 02:12:20 +0000",
    "user" : {
      "name" : "Jack Grieve",
      "screen_name" : "JWGrieve",
      "protected" : false,
      "id_str" : "2950391813",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/654751793549697024\/B8qlBwTb_normal.jpg",
      "id" : 2950391813,
      "verified" : false
    }
  },
  "id" : 551112992616902656,
  "created_at" : "2015-01-02 20:29:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Serveis Ling\u00FC\u00EDstics",
      "screen_name" : "SLBCoop",
      "indices" : [ 0, 8 ],
      "id_str" : "2365399801",
      "id" : 2365399801
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "551085526883631105",
  "geo" : { },
  "id_str" : "551086905388204033",
  "in_reply_to_user_id" : 2365399801,
  "text" : "@SLBCoop nice vid thanks :)",
  "id" : 551086905388204033,
  "in_reply_to_status_id" : 551085526883631105,
  "created_at" : "2015-01-02 18:45:31 +0000",
  "in_reply_to_screen_name" : "SLBCoop",
  "in_reply_to_user_id_str" : "2365399801",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Duygu \u00C7andarl\u0131",
      "screen_name" : "duygucandarli",
      "indices" : [ 0, 14 ],
      "id_str" : "48839094",
      "id" : 48839094
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "551079395256188928",
  "in_reply_to_user_id" : 48839094,
  "text" : "@duygucandarli thanks a lot for the share, happy new year :)",
  "id" : 551079395256188928,
  "created_at" : "2015-01-02 18:15:41 +0000",
  "in_reply_to_screen_name" : "duygucandarli",
  "in_reply_to_user_id_str" : "48839094",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30B3\u30FC\u30D1\u30B9\u8A00\u8A9E\u5B66\u305F\u3093",
      "screen_name" : "CorpusTan",
      "indices" : [ 0, 10 ],
      "id_str" : "2309797189",
      "id" : 2309797189
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "551075801203245056",
  "in_reply_to_user_id" : 2309797189,
  "text" : "@CorpusTan thanks for RT hope u are well :)",
  "id" : 551075801203245056,
  "created_at" : "2015-01-02 18:01:24 +0000",
  "in_reply_to_screen_name" : "CorpusTan",
  "in_reply_to_user_id_str" : "2309797189",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Poole",
      "screen_name" : "RobertEPoole",
      "indices" : [ 0, 13 ],
      "id_str" : "18526186",
      "id" : 18526186
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "551072977178349569",
  "in_reply_to_user_id" : 18526186,
  "text" : "@RobertEPoole thanks for RT and reblog i think only second in my blogging life :)",
  "id" : 551072977178349569,
  "created_at" : "2015-01-02 17:50:10 +0000",
  "in_reply_to_screen_name" : "RobertEPoole",
  "in_reply_to_user_id_str" : "18526186",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Corpuslinguistics",
      "indices" : [ 0, 18 ]
    }, {
      "text" : "corpusmooc",
      "indices" : [ 59, 70 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 71, 79 ]
    }, {
      "text" : "keltchat",
      "indices" : [ 80, 89 ]
    }, {
      "text" : "auselt",
      "indices" : [ 90, 97 ]
    }, {
      "text" : "eltchinwag",
      "indices" : [ 98, 109 ]
    }, {
      "text" : "langchat",
      "indices" : [ 110, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/oZr2CJGbGK",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-Sj",
      "display_url" : "wp.me\/pgHyE-Sj"
    } ]
  },
  "geo" : { },
  "id_str" : "551064667317997568",
  "text" : "#Corpuslinguistics community news 4 http:\/\/t.co\/oZr2CJGbGK #corpusmooc #eltchat #keltchat #auselt #eltchinwag #langchat",
  "id" : 551064667317997568,
  "created_at" : "2015-01-02 17:17:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Harbinson",
      "screen_name" : "DavidHarbinson",
      "indices" : [ 3, 18 ],
      "id_str" : "853078675",
      "id" : 853078675
    }, {
      "name" : "Masters Of TESOL",
      "screen_name" : "motcast",
      "indices" : [ 24, 32 ],
      "id_str" : "2859583682",
      "id" : 2859583682
    }, {
      "name" : "Ahmar Mahboob",
      "screen_name" : "AhmarMahboob",
      "indices" : [ 103, 116 ],
      "id_str" : "1913077873",
      "id" : 1913077873
    }, {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 123, 139 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 143, 144 ],
      "url" : "http:\/\/t.co\/CNeRtSWp2m",
      "expanded_url" : "http:\/\/wp.me\/p5dOWM-1u",
      "display_url" : "wp.me\/p5dOWM-1u"
    } ]
  },
  "geo" : { },
  "id_str" : "551045769541988352",
  "text" : "RT @DavidHarbinson: MT \"@motcast: Happy New Year. I celebrated by finally releasing a new podcast with @AhmarMahboob &amp; @michaelegriffin \nht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Masters Of TESOL",
        "screen_name" : "motcast",
        "indices" : [ 4, 12 ],
        "id_str" : "2859583682",
        "id" : 2859583682
      }, {
        "name" : "Ahmar Mahboob",
        "screen_name" : "AhmarMahboob",
        "indices" : [ 83, 96 ],
        "id_str" : "1913077873",
        "id" : 1913077873
      }, {
        "name" : "Michael Griffin",
        "screen_name" : "michaelegriffin",
        "indices" : [ 103, 119 ],
        "id_str" : "394053348",
        "id" : 394053348
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/CNeRtSWp2m",
        "expanded_url" : "http:\/\/wp.me\/p5dOWM-1u",
        "display_url" : "wp.me\/p5dOWM-1u"
      } ]
    },
    "geo" : { },
    "id_str" : "551036082142191617",
    "text" : "MT \"@motcast: Happy New Year. I celebrated by finally releasing a new podcast with @AhmarMahboob &amp; @michaelegriffin \nhttp:\/\/t.co\/CNeRtSWp2m\"",
    "id" : 551036082142191617,
    "created_at" : "2015-01-02 15:23:34 +0000",
    "user" : {
      "name" : "David Harbinson",
      "screen_name" : "DavidHarbinson",
      "protected" : false,
      "id_str" : "853078675",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/524830685643538432\/NdyDn_ux_normal.jpeg",
      "id" : 853078675,
      "verified" : false
    }
  },
  "id" : 551045769541988352,
  "created_at" : "2015-01-02 16:02:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Olson",
      "screen_name" : "mark_olson",
      "indices" : [ 0, 11 ],
      "id_str" : "3688491",
      "id" : 3688491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "550670393422643200",
  "geo" : { },
  "id_str" : "550671617429630978",
  "in_reply_to_user_id" : 3688491,
  "text" : "@mark_olson ah right did not see any updates in github, does the update switch work for storyboard?",
  "id" : 550671617429630978,
  "in_reply_to_status_id" : 550670393422643200,
  "created_at" : "2015-01-01 15:15:19 +0000",
  "in_reply_to_screen_name" : "mark_olson",
  "in_reply_to_user_id_str" : "3688491",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Olson",
      "screen_name" : "mark_olson",
      "indices" : [ 0, 11 ],
      "id_str" : "3688491",
      "id" : 3688491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "550663988313587712",
  "geo" : { },
  "id_str" : "550670210567786496",
  "in_reply_to_user_id" : 3688491,
  "text" : "@mark_olson great thanks have put up two issues on github prob not really issues and just my setup :\/",
  "id" : 550670210567786496,
  "in_reply_to_status_id" : 550663988313587712,
  "created_at" : "2015-01-01 15:09:43 +0000",
  "in_reply_to_screen_name" : "mark_olson",
  "in_reply_to_user_id_str" : "3688491",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 0, 8 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "550656670053842945",
  "geo" : { },
  "id_str" : "550661717169274880",
  "in_reply_to_user_id" : 20650366,
  "text" : "@seburnt blast from the past :) i guess still very much usable this time of year thanks for share Tyson, seasons greetings!",
  "id" : 550661717169274880,
  "in_reply_to_status_id" : 550656670053842945,
  "created_at" : "2015-01-01 14:35:58 +0000",
  "in_reply_to_screen_name" : "seburnt",
  "in_reply_to_user_id_str" : "20650366",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Olson",
      "screen_name" : "mark_olson",
      "indices" : [ 0, 11 ],
      "id_str" : "3688491",
      "id" : 3688491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "550654646050881537",
  "in_reply_to_user_id" : 3688491,
  "text" : "@mark_olson hi emailed u about storyboard error not sure got correct email?",
  "id" : 550654646050881537,
  "created_at" : "2015-01-01 14:07:52 +0000",
  "in_reply_to_screen_name" : "mark_olson",
  "in_reply_to_user_id_str" : "3688491",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robbie Love",
      "screen_name" : "lovermob",
      "indices" : [ 3, 12 ],
      "id_str" : "19469715",
      "id" : 19469715
    }, {
      "name" : "Daily Mail Online",
      "screen_name" : "MailOnline",
      "indices" : [ 139, 140 ],
      "id_str" : "15438913",
      "id" : 15438913
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/bKEwnBkbiy",
      "expanded_url" : "http:\/\/dailym.ai\/1wv36IG",
      "display_url" : "dailym.ai\/1wv36IG"
    } ]
  },
  "geo" : { },
  "id_str" : "550603324903657472",
  "text" : "RT @lovermob: Men rein in the sexist language: Analysis finds terms like sexy or blonde have disappeared from vo... http:\/\/t.co\/bKEwnBkbiy \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Daily Mail Online",
        "screen_name" : "MailOnline",
        "indices" : [ 129, 140 ],
        "id_str" : "15438913",
        "id" : 15438913
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/bKEwnBkbiy",
        "expanded_url" : "http:\/\/dailym.ai\/1wv36IG",
        "display_url" : "dailym.ai\/1wv36IG"
      } ]
    },
    "geo" : { },
    "id_str" : "550370682643968001",
    "text" : "Men rein in the sexist language: Analysis finds terms like sexy or blonde have disappeared from vo... http:\/\/t.co\/bKEwnBkbiy via @MailOnline",
    "id" : 550370682643968001,
    "created_at" : "2014-12-31 19:19:30 +0000",
    "user" : {
      "name" : "Robbie Love",
      "screen_name" : "lovermob",
      "protected" : false,
      "id_str" : "19469715",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733371018056716288\/4lRj6knU_normal.jpg",
      "id" : 19469715,
      "verified" : false
    }
  },
  "id" : 550603324903657472,
  "created_at" : "2015-01-01 10:43:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
} ]