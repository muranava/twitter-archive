Grailbird.data.tweets_2013_12 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FutureLearn",
      "screen_name" : "FutureLearn",
      "indices" : [ 3, 15 ],
      "id_str" : "999095640",
      "id" : 999095640
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/FutureLearn\/status\/417964718855176192\/photo\/1",
      "indices" : [ 143, 144 ],
      "url" : "http:\/\/t.co\/3KbFWTCYQH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BczosoSCQAAZjpN.jpg",
      "id_str" : "417964718863564800",
      "id" : 417964718863564800,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BczosoSCQAAZjpN.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/3KbFWTCYQH"
    } ],
    "hashtags" : [ {
      "text" : "freeonlinecourse",
      "indices" : [ 53, 70 ]
    }, {
      "text" : "FLcorpusmooc",
      "indices" : [ 71, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "418031632508272640",
  "text" : "RT @FutureLearn: Retweet if you've signed up for the #freeonlinecourse #FLcorpusmooc &amp; invite your friends to join you in 2014! http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/FutureLearn\/status\/417964718855176192\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/3KbFWTCYQH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BczosoSCQAAZjpN.jpg",
        "id_str" : "417964718863564800",
        "id" : 417964718863564800,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BczosoSCQAAZjpN.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/3KbFWTCYQH"
      } ],
      "hashtags" : [ {
        "text" : "freeonlinecourse",
        "indices" : [ 36, 53 ]
      }, {
        "text" : "FLcorpusmooc",
        "indices" : [ 54, 67 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "417964718855176192",
    "text" : "Retweet if you've signed up for the #freeonlinecourse #FLcorpusmooc &amp; invite your friends to join you in 2014! http:\/\/t.co\/3KbFWTCYQH",
    "id" : 417964718855176192,
    "created_at" : "2013-12-31 10:25:29 +0000",
    "user" : {
      "name" : "FutureLearn",
      "screen_name" : "FutureLearn",
      "protected" : false,
      "id_str" : "999095640",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458916616395173888\/7OPlOvoF_normal.png",
      "id" : 999095640,
      "verified" : false
    }
  },
  "id" : 418031632508272640,
  "created_at" : "2013-12-31 14:51:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chadsansing",
      "screen_name" : "chadsansing",
      "indices" : [ 3, 15 ],
      "id_str" : "76810409",
      "id" : 76810409
    }, {
      "name" : "Mozilla Webmaker",
      "screen_name" : "Webmaker",
      "indices" : [ 127, 136 ],
      "id_str" : "1242429835",
      "id" : 1242429835
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "teachtheweb",
      "indices" : [ 18, 30 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/CteCOWy4KX",
      "expanded_url" : "http:\/\/bit.ly\/1akNWw3",
      "display_url" : "bit.ly\/1akNWw3"
    }, {
      "indices" : [ 143, 144 ],
      "url" : "http:\/\/t.co\/B3T9bF9Ei5",
      "expanded_url" : "http:\/\/bit.ly\/1akNZrr",
      "display_url" : "bit.ly\/1akNZrr"
    } ]
  },
  "geo" : { },
  "id_str" : "417990103060201472",
  "text" : "RT @chadsansing: \"#teachtheweb: Holt, Minecraft, &amp; doing better\" on Classroots http:\/\/t.co\/CteCOWy4KX w\/ 2D math sticks on @Webmaker http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mozilla Webmaker",
        "screen_name" : "Webmaker",
        "indices" : [ 110, 119 ],
        "id_str" : "1242429835",
        "id" : 1242429835
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "teachtheweb",
        "indices" : [ 1, 13 ]
      } ],
      "urls" : [ {
        "indices" : [ 66, 88 ],
        "url" : "http:\/\/t.co\/CteCOWy4KX",
        "expanded_url" : "http:\/\/bit.ly\/1akNWw3",
        "display_url" : "bit.ly\/1akNWw3"
      }, {
        "indices" : [ 120, 142 ],
        "url" : "http:\/\/t.co\/B3T9bF9Ei5",
        "expanded_url" : "http:\/\/bit.ly\/1akNZrr",
        "display_url" : "bit.ly\/1akNZrr"
      } ]
    },
    "geo" : { },
    "id_str" : "417975845731708928",
    "text" : "\"#teachtheweb: Holt, Minecraft, &amp; doing better\" on Classroots http:\/\/t.co\/CteCOWy4KX w\/ 2D math sticks on @Webmaker http:\/\/t.co\/B3T9bF9Ei5",
    "id" : 417975845731708928,
    "created_at" : "2013-12-31 11:09:41 +0000",
    "user" : {
      "name" : "chadsansing",
      "screen_name" : "chadsansing",
      "protected" : false,
      "id_str" : "76810409",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712740640111652869\/NvEwLRy__normal.jpg",
      "id" : 76810409,
      "verified" : false
    }
  },
  "id" : 417990103060201472,
  "created_at" : "2013-12-31 12:06:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chadsansing",
      "screen_name" : "chadsansing",
      "indices" : [ 0, 12 ],
      "id_str" : "76810409",
      "id" : 76810409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417978739231043584",
  "geo" : { },
  "id_str" : "417979247018266625",
  "in_reply_to_user_id" : 76810409,
  "text" : "@chadsansing looking into it now :)",
  "id" : 417979247018266625,
  "in_reply_to_status_id" : 417978739231043584,
  "created_at" : "2013-12-31 11:23:12 +0000",
  "in_reply_to_screen_name" : "chadsansing",
  "in_reply_to_user_id_str" : "76810409",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chadsansing",
      "screen_name" : "chadsansing",
      "indices" : [ 0, 12 ],
      "id_str" : "76810409",
      "id" : 76810409
    }, {
      "name" : "Mozilla Webmaker",
      "screen_name" : "Webmaker",
      "indices" : [ 13, 22 ],
      "id_str" : "1242429835",
      "id" : 1242429835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417975845731708928",
  "geo" : { },
  "id_str" : "417978214246408193",
  "in_reply_to_user_id" : 76810409,
  "text" : "@chadsansing @webmaker nice, is there a script to rotate blocks?",
  "id" : 417978214246408193,
  "in_reply_to_status_id" : 417975845731708928,
  "created_at" : "2013-12-31 11:19:06 +0000",
  "in_reply_to_screen_name" : "chadsansing",
  "in_reply_to_user_id_str" : "76810409",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/oHzemhLrV9",
      "expanded_url" : "http:\/\/bbc.in\/1hAhNYR",
      "display_url" : "bbc.in\/1hAhNYR"
    } ]
  },
  "geo" : { },
  "id_str" : "417967620801839104",
  "text" : "WHAT THE FLUCK! by Adam Curtis http:\/\/t.co\/oHzemhLrV9",
  "id" : 417967620801839104,
  "created_at" : "2013-12-31 10:37:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pete Sanderson",
      "screen_name" : "LessonToolbox",
      "indices" : [ 3, 17 ],
      "id_str" : "1239302874",
      "id" : 1239302874
    }, {
      "name" : "Transparent Language",
      "screen_name" : "TLILanguages",
      "indices" : [ 34, 47 ],
      "id_str" : "380456976",
      "id" : 380456976
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/TLILanguages\/status\/417770929591025664\/photo\/1",
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/gFU6BL2udJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bcw4cnBCAAAKPkU.jpg",
      "id_str" : "417770929599414272",
      "id" : 417770929599414272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bcw4cnBCAAAKPkU.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 213,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/gFU6BL2udJ"
    } ],
    "hashtags" : [ {
      "text" : "edchat",
      "indices" : [ 106, 113 ]
    }, {
      "text" : "satchat",
      "indices" : [ 114, 122 ]
    }, {
      "text" : "langchat",
      "indices" : [ 123, 132 ]
    }, {
      "text" : "EAL",
      "indices" : [ 133, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "417780034519449601",
  "text" : "RT @LessonToolbox: Love this from @TLILanguages\n\nHappy New Year around the world! http:\/\/t.co\/gFU6BL2udJ\n\n#edchat #satchat #langchat #EAL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Transparent Language",
        "screen_name" : "TLILanguages",
        "indices" : [ 15, 28 ],
        "id_str" : "380456976",
        "id" : 380456976
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/TLILanguages\/status\/417770929591025664\/photo\/1",
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/gFU6BL2udJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bcw4cnBCAAAKPkU.jpg",
        "id_str" : "417770929599414272",
        "id" : 417770929599414272,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bcw4cnBCAAAKPkU.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1280,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 213,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 375,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/gFU6BL2udJ"
      } ],
      "hashtags" : [ {
        "text" : "edchat",
        "indices" : [ 87, 94 ]
      }, {
        "text" : "satchat",
        "indices" : [ 95, 103 ]
      }, {
        "text" : "langchat",
        "indices" : [ 104, 113 ]
      }, {
        "text" : "EAL",
        "indices" : [ 114, 118 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "417778149712478208",
    "text" : "Love this from @TLILanguages\n\nHappy New Year around the world! http:\/\/t.co\/gFU6BL2udJ\n\n#edchat #satchat #langchat #EAL",
    "id" : 417778149712478208,
    "created_at" : "2013-12-30 22:04:07 +0000",
    "user" : {
      "name" : "Pete Sanderson",
      "screen_name" : "LessonToolbox",
      "protected" : false,
      "id_str" : "1239302874",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/664922957127524352\/UMdIHllp_normal.jpg",
      "id" : 1239302874,
      "verified" : false
    }
  },
  "id" : 417780034519449601,
  "created_at" : "2013-12-30 22:11:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Phipps",
      "screen_name" : "lousylinguist",
      "indices" : [ 3, 17 ],
      "id_str" : "48459936",
      "id" : 48459936
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bilinguialphoneticjoke",
      "indices" : [ 113, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "417778833518231552",
  "text" : "RT @lousylinguist: \"Why do they only eat one egg for breakfast in France? Because in France, one egg is an \u0153uf.\" #bilinguialphoneticjoke",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bilinguialphoneticjoke",
        "indices" : [ 94, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "417713695725072385",
    "text" : "\"Why do they only eat one egg for breakfast in France? Because in France, one egg is an \u0153uf.\" #bilinguialphoneticjoke",
    "id" : 417713695725072385,
    "created_at" : "2013-12-30 17:48:00 +0000",
    "user" : {
      "name" : "Christopher Phipps",
      "screen_name" : "lousylinguist",
      "protected" : false,
      "id_str" : "48459936",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750789987113660416\/2IPugaM9_normal.jpg",
      "id" : 48459936,
      "verified" : false
    }
  },
  "id" : 417778833518231552,
  "created_at" : "2013-12-30 22:06:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Yau",
      "screen_name" : "flowingdata",
      "indices" : [ 3, 15 ],
      "id_str" : "14109167",
      "id" : 14109167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/6XwkOmRceb",
      "expanded_url" : "http:\/\/www.refsmmat.com\/statistics\/index.html",
      "display_url" : "refsmmat.com\/statistics\/ind\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417778563568660480",
  "text" : "RT @flowingdata: Statistics Done Wrong, a free guide on popular analysis errors. No prior stat knowledge required http:\/\/t.co\/6XwkOmRceb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/6XwkOmRceb",
        "expanded_url" : "http:\/\/www.refsmmat.com\/statistics\/index.html",
        "display_url" : "refsmmat.com\/statistics\/ind\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "417718055750610944",
    "text" : "Statistics Done Wrong, a free guide on popular analysis errors. No prior stat knowledge required http:\/\/t.co\/6XwkOmRceb",
    "id" : 417718055750610944,
    "created_at" : "2013-12-30 18:05:19 +0000",
    "user" : {
      "name" : "Nathan Yau",
      "screen_name" : "flowingdata",
      "protected" : false,
      "id_str" : "14109167",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/585826994526355456\/R3tYT5Kj_normal.png",
      "id" : 14109167,
      "verified" : false
    }
  },
  "id" : 417778563568660480,
  "created_at" : "2013-12-30 22:05:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Moravec",
      "screen_name" : "ProfessMoravec",
      "indices" : [ 0, 15 ],
      "id_str" : "369529173",
      "id" : 369529173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417719951525285888",
  "geo" : { },
  "id_str" : "417720484248031233",
  "in_reply_to_user_id" : 369529173,
  "text" : "@ProfessMoravec thx that's the one i found",
  "id" : 417720484248031233,
  "in_reply_to_status_id" : 417719951525285888,
  "created_at" : "2013-12-30 18:14:58 +0000",
  "in_reply_to_screen_name" : "ProfessMoravec",
  "in_reply_to_user_id_str" : "369529173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Moravec",
      "screen_name" : "ProfessMoravec",
      "indices" : [ 0, 15 ],
      "id_str" : "369529173",
      "id" : 369529173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "417718617677889536",
  "in_reply_to_user_id" : 369529173,
  "text" : "@ProfessMoravec hi the link to Xiao ref in yr CL for historians is broken is it titled  Making statistic claims?",
  "id" : 417718617677889536,
  "created_at" : "2013-12-30 18:07:33 +0000",
  "in_reply_to_screen_name" : "ProfessMoravec",
  "in_reply_to_user_id_str" : "369529173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenn Greenwald",
      "screen_name" : "ggreenwald",
      "indices" : [ 3, 14 ],
      "id_str" : "16076032",
      "id" : 16076032
    }, {
      "name" : "Jacob Appelbaum",
      "screen_name" : "ioerror",
      "indices" : [ 60, 68 ],
      "id_str" : "13862172",
      "id" : 13862172
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "30c3",
      "indices" : [ 77, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "https:\/\/t.co\/qgwPkBF1Dj",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=b0w36GAyZIA",
      "display_url" : "youtube.com\/watch?v=b0w36G\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417677618037948416",
  "text" : "RT @ggreenwald: Here's the video of the genuinely important @ioerror talk at #30c3 this morning, with some new NSA\/GCHQ revelations  https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jacob Appelbaum",
        "screen_name" : "ioerror",
        "indices" : [ 44, 52 ],
        "id_str" : "13862172",
        "id" : 13862172
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "30c3",
        "indices" : [ 61, 66 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/qgwPkBF1Dj",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=b0w36GAyZIA",
        "display_url" : "youtube.com\/watch?v=b0w36G\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "417639089802706945",
    "text" : "Here's the video of the genuinely important @ioerror talk at #30c3 this morning, with some new NSA\/GCHQ revelations  https:\/\/t.co\/qgwPkBF1Dj",
    "id" : 417639089802706945,
    "created_at" : "2013-12-30 12:51:33 +0000",
    "user" : {
      "name" : "Glenn Greenwald",
      "screen_name" : "ggreenwald",
      "protected" : false,
      "id_str" : "16076032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/659383028771364869\/G9HHnjiI_normal.jpg",
      "id" : 16076032,
      "verified" : true
    }
  },
  "id" : 417677618037948416,
  "created_at" : "2013-12-30 15:24:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Language Log",
      "screen_name" : "LanguageLog",
      "indices" : [ 70, 82 ],
      "id_str" : "20148973",
      "id" : 20148973
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 83, 91 ]
    }, {
      "text" : "tesol",
      "indices" : [ 92, 98 ]
    }, {
      "text" : "tefl",
      "indices" : [ 99, 104 ]
    }, {
      "text" : "elt",
      "indices" : [ 105, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/Np78pJS5Tu",
      "expanded_url" : "http:\/\/lagb-education.org\/starter-collection",
      "display_url" : "lagb-education.org\/starter-collec\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417653470078836736",
  "text" : "A collection of linguistic lesson starters http:\/\/t.co\/Np78pJS5Tu h\/t @LanguageLog #eltchat #tesol #tefl #elt",
  "id" : 417653470078836736,
  "created_at" : "2013-12-30 13:48:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Alec Couros",
      "screen_name" : "courosa",
      "indices" : [ 3, 11 ],
      "id_str" : "739293",
      "id" : 739293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/8ABCqhSYme",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=ycHluR67jiY&list=PLgcoT7-W0fP258nmxEy-2pkFJftUKjdRi",
      "display_url" : "youtube.com\/watch?v=ycHluR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417649413201592320",
  "text" : "RT @courosa: \"Someone took the time to remake Linkin Park's entire Hybrid Theory album with just \"Gangnam Style\"\" https:\/\/t.co\/8ABCqhSYme",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/8ABCqhSYme",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=ycHluR67jiY&list=PLgcoT7-W0fP258nmxEy-2pkFJftUKjdRi",
        "display_url" : "youtube.com\/watch?v=ycHluR\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "417484362670551040",
    "text" : "\"Someone took the time to remake Linkin Park's entire Hybrid Theory album with just \"Gangnam Style\"\" https:\/\/t.co\/8ABCqhSYme",
    "id" : 417484362670551040,
    "created_at" : "2013-12-30 02:36:43 +0000",
    "user" : {
      "name" : "Dr. Alec Couros",
      "screen_name" : "courosa",
      "protected" : false,
      "id_str" : "739293",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/480186733221249027\/bzI2RIfo_normal.jpeg",
      "id" : 739293,
      "verified" : false
    }
  },
  "id" : 417649413201592320,
  "created_at" : "2013-12-30 13:32:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Botanical Linguist",
      "screen_name" : "GrowMyEnglish",
      "indices" : [ 3, 17 ],
      "id_str" : "21865567",
      "id" : 21865567
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/WQUvSChRio",
      "expanded_url" : "http:\/\/www.linglish.net\/2009\/01\/03\/buy-a-pie-for-the-spy\/",
      "display_url" : "linglish.net\/2009\/01\/03\/buy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417636613968363520",
  "text" : "RT @GrowMyEnglish: Why does the \u2018p\u2019 in spy sound somewhat different from the \u2018p\u2019 in pie? http:\/\/t.co\/WQUvSChRio",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/WQUvSChRio",
        "expanded_url" : "http:\/\/www.linglish.net\/2009\/01\/03\/buy-a-pie-for-the-spy\/",
        "display_url" : "linglish.net\/2009\/01\/03\/buy\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "417629659681914880",
    "text" : "Why does the \u2018p\u2019 in spy sound somewhat different from the \u2018p\u2019 in pie? http:\/\/t.co\/WQUvSChRio",
    "id" : 417629659681914880,
    "created_at" : "2013-12-30 12:14:04 +0000",
    "user" : {
      "name" : "Botanical Linguist",
      "screen_name" : "GrowMyEnglish",
      "protected" : false,
      "id_str" : "21865567",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/640942088113274880\/9uLhlZQL_normal.jpg",
      "id" : 21865567,
      "verified" : false
    }
  },
  "id" : 417636613968363520,
  "created_at" : "2013-12-30 12:41:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MarisaConstantinides",
      "screen_name" : "Marisa_C",
      "indices" : [ 53, 62 ],
      "id_str" : "18272500",
      "id" : 18272500
    }, {
      "name" : "pat thomson",
      "screen_name" : "ThomsonPat",
      "indices" : [ 126, 137 ],
      "id_str" : "402209787",
      "id" : 402209787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/83Q06Npr2E",
      "expanded_url" : "http:\/\/bit.ly\/1hOmLii",
      "display_url" : "bit.ly\/1hOmLii"
    }, {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/bdrT2FfPZx",
      "expanded_url" : "http:\/\/patthomson.wordpress.com\/2013\/12\/30\/revisiting-the-construction-of-research-questions-a-useful-holiday-read\/",
      "display_url" : "patthomson.wordpress.com\/2013\/12\/30\/rev\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417616057440804865",
  "text" : "Can teachers do research http:\/\/t.co\/83Q06Npr2E asks @Marisa_C  &amp; so better research questions? http:\/\/t.co\/bdrT2FfPZx by @ThomsonPat",
  "id" : 417616057440804865,
  "created_at" : "2013-12-30 11:20:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 3, 14 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edchat",
      "indices" : [ 90, 97 ]
    }, {
      "text" : "elt",
      "indices" : [ 98, 102 ]
    }, {
      "text" : "tefl",
      "indices" : [ 103, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/kL7KsyiNCT",
      "expanded_url" : "http:\/\/bit.ly\/1ejiKA5",
      "display_url" : "bit.ly\/1ejiKA5"
    } ]
  },
  "geo" : { },
  "id_str" : "417287503788646400",
  "text" : "RT @leoselivan: New blog post on Leoxicon: Top 3 web tools of 2013 http:\/\/t.co\/kL7KsyiNCT #edchat #elt #tefl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "edchat",
        "indices" : [ 74, 81 ]
      }, {
        "text" : "elt",
        "indices" : [ 82, 86 ]
      }, {
        "text" : "tefl",
        "indices" : [ 87, 92 ]
      } ],
      "urls" : [ {
        "indices" : [ 51, 73 ],
        "url" : "http:\/\/t.co\/kL7KsyiNCT",
        "expanded_url" : "http:\/\/bit.ly\/1ejiKA5",
        "display_url" : "bit.ly\/1ejiKA5"
      } ]
    },
    "geo" : { },
    "id_str" : "417246412162990081",
    "text" : "New blog post on Leoxicon: Top 3 web tools of 2013 http:\/\/t.co\/kL7KsyiNCT #edchat #elt #tefl",
    "id" : 417246412162990081,
    "created_at" : "2013-12-29 10:51:11 +0000",
    "user" : {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "protected" : false,
      "id_str" : "408365496",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/460546508601819136\/12ivDBb__normal.jpeg",
      "id" : 408365496,
      "verified" : false
    }
  },
  "id" : 417287503788646400,
  "created_at" : "2013-12-29 13:34:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Divya Madhavan",
      "screen_name" : "_divyamadhavan",
      "indices" : [ 3, 18 ],
      "id_str" : "408492806",
      "id" : 408492806
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/zNRJrrVpOd",
      "expanded_url" : "http:\/\/divyamadhavan.com\/2013\/12\/26\/a-good-quality-teacher-is\/",
      "display_url" : "divyamadhavan.com\/2013\/12\/26\/a-g\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417286140337860610",
  "text" : "RT @_divyamadhavan: New post - what is a good quality teacher? http:\/\/t.co\/zNRJrrVpOd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 65 ],
        "url" : "http:\/\/t.co\/zNRJrrVpOd",
        "expanded_url" : "http:\/\/divyamadhavan.com\/2013\/12\/26\/a-good-quality-teacher-is\/",
        "display_url" : "divyamadhavan.com\/2013\/12\/26\/a-g\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "417250108095221760",
    "text" : "New post - what is a good quality teacher? http:\/\/t.co\/zNRJrrVpOd",
    "id" : 417250108095221760,
    "created_at" : "2013-12-29 11:05:52 +0000",
    "user" : {
      "name" : "Divya Madhavan",
      "screen_name" : "_divyamadhavan",
      "protected" : false,
      "id_str" : "408492806",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/764501890071666688\/jyS8Y-Ag_normal.jpg",
      "id" : 408492806,
      "verified" : false
    }
  },
  "id" : 417286140337860610,
  "created_at" : "2013-12-29 13:29:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cdmblogs",
      "screen_name" : "cdmblogs",
      "indices" : [ 3, 12 ],
      "id_str" : "15739035",
      "id" : 15739035
    }, {
      "name" : "staticdiscos",
      "screen_name" : "staticdiscos",
      "indices" : [ 108, 121 ],
      "id_str" : "253695543",
      "id" : 253695543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/YBZ1WT29Qb",
      "expanded_url" : "http:\/\/createdigitalmusic.com\/2013\/12\/mexico-meets-world-superbly-diverse-mixtapes-static-discos\/",
      "display_url" : "createdigitalmusic.com\/2013\/12\/mexico\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417084938408960000",
  "text" : "RT @cdmblogs: Awesome free listening - http:\/\/t.co\/YBZ1WT29Qb - Mexico meets the world, in superbly-diverse @staticdiscos Mixtapes",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "staticdiscos",
        "screen_name" : "staticdiscos",
        "indices" : [ 94, 107 ],
        "id_str" : "253695543",
        "id" : 253695543
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 25, 47 ],
        "url" : "http:\/\/t.co\/YBZ1WT29Qb",
        "expanded_url" : "http:\/\/createdigitalmusic.com\/2013\/12\/mexico-meets-world-superbly-diverse-mixtapes-static-discos\/",
        "display_url" : "createdigitalmusic.com\/2013\/12\/mexico\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "416336980939898880",
    "text" : "Awesome free listening - http:\/\/t.co\/YBZ1WT29Qb - Mexico meets the world, in superbly-diverse @staticdiscos Mixtapes",
    "id" : 416336980939898880,
    "created_at" : "2013-12-26 22:37:26 +0000",
    "user" : {
      "name" : "cdmblogs",
      "screen_name" : "cdmblogs",
      "protected" : false,
      "id_str" : "15739035",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464778218445094912\/zvQnoKfw_normal.png",
      "id" : 15739035,
      "verified" : false
    }
  },
  "id" : 417084938408960000,
  "created_at" : "2013-12-29 00:09:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Sound Book Site",
      "screen_name" : "sndbksite",
      "indices" : [ 3, 13 ],
      "id_str" : "1650800210",
      "id" : 1650800210
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 84, 88 ]
    }, {
      "text" : "sfx",
      "indices" : [ 89, 93 ]
    }, {
      "text" : "esol",
      "indices" : [ 94, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/sFOPGplLIW",
      "expanded_url" : "https:\/\/www.facebook.com\/soundbook\/posts\/562359987192078",
      "display_url" : "facebook.com\/soundbook\/post\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417084326040580096",
  "text" : "RT @sndbksite: Quick sound effect based activity to try out https:\/\/t.co\/sFOPGplLIW #elt #sfx #esol",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "elt",
        "indices" : [ 69, 73 ]
      }, {
        "text" : "sfx",
        "indices" : [ 74, 78 ]
      }, {
        "text" : "esol",
        "indices" : [ 79, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 45, 68 ],
        "url" : "https:\/\/t.co\/sFOPGplLIW",
        "expanded_url" : "https:\/\/www.facebook.com\/soundbook\/posts\/562359987192078",
        "display_url" : "facebook.com\/soundbook\/post\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "417079812197740544",
    "text" : "Quick sound effect based activity to try out https:\/\/t.co\/sFOPGplLIW #elt #sfx #esol",
    "id" : 417079812197740544,
    "created_at" : "2013-12-28 23:49:10 +0000",
    "user" : {
      "name" : "The Sound Book Site",
      "screen_name" : "sndbksite",
      "protected" : false,
      "id_str" : "1650800210",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/489040594639937536\/_qFoeqpa_normal.jpeg",
      "id" : 1650800210,
      "verified" : false
    }
  },
  "id" : 417084326040580096,
  "created_at" : "2013-12-29 00:07:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pete Sanderson",
      "screen_name" : "LessonToolbox",
      "indices" : [ 3, 17 ],
      "id_str" : "1239302874",
      "id" : 1239302874
    }, {
      "name" : "M Sidat",
      "screen_name" : "MohammedSidat",
      "indices" : [ 49, 63 ],
      "id_str" : "339118795",
      "id" : 339118795
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/jandain\/status\/293394339181232128\/photo\/1",
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/7zQr99SUjO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BBJYmNZCAAERZY-.jpg",
      "id_str" : "293394339185426433",
      "id" : 293394339185426433,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BBJYmNZCAAERZY-.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 415,
        "resize" : "fit",
        "w" : 554
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 415,
        "resize" : "fit",
        "w" : 554
      }, {
        "h" : 415,
        "resize" : "fit",
        "w" : 554
      } ],
      "display_url" : "pic.twitter.com\/7zQr99SUjO"
    } ],
    "hashtags" : [ {
      "text" : "edchat",
      "indices" : [ 92, 99 ]
    }, {
      "text" : "literacy",
      "indices" : [ 100, 109 ]
    }, {
      "text" : "ukedchat",
      "indices" : [ 110, 119 ]
    }, {
      "text" : "satchat",
      "indices" : [ 120, 128 ]
    }, {
      "text" : "engchat",
      "indices" : [ 129, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "417059535220920320",
  "text" : "RT @LessonToolbox: Great punctuation display via @MohammedSidat pic http:\/\/t.co\/7zQr99SUjO\n\n#edchat #literacy #ukedchat #satchat #engchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "M Sidat",
        "screen_name" : "MohammedSidat",
        "indices" : [ 30, 44 ],
        "id_str" : "339118795",
        "id" : 339118795
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/jandain\/status\/293394339181232128\/photo\/1",
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/7zQr99SUjO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BBJYmNZCAAERZY-.jpg",
        "id_str" : "293394339185426433",
        "id" : 293394339185426433,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BBJYmNZCAAERZY-.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 415,
          "resize" : "fit",
          "w" : 554
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 415,
          "resize" : "fit",
          "w" : 554
        }, {
          "h" : 415,
          "resize" : "fit",
          "w" : 554
        } ],
        "display_url" : "pic.twitter.com\/7zQr99SUjO"
      } ],
      "hashtags" : [ {
        "text" : "edchat",
        "indices" : [ 73, 80 ]
      }, {
        "text" : "literacy",
        "indices" : [ 81, 90 ]
      }, {
        "text" : "ukedchat",
        "indices" : [ 91, 100 ]
      }, {
        "text" : "satchat",
        "indices" : [ 101, 109 ]
      }, {
        "text" : "engchat",
        "indices" : [ 110, 118 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "417046676419772416",
    "text" : "Great punctuation display via @MohammedSidat pic http:\/\/t.co\/7zQr99SUjO\n\n#edchat #literacy #ukedchat #satchat #engchat",
    "id" : 417046676419772416,
    "created_at" : "2013-12-28 21:37:30 +0000",
    "user" : {
      "name" : "Pete Sanderson",
      "screen_name" : "LessonToolbox",
      "protected" : false,
      "id_str" : "1239302874",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/664922957127524352\/UMdIHllp_normal.jpg",
      "id" : 1239302874,
      "verified" : false
    }
  },
  "id" : 417059535220920320,
  "created_at" : "2013-12-28 22:28:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Wittens",
      "screen_name" : "unconed",
      "indices" : [ 3, 11 ],
      "id_str" : "8131272",
      "id" : 8131272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/urEGmqIFeK",
      "expanded_url" : "https:\/\/soundcloud.com\/albill\/30c3-keynote-glenn-greenwald",
      "display_url" : "soundcloud.com\/albill\/30c3-ke\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417055638469226496",
  "text" : "RT @unconed: Glenn Greenwald's CCC keynote. Listen to this. Preferably away from the computer. https:\/\/t.co\/urEGmqIFeK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/urEGmqIFeK",
        "expanded_url" : "https:\/\/soundcloud.com\/albill\/30c3-keynote-glenn-greenwald",
        "display_url" : "soundcloud.com\/albill\/30c3-ke\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "416756151540150272",
    "text" : "Glenn Greenwald's CCC keynote. Listen to this. Preferably away from the computer. https:\/\/t.co\/urEGmqIFeK",
    "id" : 416756151540150272,
    "created_at" : "2013-12-28 02:23:04 +0000",
    "user" : {
      "name" : "Steven Wittens",
      "screen_name" : "unconed",
      "protected" : false,
      "id_str" : "8131272",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/564573861\/4168869060_2f617dcc46_b_normal.jpg",
      "id" : 8131272,
      "verified" : false
    }
  },
  "id" : 417055638469226496,
  "created_at" : "2013-12-28 22:13:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00F6rg Lohrer",
      "screen_name" : "empeiria",
      "indices" : [ 3, 12 ],
      "id_str" : "19389942",
      "id" : 19389942
    }, {
      "name" : "Glenn Greenwald",
      "screen_name" : "ggreenwald",
      "indices" : [ 65, 76 ],
      "id_str" : "16076032",
      "id" : 16076032
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "30c3",
      "indices" : [ 49, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/wkCRujLYBn",
      "expanded_url" : "http:\/\/streaming.media.ccc.de\/wiki\/",
      "display_url" : "streaming.media.ccc.de\/wiki\/"
    } ]
  },
  "geo" : { },
  "id_str" : "416640923259633664",
  "text" : "RT @empeiria: Livestream vom Chaos Computer Club #30c3 im Moment @ggreenwald vom Guardian: http:\/\/t.co\/wkCRujLYBn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Glenn Greenwald",
        "screen_name" : "ggreenwald",
        "indices" : [ 51, 62 ],
        "id_str" : "16076032",
        "id" : 16076032
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "30c3",
        "indices" : [ 35, 40 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/wkCRujLYBn",
        "expanded_url" : "http:\/\/streaming.media.ccc.de\/wiki\/",
        "display_url" : "streaming.media.ccc.de\/wiki\/"
      } ]
    },
    "geo" : { },
    "id_str" : "416640525950021632",
    "text" : "Livestream vom Chaos Computer Club #30c3 im Moment @ggreenwald vom Guardian: http:\/\/t.co\/wkCRujLYBn",
    "id" : 416640525950021632,
    "created_at" : "2013-12-27 18:43:36 +0000",
    "user" : {
      "name" : "J\u00F6rg Lohrer",
      "screen_name" : "empeiria",
      "protected" : false,
      "id_str" : "19389942",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/586093669125660672\/l-jrOuJN_normal.jpg",
      "id" : 19389942,
      "verified" : false
    }
  },
  "id" : 416640923259633664,
  "created_at" : "2013-12-27 18:45:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Unix tool tip",
      "screen_name" : "UnixToolTip",
      "indices" : [ 3, 15 ],
      "id_str" : "363210621",
      "id" : 363210621
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/SiMN9iNESZ",
      "expanded_url" : "https:\/\/github.com\/bmatzelle\/gow",
      "display_url" : "github.com\/bmatzelle\/gow"
    } ]
  },
  "geo" : { },
  "id_str" : "416619215035310080",
  "text" : "RT @UnixToolTip: \"Gow (Gnu On Windows) is the lightweight alternative to Cygwin,\" https:\/\/t.co\/SiMN9iNESZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 88 ],
        "url" : "https:\/\/t.co\/SiMN9iNESZ",
        "expanded_url" : "https:\/\/github.com\/bmatzelle\/gow",
        "display_url" : "github.com\/bmatzelle\/gow"
      } ]
    },
    "geo" : { },
    "id_str" : "416567498956619776",
    "text" : "\"Gow (Gnu On Windows) is the lightweight alternative to Cygwin,\" https:\/\/t.co\/SiMN9iNESZ",
    "id" : 416567498956619776,
    "created_at" : "2013-12-27 13:53:25 +0000",
    "user" : {
      "name" : "Unix tool tip",
      "screen_name" : "UnixToolTip",
      "protected" : false,
      "id_str" : "363210621",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710925198724214785\/g75FcET7_normal.jpg",
      "id" : 363210621,
      "verified" : false
    }
  },
  "id" : 416619215035310080,
  "created_at" : "2013-12-27 17:18:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Thornbury",
      "screen_name" : "thornburyscott",
      "indices" : [ 3, 18 ],
      "id_str" : "23090474",
      "id" : 23090474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/mUYgubqde8",
      "expanded_url" : "http:\/\/scottthornbury.com",
      "display_url" : "scottthornbury.com"
    }, {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/9hNy7A7Dz5",
      "expanded_url" : "http:\/\/x.co\/1GvAH",
      "display_url" : "x.co\/1GvAH"
    } ]
  },
  "geo" : { },
  "id_str" : "416606141976965120",
  "text" : "RT @thornburyscott: I\u2019ve just published my website, check it out at http:\/\/t.co\/mUYgubqde8 via GoDaddy http:\/\/t.co\/9hNy7A7Dz5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 70 ],
        "url" : "http:\/\/t.co\/mUYgubqde8",
        "expanded_url" : "http:\/\/scottthornbury.com",
        "display_url" : "scottthornbury.com"
      }, {
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/9hNy7A7Dz5",
        "expanded_url" : "http:\/\/x.co\/1GvAH",
        "display_url" : "x.co\/1GvAH"
      } ]
    },
    "geo" : { },
    "id_str" : "415959266596384768",
    "text" : "I\u2019ve just published my website, check it out at http:\/\/t.co\/mUYgubqde8 via GoDaddy http:\/\/t.co\/9hNy7A7Dz5",
    "id" : 415959266596384768,
    "created_at" : "2013-12-25 21:36:31 +0000",
    "user" : {
      "name" : "Scott Thornbury",
      "screen_name" : "thornburyscott",
      "protected" : false,
      "id_str" : "23090474",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892392697\/twitter03_normal.jpg",
      "id" : 23090474,
      "verified" : false
    }
  },
  "id" : 416606141976965120,
  "created_at" : "2013-12-27 16:26:59 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gabrielle Jones",
      "screen_name" : "GJTeacher",
      "indices" : [ 0, 10 ],
      "id_str" : "268751235",
      "id" : 268751235
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/gnEFqIwmh8",
      "expanded_url" : "https:\/\/plus.google.com\/u\/0\/communities\/101266284417587206243",
      "display_url" : "plus.google.com\/u\/0\/communitie\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "414729007934881792",
  "geo" : { },
  "id_str" : "416540449633873920",
  "in_reply_to_user_id" : 268751235,
  "text" : "@GJTeacher fyi if u on G+ consider joining https:\/\/t.co\/gnEFqIwmh8 for pre-course\/during course\/after course discussions :)",
  "id" : 416540449633873920,
  "in_reply_to_status_id" : 414729007934881792,
  "created_at" : "2013-12-27 12:05:56 +0000",
  "in_reply_to_screen_name" : "GJTeacher",
  "in_reply_to_user_id_str" : "268751235",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glen Cochrane",
      "screen_name" : "GlenFCochrane",
      "indices" : [ 53, 67 ],
      "id_str" : "61789211",
      "id" : 61789211
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/i3j4jRADKQ",
      "expanded_url" : "http:\/\/wp.me\/pFtHN-jZ",
      "display_url" : "wp.me\/pFtHN-jZ"
    } ]
  },
  "geo" : { },
  "id_str" : "416446872513830912",
  "text" : "The Grammar We Don't Know http:\/\/t.co\/i3j4jRADKQ via @GlenFCochrane",
  "id" : 416446872513830912,
  "created_at" : "2013-12-27 05:54:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "edulang",
      "screen_name" : "edulang",
      "indices" : [ 0, 8 ],
      "id_str" : "2877002950",
      "id" : 2877002950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "416252402228924416",
  "geo" : { },
  "id_str" : "416255331333718016",
  "in_reply_to_user_id" : 236921161,
  "text" : "@Edulang the best &amp; worst of 70s English sitcom :)",
  "id" : 416255331333718016,
  "in_reply_to_status_id" : 416252402228924416,
  "created_at" : "2013-12-26 17:12:59 +0000",
  "in_reply_to_screen_name" : "wordtov",
  "in_reply_to_user_id_str" : "236921161",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naomi Epstein",
      "screen_name" : "naomishema",
      "indices" : [ 3, 14 ],
      "id_str" : "228469472",
      "id" : 228469472
    }, {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 92, 100 ],
      "id_str" : "20650366",
      "id" : 20650366
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 114, 122 ]
    }, {
      "text" : "efl",
      "indices" : [ 123, 127 ]
    }, {
      "text" : "esl",
      "indices" : [ 128, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/Vu4OBW0fzS",
      "expanded_url" : "http:\/\/fourc.ca\/13bibliography\/",
      "display_url" : "fourc.ca\/13bibliography\/"
    } ]
  },
  "geo" : { },
  "id_str" : "415621091089215488",
  "text" : "RT @naomishema: A bibliography of 13 posts that got me this year http:\/\/t.co\/Vu4OBW0fzS via @seburnt WHAT A LIST! #eltchat #efl #esl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tyson Seburn",
        "screen_name" : "seburnt",
        "indices" : [ 76, 84 ],
        "id_str" : "20650366",
        "id" : 20650366
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "eltchat",
        "indices" : [ 98, 106 ]
      }, {
        "text" : "efl",
        "indices" : [ 107, 111 ]
      }, {
        "text" : "esl",
        "indices" : [ 112, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/Vu4OBW0fzS",
        "expanded_url" : "http:\/\/fourc.ca\/13bibliography\/",
        "display_url" : "fourc.ca\/13bibliography\/"
      } ]
    },
    "geo" : { },
    "id_str" : "415619332551372800",
    "text" : "A bibliography of 13 posts that got me this year http:\/\/t.co\/Vu4OBW0fzS via @seburnt WHAT A LIST! #eltchat #efl #esl",
    "id" : 415619332551372800,
    "created_at" : "2013-12-24 23:05:45 +0000",
    "user" : {
      "name" : "Naomi Epstein",
      "screen_name" : "naomishema",
      "protected" : false,
      "id_str" : "228469472",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1236538360\/PICT00108_normal.JPG",
      "id" : 228469472,
      "verified" : false
    }
  },
  "id" : 415621091089215488,
  "created_at" : "2013-12-24 23:12:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "415495148038942720",
  "geo" : { },
  "id_str" : "415618515228307456",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler hope u did some ho ho hoing :)",
  "id" : 415618515228307456,
  "in_reply_to_status_id" : 415495148038942720,
  "created_at" : "2013-12-24 23:02:30 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bloogerbehindblog",
      "indices" : [ 49, 67 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "415595267597946880",
  "geo" : { },
  "id_str" : "415618122494664704",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan because merry xmas; &amp; was taking #bloogerbehindblog literally :)",
  "id" : 415618122494664704,
  "in_reply_to_status_id" : 415595267597946880,
  "created_at" : "2013-12-24 23:00:56 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen White",
      "screen_name" : "KarenWhiteInk",
      "indices" : [ 0, 14 ],
      "id_str" : "20389382",
      "id" : 20389382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "415512347164545024",
  "geo" : { },
  "id_str" : "415512883099750401",
  "in_reply_to_user_id" : 20389382,
  "text" : "@KarenWhiteInk yum, looks like it can be carried to the mouth :)",
  "id" : 415512883099750401,
  "in_reply_to_status_id" : 415512347164545024,
  "created_at" : "2013-12-24 16:02:45 +0000",
  "in_reply_to_screen_name" : "KarenWhiteInk",
  "in_reply_to_user_id_str" : "20389382",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lizzie Pinard",
      "screen_name" : "LizziePinard",
      "indices" : [ 3, 16 ],
      "id_str" : "287093748",
      "id" : 287093748
    }, {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "indices" : [ 111, 123 ],
      "id_str" : "192437743",
      "id" : 192437743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/uXgkpg7Nz3",
      "expanded_url" : "http:\/\/reflectiveteachingreflectivelearning.com\/2013\/12\/24\/the-2nd-elt-research-blog-carnival-on-learner-autonomy-has-arrived\/",
      "display_url" : "\u2026lectiveteachingreflectivelearning.com\/2013\/12\/24\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "415485003481772032",
  "text" : "RT @LizziePinard: http:\/\/t.co\/uXgkpg7Nz3  2nd ELT Research Blog Carnival on learner autonomy now published! cc @nathanghall",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nathan Hall",
        "screen_name" : "nathanghall",
        "indices" : [ 93, 105 ],
        "id_str" : "192437743",
        "id" : 192437743
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/uXgkpg7Nz3",
        "expanded_url" : "http:\/\/reflectiveteachingreflectivelearning.com\/2013\/12\/24\/the-2nd-elt-research-blog-carnival-on-learner-autonomy-has-arrived\/",
        "display_url" : "\u2026lectiveteachingreflectivelearning.com\/2013\/12\/24\/the\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "415437628696051712",
    "text" : "http:\/\/t.co\/uXgkpg7Nz3  2nd ELT Research Blog Carnival on learner autonomy now published! cc @nathanghall",
    "id" : 415437628696051712,
    "created_at" : "2013-12-24 11:03:43 +0000",
    "user" : {
      "name" : "Lizzie Pinard",
      "screen_name" : "LizziePinard",
      "protected" : false,
      "id_str" : "287093748",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/628657904460132352\/nS6hzUBs_normal.png",
      "id" : 287093748,
      "verified" : false
    }
  },
  "id" : 415485003481772032,
  "created_at" : "2013-12-24 14:11:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 58, 70 ],
      "id_str" : "525013404",
      "id" : 525013404
    }, {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 71, 82 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "Laura Adele Soracco",
      "screen_name" : "LauraSoracco",
      "indices" : [ 83, 96 ],
      "id_str" : "15663328",
      "id" : 15663328
    }, {
      "name" : "Anne Hodgson",
      "screen_name" : "annehodg",
      "indices" : [ 97, 106 ],
      "id_str" : "17589213",
      "id" : 17589213
    }, {
      "name" : "Ljiljana Havran",
      "screen_name" : "LjiljanaHavran",
      "indices" : [ 107, 122 ],
      "id_str" : "1395825290",
      "id" : 1395825290
    }, {
      "name" : "Elizabeth Anne",
      "screen_name" : "eannegrenoble",
      "indices" : [ 123, 137 ],
      "id_str" : "19869781",
      "id" : 19869781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/sAtYFXF1HF",
      "expanded_url" : "https:\/\/elt.makes.org\/thimble\/these-go-to-11",
      "display_url" : "elt.makes.org\/thimble\/these-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "415478429035675648",
  "text" : "blogging craze of 11 answered? https:\/\/t.co\/sAtYFXF1HF cc @AnneHendler @leoselivan @LauraSoracco @annehodg @LjiljanaHavran @eannegrenoble",
  "id" : 415478429035675648,
  "created_at" : "2013-12-24 13:45:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ljiljana Havran",
      "screen_name" : "LjiljanaHavran",
      "indices" : [ 0, 15 ],
      "id_str" : "1395825290",
      "id" : 1395825290
    }, {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 16, 29 ],
      "id_str" : "88655243",
      "id" : 88655243
    }, {
      "name" : "Jo Cummins",
      "screen_name" : "jo_cummins",
      "indices" : [ 30, 41 ],
      "id_str" : "897738066",
      "id" : 897738066
    }, {
      "name" : "Adi Rajan",
      "screen_name" : "adi_rajan",
      "indices" : [ 42, 52 ],
      "id_str" : "1011323449",
      "id" : 1011323449
    }, {
      "name" : "Wilma Luth",
      "screen_name" : "wilma_luth",
      "indices" : [ 53, 64 ],
      "id_str" : "1976998272",
      "id" : 1976998272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "415298642619035648",
  "geo" : { },
  "id_str" : "415394270904717312",
  "in_reply_to_user_id" : 1395825290,
  "text" : "@LjiljanaHavran @rosemerebard @jo_cummins @adi_rajan @wilma_luth sre\u0107an bo\u017Ei\u0107 ljiljana :)",
  "id" : 415394270904717312,
  "in_reply_to_status_id" : 415298642619035648,
  "created_at" : "2013-12-24 08:11:26 +0000",
  "in_reply_to_screen_name" : "LjiljanaHavran",
  "in_reply_to_user_id_str" : "1395825290",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "414880169820565504",
  "geo" : { },
  "id_str" : "414880583429279744",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan --&gt; @teflskeptic",
  "id" : 414880583429279744,
  "in_reply_to_status_id" : 414880169820565504,
  "created_at" : "2013-12-22 22:10:13 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anne Hodgson",
      "screen_name" : "annehodg",
      "indices" : [ 0, 9 ],
      "id_str" : "17589213",
      "id" : 17589213
    }, {
      "name" : "Barbara Sakamoto ",
      "screen_name" : "barbsaka",
      "indices" : [ 10, 19 ],
      "id_str" : "2970224781",
      "id" : 2970224781
    }, {
      "name" : "Carl Dowse",
      "screen_name" : "carldowse",
      "indices" : [ 20, 30 ],
      "id_str" : "15609677",
      "id" : 15609677
    }, {
      "name" : "Chia Suan Chong",
      "screen_name" : "chiasuan",
      "indices" : [ 31, 40 ],
      "id_str" : "71588589",
      "id" : 71588589
    }, {
      "name" : "Helen Strong",
      "screen_name" : "helenstrong",
      "indices" : [ 41, 53 ],
      "id_str" : "96087619",
      "id" : 96087619
    }, {
      "name" : "NATIVES",
      "screen_name" : "NATIVESdotDE",
      "indices" : [ 54, 67 ],
      "id_str" : "246216123",
      "id" : 246216123
    }, {
      "name" : "Karenne Sylvester",
      "screen_name" : "kalinagoenglish",
      "indices" : [ 68, 84 ],
      "id_str" : "22755100",
      "id" : 22755100
    }, {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 85, 94 ],
      "id_str" : "134211317",
      "id" : 134211317
    }, {
      "name" : "Rebecca",
      "screen_name" : "bexxi",
      "indices" : [ 95, 101 ],
      "id_str" : "769696",
      "id" : 769696
    }, {
      "name" : "Stephen Mayeux",
      "screen_name" : "ESLhiphop",
      "indices" : [ 102, 112 ],
      "id_str" : "1360915363",
      "id" : 1360915363
    }, {
      "name" : "Nagehan Tunar",
      "screen_name" : "stiiiv",
      "indices" : [ 113, 120 ],
      "id_str" : "799058600",
      "id" : 799058600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "414808123858108416",
  "geo" : { },
  "id_str" : "414875336547905536",
  "in_reply_to_user_id" : 17589213,
  "text" : "@annehodg @barbsaka @carldowse @chiasuan @helenstrong @NATIVESdotDE @kalinagoenglish @josipa74 @bexxi @ESLhiphop @stiiiv frohe festtage anne",
  "id" : 414875336547905536,
  "in_reply_to_status_id" : 414808123858108416,
  "created_at" : "2013-12-22 21:49:22 +0000",
  "in_reply_to_screen_name" : "annehodg",
  "in_reply_to_user_id_str" : "17589213",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephanie Fuccio",
      "screen_name" : "stephfuccio",
      "indices" : [ 34, 46 ],
      "id_str" : "153349145",
      "id" : 153349145
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tesolfr",
      "indices" : [ 17, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "414716678568554497",
  "text" : "thanks for RT of #tesolfr post :) @stephfuccio",
  "id" : 414716678568554497,
  "created_at" : "2013-12-22 11:18:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 86, 97 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "Vicky Loras",
      "screen_name" : "vickyloras",
      "indices" : [ 98, 109 ],
      "id_str" : "95957241",
      "id" : 95957241
    }, {
      "name" : "Graeme Hodgson",
      "screen_name" : "GrammyLatino",
      "indices" : [ 110, 123 ],
      "id_str" : "42042283",
      "id" : 42042283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/gnEFqIwmh8",
      "expanded_url" : "https:\/\/plus.google.com\/u\/0\/communities\/101266284417587206243",
      "display_url" : "plus.google.com\/u\/0\/communitie\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "414712952089243648",
  "geo" : { },
  "id_str" : "414716221431349248",
  "in_reply_to_user_id" : 408365496,
  "text" : "fyi G+ CL grp for any pre-course\/during-course\/post-course Qs https:\/\/t.co\/gnEFqIwmh8 @leoselivan @vickyloras @GrammyLatino",
  "id" : 414716221431349248,
  "in_reply_to_status_id" : 414712952089243648,
  "created_at" : "2013-12-22 11:17:06 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeroen Root",
      "screen_name" : "ChopEDU",
      "indices" : [ 3, 11 ],
      "id_str" : "341510847",
      "id" : 341510847
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "officialKOTESOL",
      "indices" : [ 115, 131 ]
    }, {
      "text" : "KOTESOL",
      "indices" : [ 132, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/e1HrFEUjsi",
      "expanded_url" : "http:\/\/www.koreatesol.org\/video\/ic2013",
      "display_url" : "koreatesol.org\/video\/ic2013"
    } ]
  },
  "geo" : { },
  "id_str" : "414715117075709952",
  "text" : "RT @ChopEDU: Video of Dr. Charles Browne's Pecha Kucha at 2013 KOTESOL IC, available here: http:\/\/t.co\/e1HrFEUjsi  #officialKOTESOL #KOTESOL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "officialKOTESOL",
        "indices" : [ 102, 118 ]
      }, {
        "text" : "KOTESOL",
        "indices" : [ 119, 127 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/e1HrFEUjsi",
        "expanded_url" : "http:\/\/www.koreatesol.org\/video\/ic2013",
        "display_url" : "koreatesol.org\/video\/ic2013"
      } ]
    },
    "geo" : { },
    "id_str" : "414703334730121216",
    "text" : "Video of Dr. Charles Browne's Pecha Kucha at 2013 KOTESOL IC, available here: http:\/\/t.co\/e1HrFEUjsi  #officialKOTESOL #KOTESOL",
    "id" : 414703334730121216,
    "created_at" : "2013-12-22 10:25:54 +0000",
    "user" : {
      "name" : "Jeroen Root",
      "screen_name" : "ChopEDU",
      "protected" : false,
      "id_str" : "341510847",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684731305997684736\/eBXs-OHD_normal.jpg",
      "id" : 341510847,
      "verified" : false
    }
  },
  "id" : 414715117075709952,
  "created_at" : "2013-12-22 11:12:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyler Schnoebelen",
      "screen_name" : "TSchnoebelen",
      "indices" : [ 0, 13 ],
      "id_str" : "14969147",
      "id" : 14969147
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/WVlVceq0m4",
      "expanded_url" : "http:\/\/zeega.com\/160790",
      "display_url" : "zeega.com\/160790"
    } ]
  },
  "in_reply_to_status_id_str" : "414451700188332032",
  "geo" : { },
  "id_str" : "414541171730313216",
  "in_reply_to_user_id" : 14969147,
  "text" : "@TSchnoebelen http:\/\/t.co\/WVlVceq0m4 :)",
  "id" : 414541171730313216,
  "in_reply_to_status_id" : 414451700188332032,
  "created_at" : "2013-12-21 23:41:31 +0000",
  "in_reply_to_screen_name" : "TSchnoebelen",
  "in_reply_to_user_id_str" : "14969147",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Adele Soracco",
      "screen_name" : "LauraSoracco",
      "indices" : [ 0, 13 ],
      "id_str" : "15663328",
      "id" : 15663328
    }, {
      "name" : "Ted O'Neill (DB-\u7ADC\u725B)",
      "screen_name" : "gotanda",
      "indices" : [ 26, 34 ],
      "id_str" : "9875912",
      "id" : 9875912
    }, {
      "name" : "\u0414\u0438\u0430\u043D\u043A\u0430 \u0428\u043A\u0443\u0440\u0441\u043A\u0430\u044F",
      "screen_name" : "TheSecretDoS",
      "indices" : [ 35, 48 ],
      "id_str" : "440292980",
      "id" : 440292980
    }, {
      "name" : "florentina",
      "screen_name" : "florentina_t",
      "indices" : [ 49, 62 ],
      "id_str" : "267059271",
      "id" : 267059271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "414476498662207488",
  "geo" : { },
  "id_str" : "414525694178115585",
  "in_reply_to_user_id" : 15663328,
  "text" : "@LauraSoracco @AlexSWalsh @gotanda @TheSecretDoS @florentina_t seasons greets laura :)",
  "id" : 414525694178115585,
  "in_reply_to_status_id" : 414476498662207488,
  "created_at" : "2013-12-21 22:40:01 +0000",
  "in_reply_to_screen_name" : "LauraSoracco",
  "in_reply_to_user_id_str" : "15663328",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Hersh",
      "indices" : [ 130, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 143, 144 ],
      "url" : "http:\/\/t.co\/QVTM5CUjw8",
      "expanded_url" : "http:\/\/www.medialens.org\/index.php\/alerts\/alert-archive\/alerts-2013\/751-an-awkward-silence-burying-the-hersh-revelations-of-obama-s-syrian-deceit.html",
      "display_url" : "medialens.org\/index.php\/aler\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "414367462722117632",
  "text" : "RT @medialens: Our latest media alert on an awkward silence: Guardian &amp; Independent have steered clear of embarrassing Obama. #Hersh http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Hersh",
        "indices" : [ 115, 121 ]
      } ],
      "urls" : [ {
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/QVTM5CUjw8",
        "expanded_url" : "http:\/\/www.medialens.org\/index.php\/alerts\/alert-archive\/alerts-2013\/751-an-awkward-silence-burying-the-hersh-revelations-of-obama-s-syrian-deceit.html",
        "display_url" : "medialens.org\/index.php\/aler\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "413242282188345345",
    "text" : "Our latest media alert on an awkward silence: Guardian &amp; Independent have steered clear of embarrassing Obama. #Hersh http:\/\/t.co\/QVTM5CUjw8",
    "id" : 413242282188345345,
    "created_at" : "2013-12-18 09:40:12 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 414367462722117632,
  "created_at" : "2013-12-21 12:11:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/t07TVIGG31",
      "expanded_url" : "http:\/\/www.opendemocracy.net\/alex-doherty\/mandela-and-cuba-another-memory-hole",
      "display_url" : "opendemocracy.net\/alex-doherty\/m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "414360965610622976",
  "text" : "Mandela and Cuba: another memory hole http:\/\/t.co\/t07TVIGG31",
  "id" : 414360965610622976,
  "created_at" : "2013-12-21 11:45:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Hardie",
      "screen_name" : "HardieResearch",
      "indices" : [ 3, 18 ],
      "id_str" : "970452764",
      "id" : 970452764
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CQPweb",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/ClHBISrJSr",
      "expanded_url" : "http:\/\/www.youtube.com\/playlist?list=PL2XtJIhhrHNQgf4Dp6sckGZRU4NiUVw1e",
      "display_url" : "youtube.com\/playlist?list=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "414136112681328640",
  "text" : "RT @HardieResearch: (2\/4) .... all tutorials are, incidentally, collected together for you in handy playlist form at this link: http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CQPweb",
        "indices" : [ 132, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/ClHBISrJSr",
        "expanded_url" : "http:\/\/www.youtube.com\/playlist?list=PL2XtJIhhrHNQgf4Dp6sckGZRU4NiUVw1e",
        "display_url" : "youtube.com\/playlist?list=\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "414111251623464960",
    "text" : "(2\/4) .... all tutorials are, incidentally, collected together for you in handy playlist form at this link: http:\/\/t.co\/ClHBISrJSr  #CQPweb",
    "id" : 414111251623464960,
    "created_at" : "2013-12-20 19:13:10 +0000",
    "user" : {
      "name" : "Andrew Hardie",
      "screen_name" : "HardieResearch",
      "protected" : false,
      "id_str" : "970452764",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2895091886\/5274f8f34de87999703c0f92adfdf465_normal.jpeg",
      "id" : 970452764,
      "verified" : false
    }
  },
  "id" : 414136112681328640,
  "created_at" : "2013-12-20 20:51:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "indices" : [ 3, 15 ],
      "id_str" : "192437743",
      "id" : 192437743
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELTResearch",
      "indices" : [ 37, 49 ]
    }, {
      "text" : "esl",
      "indices" : [ 119, 123 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 124, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/oFr5CQM3ME",
      "expanded_url" : "http:\/\/bit.ly\/1dqhuu6",
      "display_url" : "bit.ly\/1dqhuu6"
    } ]
  },
  "geo" : { },
  "id_str" : "414119551677509632",
  "text" : "RT @nathanghall: My post for the 2nd #ELTResearch Blog Carnival | Controlling | ELT Reflections http:\/\/t.co\/oFr5CQM3ME #esl #eltchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELTResearch",
        "indices" : [ 20, 32 ]
      }, {
        "text" : "esl",
        "indices" : [ 102, 106 ]
      }, {
        "text" : "eltchat",
        "indices" : [ 107, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/oFr5CQM3ME",
        "expanded_url" : "http:\/\/bit.ly\/1dqhuu6",
        "display_url" : "bit.ly\/1dqhuu6"
      } ]
    },
    "geo" : { },
    "id_str" : "414082339967234048",
    "text" : "My post for the 2nd #ELTResearch Blog Carnival | Controlling | ELT Reflections http:\/\/t.co\/oFr5CQM3ME #esl #eltchat",
    "id" : 414082339967234048,
    "created_at" : "2013-12-20 17:18:17 +0000",
    "user" : {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "protected" : false,
      "id_str" : "192437743",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/715691315158061056\/_00s_D48_normal.jpg",
      "id" : 192437743,
      "verified" : false
    }
  },
  "id" : 414119551677509632,
  "created_at" : "2013-12-20 19:46:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Aisha Brown",
      "screen_name" : "amyaishab",
      "indices" : [ 3, 13 ],
      "id_str" : "900029641",
      "id" : 900029641
    }, {
      "name" : "Theron Muller",
      "screen_name" : "theronmuller",
      "indices" : [ 139, 140 ],
      "id_str" : "84823513",
      "id" : 84823513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/J018XftnwI",
      "expanded_url" : "http:\/\/bit.ly\/1gL1MiJ",
      "display_url" : "bit.ly\/1gL1MiJ"
    } ]
  },
  "geo" : { },
  "id_str" : "414116216874487809",
  "text" : "RT @amyaishab: Interactive documentary investigating the manipulative power of language (with social media data) http:\/\/t.co\/J018XftnwI via\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Theron Muller",
        "screen_name" : "theronmuller",
        "indices" : [ 125, 138 ],
        "id_str" : "84823513",
        "id" : 84823513
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/J018XftnwI",
        "expanded_url" : "http:\/\/bit.ly\/1gL1MiJ",
        "display_url" : "bit.ly\/1gL1MiJ"
      } ]
    },
    "geo" : { },
    "id_str" : "414115027587973120",
    "text" : "Interactive documentary investigating the manipulative power of language (with social media data) http:\/\/t.co\/J018XftnwI via @theronmuller",
    "id" : 414115027587973120,
    "created_at" : "2013-12-20 19:28:11 +0000",
    "user" : {
      "name" : "Amy Aisha Brown",
      "screen_name" : "amyaishab",
      "protected" : false,
      "id_str" : "900029641",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/620604005799067648\/nD3nCCXK_normal.jpg",
      "id" : 900029641,
      "verified" : false
    }
  },
  "id" : 414116216874487809,
  "created_at" : "2013-12-20 19:32:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "itdi.pro",
      "screen_name" : "iTDipro",
      "indices" : [ 3, 11 ],
      "id_str" : "374391424",
      "id" : 374391424
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iTDi",
      "indices" : [ 71, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/dB0aHWf1ZO",
      "expanded_url" : "http:\/\/itdi.pro\/blog\/2013\/12\/20\/the-professionalism-issue-divya\/",
      "display_url" : "itdi.pro\/blog\/2013\/12\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "414114276920799232",
  "text" : "RT @iTDipro: The Professionalism Issue - Divya: http:\/\/t.co\/dB0aHWf1ZO #iTDi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "iTDi",
        "indices" : [ 58, 63 ]
      } ],
      "urls" : [ {
        "indices" : [ 35, 57 ],
        "url" : "http:\/\/t.co\/dB0aHWf1ZO",
        "expanded_url" : "http:\/\/itdi.pro\/blog\/2013\/12\/20\/the-professionalism-issue-divya\/",
        "display_url" : "itdi.pro\/blog\/2013\/12\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "413929300216143872",
    "text" : "The Professionalism Issue - Divya: http:\/\/t.co\/dB0aHWf1ZO #iTDi",
    "id" : 413929300216143872,
    "created_at" : "2013-12-20 07:10:10 +0000",
    "user" : {
      "name" : "itdi.pro",
      "screen_name" : "iTDipro",
      "protected" : false,
      "id_str" : "374391424",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1597476537\/iTDinstituteTwitter_normal.png",
      "id" : 374391424,
      "verified" : false
    }
  },
  "id" : 414114276920799232,
  "created_at" : "2013-12-20 19:25:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "stevemuir",
      "screen_name" : "steve_muir",
      "indices" : [ 12, 23 ],
      "id_str" : "18537988",
      "id" : 18537988
    }, {
      "name" : "C Rebuffet-Broadus",
      "screen_name" : "RebuffetBroadus",
      "indices" : [ 24, 40 ],
      "id_str" : "22635290",
      "id" : 22635290
    }, {
      "name" : "Divya Madhavan",
      "screen_name" : "_divyamadhavan",
      "indices" : [ 41, 56 ],
      "id_str" : "408492806",
      "id" : 408492806
    }, {
      "name" : "Chia Suan Chong",
      "screen_name" : "chiasuan",
      "indices" : [ 57, 66 ],
      "id_str" : "71588589",
      "id" : 71588589
    }, {
      "name" : "Jo Sayers",
      "screen_name" : "jo_sayers",
      "indices" : [ 67, 77 ],
      "id_str" : "87176766",
      "id" : 87176766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "413975460213571586",
  "geo" : { },
  "id_str" : "414088651333570560",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan @steve_muir @RebuffetBroadus @_divyamadhavan @chiasuan @jo_sayers hey up leo :)",
  "id" : 414088651333570560,
  "in_reply_to_status_id" : 413975460213571586,
  "created_at" : "2013-12-20 17:43:22 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    }, {
      "name" : "Vicky Loras",
      "screen_name" : "vickyloras",
      "indices" : [ 13, 24 ],
      "id_str" : "95957241",
      "id" : 95957241
    }, {
      "name" : "Anna Loseva",
      "screen_name" : "AnnLoseva",
      "indices" : [ 25, 35 ],
      "id_str" : "38822368",
      "id" : 38822368
    }, {
      "name" : "Ljiljana Havran",
      "screen_name" : "LjiljanaHavran",
      "indices" : [ 36, 51 ],
      "id_str" : "1395825290",
      "id" : 1395825290
    }, {
      "name" : "Jo Cummins",
      "screen_name" : "jo_cummins",
      "indices" : [ 52, 63 ],
      "id_str" : "897738066",
      "id" : 897738066
    }, {
      "name" : "Ratnavathy",
      "screen_name" : "Ratnavathy",
      "indices" : [ 64, 75 ],
      "id_str" : "47061068",
      "id" : 47061068
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "413876352329068544",
  "geo" : { },
  "id_str" : "414088585264893952",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler @vickyloras @AnnLoseva @LjiljanaHavran @jo_cummins @Ratnavathy cheers anne :)",
  "id" : 414088585264893952,
  "in_reply_to_status_id" : 413876352329068544,
  "created_at" : "2013-12-20 17:43:06 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Alec Couros",
      "screen_name" : "courosa",
      "indices" : [ 3, 11 ],
      "id_str" : "739293",
      "id" : 739293
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "k12",
      "indices" : [ 98, 102 ]
    }, {
      "text" : "higherEd",
      "indices" : [ 103, 112 ]
    }, {
      "text" : "engagement",
      "indices" : [ 113, 124 ]
    }, {
      "text" : "reform",
      "indices" : [ 125, 132 ]
    }, {
      "text" : "voice",
      "indices" : [ 133, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/npWbctczyg",
      "expanded_url" : "http:\/\/bored.brightcontext.com\/?utm_source=internal&utm_medium=intext&utm_campaign=curated",
      "display_url" : "bored.brightcontext.com\/?utm_source=in\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "413685724417110017",
  "text" : "RT @courosa: Real-time map of those tweeting about being bored in school - http:\/\/t.co\/npWbctczyg #k12 #higherEd #engagement #reform #voice",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "k12",
        "indices" : [ 85, 89 ]
      }, {
        "text" : "higherEd",
        "indices" : [ 90, 99 ]
      }, {
        "text" : "engagement",
        "indices" : [ 100, 111 ]
      }, {
        "text" : "reform",
        "indices" : [ 112, 119 ]
      }, {
        "text" : "voice",
        "indices" : [ 120, 126 ]
      } ],
      "urls" : [ {
        "indices" : [ 62, 84 ],
        "url" : "http:\/\/t.co\/npWbctczyg",
        "expanded_url" : "http:\/\/bored.brightcontext.com\/?utm_source=internal&utm_medium=intext&utm_campaign=curated",
        "display_url" : "bored.brightcontext.com\/?utm_source=in\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "413495790531657728",
    "text" : "Real-time map of those tweeting about being bored in school - http:\/\/t.co\/npWbctczyg #k12 #higherEd #engagement #reform #voice",
    "id" : 413495790531657728,
    "created_at" : "2013-12-19 02:27:33 +0000",
    "user" : {
      "name" : "Dr. Alec Couros",
      "screen_name" : "courosa",
      "protected" : false,
      "id_str" : "739293",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/480186733221249027\/bzI2RIfo_normal.jpeg",
      "id" : 739293,
      "verified" : false
    }
  },
  "id" : 413685724417110017,
  "created_at" : "2013-12-19 15:02:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kamaroth",
      "screen_name" : "kamaroth1",
      "indices" : [ 0, 10 ],
      "id_str" : "1184021592",
      "id" : 1184021592
    }, {
      "name" : "Amy Aisha Brown",
      "screen_name" : "amyaishab",
      "indices" : [ 57, 67 ],
      "id_str" : "900029641",
      "id" : 900029641
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/wNHTenUw9Q",
      "expanded_url" : "http:\/\/www.invisibleoranges.com\/2013\/11\/death-metal-english\/",
      "display_url" : "invisibleoranges.com\/2013\/11\/death-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "413678977694191616",
  "in_reply_to_user_id" : 1184021592,
  "text" : "@kamaroth1 Death Metal English http:\/\/t.co\/wNHTenUw9Q ht @amyaishab",
  "id" : 413678977694191616,
  "created_at" : "2013-12-19 14:35:28 +0000",
  "in_reply_to_screen_name" : "kamaroth1",
  "in_reply_to_user_id_str" : "1184021592",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Modern Languages UoS",
      "screen_name" : "ModernLangs",
      "indices" : [ 3, 15 ],
      "id_str" : "61283773",
      "id" : 61283773
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/ODt2iKAgbJ",
      "expanded_url" : "http:\/\/bit.ly\/1ea7slX",
      "display_url" : "bit.ly\/1ea7slX"
    } ]
  },
  "geo" : { },
  "id_str" : "413641937485586433",
  "text" : "RT @ModernLangs: Free online videos for English teachers' professional development from Univ of Southampton:: \nhttp:\/\/t.co\/ODt2iKAgbJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/ODt2iKAgbJ",
        "expanded_url" : "http:\/\/bit.ly\/1ea7slX",
        "display_url" : "bit.ly\/1ea7slX"
      } ]
    },
    "geo" : { },
    "id_str" : "411478804050087936",
    "text" : "Free online videos for English teachers' professional development from Univ of Southampton:: \nhttp:\/\/t.co\/ODt2iKAgbJ",
    "id" : 411478804050087936,
    "created_at" : "2013-12-13 12:52:46 +0000",
    "user" : {
      "name" : "Modern Languages UoS",
      "screen_name" : "ModernLangs",
      "protected" : false,
      "id_str" : "61283773",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/728524862621405185\/LyC2iYtp_normal.jpg",
      "id" : 61283773,
      "verified" : false
    }
  },
  "id" : 413641937485586433,
  "created_at" : "2013-12-19 12:08:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "413477611478581250",
  "geo" : { },
  "id_str" : "413572884091510784",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler thanks for share :)",
  "id" : 413572884091510784,
  "in_reply_to_status_id" : 413477611478581250,
  "created_at" : "2013-12-19 07:33:54 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 0, 12 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "413473580853129216",
  "geo" : { },
  "id_str" : "413572791292542976",
  "in_reply_to_user_id" : 525013404,
  "text" : "@AnneHendler no worrries great feedback post",
  "id" : 413572791292542976,
  "in_reply_to_status_id" : 413473580853129216,
  "created_at" : "2013-12-19 07:33:31 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 103, 119 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/zaEOG8YEvZ",
      "expanded_url" : "http:\/\/wp.me\/pbMLY-G4",
      "display_url" : "wp.me\/pbMLY-G4"
    } ]
  },
  "geo" : { },
  "id_str" : "413572569283850240",
  "text" : "Now Available: The Dortmund Historical Corpus of Classroom English (DOHCCE) http:\/\/t.co\/zaEOG8YEvZ via @wordpressdotcom",
  "id" : 413572569283850240,
  "created_at" : "2013-12-19 07:32:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Timothy Tate",
      "screen_name" : "Timothy_Tate",
      "indices" : [ 0, 13 ],
      "id_str" : "1084531170",
      "id" : 1084531170
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/moB31xrDF1",
      "expanded_url" : "http:\/\/www.peachnote.com\/",
      "display_url" : "peachnote.com"
    } ]
  },
  "geo" : { },
  "id_str" : "413427446256373760",
  "in_reply_to_user_id" : 1084531170,
  "text" : "@Timothy_Tate Music Ngram Viewer: enter melodies, displays how those melodies have occurred in corpus http:\/\/t.co\/moB31xrDF1",
  "id" : 413427446256373760,
  "created_at" : "2013-12-18 21:55:58 +0000",
  "in_reply_to_screen_name" : "Timothy_Tate",
  "in_reply_to_user_id_str" : "1084531170",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Phipps",
      "screen_name" : "lousylinguist",
      "indices" : [ 3, 17 ],
      "id_str" : "48459936",
      "id" : 48459936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/9HW7t275Xh",
      "expanded_url" : "http:\/\/www.peachnote.com\/info.html",
      "display_url" : "peachnote.com\/info.html"
    } ]
  },
  "geo" : { },
  "id_str" : "413426779970625537",
  "text" : "RT @lousylinguist: Whoa, cool! Just discovered Music Ngram Viewer: enter melodies, displays how those melodies have occurred in corpus http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/9HW7t275Xh",
        "expanded_url" : "http:\/\/www.peachnote.com\/info.html",
        "display_url" : "peachnote.com\/info.html"
      } ]
    },
    "geo" : { },
    "id_str" : "413402031702163456",
    "text" : "Whoa, cool! Just discovered Music Ngram Viewer: enter melodies, displays how those melodies have occurred in corpus http:\/\/t.co\/9HW7t275Xh",
    "id" : 413402031702163456,
    "created_at" : "2013-12-18 20:14:59 +0000",
    "user" : {
      "name" : "Christopher Phipps",
      "screen_name" : "lousylinguist",
      "protected" : false,
      "id_str" : "48459936",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750789987113660416\/2IPugaM9_normal.jpg",
      "id" : 48459936,
      "verified" : false
    }
  },
  "id" : 413426779970625537,
  "created_at" : "2013-12-18 21:53:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BEBC",
      "screen_name" : "Books4English",
      "indices" : [ 48, 62 ],
      "id_str" : "181893496",
      "id" : 181893496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "413373864127647744",
  "text" : "looking to train students on plagiarism look to @Books4English blog :\/ their latest new post combines web with a pdf",
  "id" : 413373864127647744,
  "created_at" : "2013-12-18 18:23:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 3, 15 ],
      "id_str" : "525013404",
      "id" : 525013404
    }, {
      "name" : "Matthew Walker",
      "screen_name" : "esltasks",
      "indices" : [ 91, 100 ],
      "id_str" : "358765485",
      "id" : 358765485
    }, {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 101, 117 ],
      "id_str" : "394053348",
      "id" : 394053348
    }, {
      "name" : "Josette LeBlanc",
      "screen_name" : "JosetteLB",
      "indices" : [ 118, 128 ],
      "id_str" : "33503694",
      "id" : 33503694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/PKw9C1s0F3",
      "expanded_url" : "http:\/\/wp.me\/p2izcv-fI",
      "display_url" : "wp.me\/p2izcv-fI"
    } ]
  },
  "geo" : { },
  "id_str" : "413370149069414400",
  "text" : "RT @AnneHendler: New Blog Post: \"Collecting and Using Feedback\" http:\/\/t.co\/PKw9C1s0F3 cc: @esltasks @michaelegriffin @josettelb Thanks for\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Matthew Walker",
        "screen_name" : "esltasks",
        "indices" : [ 74, 83 ],
        "id_str" : "358765485",
        "id" : 358765485
      }, {
        "name" : "Michael Griffin",
        "screen_name" : "michaelegriffin",
        "indices" : [ 84, 100 ],
        "id_str" : "394053348",
        "id" : 394053348
      }, {
        "name" : "Josette LeBlanc",
        "screen_name" : "JosetteLB",
        "indices" : [ 101, 111 ],
        "id_str" : "33503694",
        "id" : 33503694
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 69 ],
        "url" : "http:\/\/t.co\/PKw9C1s0F3",
        "expanded_url" : "http:\/\/wp.me\/p2izcv-fI",
        "display_url" : "wp.me\/p2izcv-fI"
      } ]
    },
    "geo" : { },
    "id_str" : "413357460276002816",
    "text" : "New Blog Post: \"Collecting and Using Feedback\" http:\/\/t.co\/PKw9C1s0F3 cc: @esltasks @michaelegriffin @josettelb Thanks for all your support!",
    "id" : 413357460276002816,
    "created_at" : "2013-12-18 17:17:53 +0000",
    "user" : {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "protected" : false,
      "id_str" : "525013404",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766910187911405568\/zw3Ez5M0_normal.jpg",
      "id" : 525013404,
      "verified" : false
    }
  },
  "id" : 413370149069414400,
  "created_at" : "2013-12-18 18:08:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 72, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/PNUpkUx89G",
      "expanded_url" : "http:\/\/haideethomson.com\/?p=183",
      "display_url" : "haideethomson.com\/?p=183"
    } ]
  },
  "geo" : { },
  "id_str" : "413337433925619712",
  "text" : "Vocab@Vic presentation: Noticing lexical bundles http:\/\/t.co\/PNUpkUx89G #eltchat",
  "id" : 413337433925619712,
  "created_at" : "2013-12-18 15:58:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cdmblogs",
      "screen_name" : "cdmblogs",
      "indices" : [ 3, 12 ],
      "id_str" : "15739035",
      "id" : 15739035
    }, {
      "name" : "kidkameleon",
      "screen_name" : "kidkameleon",
      "indices" : [ 124, 136 ],
      "id_str" : "17951292",
      "id" : 17951292
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/qHklp5PUvh",
      "expanded_url" : "http:\/\/createdigitalmusic.com\/2013\/12\/10-great-releases-2013-might-missed\/",
      "display_url" : "createdigitalmusic.com\/2013\/12\/10-gre\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "413084746290581504",
  "text" : "RT @cdmblogs: 10 great releases from 2013 you might've missed http:\/\/t.co\/qHklp5PUvh - listening, music videos in a list by @kidkameleon",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "kidkameleon",
        "screen_name" : "kidkameleon",
        "indices" : [ 110, 122 ],
        "id_str" : "17951292",
        "id" : 17951292
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 70 ],
        "url" : "http:\/\/t.co\/qHklp5PUvh",
        "expanded_url" : "http:\/\/createdigitalmusic.com\/2013\/12\/10-great-releases-2013-might-missed\/",
        "display_url" : "createdigitalmusic.com\/2013\/12\/10-gre\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "413005994138927104",
    "text" : "10 great releases from 2013 you might've missed http:\/\/t.co\/qHklp5PUvh - listening, music videos in a list by @kidkameleon",
    "id" : 413005994138927104,
    "created_at" : "2013-12-17 18:01:16 +0000",
    "user" : {
      "name" : "cdmblogs",
      "screen_name" : "cdmblogs",
      "protected" : false,
      "id_str" : "15739035",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464778218445094912\/zvQnoKfw_normal.png",
      "id" : 15739035,
      "verified" : false
    }
  },
  "id" : 413084746290581504,
  "created_at" : "2013-12-17 23:14:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Pride",
      "screen_name" : "ThomasPride",
      "indices" : [ 115, 127 ],
      "id_str" : "385867551",
      "id" : 385867551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/jJgYuCIFJX",
      "expanded_url" : "http:\/\/wp.me\/p1U04a-5Yu",
      "display_url" : "wp.me\/p1U04a-5Yu"
    } ]
  },
  "geo" : { },
  "id_str" : "412967437819080706",
  "text" : "'Anal knitter' Iain Duncan Smith knits policies with facts taken straight from his anus http:\/\/t.co\/jJgYuCIFJX via @ThomasPride",
  "id" : 412967437819080706,
  "created_at" : "2013-12-17 15:28:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Costas Gabrielatos",
      "screen_name" : "congabonga",
      "indices" : [ 0, 11 ],
      "id_str" : "187484412",
      "id" : 187484412
    }, {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "indices" : [ 12, 23 ],
      "id_str" : "152051625",
      "id" : 152051625
    }, {
      "name" : "Daniel Shore",
      "screen_name" : "DanAShore",
      "indices" : [ 24, 34 ],
      "id_str" : "1261926600",
      "id" : 1261926600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/pxnX5wjVNq",
      "expanded_url" : "http:\/\/languagelog.ldc.upenn.edu\/nll\/?p=4258#comment-273707",
      "display_url" : "languagelog.ldc.upenn.edu\/nll\/?p=4258#co\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "412964313331019776",
  "geo" : { },
  "id_str" : "412965499262095361",
  "in_reply_to_user_id" : 187484412,
  "text" : "@congabonga @heatherfro @DanAShore interesting tidbit here re COCA google ngram corpus POS tagging http:\/\/t.co\/pxnX5wjVNq",
  "id" : 412965499262095361,
  "in_reply_to_status_id" : 412964313331019776,
  "created_at" : "2013-12-17 15:20:22 +0000",
  "in_reply_to_screen_name" : "congabonga",
  "in_reply_to_user_id_str" : "187484412",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "indices" : [ 0, 11 ],
      "id_str" : "152051625",
      "id" : 152051625
    }, {
      "name" : "Daniel Shore",
      "screen_name" : "DanAShore",
      "indices" : [ 12, 22 ],
      "id_str" : "1261926600",
      "id" : 1261926600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/gSQkZeX7ix",
      "expanded_url" : "http:\/\/aclweb.org\/anthology\/\/P\/P12\/P12-3029.pdf",
      "display_url" : "aclweb.org\/anthology\/\/P\/P\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "412957938806841344",
  "geo" : { },
  "id_str" : "412961872359337984",
  "in_reply_to_user_id" : 152051625,
  "text" : "@heatherfro @DanAShore any refs? so COCA does not do dependency parsing? http:\/\/t.co\/gSQkZeX7ix",
  "id" : 412961872359337984,
  "in_reply_to_status_id" : 412957938806841344,
  "created_at" : "2013-12-17 15:05:57 +0000",
  "in_reply_to_screen_name" : "heatherfro",
  "in_reply_to_user_id_str" : "152051625",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "indices" : [ 0, 11 ],
      "id_str" : "152051625",
      "id" : 152051625
    }, {
      "name" : "Daniel Shore",
      "screen_name" : "DanAShore",
      "indices" : [ 12, 22 ],
      "id_str" : "1261926600",
      "id" : 1261926600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "412947285840916481",
  "geo" : { },
  "id_str" : "412957633226608641",
  "in_reply_to_user_id" : 152051625,
  "text" : "@heatherfro @DanAShore hmm sorry for being dense i don't see diff in n-grams btw two? they are both looking at consecutive sequences no?",
  "id" : 412957633226608641,
  "in_reply_to_status_id" : 412947285840916481,
  "created_at" : "2013-12-17 14:49:06 +0000",
  "in_reply_to_screen_name" : "heatherfro",
  "in_reply_to_user_id_str" : "152051625",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 3, 17 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/ZByBX5PS5x",
      "expanded_url" : "http:\/\/hackeducation.com\/2013\/12\/16\/top-ed-tech-trends-2013-open",
      "display_url" : "hackeducation.com\/2013\/12\/16\/top\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412908534045892608",
  "text" : "RT @audreywatters: Top Ed-Tech Trends of 2013: The Battle for \"Open\" http:\/\/t.co\/ZByBX5PS5x",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 72 ],
        "url" : "http:\/\/t.co\/ZByBX5PS5x",
        "expanded_url" : "http:\/\/hackeducation.com\/2013\/12\/16\/top-ed-tech-trends-2013-open",
        "display_url" : "hackeducation.com\/2013\/12\/16\/top\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "412700555438350337",
    "text" : "Top Ed-Tech Trends of 2013: The Battle for \"Open\" http:\/\/t.co\/ZByBX5PS5x",
    "id" : 412700555438350337,
    "created_at" : "2013-12-16 21:47:34 +0000",
    "user" : {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "protected" : false,
      "id_str" : "25388528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711668009723498496\/pauFZsdv_normal.jpg",
      "id" : 25388528,
      "verified" : false
    }
  },
  "id" : 412908534045892608,
  "created_at" : "2013-12-17 11:34:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anne Hodgson",
      "screen_name" : "annehodg",
      "indices" : [ 3, 12 ],
      "id_str" : "17589213",
      "id" : 17589213
    }, {
      "name" : "Today I Found Out",
      "screen_name" : "TodayIFoundOut1",
      "indices" : [ 95, 111 ],
      "id_str" : "104983720",
      "id" : 104983720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/v8uxtejxD2",
      "expanded_url" : "http:\/\/goo.gl\/MQCffI",
      "display_url" : "goo.gl\/MQCffI"
    } ]
  },
  "geo" : { },
  "id_str" : "412898825880473600",
  "text" : "RT @annehodg: Why British Singers Lose Their Accents When Singing - http:\/\/t.co\/v8uxtejxD2 via @TodayIFoundOut1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.shareaholic.com\" rel=\"nofollow\"\u003Eshareaholic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Today I Found Out",
        "screen_name" : "TodayIFoundOut1",
        "indices" : [ 81, 97 ],
        "id_str" : "104983720",
        "id" : 104983720
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 76 ],
        "url" : "http:\/\/t.co\/v8uxtejxD2",
        "expanded_url" : "http:\/\/goo.gl\/MQCffI",
        "display_url" : "goo.gl\/MQCffI"
      } ]
    },
    "geo" : { },
    "id_str" : "412880999748747264",
    "text" : "Why British Singers Lose Their Accents When Singing - http:\/\/t.co\/v8uxtejxD2 via @TodayIFoundOut1",
    "id" : 412880999748747264,
    "created_at" : "2013-12-17 09:44:35 +0000",
    "user" : {
      "name" : "Anne Hodgson",
      "screen_name" : "annehodg",
      "protected" : false,
      "id_str" : "17589213",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618152681920724993\/9dLkbtqM_normal.jpg",
      "id" : 17589213,
      "verified" : false
    }
  },
  "id" : 412898825880473600,
  "created_at" : "2013-12-17 10:55:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "indices" : [ 3, 14 ],
      "id_str" : "152051625",
      "id" : 152051625
    }, {
      "name" : "Daniel Allington",
      "screen_name" : "dr_d_allington",
      "indices" : [ 19, 34 ],
      "id_str" : "1287008022",
      "id" : 1287008022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/FLBtyW2Jv0",
      "expanded_url" : "http:\/\/bit.ly\/1cMZLiw",
      "display_url" : "bit.ly\/1cMZLiw"
    } ]
  },
  "geo" : { },
  "id_str" : "412872071845531648",
  "text" : "RT @heatherfro: MT @dr_d_allington: video of Ann Hewings's and my intro to corpus analysis is online: http:\/\/t.co\/FLBtyW2Jv0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Daniel Allington",
        "screen_name" : "dr_d_allington",
        "indices" : [ 3, 18 ],
        "id_str" : "1287008022",
        "id" : 1287008022
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/FLBtyW2Jv0",
        "expanded_url" : "http:\/\/bit.ly\/1cMZLiw",
        "display_url" : "bit.ly\/1cMZLiw"
      } ]
    },
    "geo" : { },
    "id_str" : "412693387016298496",
    "text" : "MT @dr_d_allington: video of Ann Hewings's and my intro to corpus analysis is online: http:\/\/t.co\/FLBtyW2Jv0",
    "id" : 412693387016298496,
    "created_at" : "2013-12-16 21:19:05 +0000",
    "user" : {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "protected" : false,
      "id_str" : "152051625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/688767277022494720\/KMrzOBc1_normal.jpg",
      "id" : 152051625,
      "verified" : false
    }
  },
  "id" : 412872071845531648,
  "created_at" : "2013-12-17 09:09:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/pxV5ucNaar",
      "expanded_url" : "http:\/\/tm.durusau.net\/?p=48311",
      "display_url" : "tm.durusau.net\/?p=48311"
    } ]
  },
  "geo" : { },
  "id_str" : "412869393526173696",
  "text" : "The Real Privacy Problem http:\/\/t.co\/pxV5ucNaar",
  "id" : 412869393526173696,
  "created_at" : "2013-12-17 08:58:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "English at work",
      "screen_name" : "englishatworkbr",
      "indices" : [ 0, 16 ],
      "id_str" : "138096174",
      "id" : 138096174
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "412830947604979712",
  "geo" : { },
  "id_str" : "412865521755774976",
  "in_reply_to_user_id" : 138096174,
  "text" : "@englishatworkbr hi there, what did i share?",
  "id" : 412865521755774976,
  "in_reply_to_status_id" : 412830947604979712,
  "created_at" : "2013-12-17 08:43:05 +0000",
  "in_reply_to_screen_name" : "englishatworkbr",
  "in_reply_to_user_id_str" : "138096174",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CUP Linguistics",
      "screen_name" : "CambUP_LangLing",
      "indices" : [ 3, 19 ],
      "id_str" : "117051544",
      "id" : 117051544
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/c9iNWaJ7Dv",
      "expanded_url" : "http:\/\/ow.ly\/rNtdo",
      "display_url" : "ow.ly\/rNtdo"
    } ]
  },
  "geo" : { },
  "id_str" : "412693979185303552",
  "text" : "RT @CambUP_LangLing: New Blog Post: Sapir, Whorf, and the hypothesis that wasn\u2019t by Aneta Pavlenko http:\/\/t.co\/c9iNWaJ7Dv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/c9iNWaJ7Dv",
        "expanded_url" : "http:\/\/ow.ly\/rNtdo",
        "display_url" : "ow.ly\/rNtdo"
      } ]
    },
    "geo" : { },
    "id_str" : "412527646564941824",
    "text" : "New Blog Post: Sapir, Whorf, and the hypothesis that wasn\u2019t by Aneta Pavlenko http:\/\/t.co\/c9iNWaJ7Dv",
    "id" : 412527646564941824,
    "created_at" : "2013-12-16 10:20:30 +0000",
    "user" : {
      "name" : "CUP Linguistics",
      "screen_name" : "CambUP_LangLing",
      "protected" : false,
      "id_str" : "117051544",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/511827278641115137\/DQP0K7Vb_normal.jpeg",
      "id" : 117051544,
      "verified" : false
    }
  },
  "id" : 412693979185303552,
  "created_at" : "2013-12-16 21:21:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Teacher ROAR",
      "screen_name" : "TeacherROAR",
      "indices" : [ 3, 15 ],
      "id_str" : "1558774417",
      "id" : 1558774417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 142, 143 ],
      "url" : "https:\/\/t.co\/afy8OBSWQ4",
      "expanded_url" : "https:\/\/portside.org\/2013-12-16\/charters-get-kids-cubicle-ready",
      "display_url" : "portside.org\/2013-12-16\/cha\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412689343795716096",
  "text" : "RT @TeacherROAR: Want to know what a school with computers instead of teachers looks like? It already exists. Look and weep  --&gt; https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/afy8OBSWQ4",
        "expanded_url" : "https:\/\/portside.org\/2013-12-16\/charters-get-kids-cubicle-ready",
        "display_url" : "portside.org\/2013-12-16\/cha\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "412681705497976832",
    "text" : "Want to know what a school with computers instead of teachers looks like? It already exists. Look and weep  --&gt; https:\/\/t.co\/afy8OBSWQ4",
    "id" : 412681705497976832,
    "created_at" : "2013-12-16 20:32:40 +0000",
    "user" : {
      "name" : "Teacher ROAR",
      "screen_name" : "TeacherROAR",
      "protected" : false,
      "id_str" : "1558774417",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/489000703038205952\/iY7K4OxP_normal.jpeg",
      "id" : 1558774417,
      "verified" : false
    }
  },
  "id" : 412689343795716096,
  "created_at" : "2013-12-16 21:03:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/ngXeyY0ktA",
      "expanded_url" : "http:\/\/johnhilley.blogspot.co.uk\/2013\/12\/mandela-coverage-urgent-need-for.html",
      "display_url" : "johnhilley.blogspot.co.uk\/2013\/12\/mandel\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412688613387038720",
  "text" : "RT @johnwhilley: Mandela coverage - the urgent need for corporate-free media http:\/\/t.co\/ngXeyY0ktA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/ngXeyY0ktA",
        "expanded_url" : "http:\/\/johnhilley.blogspot.co.uk\/2013\/12\/mandela-coverage-urgent-need-for.html",
        "display_url" : "johnhilley.blogspot.co.uk\/2013\/12\/mandel\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "412627615787143168",
    "text" : "Mandela coverage - the urgent need for corporate-free media http:\/\/t.co\/ngXeyY0ktA",
    "id" : 412627615787143168,
    "created_at" : "2013-12-16 16:57:44 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 412688613387038720,
  "created_at" : "2013-12-16 21:00:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "evanfrendo",
      "screen_name" : "evanfrendo",
      "indices" : [ 3, 14 ],
      "id_str" : "17589664",
      "id" : 17589664
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BESIG",
      "indices" : [ 80, 86 ]
    }, {
      "text" : "ESP",
      "indices" : [ 87, 91 ]
    }, {
      "text" : "ELT",
      "indices" : [ 92, 96 ]
    }, {
      "text" : "TESOL",
      "indices" : [ 97, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/HfKUKKXnX6",
      "expanded_url" : "http:\/\/inchbyinch.de\/",
      "display_url" : "inchbyinch.de"
    } ]
  },
  "geo" : { },
  "id_str" : "412680949219229696",
  "text" : "RT @evanfrendo: Technical English Inch by Inch http:\/\/t.co\/HfKUKKXnX6 Nice idea #BESIG #ESP #ELT #TESOL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BESIG",
        "indices" : [ 64, 70 ]
      }, {
        "text" : "ESP",
        "indices" : [ 71, 75 ]
      }, {
        "text" : "ELT",
        "indices" : [ 76, 80 ]
      }, {
        "text" : "TESOL",
        "indices" : [ 81, 87 ]
      } ],
      "urls" : [ {
        "indices" : [ 31, 53 ],
        "url" : "http:\/\/t.co\/HfKUKKXnX6",
        "expanded_url" : "http:\/\/inchbyinch.de\/",
        "display_url" : "inchbyinch.de"
      } ]
    },
    "geo" : { },
    "id_str" : "412679471481626624",
    "text" : "Technical English Inch by Inch http:\/\/t.co\/HfKUKKXnX6 Nice idea #BESIG #ESP #ELT #TESOL",
    "id" : 412679471481626624,
    "created_at" : "2013-12-16 20:23:47 +0000",
    "user" : {
      "name" : "evanfrendo",
      "screen_name" : "evanfrendo",
      "protected" : false,
      "id_str" : "17589664",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1267172323\/Evan_Frendo_normal.jpg",
      "id" : 17589664,
      "verified" : false
    }
  },
  "id" : 412680949219229696,
  "created_at" : "2013-12-16 20:29:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "indices" : [ 96, 108 ],
      "id_str" : "192437743",
      "id" : 192437743
    }, {
      "name" : "Lizzie Pinard",
      "screen_name" : "LizziePinard",
      "indices" : [ 109, 122 ],
      "id_str" : "287093748",
      "id" : 287093748
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "learnerautonomy",
      "indices" : [ 20, 36 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 123, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/t6LxIszKZT",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-Kg",
      "display_url" : "wp.me\/pgHyE-Kg"
    } ]
  },
  "geo" : { },
  "id_str" : "412654201915711489",
  "text" : "2nd ELT research BC #learnerautonomy online data-driven dictionaries http:\/\/t.co\/t6LxIszKZT  cc @nathanghall @LizziePinard #eltchat",
  "id" : 412654201915711489,
  "created_at" : "2013-12-16 18:43:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Freeman",
      "screen_name" : "SnoozeInBrief",
      "indices" : [ 84, 98 ],
      "id_str" : "82947233",
      "id" : 82947233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/Eq33PqnvSx",
      "expanded_url" : "http:\/\/wp.me\/p1l5Kr-4Y",
      "display_url" : "wp.me\/p1l5Kr-4Y"
    } ]
  },
  "geo" : { },
  "id_str" : "412523383000027136",
  "text" : "A number of people doesn\u2019t understand notional agreement http:\/\/t.co\/Eq33PqnvSx via @SnoozeInBrief",
  "id" : 412523383000027136,
  "created_at" : "2013-12-16 10:03:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil Chappell",
      "screen_name" : "TESOLatMQ",
      "indices" : [ 3, 13 ],
      "id_str" : "326498171",
      "id" : 326498171
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AusELT",
      "indices" : [ 40, 47 ]
    }, {
      "text" : "TESOL",
      "indices" : [ 48, 54 ]
    }, {
      "text" : "TEFL",
      "indices" : [ 55, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/e7VN70WLyp",
      "expanded_url" : "http:\/\/www.englishprofile.org\/index.php\/corpora-in-the-classroom",
      "display_url" : "englishprofile.org\/index.php\/corp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412276632591032320",
  "text" : "RT @TESOLatMQ: Corpora in the classroom #AusELT #TESOL #TEFL http:\/\/t.co\/e7VN70WLyp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AusELT",
        "indices" : [ 25, 32 ]
      }, {
        "text" : "TESOL",
        "indices" : [ 33, 39 ]
      }, {
        "text" : "TEFL",
        "indices" : [ 40, 45 ]
      } ],
      "urls" : [ {
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/e7VN70WLyp",
        "expanded_url" : "http:\/\/www.englishprofile.org\/index.php\/corpora-in-the-classroom",
        "display_url" : "englishprofile.org\/index.php\/corp\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "411738156019765248",
    "text" : "Corpora in the classroom #AusELT #TESOL #TEFL http:\/\/t.co\/e7VN70WLyp",
    "id" : 411738156019765248,
    "created_at" : "2013-12-14 06:03:20 +0000",
    "user" : {
      "name" : "Phil Chappell",
      "screen_name" : "TESOLatMQ",
      "protected" : false,
      "id_str" : "326498171",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/760985121704910848\/NtDor7Jc_normal.jpg",
      "id" : 326498171,
      "verified" : false
    }
  },
  "id" : 412276632591032320,
  "created_at" : "2013-12-15 17:43:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/fKcrsctCgh",
      "expanded_url" : "http:\/\/www.dailymaverick.co.za\/opinionista\/2013-12-12-fog-donkey-the-only-honest-man-in-a-stadium-of-fools\/?fb_action_ids=10202272144392236&fb_action_types=og.likes&fb_source=other_multiline&action_object_map=[345758188896706]&action_type_map=[%22og.likes%22]&action_ref_map=[]#.Uq1oINIW1yy",
      "display_url" : "dailymaverick.co.za\/opinionista\/20\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412213529865760768",
  "text" : "Fog donkey: the only honest man in a stadium of fools http:\/\/t.co\/fKcrsctCgh",
  "id" : 412213529865760768,
  "created_at" : "2013-12-15 13:32:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BAWE",
      "indices" : [ 21, 26 ]
    }, {
      "text" : "learnercorpus",
      "indices" : [ 30, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/j7zfmUFABL",
      "expanded_url" : "https:\/\/plus.google.com\/104940199413423400545\/posts\/U6qCNhLgYwK",
      "display_url" : "plus.google.com\/10494019941342\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412198565461516289",
  "text" : "did u know u can use #BAWE as #learnercorpus c comments&gt; https:\/\/t.co\/j7zfmUFABL",
  "id" : 412198565461516289,
  "created_at" : "2013-12-15 12:32:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BAWE",
      "indices" : [ 51, 56 ]
    }, {
      "text" : "corpuslinguistics",
      "indices" : [ 64, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "412198394967244801",
  "text" : "Q to CL folk do you know what 1st languages are in #BAWE corpus #corpuslinguistics? thanks",
  "id" : 412198394967244801,
  "created_at" : "2013-12-15 12:32:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Brown",
      "screen_name" : "sbrowntweets",
      "indices" : [ 3, 16 ],
      "id_str" : "885343459",
      "id" : 885343459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/rOJ0AbBOho",
      "expanded_url" : "http:\/\/stevebrown70.wordpress.com\/2013\/12\/14\/what-have-i-learned\/",
      "display_url" : "stevebrown70.wordpress.com\/2013\/12\/14\/wha\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412157826501705728",
  "text" : "RT @sbrowntweets: Good morning - I sneaked this new post out last night. Here it is again in case you missed it: http:\/\/t.co\/rOJ0AbBOho",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/rOJ0AbBOho",
        "expanded_url" : "http:\/\/stevebrown70.wordpress.com\/2013\/12\/14\/what-have-i-learned\/",
        "display_url" : "stevebrown70.wordpress.com\/2013\/12\/14\/wha\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "412138967991992320",
    "text" : "Good morning - I sneaked this new post out last night. Here it is again in case you missed it: http:\/\/t.co\/rOJ0AbBOho",
    "id" : 412138967991992320,
    "created_at" : "2013-12-15 08:36:01 +0000",
    "user" : {
      "name" : "Steve Brown",
      "screen_name" : "sbrowntweets",
      "protected" : false,
      "id_str" : "885343459",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746292888405934080\/tp1_ccBF_normal.jpg",
      "id" : 885343459,
      "verified" : false
    }
  },
  "id" : 412157826501705728,
  "created_at" : "2013-12-15 09:50:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David John Bradshaw",
      "screen_name" : "djb667",
      "indices" : [ 3, 10 ],
      "id_str" : "35684587",
      "id" : 35684587
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/3ELvStf4l8",
      "expanded_url" : "http:\/\/fb.me\/1f7EFBaev",
      "display_url" : "fb.me\/1f7EFBaev"
    } ]
  },
  "geo" : { },
  "id_str" : "412157165936582656",
  "text" : "RT @djb667: British Library uploads one million public domain images to the net for remix and reuse http:\/\/t.co\/3ELvStf4l8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/3ELvStf4l8",
        "expanded_url" : "http:\/\/fb.me\/1f7EFBaev",
        "display_url" : "fb.me\/1f7EFBaev"
      } ]
    },
    "geo" : { },
    "id_str" : "412155901278035968",
    "text" : "British Library uploads one million public domain images to the net for remix and reuse http:\/\/t.co\/3ELvStf4l8",
    "id" : 412155901278035968,
    "created_at" : "2013-12-15 09:43:19 +0000",
    "user" : {
      "name" : "David John Bradshaw",
      "screen_name" : "djb667",
      "protected" : false,
      "id_str" : "35684587",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/674591730537250816\/7QJnmebI_normal.jpg",
      "id" : 35684587,
      "verified" : false
    }
  },
  "id" : 412157165936582656,
  "created_at" : "2013-12-15 09:48:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 63, 71 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/NHMb7NS3eT",
      "expanded_url" : "http:\/\/youtu.be\/M_3T-Af57Pg",
      "display_url" : "youtu.be\/M_3T-Af57Pg"
    } ]
  },
  "geo" : { },
  "id_str" : "412147867894038528",
  "text" : "How does the financial system work: http:\/\/t.co\/NHMb7NS3eT via @youtube",
  "id" : 412147867894038528,
  "created_at" : "2013-12-15 09:11:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angus B Grieve-Smith",
      "screen_name" : "grvsmth",
      "indices" : [ 3, 11 ],
      "id_str" : "22381639",
      "id" : 22381639
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/grvsmth\/status\/412034324486041600\/photo\/1",
      "indices" : [ 124, 140 ],
      "url" : "http:\/\/t.co\/gBUHnxmiRA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BbfXCPDCAAExLsb.png",
      "id_str" : "412034324326645761",
      "id" : 412034324326645761,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbfXCPDCAAExLsb.png",
      "sizes" : [ {
        "h" : 176,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 310,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 519,
        "resize" : "fit",
        "w" : 1004
      }, {
        "h" : 519,
        "resize" : "fit",
        "w" : 1004
      } ],
      "display_url" : "pic.twitter.com\/gBUHnxmiRA"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/MHJ8bD9Yxd",
      "expanded_url" : "http:\/\/grieve-smith.com\/blog\/2013\/12\/existentials-and-universals\/",
      "display_url" : "grieve-smith.com\/blog\/2013\/12\/e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412138050895216640",
  "text" : "RT @grvsmth: New post: Existential and universal statements, and how much evidence you need for them http:\/\/t.co\/MHJ8bD9Yxd http:\/\/t.co\/gBU\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/grvsmth\/status\/412034324486041600\/photo\/1",
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/gBUHnxmiRA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BbfXCPDCAAExLsb.png",
        "id_str" : "412034324326645761",
        "id" : 412034324326645761,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbfXCPDCAAExLsb.png",
        "sizes" : [ {
          "h" : 176,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 310,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 519,
          "resize" : "fit",
          "w" : 1004
        }, {
          "h" : 519,
          "resize" : "fit",
          "w" : 1004
        } ],
        "display_url" : "pic.twitter.com\/gBUHnxmiRA"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/MHJ8bD9Yxd",
        "expanded_url" : "http:\/\/grieve-smith.com\/blog\/2013\/12\/existentials-and-universals\/",
        "display_url" : "grieve-smith.com\/blog\/2013\/12\/e\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "412034324486041600",
    "text" : "New post: Existential and universal statements, and how much evidence you need for them http:\/\/t.co\/MHJ8bD9Yxd http:\/\/t.co\/gBUHnxmiRA",
    "id" : 412034324486041600,
    "created_at" : "2013-12-15 01:40:12 +0000",
    "user" : {
      "name" : "Angus B Grieve-Smith",
      "screen_name" : "grvsmth",
      "protected" : false,
      "id_str" : "22381639",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/94827231\/portrait_normal.png",
      "id" : 22381639,
      "verified" : false
    }
  },
  "id" : 412138050895216640,
  "created_at" : "2013-12-15 08:32:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WIRED",
      "screen_name" : "WIRED",
      "indices" : [ 0, 6 ],
      "id_str" : "1344951",
      "id" : 1344951
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/FQRsJRFIOx",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=PtBy_ppG4hY",
      "display_url" : "youtube.com\/watch?v=PtBy_p\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "411920941489221632",
  "geo" : { },
  "id_str" : "411926839850852352",
  "in_reply_to_user_id" : 1344951,
  "text" : "@WIRED for some reason made me think of http:\/\/t.co\/FQRsJRFIOx :)",
  "id" : 411926839850852352,
  "in_reply_to_status_id" : 411920941489221632,
  "created_at" : "2013-12-14 18:33:06 +0000",
  "in_reply_to_screen_name" : "WIRED",
  "in_reply_to_user_id_str" : "1344951",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "411844172023214080",
  "geo" : { },
  "id_str" : "411876002109730816",
  "in_reply_to_user_id" : 2228367554,
  "text" : "@teflskeptic  doh u just promoted it by linking it :)",
  "id" : 411876002109730816,
  "in_reply_to_status_id" : 411844172023214080,
  "created_at" : "2013-12-14 15:11:05 +0000",
  "in_reply_to_screen_name" : "ebefl",
  "in_reply_to_user_id_str" : "2228367554",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 83, 99 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/cB9PnfYqMF",
      "expanded_url" : "http:\/\/wp.me\/p31zUY-g6",
      "display_url" : "wp.me\/p31zUY-g6"
    } ]
  },
  "geo" : { },
  "id_str" : "411829851645952000",
  "text" : "How best to teach: knowledge-led or skills-led lessons? http:\/\/t.co\/cB9PnfYqMF via @wordpressdotcom",
  "id" : 411829851645952000,
  "created_at" : "2013-12-14 12:07:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Phipps",
      "screen_name" : "lousylinguist",
      "indices" : [ 0, 14 ],
      "id_str" : "48459936",
      "id" : 48459936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/IsNLm1ZYLU",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=hkCR-w3AYOE",
      "display_url" : "youtube.com\/watch?v=hkCR-w\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "411689666186715136",
  "geo" : { },
  "id_str" : "411829316905746432",
  "in_reply_to_user_id" : 48459936,
  "text" : "@lousylinguist the full version needs viewing http:\/\/t.co\/IsNLm1ZYLU :)",
  "id" : 411829316905746432,
  "in_reply_to_status_id" : 411689666186715136,
  "created_at" : "2013-12-14 12:05:35 +0000",
  "in_reply_to_screen_name" : "lousylinguist",
  "in_reply_to_user_id_str" : "48459936",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 16, 25 ],
      "id_str" : "121063600",
      "id" : 121063600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "411769542575403008",
  "geo" : { },
  "id_str" : "411780282056855552",
  "in_reply_to_user_id" : 121063600,
  "text" : "thanks for plug @whyshona great to see u there :)",
  "id" : 411780282056855552,
  "in_reply_to_status_id" : 411769542575403008,
  "created_at" : "2013-12-14 08:50:44 +0000",
  "in_reply_to_screen_name" : "whyshona",
  "in_reply_to_user_id_str" : "121063600",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "indices" : [ 0, 12 ],
      "id_str" : "849729062",
      "id" : 849729062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "411571851895517184",
  "geo" : { },
  "id_str" : "411583373073592320",
  "in_reply_to_user_id" : 849729062,
  "text" : "@TonyMcEnery hmm nice :)",
  "id" : 411583373073592320,
  "in_reply_to_status_id" : 411571851895517184,
  "created_at" : "2013-12-13 19:48:17 +0000",
  "in_reply_to_screen_name" : "TonyMcEnery",
  "in_reply_to_user_id_str" : "849729062",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/QwFYhyptpF",
      "expanded_url" : "http:\/\/ow.ly\/rJhQg",
      "display_url" : "ow.ly\/rJhQg"
    } ]
  },
  "geo" : { },
  "id_str" : "411557219818557440",
  "text" : "RT @medialens: Latest alert: The Media's Hypocritical Oath - Mandela And Economic Apartheid http:\/\/t.co\/QwFYhyptpF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/QwFYhyptpF",
        "expanded_url" : "http:\/\/ow.ly\/rJhQg",
        "display_url" : "ow.ly\/rJhQg"
      } ]
    },
    "geo" : { },
    "id_str" : "411443407920193537",
    "text" : "Latest alert: The Media's Hypocritical Oath - Mandela And Economic Apartheid http:\/\/t.co\/QwFYhyptpF",
    "id" : 411443407920193537,
    "created_at" : "2013-12-13 10:32:07 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 411557219818557440,
  "created_at" : "2013-12-13 18:04:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "indices" : [ 0, 12 ],
      "id_str" : "849729062",
      "id" : 849729062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 70, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "411553978921414656",
  "in_reply_to_user_id" : 849729062,
  "text" : "@TonyMcEnery word on grapevine is that a web-based antconc will be on #corpusmooc?",
  "id" : 411553978921414656,
  "created_at" : "2013-12-13 17:51:29 +0000",
  "in_reply_to_screen_name" : "TonyMcEnery",
  "in_reply_to_user_id_str" : "849729062",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheLanguagePoint",
      "screen_name" : "Marie_Sanako",
      "indices" : [ 19, 32 ],
      "id_str" : "356176087",
      "id" : 356176087
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "411538427801513984",
  "geo" : { },
  "id_str" : "411553644622782464",
  "in_reply_to_user_id" : 356176087,
  "text" : "thanks for sharing @Marie_Sanako :) enjoy yr w\/e",
  "id" : 411553644622782464,
  "in_reply_to_status_id" : 411538427801513984,
  "created_at" : "2013-12-13 17:50:09 +0000",
  "in_reply_to_screen_name" : "Marie_Sanako",
  "in_reply_to_user_id_str" : "356176087",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Natallia Novikava",
      "screen_name" : "Natashetta",
      "indices" : [ 16, 27 ],
      "id_str" : "56308635",
      "id" : 56308635
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "411416283272318977",
  "geo" : { },
  "id_str" : "411462738070609921",
  "in_reply_to_user_id" : 56308635,
  "text" : "thanx for share @Natashetta have a grt w\/e :)",
  "id" : 411462738070609921,
  "in_reply_to_status_id" : 411416283272318977,
  "created_at" : "2013-12-13 11:48:56 +0000",
  "in_reply_to_screen_name" : "Natashetta",
  "in_reply_to_user_id_str" : "56308635",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karenne Sylvester",
      "screen_name" : "kalinagoenglish",
      "indices" : [ 3, 19 ],
      "id_str" : "22755100",
      "id" : 22755100
    }, {
      "name" : "TEFL.net",
      "screen_name" : "TEFL",
      "indices" : [ 25, 30 ],
      "id_str" : "19223632",
      "id" : 19223632
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELL",
      "indices" : [ 84, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/OmtOKYMNYQ",
      "expanded_url" : "http:\/\/bit.ly\/1jO8yRA",
      "display_url" : "bit.ly\/1jO8yRA"
    } ]
  },
  "geo" : { },
  "id_str" : "411267872724647936",
  "text" : "RT @kalinagoenglish: via @TEFL Writing Challenge: Root Words http:\/\/t.co\/OmtOKYMNYQ #ELL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TEFL.net",
        "screen_name" : "TEFL",
        "indices" : [ 4, 9 ],
        "id_str" : "19223632",
        "id" : 19223632
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELL",
        "indices" : [ 63, 67 ]
      } ],
      "urls" : [ {
        "indices" : [ 40, 62 ],
        "url" : "http:\/\/t.co\/OmtOKYMNYQ",
        "expanded_url" : "http:\/\/bit.ly\/1jO8yRA",
        "display_url" : "bit.ly\/1jO8yRA"
      } ]
    },
    "geo" : { },
    "id_str" : "411038164015259648",
    "text" : "via @TEFL Writing Challenge: Root Words http:\/\/t.co\/OmtOKYMNYQ #ELL",
    "id" : 411038164015259648,
    "created_at" : "2013-12-12 07:41:49 +0000",
    "user" : {
      "name" : "Karenne Sylvester",
      "screen_name" : "kalinagoenglish",
      "protected" : false,
      "id_str" : "22755100",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1180291084\/P010910_21.41_normal.jpg",
      "id" : 22755100,
      "verified" : false
    }
  },
  "id" : 411267872724647936,
  "created_at" : "2013-12-12 22:54:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MarisaConstantinides",
      "screen_name" : "Marisa_C",
      "indices" : [ 15, 24 ],
      "id_str" : "18272500",
      "id" : 18272500
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "411266296458670080",
  "text" : "thanks for RT! @Marisa_C :)",
  "id" : 411266296458670080,
  "created_at" : "2013-12-12 22:48:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BNCaudio",
      "indices" : [ 0, 9 ]
    }, {
      "text" : "corpus",
      "indices" : [ 10, 17 ]
    }, {
      "text" : "TOEIC",
      "indices" : [ 22, 28 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 62, 70 ]
    }, {
      "text" : "tesol",
      "indices" : [ 71, 77 ]
    }, {
      "text" : "tefl",
      "indices" : [ 78, 83 ]
    }, {
      "text" : "elt",
      "indices" : [ 84, 88 ]
    }, {
      "text" : "besig",
      "indices" : [ 89, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/nfXB7hKJYc",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-JY",
      "display_url" : "wp.me\/pgHyE-JY"
    } ]
  },
  "geo" : { },
  "id_str" : "411247273113182208",
  "text" : "#BNCaudio #corpus and #TOEIC listening http:\/\/t.co\/nfXB7hKJYc #eltchat #tesol #tefl #elt #besig",
  "id" : 411247273113182208,
  "created_at" : "2013-12-12 21:32:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Patsko",
      "screen_name" : "lauraahaha",
      "indices" : [ 3, 14 ],
      "id_str" : "97957137",
      "id" : 97957137
    }, {
      "name" : "ELF Pron",
      "screen_name" : "ELF_Pron",
      "indices" : [ 132, 140 ],
      "id_str" : "2222993041",
      "id" : 2222993041
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELF",
      "indices" : [ 31, 35 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "elt",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/Rz6u3aCUEn",
      "expanded_url" : "http:\/\/elfpron.wordpress.com\/2013\/12\/08\/elf-in-a-multilingual-class-finding-common-needs\/",
      "display_url" : "elfpron.wordpress.com\/2013\/12\/08\/elf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411232450413875201",
  "text" : "RT @lauraahaha: Just posted on #ELF pronunciation - How to find areas of common need in a multilingual class http:\/\/t.co\/Rz6u3aCUEn @ELF_Pr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ELF Pron",
        "screen_name" : "ELF_Pron",
        "indices" : [ 116, 125 ],
        "id_str" : "2222993041",
        "id" : 2222993041
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELF",
        "indices" : [ 15, 19 ]
      }, {
        "text" : "eltchat",
        "indices" : [ 126, 134 ]
      }, {
        "text" : "elt",
        "indices" : [ 135, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/Rz6u3aCUEn",
        "expanded_url" : "http:\/\/elfpron.wordpress.com\/2013\/12\/08\/elf-in-a-multilingual-class-finding-common-needs\/",
        "display_url" : "elfpron.wordpress.com\/2013\/12\/08\/elf\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "411228941580795905",
    "text" : "Just posted on #ELF pronunciation - How to find areas of common need in a multilingual class http:\/\/t.co\/Rz6u3aCUEn @ELF_Pron #eltchat #elt",
    "id" : 411228941580795905,
    "created_at" : "2013-12-12 20:19:54 +0000",
    "user" : {
      "name" : "Laura Patsko",
      "screen_name" : "lauraahaha",
      "protected" : false,
      "id_str" : "97957137",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/659005852477714432\/xfuJsW6q_normal.jpg",
      "id" : 97957137,
      "verified" : false
    }
  },
  "id" : 411232450413875201,
  "created_at" : "2013-12-12 20:33:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Taylor",
      "screen_name" : "theteacherjames",
      "indices" : [ 3, 19 ],
      "id_str" : "71746265",
      "id" : 71746265
    }, {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 77, 88 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "Sue Annan",
      "screen_name" : "SueAnnan",
      "indices" : [ 89, 98 ],
      "id_str" : "136001411",
      "id" : 136001411
    }, {
      "name" : "Vicky Loras",
      "screen_name" : "vickyloras",
      "indices" : [ 105, 116 ],
      "id_str" : "95957241",
      "id" : 95957241
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 42, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/Ioyc3C8RFk",
      "expanded_url" : "http:\/\/ow.ly\/rInP3",
      "display_url" : "ow.ly\/rInP3"
    } ]
  },
  "geo" : { },
  "id_str" : "411230176304201728",
  "text" : "RT @theteacherjames: A seasonal gift from #eltchat - a new podcast featuring @leoselivan @SueAnnan &amp; @VickyLoras  http:\/\/t.co\/Ioyc3C8RFk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lexical Leo",
        "screen_name" : "leoselivan",
        "indices" : [ 56, 67 ],
        "id_str" : "408365496",
        "id" : 408365496
      }, {
        "name" : "Sue Annan",
        "screen_name" : "SueAnnan",
        "indices" : [ 68, 77 ],
        "id_str" : "136001411",
        "id" : 136001411
      }, {
        "name" : "Vicky Loras",
        "screen_name" : "vickyloras",
        "indices" : [ 84, 95 ],
        "id_str" : "95957241",
        "id" : 95957241
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "eltchat",
        "indices" : [ 21, 29 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/Ioyc3C8RFk",
        "expanded_url" : "http:\/\/ow.ly\/rInP3",
        "display_url" : "ow.ly\/rInP3"
      } ]
    },
    "geo" : { },
    "id_str" : "411226867866554368",
    "text" : "A seasonal gift from #eltchat - a new podcast featuring @leoselivan @SueAnnan &amp; @VickyLoras  http:\/\/t.co\/Ioyc3C8RFk",
    "id" : 411226867866554368,
    "created_at" : "2013-12-12 20:11:40 +0000",
    "user" : {
      "name" : "James Taylor",
      "screen_name" : "theteacherjames",
      "protected" : false,
      "id_str" : "71746265",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/595367704090939392\/nJCWaI_Z_normal.jpg",
      "id" : 71746265,
      "verified" : false
    }
  },
  "id" : 411230176304201728,
  "created_at" : "2013-12-12 20:24:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "indices" : [ 3, 14 ],
      "id_str" : "152051625",
      "id" : 152051625
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nudhl",
      "indices" : [ 85, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/IixVwO9EAA",
      "expanded_url" : "http:\/\/bit.ly\/99Vup0",
      "display_url" : "bit.ly\/99Vup0"
    } ]
  },
  "geo" : { },
  "id_str" : "411172228202778624",
  "text" : "RT @heatherfro: fyi NLTK comes with a lot of fun free corpora http:\/\/t.co\/IixVwO9EAA #nudhl leaks",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "nudhl",
        "indices" : [ 69, 75 ]
      } ],
      "urls" : [ {
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/IixVwO9EAA",
        "expanded_url" : "http:\/\/bit.ly\/99Vup0",
        "display_url" : "bit.ly\/99Vup0"
      } ]
    },
    "geo" : { },
    "id_str" : "411169513392963585",
    "text" : "fyi NLTK comes with a lot of fun free corpora http:\/\/t.co\/IixVwO9EAA #nudhl leaks",
    "id" : 411169513392963585,
    "created_at" : "2013-12-12 16:23:45 +0000",
    "user" : {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "protected" : false,
      "id_str" : "152051625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/688767277022494720\/KMrzOBc1_normal.jpg",
      "id" : 152051625,
      "verified" : false
    }
  },
  "id" : 411172228202778624,
  "created_at" : "2013-12-12 16:34:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 0, 11 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/BbPrZgNETh",
      "expanded_url" : "http:\/\/www.hltmag.co.uk\/dec13\/down.htm",
      "display_url" : "hltmag.co.uk\/dec13\/down.htm"
    } ]
  },
  "in_reply_to_status_id_str" : "411170579145052160",
  "geo" : { },
  "id_str" : "411171421935521792",
  "in_reply_to_user_id" : 408365496,
  "text" : "@leoselivan no worries, the download all articles link is not working? http:\/\/t.co\/BbPrZgNETh",
  "id" : 411171421935521792,
  "in_reply_to_status_id" : 411170579145052160,
  "created_at" : "2013-12-12 16:31:20 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 60, 68 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/GofdBL3TqW",
      "expanded_url" : "http:\/\/youtu.be\/oB9rp_SAp2U",
      "display_url" : "youtu.be\/oB9rp_SAp2U"
    } ]
  },
  "geo" : { },
  "id_str" : "411169636357386241",
  "text" : "Noam Chomsky-What is Anarchism?: http:\/\/t.co\/GofdBL3TqW via @youtube",
  "id" : 411169636357386241,
  "created_at" : "2013-12-12 16:24:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The NLP Archive",
      "screen_name" : "NewLeftProject",
      "indices" : [ 3, 18 ],
      "id_str" : "94566436",
      "id" : 94566436
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/TyJPBHFYzD",
      "expanded_url" : "http:\/\/tinyurl.com\/mwob4ad",
      "display_url" : "tinyurl.com\/mwob4ad"
    } ]
  },
  "geo" : { },
  "id_str" : "411167536336863232",
  "text" : "RT @NewLeftProject: James Arnold on the scale of British collusion with Apartheid South Africa: http:\/\/t.co\/TyJPBHFYzD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/TyJPBHFYzD",
        "expanded_url" : "http:\/\/tinyurl.com\/mwob4ad",
        "display_url" : "tinyurl.com\/mwob4ad"
      } ]
    },
    "geo" : { },
    "id_str" : "411153647016222720",
    "text" : "James Arnold on the scale of British collusion with Apartheid South Africa: http:\/\/t.co\/TyJPBHFYzD",
    "id" : 411153647016222720,
    "created_at" : "2013-12-12 15:20:42 +0000",
    "user" : {
      "name" : "The NLP Archive",
      "screen_name" : "NewLeftProject",
      "protected" : false,
      "id_str" : "94566436",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1193598594\/007b2431-54b2-41bc-89ce-f861aa5c6d88_normal.png",
      "id" : 94566436,
      "verified" : false
    }
  },
  "id" : 411167536336863232,
  "created_at" : "2013-12-12 16:15:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angus B Grieve-Smith",
      "screen_name" : "grvsmth",
      "indices" : [ 3, 11 ],
      "id_str" : "22381639",
      "id" : 22381639
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/1ualxA0A1h",
      "expanded_url" : "http:\/\/whitehousetapes.net\/transcript\/nixon",
      "display_url" : "whitehousetapes.net\/transcript\/nix\u2026"
    }, {
      "indices" : [ 127, 140 ],
      "url" : "http:\/\/t.co\/RF9wmH8GFY",
      "expanded_url" : "http:\/\/nixontapes.org\/transcripts.html",
      "display_url" : "nixontapes.org\/transcripts.ht\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411166952833691648",
  "text" : "RT @grvsmth: I'm totally tempted to write a Nixon tape twitter bot. Maybe that'll be my winter project. http:\/\/t.co\/1ualxA0A1h http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/1ualxA0A1h",
        "expanded_url" : "http:\/\/whitehousetapes.net\/transcript\/nixon",
        "display_url" : "whitehousetapes.net\/transcript\/nix\u2026"
      }, {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/RF9wmH8GFY",
        "expanded_url" : "http:\/\/nixontapes.org\/transcripts.html",
        "display_url" : "nixontapes.org\/transcripts.ht\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "411016695638003712",
    "text" : "I'm totally tempted to write a Nixon tape twitter bot. Maybe that'll be my winter project. http:\/\/t.co\/1ualxA0A1h http:\/\/t.co\/RF9wmH8GFY",
    "id" : 411016695638003712,
    "created_at" : "2013-12-12 06:16:31 +0000",
    "user" : {
      "name" : "Angus B Grieve-Smith",
      "screen_name" : "grvsmth",
      "protected" : false,
      "id_str" : "22381639",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/94827231\/portrait_normal.png",
      "id" : 22381639,
      "verified" : false
    }
  },
  "id" : 411166952833691648,
  "created_at" : "2013-12-12 16:13:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/Rtv4ba4ekV",
      "expanded_url" : "https:\/\/plus.google.com\/u\/0\/communities\/116637726668547165060",
      "display_url" : "plus.google.com\/u\/0\/communitie\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "411109829365620737",
  "geo" : { },
  "id_str" : "411110700912623616",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow a pleasure think there should be more elt podcasts :) noticed LILT community been going away from ELT? https:\/\/t.co\/Rtv4ba4ekV",
  "id" : 411110700912623616,
  "in_reply_to_status_id" : 411109829365620737,
  "created_at" : "2013-12-12 12:30:03 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 3, 14 ],
      "id_str" : "144663117",
      "id" : 144663117
    }, {
      "name" : "Phil Keegan",
      "screen_name" : "PhilKeegan66",
      "indices" : [ 30, 43 ],
      "id_str" : "919161703",
      "id" : 919161703
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 143, 144 ],
      "url" : "http:\/\/t.co\/U4NqYGAnEo",
      "expanded_url" : "http:\/\/theotherthingsmatter.blogspot.jp\/2013\/12\/plums-podcast-and-hemingway-in-no.html",
      "display_url" : "theotherthingsmatter.blogspot.jp\/2013\/12\/plums-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411108957768671233",
  "text" : "RT @kevchanwow: post thanking @PhilKeegan66 for taking my ramblings on lit in the lang class &amp; turning them into a 1st rate podcast:  http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Phil Keegan",
        "screen_name" : "PhilKeegan66",
        "indices" : [ 14, 27 ],
        "id_str" : "919161703",
        "id" : 919161703
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/U4NqYGAnEo",
        "expanded_url" : "http:\/\/theotherthingsmatter.blogspot.jp\/2013\/12\/plums-podcast-and-hemingway-in-no.html",
        "display_url" : "theotherthingsmatter.blogspot.jp\/2013\/12\/plums-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "411107450217967616",
    "text" : "post thanking @PhilKeegan66 for taking my ramblings on lit in the lang class &amp; turning them into a 1st rate podcast:  http:\/\/t.co\/U4NqYGAnEo",
    "id" : 411107450217967616,
    "created_at" : "2013-12-12 12:17:08 +0000",
    "user" : {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "protected" : false,
      "id_str" : "144663117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/559618421839507456\/nPF7dP47_normal.jpeg",
      "id" : 144663117,
      "verified" : false
    }
  },
  "id" : 411108957768671233,
  "created_at" : "2013-12-12 12:23:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anne Hodgson",
      "screen_name" : "annehodg",
      "indices" : [ 0, 9 ],
      "id_str" : "17589213",
      "id" : 17589213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "411098368547368960",
  "in_reply_to_user_id" : 17589213,
  "text" : "@annehodg thanks for the RTs :)",
  "id" : 411098368547368960,
  "created_at" : "2013-12-12 11:41:03 +0000",
  "in_reply_to_screen_name" : "annehodg",
  "in_reply_to_user_id_str" : "17589213",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/JzW7UPh1s7",
      "expanded_url" : "http:\/\/members5.boardhost.com\/medialens\/msg\/1386811715.html",
      "display_url" : "members5.boardhost.com\/medialens\/msg\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411030489164554241",
  "text" : "Impostor angers many at Madiba funeral http:\/\/t.co\/JzW7UPh1s7 :)",
  "id" : 411030489164554241,
  "created_at" : "2013-12-12 07:11:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 101, 109 ]
    }, {
      "text" : "tesol",
      "indices" : [ 110, 116 ]
    }, {
      "text" : "tefl",
      "indices" : [ 117, 122 ]
    }, {
      "text" : "elt",
      "indices" : [ 123, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/8mY8p25uoC",
      "expanded_url" : "https:\/\/plus.google.com\/104940199413423400545\/posts\/JAmpN8SKUW2",
      "display_url" : "plus.google.com\/10494019941342\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410945148269252608",
  "text" : "u like authentic audio? u like corpora? u like crowdsourcing? u'll like this https:\/\/t.co\/8mY8p25uoC #eltchat #tesol #tefl #elt",
  "id" : 410945148269252608,
  "created_at" : "2013-12-12 01:32:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Justin Tarte",
      "screen_name" : "justintarte",
      "indices" : [ 0, 12 ],
      "id_str" : "169083205",
      "id" : 169083205
    }, {
      "name" : "David Fife",
      "screen_name" : "DavidFifeVP",
      "indices" : [ 13, 25 ],
      "id_str" : "595062333",
      "id" : 595062333
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "410832410318606336",
  "geo" : { },
  "id_str" : "410913698945835008",
  "in_reply_to_user_id" : 169083205,
  "text" : "@justintarte @DavidFifeVP that's assuming you accept the googled answer as a good answer :)",
  "id" : 410913698945835008,
  "in_reply_to_status_id" : 410832410318606336,
  "created_at" : "2013-12-11 23:27:14 +0000",
  "in_reply_to_screen_name" : "justintarte",
  "in_reply_to_user_id_str" : "169083205",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 73, 84 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "410896833607909376",
  "geo" : { },
  "id_str" : "410902962475524097",
  "in_reply_to_user_id" : 408365496,
  "text" : "some great articles, i especially like the two articles by simon mumford @leoselivan cheers :)",
  "id" : 410902962475524097,
  "in_reply_to_status_id" : 410896833607909376,
  "created_at" : "2013-12-11 22:44:35 +0000",
  "in_reply_to_screen_name" : "leoselivan",
  "in_reply_to_user_id_str" : "408365496",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 3, 14 ],
      "id_str" : "408365496",
      "id" : 408365496
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tefl",
      "indices" : [ 123, 128 ]
    }, {
      "text" : "elt",
      "indices" : [ 129, 133 ]
    }, {
      "text" : "tesol",
      "indices" : [ 134, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/ZVsirWMUhx",
      "expanded_url" : "http:\/\/buff.ly\/1dqAER8",
      "display_url" : "buff.ly\/1dqAER8"
    } ]
  },
  "geo" : { },
  "id_str" : "410898409772810240",
  "text" : "RT @leoselivan: Special Lexical Issue of Humanising Language Teaching which I guest-edited is out:  http:\/\/t.co\/ZVsirWMUhx #tefl #elt #tesol",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tefl",
        "indices" : [ 107, 112 ]
      }, {
        "text" : "elt",
        "indices" : [ 113, 117 ]
      }, {
        "text" : "tesol",
        "indices" : [ 118, 124 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/ZVsirWMUhx",
        "expanded_url" : "http:\/\/buff.ly\/1dqAER8",
        "display_url" : "buff.ly\/1dqAER8"
      } ]
    },
    "geo" : { },
    "id_str" : "410896833607909376",
    "text" : "Special Lexical Issue of Humanising Language Teaching which I guest-edited is out:  http:\/\/t.co\/ZVsirWMUhx #tefl #elt #tesol",
    "id" : 410896833607909376,
    "created_at" : "2013-12-11 22:20:13 +0000",
    "user" : {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "protected" : false,
      "id_str" : "408365496",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/460546508601819136\/12ivDBb__normal.jpeg",
      "id" : 408365496,
      "verified" : false
    }
  },
  "id" : 410898409772810240,
  "created_at" : "2013-12-11 22:26:29 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samira Chaibeddra",
      "screen_name" : "SChaibeddra",
      "indices" : [ 0, 12 ],
      "id_str" : "989087534",
      "id" : 989087534
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "410708482199793664",
  "geo" : { },
  "id_str" : "410842928882262017",
  "in_reply_to_user_id" : 989087534,
  "text" : "@SChaibeddra @mikejhldn thx for confirming that, it's interesting to note new uses in places like social media",
  "id" : 410842928882262017,
  "in_reply_to_status_id" : 410708482199793664,
  "created_at" : "2013-12-11 18:46:01 +0000",
  "in_reply_to_screen_name" : "SChaibeddra",
  "in_reply_to_user_id_str" : "989087534",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Purver",
      "screen_name" : "mpurver",
      "indices" : [ 0, 8 ],
      "id_str" : "22899935",
      "id" : 22899935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "410540488983576576",
  "geo" : { },
  "id_str" : "410546368470470656",
  "in_reply_to_user_id" : 22899935,
  "text" : "@mpurver ok yes can start http server",
  "id" : 410546368470470656,
  "in_reply_to_status_id" : 410540488983576576,
  "created_at" : "2013-12-10 23:07:36 +0000",
  "in_reply_to_screen_name" : "mpurver",
  "in_reply_to_user_id_str" : "22899935",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Chomsky",
      "indices" : [ 0, 8 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/Zn7ImYD3Tp",
      "expanded_url" : "http:\/\/www.nytimes.com\/2013\/12\/10\/opinion\/fish-scholarship-and-politics-the-case-of-noam-chomsky.html?pagewanted=2&_r=1&ref=opinion",
      "display_url" : "nytimes.com\/2013\/12\/10\/opi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410452724652593152",
  "text" : "#Chomsky - Educational reform, he said, is \u201Ca euphemism for the destruction of public education.\u201D http:\/\/t.co\/Zn7ImYD3Tp",
  "id" : 410452724652593152,
  "created_at" : "2013-12-10 16:55:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410439241194168321",
  "text" : "@mikejhldn ah yeah nice is there a list of french puns\/wordplay u know of?",
  "id" : 410439241194168321,
  "created_at" : "2013-12-10 16:01:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/UGlLo3RAAm",
      "expanded_url" : "http:\/\/forum.wordreference.com\/showthread.php?t=220972",
      "display_url" : "forum.wordreference.com\/showthread.php\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410437436926214144",
  "text" : "@mikejhldn a typo, refers to the actor, wallou is an interesting word http:\/\/t.co\/UGlLo3RAAm",
  "id" : 410437436926214144,
  "created_at" : "2013-12-10 15:54:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410436613118758912",
  "text" : "Ma prof d'anglais elle a voulut faire une heure de cour sur Nelson Mandela ojd mais lundi pour Pauk Walker on a fait wallou",
  "id" : 410436613118758912,
  "created_at" : "2013-12-10 15:51:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maria Pia Montoro",
      "screen_name" : "WordLo",
      "indices" : [ 67, 74 ],
      "id_str" : "190569306",
      "id" : 190569306
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 75, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/1zW1VRxYth",
      "expanded_url" : "http:\/\/recremisi.blogspot.fr\/p\/online-terminology-tools.html",
      "display_url" : "recremisi.blogspot.fr\/p\/online-termi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410414492187500545",
  "text" : "a great list of online terminology tools http:\/\/t.co\/1zW1VRxYth by @WordLo #eltchat",
  "id" : 410414492187500545,
  "created_at" : "2013-12-10 14:23:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "evanfrendo",
      "screen_name" : "evanfrendo",
      "indices" : [ 32, 43 ],
      "id_str" : "17589664",
      "id" : 17589664
    }, {
      "name" : "Nikw211",
      "screen_name" : "Nikw211",
      "indices" : [ 44, 52 ],
      "id_str" : "1323189763",
      "id" : 1323189763
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410401345628143616",
  "text" : "thanks for sharing CL news post @evanfrendo @Nikw211 :)",
  "id" : 410401345628143616,
  "created_at" : "2013-12-10 13:31:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Purver",
      "screen_name" : "mpurver",
      "indices" : [ 0, 8 ],
      "id_str" : "22899935",
      "id" : 22899935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410401137305452544",
  "in_reply_to_user_id" : 22899935,
  "text" : "@mpurver hi how do u install SCORE on mac osx? i sent email to stanford address but not sure if that is current, thanks!",
  "id" : 410401137305452544,
  "created_at" : "2013-12-10 13:30:30 +0000",
  "in_reply_to_screen_name" : "mpurver",
  "in_reply_to_user_id_str" : "22899935",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anne Hodgson",
      "screen_name" : "annehodg",
      "indices" : [ 3, 12 ],
      "id_str" : "17589213",
      "id" : 17589213
    }, {
      "name" : "Anne Hodgson",
      "screen_name" : "annehodg",
      "indices" : [ 93, 102 ],
      "id_str" : "17589213",
      "id" : 17589213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/p9G48YJZhP",
      "expanded_url" : "http:\/\/annehodgson.de\/2013\/12\/09\/grammar-guru-youll-want-to-turn-left-at-the-light\/",
      "display_url" : "annehodgson.de\/2013\/12\/09\/gra\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410147665151012865",
  "text" : "RT @annehodg: Grammar Guru: You'll want to turn left at the light http:\/\/t.co\/p9G48YJZhP via @annehodg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anne Hodgson",
        "screen_name" : "annehodg",
        "indices" : [ 79, 88 ],
        "id_str" : "17589213",
        "id" : 17589213
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/p9G48YJZhP",
        "expanded_url" : "http:\/\/annehodgson.de\/2013\/12\/09\/grammar-guru-youll-want-to-turn-left-at-the-light\/",
        "display_url" : "annehodgson.de\/2013\/12\/09\/gra\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "410093272111906816",
    "text" : "Grammar Guru: You'll want to turn left at the light http:\/\/t.co\/p9G48YJZhP via @annehodg",
    "id" : 410093272111906816,
    "created_at" : "2013-12-09 17:07:09 +0000",
    "user" : {
      "name" : "Anne Hodgson",
      "screen_name" : "annehodg",
      "protected" : false,
      "id_str" : "17589213",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618152681920724993\/9dLkbtqM_normal.jpg",
      "id" : 17589213,
      "verified" : false
    }
  },
  "id" : 410147665151012865,
  "created_at" : "2013-12-09 20:43:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 57, 65 ]
    }, {
      "text" : "tesol",
      "indices" : [ 66, 72 ]
    }, {
      "text" : "tefl",
      "indices" : [ 73, 78 ]
    }, {
      "text" : "besig",
      "indices" : [ 79, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/KGpinNImjN",
      "expanded_url" : "http:\/\/wp.me\/pgHyE-JP",
      "display_url" : "wp.me\/pgHyE-JP"
    } ]
  },
  "geo" : { },
  "id_str" : "410122369655521280",
  "text" : "Corpus linguistics community news http:\/\/t.co\/KGpinNImjN #eltchat #tesol #tefl #besig",
  "id" : 410122369655521280,
  "created_at" : "2013-12-09 19:02:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "natiserhost197",
      "screen_name" : "esl_robert",
      "indices" : [ 0, 11 ],
      "id_str" : "2982357761",
      "id" : 2982357761
    }, {
      "name" : "Amanda Potts",
      "screen_name" : "WatchedPotts",
      "indices" : [ 12, 25 ],
      "id_str" : "702925903",
      "id" : 702925903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "410082496626163713",
  "geo" : { },
  "id_str" : "410084214847991808",
  "in_reply_to_user_id" : 18526186,
  "text" : "@esl_robert @WatchedPotts ok thanks",
  "id" : 410084214847991808,
  "in_reply_to_status_id" : 410082496626163713,
  "created_at" : "2013-12-09 16:31:10 +0000",
  "in_reply_to_screen_name" : "RobertEPoole",
  "in_reply_to_user_id_str" : "18526186",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "natiserhost197",
      "screen_name" : "esl_robert",
      "indices" : [ 0, 11 ],
      "id_str" : "2982357761",
      "id" : 2982357761
    }, {
      "name" : "Amanda Potts",
      "screen_name" : "WatchedPotts",
      "indices" : [ 12, 25 ],
      "id_str" : "702925903",
      "id" : 702925903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "410073990707695617",
  "geo" : { },
  "id_str" : "410081323420639232",
  "in_reply_to_user_id" : 18526186,
  "text" : "@esl_robert @WatchedPotts trying a \"demo\" ;) version how often did you have to adjust settings to get good text out?",
  "id" : 410081323420639232,
  "in_reply_to_status_id" : 410073990707695617,
  "created_at" : "2013-12-09 16:19:41 +0000",
  "in_reply_to_screen_name" : "RobertEPoole",
  "in_reply_to_user_id_str" : "18526186",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "P\u00E9rez-Paredes",
      "screen_name" : "perezparedes",
      "indices" : [ 26, 39 ],
      "id_str" : "28528850",
      "id" : 28528850
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "410078774227927040",
  "geo" : { },
  "id_str" : "410080339977981953",
  "in_reply_to_user_id" : 28528850,
  "text" : "last cry of the dinosaurs @perezparedes bring on the open access asteroids :)",
  "id" : 410080339977981953,
  "in_reply_to_status_id" : 410078774227927040,
  "created_at" : "2013-12-09 16:15:46 +0000",
  "in_reply_to_screen_name" : "perezparedes",
  "in_reply_to_user_id_str" : "28528850",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Potts",
      "screen_name" : "WatchedPotts",
      "indices" : [ 0, 13 ],
      "id_str" : "702925903",
      "id" : 702925903
    }, {
      "name" : "natiserhost197",
      "screen_name" : "esl_robert",
      "indices" : [ 14, 25 ],
      "id_str" : "2982357761",
      "id" : 2982357761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/GBatJWzBGt",
      "expanded_url" : "http:\/\/www.onlineocr.net\/",
      "display_url" : "onlineocr.net"
    } ]
  },
  "in_reply_to_status_id_str" : "410008997870063616",
  "geo" : { },
  "id_str" : "410016379278864384",
  "in_reply_to_user_id" : 702925903,
  "text" : "@WatchedPotts @esl_robert fyi this onlineone (free 15images per hour) is one of the best i've used for scanned texts http:\/\/t.co\/GBatJWzBGt",
  "id" : 410016379278864384,
  "in_reply_to_status_id" : 410008997870063616,
  "created_at" : "2013-12-09 12:01:37 +0000",
  "in_reply_to_screen_name" : "WatchedPotts",
  "in_reply_to_user_id_str" : "702925903",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "409970409434406912",
  "text" : "@Florentina__T kinda related-i find french tradition of wrapping book covers in plain paper int, not sure how widespread this is now though",
  "id" : 409970409434406912,
  "created_at" : "2013-12-09 08:58:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/L9I0YnuhhU",
      "expanded_url" : "http:\/\/linguafrankly.blogspot.com\/2013\/12\/memory-schedules-and-danger-of-hard-line.html?spref=tw",
      "display_url" : "linguafrankly.blogspot.com\/2013\/12\/memory\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409956288009744385",
  "text" : "Lingua Frankly: Memory schedules and the danger of the hard line http:\/\/t.co\/L9I0YnuhhU",
  "id" : 409956288009744385,
  "created_at" : "2013-12-09 08:02:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "natiserhost197",
      "screen_name" : "esl_robert",
      "indices" : [ 0, 11 ],
      "id_str" : "2982357761",
      "id" : 2982357761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "409920513180303360",
  "geo" : { },
  "id_str" : "409953019027935233",
  "in_reply_to_user_id" : 18526186,
  "text" : "@esl_robert hi how does it perform with scanned texts?",
  "id" : 409953019027935233,
  "in_reply_to_status_id" : 409920513180303360,
  "created_at" : "2013-12-09 07:49:50 +0000",
  "in_reply_to_screen_name" : "RobertEPoole",
  "in_reply_to_user_id_str" : "18526186",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Willingham",
      "screen_name" : "DTWillingham",
      "indices" : [ 3, 16 ],
      "id_str" : "84619537",
      "id" : 84619537
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edchat",
      "indices" : [ 104, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/IaKB1Q6BEY",
      "expanded_url" : "http:\/\/shankerblog.org\/?p=9057",
      "display_url" : "shankerblog.org\/?p=9057"
    } ]
  },
  "geo" : { },
  "id_str" : "409689426227650560",
  "text" : "RT @DTWillingham: Pop quiz: what do you know about children's vocab development? http:\/\/t.co\/IaKB1Q6BEY #edchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "edchat",
        "indices" : [ 86, 93 ]
      } ],
      "urls" : [ {
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/IaKB1Q6BEY",
        "expanded_url" : "http:\/\/shankerblog.org\/?p=9057",
        "display_url" : "shankerblog.org\/?p=9057"
      } ]
    },
    "geo" : { },
    "id_str" : "409642496155598848",
    "text" : "Pop quiz: what do you know about children's vocab development? http:\/\/t.co\/IaKB1Q6BEY #edchat",
    "id" : 409642496155598848,
    "created_at" : "2013-12-08 11:15:56 +0000",
    "user" : {
      "name" : "Daniel Willingham",
      "screen_name" : "DTWillingham",
      "protected" : false,
      "id_str" : "84619537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1815678310\/Daniel_Willingham_Color_lowres_normal.JPG",
      "id" : 84619537,
      "verified" : false
    }
  },
  "id" : 409689426227650560,
  "created_at" : "2013-12-08 14:22:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tanja S\u00E4ily",
      "screen_name" : "TanjaSaily",
      "indices" : [ 3, 14 ],
      "id_str" : "404275915",
      "id" : 404275915
    }, {
      "name" : "vaclav",
      "screen_name" : "vaclavbrezina",
      "indices" : [ 63, 77 ],
      "id_str" : "1201576646",
      "id" : 1201576646
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/8guvKn6pn7",
      "expanded_url" : "http:\/\/corpora.lancs.ac.uk\/bnc64\/",
      "display_url" : "corpora.lancs.ac.uk\/bnc64\/"
    } ]
  },
  "geo" : { },
  "id_str" : "409607103608008704",
  "text" : "RT @TanjaSaily: BNC64: Comparison of male and female speech by @vaclavbrezina http:\/\/t.co\/8guvKn6pn7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "vaclav",
        "screen_name" : "vaclavbrezina",
        "indices" : [ 47, 61 ],
        "id_str" : "1201576646",
        "id" : 1201576646
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 84 ],
        "url" : "http:\/\/t.co\/8guvKn6pn7",
        "expanded_url" : "http:\/\/corpora.lancs.ac.uk\/bnc64\/",
        "display_url" : "corpora.lancs.ac.uk\/bnc64\/"
      } ]
    },
    "geo" : { },
    "id_str" : "409357555089948672",
    "text" : "BNC64: Comparison of male and female speech by @vaclavbrezina http:\/\/t.co\/8guvKn6pn7",
    "id" : 409357555089948672,
    "created_at" : "2013-12-07 16:23:41 +0000",
    "user" : {
      "name" : "Tanja S\u00E4ily",
      "screen_name" : "TanjaSaily",
      "protected" : false,
      "id_str" : "404275915",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3109975650\/b288fc49a2c34117d9fb2aa8e05ee76c_normal.jpeg",
      "id" : 404275915,
      "verified" : false
    }
  },
  "id" : 409607103608008704,
  "created_at" : "2013-12-08 08:55:18 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Parise",
      "screen_name" : "peterrenshu",
      "indices" : [ 3, 15 ],
      "id_str" : "631949549",
      "id" : 631949549
    }, {
      "name" : "Minitube",
      "screen_name" : "minitubeapp",
      "indices" : [ 123, 135 ],
      "id_str" : "392857958",
      "id" : 392857958
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/Y6qpMWmrt1",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=Qf46lOnMCfs",
      "display_url" : "youtube.com\/watch?v=Qf46lO\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409604379940225024",
  "text" : "RT @peterrenshu: Using Corpora in the Language Classroom | The New School for Public Engagement http:\/\/t.co\/Y6qpMWmrt1 via @minitubeapp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Minitube",
        "screen_name" : "minitubeapp",
        "indices" : [ 106, 118 ],
        "id_str" : "392857958",
        "id" : 392857958
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/Y6qpMWmrt1",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=Qf46lOnMCfs",
        "display_url" : "youtube.com\/watch?v=Qf46lO\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "409513601712414720",
    "text" : "Using Corpora in the Language Classroom | The New School for Public Engagement http:\/\/t.co\/Y6qpMWmrt1 via @minitubeapp",
    "id" : 409513601712414720,
    "created_at" : "2013-12-08 02:43:45 +0000",
    "user" : {
      "name" : "Peter Parise",
      "screen_name" : "peterrenshu",
      "protected" : false,
      "id_str" : "631949549",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2390141891\/azxwx57ppddic0hnd26k_normal.jpeg",
      "id" : 631949549,
      "verified" : false
    }
  },
  "id" : 409604379940225024,
  "created_at" : "2013-12-08 08:44:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Gillett",
      "screen_name" : "UEfAP",
      "indices" : [ 3, 9 ],
      "id_str" : "235529625",
      "id" : 235529625
    }, {
      "name" : "TimesHigherEducation",
      "screen_name" : "timeshighered",
      "indices" : [ 89, 103 ],
      "id_str" : "23602600",
      "id" : 23602600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/qvXbVWpIgi",
      "expanded_url" : "http:\/\/www.timeshighereducation.co.uk\/tablet\/3A2A41B5\/2009519.shared",
      "display_url" : "timeshighereducation.co.uk\/tablet\/3A2A41B\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409381254036221952",
  "text" : "RT @UEfAP: Travelling to Finland to give a course on \u201CEnglish for academic research\u201D via @timeshighered http:\/\/t.co\/qvXbVWpIgi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TimesHigherEducation",
        "screen_name" : "timeshighered",
        "indices" : [ 78, 92 ],
        "id_str" : "23602600",
        "id" : 23602600
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/qvXbVWpIgi",
        "expanded_url" : "http:\/\/www.timeshighereducation.co.uk\/tablet\/3A2A41B5\/2009519.shared",
        "display_url" : "timeshighereducation.co.uk\/tablet\/3A2A41B\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "409275923356057600",
    "text" : "Travelling to Finland to give a course on \u201CEnglish for academic research\u201D via @timeshighered http:\/\/t.co\/qvXbVWpIgi",
    "id" : 409275923356057600,
    "created_at" : "2013-12-07 10:59:18 +0000",
    "user" : {
      "name" : "Andy Gillett",
      "screen_name" : "UEfAP",
      "protected" : false,
      "id_str" : "235529625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1210092848\/uefap_512_normal.png",
      "id" : 235529625,
      "verified" : false
    }
  },
  "id" : 409381254036221952,
  "created_at" : "2013-12-07 17:57:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nic Subtirelu",
      "screen_name" : "linguisticpulse",
      "indices" : [ 3, 19 ],
      "id_str" : "1400748798",
      "id" : 1400748798
    }, {
      "name" : "Graham",
      "screen_name" : "onalifeglug",
      "indices" : [ 103, 115 ],
      "id_str" : "19516039",
      "id" : 19516039
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "austerity",
      "indices" : [ 89, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/EghND20fVD",
      "expanded_url" : "http:\/\/lifeglug.wordpress.com\/2013\/12\/07\/austerity\/",
      "display_url" : "lifeglug.wordpress.com\/2013\/12\/07\/aus\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409331760137527297",
  "text" : "RT @linguisticpulse: Enlightening look at the ideological content wrapped up in the word #austerity by @onalifeglug http:\/\/t.co\/EghND20fVD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Graham",
        "screen_name" : "onalifeglug",
        "indices" : [ 82, 94 ],
        "id_str" : "19516039",
        "id" : 19516039
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "austerity",
        "indices" : [ 68, 78 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/EghND20fVD",
        "expanded_url" : "http:\/\/lifeglug.wordpress.com\/2013\/12\/07\/austerity\/",
        "display_url" : "lifeglug.wordpress.com\/2013\/12\/07\/aus\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "409329568781045760",
    "text" : "Enlightening look at the ideological content wrapped up in the word #austerity by @onalifeglug http:\/\/t.co\/EghND20fVD",
    "id" : 409329568781045760,
    "created_at" : "2013-12-07 14:32:28 +0000",
    "user" : {
      "name" : "Nic Subtirelu",
      "screen_name" : "linguisticpulse",
      "protected" : false,
      "id_str" : "1400748798",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3609632834\/4ae2ef11e9cffa43e820f3ef7e18b016_normal.jpeg",
      "id" : 1400748798,
      "verified" : false
    }
  },
  "id" : 409331760137527297,
  "created_at" : "2013-12-07 14:41:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Chomsky",
      "indices" : [ 101, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/nP6xOkXH09",
      "expanded_url" : "http:\/\/www.chomsky.info\/",
      "display_url" : "chomsky.info"
    } ]
  },
  "geo" : { },
  "id_str" : "409327678941331456",
  "text" : "RT @medialens: Two disasters struck US power on December 7: 1) Pearl Harbour. 2) Happy Birthday Noam #Chomsky! 85 years young today http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Chomsky",
        "indices" : [ 86, 94 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/nP6xOkXH09",
        "expanded_url" : "http:\/\/www.chomsky.info\/",
        "display_url" : "chomsky.info"
      } ]
    },
    "geo" : { },
    "id_str" : "409226598399746048",
    "text" : "Two disasters struck US power on December 7: 1) Pearl Harbour. 2) Happy Birthday Noam #Chomsky! 85 years young today http:\/\/t.co\/nP6xOkXH09",
    "id" : 409226598399746048,
    "created_at" : "2013-12-07 07:43:18 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 409327678941331456,
  "created_at" : "2013-12-07 14:24:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/lOmTLq2bnm",
      "expanded_url" : "http:\/\/www.theguardian.com\/commentisfree\/2013\/dec\/05\/students-protests-police-repression-university-of-london",
      "display_url" : "theguardian.com\/commentisfree\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409297724920442880",
  "text" : "Student protests are changing tack \u2013 and facing heavy police repression http:\/\/t.co\/lOmTLq2bnm",
  "id" : 409297724920442880,
  "created_at" : "2013-12-07 12:25:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 79, 95 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/1g6SFJd9GN",
      "expanded_url" : "http:\/\/wp.me\/p2KE8s-47v",
      "display_url" : "wp.me\/p2KE8s-47v"
    } ]
  },
  "geo" : { },
  "id_str" : "409287502499815424",
  "text" : "Useful TEFL-based euphemisms for your everyday life http:\/\/t.co\/1g6SFJd9GN via @wordpressdotcom",
  "id" : 409287502499815424,
  "created_at" : "2013-12-07 11:45:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/4mvdmgtatq",
      "expanded_url" : "http:\/\/www.accuracy.org\/release\/mandela-beyond-the-safe-character\/",
      "display_url" : "accuracy.org\/release\/mandel\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408988732717420544",
  "text" : "M: Bynd \u201CSafe Character\u201D:refusal to renounce arm struggle; exprsn of grat to the Cuban people;supp for Palestinians http:\/\/t.co\/4mvdmgtatq",
  "id" : 408988732717420544,
  "created_at" : "2013-12-06 15:58:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 3, 15 ],
      "id_str" : "525013404",
      "id" : 525013404
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KELTchat",
      "indices" : [ 96, 105 ]
    }, {
      "text" : "mustread",
      "indices" : [ 106, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/0bl3H9udq1",
      "expanded_url" : "http:\/\/alienteachers.wordpress.com\/2013\/12\/06\/reflections-on-four-approaches-to-group-discussion-activities\/",
      "display_url" : "alienteachers.wordpress.com\/2013\/12\/06\/ref\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408986776473468930",
  "text" : "RT @AnneHendler: Very interesting action research project by @AlexSWalsh http:\/\/t.co\/0bl3H9udq1 #KELTchat #mustread",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "KELTchat",
        "indices" : [ 79, 88 ]
      }, {
        "text" : "mustread",
        "indices" : [ 89, 98 ]
      } ],
      "urls" : [ {
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/0bl3H9udq1",
        "expanded_url" : "http:\/\/alienteachers.wordpress.com\/2013\/12\/06\/reflections-on-four-approaches-to-group-discussion-activities\/",
        "display_url" : "alienteachers.wordpress.com\/2013\/12\/06\/ref\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "408984974692331520",
    "text" : "Very interesting action research project by @AlexSWalsh http:\/\/t.co\/0bl3H9udq1 #KELTchat #mustread",
    "id" : 408984974692331520,
    "created_at" : "2013-12-06 15:43:11 +0000",
    "user" : {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "protected" : false,
      "id_str" : "525013404",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766910187911405568\/zw3Ez5M0_normal.jpg",
      "id" : 525013404,
      "verified" : false
    }
  },
  "id" : 408986776473468930,
  "created_at" : "2013-12-06 15:50:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luiz Otavio Barros",
      "screen_name" : "luizotavioELT",
      "indices" : [ 3, 17 ],
      "id_str" : "54798894",
      "id" : 54798894
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "esl",
      "indices" : [ 75, 79 ]
    }, {
      "text" : "efl",
      "indices" : [ 80, 84 ]
    }, {
      "text" : "elt",
      "indices" : [ 85, 89 ]
    }, {
      "text" : "grammar",
      "indices" : [ 90, 98 ]
    }, {
      "text" : "telf",
      "indices" : [ 99, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/YbzwJ9Pezw",
      "expanded_url" : "http:\/\/www.luizotaviobarros.com\/2013\/12\/memes-teach-english-concept-checking.html",
      "display_url" : "luizotaviobarros.com\/2013\/12\/memes-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408985834898358272",
  "text" : "RT @luizotavioELT: Using memes for concept checking\nhttp:\/\/t.co\/YbzwJ9Pezw #esl #efl #elt #grammar #telf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "esl",
        "indices" : [ 56, 60 ]
      }, {
        "text" : "efl",
        "indices" : [ 61, 65 ]
      }, {
        "text" : "elt",
        "indices" : [ 66, 70 ]
      }, {
        "text" : "grammar",
        "indices" : [ 71, 79 ]
      }, {
        "text" : "telf",
        "indices" : [ 80, 85 ]
      } ],
      "urls" : [ {
        "indices" : [ 33, 55 ],
        "url" : "http:\/\/t.co\/YbzwJ9Pezw",
        "expanded_url" : "http:\/\/www.luizotaviobarros.com\/2013\/12\/memes-teach-english-concept-checking.html",
        "display_url" : "luizotaviobarros.com\/2013\/12\/memes-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "408908686946357248",
    "text" : "Using memes for concept checking\nhttp:\/\/t.co\/YbzwJ9Pezw #esl #efl #elt #grammar #telf",
    "id" : 408908686946357248,
    "created_at" : "2013-12-06 10:40:02 +0000",
    "user" : {
      "name" : "Luiz Otavio Barros",
      "screen_name" : "luizotavioELT",
      "protected" : false,
      "id_str" : "54798894",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2993483640\/18c26077182489c6d9f18ff232617587_normal.jpeg",
      "id" : 54798894,
      "verified" : false
    }
  },
  "id" : 408985834898358272,
  "created_at" : "2013-12-06 15:46:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kris Davies",
      "screen_name" : "kris_81",
      "indices" : [ 3, 11 ],
      "id_str" : "18943932",
      "id" : 18943932
    }, {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 23, 31 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/pgcGihYJoj",
      "expanded_url" : "http:\/\/youtu.be\/wvCYJhILyxU?a",
      "display_url" : "youtu.be\/wvCYJhILyxU?a"
    } ]
  },
  "geo" : { },
  "id_str" : "408875556147826688",
  "text" : "RT @kris_81: I liked a @YouTube video http:\/\/t.co\/pgcGihYJoj Dadholes",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ 10, 18 ],
        "id_str" : "10228272",
        "id" : 10228272
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 25, 47 ],
        "url" : "http:\/\/t.co\/pgcGihYJoj",
        "expanded_url" : "http:\/\/youtu.be\/wvCYJhILyxU?a",
        "display_url" : "youtu.be\/wvCYJhILyxU?a"
      } ]
    },
    "geo" : { },
    "id_str" : "408736007031627776",
    "text" : "I liked a @YouTube video http:\/\/t.co\/pgcGihYJoj Dadholes",
    "id" : 408736007031627776,
    "created_at" : "2013-12-05 23:13:52 +0000",
    "user" : {
      "name" : "Kris Davies",
      "screen_name" : "kris_81",
      "protected" : false,
      "id_str" : "18943932",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/690485994500521985\/Vr4BMXOI_normal.jpg",
      "id" : 18943932,
      "verified" : false
    }
  },
  "id" : 408875556147826688,
  "created_at" : "2013-12-06 08:28:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 99, 107 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/I8G6JJTEDe",
      "expanded_url" : "http:\/\/youtu.be\/L6unS2JF8TA",
      "display_url" : "youtu.be\/L6unS2JF8TA"
    } ]
  },
  "geo" : { },
  "id_str" : "408708304043384832",
  "text" : "The Pathology of the Rich - Chris Hedges on Reality Asserts Itself pt1: http:\/\/t.co\/I8G6JJTEDe via @youtube",
  "id" : 408708304043384832,
  "created_at" : "2013-12-05 21:23:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MarisaConstantinides",
      "screen_name" : "Marisa_C",
      "indices" : [ 0, 9 ],
      "id_str" : "18272500",
      "id" : 18272500
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408549883466240000",
  "geo" : { },
  "id_str" : "408698681886375936",
  "in_reply_to_user_id" : 18272500,
  "text" : "@Marisa_C salut from france; don't fear the social media :)",
  "id" : 408698681886375936,
  "in_reply_to_status_id" : 408549883466240000,
  "created_at" : "2013-12-05 20:45:33 +0000",
  "in_reply_to_screen_name" : "Marisa_C",
  "in_reply_to_user_id_str" : "18272500",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark McGlashan",
      "screen_name" : "Mark_McGlashan",
      "indices" : [ 0, 15 ],
      "id_str" : "286869902",
      "id" : 286869902
    }, {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "indices" : [ 16, 28 ],
      "id_str" : "849729062",
      "id" : 849729062
    }, {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "indices" : [ 29, 45 ],
      "id_str" : "1326508478",
      "id" : 1326508478
    }, {
      "name" : "Paul Rayson",
      "screen_name" : "perayson",
      "indices" : [ 46, 55 ],
      "id_str" : "263108959",
      "id" : 263108959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408582834249793536",
  "geo" : { },
  "id_str" : "408690411822010369",
  "in_reply_to_user_id" : 286869902,
  "text" : "@Mark_McGlashan @TonyMcEnery @CorpusSocialSci @perayson fab :) thanks",
  "id" : 408690411822010369,
  "in_reply_to_status_id" : 408582834249793536,
  "created_at" : "2013-12-05 20:12:41 +0000",
  "in_reply_to_screen_name" : "Mark_McGlashan",
  "in_reply_to_user_id_str" : "286869902",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OZAWA",
      "screen_name" : "ozapro18",
      "indices" : [ 0, 9 ],
      "id_str" : "115267674",
      "id" : 115267674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408486023614570496",
  "in_reply_to_user_id" : 115267674,
  "text" : "@ozapro18 \u3069\u3046\u3082 RT :)",
  "id" : 408486023614570496,
  "created_at" : "2013-12-05 06:40:31 +0000",
  "in_reply_to_screen_name" : "ozapro18",
  "in_reply_to_user_id_str" : "115267674",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Akira Murakami",
      "screen_name" : "mrkm_a",
      "indices" : [ 0, 7 ],
      "id_str" : "116922669",
      "id" : 116922669
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408485961715048448",
  "in_reply_to_user_id" : 116922669,
  "text" : "@mrkm_a thanks for RT of graded corpus :)",
  "id" : 408485961715048448,
  "created_at" : "2013-12-05 06:40:17 +0000",
  "in_reply_to_screen_name" : "mrkm_a",
  "in_reply_to_user_id_str" : "116922669",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Forbes",
      "screen_name" : "GenkiSarah",
      "indices" : [ 3, 14 ],
      "id_str" : "586340658",
      "id" : 586340658
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/RGiN2wOU0s",
      "expanded_url" : "http:\/\/sarahatktc.weebly.com\/1\/post\/2013\/12\/embracing-new-identities.html",
      "display_url" : "sarahatktc.weebly.com\/1\/post\/2013\/12\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408107708324540416",
  "text" : "RT @GenkiSarah: Embracing New Identities\u00A0 http:\/\/t.co\/RGiN2wOU0s",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.weebly.com\/\" rel=\"nofollow\"\u003EWeebly App\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 26, 48 ],
        "url" : "http:\/\/t.co\/RGiN2wOU0s",
        "expanded_url" : "http:\/\/sarahatktc.weebly.com\/1\/post\/2013\/12\/embracing-new-identities.html",
        "display_url" : "sarahatktc.weebly.com\/1\/post\/2013\/12\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "408076136883580928",
    "text" : "Embracing New Identities\u00A0 http:\/\/t.co\/RGiN2wOU0s",
    "id" : 408076136883580928,
    "created_at" : "2013-12-04 03:31:47 +0000",
    "user" : {
      "name" : "Sarah Forbes",
      "screen_name" : "GenkiSarah",
      "protected" : false,
      "id_str" : "586340658",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2237023794\/DSCF5375_normal.JPG",
      "id" : 586340658,
      "verified" : false
    }
  },
  "id" : 408107708324540416,
  "created_at" : "2013-12-04 05:37:14 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luca Marchiori",
      "screen_name" : "chuechebueb",
      "indices" : [ 0, 12 ],
      "id_str" : "1334451956",
      "id" : 1334451956
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "407919540794687488",
  "geo" : { },
  "id_str" : "407973228666032128",
  "in_reply_to_user_id" : 1334451956,
  "text" : "@chuechebueb no worries sorry to have missed end, hope it went well",
  "id" : 407973228666032128,
  "in_reply_to_status_id" : 407919540794687488,
  "created_at" : "2013-12-03 20:42:52 +0000",
  "in_reply_to_screen_name" : "chuechebueb",
  "in_reply_to_user_id_str" : "1334451956",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyler Schnoebelen",
      "screen_name" : "TSchnoebelen",
      "indices" : [ 3, 16 ],
      "id_str" : "14969147",
      "id" : 14969147
    }, {
      "name" : "Ben Crair",
      "screen_name" : "bencrair",
      "indices" : [ 26, 35 ],
      "id_str" : "42722492",
      "id" : 42722492
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/TSchnoebelen\/status\/407950155636146176\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/wPQunchGyK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BalUgU0CIAApQpq.jpg",
      "id_str" : "407950155573239808",
      "id" : 407950155573239808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BalUgU0CIAApQpq.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 613,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 613,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 359,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 204,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/wPQunchGyK"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/k8JLuAw4Ln",
      "expanded_url" : "http:\/\/idibon.com\/period-really-may-be-pissed\/",
      "display_url" : "idibon.com\/period-really-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407972963217309697",
  "text" : "RT @TSchnoebelen: Testing @bencrair's idea that the period is pissed (short answer: yes). http:\/\/t.co\/k8JLuAw4Ln http:\/\/t.co\/wPQunchGyK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ben Crair",
        "screen_name" : "bencrair",
        "indices" : [ 8, 17 ],
        "id_str" : "42722492",
        "id" : 42722492
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/TSchnoebelen\/status\/407950155636146176\/photo\/1",
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/wPQunchGyK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BalUgU0CIAApQpq.jpg",
        "id_str" : "407950155573239808",
        "id" : 407950155573239808,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BalUgU0CIAApQpq.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 613,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 613,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 359,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 204,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/wPQunchGyK"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/k8JLuAw4Ln",
        "expanded_url" : "http:\/\/idibon.com\/period-really-may-be-pissed\/",
        "display_url" : "idibon.com\/period-really-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "407950155636146176",
    "text" : "Testing @bencrair's idea that the period is pissed (short answer: yes). http:\/\/t.co\/k8JLuAw4Ln http:\/\/t.co\/wPQunchGyK",
    "id" : 407950155636146176,
    "created_at" : "2013-12-03 19:11:11 +0000",
    "user" : {
      "name" : "Tyler Schnoebelen",
      "screen_name" : "TSchnoebelen",
      "protected" : false,
      "id_str" : "14969147",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/604427674203779072\/Y4t_NODB_normal.jpg",
      "id" : 14969147,
      "verified" : false
    }
  },
  "id" : 407972963217309697,
  "created_at" : "2013-12-03 20:41:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/KwpjK6kXcB",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=Eo84dWcl74k&feature=youtu.be&t=23s",
      "display_url" : "youtube.com\/watch?v=Eo84dW\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "407906484475801600",
  "geo" : { },
  "id_str" : "407910424110055424",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin @teflskeptic http:\/\/t.co\/KwpjK6kXcB :)",
  "id" : 407910424110055424,
  "in_reply_to_status_id" : 407906484475801600,
  "created_at" : "2013-12-03 16:33:18 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "407892413407965184",
  "text" : "@Florentina__T had a quick play a nice set ot tools, thx",
  "id" : 407892413407965184,
  "created_at" : "2013-12-03 15:21:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luca Marchiori",
      "screen_name" : "chuechebueb",
      "indices" : [ 3, 15 ],
      "id_str" : "1334451956",
      "id" : 1334451956
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 125, 140 ],
      "url" : "https:\/\/t.co\/KEbY6yzt5S",
      "expanded_url" : "https:\/\/www.facebook.com\/EFTeacherZone",
      "display_url" : "facebook.com\/EFTeacherZone"
    } ]
  },
  "geo" : { },
  "id_str" : "407890224778600448",
  "text" : "RT @chuechebueb: Free seminar on teaching grammar this afternoon. The presenter is GREAT! He's ME :) Come along if you like. https:\/\/t.co\/K\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/KEbY6yzt5S",
        "expanded_url" : "https:\/\/www.facebook.com\/EFTeacherZone",
        "display_url" : "facebook.com\/EFTeacherZone"
      } ]
    },
    "geo" : { },
    "id_str" : "407889578620506112",
    "text" : "Free seminar on teaching grammar this afternoon. The presenter is GREAT! He's ME :) Come along if you like. https:\/\/t.co\/KEbY6yzt5S",
    "id" : 407889578620506112,
    "created_at" : "2013-12-03 15:10:28 +0000",
    "user" : {
      "name" : "Luca Marchiori",
      "screen_name" : "chuechebueb",
      "protected" : false,
      "id_str" : "1334451956",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/648051963029004288\/4-IhfZUE_normal.jpg",
      "id" : 1334451956,
      "verified" : false
    }
  },
  "id" : 407890224778600448,
  "created_at" : "2013-12-03 15:13:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Kern\u24C4h\u24B6n",
      "screen_name" : "dkernohan",
      "indices" : [ 3, 13 ],
      "id_str" : "12219232",
      "id" : 12219232
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fota",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 123, 140 ],
      "url" : "http:\/\/t.co\/E6UFmdUJ4L",
      "expanded_url" : "http:\/\/followersoftheapocalyp.se\/?p=802",
      "display_url" : "followersoftheapocalyp.se\/?p=802"
    } ]
  },
  "geo" : { },
  "id_str" : "407888070076559360",
  "text" : "RT @dkernohan: Blog post from me from the weekend. It's got the KLF in, and left-wing positions on technology and society: http:\/\/t.co\/E6UF\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/janetter.net\/\" rel=\"nofollow\"\u003EJanetter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fota",
        "indices" : [ 131, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/E6UFmdUJ4L",
        "expanded_url" : "http:\/\/followersoftheapocalyp.se\/?p=802",
        "display_url" : "followersoftheapocalyp.se\/?p=802"
      } ]
    },
    "geo" : { },
    "id_str" : "407879840428482560",
    "text" : "Blog post from me from the weekend. It's got the KLF in, and left-wing positions on technology and society: http:\/\/t.co\/E6UFmdUJ4L #fota",
    "id" : 407879840428482560,
    "created_at" : "2013-12-03 14:31:46 +0000",
    "user" : {
      "name" : "David Kern\u24C4h\u24B6n",
      "screen_name" : "dkernohan",
      "protected" : false,
      "id_str" : "12219232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/757702202437804032\/4Xrm7IIe_normal.jpg",
      "id" : 12219232,
      "verified" : false
    }
  },
  "id" : 407888070076559360,
  "created_at" : "2013-12-03 15:04:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol Goodey",
      "screen_name" : "cgoodey",
      "indices" : [ 31, 39 ],
      "id_str" : "26606833",
      "id" : 26606833
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "407850006129831936",
  "geo" : { },
  "id_str" : "407885473630007296",
  "in_reply_to_user_id" : 26606833,
  "text" : "great to hear thanks for share @cgoodey",
  "id" : 407885473630007296,
  "in_reply_to_status_id" : 407850006129831936,
  "created_at" : "2013-12-03 14:54:09 +0000",
  "in_reply_to_screen_name" : "cgoodey",
  "in_reply_to_user_id_str" : "26606833",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 20, 31 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "407850808252702720",
  "geo" : { },
  "id_str" : "407885297754464256",
  "in_reply_to_user_id" : 300734173,
  "text" : "thanks for share :) @lexicoloco still deciding whether to join LC association ;)",
  "id" : 407885297754464256,
  "in_reply_to_status_id" : 407850808252702720,
  "created_at" : "2013-12-03 14:53:27 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol Goodey",
      "screen_name" : "cgoodey",
      "indices" : [ 14, 22 ],
      "id_str" : "26606833",
      "id" : 26606833
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/PNFII4i9EZ",
      "expanded_url" : "https:\/\/plus.google.com\/104940199413423400545\/posts\/XvojJEv3c7Z",
      "display_url" : "plus.google.com\/10494019941342\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "407848701483175936",
  "geo" : { },
  "id_str" : "407849367433797633",
  "in_reply_to_user_id" : 26606833,
  "text" : "nice write-up @cgoodey &amp; if anyone wants to know how to use a graded reader corpus see this https:\/\/t.co\/PNFII4i9EZ",
  "id" : 407849367433797633,
  "in_reply_to_status_id" : 407848701483175936,
  "created_at" : "2013-12-03 12:30:41 +0000",
  "in_reply_to_screen_name" : "cgoodey",
  "in_reply_to_user_id_str" : "26606833",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Yau",
      "screen_name" : "flowingdata",
      "indices" : [ 3, 15 ],
      "id_str" : "14109167",
      "id" : 14109167
    }, {
      "name" : "NPR's Planet Money",
      "screen_name" : "planetmoney",
      "indices" : [ 43, 55 ],
      "id_str" : "15905103",
      "id" : 15905103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/8U1kVqGheB",
      "expanded_url" : "http:\/\/apps.npr.org\/tshirt\/",
      "display_url" : "apps.npr.org\/tshirt\/"
    } ]
  },
  "geo" : { },
  "id_str" : "407576636004265984",
  "text" : "RT @flowingdata: The story of a t-shirt by @planetmoney. So good. http:\/\/t.co\/8U1kVqGheB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NPR's Planet Money",
        "screen_name" : "planetmoney",
        "indices" : [ 26, 38 ],
        "id_str" : "15905103",
        "id" : 15905103
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/8U1kVqGheB",
        "expanded_url" : "http:\/\/apps.npr.org\/tshirt\/",
        "display_url" : "apps.npr.org\/tshirt\/"
      } ]
    },
    "geo" : { },
    "id_str" : "407556114062913536",
    "text" : "The story of a t-shirt by @planetmoney. So good. http:\/\/t.co\/8U1kVqGheB",
    "id" : 407556114062913536,
    "created_at" : "2013-12-02 17:05:24 +0000",
    "user" : {
      "name" : "Nathan Yau",
      "screen_name" : "flowingdata",
      "protected" : false,
      "id_str" : "14109167",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/585826994526355456\/R3tYT5Kj_normal.png",
      "id" : 14109167,
      "verified" : false
    }
  },
  "id" : 407576636004265984,
  "created_at" : "2013-12-02 18:26:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "isthemanwhoistallhappy",
      "indices" : [ 90, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "407524134508183552",
  "text" : "What's the point of being better than someone else? - Chomsky on competition in education #isthemanwhoistallhappy",
  "id" : 407524134508183552,
  "created_at" : "2013-12-02 14:58:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirstin Mackay",
      "screen_name" : "mackaykirs",
      "indices" : [ 127, 138 ],
      "id_str" : "429809568",
      "id" : 429809568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/nPU5MYdFRQ",
      "expanded_url" : "http:\/\/wp.me\/p2uwyW-6s",
      "display_url" : "wp.me\/p2uwyW-6s"
    } ]
  },
  "geo" : { },
  "id_str" : "407509637445869568",
  "text" : "TESOL France Presentation Overview - Tailoring ESP courses - Part 1: Comparing hotels with travel \u2026 http:\/\/t.co\/nPU5MYdFRQ via @mackaykirs",
  "id" : 407509637445869568,
  "created_at" : "2013-12-02 14:00:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 3, 14 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "Judith Dubois",
      "screen_name" : "judyldubois",
      "indices" : [ 96, 108 ],
      "id_str" : "17035334",
      "id" : 17035334
    }, {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "indices" : [ 109, 122 ],
      "id_str" : "1685397408",
      "id" : 1685397408
    }, {
      "name" : "C Rebuffet-Broadus",
      "screen_name" : "RebuffetBroadus",
      "indices" : [ 123, 139 ],
      "id_str" : "22635290",
      "id" : 22635290
    }, {
      "name" : "Scott Thornbury",
      "screen_name" : "thornburyscott",
      "indices" : [ 139, 140 ],
      "id_str" : "23090474",
      "id" : 23090474
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TESOLFr",
      "indices" : [ 38, 46 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/JSQ07YmpK7",
      "expanded_url" : "http:\/\/buff.ly\/Iz7Zir",
      "display_url" : "buff.ly\/Iz7Zir"
    } ]
  },
  "geo" : { },
  "id_str" : "407214409497731072",
  "text" : "RT @leoselivan: Going Experimental at #TESOLFr - conference summary http:\/\/t.co\/JSQ07YmpK7 feat @judyldubois @harrisonmike @RebuffetBroadus\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Judith Dubois",
        "screen_name" : "judyldubois",
        "indices" : [ 80, 92 ],
        "id_str" : "17035334",
        "id" : 17035334
      }, {
        "name" : "Mike Harrison",
        "screen_name" : "harrisonmike",
        "indices" : [ 93, 106 ],
        "id_str" : "1685397408",
        "id" : 1685397408
      }, {
        "name" : "C Rebuffet-Broadus",
        "screen_name" : "RebuffetBroadus",
        "indices" : [ 107, 123 ],
        "id_str" : "22635290",
        "id" : 22635290
      }, {
        "name" : "Scott Thornbury",
        "screen_name" : "thornburyscott",
        "indices" : [ 124, 139 ],
        "id_str" : "23090474",
        "id" : 23090474
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TESOLFr",
        "indices" : [ 22, 30 ]
      } ],
      "urls" : [ {
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/JSQ07YmpK7",
        "expanded_url" : "http:\/\/buff.ly\/Iz7Zir",
        "display_url" : "buff.ly\/Iz7Zir"
      } ]
    },
    "geo" : { },
    "id_str" : "407212663354449920",
    "text" : "Going Experimental at #TESOLFr - conference summary http:\/\/t.co\/JSQ07YmpK7 feat @judyldubois @harrisonmike @RebuffetBroadus @thornburyscott",
    "id" : 407212663354449920,
    "created_at" : "2013-12-01 18:20:39 +0000",
    "user" : {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "protected" : false,
      "id_str" : "408365496",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/460546508601819136\/12ivDBb__normal.jpeg",
      "id" : 408365496,
      "verified" : false
    }
  },
  "id" : 407214409497731072,
  "created_at" : "2013-12-01 18:27:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane Cohen",
      "screen_name" : "JaneCohenEFL",
      "indices" : [ 0, 13 ],
      "id_str" : "705261589",
      "id" : 705261589
    }, {
      "name" : "Lexical Leo",
      "screen_name" : "leoselivan",
      "indices" : [ 14, 25 ],
      "id_str" : "408365496",
      "id" : 408365496
    }, {
      "name" : "#ELTchat",
      "screen_name" : "ELTchat",
      "indices" : [ 26, 34 ],
      "id_str" : "189578708",
      "id" : 189578708
    }, {
      "name" : "ETpro",
      "screen_name" : "ETprofessional",
      "indices" : [ 68, 83 ],
      "id_str" : "501629829",
      "id" : 501629829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 142 ],
      "url" : "http:\/\/t.co\/q32iByANm0",
      "expanded_url" : "http:\/\/core.kmi.open.ac.uk\/download\/pdf\/77378.pdf",
      "display_url" : "core.kmi.open.ac.uk\/download\/pdf\/7\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "407142823608479744",
  "geo" : { },
  "id_str" : "407157656218894336",
  "in_reply_to_user_id" : 705261589,
  "text" : "@JaneCohenEFL @leoselivan @ELTchat there's a nice series started in @ETprofessional on texting &amp; refs this CL study http:\/\/t.co\/q32iByANm0",
  "id" : 407157656218894336,
  "in_reply_to_status_id" : 407142823608479744,
  "created_at" : "2013-12-01 14:42:04 +0000",
  "in_reply_to_screen_name" : "JaneCohenEFL",
  "in_reply_to_user_id_str" : "705261589",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ioannis E. Saridakis",
      "screen_name" : "iesaridakis",
      "indices" : [ 3, 15 ],
      "id_str" : "319436319",
      "id" : 319436319
    }, {
      "name" : "Scoop.it",
      "screen_name" : "scoopit",
      "indices" : [ 91, 99 ],
      "id_str" : "209484168",
      "id" : 209484168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/tXc6BbxDT7",
      "expanded_url" : "http:\/\/sco.lt\/5XDX8b",
      "display_url" : "sco.lt\/5XDX8b"
    } ]
  },
  "geo" : { },
  "id_str" : "407154955473403904",
  "text" : "RT @iesaridakis: Corpus linguistic analysis of written language: How to use \u201CI\u201D and more | @scoopit http:\/\/t.co\/tXc6BbxDT7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.scoop.it\" rel=\"nofollow\"\u003EScoop.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Scoop.it",
        "screen_name" : "scoopit",
        "indices" : [ 74, 82 ],
        "id_str" : "209484168",
        "id" : 209484168
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/tXc6BbxDT7",
        "expanded_url" : "http:\/\/sco.lt\/5XDX8b",
        "display_url" : "sco.lt\/5XDX8b"
      } ]
    },
    "geo" : { },
    "id_str" : "407130123356614656",
    "text" : "Corpus linguistic analysis of written language: How to use \u201CI\u201D and more | @scoopit http:\/\/t.co\/tXc6BbxDT7",
    "id" : 407130123356614656,
    "created_at" : "2013-12-01 12:52:40 +0000",
    "user" : {
      "name" : "Ioannis E. Saridakis",
      "screen_name" : "iesaridakis",
      "protected" : false,
      "id_str" : "319436319",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458954440406347777\/cRTX10yh_normal.jpeg",
      "id" : 319436319,
      "verified" : false
    }
  },
  "id" : 407154955473403904,
  "created_at" : "2013-12-01 14:31:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
} ]