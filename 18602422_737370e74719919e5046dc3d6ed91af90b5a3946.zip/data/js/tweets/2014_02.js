Grailbird.data.tweets_2014_02 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/PPiE94opkg",
      "expanded_url" : "http:\/\/www.cepr.net\/index.php\/blogs\/the-americas-blog\/when-protests-and-violence-are-important-to-the-us-media",
      "display_url" : "cepr.net\/index.php\/blog\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439494726291820544",
  "text" : "When Protests and Violence Are Important to the U.S. Media http:\/\/t.co\/PPiE94opkg",
  "id" : 439494726291820544,
  "created_at" : "2014-02-28 20:18:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monika Sobejko",
      "screen_name" : "SobejM",
      "indices" : [ 0, 7 ],
      "id_str" : "380504775",
      "id" : 380504775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439442651289362432",
  "geo" : { },
  "id_str" : "439483098372509696",
  "in_reply_to_user_id" : 380504775,
  "text" : "@SobejM i think this is one of the most user friendly interfaces i have seen for a corpus in a while",
  "id" : 439483098372509696,
  "in_reply_to_status_id" : 439442651289362432,
  "created_at" : "2014-02-28 19:31:50 +0000",
  "in_reply_to_screen_name" : "SobejM",
  "in_reply_to_user_id_str" : "380504775",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George Chilton",
      "screen_name" : "designerlessons",
      "indices" : [ 0, 16 ],
      "id_str" : "432090149",
      "id" : 432090149
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439432876002934784",
  "geo" : { },
  "id_str" : "439482800140738560",
  "in_reply_to_user_id" : 432090149,
  "text" : "@designerlessons all good thanks, nice to c u back on twitter :)",
  "id" : 439482800140738560,
  "in_reply_to_status_id" : 439432876002934784,
  "created_at" : "2014-02-28 19:30:39 +0000",
  "in_reply_to_screen_name" : "designerlessons",
  "in_reply_to_user_id_str" : "432090149",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian N. Larson",
      "screen_name" : "Rhetoricked",
      "indices" : [ 0, 12 ],
      "id_str" : "247464307",
      "id" : 247464307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/uw25QXqTfC",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=qnJxafaOGbQ",
      "display_url" : "youtube.com\/watch?v=qnJxaf\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "439357134623752192",
  "geo" : { },
  "id_str" : "439481667355693056",
  "in_reply_to_user_id" : 247464307,
  "text" : "@Rhetoricked nice, was reminded of this http:\/\/t.co\/uw25QXqTfC :)",
  "id" : 439481667355693056,
  "in_reply_to_status_id" : 439357134623752192,
  "created_at" : "2014-02-28 19:26:09 +0000",
  "in_reply_to_screen_name" : "Rhetoricked",
  "in_reply_to_user_id_str" : "247464307",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "i_narrator",
      "screen_name" : "i_narrator",
      "indices" : [ 3, 14 ],
      "id_str" : "281361233",
      "id" : 281361233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/zpPIB7BF8e",
      "expanded_url" : "http:\/\/ti.me\/1hciDtx",
      "display_url" : "ti.me\/1hciDtx"
    } ]
  },
  "geo" : { },
  "id_str" : "439393124532908032",
  "text" : "RT @i_narrator: Here is a map of every state's favorite band: http:\/\/t.co\/zpPIB7BF8e \u6771\u6D77\u5CB8\u5074\u306BREM\u3084nirvana\u304C\u3042\u3063\u3066\u80F8\u71B1\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/zpPIB7BF8e",
        "expanded_url" : "http:\/\/ti.me\/1hciDtx",
        "display_url" : "ti.me\/1hciDtx"
      } ]
    },
    "geo" : { },
    "id_str" : "439358599312076800",
    "text" : "Here is a map of every state's favorite band: http:\/\/t.co\/zpPIB7BF8e \u6771\u6D77\u5CB8\u5074\u306BREM\u3084nirvana\u304C\u3042\u3063\u3066\u80F8\u71B1\u3002",
    "id" : 439358599312076800,
    "created_at" : "2014-02-28 11:17:07 +0000",
    "user" : {
      "name" : "i_narrator",
      "screen_name" : "i_narrator",
      "protected" : false,
      "id_str" : "281361233",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000410308329\/8ed838331668e90230fc3a90a453f21b_normal.jpeg",
      "id" : 281361233,
      "verified" : false
    }
  },
  "id" : 439393124532908032,
  "created_at" : "2014-02-28 13:34:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/dLnpTbPO3q",
      "expanded_url" : "http:\/\/peer.ccsd.cnrs.fr\/docs\/00\/60\/48\/81\/PDF\/PEER_stage2_10.1002%252Fppul.21380.pdf",
      "display_url" : "peer.ccsd.cnrs.fr\/docs\/00\/60\/48\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439381578373152768",
  "text" : "source for widely circulated table of EnglishvsDutch language interpretation http:\/\/t.co\/dLnpTbPO3q int ref Brits survivalrates onTitanic!",
  "id" : 439381578373152768,
  "created_at" : "2014-02-28 12:48:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    }, {
      "name" : "Monika Sobejko",
      "screen_name" : "SobejM",
      "indices" : [ 12, 19 ],
      "id_str" : "380504775",
      "id" : 380504775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439373208589185024",
  "geo" : { },
  "id_str" : "439373671883628544",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco @SobejM ok will wait for yr post , hurry up :)",
  "id" : 439373671883628544,
  "in_reply_to_status_id" : 439373208589185024,
  "created_at" : "2014-02-28 12:17:01 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    }, {
      "name" : "Monika Sobejko",
      "screen_name" : "SobejM",
      "indices" : [ 12, 19 ],
      "id_str" : "380504775",
      "id" : 380504775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439369791930105856",
  "geo" : { },
  "id_str" : "439371917716635648",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco @SobejM is there a list on the site of what the error codes mean?",
  "id" : 439371917716635648,
  "in_reply_to_status_id" : 439369791930105856,
  "created_at" : "2014-02-28 12:10:02 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    }, {
      "name" : "Monika Sobejko",
      "screen_name" : "SobejM",
      "indices" : [ 12, 19 ],
      "id_str" : "380504775",
      "id" : 380504775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439368309600186368",
  "geo" : { },
  "id_str" : "439368875252396033",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco @SobejM sure is, they offer some nice data downloads as well, looking fwd to yr post :)",
  "id" : 439368875252396033,
  "in_reply_to_status_id" : 439368309600186368,
  "created_at" : "2014-02-28 11:57:57 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George Chilton",
      "screen_name" : "designerlessons",
      "indices" : [ 3, 19 ],
      "id_str" : "432090149",
      "id" : 432090149
    }, {
      "name" : "George Chilton",
      "screen_name" : "designerlessons",
      "indices" : [ 123, 139 ],
      "id_str" : "432090149",
      "id" : 432090149
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Barcelona",
      "indices" : [ 72, 82 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "edu",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "coops",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/2rfz7NU6h4",
      "expanded_url" : "http:\/\/wp.me\/p3yH5T-I",
      "display_url" : "wp.me\/p3yH5T-I"
    } ]
  },
  "geo" : { },
  "id_str" : "439368575711981568",
  "text" : "RT @designerlessons: Here's a report detailing what we found out in our #Barcelona Teachers Survey http:\/\/t.co\/2rfz7NU6h4  @designerlessons\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "George Chilton",
        "screen_name" : "designerlessons",
        "indices" : [ 102, 118 ],
        "id_str" : "432090149",
        "id" : 432090149
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Barcelona",
        "indices" : [ 51, 61 ]
      }, {
        "text" : "eltchat",
        "indices" : [ 119, 127 ]
      }, {
        "text" : "edu",
        "indices" : [ 128, 132 ]
      }, {
        "text" : "coops",
        "indices" : [ 133, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/2rfz7NU6h4",
        "expanded_url" : "http:\/\/wp.me\/p3yH5T-I",
        "display_url" : "wp.me\/p3yH5T-I"
      } ]
    },
    "geo" : { },
    "id_str" : "438001956905185280",
    "text" : "Here's a report detailing what we found out in our #Barcelona Teachers Survey http:\/\/t.co\/2rfz7NU6h4  @designerlessons #eltchat #edu #coops",
    "id" : 438001956905185280,
    "created_at" : "2014-02-24 17:26:18 +0000",
    "user" : {
      "name" : "George Chilton",
      "screen_name" : "designerlessons",
      "protected" : false,
      "id_str" : "432090149",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/468158165914501121\/aHVWzkwG_normal.jpeg",
      "id" : 432090149,
      "verified" : false
    }
  },
  "id" : 439368575711981568,
  "created_at" : "2014-02-28 11:56:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monika Sobejko",
      "screen_name" : "SobejM",
      "indices" : [ 101, 108 ],
      "id_str" : "380504775",
      "id" : 380504775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Btngw98Hyy",
      "expanded_url" : "http:\/\/pelcra.pl\/plec\/",
      "display_url" : "pelcra.pl\/plec\/"
    } ]
  },
  "geo" : { },
  "id_str" : "439364486366236673",
  "text" : "http:\/\/t.co\/Btngw98Hyy An English learner corpus of Polish people with attached sound files nice! cc @SobejM",
  "id" : 439364486366236673,
  "created_at" : "2014-02-28 11:40:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Parise",
      "screen_name" : "peterrenshu",
      "indices" : [ 0, 12 ],
      "id_str" : "631949549",
      "id" : 631949549
    }, {
      "name" : "i_narrator",
      "screen_name" : "i_narrator",
      "indices" : [ 13, 24 ],
      "id_str" : "281361233",
      "id" : 281361233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439182660963819522",
  "geo" : { },
  "id_str" : "439195583275077632",
  "in_reply_to_user_id" : 631949549,
  "text" : "@peterrenshu @i_narrator i think it adds xml no? u can try virtual machine or email author?",
  "id" : 439195583275077632,
  "in_reply_to_status_id" : 439182660963819522,
  "created_at" : "2014-02-28 00:29:21 +0000",
  "in_reply_to_screen_name" : "peterrenshu",
  "in_reply_to_user_id_str" : "631949549",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "4TUNE Teller App",
      "screen_name" : "4tunetellernet",
      "indices" : [ 0, 15 ],
      "id_str" : "467634146",
      "id" : 467634146
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439181883478654976",
  "geo" : { },
  "id_str" : "439184785630846976",
  "in_reply_to_user_id" : 467634146,
  "text" : "@4tunetellernet ok cool thx for heads up PBing now :)",
  "id" : 439184785630846976,
  "in_reply_to_status_id" : 439181883478654976,
  "created_at" : "2014-02-27 23:46:27 +0000",
  "in_reply_to_screen_name" : "4tunetellernet",
  "in_reply_to_user_id_str" : "467634146",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "i_narrator",
      "screen_name" : "i_narrator",
      "indices" : [ 3, 14 ],
      "id_str" : "281361233",
      "id" : 281361233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/8Hq7hWYbyO",
      "expanded_url" : "http:\/\/www.staff.uni-mainz.de\/fantinuo\/corpuscreator.html",
      "display_url" : "staff.uni-mainz.de\/fantinuo\/corpu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439161706624081920",
  "text" : "RT @i_narrator: CORPUSCREATOR - SPECIALIZED CORPORA IN NO TIME http:\/\/t.co\/8Hq7hWYbyO\u3000\u6C17\u306B\u306A\u308B\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 69 ],
        "url" : "http:\/\/t.co\/8Hq7hWYbyO",
        "expanded_url" : "http:\/\/www.staff.uni-mainz.de\/fantinuo\/corpuscreator.html",
        "display_url" : "staff.uni-mainz.de\/fantinuo\/corpu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "439155154286571520",
    "text" : "CORPUSCREATOR - SPECIALIZED CORPORA IN NO TIME http:\/\/t.co\/8Hq7hWYbyO\u3000\u6C17\u306B\u306A\u308B\u3002",
    "id" : 439155154286571520,
    "created_at" : "2014-02-27 21:48:42 +0000",
    "user" : {
      "name" : "i_narrator",
      "screen_name" : "i_narrator",
      "protected" : false,
      "id_str" : "281361233",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000410308329\/8ed838331668e90230fc3a90a453f21b_normal.jpeg",
      "id" : 281361233,
      "verified" : false
    }
  },
  "id" : 439161706624081920,
  "created_at" : "2014-02-27 22:14:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "i_narrator",
      "screen_name" : "i_narrator",
      "indices" : [ 0, 11 ],
      "id_str" : "281361233",
      "id" : 281361233
    }, {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "indices" : [ 12, 24 ],
      "id_str" : "849729062",
      "id" : 849729062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/dAM9WBbCd9",
      "expanded_url" : "http:\/\/docs.sslmit.unibo.it\/doku.php?id=bootcat:help:search_engine_key",
      "display_url" : "docs.sslmit.unibo.it\/doku.php?id=bo\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "439155154286571520",
  "geo" : { },
  "id_str" : "439160985434464258",
  "in_reply_to_user_id" : 281361233,
  "text" : "@i_narrator @TonyMcEnery woah building from pdf files gotta try this, fyi see this to get Bing key http:\/\/t.co\/dAM9WBbCd9",
  "id" : 439160985434464258,
  "in_reply_to_status_id" : 439155154286571520,
  "created_at" : "2014-02-27 22:11:52 +0000",
  "in_reply_to_screen_name" : "i_narrator",
  "in_reply_to_user_id_str" : "281361233",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "4TUNE Teller App",
      "screen_name" : "4tunetellernet",
      "indices" : [ 0, 15 ],
      "id_str" : "467634146",
      "id" : 467634146
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/TZMkpVCYpr",
      "expanded_url" : "http:\/\/tvtropes.org\/pmwiki\/pmwiki.php\/Main\/SuperWindowJump",
      "display_url" : "tvtropes.org\/pmwiki\/pmwiki.\u2026"
    }, {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/oSDkjbDEVV",
      "expanded_url" : "http:\/\/i.imgur.com\/hultwoB.gif",
      "display_url" : "i.imgur.com\/hultwoB.gif"
    } ]
  },
  "in_reply_to_status_id_str" : "439157575079440385",
  "geo" : { },
  "id_str" : "439159526831702016",
  "in_reply_to_user_id" : 467634146,
  "text" : "@4tunetellernet  true dat -http:\/\/t.co\/TZMkpVCYpr &amp; playing with this trope - http:\/\/t.co\/oSDkjbDEVV :)",
  "id" : 439159526831702016,
  "in_reply_to_status_id" : 439157575079440385,
  "created_at" : "2014-02-27 22:06:05 +0000",
  "in_reply_to_screen_name" : "4tunetellernet",
  "in_reply_to_user_id_str" : "467634146",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Adele Soracco",
      "screen_name" : "LauraSoracco",
      "indices" : [ 3, 16 ],
      "id_str" : "15663328",
      "id" : 15663328
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EAP",
      "indices" : [ 109, 113 ]
    }, {
      "text" : "Berlin",
      "indices" : [ 114, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/e9WRPAZu4X",
      "expanded_url" : "http:\/\/www.uni-potsdam.de\/zessko\/projekt\/eap\/workshop.html",
      "display_url" : "uni-potsdam.de\/zessko\/projekt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439156078526611456",
  "text" : "RT @LauraSoracco: Presenting at the EAP Conference in Universit\u00E4t Potsdam on May 10th http:\/\/t.co\/e9WRPAZu4X #EAP #Berlin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EAP",
        "indices" : [ 91, 95 ]
      }, {
        "text" : "Berlin",
        "indices" : [ 96, 103 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/e9WRPAZu4X",
        "expanded_url" : "http:\/\/www.uni-potsdam.de\/zessko\/projekt\/eap\/workshop.html",
        "display_url" : "uni-potsdam.de\/zessko\/projekt\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "439147245771161600",
    "text" : "Presenting at the EAP Conference in Universit\u00E4t Potsdam on May 10th http:\/\/t.co\/e9WRPAZu4X #EAP #Berlin",
    "id" : 439147245771161600,
    "created_at" : "2014-02-27 21:17:17 +0000",
    "user" : {
      "name" : "Laura Adele Soracco",
      "screen_name" : "LauraSoracco",
      "protected" : false,
      "id_str" : "15663328",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766919326427254785\/4J5Q1zgQ_normal.jpg",
      "id" : 15663328,
      "verified" : false
    }
  },
  "id" : 439156078526611456,
  "created_at" : "2014-02-27 21:52:23 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen White",
      "screen_name" : "KarenWhiteInk",
      "indices" : [ 0, 14 ],
      "id_str" : "20389382",
      "id" : 20389382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439155655069671425",
  "geo" : { },
  "id_str" : "439155968421920768",
  "in_reply_to_user_id" : 20389382,
  "text" : "@KarenWhiteInk True Detective",
  "id" : 439155968421920768,
  "in_reply_to_status_id" : 439155655069671425,
  "created_at" : "2014-02-27 21:51:56 +0000",
  "in_reply_to_screen_name" : "KarenWhiteInk",
  "in_reply_to_user_id_str" : "20389382",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol Goodey",
      "screen_name" : "cgoodey",
      "indices" : [ 0, 8 ],
      "id_str" : "26606833",
      "id" : 26606833
    }, {
      "name" : "BCSeminars",
      "screen_name" : "BCseminars",
      "indices" : [ 9, 20 ],
      "id_str" : "134099962",
      "id" : 134099962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439140008826781696",
  "geo" : { },
  "id_str" : "439141154668703745",
  "in_reply_to_user_id" : 26606833,
  "text" : "@cgoodey @BCseminars very nice double biller :)",
  "id" : 439141154668703745,
  "in_reply_to_status_id" : 439140008826781696,
  "created_at" : "2014-02-27 20:53:04 +0000",
  "in_reply_to_screen_name" : "cgoodey",
  "in_reply_to_user_id_str" : "26606833",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol Goodey",
      "screen_name" : "cgoodey",
      "indices" : [ 3, 11 ],
      "id_str" : "26606833",
      "id" : 26606833
    }, {
      "name" : "BCSeminars",
      "screen_name" : "BCseminars",
      "indices" : [ 16, 27 ],
      "id_str" : "134099962",
      "id" : 134099962
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusMOOC",
      "indices" : [ 143, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 123, 144 ],
      "url" : "http:\/\/t.co\/OciNeHoRru",
      "expanded_url" : "http:\/\/ow.ly\/u49Ji",
      "display_url" : "ow.ly\/u49Ji"
    } ]
  },
  "geo" : { },
  "id_str" : "439141094329438209",
  "text" : "RT @cgoodey: MT @BCseminars: Corpora in the classroom &amp; creating effective materials. LIVE ONLINE or London Mar11 1730 http:\/\/t.co\/OciNeHoR\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BCSeminars",
        "screen_name" : "BCseminars",
        "indices" : [ 3, 14 ],
        "id_str" : "134099962",
        "id" : 134099962
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpusMOOC",
        "indices" : [ 133, 144 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/OciNeHoRru",
        "expanded_url" : "http:\/\/ow.ly\/u49Ji",
        "display_url" : "ow.ly\/u49Ji"
      } ]
    },
    "geo" : { },
    "id_str" : "439140008826781696",
    "text" : "MT @BCseminars: Corpora in the classroom &amp; creating effective materials. LIVE ONLINE or London Mar11 1730 http:\/\/t.co\/OciNeHoRru #corpusMOOC",
    "id" : 439140008826781696,
    "created_at" : "2014-02-27 20:48:31 +0000",
    "user" : {
      "name" : "Carol Goodey",
      "screen_name" : "cgoodey",
      "protected" : false,
      "id_str" : "26606833",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/739764539839926273\/EtEpZHsA_normal.jpg",
      "id" : 26606833,
      "verified" : false
    }
  },
  "id" : 439141094329438209,
  "created_at" : "2014-02-27 20:52:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "439124142382530560",
  "geo" : { },
  "id_str" : "439128991484870656",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco am hoping that this series goes past two parts :)",
  "id" : 439128991484870656,
  "in_reply_to_status_id" : 439124142382530560,
  "created_at" : "2014-02-27 20:04:44 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 3, 14 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELT",
      "indices" : [ 122, 126 ]
    }, {
      "text" : "ELTchat",
      "indices" : [ 127, 135 ]
    }, {
      "text" : "corpusMOOC",
      "indices" : [ 136, 140 ]
    }, {
      "text" : "corpora",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/MyQlfaZ1qX",
      "expanded_url" : "http:\/\/learnercorpus.blogspot.com\/2014\/02\/openly-available-learner-corpora-1.html?spref=tw",
      "display_url" : "learnercorpus.blogspot.com\/2014\/02\/openly\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439126320078135297",
  "text" : "RT @lexicoloco: Learner Corpora and Corpus Studies: Openly available Learner Corpora 1 - a survey  http:\/\/t.co\/MyQlfaZ1qX #ELT #ELTchat #co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELT",
        "indices" : [ 106, 110 ]
      }, {
        "text" : "ELTchat",
        "indices" : [ 111, 119 ]
      }, {
        "text" : "corpusMOOC",
        "indices" : [ 120, 131 ]
      }, {
        "text" : "corpora",
        "indices" : [ 132, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/MyQlfaZ1qX",
        "expanded_url" : "http:\/\/learnercorpus.blogspot.com\/2014\/02\/openly-available-learner-corpora-1.html?spref=tw",
        "display_url" : "learnercorpus.blogspot.com\/2014\/02\/openly\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "439124142382530560",
    "text" : "Learner Corpora and Corpus Studies: Openly available Learner Corpora 1 - a survey  http:\/\/t.co\/MyQlfaZ1qX #ELT #ELTchat #corpusMOOC #corpora",
    "id" : 439124142382530560,
    "created_at" : "2014-02-27 19:45:28 +0000",
    "user" : {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "protected" : false,
      "id_str" : "300734173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2403500097\/3nmx3kjaycyoc7irwe6s_normal.jpeg",
      "id" : 300734173,
      "verified" : false
    }
  },
  "id" : 439126320078135297,
  "created_at" : "2014-02-27 19:54:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ESRC",
      "screen_name" : "ESRC",
      "indices" : [ 3, 8 ],
      "id_str" : "19393236",
      "id" : 19393236
    }, {
      "name" : "CASS",
      "screen_name" : "CorpusSocialSci",
      "indices" : [ 13, 29 ],
      "id_str" : "1326508478",
      "id" : 1326508478
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 127, 140 ],
      "url" : "http:\/\/t.co\/YR4UDEVTtT",
      "expanded_url" : "http:\/\/cass.lancs.ac.uk\/?p=1052",
      "display_url" : "cass.lancs.ac.uk\/?p=1052"
    } ]
  },
  "geo" : { },
  "id_str" : "439076663205576704",
  "text" : "RT @ESRC: RT @CorpusSocialSci: New, preliminary research on the Twitter reaction to the sentencing of the Lee Rigby murderers  http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CASS",
        "screen_name" : "CorpusSocialSci",
        "indices" : [ 3, 19 ],
        "id_str" : "1326508478",
        "id" : 1326508478
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/YR4UDEVTtT",
        "expanded_url" : "http:\/\/cass.lancs.ac.uk\/?p=1052",
        "display_url" : "cass.lancs.ac.uk\/?p=1052"
      } ]
    },
    "geo" : { },
    "id_str" : "439051430880882688",
    "text" : "RT @CorpusSocialSci: New, preliminary research on the Twitter reaction to the sentencing of the Lee Rigby murderers  http:\/\/t.co\/YR4UDEVTtT",
    "id" : 439051430880882688,
    "created_at" : "2014-02-27 14:56:32 +0000",
    "user" : {
      "name" : "ESRC",
      "screen_name" : "ESRC",
      "protected" : false,
      "id_str" : "19393236",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/679301155344683008\/5ef42RKI_normal.jpg",
      "id" : 19393236,
      "verified" : true
    }
  },
  "id" : 439076663205576704,
  "created_at" : "2014-02-27 16:36:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/E8sFWlI3pf",
      "expanded_url" : "http:\/\/language.sakura.ne.jp\/icnale\/",
      "display_url" : "language.sakura.ne.jp\/icnale\/"
    } ]
  },
  "geo" : { },
  "id_str" : "439070277897846784",
  "text" : "http:\/\/t.co\/E8sFWlI3pf Open access learner corpus h\/t facebook CL group",
  "id" : 439070277897846784,
  "created_at" : "2014-02-27 16:11:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amit Agarwal",
      "screen_name" : "labnol",
      "indices" : [ 94, 101 ],
      "id_str" : "724473",
      "id" : 724473
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/kB77PJW2jm",
      "expanded_url" : "http:\/\/www.labnol.org\/?p=28149",
      "display_url" : "labnol.org\/?p=28149"
    } ]
  },
  "geo" : { },
  "id_str" : "439033709962874880",
  "text" : "[Digital Inspiration] A Simple Way to Create RSS Feeds for Twitter http:\/\/t.co\/kB77PJW2jm via @labnol",
  "id" : 439033709962874880,
  "created_at" : "2014-02-27 13:46:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Divya Madhavan",
      "screen_name" : "_divyamadhavan",
      "indices" : [ 0, 15 ],
      "id_str" : "408492806",
      "id" : 408492806
    }, {
      "name" : "pat thomson",
      "screen_name" : "ThomsonPat",
      "indices" : [ 119, 130 ],
      "id_str" : "402209787",
      "id" : 402209787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/10cyL9bt9L",
      "expanded_url" : "http:\/\/wp.me\/p1GJk8-Ik",
      "display_url" : "wp.me\/p1GJk8-Ik"
    } ]
  },
  "geo" : { },
  "id_str" : "439022802411483136",
  "in_reply_to_user_id" : 408492806,
  "text" : "@_divyamadhavan hi divya have u seen this? - getting published in English language journals http:\/\/t.co\/10cyL9bt9L via @ThomsonPat",
  "id" : 439022802411483136,
  "created_at" : "2014-02-27 13:02:47 +0000",
  "in_reply_to_screen_name" : "_divyamadhavan",
  "in_reply_to_user_id_str" : "408492806",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "indices" : [ 3, 18 ],
      "id_str" : "27716419",
      "id" : 27716419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/hg4CEhG8nB",
      "expanded_url" : "http:\/\/www.craigmurray.org.uk\/archives\/2014\/02\/moazzam-begg-a-political-prisoner-again\/",
      "display_url" : "craigmurray.org.uk\/archives\/2014\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439016281128579072",
  "text" : "RT @CraigMurrayOrg: New post: Moazzam Begg a Political Prisoner Again http:\/\/t.co\/hg4CEhG8nB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.craigmurray.org.uk\" rel=\"nofollow\"\u003ECraig Murray posting plugin\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 72 ],
        "url" : "http:\/\/t.co\/hg4CEhG8nB",
        "expanded_url" : "http:\/\/www.craigmurray.org.uk\/archives\/2014\/02\/moazzam-begg-a-political-prisoner-again\/",
        "display_url" : "craigmurray.org.uk\/archives\/2014\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "438670361929199617",
    "text" : "New post: Moazzam Begg a Political Prisoner Again http:\/\/t.co\/hg4CEhG8nB",
    "id" : 438670361929199617,
    "created_at" : "2014-02-26 13:42:19 +0000",
    "user" : {
      "name" : "Craig Murray",
      "screen_name" : "CraigMurrayOrg",
      "protected" : false,
      "id_str" : "27716419",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1388436826\/cm_normal.jpg",
      "id" : 27716419,
      "verified" : false
    }
  },
  "id" : 439016281128579072,
  "created_at" : "2014-02-27 12:36:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hana Tich\u00E1",
      "screen_name" : "HanaTicha",
      "indices" : [ 3, 13 ],
      "id_str" : "512296705",
      "id" : 512296705
    }, {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 79, 90 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/cok2Xme4ez",
      "expanded_url" : "http:\/\/how-i-see-it-now.blogspot.cz\/2014\/02\/through-lens-of-communicativeness.html",
      "display_url" : "how-i-see-it-now.blogspot.cz\/2014\/02\/throug\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438779423450730496",
  "text" : "RT @HanaTicha: Just blogged: Through the lens of communicativeness inspired by @kevchanwow http:\/\/t.co\/cok2Xme4ez",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kevin Stein",
        "screen_name" : "kevchanwow",
        "indices" : [ 64, 75 ],
        "id_str" : "144663117",
        "id" : 144663117
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/cok2Xme4ez",
        "expanded_url" : "http:\/\/how-i-see-it-now.blogspot.cz\/2014\/02\/through-lens-of-communicativeness.html",
        "display_url" : "how-i-see-it-now.blogspot.cz\/2014\/02\/throug\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "438774942466080768",
    "text" : "Just blogged: Through the lens of communicativeness inspired by @kevchanwow http:\/\/t.co\/cok2Xme4ez",
    "id" : 438774942466080768,
    "created_at" : "2014-02-26 20:37:52 +0000",
    "user" : {
      "name" : "Hana Tich\u00E1",
      "screen_name" : "HanaTicha",
      "protected" : false,
      "id_str" : "512296705",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/699528253598494721\/HL9Np6Gu_normal.jpg",
      "id" : 512296705,
      "verified" : false
    }
  },
  "id" : 438779423450730496,
  "created_at" : "2014-02-26 20:55:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 0, 11 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/F38Rsd74lh",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=EAwFPOVwrdI",
      "display_url" : "youtube.com\/watch?v=EAwFPO\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438753814062333952",
  "text" : "#corpusmooc folk maybe interested in laughter in eap using corpus linguistics webinar http:\/\/t.co\/F38Rsd74lh",
  "id" : 438753814062333952,
  "created_at" : "2014-02-26 19:13:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Rei",
      "screen_name" : "Charlesrei1",
      "indices" : [ 0, 12 ],
      "id_str" : "464454382",
      "id" : 464454382
    }, {
      "name" : "British Council",
      "screen_name" : "BritishCouncil",
      "indices" : [ 13, 28 ],
      "id_str" : "14732889",
      "id" : 14732889
    }, {
      "name" : "BBC Learning English",
      "screen_name" : "bbcle",
      "indices" : [ 29, 35 ],
      "id_str" : "2450291",
      "id" : 2450291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438730535788363776",
  "geo" : { },
  "id_str" : "438732827547676672",
  "in_reply_to_user_id" : 464454382,
  "text" : "@Charlesrei1 @BritishCouncil @bbcle it's hard to be hip in online edu unless u have word clouds...",
  "id" : 438732827547676672,
  "in_reply_to_status_id" : 438730535788363776,
  "created_at" : "2014-02-26 17:50:32 +0000",
  "in_reply_to_screen_name" : "Charlesrei1",
  "in_reply_to_user_id_str" : "464454382",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 60, 76 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/8yJaRcJ8Cz",
      "expanded_url" : "http:\/\/wp.me\/p2dnZV-5s",
      "display_url" : "wp.me\/p2dnZV-5s"
    } ]
  },
  "geo" : { },
  "id_str" : "438731400515047424",
  "text" : "Three shockers from the Guardian http:\/\/t.co\/8yJaRcJ8Cz via @wordpressdotcom",
  "id" : 438731400515047424,
  "created_at" : "2014-02-26 17:44:51 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Rei",
      "screen_name" : "Charlesrei1",
      "indices" : [ 0, 12 ],
      "id_str" : "464454382",
      "id" : 464454382
    }, {
      "name" : "British Council",
      "screen_name" : "BritishCouncil",
      "indices" : [ 13, 28 ],
      "id_str" : "14732889",
      "id" : 14732889
    }, {
      "name" : "BBC Learning English",
      "screen_name" : "bbcle",
      "indices" : [ 29, 35 ],
      "id_str" : "2450291",
      "id" : 2450291
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wordaizer",
      "indices" : [ 48, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/hs9Epqna3n",
      "expanded_url" : "http:\/\/www.mosaizer.com\/Wordaizer\/index.htm",
      "display_url" : "mosaizer.com\/Wordaizer\/inde\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "438727618347933697",
  "geo" : { },
  "id_str" : "438729327732342784",
  "in_reply_to_user_id" : 464454382,
  "text" : "@Charlesrei1 @BritishCouncil @bbcle why not try #wordaizer lets you create own shapes http:\/\/t.co\/hs9Epqna3n",
  "id" : 438729327732342784,
  "in_reply_to_status_id" : 438727618347933697,
  "created_at" : "2014-02-26 17:36:37 +0000",
  "in_reply_to_screen_name" : "Charlesrei1",
  "in_reply_to_user_id_str" : "464454382",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StudentsFirst",
      "screen_name" : "StudentsFirst",
      "indices" : [ 58, 72 ],
      "id_str" : "221068485",
      "id" : 221068485
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438710983016849408",
  "text" : "@TESOLatRennert  it is interesting as well as the spin by @StudentsFirst ;)",
  "id" : 438710983016849408,
  "created_at" : "2014-02-26 16:23:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StudentsFirst",
      "screen_name" : "StudentsFirst",
      "indices" : [ 16, 30 ],
      "id_str" : "221068485",
      "id" : 221068485
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438709819999289344",
  "text" : "@TESOLatRennert @StudentsFirst &lt;&lt;this study does not try to link measures of student performance to particular reforms.&gt;&gt; p6",
  "id" : 438709819999289344,
  "created_at" : "2014-02-26 16:19:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike S. Boyle",
      "screen_name" : "heyboyle",
      "indices" : [ 0, 9 ],
      "id_str" : "612840231",
      "id" : 612840231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438702332029976576",
  "geo" : { },
  "id_str" : "438703542552236032",
  "in_reply_to_user_id" : 612840231,
  "text" : "@heyboyle for whoever maybe interested, i for one welcome our new language dictator overlord :)",
  "id" : 438703542552236032,
  "in_reply_to_status_id" : 438702332029976576,
  "created_at" : "2014-02-26 15:54:09 +0000",
  "in_reply_to_screen_name" : "heyboyle",
  "in_reply_to_user_id_str" : "612840231",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Aisha Brown",
      "screen_name" : "amyaishab",
      "indices" : [ 0, 10 ],
      "id_str" : "900029641",
      "id" : 900029641
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 22, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438701973484101633",
  "in_reply_to_user_id" : 900029641,
  "text" : "@amyaishab thanks for #corpusmooc top tip RT :)",
  "id" : 438701973484101633,
  "created_at" : "2014-02-26 15:47:55 +0000",
  "in_reply_to_screen_name" : "amyaishab",
  "in_reply_to_user_id_str" : "900029641",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike S. Boyle",
      "screen_name" : "heyboyle",
      "indices" : [ 0, 9 ],
      "id_str" : "612840231",
      "id" : 612840231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/6wpgA5hiPM",
      "expanded_url" : "http:\/\/corpus.byu.edu\/coca\/?c=coca&q=28764396",
      "display_url" : "corpus.byu.edu\/coca\/?c=coca&q\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "438698285591965697",
  "geo" : { },
  "id_str" : "438700589367951360",
  "in_reply_to_user_id" : 612840231,
  "text" : "@heyboyle i wasn't thinking of freq but now u mention it http:\/\/t.co\/6wpgA5hiPM :), dunno to whom trips off and sounds better imo",
  "id" : 438700589367951360,
  "in_reply_to_status_id" : 438698285591965697,
  "created_at" : "2014-02-26 15:42:25 +0000",
  "in_reply_to_screen_name" : "heyboyle",
  "in_reply_to_user_id_str" : "612840231",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike S. Boyle",
      "screen_name" : "heyboyle",
      "indices" : [ 0, 9 ],
      "id_str" : "612840231",
      "id" : 612840231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438693441716121600",
  "geo" : { },
  "id_str" : "438697545096003584",
  "in_reply_to_user_id" : 612840231,
  "text" : "@heyboyle nice list though \"to whom\" sounds better than \"to who\" in most cases",
  "id" : 438697545096003584,
  "in_reply_to_status_id" : 438693441716121600,
  "created_at" : "2014-02-26 15:30:20 +0000",
  "in_reply_to_screen_name" : "heyboyle",
  "in_reply_to_user_id_str" : "612840231",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 3, 14 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/oKF97HVouR",
      "expanded_url" : "http:\/\/www.cambridge.org\/elt\/blog\/2014\/02\/collocation-learner-wading-depths\/",
      "display_url" : "cambridge.org\/elt\/blog\/2014\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438695594669113344",
  "text" : "RT @lexicoloco: Collocation and the learner: wading into the depths  http:\/\/t.co\/oKF97HVouR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 75 ],
        "url" : "http:\/\/t.co\/oKF97HVouR",
        "expanded_url" : "http:\/\/www.cambridge.org\/elt\/blog\/2014\/02\/collocation-learner-wading-depths\/",
        "display_url" : "cambridge.org\/elt\/blog\/2014\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "438624011048603649",
    "text" : "Collocation and the learner: wading into the depths  http:\/\/t.co\/oKF97HVouR",
    "id" : 438624011048603649,
    "created_at" : "2014-02-26 10:38:08 +0000",
    "user" : {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "protected" : false,
      "id_str" : "300734173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2403500097\/3nmx3kjaycyoc7irwe6s_normal.jpeg",
      "id" : 300734173,
      "verified" : false
    }
  },
  "id" : 438695594669113344,
  "created_at" : "2014-02-26 15:22:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Aisha Brown",
      "screen_name" : "amyaishab",
      "indices" : [ 3, 13 ],
      "id_str" : "900029641",
      "id" : 900029641
    }, {
      "name" : "danah boyd",
      "screen_name" : "zephoria",
      "indices" : [ 20, 29 ],
      "id_str" : "633",
      "id" : 633
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NSMNSS",
      "indices" : [ 91, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/CV7eDghJ5v",
      "expanded_url" : "http:\/\/www.danah.org\/itscomplicated\/",
      "display_url" : "danah.org\/itscomplicated\/"
    } ]
  },
  "geo" : { },
  "id_str" : "438693939303161856",
  "text" : "RT @amyaishab: Wow! @zephoria's new book is totally free as a PDF: http:\/\/t.co\/CV7eDghJ5v  #NSMNSS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "danah boyd",
        "screen_name" : "zephoria",
        "indices" : [ 5, 14 ],
        "id_str" : "633",
        "id" : 633
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NSMNSS",
        "indices" : [ 76, 83 ]
      } ],
      "urls" : [ {
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/CV7eDghJ5v",
        "expanded_url" : "http:\/\/www.danah.org\/itscomplicated\/",
        "display_url" : "danah.org\/itscomplicated\/"
      } ]
    },
    "geo" : { },
    "id_str" : "438687720505114624",
    "text" : "Wow! @zephoria's new book is totally free as a PDF: http:\/\/t.co\/CV7eDghJ5v  #NSMNSS",
    "id" : 438687720505114624,
    "created_at" : "2014-02-26 14:51:17 +0000",
    "user" : {
      "name" : "Amy Aisha Brown",
      "screen_name" : "amyaishab",
      "protected" : false,
      "id_str" : "900029641",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/620604005799067648\/nD3nCCXK_normal.jpg",
      "id" : 900029641,
      "verified" : false
    }
  },
  "id" : 438693939303161856,
  "created_at" : "2014-02-26 15:16:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil Chappell",
      "screen_name" : "TESOLatMQ",
      "indices" : [ 3, 13 ],
      "id_str" : "326498171",
      "id" : 326498171
    }, {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "indices" : [ 15, 27 ],
      "id_str" : "192437743",
      "id" : 192437743
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELT",
      "indices" : [ 99, 103 ]
    }, {
      "text" : "AusELT",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/QZdUJFoRIU",
      "expanded_url" : "http:\/\/bit.ly\/OBhcuD",
      "display_url" : "bit.ly\/OBhcuD"
    } ]
  },
  "geo" : { },
  "id_str" : "438602721256820736",
  "text" : "RT @TESOLatMQ: @nathanghall: 7th Special Ed. TESL Canada Jnl is now online. Focus on Pragmatics in #ELT http:\/\/t.co\/QZdUJFoRIU Ed MU\u2019s Lynd\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nathan Hall",
        "screen_name" : "nathanghall",
        "indices" : [ 0, 12 ],
        "id_str" : "192437743",
        "id" : 192437743
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELT",
        "indices" : [ 84, 88 ]
      }, {
        "text" : "AusELT",
        "indices" : [ 132, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/QZdUJFoRIU",
        "expanded_url" : "http:\/\/bit.ly\/OBhcuD",
        "display_url" : "bit.ly\/OBhcuD"
      } ]
    },
    "geo" : { },
    "id_str" : "438574796876443648",
    "in_reply_to_user_id" : 192437743,
    "text" : "@nathanghall: 7th Special Ed. TESL Canada Jnl is now online. Focus on Pragmatics in #ELT http:\/\/t.co\/QZdUJFoRIU Ed MU\u2019s Lynda Yates #AusELT",
    "id" : 438574796876443648,
    "created_at" : "2014-02-26 07:22:34 +0000",
    "in_reply_to_screen_name" : "nathanghall",
    "in_reply_to_user_id_str" : "192437743",
    "user" : {
      "name" : "Phil Chappell",
      "screen_name" : "TESOLatMQ",
      "protected" : false,
      "id_str" : "326498171",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/760985121704910848\/NtDor7Jc_normal.jpg",
      "id" : 326498171,
      "verified" : false
    }
  },
  "id" : 438602721256820736,
  "created_at" : "2014-02-26 09:13:32 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adi Rajan",
      "screen_name" : "adi_rajan",
      "indices" : [ 0, 10 ],
      "id_str" : "1011323449",
      "id" : 1011323449
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438591204012204032",
  "geo" : { },
  "id_str" : "438598409780740096",
  "in_reply_to_user_id" : 1011323449,
  "text" : "@adi_rajan 2011... a good year for unamed sources :\/",
  "id" : 438598409780740096,
  "in_reply_to_status_id" : 438591204012204032,
  "created_at" : "2014-02-26 08:56:24 +0000",
  "in_reply_to_screen_name" : "adi_rajan",
  "in_reply_to_user_id_str" : "1011323449",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "indices" : [ 0, 9 ],
      "id_str" : "167020390",
      "id" : 167020390
    }, {
      "name" : "Haiyang Ai",
      "screen_name" : "aihaiyang",
      "indices" : [ 10, 20 ],
      "id_str" : "1634237000",
      "id" : 1634237000
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 38, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438587013512855552",
  "in_reply_to_user_id" : 167020390,
  "text" : "@antlabjp @aihaiyang thanks for RT of #corpusmooc top tip for wordlists :)",
  "id" : 438587013512855552,
  "created_at" : "2014-02-26 08:11:07 +0000",
  "in_reply_to_screen_name" : "antlabjp",
  "in_reply_to_user_id_str" : "167020390",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "P\u00E9rez-Paredes",
      "screen_name" : "perezparedes",
      "indices" : [ 3, 16 ],
      "id_str" : "28528850",
      "id" : 28528850
    }, {
      "name" : "Universidad Murcia",
      "screen_name" : "umnoticias",
      "indices" : [ 131, 142 ],
      "id_str" : "171047449",
      "id" : 171047449
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 147, 148 ],
      "url" : "http:\/\/t.co\/oxtZpehvWh",
      "expanded_url" : "http:\/\/www.um.es\/languagecorpora\/2014\/02\/25\/recall-special-issue-researching-uses-of-corpora-for-language-teaching-and-learning\/#sthash.x6btcfuN.dpuf",
      "display_url" : "um.es\/languagecorpor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438585593128554497",
  "text" : "RT @perezparedes: Cambridge UP ReCALL Researching uses of corpora for language teaching &amp; learning Boulton &amp; P\u00E9rez-Paredes @umnoticias http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Universidad Murcia",
        "screen_name" : "umnoticias",
        "indices" : [ 113, 124 ],
        "id_str" : "171047449",
        "id" : 171047449
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 125, 147 ],
        "url" : "http:\/\/t.co\/oxtZpehvWh",
        "expanded_url" : "http:\/\/www.um.es\/languagecorpora\/2014\/02\/25\/recall-special-issue-researching-uses-of-corpora-for-language-teaching-and-learning\/#sthash.x6btcfuN.dpuf",
        "display_url" : "um.es\/languagecorpor\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "438561287443066880",
    "text" : "Cambridge UP ReCALL Researching uses of corpora for language teaching &amp; learning Boulton &amp; P\u00E9rez-Paredes @umnoticias http:\/\/t.co\/oxtZpehvWh",
    "id" : 438561287443066880,
    "created_at" : "2014-02-26 06:28:53 +0000",
    "user" : {
      "name" : "P\u00E9rez-Paredes",
      "screen_name" : "perezparedes",
      "protected" : false,
      "id_str" : "28528850",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746249968139313153\/2-1yieTh_normal.jpg",
      "id" : 28528850,
      "verified" : false
    }
  },
  "id" : 438585593128554497,
  "created_at" : "2014-02-26 08:05:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nagehan Tunar",
      "screen_name" : "stiiiv",
      "indices" : [ 0, 7 ],
      "id_str" : "799058600",
      "id" : 799058600
    }, {
      "name" : "British Council",
      "screen_name" : "BritishCouncil",
      "indices" : [ 8, 23 ],
      "id_str" : "14732889",
      "id" : 14732889
    }, {
      "name" : "Iwona",
      "screen_name" : "yvetteinmb",
      "indices" : [ 24, 35 ],
      "id_str" : "90695737",
      "id" : 90695737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/tR2Zo0XTYg",
      "expanded_url" : "http:\/\/elfaproject.wordpress.com\/2013\/07\/27\/laughter-in-academic-talk-brits-yanks-elf-compared\/",
      "display_url" : "elfaproject.wordpress.com\/2013\/07\/27\/lau\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "438370020205535232",
  "geo" : { },
  "id_str" : "438373094512947201",
  "in_reply_to_user_id" : 69068757,
  "text" : "@stiiiv @BritishCouncil @yvetteinmb there's an interesting reproduction of the Nesi paper reported here http:\/\/t.co\/tR2Zo0XTYg",
  "id" : 438373094512947201,
  "in_reply_to_status_id" : 438370020205535232,
  "created_at" : "2014-02-25 18:01:04 +0000",
  "in_reply_to_screen_name" : "stiivkirk",
  "in_reply_to_user_id_str" : "69068757",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Forensic Linguistics",
      "screen_name" : "FORGE_LU",
      "indices" : [ 0, 9 ],
      "id_str" : "2211139201",
      "id" : 2211139201
    }, {
      "name" : "Mark McGlashan",
      "screen_name" : "Mark_McGlashan",
      "indices" : [ 10, 25 ],
      "id_str" : "286869902",
      "id" : 286869902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/EFdOSDy7P6",
      "expanded_url" : "https:\/\/firstlook.org\/theintercept\/document\/2014\/02\/24\/art-deception-training-new-generation-online-covert-operations\/",
      "display_url" : "firstlook.org\/theintercept\/d\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "438279191155736576",
  "geo" : { },
  "id_str" : "438285231549079553",
  "in_reply_to_user_id" : 2211139201,
  "text" : "@FORGE_LU @Mark_McGlashan insight to some professional trollers?--&gt;https:\/\/t.co\/EFdOSDy7P6",
  "id" : 438285231549079553,
  "in_reply_to_status_id" : 438279191155736576,
  "created_at" : "2014-02-25 12:11:56 +0000",
  "in_reply_to_screen_name" : "FORGE_LU",
  "in_reply_to_user_id_str" : "2211139201",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/EFdOSDy7P6",
      "expanded_url" : "https:\/\/firstlook.org\/theintercept\/document\/2014\/02\/24\/art-deception-training-new-generation-online-covert-operations\/",
      "display_url" : "firstlook.org\/theintercept\/d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438283765836943360",
  "text" : "The Art of Deception: Training for a New Generation of Online Covert Operations https:\/\/t.co\/EFdOSDy7P6",
  "id" : 438283765836943360,
  "created_at" : "2014-02-25 12:06:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Natallia Novikava",
      "screen_name" : "Natashetta",
      "indices" : [ 3, 14 ],
      "id_str" : "56308635",
      "id" : 56308635
    }, {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 97, 108 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 109, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/GT5bLxQB4p",
      "expanded_url" : "http:\/\/wp.me\/p4dmjk-8v",
      "display_url" : "wp.me\/p4dmjk-8v"
    } ]
  },
  "geo" : { },
  "id_str" : "438245183516606464",
  "text" : "RT @Natashetta: Are these communicative language teaching activities? http:\/\/t.co\/GT5bLxQB4p via @kevchanwow #elt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kevin Stein",
        "screen_name" : "kevchanwow",
        "indices" : [ 81, 92 ],
        "id_str" : "144663117",
        "id" : 144663117
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "elt",
        "indices" : [ 93, 97 ]
      } ],
      "urls" : [ {
        "indices" : [ 54, 76 ],
        "url" : "http:\/\/t.co\/GT5bLxQB4p",
        "expanded_url" : "http:\/\/wp.me\/p4dmjk-8v",
        "display_url" : "wp.me\/p4dmjk-8v"
      } ]
    },
    "geo" : { },
    "id_str" : "438237113281048576",
    "text" : "Are these communicative language teaching activities? http:\/\/t.co\/GT5bLxQB4p via @kevchanwow #elt",
    "id" : 438237113281048576,
    "created_at" : "2014-02-25 09:00:44 +0000",
    "user" : {
      "name" : "Natallia Novikava",
      "screen_name" : "Natashetta",
      "protected" : false,
      "id_str" : "56308635",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2877370292\/d6370dfafaa5506c53671f1bd1da0cdc_normal.jpeg",
      "id" : 56308635,
      "verified" : false
    }
  },
  "id" : 438245183516606464,
  "created_at" : "2014-02-25 09:32:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 11, 27 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438096951301906433",
  "text" : "@_FTaylor_ @michaelegriffin mike is so late in commenting, peeps have read those links, probably twice :)",
  "id" : 438096951301906433,
  "created_at" : "2014-02-24 23:43:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nagehan Tunar",
      "screen_name" : "stiiiv",
      "indices" : [ 0, 7 ],
      "id_str" : "799058600",
      "id" : 799058600
    }, {
      "name" : "Twournal Of ..",
      "screen_name" : "TwournalOf",
      "indices" : [ 8, 19 ],
      "id_str" : "2307422538",
      "id" : 2307422538
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "438045536273199104",
  "geo" : { },
  "id_str" : "438048008811581440",
  "in_reply_to_user_id" : 69068757,
  "text" : "@stiiiv @TwournalOf nice :)",
  "id" : 438048008811581440,
  "in_reply_to_status_id" : 438045536273199104,
  "created_at" : "2014-02-24 20:29:18 +0000",
  "in_reply_to_screen_name" : "stiivkirk",
  "in_reply_to_user_id_str" : "69068757",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ela Wassell",
      "screen_name" : "elawassell",
      "indices" : [ 3, 14 ],
      "id_str" : "51157050",
      "id" : 51157050
    }, {
      "name" : "Sandy Millin",
      "screen_name" : "sandymillin",
      "indices" : [ 20, 32 ],
      "id_str" : "144236944",
      "id" : 144236944
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "efl",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "elt",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/WLh0fTg5x7",
      "expanded_url" : "http:\/\/bit.ly\/1bGwBnl",
      "display_url" : "bit.ly\/1bGwBnl"
    } ]
  },
  "geo" : { },
  "id_str" : "438045101601062912",
  "text" : "RT @elawassell: via @sandymillin Sevastopol, right now: For those of you who have seen Sevastopol in the news over t... http:\/\/t.co\/WLh0fTg\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sandy Millin",
        "screen_name" : "sandymillin",
        "indices" : [ 4, 16 ],
        "id_str" : "144236944",
        "id" : 144236944
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "efl",
        "indices" : [ 127, 131 ]
      }, {
        "text" : "elt",
        "indices" : [ 132, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/WLh0fTg5x7",
        "expanded_url" : "http:\/\/bit.ly\/1bGwBnl",
        "display_url" : "bit.ly\/1bGwBnl"
      } ]
    },
    "geo" : { },
    "id_str" : "438043563369046016",
    "text" : "via @sandymillin Sevastopol, right now: For those of you who have seen Sevastopol in the news over t... http:\/\/t.co\/WLh0fTg5x7 #efl #elt",
    "id" : 438043563369046016,
    "created_at" : "2014-02-24 20:11:38 +0000",
    "user" : {
      "name" : "Ela Wassell",
      "screen_name" : "elawassell",
      "protected" : false,
      "id_str" : "51157050",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1879392732\/11elwas_normal.jpg",
      "id" : 51157050,
      "verified" : false
    }
  },
  "id" : 438045101601062912,
  "created_at" : "2014-02-24 20:17:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/aNDte5qtbh",
      "expanded_url" : "http:\/\/www.eurotrib.com\/story\/2014\/2\/22\/6947\/89782",
      "display_url" : "eurotrib.com\/story\/2014\/2\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438013555640524800",
  "text" : "Ukraine's Holodomor of 1933 and the Maidan Revolution http:\/\/t.co\/aNDte5qtbh",
  "id" : 438013555640524800,
  "created_at" : "2014-02-24 18:12:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angus B Grieve-Smith",
      "screen_name" : "grvsmth",
      "indices" : [ 3, 11 ],
      "id_str" : "22381639",
      "id" : 22381639
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/6zNyflqTdg",
      "expanded_url" : "http:\/\/grieve-smith.com\/blog\/2014\/02\/the-scotch-referendum\/",
      "display_url" : "grieve-smith.com\/blog\/2014\/02\/t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437990531722137601",
  "text" : "RT @grvsmth: New post: The Scotch Referendum - or lack thereof. What does it mean to say that a word \"is offensive\"? Who decides? http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/6zNyflqTdg",
        "expanded_url" : "http:\/\/grieve-smith.com\/blog\/2014\/02\/the-scotch-referendum\/",
        "display_url" : "grieve-smith.com\/blog\/2014\/02\/t\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "437716461008998400",
    "text" : "New post: The Scotch Referendum - or lack thereof. What does it mean to say that a word \"is offensive\"? Who decides? http:\/\/t.co\/6zNyflqTdg",
    "id" : 437716461008998400,
    "created_at" : "2014-02-23 22:31:51 +0000",
    "user" : {
      "name" : "Angus B Grieve-Smith",
      "screen_name" : "grvsmth",
      "protected" : false,
      "id_str" : "22381639",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/94827231\/portrait_normal.png",
      "id" : 22381639,
      "verified" : false
    }
  },
  "id" : 437990531722137601,
  "created_at" : "2014-02-24 16:40:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 3, 18 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eltchat",
      "indices" : [ 87, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/IJEcqCi5sq",
      "expanded_url" : "http:\/\/wp.me\/p3X7Ks-Gs",
      "display_url" : "wp.me\/p3X7Ks-Gs"
    } ]
  },
  "geo" : { },
  "id_str" : "437983145154322432",
  "text" : "RT @MrChrisJWilson: Teaching Unplugged vs The Teacher Unplugged http:\/\/t.co\/IJEcqCi5sq #eltchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "eltchat",
        "indices" : [ 67, 75 ]
      } ],
      "urls" : [ {
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/IJEcqCi5sq",
        "expanded_url" : "http:\/\/wp.me\/p3X7Ks-Gs",
        "display_url" : "wp.me\/p3X7Ks-Gs"
      } ]
    },
    "geo" : { },
    "id_str" : "437964812937478145",
    "text" : "Teaching Unplugged vs The Teacher Unplugged http:\/\/t.co\/IJEcqCi5sq #eltchat",
    "id" : 437964812937478145,
    "created_at" : "2014-02-24 14:58:43 +0000",
    "user" : {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "protected" : false,
      "id_str" : "20760283",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744952885595758592\/H4bmsUn3_normal.jpg",
      "id" : 20760283,
      "verified" : false
    }
  },
  "id" : 437983145154322432,
  "created_at" : "2014-02-24 16:11:33 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Betsy Lavolette",
      "screen_name" : "betsylavolette",
      "indices" : [ 3, 18 ],
      "id_str" : "16584276",
      "id" : 16584276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 126, 148 ],
      "url" : "http:\/\/t.co\/NhcpCQWnv0",
      "expanded_url" : "http:\/\/betsylavolette.com\/?p=1559",
      "display_url" : "betsylavolette.com\/?p=1559"
    } ]
  },
  "geo" : { },
  "id_str" : "437931753240813568",
  "text" : "RT @betsylavolette: 500th resource added to list of Web Tools for Language Learning &amp; Teaching! Pls use &amp; contribute! http:\/\/t.co\/NhcpCQWnv0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/NhcpCQWnv0",
        "expanded_url" : "http:\/\/betsylavolette.com\/?p=1559",
        "display_url" : "betsylavolette.com\/?p=1559"
      } ]
    },
    "geo" : { },
    "id_str" : "437931246065164289",
    "text" : "500th resource added to list of Web Tools for Language Learning &amp; Teaching! Pls use &amp; contribute! http:\/\/t.co\/NhcpCQWnv0",
    "id" : 437931246065164289,
    "created_at" : "2014-02-24 12:45:20 +0000",
    "user" : {
      "name" : "Betsy Lavolette",
      "screen_name" : "betsylavolette",
      "protected" : false,
      "id_str" : "16584276",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2622892118\/2dp0u9u9b3jzcdbakw0o_normal.jpeg",
      "id" : 16584276,
      "verified" : false
    }
  },
  "id" : 437931753240813568,
  "created_at" : "2014-02-24 12:47:21 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Claire Hardaker",
      "screen_name" : "DrClaireH",
      "indices" : [ 0, 10 ],
      "id_str" : "237842162",
      "id" : 237842162
    }, {
      "name" : "natiserhost197",
      "screen_name" : "esl_robert",
      "indices" : [ 11, 22 ],
      "id_str" : "2982357761",
      "id" : 2982357761
    }, {
      "name" : "Texas Tech",
      "screen_name" : "TexasTech",
      "indices" : [ 23, 33 ],
      "id_str" : "14125882",
      "id" : 14125882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "437867245155655680",
  "geo" : { },
  "id_str" : "437930282092474368",
  "in_reply_to_user_id" : 237842162,
  "text" : "@DrClaireH @esl_robert @TexasTech is it me or does writing \"special computer programs\" always sound a bit odd? :\/",
  "id" : 437930282092474368,
  "in_reply_to_status_id" : 437867245155655680,
  "created_at" : "2014-02-24 12:41:30 +0000",
  "in_reply_to_screen_name" : "DrClaireH",
  "in_reply_to_user_id_str" : "237842162",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 0, 9 ],
      "id_str" : "121063600",
      "id" : 121063600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "437922646575943680",
  "geo" : { },
  "id_str" : "437925377059479552",
  "in_reply_to_user_id" : 121063600,
  "text" : "@whyshona thanks for notifying, looks good though not got anything that may be suitable in time",
  "id" : 437925377059479552,
  "in_reply_to_status_id" : 437922646575943680,
  "created_at" : "2014-02-24 12:22:00 +0000",
  "in_reply_to_screen_name" : "whyshona",
  "in_reply_to_user_id_str" : "121063600",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 0, 9 ],
      "id_str" : "121063600",
      "id" : 121063600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "437922311803371520",
  "geo" : { },
  "id_str" : "437924064049364992",
  "in_reply_to_user_id" : 121063600,
  "text" : "@whyshona @leakygrammar yes though did not look at it closely before e.g. missing Watson which yours doesn't :)",
  "id" : 437924064049364992,
  "in_reply_to_status_id" : 437922311803371520,
  "created_at" : "2014-02-24 12:16:47 +0000",
  "in_reply_to_screen_name" : "whyshona",
  "in_reply_to_user_id_str" : "121063600",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shona Whyte",
      "screen_name" : "whyshona",
      "indices" : [ 75, 84 ],
      "id_str" : "121063600",
      "id" : 121063600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/fcA9rTSXbc",
      "expanded_url" : "http:\/\/unt.unice.fr\/uoh\/learn_teach_FL\/index.php?lang=eng&connexion=",
      "display_url" : "unt.unice.fr\/uoh\/learn_teac\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437921631751516160",
  "text" : "nice online resource to explore learning theories and language learning by @whyshona http:\/\/t.co\/fcA9rTSXbc",
  "id" : 437921631751516160,
  "created_at" : "2014-02-24 12:07:07 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evgeny Morozov",
      "screen_name" : "evgenymorozov",
      "indices" : [ 3, 17 ],
      "id_str" : "30331417",
      "id" : 30331417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/LR3h0GM6vY",
      "expanded_url" : "http:\/\/www.newrepublic.com\/article\/116618\/technologys-mindfulness-racket",
      "display_url" : "newrepublic.com\/article\/116618\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "437907792540995584",
  "text" : "RT @evgenymorozov: \"The Mindfulness Racket\" --&gt; my latest column  http:\/\/t.co\/LR3h0GM6vY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 72 ],
        "url" : "http:\/\/t.co\/LR3h0GM6vY",
        "expanded_url" : "http:\/\/www.newrepublic.com\/article\/116618\/technologys-mindfulness-racket",
        "display_url" : "newrepublic.com\/article\/116618\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "437827982527582209",
    "text" : "\"The Mindfulness Racket\" --&gt; my latest column  http:\/\/t.co\/LR3h0GM6vY",
    "id" : 437827982527582209,
    "created_at" : "2014-02-24 05:55:00 +0000",
    "user" : {
      "name" : "Evgeny Morozov",
      "screen_name" : "evgenymorozov",
      "protected" : false,
      "id_str" : "30331417",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/640536915477794816\/u9TxNsKI_normal.jpg",
      "id" : 30331417,
      "verified" : false
    }
  },
  "id" : 437907792540995584,
  "created_at" : "2014-02-24 11:12:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Parise",
      "screen_name" : "peterrenshu",
      "indices" : [ 0, 12 ],
      "id_str" : "631949549",
      "id" : 631949549
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "437778212999798784",
  "geo" : { },
  "id_str" : "437898007023853569",
  "in_reply_to_user_id" : 631949549,
  "text" : "@peterrenshu hi peter be great if you could post a higher res picture of your poster? possibly to G+ community as well? thanks",
  "id" : 437898007023853569,
  "in_reply_to_status_id" : 437778212999798784,
  "created_at" : "2014-02-24 10:33:15 +0000",
  "in_reply_to_screen_name" : "peterrenshu",
  "in_reply_to_user_id_str" : "631949549",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vagrant Seeker",
      "screen_name" : "VagrantSeeker",
      "indices" : [ 3, 17 ],
      "id_str" : "2943725492",
      "id" : 2943725492
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TEC14",
      "indices" : [ 99, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/G1aPsK6Ay8",
      "expanded_url" : "http:\/\/wp.me\/p3PBC0-V",
      "display_url" : "wp.me\/p3PBC0-V"
    } ]
  },
  "geo" : { },
  "id_str" : "437745872273936384",
  "text" : "RT @vagrantseeker: When Terribly Tiny Tales are so popular, I try to share my experiences from the #TEC14 in under three thousand words htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TEC14",
        "indices" : [ 80, 86 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/G1aPsK6Ay8",
        "expanded_url" : "http:\/\/wp.me\/p3PBC0-V",
        "display_url" : "wp.me\/p3PBC0-V"
      } ]
    },
    "geo" : { },
    "id_str" : "437667114342551552",
    "text" : "When Terribly Tiny Tales are so popular, I try to share my experiences from the #TEC14 in under three thousand words http:\/\/t.co\/G1aPsK6Ay8",
    "id" : 437667114342551552,
    "created_at" : "2014-02-23 19:15:46 +0000",
    "user" : {
      "name" : "Alpana",
      "screen_name" : "AdvisorGeneral",
      "protected" : false,
      "id_str" : "17082886",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/735839867913965569\/bGWXh-Ii_normal.jpg",
      "id" : 17082886,
      "verified" : false
    }
  },
  "id" : 437745872273936384,
  "created_at" : "2014-02-24 00:28:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristopher Boulton",
      "screen_name" : "Kris_Boulton",
      "indices" : [ 45, 58 ],
      "id_str" : "174736204",
      "id" : 174736204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/uTFeS8leti",
      "expanded_url" : "http:\/\/wp.me\/p3sTtE-4t",
      "display_url" : "wp.me\/p3sTtE-4t"
    } ]
  },
  "geo" : { },
  "id_str" : "437642891066761218",
  "text" : "What is teaching? http:\/\/t.co\/uTFeS8leti via @Kris_Boulton",
  "id" : 437642891066761218,
  "created_at" : "2014-02-23 17:39:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary Carr",
      "screen_name" : "marymcarr1",
      "indices" : [ 3, 14 ],
      "id_str" : "213701768",
      "id" : 213701768
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusMOOC",
      "indices" : [ 60, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/4obe5jrXhb",
      "expanded_url" : "http:\/\/appliedlinguisticsandtesol.blogspot.co.uk\/",
      "display_url" : "\u2026iedlinguisticsandtesol.blogspot.co.uk"
    } ]
  },
  "geo" : { },
  "id_str" : "437347837282906112",
  "text" : "RT @marymcarr1: http:\/\/t.co\/4obe5jrXhb  Corpus MOOC Week 1! #corpusMOOC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpusMOOC",
        "indices" : [ 44, 55 ]
      } ],
      "urls" : [ {
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/4obe5jrXhb",
        "expanded_url" : "http:\/\/appliedlinguisticsandtesol.blogspot.co.uk\/",
        "display_url" : "\u2026iedlinguisticsandtesol.blogspot.co.uk"
      } ]
    },
    "geo" : { },
    "id_str" : "437188978123759616",
    "text" : "http:\/\/t.co\/4obe5jrXhb  Corpus MOOC Week 1! #corpusMOOC",
    "id" : 437188978123759616,
    "created_at" : "2014-02-22 11:35:49 +0000",
    "user" : {
      "name" : "Mary Carr",
      "screen_name" : "marymcarr1",
      "protected" : false,
      "id_str" : "213701768",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/438436171941568512\/zq7raNH5_normal.jpeg",
      "id" : 213701768,
      "verified" : false
    }
  },
  "id" : 437347837282906112,
  "created_at" : "2014-02-22 22:07:04 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil Longwell",
      "screen_name" : "teacherphili",
      "indices" : [ 3, 16 ],
      "id_str" : "67863264",
      "id" : 67863264
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/cfnoLdameD",
      "expanded_url" : "http:\/\/www.iatefl.org\/webinars",
      "display_url" : "iatefl.org\/webinars"
    } ]
  },
  "geo" : { },
  "id_str" : "437214661898166272",
  "text" : "RT @teacherphili: Next IATEFL webinar is today with Michael McCarthy's 'Spoken fluency revisited' - \nhttp:\/\/t.co\/cfnoLdameD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/cfnoLdameD",
        "expanded_url" : "http:\/\/www.iatefl.org\/webinars",
        "display_url" : "iatefl.org\/webinars"
      } ]
    },
    "geo" : { },
    "id_str" : "437207314870075392",
    "text" : "Next IATEFL webinar is today with Michael McCarthy's 'Spoken fluency revisited' - \nhttp:\/\/t.co\/cfnoLdameD",
    "id" : 437207314870075392,
    "created_at" : "2014-02-22 12:48:41 +0000",
    "user" : {
      "name" : "Phil Longwell",
      "screen_name" : "teacherphili",
      "protected" : false,
      "id_str" : "67863264",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637201716295933952\/4n4DCm-q_normal.jpg",
      "id" : 67863264,
      "verified" : false
    }
  },
  "id" : 437214661898166272,
  "created_at" : "2014-02-22 13:17:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Scott",
      "screen_name" : "teachAdam",
      "indices" : [ 3, 13 ],
      "id_str" : "284617563",
      "id" : 284617563
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TEC14",
      "indices" : [ 27, 33 ]
    }, {
      "text" : "corpus",
      "indices" : [ 63, 70 ]
    }, {
      "text" : "lexicalapproach",
      "indices" : [ 87, 103 ]
    }, {
      "text" : "beginners",
      "indices" : [ 117, 127 ]
    }, {
      "text" : "ELT",
      "indices" : [ 128, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/GYel2Qg3X8",
      "expanded_url" : "http:\/\/goo.gl\/UcClUr",
      "display_url" : "goo.gl\/UcClUr"
    } ]
  },
  "geo" : { },
  "id_str" : "437189687963574272",
  "text" : "RT @teachAdam: Download my #TEC14 presentation slides on using #corpus linguistics and #lexicalapproach for teaching #beginners #ELT http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TEC14",
        "indices" : [ 12, 18 ]
      }, {
        "text" : "corpus",
        "indices" : [ 48, 55 ]
      }, {
        "text" : "lexicalapproach",
        "indices" : [ 72, 88 ]
      }, {
        "text" : "beginners",
        "indices" : [ 102, 112 ]
      }, {
        "text" : "ELT",
        "indices" : [ 113, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/GYel2Qg3X8",
        "expanded_url" : "http:\/\/goo.gl\/UcClUr",
        "display_url" : "goo.gl\/UcClUr"
      } ]
    },
    "geo" : { },
    "id_str" : "437176133856292865",
    "text" : "Download my #TEC14 presentation slides on using #corpus linguistics and #lexicalapproach for teaching #beginners #ELT http:\/\/t.co\/GYel2Qg3X8",
    "id" : 437176133856292865,
    "created_at" : "2014-02-22 10:44:47 +0000",
    "user" : {
      "name" : "Adam Scott",
      "screen_name" : "teachAdam",
      "protected" : false,
      "id_str" : "284617563",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/435763086642151424\/fMaWgo24_normal.jpeg",
      "id" : 284617563,
      "verified" : false
    }
  },
  "id" : 437189687963574272,
  "created_at" : "2014-02-22 11:38:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anna Loseva",
      "screen_name" : "AnnLoseva",
      "indices" : [ 3, 13 ],
      "id_str" : "38822368",
      "id" : 38822368
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/9lZ9lUxNre",
      "expanded_url" : "http:\/\/wp.me\/p1wlqw-bIVGM",
      "display_url" : "wp.me\/p1wlqw-bIVGM"
    } ]
  },
  "geo" : { },
  "id_str" : "436990365279993856",
  "text" : "RT @AnnLoseva: On Capote and motivation in broken\u00A0logic. http:\/\/t.co\/9lZ9lUxNre",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/9lZ9lUxNre",
        "expanded_url" : "http:\/\/wp.me\/p1wlqw-bIVGM",
        "display_url" : "wp.me\/p1wlqw-bIVGM"
      } ]
    },
    "geo" : { },
    "id_str" : "436985165911322624",
    "text" : "On Capote and motivation in broken\u00A0logic. http:\/\/t.co\/9lZ9lUxNre",
    "id" : 436985165911322624,
    "created_at" : "2014-02-21 22:05:57 +0000",
    "user" : {
      "name" : "Anna Loseva",
      "screen_name" : "AnnLoseva",
      "protected" : false,
      "id_str" : "38822368",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/767034457748541441\/VJrp4Jie_normal.jpg",
      "id" : 38822368,
      "verified" : false
    }
  },
  "id" : 436990365279993856,
  "created_at" : "2014-02-21 22:26:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vagrant Seeker",
      "screen_name" : "VagrantSeeker",
      "indices" : [ 3, 17 ],
      "id_str" : "2943725492",
      "id" : 2943725492
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TEC14",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/6SmkZ0yUOn",
      "expanded_url" : "http:\/\/educationdiaries.wordpress.com\/2014\/02\/22\/tec-2014-day1\/",
      "display_url" : "educationdiaries.wordpress.com\/2014\/02\/22\/tec\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436950908212371456",
  "text" : "RT @vagrantseeker: My insights from today's experience at Teacher Educator Conference, Hyderabad, now up on my ed blog: http:\/\/t.co\/6SmkZ0y\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TEC14",
        "indices" : [ 124, 130 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/6SmkZ0yUOn",
        "expanded_url" : "http:\/\/educationdiaries.wordpress.com\/2014\/02\/22\/tec-2014-day1\/",
        "display_url" : "educationdiaries.wordpress.com\/2014\/02\/22\/tec\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "436949500326723585",
    "text" : "My insights from today's experience at Teacher Educator Conference, Hyderabad, now up on my ed blog: http:\/\/t.co\/6SmkZ0yUOn #TEC14",
    "id" : 436949500326723585,
    "created_at" : "2014-02-21 19:44:13 +0000",
    "user" : {
      "name" : "Alpana",
      "screen_name" : "AdvisorGeneral",
      "protected" : false,
      "id_str" : "17082886",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/735839867913965569\/bGWXh-Ii_normal.jpg",
      "id" : 17082886,
      "verified" : false
    }
  },
  "id" : 436950908212371456,
  "created_at" : "2014-02-21 19:49:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/Es49fUcZbZ",
      "expanded_url" : "http:\/\/tinyurl.com\/oz7c5km",
      "display_url" : "tinyurl.com\/oz7c5km"
    } ]
  },
  "geo" : { },
  "id_str" : "436870226899386368",
  "text" : "RT @medialens: Mark Weisbrot, 7 mins interview - US is seeking regime change in Venezuela http:\/\/t.co\/Es49fUcZbZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/Es49fUcZbZ",
        "expanded_url" : "http:\/\/tinyurl.com\/oz7c5km",
        "display_url" : "tinyurl.com\/oz7c5km"
      } ]
    },
    "geo" : { },
    "id_str" : "436826232937013248",
    "text" : "Mark Weisbrot, 7 mins interview - US is seeking regime change in Venezuela http:\/\/t.co\/Es49fUcZbZ",
    "id" : 436826232937013248,
    "created_at" : "2014-02-21 11:34:24 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 436870226899386368,
  "created_at" : "2014-02-21 14:29:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 39, 55 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/cQWHpFC1V4",
      "expanded_url" : "http:\/\/wp.me\/pBWu-1xP",
      "display_url" : "wp.me\/pBWu-1xP"
    } ]
  },
  "geo" : { },
  "id_str" : "436806257375080448",
  "text" : "Sara Squint http:\/\/t.co\/cQWHpFC1V4 via @wordpressdotcom",
  "id" : 436806257375080448,
  "created_at" : "2014-02-21 10:15:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ellensclass",
      "screen_name" : "ellensclass",
      "indices" : [ 3, 15 ],
      "id_str" : "451058137",
      "id" : 451058137
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/SPj6WgUjZK",
      "expanded_url" : "http:\/\/wp.me\/p3JZOw-gF",
      "display_url" : "wp.me\/p3JZOw-gF"
    } ]
  },
  "geo" : { },
  "id_str" : "436665233516806144",
  "text" : "RT @ellensclass: Fun with movie\u00A0titles http:\/\/t.co\/SPj6WgUjZK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 22, 44 ],
        "url" : "http:\/\/t.co\/SPj6WgUjZK",
        "expanded_url" : "http:\/\/wp.me\/p3JZOw-gF",
        "display_url" : "wp.me\/p3JZOw-gF"
      } ]
    },
    "geo" : { },
    "id_str" : "436646487909363712",
    "text" : "Fun with movie\u00A0titles http:\/\/t.co\/SPj6WgUjZK",
    "id" : 436646487909363712,
    "created_at" : "2014-02-20 23:40:09 +0000",
    "user" : {
      "name" : "ellensclass",
      "screen_name" : "ellensclass",
      "protected" : false,
      "id_str" : "451058137",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1724689649\/NYThatWay_normal.jpg",
      "id" : 451058137,
      "verified" : false
    }
  },
  "id" : 436665233516806144,
  "created_at" : "2014-02-21 00:54:39 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oddbabydreams",
      "indices" : [ 99, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "436652247376998400",
  "text" : "knew my son is obsessed with 'ballons' during the day, he just cried out the word during his sleep #oddbabydreams",
  "id" : 436652247376998400,
  "created_at" : "2014-02-21 00:03:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    }, {
      "name" : "Glenn Greenwald",
      "screen_name" : "ggreenwald",
      "indices" : [ 115, 126 ],
      "id_str" : "16076032",
      "id" : 16076032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/IVbftstqrH",
      "expanded_url" : "http:\/\/johnhilley.blogspot.co.uk\/2014\/02\/spooks-and-feudalism-greenwald-savages.html",
      "display_url" : "johnhilley.blogspot.co.uk\/2014\/02\/spooks\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436639853695205376",
  "text" : "RT @johnwhilley: Spooks and feudalism: Greenwald savages Britain's secretive, archaic state http:\/\/t.co\/IVbftstqrH @ggreenwald",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Glenn Greenwald",
        "screen_name" : "ggreenwald",
        "indices" : [ 98, 109 ],
        "id_str" : "16076032",
        "id" : 16076032
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/IVbftstqrH",
        "expanded_url" : "http:\/\/johnhilley.blogspot.co.uk\/2014\/02\/spooks-and-feudalism-greenwald-savages.html",
        "display_url" : "johnhilley.blogspot.co.uk\/2014\/02\/spooks\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "436294099134840832",
    "text" : "Spooks and feudalism: Greenwald savages Britain's secretive, archaic state http:\/\/t.co\/IVbftstqrH @ggreenwald",
    "id" : 436294099134840832,
    "created_at" : "2014-02-20 00:19:53 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 436639853695205376,
  "created_at" : "2014-02-20 23:13:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Idibon",
      "screen_name" : "idibon",
      "indices" : [ 3, 10 ],
      "id_str" : "749992082",
      "id" : 749992082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/5416rxE98t",
      "expanded_url" : "http:\/\/ow.ly\/tNVbb",
      "display_url" : "ow.ly\/tNVbb"
    } ]
  },
  "geo" : { },
  "id_str" : "436635414825545728",
  "text" : "RT @idibon: English isn't the only language of the heart | Idibon http:\/\/t.co\/5416rxE98t",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 76 ],
        "url" : "http:\/\/t.co\/5416rxE98t",
        "expanded_url" : "http:\/\/ow.ly\/tNVbb",
        "display_url" : "ow.ly\/tNVbb"
      } ]
    },
    "geo" : { },
    "id_str" : "436572350755389441",
    "text" : "English isn't the only language of the heart | Idibon http:\/\/t.co\/5416rxE98t",
    "id" : 436572350755389441,
    "created_at" : "2014-02-20 18:45:34 +0000",
    "user" : {
      "name" : "Idibon",
      "screen_name" : "idibon",
      "protected" : false,
      "id_str" : "749992082",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/577899744749481985\/ospcUqfV_normal.jpeg",
      "id" : 749992082,
      "verified" : false
    }
  },
  "id" : 436635414825545728,
  "created_at" : "2014-02-20 22:56:09 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Wright",
      "screen_name" : "WrightDW",
      "indices" : [ 3, 12 ],
      "id_str" : "21451640",
      "id" : 21451640
    }, {
      "name" : "Babel",
      "screen_name" : "Babelzine",
      "indices" : [ 70, 80 ],
      "id_str" : "927973879",
      "id" : 927973879
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/cQ8W0DE58d",
      "expanded_url" : "http:\/\/www.bbc.co.uk\/programmes\/p01slnp5",
      "display_url" : "bbc.co.uk\/programmes\/p01\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436634434276958208",
  "text" : "RT @WrightDW: BBC Radio 4: A tour of the British Isles in accents (HT @Babelzine)\nhttp:\/\/t.co\/cQ8W0DE58d",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Babel",
        "screen_name" : "Babelzine",
        "indices" : [ 56, 66 ],
        "id_str" : "927973879",
        "id" : 927973879
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/cQ8W0DE58d",
        "expanded_url" : "http:\/\/www.bbc.co.uk\/programmes\/p01slnp5",
        "display_url" : "bbc.co.uk\/programmes\/p01\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "436578710968619008",
    "text" : "BBC Radio 4: A tour of the British Isles in accents (HT @Babelzine)\nhttp:\/\/t.co\/cQ8W0DE58d",
    "id" : 436578710968619008,
    "created_at" : "2014-02-20 19:10:50 +0000",
    "user" : {
      "name" : "David Wright",
      "screen_name" : "WrightDW",
      "protected" : false,
      "id_str" : "21451640",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/640879905828413441\/nAGX4y8Z_normal.jpg",
      "id" : 21451640,
      "verified" : false
    }
  },
  "id" : 436634434276958208,
  "created_at" : "2014-02-20 22:52:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Graham",
      "screen_name" : "onalifeglug",
      "indices" : [ 0, 12 ],
      "id_str" : "19516039",
      "id" : 19516039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "436606845411938307",
  "geo" : { },
  "id_str" : "436608803828957184",
  "in_reply_to_user_id" : 19516039,
  "text" : "@onalifeglug i think i may get on with your dad :)",
  "id" : 436608803828957184,
  "in_reply_to_status_id" : 436606845411938307,
  "created_at" : "2014-02-20 21:10:25 +0000",
  "in_reply_to_screen_name" : "onalifeglug",
  "in_reply_to_user_id_str" : "19516039",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Scott",
      "screen_name" : "teachAdam",
      "indices" : [ 0, 10 ],
      "id_str" : "284617563",
      "id" : 284617563
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "435761595814543360",
  "geo" : { },
  "id_str" : "436600382874456064",
  "in_reply_to_user_id" : 284617563,
  "text" : "@teachAdam hi will u be posting slides\/handouts somewhere?",
  "id" : 436600382874456064,
  "in_reply_to_status_id" : 435761595814543360,
  "created_at" : "2014-02-20 20:36:57 +0000",
  "in_reply_to_screen_name" : "teachAdam",
  "in_reply_to_user_id_str" : "284617563",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Borg",
      "screen_name" : "Simon_Borg",
      "indices" : [ 0, 11 ],
      "id_str" : "94652779",
      "id" : 94652779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "436589966756298752",
  "geo" : { },
  "id_str" : "436599289285201920",
  "in_reply_to_user_id" : 94652779,
  "text" : "@Simon_Borg \/offtopic\/ but curious u using blog for blog post or for blog site?",
  "id" : 436599289285201920,
  "in_reply_to_status_id" : 436589966756298752,
  "created_at" : "2014-02-20 20:32:36 +0000",
  "in_reply_to_screen_name" : "Simon_Borg",
  "in_reply_to_user_id_str" : "94652779",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 12, 23 ]
    }, {
      "text" : "antconc",
      "indices" : [ 37, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/S45bCBcmCd",
      "expanded_url" : "https:\/\/plus.google.com\/104940199413423400545\/posts\/UeANcr79eVr",
      "display_url" : "plus.google.com\/10494019941342\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436597083647512578",
  "text" : "top tip for #corpusmooc peeps to get #antconc friendly wordlists https:\/\/t.co\/S45bCBcmCd",
  "id" : 436597083647512578,
  "created_at" : "2014-02-20 20:23:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 3, 15 ],
      "id_str" : "525013404",
      "id" : 525013404
    }, {
      "name" : "Hana Tich\u00E1",
      "screen_name" : "HanaTicha",
      "indices" : [ 92, 102 ],
      "id_str" : "512296705",
      "id" : 512296705
    }, {
      "name" : "Gemma Lunn",
      "screen_name" : "GemL1",
      "indices" : [ 139, 140 ],
      "id_str" : "486146568",
      "id" : 486146568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/Yb3ipc4tKZ",
      "expanded_url" : "http:\/\/how-i-see-it-now.blogspot.com\/2014\/02\/observing-class-in-retrospect.html?spref=tw",
      "display_url" : "how-i-see-it-now.blogspot.com\/2014\/02\/observ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436547516797313024",
  "text" : "RT @AnneHendler: How I see it now: Observing class in retrospect http:\/\/t.co\/Yb3ipc4tKZ via @hanaticha Interesting video observation and in\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hana Tich\u00E1",
        "screen_name" : "HanaTicha",
        "indices" : [ 75, 85 ],
        "id_str" : "512296705",
        "id" : 512296705
      }, {
        "name" : "Gemma Lunn",
        "screen_name" : "GemL1",
        "indices" : [ 133, 139 ],
        "id_str" : "486146568",
        "id" : 486146568
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 70 ],
        "url" : "http:\/\/t.co\/Yb3ipc4tKZ",
        "expanded_url" : "http:\/\/how-i-see-it-now.blogspot.com\/2014\/02\/observing-class-in-retrospect.html?spref=tw",
        "display_url" : "how-i-see-it-now.blogspot.com\/2014\/02\/observ\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "436542370155229184",
    "text" : "How I see it now: Observing class in retrospect http:\/\/t.co\/Yb3ipc4tKZ via @hanaticha Interesting video observation and insight. cc: @geml1",
    "id" : 436542370155229184,
    "created_at" : "2014-02-20 16:46:26 +0000",
    "user" : {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "protected" : false,
      "id_str" : "525013404",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766910187911405568\/zw3Ez5M0_normal.jpg",
      "id" : 525013404,
      "verified" : false
    }
  },
  "id" : 436547516797313024,
  "created_at" : "2014-02-20 17:06:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 3, 15 ],
      "id_str" : "525013404",
      "id" : 525013404
    }, {
      "name" : "ETpro",
      "screen_name" : "ETprofessional",
      "indices" : [ 122, 137 ],
      "id_str" : "501629829",
      "id" : 501629829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/6ZqDmkBlqU",
      "expanded_url" : "https:\/\/www.etprofessional.com\/the_misuse_of_silence_25769807690.aspx",
      "display_url" : "etprofessional.com\/the_misuse_of_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436547467883347969",
  "text" : "RT @AnneHendler: the misuse of silence : https:\/\/t.co\/6ZqDmkBlqU \"silence is so easy to misread\" another perspective. via @etprofessional",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ETpro",
        "screen_name" : "ETprofessional",
        "indices" : [ 105, 120 ],
        "id_str" : "501629829",
        "id" : 501629829
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 24, 47 ],
        "url" : "https:\/\/t.co\/6ZqDmkBlqU",
        "expanded_url" : "https:\/\/www.etprofessional.com\/the_misuse_of_silence_25769807690.aspx",
        "display_url" : "etprofessional.com\/the_misuse_of_\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "436546310380863488",
    "text" : "the misuse of silence : https:\/\/t.co\/6ZqDmkBlqU \"silence is so easy to misread\" another perspective. via @etprofessional",
    "id" : 436546310380863488,
    "created_at" : "2014-02-20 17:02:05 +0000",
    "user" : {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "protected" : false,
      "id_str" : "525013404",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766910187911405568\/zw3Ez5M0_normal.jpg",
      "id" : 525013404,
      "verified" : false
    }
  },
  "id" : 436547467883347969,
  "created_at" : "2014-02-20 17:06:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tricycle Magazine",
      "screen_name" : "tricyclemag",
      "indices" : [ 110, 122 ],
      "id_str" : "19619541",
      "id" : 19619541
    }, {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 127, 137 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/iStvs30m5T",
      "expanded_url" : "http:\/\/www.tinyurl.com\/mku5oy6",
      "display_url" : "tinyurl.com\/mku5oy6"
    } ]
  },
  "geo" : { },
  "id_str" : "436546593420877824",
  "text" : "Protesters crash Google talk on corporate mindfulness at Wisdom 2.0 conference  -  http:\/\/t.co\/iStvs30m5T via @tricyclemag h\/t @medialens",
  "id" : 436546593420877824,
  "created_at" : "2014-02-20 17:03:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TEC14",
      "indices" : [ 0, 6 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "436531734717665280",
  "text" : "#TEC14 anyone going to the two corpus talks? if so do report\/blog\/tweet it :)",
  "id" : 436531734717665280,
  "created_at" : "2014-02-20 16:04:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ann Priestley",
      "screen_name" : "annindk",
      "indices" : [ 0, 8 ],
      "id_str" : "127530996",
      "id" : 127530996
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "436495742518448128",
  "geo" : { },
  "id_str" : "436510911097208832",
  "in_reply_to_user_id" : 127530996,
  "text" : "@annindk ah right, be good to have a way to upload to a shared space?",
  "id" : 436510911097208832,
  "in_reply_to_status_id" : 436495742518448128,
  "created_at" : "2014-02-20 14:41:25 +0000",
  "in_reply_to_screen_name" : "annindk",
  "in_reply_to_user_id_str" : "127530996",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "indices" : [ 3, 12 ],
      "id_str" : "167020390",
      "id" : 167020390
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusMOOC",
      "indices" : [ 14, 25 ]
    }, {
      "text" : "AntConc",
      "indices" : [ 26, 34 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/VoXQEtTbBl",
      "expanded_url" : "http:\/\/www.antlab.sci.waseda.ac.jp\/software.html",
      "display_url" : "antlab.sci.waseda.ac.jp\/software.html"
    } ]
  },
  "geo" : { },
  "id_str" : "436474097271603201",
  "text" : "RT @antlabjp: #corpusMOOC #AntConc AntFileConverter: A new PDF to text converter. Get it here (only for Windows at the moment): http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpusMOOC",
        "indices" : [ 0, 11 ]
      }, {
        "text" : "AntConc",
        "indices" : [ 12, 20 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/VoXQEtTbBl",
        "expanded_url" : "http:\/\/www.antlab.sci.waseda.ac.jp\/software.html",
        "display_url" : "antlab.sci.waseda.ac.jp\/software.html"
      } ]
    },
    "geo" : { },
    "id_str" : "436437407563403264",
    "text" : "#corpusMOOC #AntConc AntFileConverter: A new PDF to text converter. Get it here (only for Windows at the moment): http:\/\/t.co\/VoXQEtTbBl",
    "id" : 436437407563403264,
    "created_at" : "2014-02-20 09:49:21 +0000",
    "user" : {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "protected" : false,
      "id_str" : "167020390",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/428183580821315584\/ocgCI7Er_normal.jpeg",
      "id" : 167020390,
      "verified" : false
    }
  },
  "id" : 436474097271603201,
  "created_at" : "2014-02-20 12:15:08 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bethany Nowviskie",
      "screen_name" : "nowviskie",
      "indices" : [ 3, 13 ],
      "id_str" : "14221013",
      "id" : 14221013
    }, {
      "name" : "Quinn Norton",
      "screen_name" : "quinnnorton",
      "indices" : [ 123, 135 ],
      "id_str" : "38975663",
      "id" : 38975663
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 143, 144 ],
      "url" : "https:\/\/t.co\/bXqCQ5uYf3",
      "expanded_url" : "https:\/\/medium.com\/p\/96f86c76b9d6",
      "display_url" : "medium.com\/p\/96f86c76b9d6"
    } ]
  },
  "geo" : { },
  "id_str" : "436238174923550721",
  "text" : "RT @nowviskie: \u201CThe net doesn't understand that people change, &amp; doesn't tolerate it\u2014all growth is seen as hypocrisy.\u201D\u2014@quinnnorton https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Quinn Norton",
        "screen_name" : "quinnnorton",
        "indices" : [ 108, 120 ],
        "id_str" : "38975663",
        "id" : 38975663
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/bXqCQ5uYf3",
        "expanded_url" : "https:\/\/medium.com\/p\/96f86c76b9d6",
        "display_url" : "medium.com\/p\/96f86c76b9d6"
      } ]
    },
    "geo" : { },
    "id_str" : "436221031549005824",
    "text" : "\u201CThe net doesn't understand that people change, &amp; doesn't tolerate it\u2014all growth is seen as hypocrisy.\u201D\u2014@quinnnorton https:\/\/t.co\/bXqCQ5uYf3",
    "id" : 436221031549005824,
    "created_at" : "2014-02-19 19:29:33 +0000",
    "user" : {
      "name" : "Bethany Nowviskie",
      "screen_name" : "nowviskie",
      "protected" : false,
      "id_str" : "14221013",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751794036365594625\/xIEFm3Jp_normal.jpg",
      "id" : 14221013,
      "verified" : false
    }
  },
  "id" : 436238174923550721,
  "created_at" : "2014-02-19 20:37:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LADER ZUMSTEIN",
      "screen_name" : "eljbrown",
      "indices" : [ 3, 12 ],
      "id_str" : "4171300157",
      "id" : 4171300157
    }, {
      "name" : "Alice Bell",
      "screen_name" : "alicebell",
      "indices" : [ 132, 140 ],
      "id_str" : "19178857",
      "id" : 19178857
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/dMlybUsFye",
      "expanded_url" : "http:\/\/london-student.net\/news\/02\/17\/arms-money-pumped-london-universities-research\/",
      "display_url" : "london-student.net\/news\/02\/17\/arm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436209225816367104",
  "text" : "RT @eljbrown: Arms money pumped into London universities\u2019 research (that's Imperial, UCL and Queen Mary) http:\/\/t.co\/dMlybUsFye via @aliceb\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Alice Bell",
        "screen_name" : "alicebell",
        "indices" : [ 118, 128 ],
        "id_str" : "19178857",
        "id" : 19178857
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/dMlybUsFye",
        "expanded_url" : "http:\/\/london-student.net\/news\/02\/17\/arms-money-pumped-london-universities-research\/",
        "display_url" : "london-student.net\/news\/02\/17\/arm\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "436204823076413440",
    "text" : "Arms money pumped into London universities\u2019 research (that's Imperial, UCL and Queen Mary) http:\/\/t.co\/dMlybUsFye via @alicebell",
    "id" : 436204823076413440,
    "created_at" : "2014-02-19 18:25:08 +0000",
    "user" : {
      "name" : "death nell",
      "screen_name" : "nelleficent",
      "protected" : false,
      "id_str" : "170201962",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/640293189480525826\/DddyMoCd_normal.jpg",
      "id" : 170201962,
      "verified" : false
    }
  },
  "id" : 436209225816367104,
  "created_at" : "2014-02-19 18:42:38 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Mearns",
      "screen_name" : "davidmearns",
      "indices" : [ 3, 15 ],
      "id_str" : "30931681",
      "id" : 30931681
    }, {
      "name" : "Hydro Del Rey\u3123\u20D2",
      "screen_name" : "adopt",
      "indices" : [ 46, 52 ],
      "id_str" : "726428043955298304",
      "id" : 726428043955298304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 140 ],
      "url" : "http:\/\/t.co\/5kdWy2VQ5q",
      "expanded_url" : "http:\/\/flip.it\/JPwJy",
      "display_url" : "flip.it\/JPwJy"
    } ]
  },
  "geo" : { },
  "id_str" : "436208063817998338",
  "text" : "RT @davidmearns: DAVID MEARNS latest edu-post @Adopt and Adapt ICT- ELT: OSCARS 2014 - THINKING ABOUT A THESIS STATEMENT http:\/\/t.co\/5kdWy2\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.flipboard.com\" rel=\"nofollow\"\u003EFlipboard\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hydro Del Rey\u3123\u20D2",
        "screen_name" : "adopt",
        "indices" : [ 29, 35 ],
        "id_str" : "726428043955298304",
        "id" : 726428043955298304
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/5kdWy2VQ5q",
        "expanded_url" : "http:\/\/flip.it\/JPwJy",
        "display_url" : "flip.it\/JPwJy"
      } ]
    },
    "geo" : { },
    "id_str" : "436197157436403712",
    "text" : "DAVID MEARNS latest edu-post @Adopt and Adapt ICT- ELT: OSCARS 2014 - THINKING ABOUT A THESIS STATEMENT http:\/\/t.co\/5kdWy2VQ5q",
    "id" : 436197157436403712,
    "created_at" : "2014-02-19 17:54:41 +0000",
    "user" : {
      "name" : "David Mearns",
      "screen_name" : "davidmearns",
      "protected" : true,
      "id_str" : "30931681",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703310502659751936\/MF_hJF-m_normal.jpg",
      "id" : 30931681,
      "verified" : false
    }
  },
  "id" : 436208063817998338,
  "created_at" : "2014-02-19 18:38:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ann Priestley",
      "screen_name" : "annindk",
      "indices" : [ 0, 8 ],
      "id_str" : "127530996",
      "id" : 127530996
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/LkwJV8uu5b",
      "expanded_url" : "https:\/\/plus.google.com\/104940199413423400545\/posts\/bf4QgRU7Brr",
      "display_url" : "plus.google.com\/10494019941342\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "435779784665481216",
  "geo" : { },
  "id_str" : "436189838811746305",
  "in_reply_to_user_id" : 127530996,
  "text" : "@annindk hi been collecting blog posts here https:\/\/t.co\/LkwJV8uu5b; also how to add to your dropbox?",
  "id" : 436189838811746305,
  "in_reply_to_status_id" : 435779784665481216,
  "created_at" : "2014-02-19 17:25:36 +0000",
  "in_reply_to_screen_name" : "annindk",
  "in_reply_to_user_id_str" : "127530996",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Lewis",
      "screen_name" : "roblewiselt",
      "indices" : [ 3, 15 ],
      "id_str" : "132668606",
      "id" : 132668606
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "esl",
      "indices" : [ 105, 109 ]
    }, {
      "text" : "elt",
      "indices" : [ 110, 114 ]
    }, {
      "text" : "efl",
      "indices" : [ 115, 119 ]
    }, {
      "text" : "edtech",
      "indices" : [ 120, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/Zd9FbfDweg",
      "expanded_url" : "http:\/\/englishagenda.britishcouncil.org\/content\/englishagenda-podcast-10th-february-2014",
      "display_url" : "englishagenda.britishcouncil.org\/content\/englis\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "435938171093024768",
  "text" : "RT @roblewiselt: Podcast - update on EL writing MOOC run by UC Berkeley recently: http:\/\/t.co\/Zd9FbfDweg #esl #elt #efl #edtech",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "esl",
        "indices" : [ 88, 92 ]
      }, {
        "text" : "elt",
        "indices" : [ 93, 97 ]
      }, {
        "text" : "efl",
        "indices" : [ 98, 102 ]
      }, {
        "text" : "edtech",
        "indices" : [ 103, 110 ]
      } ],
      "urls" : [ {
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/Zd9FbfDweg",
        "expanded_url" : "http:\/\/englishagenda.britishcouncil.org\/content\/englishagenda-podcast-10th-february-2014",
        "display_url" : "englishagenda.britishcouncil.org\/content\/englis\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "435802298162638848",
    "text" : "Podcast - update on EL writing MOOC run by UC Berkeley recently: http:\/\/t.co\/Zd9FbfDweg #esl #elt #efl #edtech",
    "id" : 435802298162638848,
    "created_at" : "2014-02-18 15:45:39 +0000",
    "user" : {
      "name" : "Rob Lewis",
      "screen_name" : "roblewiselt",
      "protected" : false,
      "id_str" : "132668606",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2289220858\/105yhfsikch8po1sxbva_normal.png",
      "id" : 132668606,
      "verified" : false
    }
  },
  "id" : 435938171093024768,
  "created_at" : "2014-02-19 00:45:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anne Hodgson",
      "screen_name" : "annehodg",
      "indices" : [ 0, 9 ],
      "id_str" : "17589213",
      "id" : 17589213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "435802283658313728",
  "geo" : { },
  "id_str" : "435825294927081472",
  "in_reply_to_user_id" : 17589213,
  "text" : "@annehodg thanks for share Anne, using the BNCaudio is relatively straightforward",
  "id" : 435825294927081472,
  "in_reply_to_status_id" : 435802283658313728,
  "created_at" : "2014-02-18 17:17:02 +0000",
  "in_reply_to_screen_name" : "annehodg",
  "in_reply_to_user_id_str" : "17589213",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil Longwell",
      "screen_name" : "teacherphili",
      "indices" : [ 3, 16 ],
      "id_str" : "67863264",
      "id" : 67863264
    }, {
      "name" : "Lizzie Pinard",
      "screen_name" : "LizziePinard",
      "indices" : [ 36, 49 ],
      "id_str" : "287093748",
      "id" : 287093748
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LearnerAutonomy",
      "indices" : [ 67, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/53QtmRYd5M",
      "expanded_url" : "http:\/\/bit.ly\/1bIpET7",
      "display_url" : "bit.ly\/1bIpET7"
    } ]
  },
  "geo" : { },
  "id_str" : "435788235189788674",
  "text" : "RT @teacherphili: Free webinar with @LizziePinard  tomorrow 10 GMT #LearnerAutonomy - http:\/\/t.co\/53QtmRYd5M",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lizzie Pinard",
        "screen_name" : "LizziePinard",
        "indices" : [ 18, 31 ],
        "id_str" : "287093748",
        "id" : 287093748
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LearnerAutonomy",
        "indices" : [ 49, 65 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/53QtmRYd5M",
        "expanded_url" : "http:\/\/bit.ly\/1bIpET7",
        "display_url" : "bit.ly\/1bIpET7"
      } ]
    },
    "geo" : { },
    "id_str" : "435788037738741760",
    "text" : "Free webinar with @LizziePinard  tomorrow 10 GMT #LearnerAutonomy - http:\/\/t.co\/53QtmRYd5M",
    "id" : 435788037738741760,
    "created_at" : "2014-02-18 14:48:59 +0000",
    "user" : {
      "name" : "Phil Longwell",
      "screen_name" : "teacherphili",
      "protected" : false,
      "id_str" : "67863264",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637201716295933952\/4n4DCm-q_normal.jpg",
      "id" : 67863264,
      "verified" : false
    }
  },
  "id" : 435788235189788674,
  "created_at" : "2014-02-18 14:49:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Kern\u24C4h\u24B6n",
      "screen_name" : "dkernohan",
      "indices" : [ 3, 13 ],
      "id_str" : "12219232",
      "id" : 12219232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/bVkFenedig",
      "expanded_url" : "http:\/\/fsi-languages.yojik.eu\/",
      "display_url" : "fsi-languages.yojik.eu"
    } ]
  },
  "geo" : { },
  "id_str" : "435787114987659264",
  "text" : "RT @dkernohan: Public domain language learning materials from the US government: http:\/\/t.co\/bVkFenedig how did I not know about this??",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/janetter.net\/\" rel=\"nofollow\"\u003EJanetter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 88 ],
        "url" : "http:\/\/t.co\/bVkFenedig",
        "expanded_url" : "http:\/\/fsi-languages.yojik.eu\/",
        "display_url" : "fsi-languages.yojik.eu"
      } ]
    },
    "geo" : { },
    "id_str" : "435720669087948800",
    "text" : "Public domain language learning materials from the US government: http:\/\/t.co\/bVkFenedig how did I not know about this??",
    "id" : 435720669087948800,
    "created_at" : "2014-02-18 10:21:17 +0000",
    "user" : {
      "name" : "David Kern\u24C4h\u24B6n",
      "screen_name" : "dkernohan",
      "protected" : false,
      "id_str" : "12219232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/757702202437804032\/4Xrm7IIe_normal.jpg",
      "id" : 12219232,
      "verified" : false
    }
  },
  "id" : 435787114987659264,
  "created_at" : "2014-02-18 14:45:19 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "indices" : [ 3, 14 ],
      "id_str" : "152051625",
      "id" : 152051625
    }, {
      "name" : "Kate Wiles",
      "screen_name" : "katemond",
      "indices" : [ 59, 68 ],
      "id_str" : "14315917",
      "id" : 14315917
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/n21KH2QS6p",
      "expanded_url" : "http:\/\/www.newstatesman.com\/culture\/2014\/02\/swearing-fascinating-history-our-favourite-four-letter-words",
      "display_url" : "newstatesman.com\/culture\/2014\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "435783891287556097",
  "text" : "RT @heatherfro: and then, of course, came back to see that @katemond is writing about sweary things again http:\/\/t.co\/n21KH2QS6p",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kate Wiles",
        "screen_name" : "katemond",
        "indices" : [ 43, 52 ],
        "id_str" : "14315917",
        "id" : 14315917
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/n21KH2QS6p",
        "expanded_url" : "http:\/\/www.newstatesman.com\/culture\/2014\/02\/swearing-fascinating-history-our-favourite-four-letter-words",
        "display_url" : "newstatesman.com\/culture\/2014\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "435783284598272000",
    "text" : "and then, of course, came back to see that @katemond is writing about sweary things again http:\/\/t.co\/n21KH2QS6p",
    "id" : 435783284598272000,
    "created_at" : "2014-02-18 14:30:06 +0000",
    "user" : {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "protected" : false,
      "id_str" : "152051625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/688767277022494720\/KMrzOBc1_normal.jpg",
      "id" : 152051625,
      "verified" : false
    }
  },
  "id" : 435783891287556097,
  "created_at" : "2014-02-18 14:32:30 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anne Hodgson",
      "screen_name" : "annehodg",
      "indices" : [ 0, 9 ],
      "id_str" : "17589213",
      "id" : 17589213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "435764196576223232",
  "geo" : { },
  "id_str" : "435769592212770820",
  "in_reply_to_user_id" : 17589213,
  "text" : "@annehodg thanks for review, have been using BNCaudio corpus in class and seems to be one way to tackle jungle listening",
  "id" : 435769592212770820,
  "in_reply_to_status_id" : 435764196576223232,
  "created_at" : "2014-02-18 13:35:41 +0000",
  "in_reply_to_screen_name" : "annehodg",
  "in_reply_to_user_id_str" : "17589213",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anne Hodgson",
      "screen_name" : "annehodg",
      "indices" : [ 3, 12 ],
      "id_str" : "17589213",
      "id" : 17589213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/RH1b0DID1s",
      "expanded_url" : "http:\/\/annehodgson.de\/2014\/02\/18\/getting-real-in-teaching-listening\/",
      "display_url" : "annehodgson.de\/2014\/02\/18\/get\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "435758330712428544",
  "text" : "RT @annehodg: Just blogged review of Richard Cauldwell Phonology for Listening: Getting real in teaching listening http:\/\/t.co\/RH1b0DID1s",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/RH1b0DID1s",
        "expanded_url" : "http:\/\/annehodgson.de\/2014\/02\/18\/getting-real-in-teaching-listening\/",
        "display_url" : "annehodgson.de\/2014\/02\/18\/get\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "435738671312936960",
    "text" : "Just blogged review of Richard Cauldwell Phonology for Listening: Getting real in teaching listening http:\/\/t.co\/RH1b0DID1s",
    "id" : 435738671312936960,
    "created_at" : "2014-02-18 11:32:49 +0000",
    "user" : {
      "name" : "Anne Hodgson",
      "screen_name" : "annehodg",
      "protected" : false,
      "id_str" : "17589213",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618152681920724993\/9dLkbtqM_normal.jpg",
      "id" : 17589213,
      "verified" : false
    }
  },
  "id" : 435758330712428544,
  "created_at" : "2014-02-18 12:50:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/h3dbTSnGdx",
      "expanded_url" : "http:\/\/www.scientificamerican.com\/article\/math-explains-likely-long-shots-miracles-and-winning-the-lottery\/",
      "display_url" : "scientificamerican.com\/article\/math-e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "435736795246903296",
  "text" : "Math Explains Likely Long Shots, Miracles and Winning the Lottery [Excerpt] http:\/\/t.co\/h3dbTSnGdx",
  "id" : 435736795246903296,
  "created_at" : "2014-02-18 11:25:22 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen White",
      "screen_name" : "KarenWhiteInk",
      "indices" : [ 0, 14 ],
      "id_str" : "20389382",
      "id" : 20389382
    }, {
      "name" : "Adam Creen",
      "screen_name" : "adamcreen",
      "indices" : [ 15, 25 ],
      "id_str" : "19901094",
      "id" : 19901094
    }, {
      "name" : "Gwynne's Grammar",
      "screen_name" : "GwynnesGrammar",
      "indices" : [ 26, 41 ],
      "id_str" : "1308179192",
      "id" : 1308179192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/yEsGLBQTWN",
      "expanded_url" : "http:\/\/stroppyeditor.wordpress.com\/2014\/02\/18\/modern-standards-of-grammar-do-not-make-you-kill-yourself\/",
      "display_url" : "stroppyeditor.wordpress.com\/2014\/02\/18\/mod\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "435497472971276288",
  "geo" : { },
  "id_str" : "435713530243735554",
  "in_reply_to_user_id" : 20389382,
  "text" : "@KarenWhiteInk @adamcreen @GwynnesGrammar such suicide :) http:\/\/t.co\/yEsGLBQTWN",
  "id" : 435713530243735554,
  "in_reply_to_status_id" : 435497472971276288,
  "created_at" : "2014-02-18 09:52:55 +0000",
  "in_reply_to_screen_name" : "KarenWhiteInk",
  "in_reply_to_user_id_str" : "20389382",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MaWSIG",
      "screen_name" : "MaWSIG",
      "indices" : [ 0, 7 ],
      "id_str" : "1096618700",
      "id" : 1096618700
    }, {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 8, 19 ],
      "id_str" : "282659955",
      "id" : 282659955
    }, {
      "name" : "BCSeminars",
      "screen_name" : "BCseminars",
      "indices" : [ 20, 31 ],
      "id_str" : "134099962",
      "id" : 134099962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "435499597730160640",
  "geo" : { },
  "id_str" : "435518525893926913",
  "in_reply_to_user_id" : 1096618700,
  "text" : "@MaWSIG @teflerinha @BCseminars will BC record this?",
  "id" : 435518525893926913,
  "in_reply_to_status_id" : 435499597730160640,
  "created_at" : "2014-02-17 20:58:02 +0000",
  "in_reply_to_screen_name" : "MaWSIG",
  "in_reply_to_user_id_str" : "1096618700",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MaWSIG",
      "screen_name" : "MaWSIG",
      "indices" : [ 3, 10 ],
      "id_str" : "1096618700",
      "id" : 1096618700
    }, {
      "name" : "Rachael Roberts",
      "screen_name" : "teflerinha",
      "indices" : [ 88, 99 ],
      "id_str" : "282659955",
      "id" : 282659955
    }, {
      "name" : "BCSeminars",
      "screen_name" : "BCseminars",
      "indices" : [ 100, 111 ],
      "id_str" : "134099962",
      "id" : 134099962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/EsjFpPXJ69",
      "expanded_url" : "http:\/\/ow.ly\/tIquY",
      "display_url" : "ow.ly\/tIquY"
    } ]
  },
  "geo" : { },
  "id_str" : "435518450837237760",
  "text" : "RT @MaWSIG: More than just a worksheet: How to write effective classroom materials with @teflerinha @BCSeminars Mar4 6:30PM Londn http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rachael Roberts",
        "screen_name" : "teflerinha",
        "indices" : [ 76, 87 ],
        "id_str" : "282659955",
        "id" : 282659955
      }, {
        "name" : "BCSeminars",
        "screen_name" : "BCseminars",
        "indices" : [ 88, 99 ],
        "id_str" : "134099962",
        "id" : 134099962
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/EsjFpPXJ69",
        "expanded_url" : "http:\/\/ow.ly\/tIquY",
        "display_url" : "ow.ly\/tIquY"
      } ]
    },
    "geo" : { },
    "id_str" : "435499597730160640",
    "text" : "More than just a worksheet: How to write effective classroom materials with @teflerinha @BCSeminars Mar4 6:30PM Londn http:\/\/t.co\/EsjFpPXJ69",
    "id" : 435499597730160640,
    "created_at" : "2014-02-17 19:42:49 +0000",
    "user" : {
      "name" : "MaWSIG",
      "screen_name" : "MaWSIG",
      "protected" : false,
      "id_str" : "1096618700",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3471592092\/75c231ab25fa45330c0cf95a5763d27f_normal.jpeg",
      "id" : 1096618700,
      "verified" : false
    }
  },
  "id" : 435518450837237760,
  "created_at" : "2014-02-17 20:57:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nelson Flores",
      "screen_name" : "nelsonlflores",
      "indices" : [ 87, 101 ],
      "id_str" : "248343882",
      "id" : 248343882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/Vu9wTfo7Ua",
      "expanded_url" : "http:\/\/wp.me\/p45k2O-1T",
      "display_url" : "wp.me\/p45k2O-1T"
    } ]
  },
  "geo" : { },
  "id_str" : "435503927048409089",
  "text" : "Why multilingual Coke commercials are nothing to celebrate: http:\/\/t.co\/Vu9wTfo7Ua via @nelsonlflores",
  "id" : 435503927048409089,
  "created_at" : "2014-02-17 20:00:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Hokama",
      "screen_name" : "luhoka",
      "indices" : [ 3, 10 ],
      "id_str" : "110853657",
      "id" : 110853657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/X47tUw7fE9",
      "expanded_url" : "http:\/\/feedly.com\/k\/1mSGeiB",
      "display_url" : "feedly.com\/k\/1mSGeiB"
    } ]
  },
  "geo" : { },
  "id_str" : "435454155050999808",
  "text" : "RT @luhoka: Chrome + LEGO: You can build whatever you like: http:\/\/t.co\/X47tUw7fE9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 70 ],
        "url" : "http:\/\/t.co\/X47tUw7fE9",
        "expanded_url" : "http:\/\/feedly.com\/k\/1mSGeiB",
        "display_url" : "feedly.com\/k\/1mSGeiB"
      } ]
    },
    "geo" : { },
    "id_str" : "435447396475346944",
    "text" : "Chrome + LEGO: You can build whatever you like: http:\/\/t.co\/X47tUw7fE9",
    "id" : 435447396475346944,
    "created_at" : "2014-02-17 16:15:24 +0000",
    "user" : {
      "name" : "Luke Hokama",
      "screen_name" : "luhoka",
      "protected" : false,
      "id_str" : "110853657",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/748303764549824513\/3jlLHSCi_normal.jpg",
      "id" : 110853657,
      "verified" : false
    }
  },
  "id" : 435454155050999808,
  "created_at" : "2014-02-17 16:42:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "435418529597513728",
  "geo" : { },
  "id_str" : "435419621693218816",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson no idea looks like a new book though",
  "id" : 435419621693218816,
  "in_reply_to_status_id" : 435418529597513728,
  "created_at" : "2014-02-17 14:25:02 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 3, 15 ],
      "id_str" : "525013404",
      "id" : 525013404
    }, {
      "name" : "Russ Mayne",
      "screen_name" : "ebefl",
      "indices" : [ 35, 41 ],
      "id_str" : "2228367554",
      "id" : 2228367554
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "vanillaEinstein",
      "indices" : [ 98, 114 ]
    }, {
      "text" : "irony",
      "indices" : [ 115, 121 ]
    }, {
      "text" : "Einsteinmemes",
      "indices" : [ 122, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/ij3u8rbLGd",
      "expanded_url" : "http:\/\/malingual.blogspot.tw\/2014\/02\/emc-hammer.html",
      "display_url" : "malingual.blogspot.tw\/2014\/02\/emc-ha\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "435419385633996800",
  "text" : "RT @AnneHendler: Hey Twitterverse. @ebefl has done it again: \"E=mc-hammer\" http:\/\/t.co\/ij3u8rbLGd #vanillaEinstein #irony #Einsteinmemes",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Russ Mayne",
        "screen_name" : "ebefl",
        "indices" : [ 18, 24 ],
        "id_str" : "2228367554",
        "id" : 2228367554
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "vanillaEinstein",
        "indices" : [ 81, 97 ]
      }, {
        "text" : "irony",
        "indices" : [ 98, 104 ]
      }, {
        "text" : "Einsteinmemes",
        "indices" : [ 105, 119 ]
      } ],
      "urls" : [ {
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/ij3u8rbLGd",
        "expanded_url" : "http:\/\/malingual.blogspot.tw\/2014\/02\/emc-hammer.html",
        "display_url" : "malingual.blogspot.tw\/2014\/02\/emc-ha\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "435419102463553536",
    "text" : "Hey Twitterverse. @ebefl has done it again: \"E=mc-hammer\" http:\/\/t.co\/ij3u8rbLGd #vanillaEinstein #irony #Einsteinmemes",
    "id" : 435419102463553536,
    "created_at" : "2014-02-17 14:22:58 +0000",
    "user" : {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "protected" : false,
      "id_str" : "525013404",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766910187911405568\/zw3Ez5M0_normal.jpg",
      "id" : 525013404,
      "verified" : false
    }
  },
  "id" : 435419385633996800,
  "created_at" : "2014-02-17 14:24:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Griffin",
      "screen_name" : "michaelegriffin",
      "indices" : [ 0, 16 ],
      "id_str" : "394053348",
      "id" : 394053348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "435409324114849794",
  "geo" : { },
  "id_str" : "435410211277246465",
  "in_reply_to_user_id" : 394053348,
  "text" : "@michaelegriffin hangman a waste of time?! you blasphemer...the ELT gods will surely bring their wrath... erm probably cut-up sheets",
  "id" : 435410211277246465,
  "in_reply_to_status_id" : 435409324114849794,
  "created_at" : "2014-02-17 13:47:38 +0000",
  "in_reply_to_screen_name" : "michaelegriffin",
  "in_reply_to_user_id_str" : "394053348",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roxane Harrison",
      "screen_name" : "roxaneharrison",
      "indices" : [ 7, 22 ],
      "id_str" : "267494842",
      "id" : 267494842
    }, {
      "name" : "KBarrs",
      "screen_name" : "corpusloanword",
      "indices" : [ 23, 38 ],
      "id_str" : "95419070",
      "id" : 95419070
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 56, 67 ]
    }, {
      "text" : "bootcat",
      "indices" : [ 91, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 142 ],
      "url" : "https:\/\/t.co\/6rNDE5icYH",
      "expanded_url" : "https:\/\/plus.google.com\/104940199413423400545\/posts\/8JjUVKyA8FE",
      "display_url" : "plus.google.com\/10494019941342\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "435405129458515969",
  "text" : "thanks @roxaneharrison @corpusloanword for rt &amp; fav #corpusmooc thoughts fyi a beta of #bootcat available in reply https:\/\/t.co\/6rNDE5icYH",
  "id" : 435405129458515969,
  "created_at" : "2014-02-17 13:27:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "indices" : [ 3, 13 ],
      "id_str" : "525274103",
      "id" : 525274103
    }, {
      "name" : "Daniel C. Stevens",
      "screen_name" : "dc_stevens",
      "indices" : [ 18, 29 ],
      "id_str" : "272314175",
      "id" : 272314175
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BBCpanoroma",
      "indices" : [ 107, 119 ]
    }, {
      "text" : "AusELT",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/9K0sERWWso",
      "expanded_url" : "http:\/\/www.nusconnect.org.uk\/blogs\/blog\/danielstevens\/2014\/02\/14\/Why-sensationalist-journalism-lets-down-international-students\/#.Uv5COHBEAq8.twitter",
      "display_url" : "nusconnect.org.uk\/blogs\/blog\/dan\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "435391069673762816",
  "text" : "RT @ElkySmith: MT @dc_stevens: Why sensationalist journalism lets down int'l students - blog post slamming #BBCpanoroma http:\/\/t.co\/9K0sERW\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Daniel C. Stevens",
        "screen_name" : "dc_stevens",
        "indices" : [ 3, 14 ],
        "id_str" : "272314175",
        "id" : 272314175
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BBCpanoroma",
        "indices" : [ 92, 104 ]
      }, {
        "text" : "AusELT",
        "indices" : [ 128, 135 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/9K0sERWWso",
        "expanded_url" : "http:\/\/www.nusconnect.org.uk\/blogs\/blog\/danielstevens\/2014\/02\/14\/Why-sensationalist-journalism-lets-down-international-students\/#.Uv5COHBEAq8.twitter",
        "display_url" : "nusconnect.org.uk\/blogs\/blog\/dan\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "434361719532847104",
    "geo" : { },
    "id_str" : "435352326610489344",
    "in_reply_to_user_id" : 272314175,
    "text" : "MT @dc_stevens: Why sensationalist journalism lets down int'l students - blog post slamming #BBCpanoroma http:\/\/t.co\/9K0sERWWso #AusELT",
    "id" : 435352326610489344,
    "in_reply_to_status_id" : 434361719532847104,
    "created_at" : "2014-02-17 09:57:37 +0000",
    "in_reply_to_screen_name" : "dc_stevens",
    "in_reply_to_user_id_str" : "272314175",
    "user" : {
      "name" : "Kyle Smith",
      "screen_name" : "ElkySmith",
      "protected" : false,
      "id_str" : "525274103",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/690658566370263041\/qggTYEb3_normal.jpg",
      "id" : 525274103,
      "verified" : false
    }
  },
  "id" : 435391069673762816,
  "created_at" : "2014-02-17 12:31:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "indices" : [ 3, 12 ],
      "id_str" : "134211317",
      "id" : 134211317
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 93, 97 ]
    }, {
      "text" : "tefl",
      "indices" : [ 98, 103 ]
    }, {
      "text" : "BESIG",
      "indices" : [ 104, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/EomFcOvKf1",
      "expanded_url" : "http:\/\/wp.me\/p3Wm0j-eo",
      "display_url" : "wp.me\/p3Wm0j-eo"
    } ]
  },
  "geo" : { },
  "id_str" : "435383279353876480",
  "text" : "RT @josipa74: 3 things to help you start Decentralised Teaching today http:\/\/t.co\/EomFcOvKf1 #elt #tefl #BESIG Share if useful!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "elt",
        "indices" : [ 79, 83 ]
      }, {
        "text" : "tefl",
        "indices" : [ 84, 89 ]
      }, {
        "text" : "BESIG",
        "indices" : [ 90, 96 ]
      } ],
      "urls" : [ {
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/EomFcOvKf1",
        "expanded_url" : "http:\/\/wp.me\/p3Wm0j-eo",
        "display_url" : "wp.me\/p3Wm0j-eo"
      } ]
    },
    "geo" : { },
    "id_str" : "435380120417624067",
    "text" : "3 things to help you start Decentralised Teaching today http:\/\/t.co\/EomFcOvKf1 #elt #tefl #BESIG Share if useful!",
    "id" : 435380120417624067,
    "created_at" : "2014-02-17 11:48:04 +0000",
    "user" : {
      "name" : "paulw",
      "screen_name" : "josipa74",
      "protected" : false,
      "id_str" : "134211317",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/526853654377021441\/MtEFhYIs_normal.jpeg",
      "id" : 134211317,
      "verified" : false
    }
  },
  "id" : 435383279353876480,
  "created_at" : "2014-02-17 12:00:37 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate AG",
      "screen_name" : "RadioKate",
      "indices" : [ 3, 13 ],
      "id_str" : "20040253",
      "id" : 20040253
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/2EGaZNBOv9",
      "expanded_url" : "http:\/\/bit.ly\/1oG6Bfb",
      "display_url" : "bit.ly\/1oG6Bfb"
    } ]
  },
  "geo" : { },
  "id_str" : "435371647814881280",
  "text" : "RT @RadioKate: This is amazing from XKCD. http:\/\/t.co\/2EGaZNBOv9 I mean, even more thought provoking and amazing than usual.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 27, 49 ],
        "url" : "http:\/\/t.co\/2EGaZNBOv9",
        "expanded_url" : "http:\/\/bit.ly\/1oG6Bfb",
        "display_url" : "bit.ly\/1oG6Bfb"
      } ]
    },
    "geo" : { },
    "id_str" : "435348854322757633",
    "text" : "This is amazing from XKCD. http:\/\/t.co\/2EGaZNBOv9 I mean, even more thought provoking and amazing than usual.",
    "id" : 435348854322757633,
    "created_at" : "2014-02-17 09:43:49 +0000",
    "user" : {
      "name" : "Kate AG",
      "screen_name" : "RadioKate",
      "protected" : false,
      "id_str" : "20040253",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/287587617\/Kate140_normal.jpg",
      "id" : 20040253,
      "verified" : false
    }
  },
  "id" : 435371647814881280,
  "created_at" : "2014-02-17 11:14:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Drama Teacher Uk",
      "screen_name" : "dramateacheruk",
      "indices" : [ 0, 15 ],
      "id_str" : "817688869",
      "id" : 817688869
    }, {
      "name" : "Kathy Elliott",
      "screen_name" : "KathyKelliott",
      "indices" : [ 16, 30 ],
      "id_str" : "1270908469",
      "id" : 1270908469
    }, {
      "name" : "That's Not My Age",
      "screen_name" : "thatsntmyage",
      "indices" : [ 31, 44 ],
      "id_str" : "14459746",
      "id" : 14459746
    }, {
      "name" : "Corwynt",
      "screen_name" : "Gwenelope",
      "indices" : [ 45, 55 ],
      "id_str" : "21560089",
      "id" : 21560089
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/ewDqkZyA51",
      "expanded_url" : "http:\/\/www.huffingtonpost.co.uk\/2011\/10\/11\/dame-helen-mirren-free-sc_n_1004522.html",
      "display_url" : "huffingtonpost.co.uk\/2011\/10\/11\/dam\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "435198747291975681",
  "geo" : { },
  "id_str" : "435220927865823232",
  "in_reply_to_user_id" : 817688869,
  "text" : "@dramateacheruk @KathyKelliott @thatsntmyage @Gwenelope erm? http:\/\/t.co\/ewDqkZyA51",
  "id" : 435220927865823232,
  "in_reply_to_status_id" : 435198747291975681,
  "created_at" : "2014-02-17 01:15:29 +0000",
  "in_reply_to_screen_name" : "dramateacheruk",
  "in_reply_to_user_id_str" : "817688869",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bruce McPherson",
      "screen_name" : "brucemcpherson",
      "indices" : [ 0, 15 ],
      "id_str" : "17517365",
      "id" : 17517365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "435047891430682624",
  "geo" : { },
  "id_str" : "435175135192961024",
  "in_reply_to_user_id" : 17517365,
  "text" : "@brucemcpherson yeah d\/l client but problem working in firefox, works on safari yes",
  "id" : 435175135192961024,
  "in_reply_to_status_id" : 435047891430682624,
  "created_at" : "2014-02-16 22:13:32 +0000",
  "in_reply_to_screen_name" : "brucemcpherson",
  "in_reply_to_user_id_str" : "17517365",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donald Clark",
      "screen_name" : "DonaldClark",
      "indices" : [ 3, 15 ],
      "id_str" : "1632891",
      "id" : 1632891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/aBJZbHkYel",
      "expanded_url" : "http:\/\/bit.ly\/1dAcFSn",
      "display_url" : "bit.ly\/1dAcFSn"
    } ]
  },
  "geo" : { },
  "id_str" : "435174881949663233",
  "text" : "RT @DonaldClark: No coding shortage - brilliant piece by recruiter - nails it &amp; Year of Code chraltans http:\/\/t.co\/aBJZbHkYel",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/aBJZbHkYel",
        "expanded_url" : "http:\/\/bit.ly\/1dAcFSn",
        "display_url" : "bit.ly\/1dAcFSn"
      } ]
    },
    "geo" : { },
    "id_str" : "435112790106189824",
    "text" : "No coding shortage - brilliant piece by recruiter - nails it &amp; Year of Code chraltans http:\/\/t.co\/aBJZbHkYel",
    "id" : 435112790106189824,
    "created_at" : "2014-02-16 18:05:47 +0000",
    "user" : {
      "name" : "Donald Clark",
      "screen_name" : "DonaldClark",
      "protected" : false,
      "id_str" : "1632891",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/513085530695663616\/BfWK4n6u_normal.jpeg",
      "id" : 1632891,
      "verified" : false
    }
  },
  "id" : 435174881949663233,
  "created_at" : "2014-02-16 22:12:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Costas Gabrielatos",
      "screen_name" : "congabonga",
      "indices" : [ 49, 60 ],
      "id_str" : "187484412",
      "id" : 187484412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/JeWVR8rRdC",
      "expanded_url" : "https:\/\/plus.google.com\/104940199413423400545\/posts\/dgdqDkDKduf",
      "display_url" : "plus.google.com\/10494019941342\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "435131770032226304",
  "text" : "a linguist who was originally a language teacher @congabonga  discusses some CL and language teaching questions https:\/\/t.co\/JeWVR8rRdC",
  "id" : 435131770032226304,
  "created_at" : "2014-02-16 19:21:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bruce McPherson",
      "screen_name" : "brucemcpherson",
      "indices" : [ 0, 15 ],
      "id_str" : "17517365",
      "id" : 17517365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "435004291439267840",
  "geo" : { },
  "id_str" : "435042346296541184",
  "in_reply_to_user_id" : 17517365,
  "text" : "@brucemcpherson thanks though does not seem to load in latest firefox",
  "id" : 435042346296541184,
  "in_reply_to_status_id" : 435004291439267840,
  "created_at" : "2014-02-16 13:25:52 +0000",
  "in_reply_to_screen_name" : "brucemcpherson",
  "in_reply_to_user_id_str" : "17517365",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bruce McPherson",
      "screen_name" : "brucemcpherson",
      "indices" : [ 3, 18 ],
      "id_str" : "17517365",
      "id" : 17517365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/CkA94sCN5k",
      "expanded_url" : "http:\/\/live.bittorrent.com",
      "display_url" : "live.bittorrent.com"
    } ]
  },
  "geo" : { },
  "id_str" : "435039848303706113",
  "text" : "RT @brucemcpherson: not much content yet, but live bit torrent seems to work pretty well http:\/\/t.co\/CkA94sCN5k",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/CkA94sCN5k",
        "expanded_url" : "http:\/\/live.bittorrent.com",
        "display_url" : "live.bittorrent.com"
      } ]
    },
    "geo" : { },
    "id_str" : "435004291439267840",
    "text" : "not much content yet, but live bit torrent seems to work pretty well http:\/\/t.co\/CkA94sCN5k",
    "id" : 435004291439267840,
    "created_at" : "2014-02-16 10:54:39 +0000",
    "user" : {
      "name" : "Bruce McPherson",
      "screen_name" : "brucemcpherson",
      "protected" : false,
      "id_str" : "17517365",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/532843831230607360\/xipBHzeR_normal.png",
      "id" : 17517365,
      "verified" : false
    }
  },
  "id" : 435039848303706113,
  "created_at" : "2014-02-16 13:15:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 108, 124 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/ZnFDEHbObJ",
      "expanded_url" : "http:\/\/wp.me\/p354NQ-5e",
      "display_url" : "wp.me\/p354NQ-5e"
    } ]
  },
  "geo" : { },
  "id_str" : "435036721009283072",
  "text" : "\u2018A Sort of Verbal Bannockburn\u2019: Language and the Debate on Scottish Independence http:\/\/t.co\/ZnFDEHbObJ via @wordpressdotcom",
  "id" : 435036721009283072,
  "created_at" : "2014-02-16 13:03:31 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Brown",
      "screen_name" : "sbrowntweets",
      "indices" : [ 3, 16 ],
      "id_str" : "885343459",
      "id" : 885343459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/UsxCslzVyr",
      "expanded_url" : "http:\/\/stevebrown70.wordpress.com\/2014\/02\/16\/bogus-students-whos-to-blame\/",
      "display_url" : "stevebrown70.wordpress.com\/2014\/02\/16\/bog\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "435022063754289152",
  "text" : "RT @sbrowntweets: In my latest post I am having a bit of a pop at the home office. Bad idea? We'll see. http:\/\/t.co\/UsxCslzVyr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/UsxCslzVyr",
        "expanded_url" : "http:\/\/stevebrown70.wordpress.com\/2014\/02\/16\/bogus-students-whos-to-blame\/",
        "display_url" : "stevebrown70.wordpress.com\/2014\/02\/16\/bog\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "435020088211554304",
    "text" : "In my latest post I am having a bit of a pop at the home office. Bad idea? We'll see. http:\/\/t.co\/UsxCslzVyr",
    "id" : 435020088211554304,
    "created_at" : "2014-02-16 11:57:25 +0000",
    "user" : {
      "name" : "Steve Brown",
      "screen_name" : "sbrowntweets",
      "protected" : false,
      "id_str" : "885343459",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746292888405934080\/tp1_ccBF_normal.jpg",
      "id" : 885343459,
      "verified" : false
    }
  },
  "id" : 435022063754289152,
  "created_at" : "2014-02-16 12:05:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0411\u0430\u043B\u0438\u043D\u0433",
      "screen_name" : "websofsubstance",
      "indices" : [ 58, 74 ],
      "id_str" : "235176479",
      "id" : 235176479
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/0iXhjER85J",
      "expanded_url" : "http:\/\/wp.me\/p3hsrD-kc",
      "display_url" : "wp.me\/p3hsrD-kc"
    } ]
  },
  "geo" : { },
  "id_str" : "434987191651954688",
  "text" : "The curse of gimmicky teaching http:\/\/t.co\/0iXhjER85J via @websofsubstance",
  "id" : 434987191651954688,
  "created_at" : "2014-02-16 09:46:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hana Tich\u00E1",
      "screen_name" : "HanaTicha",
      "indices" : [ 3, 13 ],
      "id_str" : "512296705",
      "id" : 512296705
    }, {
      "name" : "JohnPfordresher",
      "screen_name" : "JohnPfordresher",
      "indices" : [ 39, 55 ],
      "id_str" : "168973558",
      "id" : 168973558
    }, {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 56, 68 ],
      "id_str" : "525013404",
      "id" : 525013404
    }, {
      "name" : "David Harbinson",
      "screen_name" : "DavidHarbinson",
      "indices" : [ 69, 84 ],
      "id_str" : "853078675",
      "id" : 853078675
    }, {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 85, 96 ],
      "id_str" : "144663117",
      "id" : 144663117
    }, {
      "name" : "Rose Bard",
      "screen_name" : "rosemerebard",
      "indices" : [ 97, 110 ],
      "id_str" : "88655243",
      "id" : 88655243
    }, {
      "name" : "Anna Loseva",
      "screen_name" : "AnnLoseva",
      "indices" : [ 111, 121 ],
      "id_str" : "38822368",
      "id" : 38822368
    }, {
      "name" : "Josette LeBlanc",
      "screen_name" : "JosetteLB",
      "indices" : [ 122, 132 ],
      "id_str" : "33503694",
      "id" : 33503694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/uKfdZ92pQ8",
      "expanded_url" : "http:\/\/how-i-see-it-now.blogspot.cz\/2014\/02\/changing-scenario-tribute-to-my-rppln.html",
      "display_url" : "how-i-see-it-now.blogspot.cz\/2014\/02\/changi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "434983491835805696",
  "text" : "RT @HanaTicha: My new post: tribute to @JohnPfordresher @AnneHendler @DavidHarbinson @kevchanwow @rosemerebard @AnnLoseva @JosetteLB http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "JohnPfordresher",
        "screen_name" : "JohnPfordresher",
        "indices" : [ 24, 40 ],
        "id_str" : "168973558",
        "id" : 168973558
      }, {
        "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
        "screen_name" : "AnneHendler",
        "indices" : [ 41, 53 ],
        "id_str" : "525013404",
        "id" : 525013404
      }, {
        "name" : "David Harbinson",
        "screen_name" : "DavidHarbinson",
        "indices" : [ 54, 69 ],
        "id_str" : "853078675",
        "id" : 853078675
      }, {
        "name" : "Kevin Stein",
        "screen_name" : "kevchanwow",
        "indices" : [ 70, 81 ],
        "id_str" : "144663117",
        "id" : 144663117
      }, {
        "name" : "Rose Bard",
        "screen_name" : "rosemerebard",
        "indices" : [ 82, 95 ],
        "id_str" : "88655243",
        "id" : 88655243
      }, {
        "name" : "Anna Loseva",
        "screen_name" : "AnnLoseva",
        "indices" : [ 96, 106 ],
        "id_str" : "38822368",
        "id" : 38822368
      }, {
        "name" : "Josette LeBlanc",
        "screen_name" : "JosetteLB",
        "indices" : [ 107, 117 ],
        "id_str" : "33503694",
        "id" : 33503694
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/uKfdZ92pQ8",
        "expanded_url" : "http:\/\/how-i-see-it-now.blogspot.cz\/2014\/02\/changing-scenario-tribute-to-my-rppln.html",
        "display_url" : "how-i-see-it-now.blogspot.cz\/2014\/02\/changi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "434962744274870272",
    "text" : "My new post: tribute to @JohnPfordresher @AnneHendler @DavidHarbinson @kevchanwow @rosemerebard @AnnLoseva @JosetteLB http:\/\/t.co\/uKfdZ92pQ8",
    "id" : 434962744274870272,
    "created_at" : "2014-02-16 08:09:34 +0000",
    "user" : {
      "name" : "Hana Tich\u00E1",
      "screen_name" : "HanaTicha",
      "protected" : false,
      "id_str" : "512296705",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/699528253598494721\/HL9Np6Gu_normal.jpg",
      "id" : 512296705,
      "verified" : false
    }
  },
  "id" : 434983491835805696,
  "created_at" : "2014-02-16 09:32:00 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Hardie",
      "screen_name" : "HardieResearch",
      "indices" : [ 0, 15 ],
      "id_str" : "970452764",
      "id" : 970452764
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434871147302113280",
  "geo" : { },
  "id_str" : "434874125375385601",
  "in_reply_to_user_id" : 970452764,
  "text" : "@HardieResearch great :) the new BootCat has some neat features apparently",
  "id" : 434874125375385601,
  "in_reply_to_status_id" : 434871147302113280,
  "created_at" : "2014-02-16 02:17:25 +0000",
  "in_reply_to_screen_name" : "HardieResearch",
  "in_reply_to_user_id_str" : "970452764",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Voce",
      "screen_name" : "julievoce",
      "indices" : [ 3, 13 ],
      "id_str" : "14796876",
      "id" : 14796876
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusMOOC",
      "indices" : [ 58, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/hW1Wl0xqJu",
      "expanded_url" : "http:\/\/wp.me\/p4hCTH-2s",
      "display_url" : "wp.me\/p4hCTH-2s"
    } ]
  },
  "geo" : { },
  "id_str" : "434868876040753152",
  "text" : "RT @julievoce: My view of Week 3 - Compare and contrast - #corpusMOOC http:\/\/t.co\/hW1Wl0xqJu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpusMOOC",
        "indices" : [ 43, 54 ]
      } ],
      "urls" : [ {
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/hW1Wl0xqJu",
        "expanded_url" : "http:\/\/wp.me\/p4hCTH-2s",
        "display_url" : "wp.me\/p4hCTH-2s"
      } ]
    },
    "geo" : { },
    "id_str" : "434833533459128320",
    "text" : "My view of Week 3 - Compare and contrast - #corpusMOOC http:\/\/t.co\/hW1Wl0xqJu",
    "id" : 434833533459128320,
    "created_at" : "2014-02-15 23:36:07 +0000",
    "user" : {
      "name" : "Julie Voce",
      "screen_name" : "julievoce",
      "protected" : false,
      "id_str" : "14796876",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/54269403\/julievoce2_normal.jpg",
      "id" : 14796876,
      "verified" : false
    }
  },
  "id" : 434868876040753152,
  "created_at" : "2014-02-16 01:56:34 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 0, 11 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/6rNDE5icYH",
      "expanded_url" : "https:\/\/plus.google.com\/104940199413423400545\/posts\/8JjUVKyA8FE",
      "display_url" : "plus.google.com\/10494019941342\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "434868456383463424",
  "text" : "#corpusmooc week 4 - idea for next version of course? https:\/\/t.co\/6rNDE5icYH",
  "id" : 434868456383463424,
  "created_at" : "2014-02-16 01:54:54 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Brindle",
      "screen_name" : "AndrewBrindle2",
      "indices" : [ 115, 130 ],
      "id_str" : "358143205",
      "id" : 358143205
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/xoDCD8OVKo",
      "expanded_url" : "http:\/\/wp.me\/p35kaI-2l",
      "display_url" : "wp.me\/p35kaI-2l"
    } ]
  },
  "geo" : { },
  "id_str" : "434786262268907521",
  "text" : "A Corpus Linguistic Approach to the Study of Writer Identity in Second Language Writing http:\/\/t.co\/xoDCD8OVKo via @AndrewBrindle2",
  "id" : 434786262268907521,
  "created_at" : "2014-02-15 20:28:17 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 91, 99 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/HRCndnXR8Y",
      "expanded_url" : "http:\/\/youtu.be\/6mhj-j0z-fk",
      "display_url" : "youtu.be\/6mhj-j0z-fk"
    } ]
  },
  "geo" : { },
  "id_str" : "434672959051923456",
  "text" : "Noam Chomsky (2014) \"How to Ruin an Economy; Some Simple Ways\": http:\/\/t.co\/HRCndnXR8Y via @youtube",
  "id" : 434672959051923456,
  "created_at" : "2014-02-15 12:58:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "indices" : [ 0, 9 ],
      "id_str" : "167020390",
      "id" : 167020390
    }, {
      "name" : "Peter Parise",
      "screen_name" : "peterrenshu",
      "indices" : [ 10, 22 ],
      "id_str" : "631949549",
      "id" : 631949549
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434591316580655104",
  "geo" : { },
  "id_str" : "434637456927776769",
  "in_reply_to_user_id" : 167020390,
  "text" : "@antlabjp @peterrenshu looks like a great ESP event :)",
  "id" : 434637456927776769,
  "in_reply_to_status_id" : 434591316580655104,
  "created_at" : "2014-02-15 10:36:59 +0000",
  "in_reply_to_screen_name" : "antlabjp",
  "in_reply_to_user_id_str" : "167020390",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "indices" : [ 3, 15 ],
      "id_str" : "223771625",
      "id" : 223771625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/7lKPcKzEli",
      "expanded_url" : "http:\/\/www.jonathan-cook.net\/blog\/2014-02-15\/the-lessons-of-russell-brands-tv-clash\/",
      "display_url" : "jonathan-cook.net\/blog\/2014-02-1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "434630618920796160",
  "text" : "RT @johnwhilley: Tremendous Cook blog on Russell Brand's skill in resisting power consensus: The lessons of Russell Brand\u2019s TV clash http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/7lKPcKzEli",
        "expanded_url" : "http:\/\/www.jonathan-cook.net\/blog\/2014-02-15\/the-lessons-of-russell-brands-tv-clash\/",
        "display_url" : "jonathan-cook.net\/blog\/2014-02-1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "434628538872778752",
    "text" : "Tremendous Cook blog on Russell Brand's skill in resisting power consensus: The lessons of Russell Brand\u2019s TV clash http:\/\/t.co\/7lKPcKzEli",
    "id" : 434628538872778752,
    "created_at" : "2014-02-15 10:01:33 +0000",
    "user" : {
      "name" : "John Hilley",
      "screen_name" : "johnwhilley",
      "protected" : false,
      "id_str" : "223771625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3027213200\/825947adffe3089b9a98f884d20a7e60_normal.jpeg",
      "id" : 223771625,
      "verified" : false
    }
  },
  "id" : 434630618920796160,
  "created_at" : "2014-02-15 10:09:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cdmblogs",
      "screen_name" : "cdmblogs",
      "indices" : [ 3, 12 ],
      "id_str" : "15739035",
      "id" : 15739035
    }, {
      "name" : "Inverted Audio",
      "screen_name" : "InvertedAudio",
      "indices" : [ 31, 45 ],
      "id_str" : "29564209",
      "id" : 29564209
    }, {
      "name" : "Nina Kehagia",
      "screen_name" : "NinaKehagia",
      "indices" : [ 113, 125 ],
      "id_str" : "22124657",
      "id" : 22124657
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "valentines",
      "indices" : [ 14, 25 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/wMD1GOenXP",
      "expanded_url" : "http:\/\/createdigitalmusic.com\/2014\/02\/valentines-mix-inverted-audio-make-v-day-sex-tape-like\/",
      "display_url" : "createdigitalmusic.com\/2014\/02\/valent\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "434384024908607488",
  "text" : "RT @cdmblogs: #valentines Mix: @InvertedAudio\n Make a V-Day \u201CSex Tape,\u201D We Like\n http:\/\/t.co\/wMD1GOenXP - thanks @NinaKehagia",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Inverted Audio",
        "screen_name" : "InvertedAudio",
        "indices" : [ 17, 31 ],
        "id_str" : "29564209",
        "id" : 29564209
      }, {
        "name" : "Nina Kehagia",
        "screen_name" : "NinaKehagia",
        "indices" : [ 99, 111 ],
        "id_str" : "22124657",
        "id" : 22124657
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "valentines",
        "indices" : [ 0, 11 ]
      } ],
      "urls" : [ {
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/wMD1GOenXP",
        "expanded_url" : "http:\/\/createdigitalmusic.com\/2014\/02\/valentines-mix-inverted-audio-make-v-day-sex-tape-like\/",
        "display_url" : "createdigitalmusic.com\/2014\/02\/valent\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "434344359086260224",
    "text" : "#valentines Mix: @InvertedAudio\n Make a V-Day \u201CSex Tape,\u201D We Like\n http:\/\/t.co\/wMD1GOenXP - thanks @NinaKehagia",
    "id" : 434344359086260224,
    "created_at" : "2014-02-14 15:12:19 +0000",
    "user" : {
      "name" : "cdmblogs",
      "screen_name" : "cdmblogs",
      "protected" : false,
      "id_str" : "15739035",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464778218445094912\/zvQnoKfw_normal.png",
      "id" : 15739035,
      "verified" : false
    }
  },
  "id" : 434384024908607488,
  "created_at" : "2014-02-14 17:49:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "indices" : [ 0, 11 ],
      "id_str" : "152051625",
      "id" : 152051625
    }, {
      "name" : "Magnus Nissel",
      "screen_name" : "u203d",
      "indices" : [ 12, 18 ],
      "id_str" : "533114985",
      "id" : 533114985
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434357351244898306",
  "geo" : { },
  "id_str" : "434380599164272640",
  "in_reply_to_user_id" : 152051625,
  "text" : "@heatherfro @u203d SWeeett thanks :)",
  "id" : 434380599164272640,
  "in_reply_to_status_id" : 434357351244898306,
  "created_at" : "2014-02-14 17:36:19 +0000",
  "in_reply_to_screen_name" : "heatherfro",
  "in_reply_to_user_id_str" : "152051625",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "indices" : [ 3, 14 ],
      "id_str" : "152051625",
      "id" : 152051625
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 36, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/Y3n5LTF4ll",
      "expanded_url" : "http:\/\/corpora.lancs.ac.uk\/clmtp\/",
      "display_url" : "corpora.lancs.ac.uk\/clmtp\/"
    } ]
  },
  "geo" : { },
  "id_str" : "434380035911602176",
  "text" : "RT @heatherfro: a supplement to the #corpusmooc? http:\/\/t.co\/Y3n5LTF4ll",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpusmooc",
        "indices" : [ 20, 31 ]
      } ],
      "urls" : [ {
        "indices" : [ 33, 55 ],
        "url" : "http:\/\/t.co\/Y3n5LTF4ll",
        "expanded_url" : "http:\/\/corpora.lancs.ac.uk\/clmtp\/",
        "display_url" : "corpora.lancs.ac.uk\/clmtp\/"
      } ]
    },
    "geo" : { },
    "id_str" : "434368969630580736",
    "text" : "a supplement to the #corpusmooc? http:\/\/t.co\/Y3n5LTF4ll",
    "id" : 434368969630580736,
    "created_at" : "2014-02-14 16:50:07 +0000",
    "user" : {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "protected" : false,
      "id_str" : "152051625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/688767277022494720\/KMrzOBc1_normal.jpg",
      "id" : 152051625,
      "verified" : false
    }
  },
  "id" : 434380035911602176,
  "created_at" : "2014-02-14 17:34:05 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Parise",
      "screen_name" : "peterrenshu",
      "indices" : [ 0, 12 ],
      "id_str" : "631949549",
      "id" : 631949549
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434372334477000704",
  "geo" : { },
  "id_str" : "434374722835320832",
  "in_reply_to_user_id" : 631949549,
  "text" : "@peterrenshu if u blog about put it on G+ comm :)",
  "id" : 434374722835320832,
  "in_reply_to_status_id" : 434372334477000704,
  "created_at" : "2014-02-14 17:12:58 +0000",
  "in_reply_to_screen_name" : "peterrenshu",
  "in_reply_to_user_id_str" : "631949549",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Parise",
      "screen_name" : "peterrenshu",
      "indices" : [ 3, 15 ],
      "id_str" : "631949549",
      "id" : 631949549
    }, {
      "name" : "Peter Parise",
      "screen_name" : "peterrenshu",
      "indices" : [ 20, 32 ],
      "id_str" : "631949549",
      "id" : 631949549
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/WiejIut5Bz",
      "expanded_url" : "http:\/\/wp.me\/pfNDY-cV",
      "display_url" : "wp.me\/pfNDY-cV"
    } ]
  },
  "geo" : { },
  "id_str" : "434357417368092672",
  "text" : "RT @peterrenshu: RT @peterrenshu: Poster presentation at International Symposium on Innovative Teaching and Research in ESP\n\u96FB\u6C17\u901A\u4FE1\u5927\u5B66,\u6771\u4EAChttp:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Peter Parise",
        "screen_name" : "peterrenshu",
        "indices" : [ 3, 15 ],
        "id_str" : "631949549",
        "id" : 631949549
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/WiejIut5Bz",
        "expanded_url" : "http:\/\/wp.me\/pfNDY-cV",
        "display_url" : "wp.me\/pfNDY-cV"
      } ]
    },
    "geo" : { },
    "id_str" : "434346862301032449",
    "text" : "RT @peterrenshu: Poster presentation at International Symposium on Innovative Teaching and Research in ESP\n\u96FB\u6C17\u901A\u4FE1\u5927\u5B66,\u6771\u4EAChttp:\/\/t.co\/WiejIut5Bz",
    "id" : 434346862301032449,
    "created_at" : "2014-02-14 15:22:16 +0000",
    "user" : {
      "name" : "Peter Parise",
      "screen_name" : "peterrenshu",
      "protected" : false,
      "id_str" : "631949549",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2390141891\/azxwx57ppddic0hnd26k_normal.jpeg",
      "id" : 631949549,
      "verified" : false
    }
  },
  "id" : 434357417368092672,
  "created_at" : "2014-02-14 16:04:12 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bruno Andrade",
      "screen_name" : "BrunoELT",
      "indices" : [ 3, 12 ],
      "id_str" : "39409915",
      "id" : 39409915
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 135, 139 ]
    }, {
      "text" : "education",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/oVg4yjhIk8",
      "expanded_url" : "http:\/\/bit.ly\/MiNf15",
      "display_url" : "bit.ly\/MiNf15"
    } ]
  },
  "geo" : { },
  "id_str" : "434296079300198400",
  "text" : "RT @BrunoELT: following a thread: A storm has blown up once again in the blogosphere over grammar McNuggets ... http:\/\/t.co\/oVg4yjhIk8 #elt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "elt",
        "indices" : [ 121, 125 ]
      }, {
        "text" : "education",
        "indices" : [ 126, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/oVg4yjhIk8",
        "expanded_url" : "http:\/\/bit.ly\/MiNf15",
        "display_url" : "bit.ly\/MiNf15"
      } ]
    },
    "geo" : { },
    "id_str" : "434293568102871040",
    "text" : "following a thread: A storm has blown up once again in the blogosphere over grammar McNuggets ... http:\/\/t.co\/oVg4yjhIk8 #elt #education",
    "id" : 434293568102871040,
    "created_at" : "2014-02-14 11:50:30 +0000",
    "user" : {
      "name" : "Bruno Andrade",
      "screen_name" : "BrunoELT",
      "protected" : false,
      "id_str" : "39409915",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1780205071\/image_normal.jpg",
      "id" : 39409915,
      "verified" : false
    }
  },
  "id" : 434296079300198400,
  "created_at" : "2014-02-14 12:00:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Moravec",
      "screen_name" : "ProfessMoravec",
      "indices" : [ 3, 18 ],
      "id_str" : "369529173",
      "id" : 369529173
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 33, 44 ]
    }, {
      "text" : "MOOCinPublic",
      "indices" : [ 121, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/YqLKWsWkG3",
      "expanded_url" : "http:\/\/bit.ly\/1b2aLoU",
      "display_url" : "bit.ly\/1b2aLoU"
    } ]
  },
  "geo" : { },
  "id_str" : "434277348998127616",
  "text" : "RT @ProfessMoravec: now blogged, #corpusmooc week 3, more lessons for the online prof  + the temptation to slack sets in #MOOCinPublic http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpusmooc",
        "indices" : [ 13, 24 ]
      }, {
        "text" : "MOOCinPublic",
        "indices" : [ 101, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/YqLKWsWkG3",
        "expanded_url" : "http:\/\/bit.ly\/1b2aLoU",
        "display_url" : "bit.ly\/1b2aLoU"
      } ]
    },
    "geo" : { },
    "id_str" : "434274831459053568",
    "text" : "now blogged, #corpusmooc week 3, more lessons for the online prof  + the temptation to slack sets in #MOOCinPublic http:\/\/t.co\/YqLKWsWkG3",
    "id" : 434274831459053568,
    "created_at" : "2014-02-14 10:36:02 +0000",
    "user" : {
      "name" : "Michelle Moravec",
      "screen_name" : "ProfessMoravec",
      "protected" : false,
      "id_str" : "369529173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751214483113013248\/qxxQX7mg_normal.jpg",
      "id" : 369529173,
      "verified" : false
    }
  },
  "id" : 434277348998127616,
  "created_at" : "2014-02-14 10:46:03 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "openpandora",
      "indices" : [ 51, 63 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434271884063301632",
  "geo" : { },
  "id_str" : "434273725630799873",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson depends e.g. i waited 3 years! for #openpandora; tech specs dated but nothing beats it as a package and community behind it",
  "id" : 434273725630799873,
  "in_reply_to_status_id" : 434271884063301632,
  "created_at" : "2014-02-14 10:31:39 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 3, 17 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/0b11z3h9rf",
      "expanded_url" : "http:\/\/www.nytimes.com\/2014\/02\/14\/education\/free-online-university-receives-accreditation-in-time-for-graduating-class-of-7.html",
      "display_url" : "nytimes.com\/2014\/02\/14\/edu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "434272498788864000",
  "text" : "RT @audreywatters: University of the People (free, online nonprofit) receives accreditation http:\/\/t.co\/0b11z3h9rf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/0b11z3h9rf",
        "expanded_url" : "http:\/\/www.nytimes.com\/2014\/02\/14\/education\/free-online-university-receives-accreditation-in-time-for-graduating-class-of-7.html",
        "display_url" : "nytimes.com\/2014\/02\/14\/edu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "434153049490063360",
    "text" : "University of the People (free, online nonprofit) receives accreditation http:\/\/t.co\/0b11z3h9rf",
    "id" : 434153049490063360,
    "created_at" : "2014-02-14 02:32:07 +0000",
    "user" : {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "protected" : false,
      "id_str" : "25388528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711668009723498496\/pauFZsdv_normal.jpg",
      "id" : 25388528,
      "verified" : false
    }
  },
  "id" : 434272498788864000,
  "created_at" : "2014-02-14 10:26:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "edulang",
      "screen_name" : "edulang",
      "indices" : [ 3, 11 ],
      "id_str" : "2877002950",
      "id" : 2877002950
    }, {
      "name" : "Jack Askew",
      "screen_name" : "eslonlinejack",
      "indices" : [ 59, 73 ],
      "id_str" : "1513170398",
      "id" : 1513170398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/qsHbArjO4k",
      "expanded_url" : "http:\/\/www.teachingeslonline.com\/build-website-wordpress",
      "display_url" : "teachingeslonline.com\/build-website-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "434270568100405248",
  "text" : "RT @Edulang: Don't Have a Teaching Website Yet? [blog] by (@eslonlinejack): http:\/\/t.co\/qsHbArjO4k",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jack Askew",
        "screen_name" : "eslonlinejack",
        "indices" : [ 46, 60 ],
        "id_str" : "1513170398",
        "id" : 1513170398
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/qsHbArjO4k",
        "expanded_url" : "http:\/\/www.teachingeslonline.com\/build-website-wordpress",
        "display_url" : "teachingeslonline.com\/build-website-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "434269402859462656",
    "text" : "Don't Have a Teaching Website Yet? [blog] by (@eslonlinejack): http:\/\/t.co\/qsHbArjO4k",
    "id" : 434269402859462656,
    "created_at" : "2014-02-14 10:14:28 +0000",
    "user" : {
      "name" : "WordTov",
      "screen_name" : "wordtov",
      "protected" : false,
      "id_str" : "236921161",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/612985595749617664\/YMxtQC1g_normal.png",
      "id" : 236921161,
      "verified" : false
    }
  },
  "id" : 434270568100405248,
  "created_at" : "2014-02-14 10:19:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Divya Madhavan",
      "screen_name" : "_divyamadhavan",
      "indices" : [ 56, 71 ],
      "id_str" : "408492806",
      "id" : 408492806
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/sJE0lsZjeK",
      "expanded_url" : "http:\/\/itdi.pro\/blog\/2014\/02\/14\/classroom-management-divya\/",
      "display_url" : "itdi.pro\/blog\/2014\/02\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "434252154690207744",
  "text" : "Classroom Management - Divya: http:\/\/t.co\/sJE0lsZjeK by @_divyamadhavan",
  "id" : 434252154690207744,
  "created_at" : "2014-02-14 09:05:56 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TESOL France",
      "screen_name" : "TESOLFrance",
      "indices" : [ 3, 15 ],
      "id_str" : "70341872",
      "id" : 70341872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 143, 144 ],
      "url" : "http:\/\/t.co\/xMlonScupD",
      "expanded_url" : "http:\/\/bit.ly\/1lq03SX",
      "display_url" : "bit.ly\/1lq03SX"
    } ]
  },
  "geo" : { },
  "id_str" : "434250607420264448",
  "text" : "RT @TESOLFrance: Call for Speaker Proposals: TESOL France Young Learners &amp; Teens Day! Event date: May 17th in Paris. Deadline: Feb 28. http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/xMlonScupD",
        "expanded_url" : "http:\/\/bit.ly\/1lq03SX",
        "display_url" : "bit.ly\/1lq03SX"
      } ]
    },
    "geo" : { },
    "id_str" : "434248810856869888",
    "text" : "Call for Speaker Proposals: TESOL France Young Learners &amp; Teens Day! Event date: May 17th in Paris. Deadline: Feb 28. http:\/\/t.co\/xMlonScupD",
    "id" : 434248810856869888,
    "created_at" : "2014-02-14 08:52:39 +0000",
    "user" : {
      "name" : "TESOL France",
      "screen_name" : "TESOLFrance",
      "protected" : false,
      "id_str" : "70341872",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1789787647\/TESOL_France_logo_normal.jpg",
      "id" : 70341872,
      "verified" : false
    }
  },
  "id" : 434250607420264448,
  "created_at" : "2014-02-14 08:59:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434241578757271552",
  "geo" : { },
  "id_str" : "434249589722337281",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson oh yeah sounds good, what happened last challenge?",
  "id" : 434249589722337281,
  "in_reply_to_status_id" : 434241578757271552,
  "created_at" : "2014-02-14 08:55:44 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "piratebox",
      "indices" : [ 59, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "434240783214850048",
  "text" : "nice! continuing steps towards less photocopying for class #piratebox ftw :)",
  "id" : 434240783214850048,
  "created_at" : "2014-02-14 08:20:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "indices" : [ 3, 11 ],
      "id_str" : "20650366",
      "id" : 20650366
    }, {
      "name" : "The-Round ELT",
      "screen_name" : "wetheround",
      "indices" : [ 91, 102 ],
      "id_str" : "281918842",
      "id" : 281918842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/4RWHMJXtB9",
      "expanded_url" : "http:\/\/the-round.com\/2014\/02\/help-us-make-the-first-unofficial-iatefltesol-t-shirt\/",
      "display_url" : "the-round.com\/2014\/02\/help-u\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "434201781246390273",
  "text" : "RT @seburnt: Can you make a wittier ELT t-shirt slogan than me? http:\/\/t.co\/4RWHMJXtB9 via @wetheround",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The-Round ELT",
        "screen_name" : "wetheround",
        "indices" : [ 78, 89 ],
        "id_str" : "281918842",
        "id" : 281918842
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 73 ],
        "url" : "http:\/\/t.co\/4RWHMJXtB9",
        "expanded_url" : "http:\/\/the-round.com\/2014\/02\/help-us-make-the-first-unofficial-iatefltesol-t-shirt\/",
        "display_url" : "the-round.com\/2014\/02\/help-u\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "434196707530653696",
    "text" : "Can you make a wittier ELT t-shirt slogan than me? http:\/\/t.co\/4RWHMJXtB9 via @wetheround",
    "id" : 434196707530653696,
    "created_at" : "2014-02-14 05:25:36 +0000",
    "user" : {
      "name" : "Tyson Seburn",
      "screen_name" : "seburnt",
      "protected" : false,
      "id_str" : "20650366",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/743248377563971584\/9d9xlHlz_normal.jpg",
      "id" : 20650366,
      "verified" : false
    }
  },
  "id" : 434201781246390273,
  "created_at" : "2014-02-14 05:45:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "European Tribune",
      "screen_name" : "EuropeanTribune",
      "indices" : [ 44, 60 ],
      "id_str" : "568326306",
      "id" : 568326306
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/1DLTLCp0Rz",
      "expanded_url" : "http:\/\/www.eurotrib.com\/story\/2014\/2\/8\/102017\/2129",
      "display_url" : "eurotrib.com\/story\/2014\/2\/8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "434073472579280896",
  "text" : "Propaganda Works http:\/\/t.co\/1DLTLCp0Rz via @EuropeanTribune",
  "id" : 434073472579280896,
  "created_at" : "2014-02-13 21:15:55 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "indices" : [ 3, 14 ],
      "id_str" : "152051625",
      "id" : 152051625
    }, {
      "name" : "Kate Wiles",
      "screen_name" : "katemond",
      "indices" : [ 35, 44 ],
      "id_str" : "14315917",
      "id" : 14315917
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/4YgActFFLp",
      "expanded_url" : "http:\/\/bit.ly\/1jyGZAo",
      "display_url" : "bit.ly\/1jyGZAo"
    } ]
  },
  "geo" : { },
  "id_str" : "434023086602850304",
  "text" : "RT @heatherfro: the very excellent @katemond has written a history of fuck, to make up for the io9 post that went viral http:\/\/t.co\/4YgActF\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kate Wiles",
        "screen_name" : "katemond",
        "indices" : [ 19, 28 ],
        "id_str" : "14315917",
        "id" : 14315917
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/4YgActFFLp",
        "expanded_url" : "http:\/\/bit.ly\/1jyGZAo",
        "display_url" : "bit.ly\/1jyGZAo"
      } ]
    },
    "geo" : { },
    "id_str" : "433912984453136385",
    "text" : "the very excellent @katemond has written a history of fuck, to make up for the io9 post that went viral http:\/\/t.co\/4YgActFFLp",
    "id" : 433912984453136385,
    "created_at" : "2014-02-13 10:38:11 +0000",
    "user" : {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "protected" : false,
      "id_str" : "152051625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/688767277022494720\/KMrzOBc1_normal.jpg",
      "id" : 152051625,
      "verified" : false
    }
  },
  "id" : 434023086602850304,
  "created_at" : "2014-02-13 17:55:42 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "434001463149600768",
  "geo" : { },
  "id_str" : "434007491794329600",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco yes i did the one on pos not checked the others yet",
  "id" : 434007491794329600,
  "in_reply_to_status_id" : 434001463149600768,
  "created_at" : "2014-02-13 16:53:44 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/UqEcdJGRfD",
      "expanded_url" : "http:\/\/www.beaugrande.com\/WiddowsonPretexts.htm",
      "display_url" : "beaugrande.com\/WiddowsonPrete\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433965324455534593",
  "text" : "Some responses from other prominent victims were, erm, considerably less adaptable to public citation - Beaugrande\nhttp:\/\/t.co\/UqEcdJGRfD",
  "id" : 433965324455534593,
  "created_at" : "2014-02-13 14:06:10 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/T59kvGjuSA",
      "expanded_url" : "http:\/\/www.beaugrande.com\/WiddowsonianDiscourse.htm",
      "display_url" : "beaugrande.com\/WiddowsonianDi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433961009393328128",
  "text" : "I am intrigued by the prospect of Widdowson knowing what a \u2018grammar\u2019 is better than Halliday - Beaugrande http:\/\/t.co\/T59kvGjuSA",
  "id" : 433961009393328128,
  "created_at" : "2014-02-13 13:49:01 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 4, 8 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433960930951442433",
  "text" : "for #elt the knockabout btw Widdowson and Beaugrande is imo more entertaining than say Chomsky vs the rest :) some tweets to demonstrate&gt;&gt;&gt;",
  "id" : 433960930951442433,
  "created_at" : "2014-02-13 13:48:43 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 0, 11 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433586173076705280",
  "geo" : { },
  "id_str" : "433957166853013504",
  "in_reply_to_user_id" : 300734173,
  "text" : "@lexicoloco that's a great site Diane, posted it on G+ comm :)",
  "id" : 433957166853013504,
  "in_reply_to_status_id" : 433586173076705280,
  "created_at" : "2014-02-13 13:33:45 +0000",
  "in_reply_to_screen_name" : "lexicoloco",
  "in_reply_to_user_id_str" : "300734173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "indices" : [ 3, 14 ],
      "id_str" : "300734173",
      "id" : 300734173
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpus",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/NVsEdrEyqZ",
      "expanded_url" : "http:\/\/www.thegrammarlab.com\/?p=343",
      "display_url" : "thegrammarlab.com\/?p=343"
    } ]
  },
  "geo" : { },
  "id_str" : "433951894214828032",
  "text" : "RT @lexicoloco: http:\/\/t.co\/NVsEdrEyqZ When did you last see quicksand in a film? Quicksand in film and language over time. Thought-provoki\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpus",
        "indices" : [ 126, 133 ]
      } ],
      "urls" : [ {
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/NVsEdrEyqZ",
        "expanded_url" : "http:\/\/www.thegrammarlab.com\/?p=343",
        "display_url" : "thegrammarlab.com\/?p=343"
      } ]
    },
    "geo" : { },
    "id_str" : "433586173076705280",
    "text" : "http:\/\/t.co\/NVsEdrEyqZ When did you last see quicksand in a film? Quicksand in film and language over time. Thought-provoking #corpus study.",
    "id" : 433586173076705280,
    "created_at" : "2014-02-12 12:59:33 +0000",
    "user" : {
      "name" : "Diane Nicholls",
      "screen_name" : "lexicoloco",
      "protected" : false,
      "id_str" : "300734173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2403500097\/3nmx3kjaycyoc7irwe6s_normal.jpeg",
      "id" : 300734173,
      "verified" : false
    }
  },
  "id" : 433951894214828032,
  "created_at" : "2014-02-13 13:12:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 20, 31 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/T59kvGjuSA",
      "expanded_url" : "http:\/\/www.beaugrande.com\/WiddowsonianDiscourse.htm",
      "display_url" : "beaugrande.com\/WiddowsonianDi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433945971882332160",
  "text" : "this might interest #corpusmooc a corpus analysis of the discourse of a corpus critique http:\/\/t.co\/T59kvGjuSA :)",
  "id" : 433945971882332160,
  "created_at" : "2014-02-13 12:49:16 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Shepherd",
      "screen_name" : "samshep",
      "indices" : [ 0, 8 ],
      "id_str" : "20146035",
      "id" : 20146035
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 70, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/gnEFqIwmh8",
      "expanded_url" : "https:\/\/plus.google.com\/u\/0\/communities\/101266284417587206243",
      "display_url" : "plus.google.com\/u\/0\/communitie\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "433854821771141121",
  "geo" : { },
  "id_str" : "433941167994974210",
  "in_reply_to_user_id" : 20146035,
  "text" : "@samshep if u are into language learn\/teach &amp; feeling lost in the #corpusmooc u can bring discussions to G+ comm https:\/\/t.co\/gnEFqIwmh8 :)",
  "id" : 433941167994974210,
  "in_reply_to_status_id" : 433854821771141121,
  "created_at" : "2014-02-13 12:30:11 +0000",
  "in_reply_to_screen_name" : "samshep",
  "in_reply_to_user_id_str" : "20146035",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Robinson",
      "screen_name" : "nmkrobinson",
      "indices" : [ 3, 15 ],
      "id_str" : "20425399",
      "id" : 20425399
    }, {
      "name" : "ELTjam",
      "screen_name" : "eltjam",
      "indices" : [ 58, 65 ],
      "id_str" : "1356363686",
      "id" : 1356363686
    }, {
      "name" : "Scott Thornbury",
      "screen_name" : "thornburyscott",
      "indices" : [ 82, 97 ],
      "id_str" : "23090474",
      "id" : 23090474
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "esl",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 125, 140 ],
      "url" : "http:\/\/t.co\/I1p3LvYmF1",
      "expanded_url" : "http:\/\/www.eltjam.com\/who-ordered-the-mcnuggets\/",
      "display_url" : "eltjam.com\/who-ordered-th\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433940045721272320",
  "text" : "RT @nmkrobinson: Absolutely thrilled to feature our first @eltjam guest post from @thornburyscott Who Ordered the McNuggets? http:\/\/t.co\/I1\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ELTjam",
        "screen_name" : "eltjam",
        "indices" : [ 41, 48 ],
        "id_str" : "1356363686",
        "id" : 1356363686
      }, {
        "name" : "Scott Thornbury",
        "screen_name" : "thornburyscott",
        "indices" : [ 65, 80 ],
        "id_str" : "23090474",
        "id" : 23090474
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "elt",
        "indices" : [ 131, 135 ]
      }, {
        "text" : "esl",
        "indices" : [ 136, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/I1p3LvYmF1",
        "expanded_url" : "http:\/\/www.eltjam.com\/who-ordered-the-mcnuggets\/",
        "display_url" : "eltjam.com\/who-ordered-th\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "433937326448717824",
    "text" : "Absolutely thrilled to feature our first @eltjam guest post from @thornburyscott Who Ordered the McNuggets? http:\/\/t.co\/I1p3LvYmF1 #elt #esl",
    "id" : 433937326448717824,
    "created_at" : "2014-02-13 12:14:55 +0000",
    "user" : {
      "name" : "Nick Robinson",
      "screen_name" : "nmkrobinson",
      "protected" : false,
      "id_str" : "20425399",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/706797940669599744\/6lTpszWm_normal.jpg",
      "id" : 20425399,
      "verified" : false
    }
  },
  "id" : 433940045721272320,
  "created_at" : "2014-02-13 12:25:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Shepherd",
      "screen_name" : "samshep",
      "indices" : [ 3, 11 ],
      "id_str" : "20146035",
      "id" : 20146035
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusMOOC",
      "indices" : [ 13, 24 ]
    } ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/TidQs94P9S",
      "expanded_url" : "http:\/\/wp.me\/pZQ5N-1fi",
      "display_url" : "wp.me\/pZQ5N-1fi"
    } ]
  },
  "geo" : { },
  "id_str" : "433937318156963840",
  "text" : "RT @samshep: #corpusMOOC http:\/\/t.co\/TidQs94P9S",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpusMOOC",
        "indices" : [ 0, 11 ]
      } ],
      "urls" : [ {
        "indices" : [ 12, 34 ],
        "url" : "http:\/\/t.co\/TidQs94P9S",
        "expanded_url" : "http:\/\/wp.me\/pZQ5N-1fi",
        "display_url" : "wp.me\/pZQ5N-1fi"
      } ]
    },
    "geo" : { },
    "id_str" : "433854821771141121",
    "text" : "#corpusMOOC http:\/\/t.co\/TidQs94P9S",
    "id" : 433854821771141121,
    "created_at" : "2014-02-13 06:47:04 +0000",
    "user" : {
      "name" : "Sam Shepherd",
      "screen_name" : "samshep",
      "protected" : false,
      "id_str" : "20146035",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/740863245880197120\/_BaMJ5Hf_normal.jpg",
      "id" : 20146035,
      "verified" : false
    }
  },
  "id" : 433937318156963840,
  "created_at" : "2014-02-13 12:14:53 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "P\u00E9rez-Paredes",
      "screen_name" : "perezparedes",
      "indices" : [ 3, 16 ],
      "id_str" : "28528850",
      "id" : 28528850
    }, {
      "name" : "Scoop.it",
      "screen_name" : "scoopit",
      "indices" : [ 64, 72 ],
      "id_str" : "209484168",
      "id" : 209484168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/yP08Dg3EDg",
      "expanded_url" : "http:\/\/sco.lt\/5acGKP",
      "display_url" : "sco.lt\/5acGKP"
    } ]
  },
  "geo" : { },
  "id_str" : "433909776062636032",
  "text" : "RT @perezparedes: Dictionary use by English language learners | @scoopit http:\/\/t.co\/yP08Dg3EDg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.scoop.it\" rel=\"nofollow\"\u003EScoop.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Scoop.it",
        "screen_name" : "scoopit",
        "indices" : [ 46, 54 ],
        "id_str" : "209484168",
        "id" : 209484168
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/yP08Dg3EDg",
        "expanded_url" : "http:\/\/sco.lt\/5acGKP",
        "display_url" : "sco.lt\/5acGKP"
      } ]
    },
    "geo" : { },
    "id_str" : "433842852658159617",
    "text" : "Dictionary use by English language learners | @scoopit http:\/\/t.co\/yP08Dg3EDg",
    "id" : 433842852658159617,
    "created_at" : "2014-02-13 05:59:31 +0000",
    "user" : {
      "name" : "P\u00E9rez-Paredes",
      "screen_name" : "perezparedes",
      "protected" : false,
      "id_str" : "28528850",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746249968139313153\/2-1yieTh_normal.jpg",
      "id" : 28528850,
      "verified" : false
    }
  },
  "id" : 433909776062636032,
  "created_at" : "2014-02-13 10:25:26 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nagehan Tunar",
      "screen_name" : "stiiiv",
      "indices" : [ 3, 10 ],
      "id_str" : "799058600",
      "id" : 799058600
    }, {
      "name" : "Cambridge ELT",
      "screen_name" : "CambridgeUPELT",
      "indices" : [ 137, 140 ],
      "id_str" : "73107903",
      "id" : 73107903
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elt",
      "indices" : [ 107, 111 ]
    }, {
      "text" : "tefl",
      "indices" : [ 112, 117 ]
    }, {
      "text" : "eltchat",
      "indices" : [ 118, 126 ]
    }, {
      "text" : "tleap",
      "indices" : [ 127, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/KTGHT4892Q",
      "expanded_url" : "http:\/\/ow.ly\/tsmOA",
      "display_url" : "ow.ly\/tsmOA"
    } ]
  },
  "geo" : { },
  "id_str" : "433727994390396928",
  "text" : "RT @stiiiv: The Teacher Research Programme is now accepting submissions. Apply now: http:\/\/t.co\/KTGHT4892Q #elt #tefl #eltchat #tleap RT @C\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/seesmic.com\/\" rel=\"nofollow\"\u003ESeesmic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Cambridge ELT",
        "screen_name" : "CambridgeUPELT",
        "indices" : [ 125, 140 ],
        "id_str" : "73107903",
        "id" : 73107903
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "elt",
        "indices" : [ 95, 99 ]
      }, {
        "text" : "tefl",
        "indices" : [ 100, 105 ]
      }, {
        "text" : "eltchat",
        "indices" : [ 106, 114 ]
      }, {
        "text" : "tleap",
        "indices" : [ 115, 121 ]
      } ],
      "urls" : [ {
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/KTGHT4892Q",
        "expanded_url" : "http:\/\/ow.ly\/tsmOA",
        "display_url" : "ow.ly\/tsmOA"
      } ]
    },
    "geo" : { },
    "id_str" : "433726740696137729",
    "text" : "The Teacher Research Programme is now accepting submissions. Apply now: http:\/\/t.co\/KTGHT4892Q #elt #tefl #eltchat #tleap RT @CambridgeUPELT",
    "id" : 433726740696137729,
    "created_at" : "2014-02-12 22:18:07 +0000",
    "user" : {
      "name" : "Steve Kirk",
      "screen_name" : "stiivkirk",
      "protected" : false,
      "id_str" : "69068757",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000758179566\/b805015edd787781185f28a0aa2d7969_normal.png",
      "id" : 69068757,
      "verified" : false
    }
  },
  "id" : 433727994390396928,
  "created_at" : "2014-02-12 22:23:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 66, 82 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/DvAn2IAxEn",
      "expanded_url" : "http:\/\/wp.me\/p4gDtp-A",
      "display_url" : "wp.me\/p4gDtp-A"
    } ]
  },
  "geo" : { },
  "id_str" : "433701487466672128",
  "text" : "Part 9: neo-liberalism and solutionism http:\/\/t.co\/DvAn2IAxEn via @wordpressdotcom",
  "id" : 433701487466672128,
  "created_at" : "2014-02-12 20:37:47 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Hall",
      "screen_name" : "nathanghall",
      "indices" : [ 0, 12 ],
      "id_str" : "192437743",
      "id" : 192437743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433673097074319360",
  "geo" : { },
  "id_str" : "433676721208823809",
  "in_reply_to_user_id" : 192437743,
  "text" : "@nathanghall rofl :)",
  "id" : 433676721208823809,
  "in_reply_to_status_id" : 433673097074319360,
  "created_at" : "2014-02-12 18:59:22 +0000",
  "in_reply_to_screen_name" : "nathanghall",
  "in_reply_to_user_id_str" : "192437743",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Hardie",
      "screen_name" : "HardieResearch",
      "indices" : [ 0, 15 ],
      "id_str" : "970452764",
      "id" : 970452764
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 33, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433667225497509888",
  "in_reply_to_user_id" : 970452764,
  "text" : "@HardieResearch cheers for RT of #corpusmooc reggae rehearsals :)",
  "id" : 433667225497509888,
  "created_at" : "2014-02-12 18:21:38 +0000",
  "in_reply_to_screen_name" : "HardieResearch",
  "in_reply_to_user_id_str" : "970452764",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "indices" : [ 0, 9 ],
      "id_str" : "167020390",
      "id" : 167020390
    }, {
      "name" : "Andrew Hardie",
      "screen_name" : "HardieResearch",
      "indices" : [ 10, 25 ],
      "id_str" : "970452764",
      "id" : 970452764
    }, {
      "name" : "Kat Gupta",
      "screen_name" : "mixosaurus",
      "indices" : [ 26, 37 ],
      "id_str" : "21158543",
      "id" : 21158543
    }, {
      "name" : "heather froehlich",
      "screen_name" : "heatherfro",
      "indices" : [ 38, 49 ],
      "id_str" : "152051625",
      "id" : 152051625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433664016490045441",
  "geo" : { },
  "id_str" : "433665807487225856",
  "in_reply_to_user_id" : 167020390,
  "text" : "@antlabjp @HardieResearch @mixosaurus @heatherfro a boss level - multimodal tagged corpus? :)",
  "id" : 433665807487225856,
  "in_reply_to_status_id" : 433664016490045441,
  "created_at" : "2014-02-12 18:16:00 +0000",
  "in_reply_to_screen_name" : "antlabjp",
  "in_reply_to_user_id_str" : "167020390",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/Sz4zZRH8n7",
      "expanded_url" : "http:\/\/tinyurl.com\/pq929en",
      "display_url" : "tinyurl.com\/pq929en"
    } ]
  },
  "geo" : { },
  "id_str" : "433524242672779264",
  "text" : "RT @medialens: Aussie TV dares to show the real Israeli occupation http:\/\/t.co\/Sz4zZRH8n7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/Sz4zZRH8n7",
        "expanded_url" : "http:\/\/tinyurl.com\/pq929en",
        "display_url" : "tinyurl.com\/pq929en"
      } ]
    },
    "geo" : { },
    "id_str" : "433523584481251328",
    "text" : "Aussie TV dares to show the real Israeli occupation http:\/\/t.co\/Sz4zZRH8n7",
    "id" : 433523584481251328,
    "created_at" : "2014-02-12 08:50:51 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 433524242672779264,
  "created_at" : "2014-02-12 08:53:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil Longwell",
      "screen_name" : "teacherphili",
      "indices" : [ 0, 13 ],
      "id_str" : "67863264",
      "id" : 67863264
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433392990623891456",
  "geo" : { },
  "id_str" : "433498349954551808",
  "in_reply_to_user_id" : 67863264,
  "text" : "@teacherphili :)",
  "id" : 433498349954551808,
  "in_reply_to_status_id" : 433392990623891456,
  "created_at" : "2014-02-12 07:10:35 +0000",
  "in_reply_to_screen_name" : "teacherphili",
  "in_reply_to_user_id_str" : "67863264",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Aisha Brown",
      "screen_name" : "amyaishab",
      "indices" : [ 0, 10 ],
      "id_str" : "900029641",
      "id" : 900029641
    }, {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "indices" : [ 37, 46 ],
      "id_str" : "167020390",
      "id" : 167020390
    }, {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "indices" : [ 51, 63 ],
      "id_str" : "849729062",
      "id" : 849729062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 88, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/U9axBBFoHN",
      "expanded_url" : "https:\/\/googledrive.com\/host\/0B7FW2BYaBgeiczNDWTJpZFoyVkE\/search-regex-corpusmooc.mp3",
      "display_url" : "googledrive.com\/host\/0B7FW2BYa\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "433369895913660416",
  "geo" : { },
  "id_str" : "433497639439454208",
  "in_reply_to_user_id" : 900029641,
  "text" : "@amyaishab thanks for RT did u catch @antlabjp and @TonyMcEnery skanking it up in their #corpusmooc reggae band? https:\/\/t.co\/U9axBBFoHN :)",
  "id" : 433497639439454208,
  "in_reply_to_status_id" : 433369895913660416,
  "created_at" : "2014-02-12 07:07:45 +0000",
  "in_reply_to_screen_name" : "amyaishab",
  "in_reply_to_user_id_str" : "900029641",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil Longwell",
      "screen_name" : "teacherphili",
      "indices" : [ 0, 13 ],
      "id_str" : "67863264",
      "id" : 67863264
    }, {
      "name" : "john johnston",
      "screen_name" : "johnjohnston",
      "indices" : [ 75, 88 ],
      "id_str" : "7484192",
      "id" : 7484192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/6ZmFYlPy91",
      "expanded_url" : "http:\/\/www.johnjohnston.info\/blog\/?e=2383",
      "display_url" : "johnjohnston.info\/blog\/?e=2383"
    }, {
      "indices" : [ 125, 147 ],
      "url" : "http:\/\/t.co\/jXBzqIhlJT",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=1ahZO9dCf10",
      "display_url" : "youtube.com\/watch?v=1ahZO9\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "433354344117719042",
  "geo" : { },
  "id_str" : "433356370394365952",
  "in_reply_to_user_id" : 67863264,
  "text" : "@teacherphili hey phil have a lk at cde press remix button &amp; c link to @johnjohnston http:\/\/t.co\/6ZmFYlPy91 &amp;foreyes http:\/\/t.co\/jXBzqIhlJT",
  "id" : 433356370394365952,
  "in_reply_to_status_id" : 433354344117719042,
  "created_at" : "2014-02-11 21:46:24 +0000",
  "in_reply_to_screen_name" : "teacherphili",
  "in_reply_to_user_id_str" : "67863264",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Moravec",
      "screen_name" : "ProfessMoravec",
      "indices" : [ 0, 15 ],
      "id_str" : "369529173",
      "id" : 369529173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433279499484925952",
  "geo" : { },
  "id_str" : "433280583683145728",
  "in_reply_to_user_id" : 369529173,
  "text" : "@ProfessMoravec nice antconc flow diagram :)",
  "id" : 433280583683145728,
  "in_reply_to_status_id" : 433279499484925952,
  "created_at" : "2014-02-11 16:45:15 +0000",
  "in_reply_to_screen_name" : "ProfessMoravec",
  "in_reply_to_user_id_str" : "369529173",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony McEnery",
      "screen_name" : "TonyMcEnery",
      "indices" : [ 0, 12 ],
      "id_str" : "849729062",
      "id" : 849729062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433277064850837504",
  "geo" : { },
  "id_str" : "433277488974680064",
  "in_reply_to_user_id" : 849729062,
  "text" : "@TonyMcEnery thank you and your team for a fun course :)",
  "id" : 433277488974680064,
  "in_reply_to_status_id" : 433277064850837504,
  "created_at" : "2014-02-11 16:32:57 +0000",
  "in_reply_to_screen_name" : "TonyMcEnery",
  "in_reply_to_user_id_str" : "849729062",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Andrews",
      "screen_name" : "patrickelt",
      "indices" : [ 0, 11 ],
      "id_str" : "2292503990",
      "id" : 2292503990
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433270961329033216",
  "geo" : { },
  "id_str" : "433274135150465025",
  "in_reply_to_user_id" : 2292503990,
  "text" : "@patrickelt is there a link?",
  "id" : 433274135150465025,
  "in_reply_to_status_id" : 433270961329033216,
  "created_at" : "2014-02-11 16:19:38 +0000",
  "in_reply_to_screen_name" : "patrickelt",
  "in_reply_to_user_id_str" : "2292503990",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 4, 15 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/D8owMgeBiu",
      "expanded_url" : "https:\/\/plus.google.com\/104940199413423400545\/posts\/HyPGT1nF5cX",
      "display_url" : "plus.google.com\/10494019941342\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "433272977874882561",
  "text" : "one #corpusmooc student finds the picturebingo but then promptly forgets where, can you help her? https:\/\/t.co\/D8owMgeBiu",
  "id" : 433272977874882561,
  "created_at" : "2014-02-11 16:15:02 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 83, 93 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusMOOC",
      "indices" : [ 97, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/UygNYMyofs",
      "expanded_url" : "http:\/\/www.carbonbrief.org\/blog\/2014\/02\/analysis-how-climate-change-features-in-newspaper-coverage-of-the-uk%E2%80%99s-floods\/",
      "display_url" : "carbonbrief.org\/blog\/2014\/02\/a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432913153639215105",
  "text" : "Analysis: How climate change features in newspaper coverage of the UK\u2019s floods h\/t @medialens cc #corpusMOOC http:\/\/t.co\/UygNYMyofs \u2026",
  "id" : 432913153639215105,
  "created_at" : "2014-02-10 16:25:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol Goodey",
      "screen_name" : "cgoodey",
      "indices" : [ 3, 11 ],
      "id_str" : "26606833",
      "id" : 26606833
    }, {
      "name" : "Vedrana Vojkovi\u0107",
      "screen_name" : "Ven_VVE",
      "indices" : [ 130, 138 ],
      "id_str" : "270839603",
      "id" : 270839603
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusMOOC",
      "indices" : [ 114, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/M5Qvo88hcY",
      "expanded_url" : "http:\/\/wp.me\/p2itcX-i9",
      "display_url" : "wp.me\/p2itcX-i9"
    } ]
  },
  "geo" : { },
  "id_str" : "432862060037570560",
  "text" : "RT @cgoodey: MOOCing and Learning: Corpora, Concordancing and Conversations http:\/\/t.co\/M5Qvo88hcY Impressions of #corpusMOOC for @Ven_VVE \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vedrana Vojkovi\u0107",
        "screen_name" : "Ven_VVE",
        "indices" : [ 117, 125 ],
        "id_str" : "270839603",
        "id" : 270839603
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpusMOOC",
        "indices" : [ 101, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/M5Qvo88hcY",
        "expanded_url" : "http:\/\/wp.me\/p2itcX-i9",
        "display_url" : "wp.me\/p2itcX-i9"
      } ]
    },
    "geo" : { },
    "id_str" : "432857868455251968",
    "text" : "MOOCing and Learning: Corpora, Concordancing and Conversations http:\/\/t.co\/M5Qvo88hcY Impressions of #corpusMOOC for @Ven_VVE :-)",
    "id" : 432857868455251968,
    "created_at" : "2014-02-10 12:45:32 +0000",
    "user" : {
      "name" : "Carol Goodey",
      "screen_name" : "cgoodey",
      "protected" : false,
      "id_str" : "26606833",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/739764539839926273\/EtEpZHsA_normal.jpg",
      "id" : 26606833,
      "verified" : false
    }
  },
  "id" : 432862060037570560,
  "created_at" : "2014-02-10 13:02:11 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Phipps",
      "screen_name" : "lousylinguist",
      "indices" : [ 0, 14 ],
      "id_str" : "48459936",
      "id" : 48459936
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 53, 64 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "432544848902508544",
  "geo" : { },
  "id_str" : "432633810753052672",
  "in_reply_to_user_id" : 48459936,
  "text" : "@lousylinguist lordy this guy really needs to do the #corpusmooc!",
  "id" : 432633810753052672,
  "in_reply_to_status_id" : 432544848902508544,
  "created_at" : "2014-02-09 21:55:13 +0000",
  "in_reply_to_screen_name" : "lousylinguist",
  "in_reply_to_user_id_str" : "48459936",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe McVeigh",
      "screen_name" : "EvilJoeMcVeigh",
      "indices" : [ 3, 18 ],
      "id_str" : "1327355143",
      "id" : 1327355143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/eAhH52iQam",
      "expanded_url" : "http:\/\/andreadallover.com\/2014\/02\/09\/dont-go-down-the-google-books-garden-path\/",
      "display_url" : "andreadallover.com\/2014\/02\/09\/don\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432521468057251840",
  "text" : "RT @EvilJoeMcVeigh: Here's my thoughts on Google's Ngram Viewer. Basically: Proceed with caution and don't jump to conclusions. http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/eAhH52iQam",
        "expanded_url" : "http:\/\/andreadallover.com\/2014\/02\/09\/dont-go-down-the-google-books-garden-path\/",
        "display_url" : "andreadallover.com\/2014\/02\/09\/don\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "432518853969469440",
    "text" : "Here's my thoughts on Google's Ngram Viewer. Basically: Proceed with caution and don't jump to conclusions. http:\/\/t.co\/eAhH52iQam",
    "id" : 432518853969469440,
    "created_at" : "2014-02-09 14:18:25 +0000",
    "user" : {
      "name" : "Joe McVeigh",
      "screen_name" : "EvilJoeMcVeigh",
      "protected" : false,
      "id_str" : "1327355143",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/633574005530693632\/omOKH3tm_normal.png",
      "id" : 1327355143,
      "verified" : false
    }
  },
  "id" : 432521468057251840,
  "created_at" : "2014-02-09 14:28:48 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tuba",
      "screen_name" : "springrose12",
      "indices" : [ 0, 13 ],
      "id_str" : "144232169",
      "id" : 144232169
    }, {
      "name" : "Burcu Akyol",
      "screen_name" : "burcuakyol",
      "indices" : [ 14, 25 ],
      "id_str" : "25390789",
      "id" : 25390789
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/B6A0LvfLLA",
      "expanded_url" : "http:\/\/skrashen.blogspot.gr\/2014\/01\/krashenpresentation-january-17-2014-01.html",
      "display_url" : "skrashen.blogspot.gr\/2014\/01\/krashe\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "432509170030739457",
  "geo" : { },
  "id_str" : "432517010920980480",
  "in_reply_to_user_id" : 144232169,
  "text" : "@springrose12 @burcuakyol krashen has found early literacy negatively affects reading scores (on PIRLS test) http:\/\/t.co\/B6A0LvfLLA",
  "id" : 432517010920980480,
  "in_reply_to_status_id" : 432509170030739457,
  "created_at" : "2014-02-09 14:11:05 +0000",
  "in_reply_to_screen_name" : "springrose12",
  "in_reply_to_user_id_str" : "144232169",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bethany Cagnol",
      "screen_name" : "bethcagnol",
      "indices" : [ 3, 14 ],
      "id_str" : "27641720",
      "id" : 27641720
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IATEFL",
      "indices" : [ 39, 46 ]
    }, {
      "text" : "BESIG",
      "indices" : [ 47, 53 ]
    }, {
      "text" : "ELT",
      "indices" : [ 85, 89 ]
    }, {
      "text" : "TESOL",
      "indices" : [ 120, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 127, 140 ],
      "url" : "http:\/\/t.co\/ztcr80Tp7H",
      "expanded_url" : "http:\/\/www.besig.org\/events\/online\/workshops\/Workshop_35.aspx",
      "display_url" : "besig.org\/events\/online\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432506888279060480",
  "text" : "RT @bethcagnol: I hope you can join my #IATEFL #BESIG webinar on Life Skills for the #ELT Classroom. 3pm GMT \/ 4pm CET. #TESOL http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IATEFL",
        "indices" : [ 23, 30 ]
      }, {
        "text" : "BESIG",
        "indices" : [ 31, 37 ]
      }, {
        "text" : "ELT",
        "indices" : [ 69, 73 ]
      }, {
        "text" : "TESOL",
        "indices" : [ 104, 110 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/ztcr80Tp7H",
        "expanded_url" : "http:\/\/www.besig.org\/events\/online\/workshops\/Workshop_35.aspx",
        "display_url" : "besig.org\/events\/online\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "432505896720023552",
    "text" : "I hope you can join my #IATEFL #BESIG webinar on Life Skills for the #ELT Classroom. 3pm GMT \/ 4pm CET. #TESOL http:\/\/t.co\/ztcr80Tp7H",
    "id" : 432505896720023552,
    "created_at" : "2014-02-09 13:26:56 +0000",
    "user" : {
      "name" : "Bethany Cagnol",
      "screen_name" : "bethcagnol",
      "protected" : false,
      "id_str" : "27641720",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/425969412265373696\/jdqAse11_normal.jpeg",
      "id" : 27641720,
      "verified" : false
    }
  },
  "id" : 432506888279060480,
  "created_at" : "2014-02-09 13:30:52 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Miguel Mendoza",
      "screen_name" : "mike08",
      "indices" : [ 3, 10 ],
      "id_str" : "9444972",
      "id" : 9444972
    }, {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "indices" : [ 82, 95 ],
      "id_str" : "1685397408",
      "id" : 1685397408
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusMOOC",
      "indices" : [ 12, 23 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/8HnhtCI8DV",
      "expanded_url" : "http:\/\/www.mikejharrison.com\/2014\/02\/corpusmooc-week-2-struggling-to-keep-up\/",
      "display_url" : "mikejharrison.com\/2014\/02\/corpus\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "432499272429600768",
  "text" : "RT @mike08: #corpusMOOC week 2 \u2013 struggling to keep up http:\/\/t.co\/8HnhtCI8DV via @harrisonmike",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mike Harrison",
        "screen_name" : "harrisonmike",
        "indices" : [ 70, 83 ],
        "id_str" : "1685397408",
        "id" : 1685397408
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpusMOOC",
        "indices" : [ 0, 11 ]
      } ],
      "urls" : [ {
        "indices" : [ 43, 65 ],
        "url" : "http:\/\/t.co\/8HnhtCI8DV",
        "expanded_url" : "http:\/\/www.mikejharrison.com\/2014\/02\/corpusmooc-week-2-struggling-to-keep-up\/",
        "display_url" : "mikejharrison.com\/2014\/02\/corpus\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "432493659385122816",
    "text" : "#corpusMOOC week 2 \u2013 struggling to keep up http:\/\/t.co\/8HnhtCI8DV via @harrisonmike",
    "id" : 432493659385122816,
    "created_at" : "2014-02-09 12:38:18 +0000",
    "user" : {
      "name" : "Miguel Mendoza",
      "screen_name" : "mike08",
      "protected" : false,
      "id_str" : "9444972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744926259247906816\/pJnxnzSL_normal.jpg",
      "id" : 9444972,
      "verified" : false
    }
  },
  "id" : 432499272429600768,
  "created_at" : "2014-02-09 13:00:36 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donald Clark",
      "screen_name" : "DonaldClark",
      "indices" : [ 3, 15 ],
      "id_str" : "1632891",
      "id" : 1632891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/NKUUVzvGJZ",
      "expanded_url" : "http:\/\/bit.ly\/1ga8pbM",
      "display_url" : "bit.ly\/1ga8pbM"
    }, {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/jTP665j4rL",
      "expanded_url" : "http:\/\/bit.ly\/MA2CBW",
      "display_url" : "bit.ly\/MA2CBW"
    } ]
  },
  "geo" : { },
  "id_str" : "432483330777677824",
  "text" : "RT @DonaldClark: Year of Code implodes as Lottie 'car crash' Dexter forces Emma Mulqueeny to resign http:\/\/t.co\/NKUUVzvGJZ see crash  http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/NKUUVzvGJZ",
        "expanded_url" : "http:\/\/bit.ly\/1ga8pbM",
        "display_url" : "bit.ly\/1ga8pbM"
      }, {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/jTP665j4rL",
        "expanded_url" : "http:\/\/bit.ly\/MA2CBW",
        "display_url" : "bit.ly\/MA2CBW"
      } ]
    },
    "geo" : { },
    "id_str" : "432481715320127490",
    "text" : "Year of Code implodes as Lottie 'car crash' Dexter forces Emma Mulqueeny to resign http:\/\/t.co\/NKUUVzvGJZ see crash  http:\/\/t.co\/jTP665j4rL",
    "id" : 432481715320127490,
    "created_at" : "2014-02-09 11:50:50 +0000",
    "user" : {
      "name" : "Donald Clark",
      "screen_name" : "DonaldClark",
      "protected" : false,
      "id_str" : "1632891",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/513085530695663616\/BfWK4n6u_normal.jpeg",
      "id" : 1632891,
      "verified" : false
    }
  },
  "id" : 432483330777677824,
  "created_at" : "2014-02-09 11:57:15 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Aisha Brown",
      "screen_name" : "amyaishab",
      "indices" : [ 49, 59 ],
      "id_str" : "900029641",
      "id" : 900029641
    }, {
      "name" : "Hapax Hegemon",
      "screen_name" : "hapaxhegemon",
      "indices" : [ 60, 73 ],
      "id_str" : "2268932004",
      "id" : 2268932004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/ZYM3HrudO3",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Hapax_legomenon",
      "display_url" : "en.wikipedia.org\/wiki\/Hapax_leg\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "432154631117238272",
  "geo" : { },
  "id_str" : "432170971399602176",
  "in_reply_to_user_id" : 900029641,
  "text" : "fmi for my information :) http:\/\/t.co\/ZYM3HrudO3 @amyaishab @hapaxhegemon",
  "id" : 432170971399602176,
  "in_reply_to_status_id" : 432154631117238272,
  "created_at" : "2014-02-08 15:16:03 +0000",
  "in_reply_to_screen_name" : "amyaishab",
  "in_reply_to_user_id_str" : "900029641",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 24, 35 ]
    } ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/U9axBBFoHN",
      "expanded_url" : "https:\/\/googledrive.com\/host\/0B7FW2BYaBgeiczNDWTJpZFoyVkE\/search-regex-corpusmooc.mp3",
      "display_url" : "googledrive.com\/host\/0B7FW2BYa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "431912372983193600",
  "text" : "come selector! a bit of #corpusmooc fun part 2 https:\/\/t.co\/U9axBBFoHN",
  "id" : 431912372983193600,
  "created_at" : "2014-02-07 22:08:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "besig",
      "indices" : [ 79, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/peCTHJokvo",
      "expanded_url" : "http:\/\/rt.com\/news\/nuland-phone-chat-ukraine-927\/",
      "display_url" : "rt.com\/news\/nuland-ph\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "431804503726108672",
  "text" : "some interesting managerial talk as well as swearing :0 http:\/\/t.co\/peCTHJokvo #besig",
  "id" : 431804503726108672,
  "created_at" : "2014-02-07 14:59:50 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Graham",
      "screen_name" : "onalifeglug",
      "indices" : [ 0, 12 ],
      "id_str" : "19516039",
      "id" : 19516039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "431781374169985024",
  "geo" : { },
  "id_str" : "431785771947683841",
  "in_reply_to_user_id" : 19516039,
  "text" : "@onalifeglug bumped into him one time and irked him by saying i used to listen to his music :)",
  "id" : 431785771947683841,
  "in_reply_to_status_id" : 431781374169985024,
  "created_at" : "2014-02-07 13:45:24 +0000",
  "in_reply_to_screen_name" : "onalifeglug",
  "in_reply_to_user_id_str" : "19516039",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gretchen McCulloch",
      "screen_name" : "GretchenAMcC",
      "indices" : [ 3, 16 ],
      "id_str" : "920491754",
      "id" : 920491754
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/zMH2thKwIy",
      "expanded_url" : "http:\/\/the-toast.net\/2014\/02\/06\/linguist-explains-grammar-doge-wow",
      "display_url" : "the-toast.net\/2014\/02\/06\/lin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "431762939973234688",
  "text" : "RT @GretchenAMcC: \"Broadly speaking, second-generation internet language plays with grammar instead of spelling.\" -from http:\/\/t.co\/zMH2thK\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/zMH2thKwIy",
        "expanded_url" : "http:\/\/the-toast.net\/2014\/02\/06\/linguist-explains-grammar-doge-wow",
        "display_url" : "the-toast.net\/2014\/02\/06\/lin\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "431528198149402624",
    "text" : "\"Broadly speaking, second-generation internet language plays with grammar instead of spelling.\" -from http:\/\/t.co\/zMH2thKwIy",
    "id" : 431528198149402624,
    "created_at" : "2014-02-06 20:41:54 +0000",
    "user" : {
      "name" : "Gretchen McCulloch",
      "screen_name" : "GretchenAMcC",
      "protected" : false,
      "id_str" : "920491754",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2800002402\/fb810f2f606e0f1413ed5191e2eac190_normal.png",
      "id" : 920491754,
      "verified" : true
    }
  },
  "id" : 431762939973234688,
  "created_at" : "2014-02-07 12:14:41 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Grevett",
      "screen_name" : "breathyvowel",
      "indices" : [ 0, 13 ],
      "id_str" : "237547177",
      "id" : 237547177
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 33, 44 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "431596338628026368",
  "geo" : { },
  "id_str" : "431758996408508416",
  "in_reply_to_user_id" : 237547177,
  "text" : "@breathyvowel good thing is that #corpusmooc will be available after official end for sometime :)",
  "id" : 431758996408508416,
  "in_reply_to_status_id" : 431596338628026368,
  "created_at" : "2014-02-07 11:59:01 +0000",
  "in_reply_to_screen_name" : "breathyvowel",
  "in_reply_to_user_id_str" : "237547177",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 0, 11 ],
      "id_str" : "144663117",
      "id" : 144663117
    }, {
      "name" : "James Taylor",
      "screen_name" : "theteacherjames",
      "indices" : [ 12, 28 ],
      "id_str" : "71746265",
      "id" : 71746265
    }, {
      "name" : "JohnPfordresher",
      "screen_name" : "JohnPfordresher",
      "indices" : [ 29, 45 ],
      "id_str" : "168973558",
      "id" : 168973558
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FF",
      "indices" : [ 80, 83 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "431552675465818112",
  "geo" : { },
  "id_str" : "431758850589356032",
  "in_reply_to_user_id" : 144663117,
  "text" : "@kevchanwow @theteacherjames @JohnPfordresher a pleasure kevchan, and a massive #FF to all you gents as well :)",
  "id" : 431758850589356032,
  "in_reply_to_status_id" : 431552675465818112,
  "created_at" : "2014-02-07 11:58:26 +0000",
  "in_reply_to_screen_name" : "kevchanwow",
  "in_reply_to_user_id_str" : "144663117",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Grevett",
      "screen_name" : "breathyvowel",
      "indices" : [ 0, 13 ],
      "id_str" : "237547177",
      "id" : 237547177
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 17, 28 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "431438598236540928",
  "geo" : { },
  "id_str" : "431531270246367233",
  "in_reply_to_user_id" : 237547177,
  "text" : "@breathyvowel ah #corpusmooc will fill that need fir sure :)",
  "id" : 431531270246367233,
  "in_reply_to_status_id" : 431438598236540928,
  "created_at" : "2014-02-06 20:54:06 +0000",
  "in_reply_to_screen_name" : "breathyvowel",
  "in_reply_to_user_id_str" : "237547177",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 9, 20 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/6EbbT2Q5sD",
      "expanded_url" : "http:\/\/timemapper.okfnlabs.org\/muranava\/history-of-computerised-corpus-tools",
      "display_url" : "timemapper.okfnlabs.org\/muranava\/histo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "431415626326757377",
  "text" : "get your #corpusmooc &amp; computers freak on by watching Mike Scott video and\/or timeline http:\/\/t.co\/6EbbT2Q5sD :)",
  "id" : 431415626326757377,
  "created_at" : "2014-02-06 13:14:35 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "indices" : [ 3, 14 ],
      "id_str" : "144663117",
      "id" : 144663117
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ELTChat",
      "indices" : [ 97, 105 ]
    }, {
      "text" : "TESOL",
      "indices" : [ 106, 112 ]
    }, {
      "text" : "EFL",
      "indices" : [ 113, 117 ]
    }, {
      "text" : "ItsOKtoCry",
      "indices" : [ 118, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/wHCNAZhWqM",
      "expanded_url" : "http:\/\/theotherthingsmatter.wordpress.com\/2014\/02\/06\/a-story-of-giving-is-a-story-of-learning\/",
      "display_url" : "theotherthingsmatter.wordpress.com\/2014\/02\/06\/a-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "431353095801806848",
  "text" : "RT @kevchanwow: Sharing a story about sharing a story.  A new blog post: http:\/\/t.co\/wHCNAZhWqM  #ELTChat #TESOL #EFL #ItsOKtoCry",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ELTChat",
        "indices" : [ 81, 89 ]
      }, {
        "text" : "TESOL",
        "indices" : [ 90, 96 ]
      }, {
        "text" : "EFL",
        "indices" : [ 97, 101 ]
      }, {
        "text" : "ItsOKtoCry",
        "indices" : [ 102, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/wHCNAZhWqM",
        "expanded_url" : "http:\/\/theotherthingsmatter.wordpress.com\/2014\/02\/06\/a-story-of-giving-is-a-story-of-learning\/",
        "display_url" : "theotherthingsmatter.wordpress.com\/2014\/02\/06\/a-s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "431341048481083392",
    "text" : "Sharing a story about sharing a story.  A new blog post: http:\/\/t.co\/wHCNAZhWqM  #ELTChat #TESOL #EFL #ItsOKtoCry",
    "id" : 431341048481083392,
    "created_at" : "2014-02-06 08:18:14 +0000",
    "user" : {
      "name" : "Kevin Stein",
      "screen_name" : "kevchanwow",
      "protected" : false,
      "id_str" : "144663117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/559618421839507456\/nPF7dP47_normal.jpeg",
      "id" : 144663117,
      "verified" : false
    }
  },
  "id" : 431353095801806848,
  "created_at" : "2014-02-06 09:06:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pete Sanderson",
      "screen_name" : "LessonToolbox",
      "indices" : [ 0, 14 ],
      "id_str" : "1239302874",
      "id" : 1239302874
    }, {
      "name" : "David Rogers",
      "screen_name" : "davidErogers",
      "indices" : [ 15, 28 ],
      "id_str" : "14616464",
      "id" : 14616464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "431156230867152896",
  "geo" : { },
  "id_str" : "431157125562105856",
  "in_reply_to_user_id" : 1239302874,
  "text" : "@LessonToolbox @davidErogers looks like English to me :\/",
  "id" : 431157125562105856,
  "in_reply_to_status_id" : 431156230867152896,
  "created_at" : "2014-02-05 20:07:23 +0000",
  "in_reply_to_screen_name" : "LessonToolbox",
  "in_reply_to_user_id_str" : "1239302874",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian James",
      "screen_name" : "ij64",
      "indices" : [ 3, 8 ],
      "id_str" : "13726222",
      "id" : 13726222
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/ij64\/status\/431016925234081793\/photo\/1",
      "indices" : [ 127, 140 ],
      "url" : "http:\/\/t.co\/8Ko0xlJrj0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BftHnCGCMAAW976.jpg",
      "id_str" : "431016925246664704",
      "id" : 431016925246664704,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BftHnCGCMAAW976.jpg",
      "sizes" : [ {
        "h" : 363,
        "resize" : "fit",
        "w" : 860
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 144,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 253,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 363,
        "resize" : "fit",
        "w" : 860
      } ],
      "display_url" : "pic.twitter.com\/8Ko0xlJrj0"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/0uBEFnb2rd",
      "expanded_url" : "http:\/\/viralelt.wordpress.com",
      "display_url" : "viralelt.wordpress.com"
    } ]
  },
  "geo" : { },
  "id_str" : "431026405267496960",
  "text" : "RT @ij64: Thought I'd launch a new blog today - http:\/\/t.co\/0uBEFnb2rd - When you get a mo, you know, have a look if you like. http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ij64\/status\/431016925234081793\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/8Ko0xlJrj0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BftHnCGCMAAW976.jpg",
        "id_str" : "431016925246664704",
        "id" : 431016925246664704,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BftHnCGCMAAW976.jpg",
        "sizes" : [ {
          "h" : 363,
          "resize" : "fit",
          "w" : 860
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 144,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 253,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 363,
          "resize" : "fit",
          "w" : 860
        } ],
        "display_url" : "pic.twitter.com\/8Ko0xlJrj0"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 60 ],
        "url" : "http:\/\/t.co\/0uBEFnb2rd",
        "expanded_url" : "http:\/\/viralelt.wordpress.com",
        "display_url" : "viralelt.wordpress.com"
      } ]
    },
    "geo" : { },
    "id_str" : "431016925234081793",
    "text" : "Thought I'd launch a new blog today - http:\/\/t.co\/0uBEFnb2rd - When you get a mo, you know, have a look if you like. http:\/\/t.co\/8Ko0xlJrj0",
    "id" : 431016925234081793,
    "created_at" : "2014-02-05 10:50:17 +0000",
    "user" : {
      "name" : "Ian James",
      "screen_name" : "ij64",
      "protected" : false,
      "id_str" : "13726222",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/743406996901212160\/a0S-1Kiw_normal.jpg",
      "id" : 13726222,
      "verified" : false
    }
  },
  "id" : 431026405267496960,
  "created_at" : "2014-02-05 11:27:57 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol Goodey",
      "screen_name" : "cgoodey",
      "indices" : [ 3, 11 ],
      "id_str" : "26606833",
      "id" : 26606833
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusMOOC",
      "indices" : [ 25, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431014778791002112",
  "text" : "RT @cgoodey: I recommend #corpusMOOC 'In Conversation' bits. Just watched T.McEnery &amp; M.Hoey share stories about collocation &amp; language lea\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpusMOOC",
        "indices" : [ 12, 23 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "431013895810330624",
    "text" : "I recommend #corpusMOOC 'In Conversation' bits. Just watched T.McEnery &amp; M.Hoey share stories about collocation &amp; language learning. Great!",
    "id" : 431013895810330624,
    "created_at" : "2014-02-05 10:38:15 +0000",
    "user" : {
      "name" : "Carol Goodey",
      "screen_name" : "cgoodey",
      "protected" : false,
      "id_str" : "26606833",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/739764539839926273\/EtEpZHsA_normal.jpg",
      "id" : 26606833,
      "verified" : false
    }
  },
  "id" : 431014778791002112,
  "created_at" : "2014-02-05 10:41:45 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yolanda B. Schell",
      "screen_name" : "mattellman",
      "indices" : [ 0, 11 ],
      "id_str" : "725597315860434945",
      "id" : 725597315860434945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/xnQD3saEGY",
      "expanded_url" : "http:\/\/theweek.com\/article\/index\/255746\/what-grocery-stores-can-teach-us-about-linguistics",
      "display_url" : "theweek.com\/article\/index\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "430937069775384577",
  "geo" : { },
  "id_str" : "430993117211152384",
  "in_reply_to_user_id" : 394987109,
  "text" : "@mattellman hi matt thought of your latest post when reading this http:\/\/t.co\/xnQD3saEGY :)",
  "id" : 430993117211152384,
  "in_reply_to_status_id" : 430937069775384577,
  "created_at" : "2014-02-05 09:15:41 +0000",
  "in_reply_to_screen_name" : "MatthewEllman",
  "in_reply_to_user_id_str" : "394987109",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 10, 21 ]
    } ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/D8owMgeBiu",
      "expanded_url" : "https:\/\/plus.google.com\/104940199413423400545\/posts\/HyPGT1nF5cX",
      "display_url" : "plus.google.com\/10494019941342\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "430856826351910912",
  "text" : "come play #corpusmooc picture bingo https:\/\/t.co\/D8owMgeBiu",
  "id" : 430856826351910912,
  "created_at" : "2014-02-05 00:14:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "indices" : [ 3, 17 ],
      "id_str" : "25388528",
      "id" : 25388528
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ettipad",
      "indices" : [ 106, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/0x9BqEUkJq",
      "expanded_url" : "http:\/\/hackeducation.com\/2014\/02\/04\/the-history-of-the-future-of-ed-tech",
      "display_url" : "hackeducation.com\/2014\/02\/04\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "430767320374706176",
  "text" : "RT @audreywatters: The History of the Future of Ed-Tech (notes and slides from my keynote this morning at #ettipad) http:\/\/t.co\/0x9BqEUkJq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ettipad",
        "indices" : [ 87, 95 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/0x9BqEUkJq",
        "expanded_url" : "http:\/\/hackeducation.com\/2014\/02\/04\/the-history-of-the-future-of-ed-tech",
        "display_url" : "hackeducation.com\/2014\/02\/04\/the\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "430765279094661120",
    "text" : "The History of the Future of Ed-Tech (notes and slides from my keynote this morning at #ettipad) http:\/\/t.co\/0x9BqEUkJq",
    "id" : 430765279094661120,
    "created_at" : "2014-02-04 18:10:20 +0000",
    "user" : {
      "name" : "Audrey Watters",
      "screen_name" : "audreywatters",
      "protected" : false,
      "id_str" : "25388528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711668009723498496\/pauFZsdv_normal.jpg",
      "id" : 25388528,
      "verified" : false
    }
  },
  "id" : 430767320374706176,
  "created_at" : "2014-02-04 18:18:27 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "indices" : [ 0, 9 ],
      "id_str" : "167020390",
      "id" : 167020390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430758531545841666",
  "geo" : { },
  "id_str" : "430761035801182208",
  "in_reply_to_user_id" : 167020390,
  "text" : "@antlabjp ok, any reason you chose R in particular?",
  "id" : 430761035801182208,
  "in_reply_to_status_id" : 430758531545841666,
  "created_at" : "2014-02-04 17:53:28 +0000",
  "in_reply_to_screen_name" : "antlabjp",
  "in_reply_to_user_id_str" : "167020390",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "indices" : [ 4, 13 ],
      "id_str" : "167020390",
      "id" : 167020390
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 28, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430741985909932032",
  "text" : "ooh @antlabjp mentions in a #corpusmooc post that next version AntConc will include R environment :0",
  "id" : 430741985909932032,
  "created_at" : "2014-02-04 16:37:46 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "indices" : [ 3, 13 ],
      "id_str" : "6531902",
      "id" : 6531902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/lEjB3Mf5rn",
      "expanded_url" : "http:\/\/ow.ly\/tg5Wa",
      "display_url" : "ow.ly\/tg5Wa"
    } ]
  },
  "geo" : { },
  "id_str" : "430739519378571264",
  "text" : "RT @medialens: Media Alert: 'Not Even Close To Reality' - Filtering Sources On The Syrian War http:\/\/t.co\/lEjB3Mf5rn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/lEjB3Mf5rn",
        "expanded_url" : "http:\/\/ow.ly\/tg5Wa",
        "display_url" : "ow.ly\/tg5Wa"
      } ]
    },
    "geo" : { },
    "id_str" : "430653600172240896",
    "text" : "Media Alert: 'Not Even Close To Reality' - Filtering Sources On The Syrian War http:\/\/t.co\/lEjB3Mf5rn",
    "id" : 430653600172240896,
    "created_at" : "2014-02-04 10:46:34 +0000",
    "user" : {
      "name" : "Media Lens",
      "screen_name" : "medialens",
      "protected" : false,
      "id_str" : "6531902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378843257\/medialens_twitter_logo_cherry_normal.jpg",
      "id" : 6531902,
      "verified" : false
    }
  },
  "id" : 430739519378571264,
  "created_at" : "2014-02-04 16:27:58 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DDlpu\u01DD\u0265 \u01DDuu\u0250",
      "screen_name" : "AnneHendler",
      "indices" : [ 64, 76 ],
      "id_str" : "525013404",
      "id" : 525013404
    }, {
      "name" : "Alex Grevett",
      "screen_name" : "breathyvowel",
      "indices" : [ 77, 90 ],
      "id_str" : "237547177",
      "id" : 237547177
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/P4Wt4wNCoe",
      "expanded_url" : "https:\/\/plus.google.com\/104940199413423400545\/posts\/3ZbuTQeACDc",
      "display_url" : "plus.google.com\/10494019941342\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "430731967957438464",
  "geo" : { },
  "id_str" : "430733416015728640",
  "in_reply_to_user_id" : 525013404,
  "text" : "indeed especially the 2 corpus use vids https:\/\/t.co\/P4Wt4wNCoe @AnneHendler @breathyvowel :)",
  "id" : 430733416015728640,
  "in_reply_to_status_id" : 430731967957438464,
  "created_at" : "2014-02-04 16:03:43 +0000",
  "in_reply_to_screen_name" : "AnneHendler",
  "in_reply_to_user_id_str" : "525013404",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Divya Madhavan",
      "screen_name" : "_divyamadhavan",
      "indices" : [ 0, 15 ],
      "id_str" : "408492806",
      "id" : 408492806
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430590533224775680",
  "geo" : { },
  "id_str" : "430628237132054529",
  "in_reply_to_user_id" : 408492806,
  "text" : "@_divyamadhavan looking fwd to the voyage cap'n :)",
  "id" : 430628237132054529,
  "in_reply_to_status_id" : 430590533224775680,
  "created_at" : "2014-02-04 09:05:47 +0000",
  "in_reply_to_screen_name" : "_divyamadhavan",
  "in_reply_to_user_id_str" : "408492806",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "indices" : [ 3, 12 ],
      "id_str" : "167020390",
      "id" : 167020390
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusMOOC",
      "indices" : [ 54, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/YYICPqc8yL",
      "expanded_url" : "http:\/\/www.youtube.com\/playlist?list=PLiRIDpYmiC0Ta0-Hdvc1D7hG6dmiS_TZj",
      "display_url" : "youtube.com\/playlist?list=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "430627816192106496",
  "text" : "RT @antlabjp: All the AntConc tutorial videos used at #corpusMOOC are now here http:\/\/t.co\/YYICPqc8yL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpusMOOC",
        "indices" : [ 40, 51 ]
      } ],
      "urls" : [ {
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/YYICPqc8yL",
        "expanded_url" : "http:\/\/www.youtube.com\/playlist?list=PLiRIDpYmiC0Ta0-Hdvc1D7hG6dmiS_TZj",
        "display_url" : "youtube.com\/playlist?list=\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "430568218449551360",
    "text" : "All the AntConc tutorial videos used at #corpusMOOC are now here http:\/\/t.co\/YYICPqc8yL",
    "id" : 430568218449551360,
    "created_at" : "2014-02-04 05:07:17 +0000",
    "user" : {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "protected" : false,
      "id_str" : "167020390",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/428183580821315584\/ocgCI7Er_normal.jpeg",
      "id" : 167020390,
      "verified" : false
    }
  },
  "id" : 430627816192106496,
  "created_at" : "2014-02-04 09:04:06 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 77, 93 ],
      "id_str" : "823905",
      "id" : 823905
    }, {
      "name" : "Divya Madhavan",
      "screen_name" : "_divyamadhavan",
      "indices" : [ 97, 112 ],
      "id_str" : "408492806",
      "id" : 408492806
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/mQV9CiW7fX",
      "expanded_url" : "http:\/\/wp.me\/p3augf-cv",
      "display_url" : "wp.me\/p3augf-cv"
    } ]
  },
  "geo" : { },
  "id_str" : "430435119191429120",
  "text" : "Whose English? A window into written academic ELF http:\/\/t.co\/mQV9CiW7fX via @wordpressdotcom cc @_divyamadhavan",
  "id" : 430435119191429120,
  "created_at" : "2014-02-03 20:18:24 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luca Marchiori",
      "screen_name" : "chuechebueb",
      "indices" : [ 0, 12 ],
      "id_str" : "1334451956",
      "id" : 1334451956
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430430192675209216",
  "geo" : { },
  "id_str" : "430434285934223360",
  "in_reply_to_user_id" : 1334451956,
  "text" : "@chuechebueb hmm not sure i like :\/",
  "id" : 430434285934223360,
  "in_reply_to_status_id" : 430430192675209216,
  "created_at" : "2014-02-03 20:15:05 +0000",
  "in_reply_to_screen_name" : "chuechebueb",
  "in_reply_to_user_id_str" : "1334451956",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nik Molnar",
      "screen_name" : "nikmd23",
      "indices" : [ 0, 8 ],
      "id_str" : "14169419",
      "id" : 14169419
    }, {
      "name" : "Paul Rayson",
      "screen_name" : "perayson",
      "indices" : [ 9, 18 ],
      "id_str" : "263108959",
      "id" : 263108959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/QzuPLDobj3",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=B8Wd831gUt4",
      "display_url" : "youtube.com\/watch?v=B8Wd83\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "429976449664446464",
  "geo" : { },
  "id_str" : "430421263249440768",
  "in_reply_to_user_id" : 14169419,
  "text" : "@nikmd23 @perayson these lot need to stop being engineers https:\/\/t.co\/QzuPLDobj3 :0",
  "id" : 430421263249440768,
  "in_reply_to_status_id" : 429976449664446464,
  "created_at" : "2014-02-03 19:23:20 +0000",
  "in_reply_to_screen_name" : "nikmd23",
  "in_reply_to_user_id_str" : "14169419",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nooj",
      "indices" : [ 9, 14 ]
    }, {
      "text" : "corpusmooc",
      "indices" : [ 76, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/JaxZ9rvlC7",
      "expanded_url" : "http:\/\/www.nooj4nlp.net\/pages\/download.html",
      "display_url" : "nooj4nlp.net\/pages\/download\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "430395192265289728",
  "text" : "oh lordy #nooj opensource texttool with java version http:\/\/t.co\/JaxZ9rvlC7 #corpusmooc",
  "id" : 430395192265289728,
  "created_at" : "2014-02-03 17:39:44 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 3, 18 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/Y4DJpTO5Sg",
      "expanded_url" : "http:\/\/wp.me\/p3X7Ks-Gf",
      "display_url" : "wp.me\/p3X7Ks-Gf"
    } ]
  },
  "geo" : { },
  "id_str" : "430058909899194369",
  "text" : "RT @MrChrisJWilson: Why I'm Not Blogging About TEFL At The Moment http:\/\/t.co\/Y4DJpTO5Sg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/Y4DJpTO5Sg",
        "expanded_url" : "http:\/\/wp.me\/p3X7Ks-Gf",
        "display_url" : "wp.me\/p3X7Ks-Gf"
      } ]
    },
    "geo" : { },
    "id_str" : "430040501652557824",
    "text" : "Why I'm Not Blogging About TEFL At The Moment http:\/\/t.co\/Y4DJpTO5Sg",
    "id" : 430040501652557824,
    "created_at" : "2014-02-02 18:10:20 +0000",
    "user" : {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "protected" : false,
      "id_str" : "20760283",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744952885595758592\/H4bmsUn3_normal.jpg",
      "id" : 20760283,
      "verified" : false
    }
  },
  "id" : 430058909899194369,
  "created_at" : "2014-02-02 19:23:28 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Wilson",
      "screen_name" : "MrChrisJWilson",
      "indices" : [ 0, 15 ],
      "id_str" : "20760283",
      "id" : 20760283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430040501652557824",
  "geo" : { },
  "id_str" : "430058769951649792",
  "in_reply_to_user_id" : 20760283,
  "text" : "@MrChrisJWilson dam...your blogging voice sure missed, keep the faith",
  "id" : 430058769951649792,
  "in_reply_to_status_id" : 430040501652557824,
  "created_at" : "2014-02-02 19:22:55 +0000",
  "in_reply_to_screen_name" : "MrChrisJWilson",
  "in_reply_to_user_id_str" : "20760283",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/muranava\/status\/429989163618676736\/photo\/1",
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/ntOnuWZXeo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bfeg3bsCMAIT7VD.png",
      "id_str" : "429989163622871042",
      "id" : 429989163622871042,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bfeg3bsCMAIT7VD.png",
      "sizes" : [ {
        "h" : 213,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/ntOnuWZXeo"
    } ],
    "hashtags" : [ {
      "text" : "corpusmooc",
      "indices" : [ 19, 30 ]
    }, {
      "text" : "openpandora",
      "indices" : [ 49, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "429989163618676736",
  "text" : "TACT on the go for #corpusmooc screenshot dosbox #openpandora nice :) http:\/\/t.co\/ntOnuWZXeo",
  "id" : 429989163618676736,
  "created_at" : "2014-02-02 14:46:20 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yuichiro Kobayashi",
      "screen_name" : "langstat",
      "indices" : [ 3, 12 ],
      "id_str" : "108896452",
      "id" : 108896452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 125, 140 ],
      "url" : "http:\/\/t.co\/OFyb8kJCUf",
      "expanded_url" : "http:\/\/tm.durusau.net\/?p=50098",
      "display_url" : "tm.durusau.net\/?p=50098"
    } ]
  },
  "geo" : { },
  "id_str" : "429913939074625536",
  "text" : "RT @langstat: PornGram is an n-gram program that plots the evolution of word frequencies in almost 800,000 porn video titles http:\/\/t.co\/OF\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/OFyb8kJCUf",
        "expanded_url" : "http:\/\/tm.durusau.net\/?p=50098",
        "display_url" : "tm.durusau.net\/?p=50098"
      } ]
    },
    "geo" : { },
    "id_str" : "429803062514184192",
    "text" : "PornGram is an n-gram program that plots the evolution of word frequencies in almost 800,000 porn video titles http:\/\/t.co\/OFyb8kJCUf \u4F55\u306B\u4F7F\u3046\u306E\uFF1F",
    "id" : 429803062514184192,
    "created_at" : "2014-02-02 02:26:50 +0000",
    "user" : {
      "name" : "Yuichiro Kobayashi",
      "screen_name" : "langstat",
      "protected" : false,
      "id_str" : "108896452",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1111159202\/profile_normal.gif",
      "id" : 108896452,
      "verified" : false
    }
  },
  "id" : 429913939074625536,
  "created_at" : "2014-02-02 09:47:25 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angus B Grieve-Smith",
      "screen_name" : "grvsmth",
      "indices" : [ 3, 11 ],
      "id_str" : "22381639",
      "id" : 22381639
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 125, 140 ],
      "url" : "http:\/\/t.co\/L91ExuDwIU",
      "expanded_url" : "http:\/\/grieve-smith.com\/blog\/2014\/02\/non-native-speech-role-models\/",
      "display_url" : "grieve-smith.com\/blog\/2014\/02\/n\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429913751996084224",
  "text" : "RT @grvsmth: New post: Non-native speech role models. Ban Ki-Moon, Luis von Ahn, Guillermo del Toro, Yao Ming, and who else? http:\/\/t.co\/L9\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/L91ExuDwIU",
        "expanded_url" : "http:\/\/grieve-smith.com\/blog\/2014\/02\/non-native-speech-role-models\/",
        "display_url" : "grieve-smith.com\/blog\/2014\/02\/n\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "429781130221727744",
    "text" : "New post: Non-native speech role models. Ban Ki-Moon, Luis von Ahn, Guillermo del Toro, Yao Ming, and who else? http:\/\/t.co\/L91ExuDwIU",
    "id" : 429781130221727744,
    "created_at" : "2014-02-02 00:59:41 +0000",
    "user" : {
      "name" : "Angus B Grieve-Smith",
      "screen_name" : "grvsmth",
      "protected" : false,
      "id_str" : "22381639",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/94827231\/portrait_normal.png",
      "id" : 22381639,
      "verified" : false
    }
  },
  "id" : 429913751996084224,
  "created_at" : "2014-02-02 09:46:40 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth Anne",
      "screen_name" : "eannegrenoble",
      "indices" : [ 0, 14 ],
      "id_str" : "19869781",
      "id" : 19869781
    }, {
      "name" : "Carol Goodey",
      "screen_name" : "cgoodey",
      "indices" : [ 15, 23 ],
      "id_str" : "26606833",
      "id" : 26606833
    }, {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "indices" : [ 24, 37 ],
      "id_str" : "1685397408",
      "id" : 1685397408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "429719783181807616",
  "geo" : { },
  "id_str" : "429722308807110656",
  "in_reply_to_user_id" : 19869781,
  "text" : "@eannegrenoble @cgoodey @harrisonmike :)",
  "id" : 429722308807110656,
  "in_reply_to_status_id" : 429719783181807616,
  "created_at" : "2014-02-01 21:05:56 +0000",
  "in_reply_to_screen_name" : "eannegrenoble",
  "in_reply_to_user_id_str" : "19869781",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Voce",
      "screen_name" : "julievoce",
      "indices" : [ 3, 13 ],
      "id_str" : "14796876",
      "id" : 14796876
    }, {
      "name" : "FutureLearn",
      "screen_name" : "FutureLearn",
      "indices" : [ 99, 111 ],
      "id_str" : "999095640",
      "id" : 999095640
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusMOOC",
      "indices" : [ 87, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/0uvxMpxufX",
      "expanded_url" : "http:\/\/wp.me\/p4hCTH-9",
      "display_url" : "wp.me\/p4hCTH-9"
    } ]
  },
  "geo" : { },
  "id_str" : "429662737040678912",
  "text" : "RT @julievoce: My view on week 1 of the Corpus Linguistics MOOC http:\/\/t.co\/0uvxMpxufX #corpusMOOC @futurelearn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "FutureLearn",
        "screen_name" : "FutureLearn",
        "indices" : [ 84, 96 ],
        "id_str" : "999095640",
        "id" : 999095640
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpusMOOC",
        "indices" : [ 72, 83 ]
      } ],
      "urls" : [ {
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/0uvxMpxufX",
        "expanded_url" : "http:\/\/wp.me\/p4hCTH-9",
        "display_url" : "wp.me\/p4hCTH-9"
      } ]
    },
    "geo" : { },
    "id_str" : "429633129305763841",
    "text" : "My view on week 1 of the Corpus Linguistics MOOC http:\/\/t.co\/0uvxMpxufX #corpusMOOC @futurelearn",
    "id" : 429633129305763841,
    "created_at" : "2014-02-01 15:11:34 +0000",
    "user" : {
      "name" : "Julie Voce",
      "screen_name" : "julievoce",
      "protected" : false,
      "id_str" : "14796876",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/54269403\/julievoce2_normal.jpg",
      "id" : 14796876,
      "verified" : false
    }
  },
  "id" : 429662737040678912,
  "created_at" : "2014-02-01 17:09:13 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "indices" : [ 0, 9 ],
      "id_str" : "167020390",
      "id" : 167020390
    }, {
      "name" : "Andrew Hardie",
      "screen_name" : "HardieResearch",
      "indices" : [ 10, 25 ],
      "id_str" : "970452764",
      "id" : 970452764
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "429610501971001344",
  "geo" : { },
  "id_str" : "429611627961253889",
  "in_reply_to_user_id" : 167020390,
  "text" : "@antlabjp @HardieResearch want to compare Brown &amp; LOB; those checkboxes would help identify words that don't appear in either list?",
  "id" : 429611627961253889,
  "in_reply_to_status_id" : 429610501971001344,
  "created_at" : "2014-02-01 13:46:08 +0000",
  "in_reply_to_screen_name" : "antlabjp",
  "in_reply_to_user_id_str" : "167020390",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "indices" : [ 0, 9 ],
      "id_str" : "167020390",
      "id" : 167020390
    }, {
      "name" : "Andrew Hardie",
      "screen_name" : "HardieResearch",
      "indices" : [ 10, 25 ],
      "id_str" : "970452764",
      "id" : 970452764
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "429600250328662016",
  "geo" : { },
  "id_str" : "429608566492647424",
  "in_reply_to_user_id" : 167020390,
  "text" : "@antlabjp @HardieResearch  words that don't appear in either list or file are shown at bottom of results screen but with no freq data",
  "id" : 429608566492647424,
  "in_reply_to_status_id" : 429600250328662016,
  "created_at" : "2014-02-01 13:33:58 +0000",
  "in_reply_to_screen_name" : "antlabjp",
  "in_reply_to_user_id_str" : "167020390",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30B3\u30FC\u30D1\u30B9\u8A00\u8A9E\u5B66\u305F\u3093",
      "screen_name" : "CorpusTan",
      "indices" : [ 0, 10 ],
      "id_str" : "2309797189",
      "id" : 2309797189
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "429598978246598656",
  "in_reply_to_user_id" : 2309797189,
  "text" : "@CorpusTan thanks for RT of timeline :)",
  "id" : 429598978246598656,
  "created_at" : "2014-02-01 12:55:52 +0000",
  "in_reply_to_screen_name" : "CorpusTan",
  "in_reply_to_user_id_str" : "2309797189",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurence Anthony",
      "screen_name" : "antlabjp",
      "indices" : [ 0, 9 ],
      "id_str" : "167020390",
      "id" : 167020390
    }, {
      "name" : "Andrew Hardie",
      "screen_name" : "HardieResearch",
      "indices" : [ 10, 25 ],
      "id_str" : "970452764",
      "id" : 970452764
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "429581603791056896",
  "geo" : { },
  "id_str" : "429598728266080256",
  "in_reply_to_user_id" : 167020390,
  "text" : "@antlabjp @HardieResearch thanks, the not in file\/list checkbox does not list frequency of those items?",
  "id" : 429598728266080256,
  "in_reply_to_status_id" : 429581603791056896,
  "created_at" : "2014-02-01 12:54:53 +0000",
  "in_reply_to_screen_name" : "antlabjp",
  "in_reply_to_user_id_str" : "167020390",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "indices" : [ 3, 16 ],
      "id_str" : "1685397408",
      "id" : 1685397408
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corpusMOOC",
      "indices" : [ 18, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/pPW88A1zpH",
      "expanded_url" : "http:\/\/bit.ly\/LxVjdR",
      "display_url" : "bit.ly\/LxVjdR"
    } ]
  },
  "geo" : { },
  "id_str" : "429401411550728193",
  "text" : "RT @harrisonmike: #corpusMOOC \u2013 Corpus linguistics week 1 http:\/\/t.co\/pPW88A1zpH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "corpusMOOC",
        "indices" : [ 0, 11 ]
      } ],
      "urls" : [ {
        "indices" : [ 40, 62 ],
        "url" : "http:\/\/t.co\/pPW88A1zpH",
        "expanded_url" : "http:\/\/bit.ly\/LxVjdR",
        "display_url" : "bit.ly\/LxVjdR"
      } ]
    },
    "geo" : { },
    "id_str" : "429367592399429632",
    "text" : "#corpusMOOC \u2013 Corpus linguistics week 1 http:\/\/t.co\/pPW88A1zpH",
    "id" : 429367592399429632,
    "created_at" : "2014-01-31 21:36:25 +0000",
    "user" : {
      "name" : "Mike Harrison",
      "screen_name" : "harrisonmike",
      "protected" : false,
      "id_str" : "1685397408",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/697937835127672832\/Z5BuTNo2_normal.jpg",
      "id" : 1685397408,
      "verified" : false
    }
  },
  "id" : 429401411550728193,
  "created_at" : "2014-01-31 23:50:49 +0000",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Rayson",
      "screen_name" : "perayson",
      "indices" : [ 0, 9 ],
      "id_str" : "263108959",
      "id" : 263108959
    }, {
      "name" : "Andrew Hardie",
      "screen_name" : "HardieResearch",
      "indices" : [ 10, 25 ],
      "id_str" : "970452764",
      "id" : 970452764
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "429389856998162432",
  "geo" : { },
  "id_str" : "429391643968421890",
  "in_reply_to_user_id" : 263108959,
  "text" : "@perayson @HardieResearch okay updated thanks :)",
  "id" : 429391643968421890,
  "in_reply_to_status_id" : 429389856998162432,
  "created_at" : "2014-01-31 23:12:00 +0000",
  "in_reply_to_screen_name" : "perayson",
  "in_reply_to_user_id_str" : "263108959",
  "user" : {
    "name" : "Mura Nava",
    "screen_name" : "muranava",
    "protected" : false,
    "id_str" : "18602422",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1801295431\/wnw_sprite_normal.gif",
    "id" : 18602422,
    "verified" : false
  }
} ]